package gentest.org.apache.commons.compress.archivers.sevenz.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.sevenz.*;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.LinkedList;
import java.util.zip.CRC32;
import org.apache.commons.compress.utils.BoundedInputStream;
import org.apache.commons.compress.utils.CRC32VerifyingInputStream;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class SevenZFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                          public void testGetCurrentStream_EmptyFileEntry() throws Exception {
                                                                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test"));
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                              Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                              archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                              Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                              currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                              currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Mock FileEntry array
                                                                                                                                                                                                                                                                                                              Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                                                                                                                                              Object fileEntry = mock(fileEntryClass);
                                                                                                                                                                                                                                                                                                              Method getSizeMethod = fileEntryClass.getMethod("getSize");
                                                                                                                                                                                                                                                                                                              when(getSizeMethod.invoke(fileEntry)).thenReturn(0L);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              Object[] filesArray = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                                                                                                                                                                                                                                              filesArray[0] = fileEntry;
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              Method getFilesMethod = archive.getClass().getMethod("getFiles");
                                                                                                                                                                                                                                                                                                              when(getFilesMethod.invoke(archive)).thenReturn(filesArray);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Get private method
                                                                                                                                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Execute
                                                                                                                                                                                                                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                                                                              assertNotNull(result);
                                                                                                                                                                                                                                                                                                              assertEquals(0, result.available());
                                                                                                                                                                                                                                                                                                              assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                      public void testGetCurrentStream_NoDeferredStreams() throws Exception {
                                                                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test"));
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Mock archive contents
                                                                                                                                                                                                                                                                                                          Class<?>[] declaredClasses = archiveField.getType().getDeclaredClasses();
                                                                                                                                                                                                                                                                                                          Object fileEntry = mock(declaredClasses[0]);
                                                                                                                                                                                                                                                                                                          Field filesField = archiveField.getType().getDeclaredField("files");
                                                                                                                                                                                                                                                                                                          filesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          filesField.set(archive, new Object[]{fileEntry});
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Method getSizeMethod = fileEntry.getClass().getDeclaredMethod("getSize");
                                                                                                                                                                                                                                                                                                          when(getSizeMethod.invoke(fileEntry)).thenReturn(100L);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Set archive field
                                                                                                                                                                                                                                                                                                          archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Expected exception
                                                                                                                                                                                                                                                                                                          ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                                                          expectedException.expect(IllegalStateException.class);
                                                                                                                                                                                                                                                                                                          expectedException.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Use reflection to call private method
                                                                                                                                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                          getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                      public void testGetCurrentStream_SingleDeferredStream() throws Exception {
                                                                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                                                                          SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                                                                                          InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                                                          streams.add(mockStream);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field filesField = archiveField.getType().getDeclaredField("files");
                                                                                                                                                                                                                                                                                                          filesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object fileEntry = mock(filesField.getType().getComponentType());
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          when(sevenZFile.getNextEntry()).thenCallRealMethod();
                                                                                                                                                                                                                                                                                                          archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Object[] fileEntries = (Object[]) Array.newInstance(fileEntry.getClass(), 1);
                                                                                                                                                                                                                                                                                                          fileEntries[0] = fileEntry;
                                                                                                                                                                                                                                                                                                          filesField.set(archive, fileEntries);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Method getSizeMethod = fileEntry.getClass().getDeclaredMethod("getSize");
                                                                                                                                                                                                                                                                                                          when(getSizeMethod.invoke(fileEntry)).thenReturn(100L);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                                                                                                          assertSame(mockStream, result);
                                                                                                                                                                                                                                                                                                          assertEquals(1, streams.size()); // Should not modify the list
                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                      public void testGetCurrentStream_MultipleDeferredStreams() throws Exception {
                                                                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z")); // Create real instance
                                                                                                                                                                                                                                                                                                          InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                          InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                          InputStream mockStream3 = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                                                          streams.add(mockStream1);
                                                                                                                                                                                                                                                                                                          streams.add(mockStream2);
                                                                                                                                                                                                                                                                                                          streams.add(mockStream3);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                                                          filesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object fileEntry = mock(filesField.getType().getComponentType());
                                                                                                                                                                                                                                                                                                          filesField.set(archive, new Object[]{fileEntry});
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field sizeField = fileEntry.getClass().getDeclaredField("size");
                                                                                                                                                                                                                                                                                                          sizeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          sizeField.set(fileEntry, 100L);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Get the private method via reflection
                                                                                                                                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                                                                                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                                                                                                          assertSame(mockStream3, result);
                                                                                                                                                                                                                                                                                                          assertEquals(1, streams.size()); // Should have removed first two streams
                                                                                                                                                                                                                                                                                                          verify(mockStream1).close();
                                                                                                                                                                                                                                                                                                          verify(mockStream2).close();
                                                                                                                                                                                                                                                                                                          verify(mockStream1).skip(Long.MAX_VALUE);
                                                                                                                                                                                                                                                                                                          verify(mockStream2).skip(Long.MAX_VALUE);
                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                      public void testGetCurrentStream_IOExceptionDuringSkip() throws Exception {
                                                                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                                                                          SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                                                                                          InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                          InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                                                          streams.add(mockStream1);
                                                                                                                                                                                                                                                                                                          streams.add(mockStream2);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field filesField = archiveField.getType().getDeclaredField("files");
                                                                                                                                                                                                                                                                                                          filesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          Object fileEntry = mock(filesField.getType().getComponentType());
                                                                                                                                                                                                                                                                                                          filesField.set(archive, new Object[]{fileEntry});
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Method getSizeMethod = fileEntry.getClass().getMethod("getSize");
                                                                                                                                                                                                                                                                                                          when(getSizeMethod.invoke(fileEntry)).thenReturn(100L);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          when(mockStream1.skip(Long.MAX_VALUE)).thenThrow(new IOException("Test exception"));
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Get private method
                                                                                                                                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Expected exception
                                                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                                                              getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                              fail("Expected IOException");
                                                                                                                                                                                                                                                                                                          } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                              assertTrue(e.getCause() instanceof IOException);
                                                                                                                                                                                                                                                                                                              assertEquals("Test exception", e.getCause().getMessage());
                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                 public void testGetCurrentStreamWithZeroSizeEntry() throws Exception {
                                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Use reflection to access and modify private fields
                                                                                                                                                                                                                                                                                                     // Get the Archive class (package-private)
                                                                                                                                                                                                                                                                                                     Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                                                     Object archive = mock(archiveClass);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Create mock FileEntry array
                                                                                                                                                                                                                                                                                                     Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                                                                                                                                     Object fileEntry = mock(fileEntryClass);
                                                                                                                                                                                                                                                                                                     when(fileEntry.getClass().getMethod("getSize").invoke(fileEntry)).thenReturn(0L);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                                                                                                                                                                                                                                     files[0] = fileEntry;
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     when(archive.getClass().getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Set private fields
                                                                                                                                                                                                                                                                                                     Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                     archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                     currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                     deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Access private getCurrentStream method
                                                                                                                                                                                                                                                                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                     getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                     InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                                     assertNotNull("Should return a stream", result);
                                                                                                                                                                                                                                                                                                     assertEquals("Should return empty stream for zero size entry", 
                                                                                                                                                                                                                                                                                                                 0, result.available());
                                                                                                                                                                                                                                                                                                     assertTrue("Should return ByteArrayInputStream instance", 
                                                                                                                                                                                                                                                                                                                result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Cleanup
                                                                                                                                                                                                                                                                                                     result.close();
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                            public void testGetCurrentStreamWithZeroSizeFile() throws Exception {
                                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Mock entry
                                                                                                                                                                                                                                                                                                SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                                                                when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                // Create and set archive object using reflection
                                                                                                                                                                                                                                                                                                Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                                                Object archive = mock(archiveClass);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Create files array using reflection
                                                                                                                                                                                                                                                                                                Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                                                                                                                                Object[] files = (Object[]) Array.newInstance(fileClass, 1);
                                                                                                                                                                                                                                                                                                Object file = fileClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                                                                                                                Method setEntryMethod = fileClass.getMethod("setEntry", SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                                                                setEntryMethod.invoke(file, entry);
                                                                                                                                                                                                                                                                                                files[0] = file;
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Set archive.files
                                                                                                                                                                                                                                                                                                Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                                                                                                                                filesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                filesField.set(archive, files);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Set archive field in SevenZFile
                                                                                                                                                                                                                                                                                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Test - use reflection to call private method
                                                                                                                                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                                                                                                assertEquals(0, result.available()); // Should be empty stream
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // This test would fail with the mutant since it would skip the zero-size case
                                                                                                                                                                                                                                                                                                // and throw IllegalStateException instead
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                            public void testGetCurrentStreamWithNonZeroSizeFile() throws Exception {
                                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Mock entry
                                                                                                                                                                                                                                                                                                SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                                                                when(entry.getSize()).thenReturn(100L); // Non-zero size
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Create archive instance via reflection since it's package-private
                                                                                                                                                                                                                                                                                                Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                                                Object archive = mock(archiveClass);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Create files array via reflection
                                                                                                                                                                                                                                                                                                Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                                                                                                                                Object[] files = (Object[]) Array.newInstance(fileClass, 1);
                                                                                                                                                                                                                                                                                                Object file = fileClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                                                                                                                Method setEntryMethod = fileClass.getMethod("setEntry", SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                                                                setEntryMethod.invoke(file, entry);
                                                                                                                                                                                                                                                                                                files[0] = file;
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Set files field
                                                                                                                                                                                                                                                                                                when(archive.getClass().getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                                                                                                                                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                                archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                                archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Prepare a real stream to return (not empty)
                                                                                                                                                                                                                                                                                                InputStream mockStream = new ByteArrayInputStream(new byte[100]);
                                                                                                                                                                                                                                                                                                ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                                                streams.add(mockStream);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Test - use reflection to call private method
                                                                                                                                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                                                                                                assertEquals(100, result.available()); // Should have content
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // This test would fail with the mutant since it would return empty stream
                                                                                                                                                                                                                                                                                                // for non-zero size files
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                       public void testGetCurrentStreamWithNegativeSizeShouldNotReturnEmptyStream() throws Exception {
                                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Use reflection to access private archive field and set up mock structure
                                                                                                                                                                                                                                                                                           Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                           archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Create mock entry with negative size
                                                                                                                                                                                                                                                                                           SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                                                           when(mockEntry.getSize()).thenReturn(-1L); // Negative size
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Create mock files array using reflection since Archive is package-private
                                                                                                                                                                                                                                                                                           Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                                           Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                                                                                                                           Constructor<?> fileConstructor = fileClass.getDeclaredConstructor(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                                                           fileConstructor.setAccessible(true);
                                                                                                                                                                                                                                                                                           Object mockFile = fileConstructor.newInstance(mockEntry);
                                                                                                                                                                                                                                                                                           Object[] mockFiles = (Object[]) Array.newInstance(fileClass, 1);
                                                                                                                                                                                                                                                                                           mockFiles[0] = mockFile;
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Create mock archive and set files
                                                                                                                                                                                                                                                                                           Object mockArchive = mock(archiveClass);
                                                                                                                                                                                                                                                                                           Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                                                                                                                           filesField.setAccessible(true);
                                                                                                                                                                                                                                                                                           filesField.set(mockArchive, mockFiles);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Set mock archive via reflection
                                                                                                                                                                                                                                                                                           archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Set current entry index via reflection
                                                                                                                                                                                                                                                                                           Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                           currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                           currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Prepare deferred block streams to avoid IllegalStateException
                                                                                                                                                                                                                                                                                           Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                           deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                           ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                                           streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                                                                                                                                                                                                                           deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Access private getCurrentStream method via reflection
                                                                                                                                                                                                                                                                                           Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                           getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                           InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Test - should not return empty stream for negative size
                                                                                                                                                                                                                                                                                           assertNotNull(result);
                                                                                                                                                                                                                                                                                           assertNotEquals(0, result.available()); // Should have content, not empty
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Cleanup
                                                                                                                                                                                                                                                                                           result.close();
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                  public void testGetCurrentStreamWithZeroSizeEntry1() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to access and modify private fields
                                                                                                                                                                                                                                                                                      Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                                      Object archive = mock(archiveClass);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                                                                                                                      Object[] files = (Object[]) Array.newInstance(fileClass, 1);
                                                                                                                                                                                                                                                                                      files[0] = mock(fileClass);
                                                                                                                                                                                                                                                                                      when(files[0].getClass().getMethod("getSize").invoke(files[0])).thenReturn(0L);
                                                                                                                                                                                                                                                                                      when(archive.getClass().getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Set private fields
                                                                                                                                                                                                                                                                                      Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                      archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                      archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                      currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                      currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                      deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Test - access private method via reflection
                                                                                                                                                                                                                                                                                      Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                      getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                      InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      assertNotNull("Should return a stream", result);
                                                                                                                                                                                                                                                                                      assertEquals("Should return empty ByteArrayInputStream when size is 0", 
                                                                                                                                                                                                                                                                                                  ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify the stream is empty
                                                                                                                                                                                                                                                                                      assertEquals("Stream should be empty", -1, result.read());
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                             public void testGetCurrentStreamWithNonZeroSizeShouldNotReturnEmptyStream() throws Exception {
                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Get the private Archive class using reflection
                                                                                                                                                                                                                                                                                 Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                                 Object mockArchive = mock(archiveClass);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Create mock FileEntry array
                                                                                                                                                                                                                                                                                 Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                                                                                                                 Object[] mockFiles = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                                                                                                                                                                                                                 Object mockFileEntry = mock(fileEntryClass);
                                                                                                                                                                                                                                                                                 mockFiles[0] = mockFileEntry;
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Mock archive.files to return our mock files array
                                                                                                                                                                                                                                                                                 when(archiveClass.getMethod("getFiles").invoke(mockArchive)).thenReturn(mockFiles);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Set mock file entry to return non-zero size
                                                                                                                                                                                                                                                                                 when(fileEntryClass.getMethod("getSize").invoke(mockFileEntry)).thenReturn(100L); // Non-zero size
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Set currentEntryIndex to 0 using reflection
                                                                                                                                                                                                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Inject mock archive
                                                                                                                                                                                                                                                                                 Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                                 archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                                 archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Create a real input stream (not empty) to return
                                                                                                                                                                                                                                                                                 InputStream testStream = new ByteArrayInputStream(new byte[]{1, 2, 3});
                                                                                                                                                                                                                                                                                 Field streamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                                 streamsField.setAccessible(true);
                                                                                                                                                                                                                                                                                 ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                                 streams.add(testStream);
                                                                                                                                                                                                                                                                                 streamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Get the private getCurrentStream method using reflection
                                                                                                                                                                                                                                                                                 Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                                 getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                 InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                 assertNotEquals("Should not return empty stream for non-zero size file",
                                                                                                                                                                                                                                                                                         0, result.available());
                                                                                                                                                                                                                                                                                 assertFalse("Result should not be empty ByteArrayInputStream",
                                                                                                                                                                                                                                                                                         result instanceof ByteArrayInputStream && result.available() == 0);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Cleanup
                                                                                                                                                                                                                                                                                 result.close();
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                        public void testGetCurrentStream_ShouldReturnEmptyStreamWhenFileSizeIsZero() throws Exception {
                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Use reflection to get and modify private fields
                                                                                                                                                                                                                                                                            Class<?> sevenZFileClass = SevenZFile.class;
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Get and set archive field (using reflection to access package-private class)
                                                                                                                                                                                                                                                                            Field archiveField = sevenZFileClass.getDeclaredField("archive");
                                                                                                                                                                                                                                                                            archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                            Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Get files array from archive
                                                                                                                                                                                                                                                                            Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                            filesField.setAccessible(true);
                                                                                                                                                                                                                                                                            Object[] files = (Object[]) filesField.get(archive);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Mock file size
                                                                                                                                                                                                                                                                            Object file = files[0];
                                                                                                                                                                                                                                                                            Method getSizeMethod = file.getClass().getDeclaredMethod("getSize");
                                                                                                                                                                                                                                                                            getSizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                            when(getSizeMethod.invoke(file)).thenReturn(0L);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Set current entry index
                                                                                                                                                                                                                                                                            Field currentEntryIndexField = sevenZFileClass.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Set deferred block streams
                                                                                                                                                                                                                                                                            Field deferredBlockStreamsField = sevenZFileClass.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                            deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                            deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test - use reflection to call private method
                                                                                                                                                                                                                                                                            Method getCurrentStreamMethod = sevenZFileClass.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                            InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                                            assertNotNull("Should return a stream", result);
                                                                                                                                                                                                                                                                            assertEquals("Should return empty ByteArrayInputStream when file size is 0", 
                                                                                                                                                                                                                                                                                        ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                                                                                                            assertEquals("Stream should be empty", -1, result.read());
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Cleanup
                                                                                                                                                                                                                                                                            result.close();
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                   public void testGetCurrentStream_EmptyFile_ReturnsEmptyStream() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Get the Archive class through reflection since it's package-private
                                                                                                                                                                                                                                                                       Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                                                       Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Create mock archive and file entry using reflection
                                                                                                                                                                                                                                                                       Object mockArchive = mock(archiveClass);
                                                                                                                                                                                                                                                                       Object mockFileEntry = mock(fileEntryClass);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Mock behavior
                                                                                                                                                                                                                                                                       when(mockFileEntry.getClass().getMethod("getSize").invoke(mockFileEntry))
                                                                                                                                                                                                                                                                           .thenReturn(0L);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Create files array
                                                                                                                                                                                                                                                                       Object[] files = {mockFileEntry};
                                                                                                                                                                                                                                                                       when(mockArchive.getClass().getField("files").get(mockArchive))
                                                                                                                                                                                                                                                                           .thenReturn(files);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                       archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Test - use reflection to call private getCurrentStream method
                                                                                                                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       byte[] buffer = new byte[1];
                                                                                                                                                                                                                                                                       int bytesRead = result.read(buffer);
                                                                                                                                                                                                                                                                       assertEquals(0, bytesRead);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Cleanup
                                                                                                                                                                                                                                                                       result.close();
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                              public void testGetCurrentStream_ReturnsEmptyStreamForZeroSizeFile() throws Exception {
                                                                                                                                                                                                                                                                  // Setup test data
                                                                                                                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Use reflection to access private archive field
                                                                                                                                                                                                                                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                  archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                  Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Get the files array from archive using reflection
                                                                                                                                                                                                                                                                  Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                  filesField.setAccessible(true);
                                                                                                                                                                                                                                                                  Object[] files = (Object[]) filesField.get(archive);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Get first file from array
                                                                                                                                                                                                                                                                  Object file = files[0];
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Mock the size to return 0
                                                                                                                                                                                                                                                                  Method getSizeMethod = file.getClass().getMethod("getSize");
                                                                                                                                                                                                                                                                  getSizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Create a proxy to override getSize() to return 0
                                                                                                                                                                                                                                                                  Object mockFile = Proxy.newProxyInstance(
                                                                                                                                                                                                                                                                      getClass().getClassLoader(),
                                                                                                                                                                                                                                                                      new Class<?>[] { file.getClass().getInterfaces()[0] },
                                                                                                                                                                                                                                                                      (proxy, method, args) -> {
                                                                                                                                                                                                                                                                          if ("getSize".equals(method.getName())) {
                                                                                                                                                                                                                                                                              return 0L;
                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                          return method.invoke(file, args);
                                                                                                                                                                                                                                                                      });
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Replace the file in the array with our mock
                                                                                                                                                                                                                                                                  files[0] = mockFile;
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Set currentEntryIndex to 0 (first file)
                                                                                                                                                                                                                                                                  Field entryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                  entryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                  entryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Get the stream using reflection since getCurrentStream is private
                                                                                                                                                                                                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                  InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify the result is a non-null empty stream
                                                                                                                                                                                                                                                                  assertNotNull("Should return non-null stream for zero-size file", result);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify it's an empty stream by reading from it
                                                                                                                                                                                                                                                                  assertEquals("Empty stream should return -1 on read", -1, result.read());
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Clean up
                                                                                                                                                                                                                                                                  result.close();
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                         public void testGetCurrentStreamWithZeroSizeFileShouldReturnEmptyStream() throws Exception {
                                                                                                                                                                                                                                                             // Setup test objects
                                                                                                                                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to access private fields since we need to set up test state
                                                                                                                                                                                                                                                             Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                             archiveField.setAccessible(true);
                                                                                                                                                                                                                                                             Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                                                                                                                                             archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                             currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                             deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Mock archive files
                                                                                                                                                                                                                                                             SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                             when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                                             SevenZArchiveEntry[] entries = new SevenZArchiveEntry[]{entry};
                                                                                                                                                                                                                                                             when(archive.getClass().getDeclaredField("files").get(archive)).thenReturn(entries);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Access private getCurrentStream method via reflection
                                                                                                                                                                                                                                                             Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                             getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                             InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify original behavior - should return empty ByteArrayInputStream
                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                             assertEquals(0, result.available());
                                                                                                                                                                                                                                                             assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Cleanup
                                                                                                                                                                                                                                                             result.close();
                                                                                                                                                                                                                                                         }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                                                    public void testGetCurrentStreamWithEmptyDeferredStreamsShouldThrow() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access private archive field and set mock data
                                                                                                                                                                                                                                                        Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                        archiveField.setAccessible(true);
                                                                                                                                                                                                                                                        Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Mock entry using reflection
                                                                                                                                                                                                                                                        Class<?> archiveEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$ArchiveEntry");
                                                                                                                                                                                                                                                        Object entry = archiveEntryClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                                                                        Method setSizeMethod = archiveEntryClass.getDeclaredMethod("setSize", long.class);
                                                                                                                                                                                                                                                        setSizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                        setSizeMethod.invoke(entry, 1L); // Non-zero size
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Set entries array
                                                                                                                                                                                                                                                        Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                        filesField.setAccessible(true);
                                                                                                                                                                                                                                                        Object[] entries = (Object[]) Array.newInstance(archiveEntryClass, 1);
                                                                                                                                                                                                                                                        entries[0] = entry;
                                                                                                                                                                                                                                                        filesField.set(archive, entries);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Set empty deferredBlockStreams
                                                                                                                                                                                                                                                        Field streamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                        streamsField.setAccessible(true);
                                                                                                                                                                                                                                                        streamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Set current entry index
                                                                                                                                                                                                                                                        Field indexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                        indexField.setAccessible(true);
                                                                                                                                                                                                                                                        indexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Access private getCurrentStream method via reflection
                                                                                                                                                                                                                                                        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                        getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                        getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                    }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                                           public void testGetCurrentStream_EmptyDeferredBlockStreams_ThrowsIllegalStateException() throws Exception {
                                                                                                                                                                                                                                               // Arrange
                                                                                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to set the private archive field to an empty state
                                                                                                                                                                                                                                               Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                               archiveField.setAccessible(true);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Get the existing archive object
                                                                                                                                                                                                                                               Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to set the files field to empty array
                                                                                                                                                                                                                                               Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                               filesField.setAccessible(true);
                                                                                                                                                                                                                                               filesField.set(archive, new Object[0]); // Empty files array
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to access private getCurrentStream method
                                                                                                                                                                                                                                               Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                               getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Act - should throw IllegalStateException
                                                                                                                                                                                                                                               getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                           }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                                           public void testGetCurrentStream_NullDeferredBlockStreams_ThrowsNullPointerException() throws Exception {
                                                                                                                                                                                                                                               // Arrange
                                                                                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to set private field
                                                                                                                                                                                                                                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                               deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                               deferredBlockStreamsField.set(sevenZFile, null);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                                                                                               Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                               getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Act - should throw NullPointerException
                                                                                                                                                                                                                                               getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                      public void testGetCurrentStreamWithNonEmptyDeferredStreamsShouldNotThrow() throws Exception {
                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to create and set up the archive structure
                                                                                                                                                                                                                                          Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                          Object archive = mock(archiveClass);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          Class<?> archiveFileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveFile");
                                                                                                                                                                                                                                          Object file = mock(archiveFileClass);
                                                                                                                                                                                                                                          when(file.getClass().getMethod("getSize").invoke(file)).thenReturn(1L); // Non-zero size
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          Object[] files = (Object[]) Array.newInstance(archiveFileClass, 1);
                                                                                                                                                                                                                                          files[0] = file;
                                                                                                                                                                                                                                          when(archive.getClass().getField("files").get(archive)).thenReturn(files);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Set private fields using reflection
                                                                                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                                                                          archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Create non-empty deferredBlockStreams
                                                                                                                                                                                                                                          ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                          streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Access private getCurrentStream method via reflection
                                                                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // This should throw IllegalStateException with the mutant, but pass with original code
                                                                                                                                                                                                                                          getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // If we get here, the test fails (original behavior passed)
                                                                                                                                                                                                                                          // With mutant, it will throw the expected exception
                                                                                                                                                                                                                                      }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                                 public void testGetCurrentStreamThrowsWhenEmpty() throws Exception {
                                                                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Use reflection to access private fields since we need to set up test conditions
                                                                                                                                                                                                                                     Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                     archiveField.setAccessible(true);
                                                                                                                                                                                                                                     Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                                                                                                                     archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                     currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                     currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Create mock entry with non-zero size
                                                                                                                                                                                                                                     Object mockEntry = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveEntry"));
                                                                                                                                                                                                                                     when(mockEntry.getClass().getMethod("getSize").invoke(mockEntry)).thenReturn(1L);
                                                                                                                                                                                                                                     Object[] entries = new Object[]{mockEntry};
                                                                                                                                                                                                                                     when(archive.getClass().getField("files").get(archive)).thenReturn(entries);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Ensure deferredBlockStreams is empty
                                                                                                                                                                                                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                     deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                     ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                                                                                                                                                                     deferredBlockStreamsField.set(sevenZFile, emptyList);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Access private method via reflection
                                                                                                                                                                                                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                     getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                     getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                            public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry() throws Exception {
                                                                                                                                                                                                                                // Setup test objects
                                                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Use reflection to access private fields since we need to set up test conditions
                                                                                                                                                                                                                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                archiveField.setAccessible(true);
                                                                                                                                                                                                                                Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                                                                                                                archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                Field filesField = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive").getDeclaredField("files");
                                                                                                                                                                                                                                filesField.setAccessible(true);
                                                                                                                                                                                                                                SevenZArchiveEntry[] entries = new SevenZArchiveEntry[1];
                                                                                                                                                                                                                                entries[0] = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                when(entries[0].getSize()).thenReturn(1L); // Non-zero size to avoid first if condition
                                                                                                                                                                                                                                filesField.set(archive, entries);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                ArrayList<InputStream> emptyStreams = new ArrayList<>();
                                                                                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, emptyStreams);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Access private getCurrentStream method
                                                                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // This should throw IllegalStateException (original behavior)
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                    fail("Expected IllegalStateException");
                                                                                                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                    assertTrue(e.getCause() instanceof IllegalStateException);
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                   public void testGetCurrentStreamThrowsExceptionWithCorrectMessageWhenNoEntry() throws Exception {
                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Use reflection to set private fields since we need to test error case
                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Create mock files array using reflection since Archive class is not accessible
                                                                                                                                                                                                                       Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                       Object mockArchive = mock(archiveClass);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                                                       Object[] mockFiles = (Object[]) Array.newInstance(fileClass, 1);
                                                                                                                                                                                                                       Object mockFile = mock(fileClass);
                                                                                                                                                                                                                       when(mockFile.getClass().getMethod("getSize").invoke(mockFile)).thenReturn(1L); // Non-zero size
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       mockFiles[0] = mockFile;
                                                                                                                                                                                                                       when(mockArchive.getClass().getField("files").get(mockArchive)).thenReturn(mockFiles);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                       deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>()); // Empty list
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                           // This should throw IllegalStateException
                                                                                                                                                                                                                           Method method = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                           method.setAccessible(true);
                                                                                                                                                                                                                           method.invoke(sevenZFile);
                                                                                                                                                                                                                       } catch (InvocationTargetException e) {
                                                                                                                                                                                                                           // Verify the exception message
                                                                                                                                                                                                                           assertEquals("No current 7z entry (call getNextEntry() first).", 
                                                                                                                                                                                                                                        e.getCause().getMessage());
                                                                                                                                                                                                                           throw (IllegalStateException) e.getCause();
                                                                                                                                                                                                                       }
                                                                                                                                                                                                                   }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                              public void testGetCurrentStream_ThrowsExceptionWhenNoEntry() throws Exception {
                                                                                                                                                                                                                  // Create a real SevenZFile instance with a dummy file
                                                                                                                                                                                                                  File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                  tempFile.deleteOnExit();
                                                                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      // Use reflection to access private getCurrentStream method
                                                                                                                                                                                                                      Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                      getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to set private fields to simulate test conditions
                                                                                                                                                                                                                      Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                      archiveField.setAccessible(true);
                                                                                                                                                                                                                      Object archive = new Object(); // Since we can't access Archive class
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                      filesField.setAccessible(true);
                                                                                                                                                                                                                      Object[] files = new Object[1]; // Mock file entries array
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                      currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                      currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                      deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Invoke the method which should throw IllegalStateException
                                                                                                                                                                                                                      getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                  } finally {
                                                                                                                                                                                                                      sevenZFile.close();
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                         public void testGetCurrentStream_EmptyDeferredBlockStreams_ShouldThrowException() throws Exception {
                                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to access private fields
                                                                                                                                                                                                             Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                             archiveField.setAccessible(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create a mock archive object through reflection since Archive class is not public
                                                                                                                                                                                                             Object mockArchive = mock(archiveField.getType());
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create a mock entry object through reflection since ArchiveEntry is not accessible
                                                                                                                                                                                                             Class<?> archiveEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveEntry");
                                                                                                                                                                                                             Object mockEntry = mock(archiveEntryClass);
                                                                                                                                                                                                             when(mockEntry.getClass().getMethod("getSize").invoke(mockEntry)).thenReturn(1L); // Non-zero size
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create entries array
                                                                                                                                                                                                             Object[] entries = {mockEntry};
                                                                                                                                                                                                             when(mockArchive.getClass().getMethod("getFiles").invoke(mockArchive)).thenReturn(entries);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Set the mock archive
                                                                                                                                                                                                             archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Set current entry index
                                                                                                                                                                                                             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                             currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                             currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Set empty deferred block streams
                                                                                                                                                                                                             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                             deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>()); // Empty list
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Access private method through reflection
                                                                                                                                                                                                             Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                             getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // This should throw IllegalStateException
                                                                                                                                                                                                             getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                         }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                    public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry1() throws Exception {
                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Use reflection to set private fields since we need to test internal state
                                                                                                                                                                                                        // Set archive field (we don't need to mock it since we're testing the no entry case)
                                                                                                                                                                                                        Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                        archiveField.setAccessible(true);
                                                                                                                                                                                                        archiveField.set(sevenZFile, null);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Set currentEntryIndex to -1 to simulate no current entry
                                                                                                                                                                                                        Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                        currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                        currentEntryIndexField.set(sevenZFile, -1);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Set deferredBlockStreams to empty list
                                                                                                                                                                                                        Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                        deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                        deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Get the private getCurrentStream method
                                                                                                                                                                                                        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                        getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Exercise and verify
                                                                                                                                                                                                        try {
                                                                                                                                                                                                            getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                            fail("Expected IllegalStateException to be thrown");
                                                                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                                                                            Throwable cause = e.getCause();
                                                                                                                                                                                                            assertTrue(cause instanceof IllegalStateException);
                                                                                                                                                                                                            assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                                                                                                                                                                                                            throw (IllegalStateException) cause; // rethrow for the @Test expected verification
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                               public void testGetCurrentStreamWithZeroSizeFile1() throws Exception {
                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Get the Archive class through reflection
                                                                                                                                                                                                   Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                   Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Mock archive and file entry
                                                                                                                                                                                                   Object archive = mock(archiveClass);
                                                                                                                                                                                                   Object fileEntry = mock(fileEntryClass);
                                                                                                                                                                                                   when(fileEntryClass.getMethod("getSize").invoke(fileEntry)).thenReturn(0L);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set up test object state using reflection
                                                                                                                                                                                                   Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                   archiveField.setAccessible(true);
                                                                                                                                                                                                   archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                   
                                                                                                                                                                                                   Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                   currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                   currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                   
                                                                                                                                                                                                   Object[] files = (Object[])Array.newInstance(fileEntryClass, 1);
                                                                                                                                                                                                   files[0] = fileEntry;
                                                                                                                                                                                                   when(archiveClass.getField("files").get(archive)).thenReturn(files);
                                                                                                                                                                                                   
                                                                                                                                                                                                   Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                   deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                   deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Test getCurrentStream via reflection
                                                                                                                                                                                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                   getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                   InputStream result = (InputStream)getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                   assertNotNull("Should return a stream", result);
                                                                                                                                                                                                   assertEquals("Should return empty ByteArrayInputStream", 
                                                                                                                                                                                                               ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                                   assertEquals("Stream should be empty", -1, result.read());
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Clean up
                                                                                                                                                                                                   result.close();
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                          public void testGetCurrentStreamWithZeroSizeFile2() throws Exception {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                              tempFile.deleteOnExit();
                                                                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to access private classes and methods
                                                                                                                                                                                              Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                              Object archive = mock(archiveClass);
                                                                                                                                                                                              
                                                                                                                                                                                              Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                              Object fileEntry = mock(fileEntryClass);
                                                                                                                                                                                              when(fileEntryClass.getMethod("getSize").invoke(fileEntry)).thenReturn(0L);
                                                                                                                                                                                              
                                                                                                                                                                                              Object[] files = new Object[]{fileEntry};
                                                                                                                                                                                              when(archiveClass.getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set private fields using reflection
                                                                                                                                                                                              Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                              archiveField.setAccessible(true);
                                                                                                                                                                                              archiveField.set(sevenZFile, archive);
                                                                                                                                                                                              
                                                                                                                                                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                              currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                              currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                              deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                              deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                              
                                                                                                                                                                                              // Access private method via reflection
                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertNotNull("Should return a stream", result);
                                                                                                                                                                                              assertEquals("Should return empty ByteArrayInputStream", 
                                                                                                                                                                                                          ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                              assertEquals("Stream should be empty", -1, result.read());
                                                                                                                                                                                              
                                                                                                                                                                                              // Clean up
                                                                                                                                                                                              result.close();
                                                                                                                                                                                              sevenZFile.close();
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testGetCurrentStreamWithNonZeroSizeFile1() throws Exception {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to access private archive field and create mock entries
                                                                                                                                                                                              Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                              archiveField.setAccessible(true);
                                                                                                                                                                                              Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                              
                                                                                                                                                                                              // Get the FileEntry class through reflection
                                                                                                                                                                                              Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                                                                                                                              Object fileEntry = fileEntryClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                              
                                                                                                                                                                                              // Set size using reflection
                                                                                                                                                                                              Method setSizeMethod = fileEntryClass.getDeclaredMethod("setSize", long.class);
                                                                                                                                                                                              setSizeMethod.setAccessible(true);
                                                                                                                                                                                              setSizeMethod.invoke(fileEntry, 100L); // Non-zero size
                                                                                                                                                                                              
                                                                                                                                                                                              // Set files array in archive
                                                                                                                                                                                              Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                              filesField.setAccessible(true);
                                                                                                                                                                                              Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                                                                                                                              files[0] = fileEntry;
                                                                                                                                                                                              filesField.set(archive, files);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set current entry index
                                                                                                                                                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                              currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                              currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Prepare a real deferred block stream (not empty)
                                                                                                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                              streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                                                                                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                              deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                              deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test - get current stream via reflection
                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertNotNull("Should return a stream", result);
                                                                                                                                                                                              assertNotEquals("Should NOT return empty ByteArrayInputStream", 
                                                                                                                                                                                                             ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                              assertTrue("Stream should have content", result.read() != -1);
                                                                                                                                                                                              
                                                                                                                                                                                              // Clean up
                                                                                                                                                                                              result.close();
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                     public void testGetCurrentStreamWithNegativeSizeShouldNotReturnEmptyStream1() throws Exception {
                                                                                                                                                                                         // Setup
                                                                                                                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private fields
                                                                                                                                                                                         Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                         Object archive = mock(archiveClass);
                                                                                                                                                                                         
                                                                                                                                                                                         Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                         Object mockFile = mock(fileClass);
                                                                                                                                                                                         when(fileClass.getMethod("getSize").invoke(mockFile)).thenReturn(-1L); // Negative size
                                                                                                                                                                                         
                                                                                                                                                                                         // Set archive field
                                                                                                                                                                                         Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                         archiveField.setAccessible(true);
                                                                                                                                                                                         archiveField.set(sevenZFile, archive);
                                                                                                                                                                                         
                                                                                                                                                                                         // Set currentEntryIndex
                                                                                                                                                                                         Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                         currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                         currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                         
                                                                                                                                                                                         // Set files array
                                                                                                                                                                                         Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                         filesField.setAccessible(true);
                                                                                                                                                                                         filesField.set(archive, Array.newInstance(fileClass, 1));
                                                                                                                                                                                         Array.set(filesField.get(archive), 0, mockFile);
                                                                                                                                                                                         
                                                                                                                                                                                         // Set deferredBlockStreams
                                                                                                                                                                                         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                         deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                         ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                         InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                         streams.add(mockStream);
                                                                                                                                                                                         deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                         
                                                                                                                                                                                         // Access private getCurrentStream method
                                                                                                                                                                                         Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                         getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                         InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify
                                                                                                                                                                                         assertNotEquals("Should not return empty stream for negative size", 
                                                                                                                                                                                                        ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                         assertSame("Should return the deferred block stream", mockStream, result);
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                public void testGetCurrentStreamWithZeroSizeFile3() throws Exception {
                                                                                                                                                                                    // Setup
                                                                                                                                                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock SevenZArchiveEntry
                                                                                                                                                                                    SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                    when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                    // Set archive.files
                                                                                                                                                                                    Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                    Object archive = mock(archiveClass);
                                                                                                                                                                                    Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                    filesField.setAccessible(true);
                                                                                                                                                                                    filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                                                                                                                                                                    
                                                                                                                                                                                    Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                    archiveField.setAccessible(true);
                                                                                                                                                                                    archiveField.set(sevenZFile, archive);
                                                                                                                                                                                    
                                                                                                                                                                                    Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                    currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                    currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                    
                                                                                                                                                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                    deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                    deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                    
                                                                                                                                                                                    // Test - use reflection to call private getCurrentStream()
                                                                                                                                                                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                    getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                    InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify
                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                    assertEquals(0, result.available()); // Should be empty stream
                                                                                                                                                                                    
                                                                                                                                                                                    // Cleanup
                                                                                                                                                                                    result.close();
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGetCurrentStreamWithSizeOneFile() throws Exception {
                                                                                                                                                                                    // Setup - create a temporary test file
                                                                                                                                                                                    File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                    tempFile.deleteOnExit();
                                                                                                                                                                                    SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get the Archive class via reflection since it's not public
                                                                                                                                                                                    Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                    Object archive = mock(archiveClass);
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock entry and files
                                                                                                                                                                                    SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                    when(entry.getSize()).thenReturn(1L);
                                                                                                                                                                                    SevenZArchiveEntry[] files = {entry};
                                                                                                                                                                                    
                                                                                                                                                                                    // Set the files field via reflection
                                                                                                                                                                                    Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                    filesField.setAccessible(true);
                                                                                                                                                                                    filesField.set(archive, files);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set private fields in SevenZFile
                                                                                                                                                                                    Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                    archiveField.setAccessible(true);
                                                                                                                                                                                    archiveField.set(sevenZFile, archive);
                                                                                                                                                                                    
                                                                                                                                                                                    Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                    currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                    currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Add a dummy stream to deferredBlockStreams
                                                                                                                                                                                    ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                    streams.add(new ByteArrayInputStream(new byte[1]));
                                                                                                                                                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                    deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                    deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test - get private method via reflection
                                                                                                                                                                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                    getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                    InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify
                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                    assertEquals(1, result.available()); // Should not be empty stream
                                                                                                                                                                                    
                                                                                                                                                                                    // Cleanup
                                                                                                                                                                                    result.close();
                                                                                                                                                                                    sevenZFile.close();
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testGetCurrentStreamWithNonZeroSizeFile2() throws Exception {
                                                                                                                                                                               // Setup test data
                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private fields and methods
                                                                                                                                                                               // Get the archive field and set it to null since we can't mock the internal Archive class
                                                                                                                                                                               Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                               archiveField.setAccessible(true);
                                                                                                                                                                               archiveField.set(sevenZFile, null);
                                                                                                                                                                               
                                                                                                                                                                               // Set current entry index
                                                                                                                                                                               Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                               currentEntryIndexField.setAccessible(true);
                                                                                                                                                                               currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                               
                                                                                                                                                                               // Create a real input stream to return (not empty)
                                                                                                                                                                               InputStream expectedStream = new ByteArrayInputStream(new byte[]{1, 2, 3});
                                                                                                                                                                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                               deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                               ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                               streams.add(expectedStream);
                                                                                                                                                                               deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                               
                                                                                                                                                                               // Get the private getCurrentStream method
                                                                                                                                                                               Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                               getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               // Test the method
                                                                                                                                                                               InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                               
                                                                                                                                                                               // Verify - original should return our expectedStream, mutant will return empty stream
                                                                                                                                                                               assertNotEquals("Should not return empty stream for non-zero size file", 
                                                                                                                                                                                   0, result.available());
                                                                                                                                                                               assertSame("Should return the expected input stream", 
                                                                                                                                                                                   expectedStream, result);
                                                                                                                                                                               
                                                                                                                                                                               // Clean up
                                                                                                                                                                               result.close();
                                                                                                                                                                           }

    @Test
                                                                                                                                                                      public void testGetCurrentStreamWithZeroSizeFile4() throws Exception {
                                                                                                                                                                          // Setup
                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to set private fields and call private methods
                                                                                                                                                                          // Get the archive field and set it to null since we can't mock it
                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                          archiveField.set(sevenZFile, null);
                                                                                                                                                                          
                                                                                                                                                                          // Set currentEntryIndex to 0
                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                          
                                                                                                                                                                          // Set deferredBlockStreams to empty list
                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                          
                                                                                                                                                                          // Create a mock entry with size 0
                                                                                                                                                                          SevenZArchiveEntry mockEntry = new SevenZArchiveEntry();
                                                                                                                                                                          mockEntry.setSize(0);
                                                                                                                                                                          
                                                                                                                                                                          // Set the current entry using reflection
                                                                                                                                                                          Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntry");
                                                                                                                                                                          currentEntryField.setAccessible(true);
                                                                                                                                                                          currentEntryField.set(sevenZFile, mockEntry);
                                                                                                                                                                          
                                                                                                                                                                          // Get the private getCurrentStream method
                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Test
                                                                                                                                                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertNotNull("Should return a stream", result);
                                                                                                                                                                          assertEquals("Should return empty ByteArrayInputStream for zero-size file", 
                                                                                                                                                                              0, result.available());
                                                                                                                                                                          assertTrue("Should be ByteArrayInputStream", 
                                                                                                                                                                              result instanceof ByteArrayInputStream);
                                                                                                                                                                          
                                                                                                                                                                          // Cleanup
                                                                                                                                                                          result.close();
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testGetCurrentStream_EmptyFile_ReturnsEmptyStream1() throws Exception {
                                                                                                                                                                     // Setup
                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                     
                                                                                                                                                                     // Mock file entry with size 0
                                                                                                                                                                     SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                     when(mockEntry.getSize()).thenReturn(0L);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set private fields since we need to test specific conditions
                                                                                                                                                                     // Get the archive field and set it to a new object (can't mock directly)
                                                                                                                                                                     Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                     archiveField.setAccessible(true);
                                                                                                                                                                     Object archive = archiveField.get(sevenZFile); // Get the existing archive object
                                                                                                                                                                     
                                                                                                                                                                     // Set the files field in the archive
                                                                                                                                                                     Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                     filesField.setAccessible(true);
                                                                                                                                                                     filesField.set(archive, new SevenZArchiveEntry[]{mockEntry});
                                                                                                                                                                     
                                                                                                                                                                     // Set current entry index
                                                                                                                                                                     Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                     currentEntryIndexField.setAccessible(true);
                                                                                                                                                                     currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                     
                                                                                                                                                                     // Get the private getCurrentStream method
                                                                                                                                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                     getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertNotNull("Stream should not be null", result);
                                                                                                                                                                     assertEquals("Stream should be empty (0 bytes available)", 0, result.available());
                                                                                                                                                                     
                                                                                                                                                                     // Cleanup
                                                                                                                                                                     result.close();
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testGetCurrentStreamWithZeroSizeFileReturnsEmptyStream() throws Exception {
                                                                                                                                                                // Setup test objects
                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private fields and methods
                                                                                                                                                                Class<?> sevenZFileClass = SevenZFile.class;
                                                                                                                                                                
                                                                                                                                                                // Get the archive field and set a mock entry with size 0
                                                                                                                                                                Field archiveField = sevenZFileClass.getDeclaredField("archive");
                                                                                                                                                                archiveField.setAccessible(true);
                                                                                                                                                                Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                
                                                                                                                                                                // Get the files field from archive and set an entry with size 0
                                                                                                                                                                Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                filesField.setAccessible(true);
                                                                                                                                                                Object[] entries = (Object[]) filesField.get(archive);
                                                                                                                                                                Object entry = entries[0];
                                                                                                                                                                
                                                                                                                                                                // Set size to 0 for the entry
                                                                                                                                                                Method getSizeMethod = entry.getClass().getDeclaredMethod("getSize");
                                                                                                                                                                getSizeMethod.setAccessible(true);
                                                                                                                                                                Field sizeField = entry.getClass().getDeclaredField("size");
                                                                                                                                                                sizeField.setAccessible(true);
                                                                                                                                                                sizeField.set(entry, 0L);
                                                                                                                                                                
                                                                                                                                                                // Set current entry index to 0
                                                                                                                                                                Field currentEntryIndexField = sevenZFileClass.getDeclaredField("currentEntryIndex");
                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                
                                                                                                                                                                // Set empty deferred block streams
                                                                                                                                                                Field deferredBlockStreamsField = sevenZFileClass.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                
                                                                                                                                                                // Get the private getCurrentStream method
                                                                                                                                                                Method getCurrentStreamMethod = sevenZFileClass.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Test the method
                                                                                                                                                                InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                
                                                                                                                                                                // Verify the result
                                                                                                                                                                assertNotNull("Should return empty stream instead of null for zero-size file", result);
                                                                                                                                                                assertEquals("Should return ByteArrayInputStream for zero-size file", 
                                                                                                                                                                    ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                assertEquals("Stream should be empty", 0, result.available());
                                                                                                                                                                
                                                                                                                                                                // Clean up
                                                                                                                                                                result.close();
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testGetCurrentStreamWithZeroSizeEntry_ShouldReturnEmptyStream() throws Exception {
                                                                                                                                                           // Setup
                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                           
                                                                                                                                                           // Use reflection to access private fields and methods
                                                                                                                                                           Class<?> sevenZFileClass = sevenZFile.getClass();
                                                                                                                                                           
                                                                                                                                                           // Mock SevenZArchiveEntry (since we can't access internal Archive class)
                                                                                                                                                           SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                           entry.setSize(0);
                                                                                                                                                           
                                                                                                                                                           // Set current entry index via reflection
                                                                                                                                                           Field currentEntryIndexField = sevenZFileClass.getDeclaredField("currentEntryIndex");
                                                                                                                                                           currentEntryIndexField.setAccessible(true);
                                                                                                                                                           currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                           
                                                                                                                                                           // Set entries list via reflection
                                                                                                                                                           Field entriesField = sevenZFileClass.getDeclaredField("entries");
                                                                                                                                                           entriesField.setAccessible(true);
                                                                                                                                                           @SuppressWarnings("unchecked")
                                                                                                                                                           List<SevenZArchiveEntry> entries = (List<SevenZArchiveEntry>) entriesField.get(sevenZFile);
                                                                                                                                                           entries.add(entry);
                                                                                                                                                           
                                                                                                                                                           // Access private getCurrentStream method
                                                                                                                                                           Method getCurrentStreamMethod = sevenZFileClass.getDeclaredMethod("getCurrentStream");
                                                                                                                                                           getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Test and verify
                                                                                                                                                           InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                           assertNotNull("Should return a stream", result);
                                                                                                                                                           assertEquals("Should return empty stream", 0, result.available());
                                                                                                                                                       }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                  public void testGetCurrentStream_EmptyDeferredStreams_ShouldThrowException() throws Exception {
                                                                                                                                                      // Setup
                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private fields since we need to set up test conditions
                                                                                                                                                      Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                      archiveField.setAccessible(true);
                                                                                                                                                      Object archive = mock(archiveField.getType());
                                                                                                                                                      archiveField.set(sevenZFile, archive);
                                                                                                                                                      
                                                                                                                                                      Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                      currentEntryIndexField.setAccessible(true);
                                                                                                                                                      currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                      
                                                                                                                                                      // Create mock archive file with non-zero size to avoid first return case
                                                                                                                                                      Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                      Object mockFile = mock(fileClass);
                                                                                                                                                      when(fileClass.getMethod("getSize").invoke(mockFile)).thenReturn(1L);
                                                                                                                                                      Object[] files = new Object[]{mockFile};
                                                                                                                                                      when(archive.getClass().getField("files").get(archive)).thenReturn(files);
                                                                                                                                                      
                                                                                                                                                      // Ensure deferredBlockStreams is empty
                                                                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                      @SuppressWarnings("unchecked")
                                                                                                                                                      ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                                                                                      deferredBlockStreamsField.set(sevenZFile, emptyList);
                                                                                                                                                      
                                                                                                                                                      // Access private method via reflection
                                                                                                                                                      Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                      getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                      getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                  }

    @Test(expected = IllegalStateException.class)
                                                                                                                                         public void testGetCurrentStreamWithEmptyDeferredBlockStreams() throws Exception {
                                                                                                                                             // Arrange
                                                                                                                                             SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                             when(mockEntry.getSize()).thenReturn(1L); // Non-zero size
                                                                                                                                             
                                                                                                                                             File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                             tempFile.deleteOnExit();
                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                             
                                                                                                                                             // Use reflection to set private field
                                                                                                                                             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                                                                                             deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                             
                                                                                                                                             // Set current entry
                                                                                                                                             Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntry");
                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                             currentEntryField.set(sevenZFile, mockEntry);
                                                                                                                                             
                                                                                                                                             // Use reflection to access private method
                                                                                                                                             Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                             getCurrentStreamMethod.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Act
                                                                                                                                             getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                         }

    @Test
                                                                                                                                    public void testGetCurrentStreamWithNonEmptyStreamsShouldReturnStream() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                        
                                                                                                                                        // Mock current entry using SevenZArchiveEntry (public class)
                                                                                                                                        SevenZArchiveEntry archiveEntry = new SevenZArchiveEntry();
                                                                                                                                        archiveEntry.setSize(1L); // Non-zero size
                                                                                                                                        
                                                                                                                                        // Use reflection to set private fields
                                                                                                                                        // Set currentEntryIndex
                                                                                                                                        Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                        currentEntryIndexField.setAccessible(true);
                                                                                                                                        currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                        
                                                                                                                                        // Set entries (using SevenZArchiveEntry array)
                                                                                                                                        Field entriesField = SevenZFile.class.getDeclaredField("entries");
                                                                                                                                        entriesField.setAccessible(true);
                                                                                                                                        SevenZArchiveEntry[] entries = {archiveEntry};
                                                                                                                                        entriesField.set(sevenZFile, entries);
                                                                                                                                        
                                                                                                                                        // Set up non-empty deferredBlockStreams
                                                                                                                                        InputStream mockStream = mock(InputStream.class);
                                                                                                                                        ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                        streams.add(mockStream);
                                                                                                                                        
                                                                                                                                        Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                        deferredBlockStreamsField.setAccessible(true);
                                                                                                                                        deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                        
                                                                                                                                        // Use reflection to call private getCurrentStream method
                                                                                                                                        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                        getCurrentStreamMethod.setAccessible(true);
                                                                                                                                        InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                        
                                                                                                                                        assertSame(mockStream, result);
                                                                                                                                        
                                                                                                                                        // Verify no streams were processed (since size is 1)
                                                                                                                                        verify(mockStream, never()).close();
                                                                                                                                        verify(mockStream, never()).skip(anyLong());
                                                                                                                                    }

    @Test
                                                                                                                               public void testGetCurrentStreamThrowsWhenDeferredBlockStreamsIsEmpty() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z")); // Need a real file for constructor
                                                                                                                                   Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                   archiveField.setAccessible(true);
                                                                                                                                   
                                                                                                                                   Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                   deferredBlockStreamsField.setAccessible(true);
                                                                                                                                   deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                   
                                                                                                                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                   getCurrentStreamMethod.setAccessible(true);
                                                                                                                                   
                                                                                                                                   // Expect exception
                                                                                                                                   try {
                                                                                                                                       getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                       fail("Expected IllegalStateException");
                                                                                                                                   } catch (InvocationTargetException e) {
                                                                                                                                       assertEquals(IllegalStateException.class, e.getCause().getClass());
                                                                                                                                       assertEquals("No current 7z entry (call getNextEntry() first).", e.getCause().getMessage());
                                                                                                                                   }
                                                                                                                               }

    @Test(expected = IllegalStateException.class)
                                                                                                                          public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry2() throws Exception {
                                                                                                                              // Setup test objects
                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                              
                                                                                                                              // Use reflection to access private fields since we need to set up the test state
                                                                                                                              Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                              archiveField.setAccessible(true);
                                                                                                                              
                                                                                                                              // Create mock Archive with a non-zero size file
                                                                                                                              Object mockArchive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                              Object mockFile = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveFile"));
                                                                                                                              when(mockFile.getClass().getMethod("getSize").invoke(mockFile)).thenReturn(1L); // Non-zero size
                                                                                                                              Object[] files = {mockFile};
                                                                                                                              when(mockArchive.getClass().getField("files").get(mockArchive)).thenReturn(files);
                                                                                                                              archiveField.set(sevenZFile, mockArchive);
                                                                                                                              
                                                                                                                              // Set currentEntryIndex to 0 (first file)
                                                                                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                              currentEntryIndexField.setAccessible(true);
                                                                                                                              currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                              
                                                                                                                              // Ensure deferredBlockStreams is empty
                                                                                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                              deferredBlockStreamsField.setAccessible(true);
                                                                                                                              @SuppressWarnings("unchecked")
                                                                                                                              ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                                                              deferredBlockStreamsField.set(sevenZFile, emptyList);
                                                                                                                              
                                                                                                                              // Access private getCurrentStream method via reflection
                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                              getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                          }

    @Test(expected = IllegalStateException.class)
                                                                                                                 public void testGetCurrentStreamThrowsCorrectExceptionWhenNoEntry() throws Exception {
                                                                                                                     // Setup test data
                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                     
                                                                                                                     // Use reflection to set private fields since we need to test error case
                                                                                                                     Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                     archiveField.setAccessible(true);
                                                                                                                     Object archive = new Object(); // Using Object since we can't access Archive directly
                                                                                                                     archiveField.set(sevenZFile, archive);
                                                                                                                     
                                                                                                                     Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                     currentEntryIndexField.setAccessible(true);
                                                                                                                     currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                     
                                                                                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                     deferredBlockStreamsField.setAccessible(true);
                                                                                                                     deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                     
                                                                                                                     // Mock files array using reflection
                                                                                                                     Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                     filesField.setAccessible(true);
                                                                                                                     Object[] filesArray = new Object[1]; // Create array of Objects
                                                                                                                     filesField.set(archive, filesArray);
                                                                                                                     
                                                                                                                     try {
                                                                                                                         // This should throw IllegalStateException
                                                                                                                         Method method = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                         method.setAccessible(true);
                                                                                                                         method.invoke(sevenZFile);
                                                                                                                     } catch (InvocationTargetException e) {
                                                                                                                         // Verify the exception type and message
                                                                                                                         Throwable cause = e.getCause();
                                                                                                                         assertEquals(IllegalStateException.class, cause.getClass());
                                                                                                                         assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                                                                                                                         throw (IllegalStateException) cause;
                                                                                                                     }
                                                                                                                 }

    @Test(expected = IllegalStateException.class)
                                                                                                            public void testGetCurrentStream_WhenNoCurrentEntry_ShouldThrowException() throws Exception {
                                                                                                                // Arrange
                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                
                                                                                                                // Use reflection to set private fields since we need to control test conditions
                                                                                                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                archiveField.setAccessible(true);
                                                                                                                Object archive = mock(archiveField.getType());
                                                                                                                archiveField.set(sevenZFile, archive);
                                                                                                                
                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                
                                                                                                                // Mock archive.files[0] to have non-zero size
                                                                                                                Object[] files = new Object[1];
                                                                                                                Object fileEntry = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry"));
                                                                                                                when(fileEntry.getClass().getMethod("getSize").invoke(fileEntry)).thenReturn(1L); // Non-zero size
                                                                                                                files[0] = fileEntry;
                                                                                                                when(archive.getClass().getField("files").get(archive)).thenReturn(files);
                                                                                                                
                                                                                                                // Set deferredBlockStreams to empty
                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                
                                                                                                                // Get private method via reflection
                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Act - should throw IllegalStateException
                                                                                                                getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                            }

    @Test(expected = IllegalStateException.class)
                                                                                                       public void testGetCurrentStream_WhenNoCurrentEntry_ShouldThrowException1() throws Exception {
                                                                                                           // Setup test data
                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                           
                                                                                                           // Use reflection to access private fields since we need to set up test conditions
                                                                                                           Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                           archiveField.setAccessible(true);
                                                                                                           Object archive = mock(archiveField.getType());
                                                                                                           archiveField.set(sevenZFile, archive);
                                                                                                           
                                                                                                           Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                           currentEntryIndexField.setAccessible(true);
                                                                                                           currentEntryIndexField.set(sevenZFile, 0);
                                                                                                           
                                                                                                           // Create mock archive file with non-zero size
                                                                                                           Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                           filesField.setAccessible(true);
                                                                                                           Object[] files = new Object[1];
                                                                                                           Object mockFile = mock(filesField.getType().getComponentType());
                                                                                                           Method getSizeMethod = mockFile.getClass().getMethod("getSize");
                                                                                                           when(getSizeMethod.invoke(mockFile)).thenReturn(1L); // Non-zero size
                                                                                                           files[0] = mockFile;
                                                                                                           filesField.set(archive, files);
                                                                                                           
                                                                                                           // Ensure deferredBlockStreams is empty
                                                                                                           Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                           deferredBlockStreamsField.setAccessible(true);
                                                                                                           @SuppressWarnings("unchecked")
                                                                                                           ArrayList<InputStream> emptyStreams = new ArrayList<>();
                                                                                                           deferredBlockStreamsField.set(sevenZFile, emptyStreams);
                                                                                                           
                                                                                                           // Access private getCurrentStream method
                                                                                                           Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                           getCurrentStreamMethod.setAccessible(true);
                                                                                                           
                                                                                                           // This should throw IllegalStateException
                                                                                                           getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                       }

    @Test(expected = IllegalStateException.class)
                                                                                                  public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry3() throws Exception {
                                                                                                      // Setup test data
                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                      
                                                                                                      // Use reflection to set private fields since we need to test internal state
                                                                                                      // Set archive field
                                                                                                      Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                      archiveField.setAccessible(true);
                                                                                                      
                                                                                                      // Create a mock archive object using reflection since Archive class is not public
                                                                                                      Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                      Object archive = archiveClass.getDeclaredConstructor().newInstance();
                                                                                                      
                                                                                                      // Create mock files array
                                                                                                      Class<?> archiveFileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveFile");
                                                                                                      Object[] files = (Object[]) Array.newInstance(archiveFileClass, 1);
                                                                                                      Object file = archiveFileClass.getDeclaredConstructor().newInstance();
                                                                                                      
                                                                                                      // Set size field
                                                                                                      Field sizeField = archiveFileClass.getDeclaredField("size");
                                                                                                      sizeField.setAccessible(true);
                                                                                                      sizeField.set(file, 1L); // Non-zero size to avoid first condition
                                                                                                      
                                                                                                      files[0] = file;
                                                                                                      
                                                                                                      // Set files field in archive
                                                                                                      Field filesField = archiveClass.getDeclaredField("files");
                                                                                                      filesField.setAccessible(true);
                                                                                                      filesField.set(archive, files);
                                                                                                      
                                                                                                      archiveField.set(sevenZFile, archive);
                                                                                                      
                                                                                                      // Set deferredBlockStreams field
                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                      deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>()); // Empty list
                                                                                                      
                                                                                                      // Get private getCurrentStream method
                                                                                                      Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                      getCurrentStreamMethod.setAccessible(true);
                                                                                                      
                                                                                                      // This should throw IllegalStateException
                                                                                                      getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                  }

    @Test
                                                                                             public void testGetCurrentStreamWithZeroSizeFile5() throws Exception {
                                                                                                 // Setup test objects
                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                 
                                                                                                 // Use reflection to access private fields
                                                                                                 Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                 archiveField.setAccessible(true);
                                                                                                 Object archive = archiveField.get(sevenZFile);
                                                                                                 
                                                                                                 // Get the File class from the archive
                                                                                                 Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                 Object fileEntry = fileEntryClass.getDeclaredConstructor().newInstance();
                                                                                                 
                                                                                                 // Set up zero size file scenario
                                                                                                 Method setSizeMethod = fileEntryClass.getMethod("setSize", long.class);
                                                                                                 setSizeMethod.invoke(fileEntry, 0L);
                                                                                                 
                                                                                                 // Create files array
                                                                                                 Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                                 files[0] = fileEntry;
                                                                                                 
                                                                                                 // Set the files array in archive
                                                                                                 Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                 filesField.setAccessible(true);
                                                                                                 filesField.set(archive, files);
                                                                                                 
                                                                                                 // Set current entry index
                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                 
                                                                                                 // Set deferred block streams
                                                                                                 Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                 deferredBlockStreamsField.setAccessible(true);
                                                                                                 deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                 
                                                                                                 // Access the private getCurrentStream method
                                                                                                 Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                 getCurrentStreamMethod.setAccessible(true);
                                                                                                 InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                 
                                                                                                 // Verify the result
                                                                                                 assertNotNull("Should return a stream", result);
                                                                                                 assertTrue("Should return ByteArrayInputStream when size is 0", 
                                                                                                            result instanceof ByteArrayInputStream);
                                                                                                 assertEquals("Stream should be empty", 0, result.available());
                                                                                                 
                                                                                                 // Clean up
                                                                                                 result.close();
                                                                                             }

    @Test
                                                                                             public void testGetCurrentStreamWithNonZeroSizeFile3() throws Exception {
                                                                                                 // Setup test objects
                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                 
                                                                                                 // Use reflection to set up the test scenario without directly using Archive class
                                                                                                 // Get the private archive field and create a mock-like structure using reflection
                                                                                                 Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                 archiveField.setAccessible(true);
                                                                                                 Object archive = archiveField.get(sevenZFile);
                                                                                                 
                                                                                                 // Create a mock file entry with size using reflection
                                                                                                 Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                 Object fileEntry = fileEntryClass.getDeclaredConstructor().newInstance();
                                                                                                 
                                                                                                 // Set size for the file entry
                                                                                                 Method setSizeMethod = fileEntryClass.getDeclaredMethod("setSize", long.class);
                                                                                                 setSizeMethod.setAccessible(true);
                                                                                                 setSizeMethod.invoke(fileEntry, 100L); // non-zero size
                                                                                                 
                                                                                                 // Set the files array in archive
                                                                                                 Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                 filesField.setAccessible(true);
                                                                                                 Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                                 files[0] = fileEntry;
                                                                                                 filesField.set(archive, files);
                                                                                                 
                                                                                                 // Set current entry index
                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                 
                                                                                                 // Create a real input stream to return (not empty)
                                                                                                 InputStream mockStream = new ByteArrayInputStream(new byte[]{1, 2, 3});
                                                                                                 ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                 streams.add(mockStream);
                                                                                                 
                                                                                                 Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                 deferredBlockStreamsField.setAccessible(true);
                                                                                                 deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                 
                                                                                                 // Test the method using reflection since it's private
                                                                                                 Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                 getCurrentStreamMethod.setAccessible(true);
                                                                                                 InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                 
                                                                                                 // Verify the result
                                                                                                 assertNotNull("Should return a stream", result);
                                                                                                 assertFalse("Should not return empty stream when size is non-zero", 
                                                                                                             result instanceof ByteArrayInputStream && result.available() == 0);
                                                                                                 assertEquals("Stream should have content", 3, result.available());
                                                                                                 
                                                                                                 // Clean up
                                                                                                 result.close();
                                                                                             }

    @Test
                                                                                        public void testGetCurrentStreamWithZeroSizeEntry2() throws Exception {
                                                                                            // Setup
                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                            
                                                                                            // Mock SevenZArchiveEntry
                                                                                            SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                            when(entry.getSize()).thenReturn(0L);
                                                                                            
                                                                                            // Use reflection to set private fields
                                                                                            // Get the archive field and set it
                                                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                            archiveField.setAccessible(true);
                                                                                            Object archive = archiveField.get(sevenZFile);
                                                                                            
                                                                                            // Get the files field from the archive and set it
                                                                                            Field filesField = archive.getClass().getDeclaredField("files");
                                                                                            filesField.setAccessible(true);
                                                                                            filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                                                                            
                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                            
                                                                                            Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                            deferredBlockStreamsField.setAccessible(true);
                                                                                            deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                            
                                                                                            // Get the private getCurrentStream method
                                                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                            
                                                                                            // Test
                                                                                            InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull("Should return a stream", result);
                                                                                            assertEquals("Should return empty ByteArrayInputStream when size is 0", 
                                                                                                ByteArrayInputStream.class, result.getClass());
                                                                                            assertEquals("Stream should be empty", -1, result.read());
                                                                                            
                                                                                            // Cleanup
                                                                                            result.close();
                                                                                        }

    @Test
                                                                                        public void testGetCurrentStreamWithNonZeroSizeEntry() throws Exception {
                                                                                            // Setup
                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                            
                                                                                            // Mock entry
                                                                                            SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                            when(entry.getSize()).thenReturn(1L); // Non-zero size
                                                                                            
                                                                                            // Use reflection to set private fields
                                                                                            // Set files array directly in archive
                                                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                            archiveField.setAccessible(true);
                                                                                            Object archive = archiveField.get(sevenZFile); // Get existing archive instance
                                                                                            
                                                                                            Field filesField = archive.getClass().getDeclaredField("files");
                                                                                            filesField.setAccessible(true);
                                                                                            SevenZArchiveEntry[] files = {entry};
                                                                                            filesField.set(archive, files);
                                                                                            
                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                            
                                                                                            // Prepare a real deferred block stream (not empty)
                                                                                            ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                                            deferredBlockStreams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                            
                                                                                            Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                            deferredBlockStreamsField.setAccessible(true);
                                                                                            deferredBlockStreamsField.set(sevenZFile, deferredBlockStreams);
                                                                                            
                                                                                            // Test - access private method via reflection
                                                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                            InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull("Should return a stream", result);
                                                                                            assertNotEquals("Should NOT return empty ByteArrayInputStream when size > 0", 
                                                                                                ByteArrayInputStream.class, result.getClass());
                                                                                            assertTrue("Stream should have content", result.read() != -1);
                                                                                            
                                                                                            // Cleanup
                                                                                            result.close();
                                                                                        }

    @Test
                                                                                   public void testGetCurrentStreamWithNegativeSizeShouldNotReturnEmptyStream2() throws Exception {
                                                                                       // Setup
                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                       
                                                                                       // Use reflection to get the Archive instance from SevenZFile
                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                       archiveField.setAccessible(true);
                                                                                       Object archive = archiveField.get(sevenZFile);
                                                                                       
                                                                                       // Mock SevenZArchiveEntry
                                                                                       SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                       when(entry.getSize()).thenReturn(-1L); // Negative size
                                                                                       
                                                                                       // Use reflection to set the files array in archive
                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                       filesField.setAccessible(true);
                                                                                       SevenZArchiveEntry[] entries = {entry};
                                                                                       filesField.set(archive, entries);
                                                                                       
                                                                                       // Set currentEntryIndex
                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                                                       
                                                                                       // Set deferredBlockStreams
                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                       ArrayList<InputStream> streams = new ArrayList<>();
                                                                                       streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                       deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                       
                                                                                       // Use reflection to call private getCurrentStream method
                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                       
                                                                                       // Verify - result should be our mocked stream (first read byte should be 1)
                                                                                       assertEquals(1, result.read());
                                                                                       
                                                                                       // Cleanup
                                                                                       result.close();
                                                                                   }

    @Test
                                                                              public void testGetCurrentStreamWithZeroSizeFile6() throws Exception {
                                                                                  // Setup
                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                  
                                                                                  // Use reflection to get the Archive class since it's not public
                                                                                  Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                  Object archive = mock(archiveClass);
                                                                                  
                                                                                  // Create mock file entry
                                                                                  Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                  Object fileEntry = mock(fileEntryClass);
                                                                                  when(fileEntry.getClass().getMethod("getSize").invoke(fileEntry)).thenReturn(0L);
                                                                                  
                                                                                  // Set up files array
                                                                                  Object[] files = {fileEntry};
                                                                                  when(archive.getClass().getField("files").get(archive)).thenReturn(files);
                                                                                  
                                                                                  // Use reflection to set private fields
                                                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                  archiveField.setAccessible(true);
                                                                                  archiveField.set(sevenZFile, archive);
                                                                                  
                                                                                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                  
                                                                                  Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                  deferredBlockStreamsField.setAccessible(true);
                                                                                  deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                  
                                                                                  // Test - use reflection to access private method
                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                  InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                  
                                                                                  // Verify
                                                                                  assertNotNull(result);
                                                                                  assertEquals(0, result.available()); // Should be empty stream
                                                                                  
                                                                                  // Clean up
                                                                                  result.close();
                                                                              }

    @Test
                                                                              public void testGetCurrentStreamWithSizeOneFile1() throws Exception {
                                                                                  // Setup
                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                  
                                                                                  // Use reflection to access private fields and methods
                                                                                  Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                  Object archive = mock(archiveClass);
                                                                                  
                                                                                  Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                  Object fileEntry = mock(fileEntryClass);
                                                                                  
                                                                                  // Mock behavior
                                                                                  when(fileEntryClass.getMethod("getSize").invoke(fileEntry)).thenReturn(1L);
                                                                                  Object[] files = new Object[]{fileEntry};
                                                                                  when(archiveClass.getField("files").get(archive)).thenReturn(files);
                                                                                  
                                                                                  // Set private fields
                                                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                  archiveField.setAccessible(true);
                                                                                  archiveField.set(sevenZFile, archive);
                                                                                  
                                                                                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                  
                                                                                  // Add a dummy stream to deferredBlockStreams
                                                                                  ArrayList<InputStream> streams = new ArrayList<>();
                                                                                  streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                  Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                  deferredBlockStreamsField.setAccessible(true);
                                                                                  deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                  
                                                                                  // Access private method
                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                  InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                  
                                                                                  // Verify
                                                                                  assertNotNull(result);
                                                                                  assertTrue(result.available() > 0); // Should NOT be empty stream
                                                                                  
                                                                                  // Clean up
                                                                                  result.close();
                                                                              }

    @Test
                                                                         public void testGetCurrentStreamWithNonZeroSizeShouldNotReturnEmptyStream1() throws Exception {
                                                                             // Setup
                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                             
                                                                             // Get the Archive class through reflection since it's package-private
                                                                             Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                             Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                             
                                                                             // Mock archive and its files using reflection
                                                                             Object archive = mock(archiveClass);
                                                                             Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                             Object fileEntry = mock(fileEntryClass);
                                                                             
                                                                             // Mock the getSize() method
                                                                             when(fileEntryClass.getMethod("getSize").invoke(fileEntry)).thenReturn(100L); // Non-zero size
                                                                             
                                                                             files[0] = fileEntry;
                                                                             when(archiveClass.getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                             
                                                                             // Set up deferred block streams
                                                                             ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                             InputStream mockStream = mock(InputStream.class);
                                                                             deferredBlockStreams.add(mockStream);
                                                                             
                                                                             // Inject mocks into SevenZFile using reflection
                                                                             Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                             archiveField.setAccessible(true);
                                                                             archiveField.set(sevenZFile, archive);
                                                                             
                                                                             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                             currentEntryIndexField.setAccessible(true);
                                                                             currentEntryIndexField.set(sevenZFile, 0);
                                                                             
                                                                             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                             deferredBlockStreamsField.set(sevenZFile, deferredBlockStreams);
                                                                             
                                                                             // Test - access private method via reflection
                                                                             Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                             getCurrentStreamMethod.setAccessible(true);
                                                                             InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                             
                                                                             // Verify
                                                                             assertNotEquals("Should not return empty ByteArrayInputStream for non-zero size file",
                                                                                            ByteArrayInputStream.class, result.getClass());
                                                                             assertSame("Should return the deferred block stream", mockStream, result);
                                                                         }

    @Test
                                                                    public void testGetCurrentStream_ShouldReturnEmptyStreamWhenEntrySizeIsZero() throws Exception {
                                                                        // Setup
                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                        
                                                                        // Mock SevenZArchiveEntry
                                                                        SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                        when(mockEntry.getSize()).thenReturn(0L);
                                                                        
                                                                        // Use reflection to set private fields
                                                                        // Set currentEntryIndex
                                                                        Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                        currentEntryIndexField.setAccessible(true);
                                                                        currentEntryIndexField.set(sevenZFile, 0);
                                                                        
                                                                        // Set deferredBlockStreams
                                                                        Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                        deferredBlockStreamsField.setAccessible(true);
                                                                        deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                        
                                                                        // Set entries (instead of using Archive class directly)
                                                                        Field entriesField = SevenZFile.class.getDeclaredField("entries");
                                                                        entriesField.setAccessible(true);
                                                                        SevenZArchiveEntry[] entries = {mockEntry};
                                                                        entriesField.set(sevenZFile, entries);
                                                                        
                                                                        // Access private getCurrentStream method via reflection
                                                                        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                        getCurrentStreamMethod.setAccessible(true);
                                                                        InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                        
                                                                        // Verify
                                                                        assertNotNull("Should return a stream", result);
                                                                        assertEquals("Should return empty ByteArrayInputStream", 
                                                                                    ByteArrayInputStream.class, result.getClass());
                                                                        assertEquals("Stream should be empty", -1, result.read());
                                                                        
                                                                        // Cleanup
                                                                        result.close();
                                                                    }

    @Test
                                                               public void testGetCurrentStreamWithZeroSizeEntry3() throws Exception {
                                                                   // Setup
                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                   
                                                                   // Use reflection to get the archive instance and modify it
                                                                   Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                   archiveField.setAccessible(true);
                                                                   Object archive = archiveField.get(sevenZFile);
                                                                   
                                                                   // Get the files array from archive
                                                                   Field filesField = archive.getClass().getDeclaredField("files");
                                                                   filesField.setAccessible(true);
                                                                   Object[] entries = (Object[]) filesField.get(archive);
                                                                   
                                                                   // Get the first entry and set its size to 0
                                                                   Object entry = entries[0];
                                                                   Method getSizeMethod = entry.getClass().getDeclaredMethod("getSize");
                                                                   getSizeMethod.setAccessible(true);
                                                                   
                                                                   // Mock the size to return 0
                                                                   Object mockEntry = mock(entry.getClass());
                                                                   when(getSizeMethod.invoke(mockEntry)).thenReturn(0L);
                                                                   entries[0] = mockEntry;
                                                                   
                                                                   // Set current entry index to 0
                                                                   Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                   currentEntryIndexField.setAccessible(true);
                                                                   currentEntryIndexField.set(sevenZFile, 0);
                                                                   
                                                                   // Get the private getCurrentStream method
                                                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                   getCurrentStreamMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   InputStream stream = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                   
                                                                   // Verify - original should return truly empty stream
                                                                   assertEquals(0, stream.available());  // Will fail on mutant (1 vs 0)
                                                                   assertEquals(-1, stream.read());      // Will fail on mutant (0 vs -1)
                                                                   
                                                                   // Cleanup
                                                                   stream.close();
                                                               }

    @Test
                                                          public void testGetCurrentStream_ReturnsEmptyStreamForZeroSizeEntry() throws Exception {
                                                              // Setup
                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                              
                                                              // Get the internal Archive class using reflection
                                                              Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                              Object archive = mock(archiveClass);
                                                              
                                                              // Get the internal FileEntry class
                                                              Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                              Object fileEntry = mock(fileEntryClass);
                                                              
                                                              // Mock the size to return 0
                                                              when(fileEntryClass.getMethod("getSize").invoke(fileEntry)).thenReturn(0L);
                                                              
                                                              // Set up test object state using reflection
                                                              Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                              archiveField.setAccessible(true);
                                                              archiveField.set(sevenZFile, archive);
                                                              
                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                              currentEntryIndexField.setAccessible(true);
                                                              currentEntryIndexField.set(sevenZFile, 0);
                                                              
                                                              Field filesField = archiveClass.getDeclaredField("files");
                                                              filesField.setAccessible(true);
                                                              filesField.set(archive, Array.newInstance(fileEntryClass, 1));
                                                              Array.set(filesField.get(archive), 0, fileEntry);
                                                              
                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                              deferredBlockStreamsField.setAccessible(true);
                                                              deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                              
                                                              // Get the private method using reflection
                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                              getCurrentStreamMethod.setAccessible(true);
                                                              
                                                              // Test
                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                              
                                                              // Verify
                                                              assertNotNull("Should return non-null stream for zero-size entry", result);
                                                              assertEquals("Should return empty stream", 0, result.available());
                                                              assertTrue("Should return ByteArrayInputStream", result instanceof ByteArrayInputStream);
                                                              
                                                              // Cleanup
                                                              result.close();
                                                          }

    @Test
                                                     public void testGetCurrentStreamWithZeroSizeFileShouldReturnEmptyStream1() throws Exception {
                                                         // Setup test objects
                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                         
                                                         // Use reflection to access private fields since we need to set up test conditions
                                                         Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                         archiveField.setAccessible(true);
                                                         Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                         archiveField.set(sevenZFile, archive);
                                                         
                                                         Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                         currentEntryIndexField.setAccessible(true);
                                                         currentEntryIndexField.set(sevenZFile, 0);
                                                         
                                                         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                         deferredBlockStreamsField.setAccessible(true);
                                                         deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                         
                                                         // Mock the archive file entry to return size 0
                                                         Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                         Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                         Object fileEntry = mock(fileEntryClass);
                                                         when(fileEntryClass.getMethod("getSize").invoke(fileEntry)).thenReturn(0L);
                                                         files[0] = fileEntry;
                                                         when(archive.getClass().getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                         
                                                         // Test the method using reflection since getCurrentStream is private
                                                         Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                         getCurrentStreamMethod.setAccessible(true);
                                                         InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                         
                                                         // Verify the result is an empty stream
                                                         assertNotNull(result);
                                                         assertEquals(0, result.available());
                                                         assertTrue(result instanceof ByteArrayInputStream);
                                                         
                                                         // Clean up
                                                         result.close();
                                                     }

    @Test
                                                public void testGetCurrentStreamThrowsWhenEmpty1() throws Exception {
                                                    // Setup
                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                    
                                                    // Use reflection to access private field since we can't set it directly
                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                    deferredBlockStreamsField.setAccessible(true);
                                                    ArrayList<InputStream> emptyList = new ArrayList<>();
                                                    deferredBlockStreamsField.set(sevenZFile, emptyList);
                                                    
                                                    // Set currentEntryIndex to a non-zero size file to avoid first condition
                                                    Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                    currentEntryIndexField.setAccessible(true);
                                                    currentEntryIndexField.set(sevenZFile, 0);
                                                    
                                                    // Mock archive and its files using reflection since Archive is package-private
                                                    Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                    archiveField.setAccessible(true);
                                                    Object archive = archiveField.get(sevenZFile);
                                                    
                                                    // Get files array from archive
                                                    Field filesField = archive.getClass().getDeclaredField("files");
                                                    filesField.setAccessible(true);
                                                    Object[] files = (Object[]) filesField.get(archive);
                                                    files = new Object[1]; // Create new array
                                                    
                                                    // Create mock file entry
                                                    Object fileEntry = files[0].getClass().newInstance();
                                                    Field sizeField = fileEntry.getClass().getDeclaredField("size");
                                                    sizeField.setAccessible(true);
                                                    sizeField.set(fileEntry, 1L); // Non-zero size
                                                    
                                                    files[0] = fileEntry;
                                                    filesField.set(archive, files);
                                                    
                                                    // Access getCurrentStream via reflection
                                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                    getCurrentStreamMethod.setAccessible(true);
                                                    
                                                    // This should throw IllegalStateException
                                                    getCurrentStreamMethod.invoke(sevenZFile);
                                                }

    @Test(expected = IllegalStateException.class)
                                           public void testGetCurrentStream_EmptyDeferredBlockStreams_ShouldThrowException1() throws Exception {
                                               // Setup
                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                               
                                               // Use reflection to access private fields since we need to set up test conditions
                                               Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                               archiveField.setAccessible(true);
                                               Object archive = mock(archiveField.getType()); // Use reflection to get the type
                                               archiveField.set(sevenZFile, archive);
                                               
                                               Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                               currentEntryIndexField.setAccessible(true);
                                               currentEntryIndexField.set(sevenZFile, 0);
                                               
                                               // Create a non-zero size file entry
                                               SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                               when(entry.getSize()).thenReturn(1L);
                                               
                                               // Create files array using reflection since Archive.File is not accessible
                                               Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                               Object file = fileClass.getConstructor(SevenZArchiveEntry.class).newInstance(entry);
                                               Object[] files = (Object[]) Array.newInstance(fileClass, 1);
                                               files[0] = file;
                                               
                                               // Mock the files field
                                               Field filesField = archive.getClass().getDeclaredField("files");
                                               filesField.setAccessible(true);
                                               filesField.set(archive, files);
                                               
                                               // Set deferredBlockStreams to empty list (not null)
                                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                               deferredBlockStreamsField.setAccessible(true);
                                               deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                               
                                               // Get the private method via reflection
                                               Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                               getCurrentStreamMethod.setAccessible(true);
                                               
                                               // Exercise - should throw IllegalStateException
                                               getCurrentStreamMethod.invoke(sevenZFile);
                                           }

    @Test
                                      public void testGetCurrentStreamWithNonEmptyDeferredStreamsShouldNotThrowException() throws Exception {
                                          // Setup
                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                          
                                          // Get the Archive class via reflection since it's package-private
                                          Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                          Class<?> archiveEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveEntry");
                                          
                                          // Mock archive and current entry
                                          Object mockArchive = mock(archiveClass);
                                          Object mockEntry = mock(archiveEntryClass);
                                          when(mockEntry.getClass().getMethod("getSize").invoke(mockEntry)).thenReturn(1L); // Non-zero size
                                          Object[] entries = new Object[]{mockEntry};
                                          when(mockArchive.getClass().getField("files").get(mockArchive)).thenReturn(entries);
                                          
                                          // Set up non-empty deferredBlockStreams
                                          ArrayList<InputStream> streams = new ArrayList<>();
                                          InputStream mockStream = mock(InputStream.class);
                                          streams.add(mockStream);
                                          
                                          // Use reflection to set private fields
                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                          archiveField.setAccessible(true);
                                          archiveField.set(sevenZFile, mockArchive);
                                          
                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                          currentEntryIndexField.setAccessible(true);
                                          currentEntryIndexField.set(sevenZFile, 0);
                                          
                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                          deferredBlockStreamsField.setAccessible(true);
                                          deferredBlockStreamsField.set(sevenZFile, streams);
                                          
                                          // Access private getCurrentStream method via reflection
                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                          getCurrentStreamMethod.setAccessible(true);
                                          
                                          // Test - should not throw exception with original code
                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                          
                                          // Verify
                                          assertNotNull(result);
                                          assertEquals(mockStream, result);
                                      }

    @Test
                                 public void testGetCurrentStreamThrowsWhenEmpty2() throws Exception {
                                     // Setup
                                     SevenZFile sevenZFile = mock(SevenZFile.class);
                                     SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                     
                                     // Use reflection to access private fields and methods
                                     Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                     archiveField.setAccessible(true);
                                     Object archive = mock(archiveField.getType());
                                     
                                     Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                     currentEntryIndexField.setAccessible(true);
                                     
                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                     deferredBlockStreamsField.setAccessible(true);
                                     
                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                     getCurrentStreamMethod.setAccessible(true);
                                     
                                     // Configure mocks
                                     when(sevenZFile.getNextEntry()).thenReturn(null); // Simulate no current entry
                                     when(archiveField.get(sevenZFile)).thenReturn(archive);
                                     when(currentEntryIndexField.get(sevenZFile)).thenReturn(0);
                                     when(deferredBlockStreamsField.get(sevenZFile)).thenReturn(new ArrayList<>());
                                     
                                     // Configure archive mock
                                     Field filesField = archive.getClass().getDeclaredField("files");
                                     filesField.setAccessible(true);
                                     filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                     
                                     when(entry.getSize()).thenReturn(1L); // Non-zero size
                                     
                                     // Expect exception
                                     thrown.expect(IllegalStateException.class);
                                     thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                     
                                     // Test
                                     getCurrentStreamMethod.invoke(sevenZFile);
                                 }

    @Test(expected = IllegalStateException.class)
                            public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry4() throws Exception {
                                // Setup test data
                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                
                                // Use reflection to access private fields since we need to set up the test condition
                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                archiveField.setAccessible(true);
                                
                                // Create mock archive using reflection since Archive class is not public
                                Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                Object archive = mock(archiveClass);
                                archiveField.set(sevenZFile, archive);
                                
                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                currentEntryIndexField.setAccessible(true);
                                currentEntryIndexField.set(sevenZFile, 0);
                                
                                // Create mock archive file with non-zero size
                                Class<?> archiveFileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveFile");
                                Object mockFile = mock(archiveFileClass);
                                when(mockFile.getClass().getMethod("getSize").invoke(mockFile)).thenReturn(1L); // Non-zero size
                                
                                Field filesField = archiveClass.getDeclaredField("files");
                                filesField.setAccessible(true);
                                Object[] filesArray = (Object[]) Array.newInstance(archiveFileClass, 1);
                                filesArray[0] = mockFile;
                                filesField.set(archive, filesArray);
                                
                                // Ensure deferredBlockStreams is empty
                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                deferredBlockStreamsField.setAccessible(true);
                                @SuppressWarnings("unchecked")
                                ArrayList<InputStream> emptyList = new ArrayList<>();
                                deferredBlockStreamsField.set(sevenZFile, emptyList);
                                
                                // Access private getCurrentStream method
                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                getCurrentStreamMethod.setAccessible(true);
                                getCurrentStreamMethod.invoke(sevenZFile);
                            }

    @Test(expected = IllegalStateException.class)
                   public void testGetCurrentStreamThrowsExceptionWithCorrectMessageWhenNoEntry1() throws Exception {
                       // Setup
                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                       
                       // Use reflection to access private field since we need to test error case
                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                       deferredBlockStreamsField.setAccessible(true);
                       ArrayList<InputStream> emptyList = new ArrayList<>();
                       deferredBlockStreamsField.set(sevenZFile, emptyList);
                       
                       // Get the Archive class through reflection since it's not public
                       Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                       archiveField.setAccessible(true);
                       Object archive = mock(archiveClass);
                       archiveField.set(sevenZFile, archive);
                       
                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                       currentEntryIndexField.setAccessible(true);
                       currentEntryIndexField.set(sevenZFile, 0);
                       
                       // Mock archive.files[0] behavior
                       SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                       when(entry.getSize()).thenReturn(1L); // Not zero case
                       
                       // Create FileInfo array through reflection
                       Class<?> fileInfoClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileInfo");
                       Constructor<?> fileInfoCtor = fileInfoClass.getDeclaredConstructor(SevenZArchiveEntry.class);
                       fileInfoCtor.setAccessible(true);
                       Object fileInfo = fileInfoCtor.newInstance(entry);
                       Object[] files = (Object[]) Array.newInstance(fileInfoClass, 1);
                       files[0] = fileInfo;
                       
                       // Mock the files field
                       Field filesField = archiveClass.getDeclaredField("files");
                       filesField.setAccessible(true);
                       filesField.set(archive, files);
                       
                       try {
                           // Method under test
                           Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                           getCurrentStreamMethod.setAccessible(true);
                           getCurrentStreamMethod.invoke(sevenZFile);
                       } catch (InvocationTargetException e) {
                           // Verify the exception message
                           assertEquals("No current 7z entry (call getNextEntry() first).", e.getCause().getMessage());
                           throw (IllegalStateException) e.getCause();
                       }
                   }

    @Test(expected = IllegalStateException.class)
              public void testGetCurrentStream_WhenNoDeferredBlockStreams_ShouldThrowException() throws Exception {
                  // Arrange
                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                  
                  // Use reflection to access private fields since we need to set up test conditions
                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                  archiveField.setAccessible(true);
                  Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                  archiveField.set(sevenZFile, archive);
                  
                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                  currentEntryIndexField.setAccessible(true);
                  currentEntryIndexField.set(sevenZFile, 0);
                  
                  Field filesField = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive").getDeclaredField("files");
                  filesField.setAccessible(true);
                  SevenZArchiveEntry[] files = new SevenZArchiveEntry[1];
                  files[0] = mock(SevenZArchiveEntry.class);
                  when(files[0].getSize()).thenReturn(1L); // Ensure size is not 0
                  filesField.set(archive, files);
                  
                  Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                  deferredBlockStreamsField.setAccessible(true);
                  ArrayList<InputStream> emptyList = new ArrayList<>();
                  deferredBlockStreamsField.set(sevenZFile, emptyList);
                  
                  // Access private getCurrentStream method
                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                  getCurrentStreamMethod.setAccessible(true);
                  
                  // Act - should throw IllegalStateException
                  getCurrentStreamMethod.invoke(sevenZFile);
              }

    @Test(expected = IllegalStateException.class)
         public void testGetCurrentStream_WhenNoCurrentEntry_ShouldThrowException2() throws Exception {
             // Setup test data
             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
             
             // Use reflection to access private fields
             Field archiveField = SevenZFile.class.getDeclaredField("archive");
             archiveField.setAccessible(true);
             Object archive = mock(archiveField.getType()); // Use reflection to create mock
             
             archiveField.set(sevenZFile, archive);
             
             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
             currentEntryIndexField.setAccessible(true);
             currentEntryIndexField.set(sevenZFile, 0);
             
             // Create mock files array
             Object[] files = new Object[1];
             Object mockFile = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveFile"));
             when(mockFile.getClass().getMethod("getSize").invoke(mockFile)).thenReturn(1L); // Non-zero size
             files[0] = mockFile;
             when(archive.getClass().getMethod("getFiles").invoke(archive)).thenReturn(files);
             
             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
             deferredBlockStreamsField.setAccessible(true);
             ArrayList<InputStream> emptyStreams = new ArrayList<>();
             deferredBlockStreamsField.set(sevenZFile, emptyStreams);
             
             // Access private method via reflection
             Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
             getCurrentStreamMethod.setAccessible(true);
             getCurrentStreamMethod.invoke(sevenZFile);
         }

    @Test
    public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry5() throws Exception {
        // Setup test data
        SevenZFile sevenZFile = mock(SevenZFile.class);
        
        // Use reflection to access private fields
        Field archiveField = SevenZFile.class.getDeclaredField("archive");
        archiveField.setAccessible(true);
        Object archive = mock(archiveField.getType());
        
        Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
        currentEntryIndexField.setAccessible(true);
        
        Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
        deferredBlockStreamsField.setAccessible(true);
        
        SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
        
        // Configure mocks
        when(sevenZFile.getNextEntry()).thenCallRealMethod();
        archiveField.set(sevenZFile, archive);
        currentEntryIndexField.set(sevenZFile, -1); // Set to -1 to trigger the exception
        deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
        
        // Mock archive contents
        Field filesField = archive.getClass().getDeclaredField("files");
        filesField.setAccessible(true);
        SevenZArchiveEntry[] entries = new SevenZArchiveEntry[]{entry};
        filesField.set(archive, entries);
        
        when(entry.getSize()).thenReturn(1L); // Ensure we don't take the empty stream path
        
        // Expect specific exception
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
        
        // Use reflection to call private method
        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
        getCurrentStreamMethod.setAccessible(true);
        getCurrentStreamMethod.invoke(sevenZFile);
    }


}
