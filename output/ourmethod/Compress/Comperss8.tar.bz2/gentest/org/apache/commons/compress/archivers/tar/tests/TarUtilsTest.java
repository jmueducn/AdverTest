package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
        public void testParseOctal_ValidOctalNumber() {
            byte[] buffer = {' ', '1', '2', '3', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 6);
            assertEquals(83L, result); // 123 in octal is 83 in decimal
        }

    @Test
        public void testParseOctal_AllNULBytes() {
            byte[] buffer = {0, 0, 0, 0, 0};
            long result = TarUtils.parseOctal(buffer, 0, 5);
            assertEquals(0L, result);
        }

    @Test
        public void testParseOctal_LeadingSpaces() {
            byte[] buffer = {' ', ' ', '7', '5', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 6);
            assertEquals(61L, result); // 75 in octal is 61 in decimal
        }

    @Test
        public void testParseOctal_DoubleTrailingSeparators() {
            byte[] buffer = {'1', '0', ' ', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 5);
            assertEquals(8L, result); // 10 in octal is 8 in decimal
        }

    @Test
        public void testParseOctal_MinimumValidLength() {
            byte[] buffer = {'1', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 3);
            assertEquals(1L, result);
        }

    @Test
        public void testParseOctal_InvalidLength() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("Length 1 must be at least 2");
            byte[] buffer = {'1'};
            TarUtils.parseOctal(buffer, 0, 1);
        }

    @Test
        public void testParseOctal_InvalidTrailer() {
            thrown.expect(IllegalArgumentException.class);
            byte[] buffer = {'1', '2', '3', 'x'};
            TarUtils.parseOctal(buffer, 0, 4);
        }

    @Test
        public void testParseOctal_InvalidOctalDigit() {
            thrown.expect(IllegalArgumentException.class);
            byte[] buffer = {'1', '8', ' ', 0};
            TarUtils.parseOctal(buffer, 0, 4);
        }

    @Test
        public void testParseOctal_MaximumOctalValue() {
            byte[] buffer = {'1', '7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 11);
            assertEquals(2147483647L, result); // 17777777777 in octal is 2147483647 in decimal
        }

    @Test
        public void testParseOctal_WithOffset() {
            byte[] buffer = {'x', 'x', ' ', '7', '5', ' ', 0, 'x'};
            long result = TarUtils.parseOctal(buffer, 2, 5);
            assertEquals(61L, result); // 75 in octal is 61 in decimal
        }

    @Test
        public void testParseOctal_EmptyAfterTrim() {
            byte[] buffer = {' ', ' ', 0};
            long result = TarUtils.parseOctal(buffer, 0, 3);
            assertEquals(0L, result);
        }

}
