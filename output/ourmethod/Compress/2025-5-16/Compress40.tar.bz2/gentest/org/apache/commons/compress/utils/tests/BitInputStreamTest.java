package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteOrder;
 
public class BitInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test(expected = IllegalArgumentException.class)
                                                                                                                                                    public void testReadBits_InvalidCount_ThrowsException() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                        InputStream mockInput = mock(InputStream.class);
                                                                                                                                                        BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        // Get MAXIMUM_CACHE_SIZE via reflection
                                                                                                                                                        Field maxCacheField = BitInputStream.class.getDeclaredField("MAXIMUM_CACHE_SIZE");
                                                                                                                                                        maxCacheField.setAccessible(true);
                                                                                                                                                        int maxCacheSize = maxCacheField.getInt(bis);
                                                                                                                                                        
                                                                                                                                                        try {
                                                                                                                                                            bis.readBits(-1);
                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                            assertEquals("count must not be negative or greater than " + maxCacheSize, e.getMessage());
                                                                                                                                                            throw e;
                                                                                                                                                        }
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_CountZero_ReturnsZero() throws IOException {
                                                                                                                                                        byte[] TEST_BYTES = new byte[] {0x01, 0x02, 0x03}; // Sample test bytes
                                                                                                                                                        InputStream input = new ByteArrayInputStream(TEST_BYTES);
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0, bis.readBits(0));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_BigEndian_SingleByte() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x55});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0x5, bis.readBits(4));
                                                                                                                                                        assertEquals(0x5, bis.readBits(4));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_LittleEndian_SingleByte() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x55});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0x5, bis.readBits(4));
                                                                                                                                                        assertEquals(0x5, bis.readBits(4));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_BigEndian_MultipleBytes() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x12, 0x34});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        org.junit.Assert.assertEquals(0x123, bis.readBits(12));
                                                                                                                                                        org.junit.Assert.assertEquals(0x4, bis.readBits(4));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_LittleEndian_MultipleBytes() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x12, 0x34});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0x412, bis.readBits(12));
                                                                                                                                                        assertEquals(0x3, bis.readBits(4));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_WithOverflow_BigEndian() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{
                                                                                                                                                            (byte)0x12, (byte)0x34, (byte)0x56, (byte)0x78, 
                                                                                                                                                            (byte)0x9A, (byte)0xBC, (byte)0xDE, (byte)0xF0
                                                                                                                                                        });
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        // Read 57 bits (more than can fit in a long without overflow)
                                                                                                                                                        long result = bis.readBits(57);
                                                                                                                                                        assertEquals(0x123456789ABCDEFL >>> 7, result);
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_WithOverflow_LittleEndian() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{
                                                                                                                                                            (byte)0x12, (byte)0x34, (byte)0x56, (byte)0x78,
                                                                                                                                                            (byte)0x9A, (byte)0xBC, (byte)0xDE, (byte)0xF0
                                                                                                                                                        });
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        // Read 57 bits (more than can fit in a long without overflow)
                                                                                                                                                        long result = bis.readBits(57);
                                                                                                                                                        long expected = 0xF0DEBC9A78563412L & ((1L << 57) - 1);
                                                                                                                                                        assertEquals(expected, result);
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_EndOfStream_ReturnsNegative() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(-1, bis.readBits(8));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_PartialEndOfStream() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x12});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0x1, bis.readBits(4));
                                                                                                                                                        assertEquals(-1, bis.readBits(8));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_CacheBehavior() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x12, 0x34, 0x56, 0x78});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        // Read partial bytes and verify cache behavior
                                                                                                                                                        assertEquals(0x1, bis.readBits(4));
                                                                                                                                                        assertEquals(0x2, bis.readBits(4));
                                                                                                                                                        assertEquals(0x3, bis.readBits(4));
                                                                                                                                                        assertEquals(0x4, bis.readBits(4));
                                                                                                                                                        assertEquals(0x56, bis.readBits(8));
                                                                                                                                                        assertEquals(0x7, bis.readBits(4));
                                                                                                                                                        assertEquals(0x8, bis.readBits(4));
                                                                                                                                                    }

 @Test
                                                                                                                                                    public void testReadBits_MixedSizes() throws IOException {
                                                                                                                                                        InputStream input = new ByteArrayInputStream(new byte[]{0x12, 0x34, 0x56, 0x78});
                                                                                                                                                        BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0x123, bis.readBits(12));
                                                                                                                                                        assertEquals(0x45, bis.readBits(8));
                                                                                                                                                        assertEquals(0x678, bis.readBits(12));
                                                                                                                                                    }

 @Test
                                                                                                                                               public void testReadBitsWithMaximumCacheSizeShouldNotThrowException() throws Exception {
                                                                                                                                                   // Arrange
                                                                                                                                                   final int MAXIMUM_CACHE_SIZE = 63; // Based on tested method's logic
                                                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                   BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                                                                                                   
                                                                                                                                                   // We need to set up the mock to return some bytes since the method will try to read
                                                                                                                                                   when(mockInputStream.read()).thenReturn(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, -1);
                                                                                                                                                   
                                                                                                                                                   try {
                                                                                                                                                       // Act - This should NOT throw exception in original, but would throw in mutant
                                                                                                                                                       long result = bis.readBits(MAXIMUM_CACHE_SIZE);
                                                                                                                                                       
                                                                                                                                                       // Assert - If we get here in original, test passes
                                                                                                                                                       // The actual value doesn't matter for this test case
                                                                                                                                                       assertTrue(true);
                                                                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                                                                       // This is where the mutant would fail
                                                                                                                                                       fail("Original implementation should accept count equal to MAXIMUM_CACHE_SIZE");
                                                                                                                                                   }
                                                                                                                                               }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                               public void testReadBitsExceedingMaximumCacheSizeShouldThrowException() throws Exception {
                                                                                                                                                   // Arrange
                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                   BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                                                                                                   
                                                                                                                                                   // Get MAXIMUM_CACHE_SIZE via reflection since it's likely a private constant
                                                                                                                                                   Field maxCacheSizeField = BitInputStream.class.getDeclaredField("MAXIMUM_CACHE_SIZE");
                                                                                                                                                   maxCacheSizeField.setAccessible(true);
                                                                                                                                                   int MAXIMUM_CACHE_SIZE = maxCacheSizeField.getInt(bis);
                                                                                                                                                   
                                                                                                                                                   // Act - This should throw exception in both original and mutant
                                                                                                                                                   bis.readBits(MAXIMUM_CACHE_SIZE + 1);
                                                                                                                                               }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                               public void testReadBitsWithNegativeCountShouldThrowException() throws Exception {
                                                                                                                                                   // Arrange
                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                   BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                                                                                                   
                                                                                                                                                   // Act - This should throw exception in both original and mutant
                                                                                                                                                   bis.readBits(-1);
                                                                                                                                               }

 @Test
                                                                                                                                      public void testReadBitsThrowsIllegalArgumentExceptionWithNegativeCount() throws IOException {
                                                                                                                                          final int MAXIMUM_CACHE_SIZE = 57;
                                                                                                                                          ExpectedException thrown = ExpectedException.none();
                                                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                                                          thrown.expectMessage("count must not be negative or greater than " + MAXIMUM_CACHE_SIZE);
                                                                                                                                          
                                                                                                                                          // Create mock input stream
                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                          BitInputStream bitInputStream = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                                                                                          
                                                                                                                                          // Test with negative count
                                                                                                                                          bitInputStream.readBits(-1);
                                                                                                                                      }

 @Test
                                                                                                                                      public void testReadBitsThrowsIllegalArgumentExceptionWithExcessiveCount() throws IOException {
                                                                                                                                          final int MAXIMUM_CACHE_SIZE = 63; // Based on the tested method's logic
                                                                                                                                          InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                          BitInputStream bitInputStream = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                                                                                                                          
                                                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                                                          thrown.expectMessage("count must not be negative or greater than " + MAXIMUM_CACHE_SIZE);
                                                                                                                                          
                                                                                                                                          // Test with count exceeding MAXIMUM_CACHE_SIZE
                                                                                                                                          bitInputStream.readBits(MAXIMUM_CACHE_SIZE + 1);
                                                                                                                                      }

 @Test
                                                                                                                                  public void testReadBitsDetectsMutatedReadByte() throws IOException {
                                                                                                                                      // Setup mock input stream that returns specific bytes
                                                                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                                                                      when(mockInput.read()).thenReturn(0x12, 0x34, -1); // Return two bytes then EOF
                                                                                                                                      
                                                                                                                                      // Test both byte orders
                                                                                                                                      for (ByteOrder order : new ByteOrder[]{ByteOrder.LITTLE_ENDIAN, ByteOrder.BIG_ENDIAN}) {
                                                                                                                                          BitInputStream bis = new BitInputStream(mockInput, order);
                                                                                                                                          
                                                                                                                                          // First read - should return actual byte content, not 0
                                                                                                                                          long result = bis.readBits(8);
                                                                                                                                          assertNotEquals("Should not return 0 when input is non-zero", 0, result);
                                                                                                                                          
                                                                                                                                          // Second read - should return next byte
                                                                                                                                          result = bis.readBits(8);
                                                                                                                                          assertNotEquals("Should not return 0 when input is non-zero", 0, result);
                                                                                                                                          
                                                                                                                                          // Third read - should detect EOF
                                                                                                                                          result = bis.readBits(8);
                                                                                                                                          assertEquals("Should return -1 for EOF", -1, result);
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Verify mock interactions
                                                                                                                                      verify(mockInput, times(3)).read();
                                                                                                                                  }

 @Test
                                                                                                                                public void testReadBitsWithZeroByteShouldNotReturnEOF() throws Exception {
                                                                                                                                    // Setup mock InputStream to return 0 (valid byte) then -1 (EOF)
                                                                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                                                                    when(mockIn.read())
                                                                                                                                        .thenReturn(0)  // First byte is zero
                                                                                                                                        .thenReturn(-1); // Then EOF
                                                                                                                                    
                                                                                                                                    // Create BitInputStream with mock and BIG_ENDIAN (order doesn't matter for this test)
                                                                                                                                    BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                                                                                    
                                                                                                                                    // Set initial cache state using reflection
                                                                                                                                    Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                                                    bitsCachedField.setAccessible(true);
                                                                                                                                    bitsCachedField.setLong(bis, 0L);
                                                                                                                                    
                                                                                                                                    Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                                                    bitsCachedSizeField.setAccessible(true);
                                                                                                                                    bitsCachedSizeField.setInt(bis, 0);
                                                                                                                                    
                                                                                                                                    // Test reading 8 bits (1 byte)
                                                                                                                                    long result = bis.readBits(8);
                                                                                                                                    
                                                                                                                                    // Verify we got the zero byte, not -1
                                                                                                                                    assertEquals(0L, result);
                                                                                                                                    
                                                                                                                                    // Verify we actually tried to read from stream
                                                                                                                                    verify(mockIn, times(2)).read(); // Once for the byte, once for EOF
                                                                                                                                }

 @Test
                                                                                                                           public void testReadBitsWithOverflowDetectsMutant() throws Exception {
                                                                                                                               // Setup mock input stream to return specific bytes
                                                                                                                               InputStream mockIn = mock(InputStream.class);
                                                                                                                               when(mockIn.read())
                                                                                                                                   .thenReturn(0xFF)  // First byte to fill cache
                                                                                                                                   .thenReturn(0xAA); // Second byte for overflow
                                                                                                                               
                                                                                                                               // Initialize BitInputStream with little-endian order
                                                                                                                               BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                                                               
                                                                                                                               // Set up initial cache state to force overflow handling using reflection
                                                                                                                               // We need bitsCachedSize < count and count large enough to trigger overflow
                                                                                                                               Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                                               bitsCachedField.setAccessible(true);
                                                                                                                               bitsCachedField.setLong(bis, 0L);
                                                                                                                               
                                                                                                                               Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                                               bitsCachedSizeField.setAccessible(true);
                                                                                                                               bitsCachedSizeField.setInt(bis, 56); // Just below 57 to force overflow path
                                                                                                                               
                                                                                                                               // Call readBits with count that requires overflow handling
                                                                                                                               long result = bis.readBits(60); // 60 > 56, will trigger overflow path
                                                                                                                               
                                                                                                                               // Verify the result - mutant would return wrong value due to overflow=1
                                                                                                                               // Expected calculation:
                                                                                                                               // - First byte (0xFF) fills 56 bits (all 1s)
                                                                                                                               // - Second byte (0xAA) provides 4 more bits (1010)
                                                                                                                               // - In little-endian, these are OR'd together
                                                                                                                               // - Final mask should be 60 bits: 0xAAAAAAAAAAAAAAAF (last 4 bits from 0xA)
                                                                                                                               long expected = 0xAAAAAAAAAAAAAAAFL & ((1L << 60) - 1);
                                                                                                                               assertEquals("Should correctly handle overflow bits", expected, result);
                                                                                                                               
                                                                                                                               // Verify overflow bits were properly set in cache using reflection
                                                                                                                               // After reading 60 bits from 56+8, we should have 4 overflow bits left (1010)
                                                                                                                               assertEquals(4, bitsCachedSizeField.getInt(bis));
                                                                                                                               assertEquals(0xAL, bitsCachedField.getLong(bis));
                                                                                                                           }

 @Test
                                                                                                                      public void testReadBitsWithOverflowCalculation() throws Exception {
                                                                                                                          // Setup - create a BitInputStream with mocked InputStream
                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                          when(mockInput.read())
                                                                                                                              .thenReturn(0xFF)  // First byte read (all 1s)
                                                                                                                              .thenReturn(0xAA); // Second byte read (10101010)
                                                                                                                          
                                                                                                                          BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                                                                          
                                                                                                                          // Initialize cache state to force overflow calculation
                                                                                                                          // We'll set bitsCachedSize to 56 (just below 57 threshold)
                                                                                                                          // and request 60 bits (count = 60)
                                                                                                                          // This makes bitsToAddCount = 60 - 56 = 4
                                                                                                                          // Original: overflowBits = 8 - 4 = 4
                                                                                                                          // Mutant: overflowBits = 7 - 4 = 3 (incorrect)
                                                                                                                          
                                                                                                                          // Use reflection to set private fields
                                                                                                                          Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                                          bitsCachedField.setAccessible(true);
                                                                                                                          bitsCachedField.set(bis, 0L); // Clear cache
                                                                                                                          
                                                                                                                          Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                                          bitsCachedSizeField.setAccessible(true);
                                                                                                                          bitsCachedSizeField.set(bis, 56); // Set to 56 bits
                                                                                                                          
                                                                                                                          // Test - read 60 bits
                                                                                                                          long result = bis.readBits(60);
                                                                                                                          
                                                                                                                          // Verify
                                                                                                                          // Original behavior:
                                                                                                                          // - First byte (0xFF) is read and added to cache (56->64 bits)
                                                                                                                          // - Then we need 60 bits from cache (no overflow case)
                                                                                                                          // - Should return lower 60 bits of 0xFF (which is 0xFF)
                                                                                                                          // - Remaining cache should be upper 4 bits (0xF)
                                                                                                                          
                                                                                                                          // With mutant:
                                                                                                                          // - Overflow calculation would be wrong
                                                                                                                          // - Cache handling would be incorrect
                                                                                                                          
                                                                                                                          // 0xFFFFFFFFFFFFFFFL is the mask for 60 bits (60 1's)
                                                                                                                          assertEquals(0xFFFFFFFFFFFFFFFL, result);
                                                                                                                          
                                                                                                                          // Verify remaining cache state
                                                                                                                          long remainingCache = (Long)bitsCachedField.get(bis);
                                                                                                                          int remainingSize = (Integer)bitsCachedSizeField.get(bis);
                                                                                                                          assertEquals(4, remainingSize);
                                                                                                                          assertEquals(0xF, remainingCache);
                                                                                                                      }

 @Test
                                                                                                                 public void testReadBitsDetectsBitmaskMutation() throws Exception {
                                                                                                                     // Setup - we need to trigger the overflow case with little-endian order
                                                                                                                     // and verify the bit extraction is correct
                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                     when(mockInput.read()).thenReturn(0b11010101); // test byte with high bits set
                                                                                                                     
                                                                                                                     BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                                                                     
                                                                                                                     // Use reflection to access private fields
                                                                                                                     Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                                     bitsCachedField.setAccessible(true);
                                                                                                                     Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                                     bitsCachedSizeField.setAccessible(true);
                                                                                                                     
                                                                                                                     // Initialize cache state to trigger overflow path
                                                                                                                     bitsCachedField.setLong(bis, 0L);
                                                                                                                     bitsCachedSizeField.setInt(bis, 56); // 7 bytes cached (7*8=56 bits), need more
                                                                                                                     
                                                                                                                     // Try to read 60 bits (will trigger overflow path)
                                                                                                                     long result = bis.readBits(60);
                                                                                                                     
                                                                                                                     // Verify only the correct bits were extracted
                                                                                                                     // For little-endian, we expect:
                                                                                                                     // - First 56 bits come from bitsCached (all 0 in our case)
                                                                                                                     // - Next 4 bits come from the first 4 bits of our test byte (0b0101)
                                                                                                                     // The mutation would OR with the mask (0b1111) giving us 0b1101 | 0b1111 = 0b1111
                                                                                                                     // instead of the correct 0b1101 & 0b1111 = 0b0101
                                                                                                                     assertEquals(0b0101L, result);
                                                                                                                     
                                                                                                                     // Verify the overflow bits were handled correctly
                                                                                                                     // The remaining 4 bits should be saved in cache (0b1101)
                                                                                                                     assertEquals(4, bitsCachedSizeField.getInt(bis));
                                                                                                                     assertEquals(0b1101L, bitsCachedField.getLong(bis));
                                                                                                                 }

 @Test
                                                                                                             public void testReadBitsWithOverflowPreservesExistingCache_LittleEndian() throws Exception {
                                                                                                                 // Setup mock input stream to return bytes that will trigger overflow handling
                                                                                                                 // First byte (0xFF) will be cached normally, second byte (0x01) will trigger overflow
                                                                                                                 InputStream mockIn = mock(InputStream.class);
                                                                                                                 when(mockIn.read())
                                                                                                                     .thenReturn(0xFF)  // First byte - fills initial cache
                                                                                                                     .thenReturn(0x01); // Second byte - triggers overflow handling
                                                                                                                 
                                                                                                                 // Create BitInputStream with little-endian byte order
                                                                                                                 BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                                                 
                                                                                                                 // Read first 8 bits to populate cache (0xFF)
                                                                                                                 bis.readBits(8);
                                                                                                                 
                                                                                                                 // Now read 56 bits - this will trigger overflow handling
                                                                                                                 // Original behavior: should OR the new bits with existing 0xFF in cache
                                                                                                                 // Mutant behavior: will overwrite the cache with just the new bits
                                                                                                                 long result = bis.readBits(56);
                                                                                                                 
                                                                                                                 // Verify the result contains bits from both reads
                                                                                                                 // For little-endian, the first byte (0xFF) should be in lower bits
                                                                                                                 // and the second byte (0x01) should be in higher bits
                                                                                                                 long expected = 0x01L << 8 | 0xFFL;
                                                                                                                 assertEquals("Result should combine bits from both reads", expected, result);
                                                                                                                 
                                                                                                                 // Verify we read exactly two bytes from the stream
                                                                                                                 verify(mockIn, times(2)).read();
                                                                                                             }

 @Test
                                                                                                           public void testReadBitsDetectsUnsignedShiftMutant() throws Exception {
                                                                                                               // Define MASKS array locally
                                                                                                               final long[] MASKS = new long[65];
                                                                                                               for (int i = 0; i < MASKS.length; i++) {
                                                                                                                   MASKS[i] = (1L << i) - 1;
                                                                                                               }
                                                                                                               
                                                                                                               // Setup - create a negative byte value (highest bit set)
                                                                                                               final long negativeByte = 0b10000000L; // -128 in byte
                                                                                                               final int count = 60; // Force overflow handling (bitsCachedSize >= 57)
                                                                                                               final int initialCachedSize = 56; // Just below overflow threshold
                                                                                                               final int bitsToAddCount = count - initialCachedSize; // 4
                                                                                                               final int overflowBits = 8 - bitsToAddCount; // 4
                                                                                                               
                                                                                                               // Mock input stream to return our negative byte
                                                                                                               InputStream mockIn = mock(InputStream.class);
                                                                                                               when(mockIn.read()).thenReturn((int)negativeByte);
                                                                                                               
                                                                                                               // Create BitInputStream with LITTLE_ENDIAN order
                                                                                                               BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                                               
                                                                                                               // Set up initial cache state using reflection
                                                                                                               Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                               bitsCachedField.setAccessible(true);
                                                                                                               bitsCachedField.setLong(bis, 0L);
                                                                                                               
                                                                                                               Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                               bitsCachedSizeField.setAccessible(true);
                                                                                                               bitsCachedSizeField.setInt(bis, initialCachedSize);
                                                                                                               
                                                                                                               // Calculate expected overflow with proper unsigned shift
                                                                                                               long expectedOverflow = (negativeByte >>> bitsToAddCount) & MASKS[overflowBits];
                                                                                                               
                                                                                                               // Execute
                                                                                                               long result = bis.readBits(count);
                                                                                                               
                                                                                                               // Verify - for original code, overflow should be 0b1000 (8)
                                                                                                               // For mutant with >>, overflow would be 0b11111000 (-8 & 0xF = 8) 
                                                                                                               // but we can verify the bitsOut is correct which depends on proper overflow handling
                                                                                                               long expectedBitsOut = negativeByte & MASKS[bitsToAddCount]; // Last 4 bits of negativeByte (0)
                                                                                                               
                                                                                                               assertEquals("Bits out should match expected value", expectedBitsOut, result);
                                                                                                               
                                                                                                               // Additional verification for overflow handling
                                                                                                               int actualCachedSize = bitsCachedSizeField.getInt(bis);
                                                                                                               if (actualCachedSize == overflowBits) {
                                                                                                                   long actualOverflow = bitsCachedField.getLong(bis);
                                                                                                                   assertEquals("Overflow bits should be properly shifted", expectedOverflow, actualOverflow);
                                                                                                               }
                                                                                                           }

 @Test
                                                                                                       public void testReadBitsDetectsShiftMutant() throws Exception {
                                                                                                           // Setup - create a mock input stream that will return specific bytes
                                                                                                           InputStream mockIn = mock(InputStream.class);
                                                                                                           when(mockIn.read())
                                                                                                               .thenReturn(0xFF)  // first byte to fill cache
                                                                                                               .thenReturn(0xAA); // second byte for overflow handling
                                                                                                           
                                                                                                           // Create BitInputStream with big-endian byte order
                                                                                                           BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                                                           
                                                                                                           // Set up initial cache state to trigger overflow handling path
                                                                                                           // We need bitsCachedSize < count and bitsCachedSize >= 57
                                                                                                           // Let's set count to 60 (needing 3 more bits than we have)
                                                                                                           // and initialize cache with 57 bits (so we need to read one more byte)
                                                                                                           
                                                                                                           // Use reflection to set private fields since we need specific initial state
                                                                                                           Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                           bitsCachedField.setAccessible(true);
                                                                                                           bitsCachedField.set(bis, 0x1FFFFFFFFFFFFFFL); // 57 bits set (value doesn't matter much)
                                                                                                           
                                                                                                           Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                           bitsCachedSizeField.setAccessible(true);
                                                                                                           bitsCachedSizeField.set(bis, 57);
                                                                                                           
                                                                                                           // Call method - requesting 60 bits
                                                                                                           long result = bis.readBits(60);
                                                                                                           
                                                                                                           // Verify the result - with original code, this would be:
                                                                                                           // bitsCached (57 bits) shifted left by 3 (count - bitsCachedSize = 60-57=3)
                                                                                                           // OR'ed with top 3 bits of 0xAA (10101010 -> 101)
                                                                                                           // Expected: (0x1FFFFFFFFFFFFFFL << 3) | (0xAA >>> 5)
                                                                                                           long expected = (0x1FFFFFFFFFFFFFFL << 3) | (0xAA >>> 5);
                                                                                                           
                                                                                                           // The mutant would shift by 4 instead of 3, giving wrong result
                                                                                                           assertEquals("Mutant not detected - shift operation incorrect", expected, result);
                                                                                                           
                                                                                                           // Verify we read exactly two bytes
                                                                                                           verify(mockIn, times(2)).read();
                                                                                                       }

 @Test
                                                                                                     public void testReadBitsWithHighBitByteBigEndian() throws Exception {
                                                                                                         // Setup
                                                                                                         InputStream mockInput = mock(InputStream.class);
                                                                                                         when(mockInput.read())
                                                                                                             .thenReturn(0x80)  // First byte with high bit set (10000000 binary)
                                                                                                             .thenReturn(-1);   // End of stream
                                                                                                         
                                                                                                         BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                                                                                         
                                                                                                         // Use reflection to access private fields
                                                                                                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                         bitsCachedField.setAccessible(true);
                                                                                                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                         bitsCachedSizeField.setAccessible(true);
                                                                                                         
                                                                                                         // Set initial cache state to force overflow case
                                                                                                         bitsCachedField.setLong(bis, 0L);
                                                                                                         bitsCachedSizeField.setInt(bis, 56); // Just below 57 to trigger overflow handling
                                                                                                         
                                                                                                         // Test reading 57 bits (which will need to read another byte)
                                                                                                         long result = bis.readBits(57);
                                                                                                         
                                                                                                         // Verify
                                                                                                         // Original code with >>> would give 0x80 shifted right by (8-(57-56))=7 bits
                                                                                                         // which is 0x01 (00000001)
                                                                                                         // Mutant with >> would give 0xFF shifted right by 7 bits (due to sign extension)
                                                                                                         // which is 0xFF (11111111)
                                                                                                         assertEquals(0x01L, result);
                                                                                                         
                                                                                                         // Verify the input stream was read
                                                                                                         verify(mockInput, times(1)).read();
                                                                                                         
                                                                                                         // Reset accessibility
                                                                                                         bitsCachedField.setAccessible(false);
                                                                                                         bitsCachedSizeField.setAccessible(false);
                                                                                                     }

 @Test
                                                                                                 public void testReadBitsDetectsBitwiseOrMutation() throws IOException {
                                                                                                     // Setup - create a mock input stream that will return specific bytes
                                                                                                     InputStream mockIn = mock(InputStream.class);
                                                                                                     when(mockIn.read())
                                                                                                         .thenReturn(0x12)  // first byte to populate initial cache
                                                                                                         .thenReturn(0x34); // second byte for overflow handling
                                                                                                     
                                                                                                     // Create BitInputStream with big-endian byte order
                                                                                                     BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                                                     
                                                                                                     // Set initial cache state to have some bits (simulate previous reads)
                                                                                                     // Using reflection to set private fields for testing
                                                                                                     try {
                                                                                                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                         bitsCachedField.setAccessible(true);
                                                                                                         bitsCachedField.set(bis, 0x12L); // existing cached bits
                                                                                                         
                                                                                                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                         bitsCachedSizeField.setAccessible(true);
                                                                                                         bitsCachedSizeField.set(bis, 8); // 8 bits already cached
                                                                                                     } catch (Exception e) {
                                                                                                         fail("Failed to set private fields via reflection");
                                                                                                     }
                                                                                                     
                                                                                                     // Test reading 16 bits - this will trigger overflow handling
                                                                                                     // With original code: (0x12 << 8) | 0x34 = 0x1234
                                                                                                     // With mutant: would just keep 0x34
                                                                                                     long result = bis.readBits(16);
                                                                                                     
                                                                                                     // Verify the result combines both bytes correctly
                                                                                                     assertEquals(0x1234L, result);
                                                                                                     
                                                                                                     // Verify the input stream was read twice
                                                                                                     verify(mockIn, times(2)).read();
                                                                                                 }

 @Test
                                                                                               public void testReadBitsOverflowBitsComparison() throws Exception {
                                                                                                   // Setup mock InputStream to return specific bytes
                                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                                   when(mockInput.read())
                                                                                                       .thenReturn(0xFF)  // first byte
                                                                                                       .thenReturn(0xFF); // second byte
                                                                                                   
                                                                                                   // Create BitInputStream with big-endian order
                                                                                                   BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                                                                                   
                                                                                                   // First test case: overflowBits == 0 (normal case)
                                                                                                   // Request 64 bits (8 bytes) which will trigger the overflow handling
                                                                                                   // but with overflowBits == 0
                                                                                                   long result = bis.readBits(64);
                                                                                                   // Verify correct bits were returned (all 1s in this case)
                                                                                                   assertEquals(0xFFFFFFFFFFFFFFFFL, result);
                                                                                                   
                                                                                                   // Second test case: try to force negative overflowBits
                                                                                                   // This should never happen in correct operation, but we test it to catch the mutant
                                                                                                   try {
                                                                                                       // Reset mock
                                                                                                       reset(mockInput);
                                                                                                       when(mockInput.read())
                                                                                                           .thenReturn(0xFF)  // first byte
                                                                                                           .thenReturn(0xFF); // second byte
                                                                                                       
                                                                                                       // Request more bits than possible to create negative overflowBits
                                                                                                       // This should throw an exception or behave differently than the == 0 case
                                                                                                       result = bis.readBits(100);
                                                                                                       
                                                                                                       // If we get here, the test should fail as the mutant wasn't caught
                                                                                                       fail("Expected exception or different behavior for negative overflowBits");
                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                       // Expected behavior - count too large
                                                                                                   } catch (Exception e) {
                                                                                                       // Any other exception also indicates the mutant was caught
                                                                                                   }
                                                                                                   
                                                                                                   // Third test case: edge case where bitsToAddCount == 8 (overflowBits = 0)
                                                                                                   reset(mockInput);
                                                                                                   when(mockInput.read())
                                                                                                       .thenReturn(0xFF)  // first byte
                                                                                                       .thenReturn(0xFF); // second byte
                                                                                                   
                                                                                                   // Setup bitsCached to need exactly 8 more bits (overflowBits = 0)
                                                                                                   // Using reflection to access private fields
                                                                                                   Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                   bitsCachedSizeField.setAccessible(true);
                                                                                                   bitsCachedSizeField.set(bis, 56); // 7 bytes already cached
                                                                                                   
                                                                                                   Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                   bitsCachedField.setAccessible(true);
                                                                                                   bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL);
                                                                                                   
                                                                                                   result = bis.readBits(64); // Request 8 bytes total
                                                                                                   assertEquals(0xFFFFFFFFFFFFFFFFL, result);
                                                                                                   
                                                                                                   // Verify overflowBits handling was correct (== 0 case)
                                                                                                   int remainingBits = (int) bitsCachedSizeField.get(bis);
                                                                                                   assertEquals(0, remainingBits);
                                                                                               }

 @Test
                                                                                           public void testReadBitsDetectsUnsignedShiftMutant1() throws IOException {
                                                                                               // Setup - create a negative bitsCached value (high bit set)
                                                                                               // We'll use little-endian mode and setup bitsCached to be negative
                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                               when(mockInput.read())
                                                                                                   .thenReturn(0xFF)  // First byte (all 1s)
                                                                                                   .thenReturn(0x00); // Second byte (all 0s)
                                                                                               
                                                                                               BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                                               
                                                                                               // Use reflection to access private fields for setup
                                                                                               try {
                                                                                                   Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                                   bitsCachedField.setAccessible(true);
                                                                                                   Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                                   bitsCachedSizeField.setAccessible(true);
                                                                                                   
                                                                                                   // Setup initial cache state:
                                                                                                   // Read first byte (0xFF) which will set high bit in little-endian
                                                                                                   bis.readBits(8);
                                                                                                   
                                                                                                   // Now cache has 0xFF (8 bits), which is negative if interpreted as long
                                                                                                   // Read second byte (0x00) to make cache 0x00FF (16 bits)
                                                                                                   bis.readBits(8);
                                                                                                   
                                                                                                   // Now cache has 0x00FF (16 bits)
                                                                                                   // We'll read 8 bits, leaving 8 bits in cache
                                                                                                   // Original code would do unsigned shift, mutant would do signed shift
                                                                                                   long result = bis.readBits(8);
                                                                                                   
                                                                                                   // Verify the result is correct (should be 0xFF)
                                                                                                   assertEquals(0xFF, result);
                                                                                                   
                                                                                                   // Now verify the remaining cache is correct
                                                                                                   long remainingBits = (Long)bitsCachedField.get(bis);
                                                                                                   int remainingSize = (Integer)bitsCachedSizeField.get(bis);
                                                                                                   
                                                                                                   // Original: remainingBits should be 0x00 (unsigned shift)
                                                                                                   // Mutant: remainingBits would be 0xFF (sign-extended)
                                                                                                   assertEquals(0x00, remainingBits);
                                                                                                   assertEquals(8, remainingSize);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Reflection failed: " + e.getMessage());
                                                                                               }
                                                                                           }

 @Test
                                                                                         public void testReadBitsWithCountEqualToMaximumCacheSize() throws Exception {
                                                                                             // Define constants
                                                                                             final int MAXIMUM_CACHE_SIZE = 63; // Based on tested method's logic (57 + 8 - 1)
                                                                                             
                                                                                             // Setup mock input stream
                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                             when(mockInputStream.read()).thenReturn(0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08);
                                                                                             
                                                                                             // Create test streams with different byte orders
                                                                                             BitInputStream littleEndianStream = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
                                                                                             BitInputStream bigEndianStream = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                                             
                                                                                             try {
                                                                                                 // Test with count exactly equal to MAXIMUM_CACHE_SIZE
                                                                                                 long result = littleEndianStream.readBits(MAXIMUM_CACHE_SIZE);
                                                                                                 // If we get here, the test passes (original behavior)
                                                                                                 
                                                                                                 // Also test with big endian
                                                                                                 result = bigEndianStream.readBits(MAXIMUM_CACHE_SIZE);
                                                                                                 
                                                                                             } catch (IllegalArgumentException e) {
                                                                                                 fail("Should not throw exception when count equals MAXIMUM_CACHE_SIZE");
                                                                                             }
                                                                                         }

 @Test
                                                                                         public void testReadBitsWithCountGreaterThanMaximumCacheSize() throws Exception {
                                                                                             // Setup
                                                                                             final int MAXIMUM_CACHE_SIZE = 63; // Based on the tested method's logic
                                                                                             InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                             BitInputStream littleEndianStream = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                                             
                                                                                             // Test
                                                                                             try {
                                                                                                 littleEndianStream.readBits(MAXIMUM_CACHE_SIZE + 1);
                                                                                                 fail("Expected IllegalArgumentException");
                                                                                             } catch (IllegalArgumentException e) {
                                                                                                 // Verify
                                                                                                 assertEquals("count must not be negative or greater than " + MAXIMUM_CACHE_SIZE, e.getMessage());
                                                                                             }
                                                                                         }

 @Test(expected = IllegalArgumentException.class)
                                                                                         public void testReadBitsWithNegativeCount() throws Exception {
                                                                                             // Create a mock InputStream
                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                             // Create BitInputStream with LITTLE_ENDIAN byte order
                                                                                             BitInputStream littleEndianStream = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
                                                                                             // This should throw IllegalArgumentException
                                                                                             littleEndianStream.readBits(-1);
                                                                                         }

 @Test
                                                                                     public void testReadBitsDetectsStreamReadMutation() throws IOException {
                                                                                         // Setup mock input stream that returns specific bytes
                                                                                         InputStream mockStream = mock(InputStream.class);
                                                                                         when(mockStream.read()).thenReturn(0x55, 0xAA); // Return alternating bit patterns
                                                                                         
                                                                                         // Test both byte orders
                                                                                         for (ByteOrder order : new ByteOrder[]{ByteOrder.LITTLE_ENDIAN, ByteOrder.BIG_ENDIAN}) {
                                                                                             BitInputStream bis = new BitInputStream(mockStream, order);
                                                                                             
                                                                                             // First read - should read from stream (would fail if mutated to 0)
                                                                                             long result = bis.readBits(8);
                                                                                             if (order == ByteOrder.LITTLE_ENDIAN) {
                                                                                                 assertEquals(0x55, result); // 01010101
                                                                                             } else {
                                                                                                 assertEquals(0x55, result); // Same for first byte in BIG_ENDIAN
                                                                                             }
                                                                                             
                                                                                             // Second read - should read next byte from stream
                                                                                             result = bis.readBits(8);
                                                                                             if (order == ByteOrder.LITTLE_ENDIAN) {
                                                                                                 assertEquals(0xAA, result); // 10101010
                                                                                             } else {
                                                                                                 assertEquals(0xAA, result); // Same for second byte in BIG_ENDIAN
                                                                                             }
                                                                                             
                                                                                             // Verify the stream was actually read from
                                                                                             verify(mockStream, times(2)).read();
                                                                                             
                                                                                             // Test partial read that requires new byte
                                                                                             when(mockStream.read()).thenReturn(0xFF);
                                                                                             result = bis.readBits(4);
                                                                                             if (order == ByteOrder.LITTLE_ENDIAN) {
                                                                                                 assertEquals(0x0F, result); // Lower 4 bits of 0xFF
                                                                                             } else {
                                                                                                 assertEquals(0x0F, result); // Same for BIG_ENDIAN in this case
                                                                                             }
                                                                                         }
                                                                                     }

 @Test
                                                                                   public void testReadBitsWithZeroByteShouldProcessNotReturn() throws IOException {
                                                                                       // Setup mock InputStream to return a zero byte
                                                                                       InputStream mockIn = mock(InputStream.class);
                                                                                       when(mockIn.read()).thenReturn(0);
                                                                                       
                                                                                       // Create BitInputStream with mock and BIG_ENDIAN (order doesn't matter for this test)
                                                                                       BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                                       
                                                                                       // Clear initial cache state using public method
                                                                                       bis.clearBitCache();
                                                                                       
                                                                                       // Call readBits - should process the zero byte, not return it
                                                                                       long result = bis.readBits(8);
                                                                                       
                                                                                       // Verify the zero byte was processed (result should be 0)
                                                                                       assertEquals(0L, result);
                                                                                       // Verify the stream was read from (wouldn't be called if mutant returned early)
                                                                                       verify(mockIn).read();
                                                                                       
                                                                                       // For thoroughness, also test with LITTLE_ENDIAN
                                                                                       bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                       bis.clearBitCache();
                                                                                       result = bis.readBits(8);
                                                                                       assertEquals(0L, result);
                                                                                       verify(mockIn, times(2)).read();
                                                                                   }

 @Test
                                                                               public void testReadBitsWithOverflowHandling_DetectsOverflowInitializationMutant() throws Exception {
                                                                                   // Setup mock input stream to return specific bytes
                                                                                   InputStream mockIn = mock(InputStream.class);
                                                                                   when(mockIn.read())
                                                                                       .thenReturn(0xFF)  // First byte (all bits set)
                                                                                       .thenReturn(0x00); // Second byte (no bits set)
                                                                                   
                                                                                   // Create BitInputStream with big-endian order
                                                                                   BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                                   
                                                                                   // Set initial cache state to force overflow handling path
                                                                                   // We need bitsCachedSize < count (57) but also >= 57 would cause overflow
                                                                                   // So we'll set count to 58 which is > 57 (MAXIMUM_CACHE_SIZE?)
                                                                                   // and bitsCachedSize to 56 (so we enter the overflow handling path)
                                                                                   
                                                                                   // Use reflection to set private fields for testing
                                                                                   Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                   bitsCachedField.setAccessible(true);
                                                                                   bitsCachedField.set(bis, 0L);  // Start with empty cache
                                                                                   
                                                                                   Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                   bitsCachedSizeField.setAccessible(true);
                                                                                   bitsCachedSizeField.set(bis, 56);  // Almost full cache
                                                                                   
                                                                                   // Call method - requesting 58 bits which will trigger overflow handling
                                                                                   long result = bis.readBits(58);
                                                                                   
                                                                                   // Verify the result and internal state
                                                                                   // Original code would have bitsCached = 0 after processing
                                                                                   // Mutant would have bitsCached = 1
                                                                                   assertEquals(0L, bitsCachedField.get(bis));
                                                                                   
                                                                                   // Also verify the returned bits
                                                                                   // First byte (0xFF) shifted left 56 bits, plus 2 bits from second byte (00)
                                                                                   // For BIG_ENDIAN, we expect:
                                                                                   // (0xFF << 56) | (0x00 >>> 6) [taking top 2 bits of second byte]
                                                                                   long expected = (0xFFL << 56) | 0x00L;
                                                                                   assertEquals(expected, result);
                                                                                   
                                                                                   // Verify bitsCachedSize is properly updated
                                                                                   assertEquals(6, bitsCachedSizeField.get(bis));  // 8 - 2 bits used = 6 remaining
                                                                               }

 @Test
                                                                             public void testReadBitsDetectsOverflowBitsMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                 // Setup - create a mock input stream that will return specific bytes
                                                                                 InputStream mockIn = mock(InputStream.class);
                                                                                 when(mockIn.read())
                                                                                     .thenReturn(0xFF)  // First byte (all bits set)
                                                                                     .thenReturn(0xAA);  // Second byte (10101010 pattern)
                                                                                 
                                                                                 // Create BitInputStream with little-endian order to test the mutation
                                                                                 BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                 
                                                                                 // Clear any initial cache
                                                                                 bis.clearBitCache();
                                                                                 
                                                                                 // Test case designed to trigger the overflow path:
                                                                                 // - First read 56 bits (7 bytes) to nearly fill the cache (bitsCachedSize=56)
                                                                                 // - Then read 8 more bits which will trigger the overflow path with bitsToAddCount=1
                                                                                 // This will make overflowBits calculation critical (should be 7, mutant would make it 6)
                                                                                 
                                                                                 // First read 56 bits (7 bytes)
                                                                                 for (int i = 0; i < 7; i++) {
                                                                                     bis.readBits(8);
                                                                                 }
                                                                                 
                                                                                 // Now read 8 more bits - this will trigger the overflow path
                                                                                 // With original code: bitsToAddCount=1, overflowBits=7
                                                                                 // With mutant: bitsToAddCount=1, overflowBits=6
                                                                                 long result = bis.readBits(8);
                                                                                 
                                                                                 // Verify the result - with correct overflowBits calculation, the result should be:
                                                                                 // - First bit from second byte (0xAA) is 0 (rightmost bit in little-endian)
                                                                                 // - Remaining 7 bits should be from the first byte's overflow (all 1s)
                                                                                 assertEquals(0b11111110L, result);
                                                                                 
                                                                                 // Use reflection to access private fields for verification
                                                                                 Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                 bitsCachedSizeField.setAccessible(true);
                                                                                 int bitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                                 
                                                                                 Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                 bitsCachedField.setAccessible(true);
                                                                                 long bitsCached = bitsCachedField.getLong(bis);
                                                                                 
                                                                                 // Verify the remaining cache - should contain the remaining 7 bits of 0xAA
                                                                                 // With correct overflowBits=7, these would be bits [7:1] of 0xAA (1010101)
                                                                                 // With mutant overflowBits=6, it would incorrectly capture bits [6:0]
                                                                                 assertEquals(7, bitsCachedSize);
                                                                                 assertEquals(0b1010101L, bitsCached);
                                                                             }

 @Test
                                                                         public void testReadBits_LittleEndian_OverflowBits_DetectsMaskMutation() throws Exception {
                                                                             // Setup
                                                                             InputStream mockInput = mock(InputStream.class);
                                                                             when(mockInput.read()).thenReturn(0b10101010); // test byte with alternating bits
                                                                             
                                                                             BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                             
                                                                             // Set up internal state to trigger overflow path
                                                                             // We need bitsCachedSize < count and bitsCachedSize >= 57
                                                                             // Let's set count to 60 (needing 3 more bits than cached)
                                                                             // and bitsCachedSize to 57 (so we need 3 more bits)
                                                                             
                                                                             // Using reflection to set private fields since we need specific internal state
                                                                             Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                             bitsCachedField.setAccessible(true);
                                                                             bitsCachedField.set(bis, 0L); // clear cache
                                                                             
                                                                             Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                             bitsCachedSizeField.setAccessible(true);
                                                                             bitsCachedSizeField.set(bis, 57); // set to trigger overflow path
                                                                             
                                                                             // MASKS[3] should be 0b111 (7)
                                                                             // For original code: 0b10101010 & 0b111 = 0b010 (2)
                                                                             // For mutant code: 0b10101010 | 0b111 = 0b10101111 (175)
                                                                             
                                                                             // Execute
                                                                             long result = bis.readBits(60);
                                                                             
                                                                             // Verify
                                                                             // The correct output should only contain the first 3 bits (010)
                                                                             // If mutant is present, it would include extra bits
                                                                             assertEquals(2L, result);
                                                                             
                                                                             // Verify the remaining bits were properly handled
                                                                             long remainingBits = (Long)bitsCachedField.get(bis);
                                                                             assertEquals(0b10101L, remainingBits); // remaining 5 bits (10101)
                                                                         }

 @Test
                                                                       public void testReadBitsDetectsOrEqualsMutant_LittleEndianWithOverflow() throws Exception {
                                                                           // Setup mock input stream to return specific bytes
                                                                           InputStream mockIn = mock(InputStream.class);
                                                                           when(mockIn.read())
                                                                               .thenReturn(0xFF)  // First byte (will be shifted out)
                                                                               .thenReturn(0xAA); // Second byte (will be partially used)
                                                                           
                                                                           // Create BitInputStream with little endian order
                                                                           BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                           
                                                                           // Set up initial cache state with existing bits
                                                                           // We need bitsCachedSize >= 57 to trigger the overflow path
                                                                           // Using reflection to set private fields for testing
                                                                           Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                           bitsCachedField.setAccessible(true);
                                                                           bitsCachedField.set(bis, 0x123456789ABCDEFL); // Some existing bits
                                                                           
                                                                           Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                           bitsCachedSizeField.setAccessible(true);
                                                                           bitsCachedSizeField.set(bis, 57); // Just at the overflow threshold
                                                                           
                                                                           // Test reading 8 bits (count=8) which will trigger overflow handling
                                                                           long result = bis.readBits(8);
                                                                           
                                                                           // Verify the result contains the correct bits
                                                                           // The original code would preserve the existing bits, while the mutant would overwrite them
                                                                           // We expect the existing bits (0x123456789ABCDE) to be preserved with new bits (0xAA) added
                                                                           // For 8 bits, the mask is always 0xFF
                                                                           assertNotEquals("Result should not just be the new bits (mutant behavior)", 
                                                                                          0xAA & 0xFF, result);
                                                                           
                                                                           // Verify the remaining cache contains the overflow bits
                                                                           long remainingCache = (Long)bitsCachedField.get(bis);
                                                                           int remainingSize = (Integer)bitsCachedSizeField.get(bis);
                                                                           assertEquals(8 - (64 - 57), remainingSize); // Verify overflow bits count
                                                                       }

 @Test
                                                                  public void testReadBitsDetectsUnsignedShiftMutant2() throws Exception {
                                                                      // Setup
                                                                      InputStream mockInput = mock(InputStream.class);
                                                                      when(mockInput.read())
                                                                          .thenReturn(0xFF)  // -1 in signed byte, 255 in unsigned
                                                                          .thenReturn(-1);    // EOF
                                                                      
                                                                      BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                      
                                                                      // Set up internal state to trigger overflow path
                                                                      // We need bitsCachedSize < count and bitsCachedSize >= 57
                                                                      // Let's set count to 58 (needing 58 bits when we have less than that cached)
                                                                      // and make sure we have some bits cached (but less than 58)
                                                                      Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                      bitsCachedSizeField.setAccessible(true);
                                                                      bitsCachedSizeField.set(bis, 56);  // Just below 57
                                                                      
                                                                      Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                      bitsCachedField.setAccessible(true);
                                                                      bitsCachedField.set(bis, 0L);      // Clear cache
                                                                      
                                                                      // The key is that when we read 0xFF (which is -1 as signed byte),
                                                                      // the unsigned shift (>>>) vs signed shift (>>) will produce different results
                                                                      // for the overflow calculation
                                                                      
                                                                      // Execute
                                                                      long result = bis.readBits(58);
                                                                      
                                                                      // Verify - the mutant would calculate overflow differently
                                                                      // Original would do: overflow = (0xFF >>> 2) & MASKS[6] = 63 & 0x3F = 63
                                                                      // Mutant would do: overflow = (0xFF >> 2) & MASKS[6] = -1 & 0x3F = 63
                                                                      // Wait, same result in this case - need different test value
                                                                      
                                                                      // Let's adjust the test to use a different value that shows the difference
                                                                      reset(mockInput);
                                                                      when(mockInput.read())
                                                                          .thenReturn(0x80)  // -128 in signed byte, 128 in unsigned
                                                                          .thenReturn(-1);   // EOF
                                                                      
                                                                      bitsCachedSizeField.set(bis, 56);
                                                                      bitsCachedField.set(bis, 0L);
                                                                      
                                                                      result = bis.readBits(58);
                                                                      
                                                                      // Now:
                                                                      // bitsToAddCount = 58 - 56 = 2
                                                                      // overflowBits = 8 - 2 = 6
                                                                      // Original: overflow = (0x80 >>> 2) & MASKS[6] = 32 & 0x3F = 32
                                                                      // Mutant: overflow = (0x80 >> 2) & MASKS[6] = -32 & 0x3F = 32
                                                                      // Still same - need to look at the final bitsOut
                                                                      
                                                                      // The real difference comes when we use the overflow in subsequent operations
                                                                      // Let's test with two reads where the overflow is preserved
                                                                      
                                                                      reset(mockInput);
                                                                      when(mockInput.read())
                                                                          .thenReturn(0x80)  // First read for overflow
                                                                          .thenReturn(0x00)  // Second read for normal bits
                                                                          .thenReturn(-1);    // EOF
                                                                      
                                                                      bitsCachedSizeField.set(bis, 0);
                                                                      bitsCachedField.set(bis, 0L);
                                                                      
                                                                      // First read - should store overflow
                                                                      bis.readBits(58);
                                                                      
                                                                      // Second read - should use the overflow
                                                                      long finalResult = bis.readBits(6);
                                                                      
                                                                      // Original would have overflow = 32 (from unsigned shift)
                                                                      // Mutant would have overflow = -32 (but masked to 32)
                                                                      // The difference would appear in the final bitsOut
                                                                      assertEquals(32, finalResult);
                                                                  }

 @Test
                                                             public void testReadBits_DetectsShiftMutantInBigEndianOverflow() throws Exception {
                                                                 // Setup - create a BitInputStream with big-endian byte order
                                                                 InputStream mockInput = mock(InputStream.class);
                                                                 when(mockInput.read())
                                                                     .thenReturn(0xFF)  // first byte (will be shifted)
                                                                     .thenReturn(0xAA); // second byte (overflow byte)
                                                                 
                                                                 BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                                                 
                                                                 // Helper method to set private field using reflection
                                                                 Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                 bitsCachedSizeField.setAccessible(true);
                                                                 bitsCachedSizeField.set(bis, 57);
                                                                 
                                                                 Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                 bitsCachedField.setAccessible(true);
                                                                 bitsCachedField.set(bis, 0x123456789ABCDEFL); // some existing bits
                                                                 
                                                                 // We'll request 8 bits (count=8) when we have 57 cached
                                                                 // This will trigger the overflow path where the mutant exists
                                                                 // bitsToAddCount will be 8 - (64-57) = 1
                                                                 // Original code: shifts left by 1, mutant shifts left by 2
                                                                 
                                                                 // Calculate expected value:
                                                                 // Original behavior:
                                                                 // 1. bitsCached (0x123456789ABCDEF) << 1 = 0x2468ACF13579BDE
                                                                 // 2. Add bits from nextByte (0xAA >>> (8-1)) & MASK[1] = (0xAA >>> 7) & 0x1 = 1
                                                                 // 3. Final output is (bitsCached >> (57-8)) & MASK[8] = (0x2468ACF13579BDE >> 49) & 0xFF
                                                                 //    = 0x12 & 0xFF = 0x12
                                                                 
                                                                 // Mutant behavior would shift left by 2 instead of 1, changing the result
                                                                 
                                                                 long result = bis.readBits(8);
                                                                 
                                                                 // Verify the result matches exactly what we expect
                                                                 assertEquals(0x12L, result);
                                                                 
                                                                 // Verify the remaining cache state
                                                                 assertEquals(49, bitsCachedSizeField.get(bis));
                                                                 assertEquals(0x68ACF13579BDEFL, bitsCachedField.get(bis));
                                                             }

 @Test
                                                        public void testReadBitsDetectsUnsignedShiftMutant3() throws Exception {
                                                            // Setup - create a mock input stream that returns a byte with high bit set
                                                            InputStream mockIn = mock(InputStream.class);
                                                            when(mockIn.read())
                                                                .thenReturn(0x00)  // first byte (bits 0-7)
                                                                .thenReturn(0x80); // second byte with high bit set (value -128)
                                                            
                                                            // Create BitInputStream with BIG_ENDIAN order
                                                            BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                            
                                                            // Use reflection to set private fields
                                                            Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                            bitsCachedField.setAccessible(true);
                                                            bitsCachedField.set(bis, 0x00L);
                                                            
                                                            Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                            bitsCachedSizeField.setAccessible(true);
                                                            bitsCachedSizeField.set(bis, 56); // 7 bytes cached, need more
                                                            
                                                            // Try to read 57 bits - this will trigger the overflow case
                                                            long result = bis.readBits(57);
                                                            
                                                            // Verify the result - with unsigned shift we should get 0x80 in the result
                                                            // With signed shift (mutant), we'd get a different value due to sign extension
                                                            assertEquals(0x80L, result & 0x80L);
                                                            
                                                            // Verify we read exactly two bytes
                                                            verify(mockIn, times(2)).read();
                                                        }

 @Test
                                                    public void testReadBitsDetectsBitwiseOrMutation1() throws Exception {
                                                        // Setup mock input stream that will return bytes in sequence
                                                        InputStream mockIn = mock(InputStream.class);
                                                        when(mockIn.read())
                                                            .thenReturn(0x12)  // First byte to be read into cache
                                                            .thenReturn(0x34); // Second byte for overflow case
                                                        
                                                        // Create BitInputStream with big-endian byte order
                                                        BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                        
                                                        // Set initial cache state (simulate some bits already in cache)
                                                        // Using reflection to access private fields for testing
                                                        Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                        bitsCachedField.setAccessible(true);
                                                        bitsCachedField.set(bis, 0x1L); // Existing bits in cache
                                                        
                                                        Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                        bitsCachedSizeField.setAccessible(true);
                                                        bitsCachedSizeField.set(bis, 4); // 4 bits already in cache
                                                        
                                                        // Test reading 12 bits (4 existing + need to read 8 more, triggering overflow case)
                                                        long result = bis.readBits(12);
                                                        
                                                        // Verify the result - should combine existing bits (0x1) with new bits (0x34)
                                                        // For big-endian, expected:
                                                        // Initial bits: 0x1 (4 bits)
                                                        // Read 0x34 (8 bits)
                                                        // Take first 8 bits of the 12 needed (0x1 shifted left 8) | (0x34 >>> 4)
                                                        long expected = ((0x1L << 8) | (0x34 >>> 4)) & 0xFFF; // Mask to 12 bits
                                                        assertEquals("Result should properly combine cached and new bits", expected, result);
                                                        
                                                        // Verify the mutation would fail here because:
                                                        // Original: (bitsCached |= bitsToAdd) would combine 0x100 with 0x3 = 0x103
                                                        // Mutant: (bitsCached = bitsToAdd) would just keep 0x3, losing the 0x100
                                                    }

 @Test
                                                   public void testReadBitsWithNegativeOverflowBits() throws Exception {
                                                       // Setup mock input stream
                                                       InputStream mockIn = mock(InputStream.class);
                                                       when(mockIn.read()).thenReturn(0xFF); // Return byte with all bits set
                                                       
                                                       // Create BitInputStream with little-endian order
                                                       BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                       
                                                       // Force negative overflowBits scenario:
                                                       // Set bitsCachedSize to 56 (just below 57 threshold)
                                                       // Request count of 65 (57 + 8) which will make bitsToAddCount = 65-57 = 8
                                                       // But in overflow calculation, overflowBits = 8 - bitsToAddCount = 0
                                                       // Then request another read that would make bitsToAddCount > 8
                                                       
                                                       // First setup some cached bits
                                                       bis.readBits(56); // This will fill cache to 56 bits
                                                       
                                                       // Now request more bits that would require overflow handling
                                                       // This should make overflowBits = 0 in first overflow handling
                                                       bis.readBits(57); 
                                                       
                                                       // Now request more bits to force negative overflowBits scenario
                                                       // Requesting 65 bits when we have 57 cached would make:
                                                       // bitsToAddCount = 65-57 = 8
                                                       // overflowBits = 8-8 = 0 (normal case)
                                                       // Then request another read that would make bitsToAddCount > 8
                                                       // This is impossible in normal operation since count is validated
                                                       
                                                       // Alternative approach: use reflection to directly set negative overflowBits
                                                       try {
                                                           // Use reflection to force negative overflowBits scenario
                                                           Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                           bitsCachedSizeField.setAccessible(true);
                                                           bitsCachedSizeField.set(bis, 57); // Set cached size to 57
                                                           
                                                           Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                           bitsCachedField.setAccessible(true);
                                                           bitsCachedField.set(bis, 0x123456789L); // Set some dummy cached value
                                                           
                                                           // Now read with count that would make overflowBits negative if the calculation was wrong
                                                           long result = bis.readBits(65);
                                                           
                                                           // Verify the result is correct (should use overflow branch, not ==0 branch)
                                                           // The exact assertion depends on the expected behavior, but we're mainly checking
                                                           // that the method doesn't throw exceptions or behave incorrectly
                                                           assertTrue("Method should handle potential negative overflowBits correctly", 
                                                                     result >= 0 || result == -1);
                                                       } catch (Exception e) {
                                                           fail("Should not throw exception with negative overflowBits scenario");
                                                       }
                                                   }

 @Test
                                                 public void testReadBits_DetectsUnsignedShiftMutant() throws Exception {
                                                     // Setup input stream to return bytes that will create a negative bitsCached value
                                                     InputStream mockIn = mock(InputStream.class);
                                                     when(mockIn.read())
                                                         .thenReturn(0xFF)  // first byte (all 1s)
                                                         .thenReturn(0x00); // second byte (to complete the read)
                                                     
                                                     // Create BitInputStream with little-endian order
                                                     BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                     
                                                     // Set up initial cache state with high bit set (negative value)
                                                     // We'll set bitsCached to 0x8000000000000000 (just high bit set)
                                                     // and bitsCachedSize to 64 (full long)
                                                     Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                     bitsCachedField.setAccessible(true);
                                                     bitsCachedField.set(bis, 0x8000000000000000L);
                                                     
                                                     Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                     bitsCachedSizeField.setAccessible(true);
                                                     bitsCachedSizeField.set(bis, 64);
                                                     
                                                     // Read 32 bits - this should use the >>>= operation in original code
                                                     long result = bis.readBits(32);
                                                     
                                                     // Verify the remaining bits in cache should be 0 (unsigned shift)
                                                     // With mutant's >>=, it would be 0x80000000 (sign extended)
                                                     long remainingBits = (long) bitsCachedField.get(bis);
                                                     assertEquals(0L, remainingBits);
                                                     
                                                     // Also verify the bits read
                                                     assertEquals(0x00000000L, result);
                                                 }

 @Test(expected = IllegalArgumentException.class)
                                            public void testReadBits_CountEqualsMaximumCacheSize_ShouldThrowException() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                // Arrange
                                                InputStream mockInputStream = mock(InputStream.class);
                                                BitInputStream bitInputStream = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                
                                                // Use reflection to get MAXIMUM_CACHE_SIZE value since it's private
                                                Field maxCacheSizeField = BitInputStream.class.getDeclaredField("MAXIMUM_CACHE_SIZE");
                                                maxCacheSizeField.setAccessible(true);
                                                int MAXIMUM_CACHE_SIZE = maxCacheSizeField.getInt(bitInputStream);
                                                
                                                // Act
                                                bitInputStream.readBits(MAXIMUM_CACHE_SIZE);
                                                
                                                // Assert - exception expected (handled by @Test annotation)
                                            }

 @Test
                                        public void testReadBitsDetectsReadByteMutation() throws Exception {
                                            // Setup mock InputStream that returns specific test data
                                            InputStream mockInput = mock(InputStream.class);
                                            when(mockInput.read())
                                                .thenReturn(0x12)  // First byte to read
                                                .thenReturn(0x34); // Second byte to read
                                            
                                            // Create BitInputStream with mock and BIG_ENDIAN order
                                            BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                            
                                            // First read 8 bits (should return first byte 0x12)
                                            long result1 = bis.readBits(8);
                                            assertEquals(0x12, result1);
                                            
                                            // Read another 8 bits (should return second byte 0x34)
                                            long result2 = bis.readBits(8);
                                            assertEquals(0x34, result2);
                                            
                                            // Verify mock interactions
                                            verify(mockInput, times(2)).read();
                                            
                                            // The mutant would return 0 for both reads because it replaces in.read() with 0
                                            // This test would fail on the mutant because:
                                            // - With mutant: result1 and result2 would be 0
                                            // - Original: returns actual bytes from stream (0x12 and 0x34)
                                        }

 @Test
                                           public void testReadBitsWithZeroByteShouldNotReturnEOF1() throws Exception {
                                               // Setup mock InputStream that returns a zero byte
                                               InputStream mockInput = mock(InputStream.class);
                                               when(mockInput.read())
                                                   .thenReturn(0)  // First byte is 0 (should not be treated as EOF)
                                                   .thenReturn(-1); // Then EOF
                                               
                                               // Create BitInputStream with little-endian order for simplicity
                                               BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                               
                                               // Try to read 8 bits (1 byte)
                                               long result = bis.readBits(8);
                                               
                                               // Verify we got the zero byte, not -1 (EOF)
                                               assertEquals(0L, result);
                                               
                                               // Verify we actually tried to read from the stream
                                               verify(mockInput, times(2)).read();
                                           }

 @Test
                                           public void testReadBitsWithZeroByteInCacheShouldProcessCorrectly() throws Exception {
                                               // Setup mock InputStream that returns sequence: 0, 1, -1
                                               InputStream mockInput = mock(InputStream.class);
                                               when(mockInput.read())
                                                   .thenReturn(0)   // First byte is 0
                                                   .thenReturn(1)   // Second byte is 1
                                                   .thenReturn(-1);  // Then EOF
                                               
                                               // Create BitInputStream with big-endian order
                                               BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                               
                                               // Read first 8 bits (should get 0)
                                               long firstByte = bis.readBits(8);
                                               assertEquals(0L, firstByte);
                                               
                                               // Read next 8 bits (should get 1, not -1)
                                               long secondByte = bis.readBits(8);
                                               assertEquals(1L, secondByte);
                                               
                                               // Next read should return -1 (real EOF)
                                               long eof = bis.readBits(8);
                                               assertEquals(-1L, eof);
                                           }

 @Test
                                     public void testReadBitsWithOverflowDetectsMutant1() throws Exception {
                                         // Setup mock InputStream to return specific bytes
                                         InputStream mockIn = mock(InputStream.class);
                                         when(mockIn.read())
                                             .thenReturn(0xFF)  // First byte (all 1s)
                                             .thenReturn(0xAA); // Second byte (10101010)
                                         
                                         // Create BitInputStream with little-endian order
                                         BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                         
                                         // Use reflection to set private fields for test setup
                                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                         bitsCachedField.setAccessible(true);
                                         bitsCachedField.setLong(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set to 1
                                         
                                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                         bitsCachedSizeField.setAccessible(true);
                                         bitsCachedSizeField.setInt(bis, 56);
                                         
                                         // Read 64 bits - this will trigger overflow handling
                                         long result = bis.readBits(64);
                                         
                                         // Verify the result - with original code (overflow=0), the lower 56 bits would be 1s
                                         // and upper 8 bits would be from the first byte (0xFF)
                                         // With mutant (overflow=1), the behavior would be different
                                         assertEquals(0xFFFFFFFFFFFFFFL, result & 0xFFFFFFFFFFFFFFL); // Check first 56 bits
                                         assertEquals(0xFFL, (result >>> 56) & 0xFFL); // Check last 8 bits
                                         
                                         // Verify cache state - should contain overflow bits (last 8 bits of second byte)
                                         assertEquals(8, bitsCachedSizeField.getInt(bis));
                                         assertEquals(0xAA, bitsCachedField.getLong(bis)); // With original code
                                     }

 @Test
                                public void testReadBitsWithOverflowDetectsMutant2() throws Exception {
                                    // Setup - create a mock input stream that will return specific bytes
                                    InputStream mockIn = mock(InputStream.class);
                                    when(mockIn.read())
                                        .thenReturn(0xFF)  // first byte read (all bits set)
                                        .thenReturn(0xFF); // second byte read (all bits set)
                                    
                                    // Initialize BitInputStream with little-endian order
                                    BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                    
                                    // Use reflection to access private fields
                                    Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                    bitsCachedField.setAccessible(true);
                                    Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                    bitsCachedSizeField.setAccessible(true);
                                    
                                    // Force the cache to be nearly full (56 bits)
                                    bitsCachedField.setLong(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set
                                    bitsCachedSizeField.setInt(bis, 56);
                                    
                                    // Try to read 57 bits - this will trigger the overflow path
                                    long result = bis.readBits(57);
                                    
                                    // Verify the result - with original code, this would be:
                                    // First 56 bits from cache + 1 bit from new byte (0xFF)
                                    // With mutant, the overflow calculation would be wrong
                                    assertEquals(0x1FFFFFFFFFFFFFFL, result);
                                    
                                    // Verify the remaining bits in cache should be 7 bits (0x7F)
                                    assertEquals(7, bitsCachedSizeField.getInt(bis));
                                    assertEquals(0x7FL, bitsCachedField.getLong(bis));
                                    
                                    // Verify the input stream was read from exactly twice
                                    verify(mockIn, times(2)).read();
                                }

 @Test
                            public void testReadBitsDetectsBitwiseOperatorMutant() throws Exception {
                                // Setup test with little-endian order and mock input stream
                                InputStream mockIn = mock(InputStream.class);
                                BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                
                                // Set up test scenario where:
                                // - We need to read more bits than currently cached (triggering overflow case)
                                // - The mask operation difference will be visible
                                when(mockIn.read())
                                    .thenReturn(0x0F)  // first byte (will be cached normally)
                                    .thenReturn(0xAA); // second byte (will trigger the mutated code)
                                
                                // First read some bits to populate the cache
                                bis.readBits(8); // reads first byte (0x0F)
                                
                                // Now read enough bits to trigger the overflow case where the mutation occurs
                                // We're reading 57 bits total (more than the 8 we have cached)
                                // The mask for 49 bits (57-8) will be applied to 0xAA
                                long result = bis.readBits(57);
                                
                                // Verify the result would be different between original and mutant:
                                // Original: 0x0F | ((0xAA & mask49) << 8)
                                // Mutant:   0x0F | ((0xAA | mask49) << 8)
                                // Since mask49 for 49 bits would be a very large number, OR-ing would produce
                                // a different result than AND-ing
                                long expectedForOriginal = 0x0FL | ((0xAAL & ((1L << 49) - 1)) << 8);
                                assertEquals("Test should detect bitwise operator mutation", 
                                            expectedForOriginal, result);
                                
                                // Verify we read exactly two bytes from the stream
                                verify(mockIn, times(2)).read();
                            }

 @Test
                          public void testReadBitsLittleEndianWithOverflowPreservesExistingBits() throws Exception {
                              // Setup mock input stream to return specific bytes
                              InputStream mockIn = mock(InputStream.class);
                              when(mockIn.read())
                                  .thenReturn(0xFF)  // first byte to fill initial cache
                                  .thenReturn(0xFF)  // second byte to fill initial cache
                                  .thenReturn(0xAA); // byte for overflow handling
                              
                              // Create BitInputStream with little-endian order
                              BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                              
                              // Use reflection to set up initial cache state (simulate having read some bits already)
                              // We need bitsCachedSize >= 57 to trigger overflow case
                              // Let's set it to 56 (7 full bytes) plus 1 bit = 57 bits
                              Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                              bitsCachedField.setAccessible(true);
                              bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set
                              
                              Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                              bitsCachedSizeField.setAccessible(true);
                              bitsCachedSizeField.set(bis, 57);
                              
                              // Request 64 bits (which will trigger overflow handling)
                              long result = bis.readBits(64);
                              
                              // Verify the result contains both the original bits and new bits
                              // Original bits should be preserved (0xFFFFFFFFFFFFFF) plus new bits (0xAA)
                              // In little-endian, new bits are shifted left by bitsCachedSize (57)
                              // But since we're testing the OR vs assignment, we just need to verify
                              // that the original bits weren't lost
                              assertTrue("Result should contain original cached bits", 
                                        (result & 0xFFFFFFFFFFFFFFL) != 0);
                              
                              // Additional verification for the exact expected value
                              // Expected: original bits (0xFFFFFFFFFFFFFF) OR (0xAA << 57)
                              long expected = 0xFFFFFFFFFFFFFFL | (0xAAL << 57);
                              assertEquals("Result should combine original and new bits", 
                                          expected, result);
                          }

 @Test
                     public void testReadBitsDetectsUnsignedShiftMutant4() throws Exception {
                         // Setup
                         InputStream mockInput = mock(InputStream.class);
                         BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                         
                         // Helper method to set private fields
                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                         bitsCachedSizeField.setAccessible(true);
                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                         bitsCachedField.setAccessible(true);
                         
                         // Set up initial cache state to trigger overflow branch
                         bitsCachedSizeField.set(bis, 56); // Just below 57
                         bitsCachedField.set(bis, 0L);
                         
                         // Mock input to return a negative byte (high bit set)
                         when(mockInput.read()).thenReturn(0b10000000); // -128 in byte
                         
                         // Test - request more bits than in cache to trigger overflow branch
                         long result = bis.readBits(64);
                         
                         // Verify overflow calculation used unsigned shift
                         // In original: (0b10000000 >>> 1) & MASKS[7] = 0b01000000 & 0x7F = 0x40
                         // In mutant: (0b10000000 >> 1) & MASKS[7] = 0b11000000 & 0x7F = 0x40
                         // Wait, this case doesn't show difference - need different shift amount
                         
                         // Better test case - shift by 7 bits
                         bitsCachedSizeField.set(bis, 57);
                         when(mockInput.read()).thenReturn(0b10000000); // -128 in byte
                         result = bis.readBits(64);
                         
                         // Original: (0b10000000 >>> 7) & MASKS[1] = 0b00000001 & 0x1 = 1
                         // Mutant: (0b10000000 >> 7) & MASKS[1] = 0b11111111 & 0x1 = 1
                         // Still same... need different approach
                         
                         // Alternative approach - test with byte that has bits in both parts
                         bitsCachedSizeField.set(bis, 60); // Need 4 more bits
                         when(mockInput.read()).thenReturn(0b10101010); // -86 in byte
                         result = bis.readBits(64);
                         
                         // Original: (0b10101010 >>> 4) & MASKS[4] = 0b00001010 & 0xF = 0xA
                         // Mutant: (0b10101010 >> 4) & MASKS[4] = 0b11111010 & 0xF = 0xA
                         // Still same... seems this mutation is hard to catch
                         
                         // Final approach - use maximum shift (7 bits) with specific value
                         bitsCachedSizeField.set(bis, 57);
                         when(mockInput.read()).thenReturn(0b11000000); // -64 in byte
                         result = bis.readBits(64);
                         
                         // Original: (0b11000000 >>> 7) & MASKS[1] = 0b00000001 & 0x1 = 1
                         // Mutant: (0b11000000 >> 7) & MASKS[1] = 0b11111111 & 0x1 = 1
                         // Still same... seems this particular mutation might not be detectable through output
                         
                         // Conclusion: After careful analysis, this specific mutation (>>> to >>) 
                         // when masked with MASKS[overflowBits] produces identical results
                         // because the mask removes the sign-extended bits.
                         // Therefore, this mutant might be equivalent (not killable) in practice.
                     }

 @Test
                public void testReadBitsDetectsShiftMutant1() throws IOException, NoSuchFieldException, IllegalAccessException {
                    // Setup - create a mock input stream that will return specific bytes
                    InputStream mockIn = mock(InputStream.class);
                    when(mockIn.read())
                        .thenReturn(0xFF)  // first byte (all 1s)
                        .thenReturn(0xAA); // second byte (10101010)
                    
                    // Create BitInputStream with big-endian byte order
                    BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                    
                    // Set up initial cache state to force overflow path
                    // We'll request 60 bits (more than 57) to trigger the overflow handling
                    // First read will add 8 bits (from 0xFF), leaving us needing 52 more
                    // Second read will handle the overflow case where the mutation occurs
                    
                    // Call readBits - should read exactly 60 bits
                    long result = bis.readBits(60);
                    
                    // Verify the result - with the mutation, the bits would be shifted incorrectly
                    // Expected behavior:
                    // - First byte (0xFF) becomes high 8 bits
                    // - Second byte (0xAA) provides next 8 bits, but we only take 4 bits (since 60-56=4)
                    // - The correct result should be: 0xFFA (from first byte and top 4 bits of second)
                    // With mutation (extra shift), it would become 0xFF5 (incorrect)
                    assertEquals(0xFFAL, result);
                    
                    // Use reflection to access private fields for verification
                    Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                    bitsCachedSizeField.setAccessible(true);
                    int bitsCachedSize = bitsCachedSizeField.getInt(bis);
                    
                    Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                    bitsCachedField.setAccessible(true);
                    long bitsCached = bitsCachedField.getLong(bis);
                    
                    // Verify the remaining bits in cache should be the lower 4 bits of 0xAA (0xA)
                    // This is another way to detect the mutation
                    assertEquals(4, bitsCachedSize);
                    assertEquals(0xAL, bitsCached);
                    
                    // Verify the mock interactions
                    verify(mockIn, times(2)).read();
                }

 @Test
            public void testReadBitsDetectsUnsignedShiftMutant5() throws Exception {
                // Setup - create a mock input stream that returns a negative byte (high bit set)
                InputStream mockIn = mock(InputStream.class);
                when(mockIn.read()).thenReturn(0x80); // binary 10000000 (negative byte)
                
                // Create BitInputStream with big-endian byte order
                BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                
                // Set up internal state to trigger the overflow case
                // We need bitsCachedSize < count and bitsCachedSize >= 57
                // Let's set count to 58 (needing 58 bits when we have none cached)
                
                // Call readBits - this should go through the mutated code path
                long result = bis.readBits(58);
                
                // Verify the result - with unsigned shift we expect:
                // nextByte = 0x80 (10000000)
                // overflowBits = 8 - (58-56) = 6 (since we pretend we had 56 bits cached)
                // bitsToAddCount = 2
                // With unsigned shift: (0x80 >>> 6) & mask[2] = (0x02) & 0x3 = 0x2
                // With signed shift: (0x80 >> 6) & mask[2] = (0xFE) & 0x3 = 0x2
                // Wait - same result in this case, need different test value
                
                // Let's try a different test value that would show the difference
                reset(mockIn);
                when(mockIn.read()).thenReturn(0xFF); // binary 11111111
                bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                
                // Now test with count = 59 (bitsToAddCount = 3, overflowBits = 5)
                result = bis.readBits(59);
                
                // Expected behavior with unsigned shift:
                // (0xFF >>> 5) & mask[3] = (0x07) & 0x7 = 0x7
                // Mutated behavior with signed shift:
                // (0xFF >> 5) & mask[3] = (0xFFFFFFFFFFFFFFF) & 0x7 = 0x7
                // Still same... need to find a value where sign extension matters
                
                // Final approach - need to test with count that makes bitsToAddCount large enough
                // Let's try count = 60 (bitsToAddCount = 4, overflowBits = 4)
                reset(mockIn);
                when(mockIn.read()).thenReturn(0xF0); // binary 11110000
                bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                
                result = bis.readBits(60);
                
                // Original behavior (unsigned shift):
                // (0xF0 >>> 4) & mask[4] = (0x0F) & 0xF = 0xF
                // Mutated behavior (signed shift):
                // (0xF0 >> 4) & mask[4] = (0xFFFFFFFFFFFFFFF) & 0xF = 0xF
                // Still same... seems this mutant is hard to catch
                
                // After careful analysis, this particular mutant might not be detectable through
                // normal input/output testing because:
                // 1. The input comes from InputStream.read() which returns unsigned bytes (0-255)
                // 2. Even when cast to long, the high bits are 0
                // 3. The mask operation removes any sign-extended bits
                
                // Therefore, this mutant might be "equivalent" - it doesn't change behavior
                // with valid inputs. We would need to either:
                // 1. Modify the method to accept long values directly (not from InputStream)
                // 2. Find a way to inject negative values into the stream (which InputStream doesn't allow)
                
                // Conclusion: This mutant might not be detectable through normal testing
                // as it doesn't affect the observable behavior with valid inputs
                
                // However, if we could test with invalid input (negative bytes), we would do:
                // assertEquals(0xF, result); // This would catch if signed shift was used
                // But since we can't get negative bytes from InputStream.read(), we can't test this
                
                // Alternative approach - we need to modify the test to directly test the shift behavior
                // This would require refactoring the method to make the shift operation testable
                
                // Since we can't modify the production code, we must conclude this mutant is
                // either equivalent or undetectable with current method signature
            }

 @Test
          public void testReadBitsWithOverflowPreservesExistingCache_BigEndian() throws Exception {
              // Setup mock input stream to return test bytes
              InputStream mockIn = mock(InputStream.class);
              when(mockIn.read())
                  .thenReturn(0xFF)  // First byte (will be cached)
                  .thenReturn(0xAA); // Second byte (will cause overflow)
              
              // Create BitInputStream with big-endian order
              BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
              
              // Set up initial cache state (simulate previous reads) using reflection
              Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
              bitsCachedField.setAccessible(true);
              bitsCachedField.setLong(bis, 0x12345678L);
              
              Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
              bitsCachedSizeField.setAccessible(true);
              bitsCachedSizeField.setInt(bis, 32);
              
              // Read 40 bits (will need to read another byte with overflow)
              long result = bis.readBits(40);
              
              // Verify the result contains correct bits
              // First 8 bits should be from original cache (0x12)
              // Next 32 bits should be remaining cache (0x345678) + first 8 bits of new byte (0xAA)
              assertEquals(0x12345678AAL, result);
              
              // Verify cache state - should contain remaining 4 bits from second byte (0xA)
              // Original behavior would OR these bits with existing cache (if any)
              // Mutant would overwrite the cache completely
              assertEquals(4, bitsCachedSizeField.getInt(bis));
              assertEquals(0xAL, bitsCachedField.getLong(bis)); // Would fail if mutant is present (would be 0xA instead of 0xA | existing)
          }

 @Test
     public void testReadBitsDetectsOverflowBitsMutant() throws IOException, NoSuchFieldException, IllegalAccessException {
         // Setup - create a mock InputStream that will provide specific bytes
         InputStream mockInput = mock(InputStream.class);
         when(mockInput.read())
             .thenReturn(0xFF)  // first byte (all 1s)
             .thenReturn(0xFF); // second byte (all 1s)
         
         // Create BitInputStream with big-endian order
         BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
         
         // First read 56 bits to fill the cache (7 bytes)
         // This puts us in a state where bitsCachedSize is 56
         for (int i = 0; i < 7; i++) {
             bis.readBits(8);
         }
         
         // Now read 57 bits - this will trigger the overflow case
         // In original code, overflowBits should be 7 (8 - (57-56) = 7)
         // But we'll force a situation where bitsToAddCount > 8 to make overflowBits negative
         try {
             // This should throw an exception since count > MAXIMUM_CACHE_SIZE
             bis.readBits(65);
             fail("Should have thrown IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             // Expected
         }
         
         // Now test the actual case that would detect the mutant
         // Reset the mock and stream
         reset(mockInput);
         when(mockInput.read())
             .thenReturn(0xFF)  // first byte (all 1s)
             .thenReturn(0xFF); // second byte (all 1s)
         
         bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
         
         // Read 56 bits first
         for (int i = 0; i < 7; i++) {
             bis.readBits(8);
         }
         
         // Now read 57 bits - this will trigger the overflow case
         // The key is that with count=57 and bitsCachedSize=56:
         // bitsToAddCount = 57-56 = 1
         // overflowBits = 8-1 = 7 (positive)
         long result = bis.readBits(57);
         
         // Verify the result - this would be different if mutant was present
         // because with mutant, the overflowBits <= 0 condition would be false
         // and it would take the else branch
         assertEquals(0xFFFFFFFFFFFFFFL, result); // expected 56 bits + 1 bit = 57 bits of 1s
         
         // Verify the remaining bits in cache using reflection
         // Should be 7 bits left (from the second byte read)
         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
         bitsCachedSizeField.setAccessible(true);
         int bitsCachedSize = (int) bitsCachedSizeField.get(bis);
         assertEquals(7, bitsCachedSize);
         
         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
         bitsCachedField.setAccessible(true);
         long bitsCached = (long) bitsCachedField.get(bis);
         assertEquals(0x7FL, bitsCached); // 7 bits of 1s (01111111)
     }

 @Test
 public void testReadBitsDetectsUnsignedShiftMutant6() throws Exception {
     // Setup input stream to return bytes that will create a negative bitsCached
     InputStream mockIn = mock(InputStream.class);
     when(mockIn.read()).thenReturn(0xFF, 0x00); // First byte will make bitsCached negative
     
     BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
     
     // Set up internal state to trigger the specific code path
     // First read will populate bitsCached with 0xFF (negative in long)
     bis.readBits(8); // Reads first byte, now bitsCached = 0xFF (negative)
     
     // Now test reading some bits where overflowBits == 0
     // Original code would do unsigned shift, mutant does signed shift
     long result = bis.readBits(4); // Should read 4 bits and shift remaining 4
     
     // Verify the result is correct (first 4 bits of 0xFF)
     assertEquals(0x0F, result);
     
     // The key verification - check if remaining bits were shifted properly
     // Original: bitsCached >>>= 4 would leave 0x0F (unsigned shift)
     // Mutant: bitsCached >>= 4 would leave 0xFF...F0F (signed shift)
     // We can verify by reading remaining bits
     long remaining = bis.readBits(4);
     assertEquals(0x0F, remaining); // Should be 0x0F if unsigned shift was used
 }

}
