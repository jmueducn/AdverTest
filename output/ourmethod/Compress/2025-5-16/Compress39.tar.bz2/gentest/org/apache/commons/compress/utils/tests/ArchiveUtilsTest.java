package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ArchiveUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                          public void testSanitize_NormalString() {
                              String input = "HelloWorld123";
                              String result = ArchiveUtils.sanitize(input);
                              assertEquals("Normal string should remain unchanged", input, result);
                          }

 @Test
                          public void testSanitize_ControlCharacters() {
                              String input = "Hello\u0001World\u0002";
                              String result = ArchiveUtils.sanitize(input);
                              assertEquals("Control characters should be replaced", "Hello?World?", result);
                          }

 @Test
                          public void testSanitize_UnicodeSpecials() {
                              // Using some characters from Unicode SPECIALS block (U+FFF0-U+FFFF)
                              String input = "Normal\uFFF0Special\uFFF1Chars";
                              String result = ArchiveUtils.sanitize(input);
                              assertEquals("Unicode SPECIALS should be replaced", "Normal?Special?Chars", result);
                          }

 @Test
                          public void testSanitize_EmptyString() {
                              String input = "";
                              String result = ArchiveUtils.sanitize(input);
                              assertEquals("Empty string should remain empty", "", result);
                          }

 @Test
                          public void testSanitize_MixedCharacters() {
                              String input = "H\u0001el\uFFF2lo\u0003W\uFFF0orld";
                              String result = ArchiveUtils.sanitize(input);
                              assertEquals("Mixed characters should be properly sanitized", 
                                           "H?el?lo?W?orld", result);
                          }

 @Test
                          public void testSanitize_AllInvalidCharacters() {
                              String input = "\u0001\u0002\u0003\uFFF0\uFFF1\uFFF2";
                              String result = ArchiveUtils.sanitize(input);
                              assertEquals("All invalid chars should become ?", "??????", result);
                          }

 @Test
                  public void testSanitize_StringExceedingMaxLength() {
                      // Define the max length constant used by the tested method
                      final int MAX_SANITIZED_NAME_LENGTH = 255; // Assuming this is the value used in ArchiveUtils
                      
                      // Create a string longer than MAX_SANITIZED_NAME_LENGTH
                      StringBuilder longString = new StringBuilder();
                      for (int i = 0; i < MAX_SANITIZED_NAME_LENGTH + 10; i++) {
                          longString.append('a');
                      }
                      
                      String result = ArchiveUtils.sanitize(longString.toString());
                      assertEquals("String should be truncated to MAX length", MAX_SANITIZED_NAME_LENGTH, result.length());
                      
                      // Check the last 3 characters are dots
                      String lastThree = result.substring(MAX_SANITIZED_NAME_LENGTH - 3);
                      assertEquals("Last 3 chars should be dots", "...", lastThree);
                  }

 @Test
                  public void testSanitize_ExactMaxLength() {
                      // Create string of exactly MAX length (using test value of 255)
                      final int testMaxLength = 255;
                      StringBuilder exactLengthString = new StringBuilder();
                      for (int i = 0; i < testMaxLength; i++) {
                          exactLengthString.append('a');
                      }
                      
                      String result = ArchiveUtils.sanitize(exactLengthString.toString());
                      assertEquals("Exact length string should remain unchanged", 
                                   exactLengthString.toString(), result);
                  }

 @Test
                  public void testSanitize_NullInput() {
                      org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                      exceptionRule.expect(NullPointerException.class);
                      ArchiveUtils.sanitize(null);
                  }

 @Test
                  public void testSanitize_StringOneCharOverMaxLength() throws Exception {
                      // Get the private MAX_SANITIZED_NAME_LENGTH constant using reflection
                      Field maxLengthField = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
                      maxLengthField.setAccessible(true);
                      int maxLength = maxLengthField.getInt(null);
                      
                      // Create string of MAX+1 length
                      StringBuilder string = new StringBuilder();
                      for (int i = 0; i < maxLength + 1; i++) {
                          string.append('a');
                      }
                      
                      String result = ArchiveUtils.sanitize(string.toString());
                      assertEquals("String should be truncated to MAX length", maxLength, result.length());
                      
                      // Check the last 3 characters are dots
                      String lastThree = result.substring(maxLength - 3);
                      assertEquals("Last 3 chars should be dots", "...", lastThree);
                  }

 @Test
                  public void testIsArrayZero_ShouldDetectMutant() {
                      // Test case where only the element at index=size is non-zero
                      // This would pass original code but fail mutated code
                      byte[] arrayWithNonZeroAtSize = {0, 0, 0, 1};
                      boolean result = ArchiveUtils.isArrayZero(arrayWithNonZeroAtSize, 3);
                      assertTrue("Should return true as only first 3 elements are checked", result);
                      
                      // Test with size equal to array length to check for ArrayIndexOutOfBounds
                      try {
                          ArchiveUtils.isArrayZero(new byte[5], 5);
                      } catch (ArrayIndexOutOfBoundsException e) {
                          fail("Method should not throw ArrayIndexOutOfBoundsException");
                      }
                      
                      // Test with size=0 (boundary case)
                      assertTrue("Empty array check should return true", 
                          ArchiveUtils.isArrayZero(new byte[1], 0));
                  }

 @Test
                 public void testIsArrayZero_FirstElementNonZero() {
                     // This test will catch the mutant by having a non-zero first element
                     byte[] arrayWithNonZeroFirst = {1, 0, 0, 0}; // First element is non-zero
                     int size = arrayWithNonZeroFirst.length;
                     
                     // Original should return false, mutant will skip first element and return true
                     assertFalse("Should return false when first element is non-zero", 
                                ArchiveUtils.isArrayZero(arrayWithNonZeroFirst, size));
                 }

 @Test
                 public void testIsArrayZero_AllZeros() {
                     // Test case where all elements are zero
                     byte[] allZeros = {0, 0, 0, 0};
                     int size = allZeros.length;
                     
                     // Both original and mutant should return true
                     assertTrue("Should return true when all elements are zero",
                               ArchiveUtils.isArrayZero(allZeros, size));
                 }

 @Test
                 public void testIsArrayZero_NonZeroInMiddle() {
                     // Test case where non-zero is not the first element
                     byte[] nonZeroInMiddle = {0, 0, 1, 0};
                     int size = nonZeroInMiddle.length;
                     
                     // Both original and mutant should return false
                     assertFalse("Should return false when any element is non-zero",
                                ArchiveUtils.isArrayZero(nonZeroInMiddle, size));
                 }

 @Test
                 public void testIsArrayZero_EmptyArray() {
                     // Edge case: empty array
                     byte[] emptyArray = {};
                     int size = 0;
                     
                     // Both original and mutant should return true
                     assertTrue("Should return true for empty array",
                               ArchiveUtils.isArrayZero(emptyArray, size));
                 }

 @Test
                public void testIsArrayZeroWithMixedValuesShouldReturnFalse() {
                    // This test will catch the mutant
                    byte[] mixedArray = {0, 1, 0, 0}; // Contains both zero and non-zero values
                    boolean result = ArchiveUtils.isArrayZero(mixedArray, mixedArray.length);
                    assertFalse("Should return false for array with non-zero values", result);
                }

 @Test
                public void testIsArrayZeroWithAllZerosShouldReturnTrue() {
                    byte[] allZeros = {0, 0, 0, 0};
                    boolean result = ArchiveUtils.isArrayZero(allZeros, allZeros.length);
                    assertTrue("Should return true for all-zero array", result);
                }

 @Test
                public void testIsArrayZeroWithAllNonZerosShouldReturnFalse() {
                    byte[] allNonZeros = {1, 2, 3, 4};
                    boolean result = ArchiveUtils.isArrayZero(allNonZeros, allNonZeros.length);
                    assertFalse("Should return false for all-non-zero array", result);
                }

 @Test
                public void testIsArrayZeroWithEmptyArrayShouldReturnTrue() {
                    byte[] emptyArray = {};
                    boolean result = ArchiveUtils.isArrayZero(emptyArray, 0);
                    assertTrue("Should return true for empty array", result);
                }

 @Test
                public void testIsArrayZeroWithPartialArrayCheck() {
                    byte[] array = {0, 0, 1, 0};
                    boolean result = ArchiveUtils.isArrayZero(array, 2); // Only check first 2 elements
                    assertTrue("Should return true when checking only zero elements", result);
                }

 @Test
               public void testIsArrayZeroWithNegativeValues() {
                   // Create an array with negative values
                   byte[] arrayWithNegatives = new byte[]{0, 0, -1, 0};
                   int size = arrayWithNegatives.length;
                   
                   // Original method should return false (since -1 != 0)
                   // Mutated method would return true (since -1 is not > 0)
                   assertFalse("Should return false for arrays containing negative values", 
                              ArchiveUtils.isArrayZero(arrayWithNegatives, size));
               }

 @Test
               public void testIsArrayZeroWithAllZeros() {
                   byte[] allZeros = new byte[]{0, 0, 0, 0};
                   int size = allZeros.length;
                   assertTrue("Should return true for all-zero arrays",
                             ArchiveUtils.isArrayZero(allZeros, size));
               }

 @Test
               public void testIsArrayZeroWithPositiveValues() {
                   byte[] arrayWithPositives = new byte[]{0, 1, 0, 0};
                   int size = arrayWithPositives.length;
                   assertFalse("Should return false for arrays containing positive values",
                              ArchiveUtils.isArrayZero(arrayWithPositives, size));
               }

 @Test
              public void testIsArrayZero_NonZeroElementAtBeginning() {
                  byte[] array = {1, 0, 0, 0};
                  boolean result = ArchiveUtils.isArrayZero(array, array.length);
                  assertFalse("Should return false when array contains non-zero element at beginning", result);
              }

 @Test
              public void testIsArrayZero_NonZeroElementAtMiddle() {
                  byte[] array = {0, 0, 1, 0, 0};
                  boolean result = ArchiveUtils.isArrayZero(array, array.length);
                  assertFalse("Should return false when array contains non-zero element in middle", result);
              }

 @Test
              public void testIsArrayZero_NonZeroElementAtEnd() {
                  byte[] array = {0, 0, 0, 1};
                  boolean result = ArchiveUtils.isArrayZero(array, array.length);
                  assertFalse("Should return false when array contains non-zero element at end", result);
              }

 @Test
              public void testIsArrayZero_AllZeroElements() {
                  byte[] array = {0, 0, 0, 0};
                  boolean result = ArchiveUtils.isArrayZero(array, array.length);
                  assertTrue("Should return true when all elements are zero", result);
              }

 @Test
              public void testIsArrayZero_EmptyArray1() {
                  byte[] array = {};
                  boolean result = ArchiveUtils.isArrayZero(array, array.length);
                  assertTrue("Should return true for empty array", result);
              }

 @Test
         public void testIsArrayZero_AllZeros_ShouldReturnTrue() {
             // Arrange
             byte[] zeroArray = new byte[]{0, 0, 0, 0, 0};
             int size = zeroArray.length;
             
             // Act
             boolean result = ArchiveUtils.isArrayZero(zeroArray, size);
             
             // Assert
             assertTrue("Method should return true for all-zero array", result);
         }

 @Test
       public void testSanitizeWithLengthEqualToMax() {
           // Setup
           try {
               // Get the original MAX_SANITIZED_NAME_LENGTH value using reflection
               Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
               field.setAccessible(true);
               
               // Remove final modifier if present
               Field modifiersField = Field.class.getDeclaredField("modifiers");
               modifiersField.setAccessible(true);
               modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
               
               int originalMaxLength = field.getInt(null);
               
               try {
                   // Set a small MAX_SANITIZED_NAME_LENGTH for testing
                   field.set(null, 5);
                   
                   // Create input string with exact max length
                   String input = "12345"; // length = 5 = MAX_SANITIZED_NAME_LENGTH
                   
                   // Test
                   String result = ArchiveUtils.sanitize(input);
                   
                   // Verify - original should be used (not a copy) in original code
                   // The mutant would make a copy instead
                   char[] originalChars = input.toCharArray();
                   char[] resultChars = result.toCharArray();
                   
                   // In original code, they should be the same array (== comparison)
                   // In mutated code, they would be different arrays
                   assertTrue("Should use original array when length equals MAX_SANITIZED_NAME_LENGTH",
                             originalChars == resultChars || Arrays.equals(originalChars, resultChars));
               } finally {
                   // Reset MAX_SANITIZED_NAME_LENGTH to original value
                   field.set(null, originalMaxLength);
               }
           } catch (Exception e) {
               fail("Exception during test: " + e.getMessage());
           }
       }

 @Test
       public void testIsArrayZero_EmptyArray2() {
           byte[] emptyArray = new byte[0];
           assertTrue(ArchiveUtils.isArrayZero(emptyArray, 0));
       }

 @Test
       public void testIsArrayZero_AllZeros1() {
           byte[] allZeros = new byte[]{0, 0, 0, 0};
           assertTrue(ArchiveUtils.isArrayZero(allZeros, 4));
       }

 @Test
       public void testIsArrayZero_NonZeroElementAtStart() {
           byte[] array = new byte[]{1, 0, 0, 0};
           assertFalse(ArchiveUtils.isArrayZero(array, 4));
       }

 @Test
       public void testIsArrayZero_NonZeroElementAtEnd1() {
           byte[] array = new byte[]{0, 0, 0, 1};
           assertFalse(ArchiveUtils.isArrayZero(array, 4));
       }

 @Test
       public void testIsArrayZero_NonZeroElementInMiddle() {
           byte[] array = new byte[]{0, 0, 1, 0};
           assertFalse(ArchiveUtils.isArrayZero(array, 4));
       }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
       public void testIsArrayZero_SizeLargerThanArray() {
           byte[] array = new byte[]{0, 0, 0, 0};
           ArchiveUtils.isArrayZero(array, 5);
       }

 @Test
       public void testIsArrayZero_PartialCheck() {
           byte[] array = new byte[]{0, 0, 1, 0};
           assertTrue(ArchiveUtils.isArrayZero(array, 2));
       }

 @Test
      public void testIsArrayZero_AllZeros2() {
          byte[] array = {0, 0, 0, 0};
          assertTrue(ArchiveUtils.isArrayZero(array, array.length));
      }

 @Test
      public void testIsArrayZero_NonZeroElement() {
          byte[] array = {0, 0, 1, 0};
          assertFalse(ArchiveUtils.isArrayZero(array, array.length));
      }

 @Test
      public void testIsArrayZero_FirstElementNonZero1() {
          byte[] array = {1, 0, 0, 0};
          assertFalse(ArchiveUtils.isArrayZero(array, array.length));
      }

 @Test
      public void testIsArrayZero_LastElementNonZero() {
          byte[] array = {0, 0, 0, 1};
          assertFalse(ArchiveUtils.isArrayZero(array, array.length));
      }

 @Test
      public void testIsArrayZero_EmptyArray3() {
          byte[] array = {};
          assertTrue(ArchiveUtils.isArrayZero(array, 0));
      }

 @Test
      public void testIsArrayZero_SizeZero() {
          byte[] array = {1, 2, 3};
          assertTrue(ArchiveUtils.isArrayZero(array, 0));
      }

 @Test
      public void testIsArrayZero_PartialCheckWithZero() {
          byte[] array = {0, 0, 1, 0};
          assertTrue(ArchiveUtils.isArrayZero(array, 2));
      }

 @Test
      public void testIsArrayZero_PartialCheckWithNonZero() {
          byte[] array = {0, 1, 0, 0};
          assertFalse(ArchiveUtils.isArrayZero(array, 2));
      }

 @Test
 public void testIsArrayZero_DetectsMutantInPartialCheck() {
     // Setup - create an array where the 4th last element is non-zero
     // Assuming MAX_SANITIZED_NAME_LENGTH is large enough (let's say 10 for this test)
     byte[] testArray = new byte[10];
     testArray[6] = 1;  // 4th last element (index 6 for length 10)
     
     // Test with size equal to MAX_SANITIZED_NAME_LENGTH
     // This should return false since there's a non-zero element
     boolean result = ArchiveUtils.isArrayZero(testArray, 10);
     
     // Assert - should be false because of the non-zero element
     assertFalse("Method should detect non-zero element in checked range", result);
     
     // Additional test case where non-zero is outside original check range
     byte[] testArray2 = new byte[10];
     testArray2[3] = 1;  // 7th last element (would be outside mutated check range)
     
     // This should return false for both original and mutant
     boolean result2 = ArchiveUtils.isArrayZero(testArray2, 10);
     assertFalse("Method should detect any non-zero element", result2);
 }

}
