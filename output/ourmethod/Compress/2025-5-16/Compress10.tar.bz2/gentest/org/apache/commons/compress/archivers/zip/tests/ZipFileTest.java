package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipException;
 
public class ZipFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                        public void testResolveLocalFileHeaderData_MultipleEntries() throws Exception {
                                                                                                                                                            // Define OffsetEntry inner class
                                                                                                                                                            class OffsetEntry {
                                                                                                                                                                long headerOffset;
                                                                                                                                                                long dataOffset;
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Define NameAndComment inner class
                                                                                                                                                            class NameAndComment {
                                                                                                                                                                String name;
                                                                                                                                                                byte[] comment;
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Setup test data
                                                                                                                                                            Map<ZipArchiveEntry, OffsetEntry> entries = new HashMap<>();
                                                                                                                                                            Map<ZipArchiveEntry, NameAndComment> entriesWithoutUTF8Flag = new HashMap<>();
                                                                                                                                                            
                                                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("file1.txt");
                                                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("file2.txt");
                                                                                                                                                            OffsetEntry offset1 = new OffsetEntry();
                                                                                                                                                            OffsetEntry offset2 = new OffsetEntry();
                                                                                                                                                            offset1.headerOffset = 100L;
                                                                                                                                                            offset2.headerOffset = 200L;
                                                                                                                                                            entries.put(entry1, offset1);
                                                                                                                                                            entries.put(entry2, offset2);
                                                                                                                                                            
                                                                                                                                                            // Mock archive
                                                                                                                                                            RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                                                                                                                                                            doAnswer(invocation -> {
                                                                                                                                                                byte[] b = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                // Simulate reading filename length (8) and extra field length (0)
                                                                                                                                                                if (b.length == 2) {
                                                                                                                                                                    b[0] = 8;
                                                                                                                                                                    b[1] = 0;
                                                                                                                                                                }
                                                                                                                                                                return null;
                                                                                                                                                            }).when(mockArchive).readFully(any(byte[].class));
                                                                                                                                                            
                                                                                                                                                            when(mockArchive.skipBytes(anyInt())).thenReturn(8); // Skip filename
                                                                                                                                                            
                                                                                                                                                            doAnswer(invocation -> {
                                                                                                                                                                // Empty extra field
                                                                                                                                                                return null;
                                                                                                                                                            }).when(mockArchive).readFully(any(byte[].class));
                                                                                                                                                            
                                                                                                                                                            // Create ZipFile instance using reflection
                                                                                                                                                            ZipFile zipFile = new ZipFile(new File("test.zip"));
                                                                                                                                                            Field archiveField = ZipFile.class.getDeclaredField("archive");
                                                                                                                                                            archiveField.setAccessible(true);
                                                                                                                                                            archiveField.set(zipFile, mockArchive);
                                                                                                                                                            
                                                                                                                                                            Field entriesField = ZipFile.class.getDeclaredField("entries");
                                                                                                                                                            entriesField.setAccessible(true);
                                                                                                                                                            entriesField.set(zipFile, entries);
                                                                                                                                                            
                                                                                                                                                            // Get private constant via reflection
                                                                                                                                                            Field lfhOffsetField = ZipFile.class.getDeclaredField("LFH_OFFSET_FOR_FILENAME_LENGTH");
                                                                                                                                                            lfhOffsetField.setAccessible(true);
                                                                                                                                                            long LFH_OFFSET_FOR_FILENAME_LENGTH = lfhOffsetField.getLong(zipFile);
                                                                                                                                                            
                                                                                                                                                            // Execute
                                                                                                                                                            Method method = ZipFile.class.getDeclaredMethod("resolveLocalFileHeaderData", Map.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            method.invoke(zipFile, entriesWithoutUTF8Flag);
                                                                                                                                                            
                                                                                                                                                            // Verify both entries were processed
                                                                                                                                                            assertEquals(2, entries.size());
                                                                                                                                                            assertTrue(entries.containsKey(entry1));
                                                                                                                                                            assertTrue(entries.containsKey(entry2));
                                                                                                                                                            assertEquals(100L + LFH_OFFSET_FOR_FILENAME_LENGTH + 2 + 2 + 8 + 0, 
                                                                                                                                                                        entries.get(entry1).dataOffset);
                                                                                                                                                            assertEquals(200L + LFH_OFFSET_FOR_FILENAME_LENGTH + 2 + 2 + 8 + 0, 
                                                                                                                                                                        entries.get(entry2).dataOffset);
                                                                                                                                                        }

    @Test
                                                                                                                                        public void testResolveLocalFileHeaderData_WithExtraFields() throws Exception {
                                                                                                                                            // Setup test data
                                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                            Map<ZipArchiveEntry, Object> entries = new HashMap<ZipArchiveEntry, Object>();
                                                                                                                                            Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<ZipArchiveEntry, Object>();
                                                                                                                                            
                                                                                                                                            // Create real ZipFile instance first
                                                                                                                                            File tempFile = File.createTempFile("test", ".zip");
                                                                                                                                            tempFile.deleteOnExit();
                                                                                                                                            ZipFile realZipFile = new ZipFile(tempFile);
                                                                                                                                            try {
                                                                                                                                                // Create OffsetEntry using reflection
                                                                                                                                                Class<?>[] declaredClasses = ZipFile.class.getDeclaredClasses();
                                                                                                                                                Class<?> offsetEntryClass = null;
                                                                                                                                                for (Class<?> clazz : declaredClasses) {
                                                                                                                                                    if (clazz.getSimpleName().equals("OffsetEntry")) {
                                                                                                                                                        offsetEntryClass = clazz;
                                                                                                                                                        break;
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                Constructor<?> constructor = offsetEntryClass.getDeclaredConstructor(ZipFile.class);
                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                Object offsetEntry = constructor.newInstance(realZipFile);
                                                                                                                                                
                                                                                                                                                Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
                                                                                                                                                headerOffsetField.setAccessible(true);
                                                                                                                                                headerOffsetField.set(offsetEntry, 100L);
                                                                                                                                                
                                                                                                                                                Field dataOffsetField = offsetEntryClass.getDeclaredField("dataOffset");
                                                                                                                                                dataOffsetField.setAccessible(true);
                                                                                                                                                dataOffsetField.set(offsetEntry, 0L);
                                                                                                                                                
                                                                                                                                                entries.put(entry, offsetEntry);
                                                                                                                                                
                                                                                                                                                // Get private constant using reflection
                                                                                                                                                Field lfhOffsetField = ZipFile.class.getDeclaredField("LFH_OFFSET_FOR_FILENAME_LENGTH");
                                                                                                                                                lfhOffsetField.setAccessible(true);
                                                                                                                                                long LFH_OFFSET_FOR_FILENAME_LENGTH = lfhOffsetField.getLong(null);
                                                                                                                                                
                                                                                                                                                // Mock archive
                                                                                                                                                RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                                                                                                                                                doAnswer(invocation -> {
                                                                                                                                                    byte[] b = (byte[]) invocation.getArguments()[0];
                                                                                                                                                    if (b.length == 4) {  // Changed from 2 to 4 to avoid array bounds
                                                                                                                                                        b[0] = 5;  // filename length
                                                                                                                                                        b[1] = 0;
                                                                                                                                                        b[2] = 10; // extra field length
                                                                                                                                                        b[3] = 0;
                                                                                                                                                    } else if (b.length > 2) {
                                                                                                                                                        Arrays.fill(b, (byte)1); // extra field data
                                                                                                                                                    }
                                                                                                                                                    return null;
                                                                                                                                                }).when(mockArchive).readFully(any(byte[].class));
                                                                                                                                                when(mockArchive.skipBytes(anyInt())).thenReturn(5); // Skip filename
                                                                                                                                                
                                                                                                                                                // Create ZipFile instance and set archive via reflection
                                                                                                                                                ZipFile zipFile = new ZipFile(tempFile);
                                                                                                                                                try {
                                                                                                                                                    Field archiveField = ZipFile.class.getDeclaredField("archive");
                                                                                                                                                    archiveField.setAccessible(true);
                                                                                                                                                    archiveField.set(zipFile, mockArchive);
                                                                                                                                                    Field entriesField = ZipFile.class.getDeclaredField("entries");
                                                                                                                                                    entriesField.setAccessible(true);
                                                                                                                                                    entriesField.set(zipFile, entries);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    Method resolveMethod = ZipFile.class.getDeclaredMethod("resolveLocalFileHeaderData", Map.class);
                                                                                                                                                    resolveMethod.setAccessible(true);
                                                                                                                                                    resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(entry.getExtra());
                                                                                                                                                    assertEquals(10, entry.getExtra().length);
                                                                                                                                                    long expectedOffset = 100L + LFH_OFFSET_FOR_FILENAME_LENGTH + 2 + 2 + 5 + 10;
                                                                                                                                                    assertEquals(expectedOffset, dataOffsetField.getLong(offsetEntry));
                                                                                                                                                } finally {
                                                                                                                                                    zipFile.close();
                                                                                                                                                }
                                                                                                                                            } finally {
                                                                                                                                                realZipFile.close();
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                        public void testResolveLocalFileHeaderData_WithoutUTF8Flag() throws Exception {
                                                                                                                            // Setup test data structures
                                                                                                                            java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entries = 
                                                                                                                                new java.util.HashMap<>();
                                                                                                                            java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entriesWithoutUTF8Flag = 
                                                                                                                                new java.util.HashMap<>();
                                                                                                                            java.util.Map<String, org.apache.commons.compress.archivers.zip.ZipArchiveEntry> nameMap = 
                                                                                                                                new java.util.HashMap<>();
                                                                                                                            
                                                                                                                            // Create mock archive
                                                                                                                            java.io.RandomAccessFile mockArchive = new java.io.RandomAccessFile(
                                                                                                                                java.io.File.createTempFile("mock", ".zip"), "r");
                                                                                                                            
                                                                                                                            // Create ZipFile instance
                                                                                                                            java.io.File tempFile = java.io.File.createTempFile("test", ".zip");
                                                                                                                            tempFile.deleteOnExit();
                                                                                                                            org.apache.commons.compress.archivers.zip.ZipFile zipFile = 
                                                                                                                                new org.apache.commons.compress.archivers.zip.ZipFile(tempFile);
                                                                                                                            
                                                                                                                            // Set private fields using reflection
                                                                                                                            java.lang.reflect.Field archiveField = 
                                                                                                                                org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("archive");
                                                                                                                            archiveField.setAccessible(true);
                                                                                                                            archiveField.set(zipFile, mockArchive);
                                                                                                                            
                                                                                                                            java.lang.reflect.Field entriesField = 
                                                                                                                                org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("entries");
                                                                                                                            entriesField.setAccessible(true);
                                                                                                                            entriesField.set(zipFile, entries);
                                                                                                                            
                                                                                                                            java.lang.reflect.Field nameMapField = 
                                                                                                                                org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("nameMap");
                                                                                                                            nameMapField.setAccessible(true);
                                                                                                                            nameMapField.set(zipFile, nameMap);
                                                                                                                            
                                                                                                                            // Setup test data
                                                                                                                            org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
                                                                                                                                new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("oldname.txt");
                                                                                                                            Object offsetEntry = new Object(); // Simplified for test
                                                                                                                            entries.put(entry, offsetEntry);
                                                                                                                            
                                                                                                                            // Create NameAndComment object using reflection
                                                                                                                            Class<?>[] declaredClasses = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredClasses();
                                                                                                                            Class<?> nameAndCommentClass = null;
                                                                                                                            for (Class<?> clazz : declaredClasses) {
                                                                                                                                if (clazz.getSimpleName().equals("NameAndComment")) {
                                                                                                                                    nameAndCommentClass = clazz;
                                                                                                                                    break;
                                                                                                                                }
                                                                                                                            }
                                                                                                                            
                                                                                                                            java.lang.reflect.Constructor<?> constructor = nameAndCommentClass.getDeclaredConstructor(
                                                                                                                                org.apache.commons.compress.archivers.zip.ZipFile.class, byte[].class, byte[].class);
                                                                                                                            constructor.setAccessible(true);
                                                                                                                            Object nc = constructor.newInstance(zipFile, "newname.txt".getBytes(), new byte[0]);
                                                                                                                            entriesWithoutUTF8Flag.put(entry, nc);
                                                                                                                            nameMap.put("oldname.txt", entry);
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            java.lang.reflect.Method resolveMethod = 
                                                                                                                                org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredMethod(
                                                                                                                                    "resolveLocalFileHeaderData", java.util.Map.class);
                                                                                                                            resolveMethod.setAccessible(true);
                                                                                                                            resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            org.junit.Assert.assertEquals("newname.txt", entry.getName());
                                                                                                                            org.junit.Assert.assertFalse(nameMap.containsKey("oldname.txt"));
                                                                                                                            org.junit.Assert.assertTrue(nameMap.containsKey("newname.txt"));
                                                                                                                            
                                                                                                                            // Clean up
                                                                                                                            mockArchive.close();
                                                                                                                        }

    @Test
                                                                            public void testResolveLocalFileHeaderData_FailedSkipOperation() throws IOException {
                                                                                // Setup test data
                                                                                java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entries = 
                                                                                    new java.util.HashMap<>();
                                                                                java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entriesWithoutUTF8Flag = 
                                                                                    new java.util.HashMap<>();
                                                                                org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
                                                                                    new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("test.txt");
                                                                                
                                                                                // Create OffsetEntry instance via reflection
                                                                                Object offsetEntry;
                                                                                try {
                                                                                    Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
                                                                                    offsetEntry = offsetEntryClass.getDeclaredConstructor().newInstance();
                                                                                    java.lang.reflect.Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
                                                                                    headerOffsetField.setAccessible(true);
                                                                                    headerOffsetField.set(offsetEntry, 300L);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to create OffsetEntry");
                                                                                    return;
                                                                                }
                                                                                entries.put(entry, offsetEntry);
                                                                                
                                                                                // Create temporary file for ZipFile constructor
                                                                                File tempFile = File.createTempFile("test", ".zip");
                                                                                tempFile.deleteOnExit();
                                                                                org.apache.commons.compress.archivers.zip.ZipFile zipFile = 
                                                                                    new org.apache.commons.compress.archivers.zip.ZipFile(tempFile);
                                                                                
                                                                                // Create mock RandomAccessFile
                                                                                RandomAccessFile mockArchive = mock(RandomAccessFile.class);
                                                                                
                                                                                // Mock read behavior to return local file header signature
                                                                                when(mockArchive.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                    Object[] args = invocation.getArguments();
                                                                                    byte[] b = (byte[]) args[0];
                                                                                    b[0] = 'P';
                                                                                    b[1] = 'K';
                                                                                    b[2] = 3;
                                                                                    b[3] = 4;
                                                                                    return 4;
                                                                                });
                                                                                
                                                                                // Mock skipBytes to throw IOException
                                                                                doThrow(new IOException("failed to skip file name in local file header"))
                                                                                    .when(mockArchive).skipBytes(anyInt());
                                                                                
                                                                                // Use reflection to set private archive field
                                                                                try {
                                                                                    java.lang.reflect.Field archiveField = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("archive");
                                                                                    archiveField.setAccessible(true);
                                                                                    archiveField.set(zipFile, mockArchive);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set mock archive");
                                                                                }
                                                                                
                                                                                // Test the method
                                                                                try {
                                                                                    Method method = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredMethod(
                                                                                        "resolveLocalFileHeaderData", Map.class);
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(zipFile, entriesWithoutUTF8Flag);
                                                                                    fail("Expected IOException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertTrue(e.getCause() instanceof IOException);
                                                                                    assertEquals("failed to skip file name in local file header", e.getCause().getMessage());
                                                                                } catch (Exception e) {
                                                                                    fail("Unexpected exception: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                        public void testResolveLocalFileHeaderData_EmptyEntries() throws IOException {
                                            // Create empty maps
                                            Map<ZipArchiveEntry, Object> entriesWithoutUTF8Flag = new HashMap<>();
                                            Map<ZipArchiveEntry, Object> entries = new HashMap<>();
                                            
                                            // Create a temporary empty zip file for testing
                                            File tempFile = File.createTempFile("empty", ".zip");
                                            tempFile.deleteOnExit();
                                            
                                            // Initialize ZipFile with the empty file
                                            ZipFile zipFile = new ZipFile(tempFile);
                                            
                                            // Use reflection to set the private entries field
                                            try {
                                                Field entriesField = ZipFile.class.getDeclaredField("entries");
                                                entriesField.setAccessible(true);
                                                entriesField.set(zipFile, entries);
                                            } catch (Exception e) {
                                                throw new RuntimeException("Failed to set entries field via reflection", e);
                                            }
                                            
                                            // Execute - should not throw any exceptions
                                            try {
                                                Method resolveMethod = ZipFile.class.getDeclaredMethod(
                                                    "resolveLocalFileHeaderData", Map.class);
                                                resolveMethod.setAccessible(true);
                                                resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
                                            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                throw new RuntimeException("Failed to invoke resolveLocalFileHeaderData via reflection", e);
                                            }
                                            
                                            // Verify
                                            assertTrue(entries.isEmpty());
                                            
                                            // Clean up
                                            zipFile.close();
                                        }


}
