package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                   public void testGetEntryEncoding_DefaultConstructor() {
                                                                                                                                                                                                                                       // Test with default constructor (null encoding)
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       assertNull("Default constructor should initialize entryEncoding as null", 
                                                                                                                                                                                                                                                  factory.getEntryEncoding());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testGetEntryEncoding_ConstructorWithEncoding() {
                                                                                                                                                                                                                                       // Test with specific encoding in constructor
                                                                                                                                                                                                                                       String testEncoding = "UTF-8";
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                                                                                                                                                                       assertEquals("Constructor should set the provided encoding",
                                                                                                                                                                                                                                                   testEncoding, factory.getEntryEncoding());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testGetEntryEncoding_AfterSetter() {
                                                                                                                                                                                                                                       // Test changing encoding via setter
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       String newEncoding = "ISO-8859-1";
                                                                                                                                                                                                                                       factory.setEntryEncoding(newEncoding);
                                                                                                                                                                                                                                       assertEquals("Setter should update the entry encoding",
                                                                                                                                                                                                                                                   newEncoding, factory.getEntryEncoding());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testGetEntryEncoding_ThreadVisibility() throws InterruptedException {
                                                                                                                                                                                                                                       // Test volatile behavior with multiple threads
                                                                                                                                                                                                                                       final ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       final String[] result = new String[1];
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Initial value check
                                                                                                                                                                                                                                       assertNull(factory.getEntryEncoding());
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Thread that will read the value
                                                                                                                                                                                                                                       Thread readerThread = new Thread(() -> {
                                                                                                                                                                                                                                           result[0] = factory.getEntryEncoding();
                                                                                                                                                                                                                                       });
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Thread that will set the value
                                                                                                                                                                                                                                       Thread writerThread = new Thread(() -> {
                                                                                                                                                                                                                                           factory.setEntryEncoding("UTF-16");
                                                                                                                                                                                                                                       });
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Start writer first then reader
                                                                                                                                                                                                                                       writerThread.start();
                                                                                                                                                                                                                                       writerThread.join(); // Wait for writer to finish
                                                                                                                                                                                                                                       readerThread.start();
                                                                                                                                                                                                                                       readerThread.join(); // Wait for reader to finish
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertEquals("Volatile field should be visible across threads",
                                                                                                                                                                                                                                                   "UTF-16", result[0]);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testGetEntryEncoding_AfterSettingNull() {
                                                                                                                                                                                                                                       // Test setting null encoding
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       factory.setEntryEncoding(null);
                                                                                                                                                                                                                                       assertNull("Should allow setting null encoding", factory.getEntryEncoding());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testGetEntryEncoding_EmptyString() {
                                                                                                                                                                                                                                       // Test with empty string encoding
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("");
                                                                                                                                                                                                                                       assertEquals("Should handle empty string encoding",
                                                                                                                                                                                                                                                   "", factory.getEntryEncoding());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_AR_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ARJ_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ARJ_WithEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ZIP_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ZIP_WithEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_TAR_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_TAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_JAR_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_JAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_CPIO_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_CPIO_WithEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_DUMP_NoEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_DUMP_WithEncoding() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, input);
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_CaseInsensitive() throws Exception {
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveInputStream result1 = factory.createArchiveInputStream("ar", input);
                                                                                                                                                                                                                                       ArchiveInputStream result2 = factory.createArchiveInputStream("Ar", input);
                                                                                                                                                                                                                                       ArchiveInputStream result3 = factory.createArchiveInputStream("AR", input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result1);
                                                                                                                                                                                                                                       assertNotNull(result2);
                                                                                                                                                                                                                                       assertNotNull(result3);
                                                                                                                                                                                                                                       assertTrue(result1 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                       assertTrue(result2 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                       assertTrue(result3 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_ArFormat() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.AR, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ArArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_ZipFormat() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_ZipFormatWithEncoding() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                       assertEquals("UTF-8", ((ZipArchiveOutputStream) result).getEncoding());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_TarFormat() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof TarArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_TarFormatWithEncoding() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof TarArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_JarFormat() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof JarArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_JarFormatWithEncoding() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof JarArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_CpioFormat() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.CPIO, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof CpioArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_CpioFormatWithEncoding() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.CPIO, out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof CpioArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_CaseInsensitiveFormat() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveOutputStream result1 = factory.createArchiveOutputStream("zip", out);
                                                                                                                                                                                                                                       ArchiveOutputStream result2 = factory.createArchiveOutputStream("ZIP", out);
                                                                                                                                                                                                                                       ArchiveOutputStream result3 = factory.createArchiveOutputStream("Zip", out);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result1);
                                                                                                                                                                                                                                       assertNotNull(result2);
                                                                                                                                                                                                                                       assertNotNull(result3);
                                                                                                                                                                                                                                       assertTrue(result1 instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                       assertTrue(result2 instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                       assertTrue(result3 instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ZipFormat() throws Exception {
                                                                                                                                                                                                                                       // ZIP signature: 50 4B 03 04
                                                                                                                                                                                                                                       byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.zip.ZipArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_JarFormat() throws Exception {
                                                                                                                                                                                                                                       // JAR signature is same as ZIP
                                                                                                                                                                                                                                       byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(jarSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.jar.JarArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ArFormat() throws Exception {
                                                                                                                                                                                                                                       // AR signature: "!<arch>"
                                                                                                                                                                                                                                       byte[] arSignature = "!<arch>\n".getBytes();
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(arSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.ar.ArArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_CpioFormat() throws Exception {
                                                                                                                                                                                                                                       // CPIO signature: "070707" or "070701" or "070702"
                                                                                                                                                                                                                                       byte[] cpioSignature = "070707".getBytes();
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(cpioSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ArjFormat() throws Exception {
                                                                                                                                                                                                                                       // ARJ signature: 0x60 0xEA
                                                                                                                                                                                                                                       byte[] arjSignature = new byte[] {(byte)0x60, (byte)0xEA, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(arjSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.arj.ArjArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_DumpFormat() throws Exception {
                                                                                                                                                                                                                                       // Dump signature: starts with "DUMP"
                                                                                                                                                                                                                                       byte[] dumpSignature = new byte[32];
                                                                                                                                                                                                                                       System.arraycopy("DUMP".getBytes(), 0, dumpSignature, 0, 4);
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(dumpSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.dump.DumpArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_TarFormat() throws Exception {
                                                                                                                                                                                                                                       // Tar signature: first 512 bytes block with valid checksum
                                                                                                                                                                                                                                       byte[] tarSignature = new byte[512];
                                                                                                                                                                                                                                       // Create a simple valid tar header
                                                                                                                                                                                                                                       System.arraycopy("test.txt".getBytes(), 0, tarSignature, 0, 8); // filename
                                                                                                                                                                                                                                       tarSignature[100] = '0'; // file mode
                                                                                                                                                                                                                                       tarSignature[108] = '0'; // uid
                                                                                                                                                                                                                                       tarSignature[116] = '0'; // gid
                                                                                                                                                                                                                                       System.arraycopy("00000000000".getBytes(), 0, tarSignature, 124, 11); // size
                                                                                                                                                                                                                                       System.arraycopy("00000000000".getBytes(), 0, tarSignature, 136, 11); // mtime
                                                                                                                                                                                                                                       // Calculate checksum (simplified)
                                                                                                                                                                                                                                       int checksum = 8 * ' '; // spaces for checksum field
                                                                                                                                                                                                                                       for (int i = 0; i < 148; i++) {
                                                                                                                                                                                                                                           checksum += tarSignature[i];
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       for (int i = 156; i < 512; i++) {
                                                                                                                                                                                                                                           checksum += tarSignature[i];
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       String chk = String.format("%06o", checksum);
                                                                                                                                                                                                                                       System.arraycopy(chk.getBytes(), 0, tarSignature, 148, 6);
                                                                                                                                                                                                                                       tarSignature[154] = ' ';
                                                                                                                                                                                                                                       tarSignature[155] = 0;
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.tar.TarArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_WithEntryEncoding() throws Exception {
                                                                                                                                                                                                                                       // ZIP signature: 50 4B 03 04
                                                                                                                                                                                                                                       byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                       factory.setEntryEncoding("UTF-16");
                                                                                                                                                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(ais);
                                                                                                                                                                                                                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.zip.ZipArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                       public void testCreateArchiveInputStream_NullArchiverName() throws Exception {
                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                               factory.createArchiveInputStream(null, mock(InputStream.class));
                                                                                                                                                                                                                               fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                               assertEquals("Archivername must not be null.", e.getMessage());
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                       public void testCreateArchiveInputStream_NullInputStream() throws Exception {
                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                               factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                                                                                                                               fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                               assertEquals("InputStream must not be null.", e.getMessage());
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                       public void testCreateArchiveOutputStream_NullArchiverName() throws Exception {
                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                           OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                           expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                           expectedException.expectMessage("Archivername must not be null.");
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           factory.createArchiveOutputStream(null, out);
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                       public void testCreateArchiveInputStream_UnsupportedMark() {
                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                           when(input.markSupported()).thenReturn(false);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                               factory.createArchiveInputStream(input);
                                                                                                                                                                                                                               fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                               assertTrue(e instanceof IllegalArgumentException);
                                                                                                                                                                                                                               assertEquals("Mark is not supported.", e.getMessage());
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                   public void testCreateArchiveInputStream_SEVEN_Z() throws Exception {
                                                                                                                                                                                       try {
                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                           factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, mockInputStream);
                                                                                                                                                                                           fail("Expected StreamingNotSupportedException to be thrown");
                                                                                                                                                                                       } catch (StreamingNotSupportedException e) {
                                                                                                                                                                                           assertEquals(ArchiveStreamFactory.SEVEN_Z, e.getMessage());
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testCreateArchiveOutputStream_UnknownFormat() throws Exception {
                                                                                                                                                                                       // Setup
                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                       
                                                                                                                                           {
                                                                                                                                                                                           // Test
                                                                                                                                                                                           fail("Expected ArchiveException to be thrown");
                                                                                                                                           }{
                                                                                                                                                                                           // Verify
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testCreateArchiveOutputStream_NullOutputStream() throws Exception {
                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                       
                                                                                                                                                                                       try {
                                                                                                                                                                                           factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, null);
                                                                                                                                                                                           fail("Expected IllegalArgumentException");
                                                                                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                                                                                           assertEquals("OutputStream must not be null.", e.getMessage());
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testCreateArchiveInputStream_SevenZFormat() throws Exception {
                                                                                                                                                                                       try {
                                                                                                                                                                                           // 7z signature: "7z" followed by 0xBC 0xAF 0x27 0x1C
                                                                                                                                                                                           byte[] sevenZSignature = new byte[] {'7', 'z', (byte)0xBC, (byte)0xAF, 0x27, 0x1C, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                           InputStream input = new ByteArrayInputStream(sevenZSignature);
                                                                                                                                                                                           
                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                           factory.createArchiveInputStream(input);
                                                                                                                                                                                           fail("Expected StreamingNotSupportedException to be thrown");
                                                                                                                                                                                       } catch (StreamingNotSupportedException e) {
                                                                                                                                                                                           assertTrue(e.getMessage().contains("7z"));
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testCreateArchiveInputStream_IOExceptionDuringRead() throws Exception {
                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                       when(input.markSupported()).thenReturn(true);
                                                                                                                                                                                       when(input.read(any(byte[].class))).thenThrow(new IOException("Test IO Exception"));
                                                                                                                                                                                       
                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                       try {
                                                                                                                                                                                           factory.createArchiveInputStream(input);
                                                                                                                                                                                           fail("Expected ArchiveException to be thrown");
                                                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                                                           assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testCreateArchiveOutputStream_SevenZFormat() throws Exception {
                                                                                                                                                                                       // Setup
                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                       
                                                                                                                                                                                       try {
                                                                                                                                                                                           // Test
                                                                                                                                                                                           factory.createArchiveOutputStream(ArchiveStreamFactory.SEVEN_Z, out);
                                                                                                                                                                                           fail("Expected StreamingNotSupportedException");
                                                                                                                                                                                       } catch (StreamingNotSupportedException e) {
                                                                                                                                                                                           // Verify
                                                                                                                                                                                           assertEquals(ArchiveStreamFactory.SEVEN_Z, e.getMessage());
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                               public void testSetEntryEncoding_ShouldThrowIllegalStateExceptionWhenEncodingExists() {
                                                                                                                                                   // Arrange
                                                                                                                                                   String initialEncoding = "UTF-8";
                                                                                                                                                   String newEncoding = "UTF-16";
                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(initialEncoding);
                                                                                                                                                   
                                                                                                                                                   // Expect exception
                                                                                                                                                   thrown.expect(IllegalStateException.class);
                                                                                                                                                   thrown.expectMessage("Cannot overide encoding set by the constructor");
                                                                                                                                                   
                                                                                                                                                   // Act
                                                                                                                                                   factory.setEntryEncoding(newEncoding);
                                                                                                                                               }

    @Test
                                                                                                                                              public void testCreateArchiveInputStream_ARFormat() throws Exception {
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  ByteArrayInputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                  
                                                                                                                                                  // This should work for AR format in original code, but fail with mutant
                                                                                                                                                  ArchiveInputStream stream = factory.createArchiveInputStream(ArchiveStreamFactory.AR, input);
                                                                                                                                                  assertNotNull(stream);
                                                                                                                                              }

    @Test
                                                                                                                                              public void testCreateArchiveInputStream_ARJFormat() throws Exception {
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  ByteArrayInputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                  
                                                                                                                                                  // This should work for ARJ format in both original and mutant
                                                                                                                                                  ArchiveInputStream stream = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                                                                                                  assertNotNull(stream);
                                                                                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                              public void testCreateArchiveInputStream_InvalidFormat() throws Exception {
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  ByteArrayInputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                  
                                                                                                                                                  // This should throw IllegalArgumentException for unknown format
                                                                                                                                                  factory.createArchiveInputStream("INVALID_FORMAT", input);
                                                                                                                                              }

    @Test
                                                                                                                                              public void testCreateArchiveOutputStream_ARFormat() throws Exception {
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  ByteArrayOutputStream output = new ByteArrayOutputStream();
                                                                                                                                                  
                                                                                                                                                  // This should work for AR format in original code, but fail with mutant
                                                                                                                                                  ArchiveOutputStream stream = factory.createArchiveOutputStream(ArchiveStreamFactory.AR, output);
                                                                                                                                                  assertNotNull(stream);
                                                                                                                                              }

    @Test
                                                                                                                                              public void testCreateArchiveOutputStream_ARJFormat() throws Exception {
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  ByteArrayOutputStream output = new ByteArrayOutputStream();
                                                                                                                                                  
                                                                                                                                                  // This should work for ARJ format in both original and mutant
                                                                                                                                                  ArchiveOutputStream stream = factory.createArchiveOutputStream(ArchiveStreamFactory.ARJ, output);
                                                                                                                                                  assertNotNull(stream);
                                                                                                                                              }

    @Test
                                                                                                                                             public void testCreateArchiveInputStreamWithArShouldNotReturnNullInputStream() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                                                                 
                                                                                                                                                 // Test
                                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInput);
                                                                                                                                                 
                                                                                                                                                 // Verify the stream was created with our input, not null
                                                                                                                                                 // This would throw NullPointerException if mutant is present
                                                                                                                                                 result.read();
                                                                                                                                                 
                                                                                                                                                 // If we get here, the test passes (no NullPointerException)
                                                                                                                                                 // We could also verify the mock was interacted with
                                                                                                                                                 verify(mockInput, atLeastOnce()).read();
                                                                                                                                             }

    @Test
                                                                                                                                             public void testCreateArchiveInputStreamShouldNotAcceptNullInput() throws Exception {
                                                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                                             }

    @Test
                                                                                                                                            public void testSetEntryEncodingWhenEncodingIsSet() {
                                                                                                                                                // Create instance with non-null encoding
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                
                                                                                                                                                try {
                                                                                                                                                    // Try to set entry encoding - should throw exception
                                                                                                                                                    factory.setEntryEncoding("ASCII");
                                                                                                                                                    
                                                                                                                                                    // If we get here, the mutant survived - fail the test
                                                                                                                                                    fail("Expected IllegalStateException not thrown");
                                                                                                                                                    
                                                                                                                                                } catch (IllegalStateException e) {
                                                                                                                                                    // Original behavior - verify exception message
                                                                                                                                                    assertEquals("Cannot overide encoding set by the constructor", e.getMessage());
                                                                                                                                                    
                                                                                                                                                    // Additional verification that entryEncoding wasn't changed
                                                                                                                                                    // (though the original method would have thrown exception before setting it)
                                                                                                                                                    assertEquals("UTF-8", factory.getEntryEncoding());
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                            public void testSetEntryEncodingWhenEncodingIsNull() {
                                                                                                                                                // Create instance with null encoding
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                
                                                                                                                                                // Set entry encoding - should work
                                                                                                                                                factory.setEntryEncoding("ASCII");
                                                                                                                                                
                                                                                                                                                // Verify entryEncoding was set
                                                                                                                                                assertEquals("ASCII", factory.getEntryEncoding());
                                                                                                                                            }

    @Test
                                                                                                                                       public void testCreateArchiveInputStreamUsesSpecifiedEncoding() throws Exception {
                                                                                                                                           // Arrange
                                                                                                                                           String testEncoding = "ISO-8859-1"; // Any non-UTF-8 encoding
                                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                                                                           
                                                                                                                                           // Act
                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(mockInputStream);
                                                                                                                                           
                                                                                                                                           // Assert
                                                                                                                                           // Verify the encoding was passed correctly by checking the entry encoding
                                                                                                                                           assertEquals("Encoding should match constructor parameter", 
                                                                                                                                                        testEncoding, factory.getEntryEncoding());
                                                                                                                                           
                                                                                                                                           // Additional verification that the stream was created with correct encoding
                                                                                                                                           // This assumes the ARJ archive stream properly sets its encoding field
                                                                                                                                           if (result instanceof ArjArchiveInputStream) {
                                                                                                                                               Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                                                                                               encodingField.setAccessible(true);
                                                                                                                                               String actualEncoding = (String) encodingField.get(result);
                                                                                                                                               assertEquals("Stream should be created with specified encoding",
                                                                                                                                                           testEncoding, actualEncoding);
                                                                                                                                           } else {
                                                                                                                                               fail("Expected ARJ archive input stream");
                                                                                                                                           }
                                                                                                                                       }

    @Test
                                                                                                                                      public void testCreateArchiveInputStreamUsesSpecifiedEncoding1() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String testEncoding = "ISO-8859-1"; // Any non-UTF-8 encoding
                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(mockInputStream);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          // Verify the encoding was passed correctly by checking the factory's encoding
                                                                                                                                          assertEquals("Encoding should match constructor parameter", 
                                                                                                                                                      testEncoding, factory.getEntryEncoding());
                                                                                                                                          
                                                                                                                                          // Verify the stream was created successfully
                                                                                                                                          assertNotNull("ArchiveInputStream should not be null", result);
                                                                                                                                      }

    @Test
                                                                                                                                  public void testCreateArchiveInputStreamForArjWithNonNullInput() throws Exception {
                                                                                                                                      // Setup
                                                                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                      InputStream input = new ByteArrayInputStream(new byte[0]); // non-null input
                                                                                                                                      
                                                                                                                                      // Test
                                                                                                                                      ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                                                                                      
                                                                                                                                      // Verify the stream is properly created
                                                                                                                                      assertNotNull("Resulting stream should not be null", result);
                                                                                                                                      
                                                                                                                                      // Additional verification that the stream works with the input
                                                                                                                                      try {
                                                                                                                                          result.getNextEntry(); // This would throw NullPointerException if input was null
                                                                                                                                      } catch (NullPointerException e) {
                                                                                                                                          fail("ArchiveInputStream was created with null input (mutant detected)");
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                                     public void testCreateArchiveInputStreamDetectsTarCorrectly() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                         ByteArrayInputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                         
                                                                                                                                         // Test TAR detection
                                                                                                                                         ArchiveInputStream tarStream = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                         assertNotNull("Should successfully create TAR input stream", tarStream);
                                                                                                                                         assertTrue("Should be TAR stream", tarStream.getClass().getName().contains("TarArchiveInputStream"));
                                                                                                                                         
                                                                                                                                         // Test JAR detection
                                                                                                                                         ArchiveInputStream jarStream = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                         assertNotNull("Should successfully create JAR input stream", jarStream);
                                                                                                                                         assertTrue("Should be JAR stream", jarStream.getClass().getName().contains("JarArchiveInputStream"));
                                                                                                                                     }

    @Test
                                                                                                                                     public void testCreateArchiveOutputStreamDetectsTarCorrectly() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                         ByteArrayOutputStream output = new ByteArrayOutputStream();
                                                                                                                                         
                                                                                                                                         // Test TAR detection
                                                                                                                                         ArchiveOutputStream tarStream = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, output);
                                                                                                                                         assertNotNull("Should successfully create TAR output stream", tarStream);
                                                                                                                                         assertTrue("Should be TAR stream", tarStream.getClass().getName().contains("TarArchiveOutputStream"));
                                                                                                                                         
                                                                                                                                         // Test JAR detection
                                                                                                                                         ArchiveOutputStream jarStream = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, output);
                                                                                                                                         assertNotNull("Should successfully create JAR output stream", jarStream);
                                                                                                                                         assertTrue("Should be JAR stream", jarStream.getClass().getName().contains("JarArchiveOutputStream"));
                                                                                                                                     }

    @Test
                                                                                                                                    public void testCreateArchiveInputStreamWithCPIO() throws Exception {
                                                                                                                                        // Arrange
                                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                        ByteArrayInputStream in = new ByteArrayInputStream(new byte[0]);
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        ArchiveInputStream stream = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, in);
                                                                                                                                        
                                                                                                                                        // Assert
                                                                                                                                        assertNotNull(stream);
                                                                                                                                        // This test would fail if the mutant is present because 
                                                                                                                                        // the mutant would not properly handle CPIO format
                                                                                                                                    }

    @Test
                                                                                                                                    public void testCreateArchiveInputStreamWithDUMP() throws Exception {
                                                                                                                                        // Arrange
                                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                        ByteArrayInputStream in = new ByteArrayInputStream(new byte[0]);
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        ArchiveInputStream stream = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, in);
                                                                                                                                        
                                                                                                                                        // Assert
                                                                                                                                        assertNotNull(stream);
                                                                                                                                        // This test would pass with both original and mutant code,
                                                                                                                                        // but combined with the CPIO test, it helps verify the mutation
                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                    public void testCreateArchiveInputStreamWithUnknownFormat() throws Exception {
                                                                                                                                        // Arrange
                                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                        ByteArrayInputStream in = new ByteArrayInputStream(new byte[0]);
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        factory.createArchiveInputStream("UNKNOWN_FORMAT", in);
                                                                                                                                        
                                                                                                                                        // Assert - expects exception
                                                                                                                                    }

    @Test
                                                                                                                                    public void testSetEntryEncodingWhenEncodingIsNull1() {
                                                                                                                                        // Arrange
                                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory(); // encoding is null
                                                                                                                                        String testEncoding = "UTF-8";
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        factory.setEntryEncoding(testEncoding);
                                                                                                                                        
                                                                                                                                        // Assert
                                                                                                                                        assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                                                                    }

    @Test(expected = IllegalStateException.class)
                                                                                                                                    public void testSetEntryEncodingWhenEncodingIsNotNull() {
                                                                                                                                        // Arrange
                                                                                                                                        String initialEncoding = "ASCII";
                                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory(initialEncoding);
                                                                                                                                        String testEncoding = "UTF-8";
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        factory.setEntryEncoding(testEncoding);
                                                                                                                                        
                                                                                                                                        // Assert - expects exception
                                                                                                                                    }

    @Test(expected = IllegalStateException.class)
                                                                                                                                   public void testSetEntryEncoding_ShouldThrowWhenEncodingAlreadySet() {
                                                                                                                                       // Arrange
                                                                                                                                       String initialEncoding = "UTF-8";
                                                                                                                                       String newEncoding = "UTF-16";
                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(initialEncoding);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       factory.setEntryEncoding(newEncoding);
                                                                                                                                       
                                                                                                                                       // Assert - should throw IllegalStateException
                                                                                                                                       // If mutant survives, it would return ArArchiveInputStream instead
                                                                                                                                   }

    @Test
                                                                                                                                   public void testSetEntryEncoding_ShouldNotChangeEncodingWhenAlreadySet() {
                                                                                                                                       // Arrange
                                                                                                                                       String initialEncoding = "UTF-8";
                                                                                                                                       String newEncoding = "UTF-16";
                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(initialEncoding);
                                                                                                                                       
                                                                                                                                       try {
                                                                                                                                           // Act
                                                                                                                                           factory.setEntryEncoding(newEncoding);
                                                                                                                                           fail("Expected IllegalStateException was not thrown");
                                                                                                                                       } catch (IllegalStateException e) {
                                                                                                                                           // Assert
                                                                                                                                           assertEquals("Encoding should remain unchanged", 
                                                                                                                                                       initialEncoding, factory.getEntryEncoding());
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // If mutant survives, entryEncoding would be changed to newEncoding
                                                                                                                                       // and no exception would be thrown
                                                                                                                                   }

    @Test
                                                                                                                                   public void testSetEntryEncoding_ShouldAcceptEncodingWhenNotSet() {
                                                                                                                                       // Arrange
                                                                                                                                       String newEncoding = "UTF-8";
                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(); // no encoding set
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       factory.setEntryEncoding(newEncoding);
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertEquals("Encoding should be set when no previous encoding exists",
                                                                                                                                                   newEncoding, factory.getEntryEncoding());
                                                                                                                                   }

    @Test
                                                                                                                                  public void testSetEntryEncoding_WhenEncodingSetByConstructor_ShouldThrowIllegalStateException() {
                                                                                                                                      // Arrange
                                                                                                                                      String initialEncoding = "UTF-8";
                                                                                                                                      String newEncoding = "UTF-16";
                                                                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory(initialEncoding);
                                                                                                                                      
                                                                                                                                      // Set expectations
                                                                                                                                      thrown.expect(IllegalStateException.class);
                                                                                                                                      thrown.expectMessage("Cannot override encoding set by the constructor");
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      factory.setEntryEncoding(newEncoding);
                                                                                                                                  }

    @Test
                                                                                                                            public void testCreateArArchiveInputStreamWithValidStream() throws Exception {
                                                                                                                                // Create factory instance
                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                
                                                                                                                                // Create mock input stream
                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                // Configure mock to return -1 when read() is called (EOF)
                                                                                                                                when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                
                                                                                                                                // Test that AR archive input stream is created with the provided input stream
                                                                                                                                ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                
                                                                                                                                // Verify the returned stream is of correct type
                                                                                                                                assertTrue(ais instanceof ArArchiveInputStream);
                                                                                                                                
                                                                                                                                // Try to read from the stream to verify it was initialized with our mock stream
                                                                                                                                // This would throw NullPointerException if mutant is present (stream initialized with null)
                                                                                                                                try {
                                                                                                                                    ais.read();
                                                                                                                                    // If we get here, the stream was properly initialized
                                                                                                                                } catch (NullPointerException e) {
                                                                                                                                    fail("ArArchiveInputStream was initialized with null input stream");
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                        public void testCreateArchiveInputStreamForArWithNonNullStream() throws Exception {
                                                                                            // Prepare AR signature
                                                                                            byte[] arSignature = new byte[12];
                                                                                            // AR signature is "!<arch>\n" at the beginning
                                                                                            System.arraycopy("!<arch>\n".getBytes(), 0, arSignature, 0, 8);
                                                                                            
                                                                                            // Create mock input stream that returns AR signature
                                                                                            InputStream mockIn = mock(InputStream.class);
                                                                                            when(mockIn.markSupported()).thenReturn(true);
                                                                                            when(mockIn.read(any(byte[].class)))
                                                                                                .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                    @Override
                                                                                                    public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                        byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                        System.arraycopy(arSignature, 0, buf, 0, Math.min(arSignature.length, buf.length));
                                                                                                        return arSignature.length;
                                                                                                    }
                                                                                                });
                                                                                            
                                                                                            // Create factory instance
                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                            
                                                                                            // Call method under test
                                                                                            ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                            
                                                                                            // Verify the result is AR archive stream and contains our input stream
                                                                                            assertTrue(result instanceof ArArchiveInputStream);
                                                                                            
                                                                                            // Verify the underlying stream is our mock stream (not null)
                                                                                            // This is the key assertion that would catch the mutant
                                                                                            java.lang.reflect.Field inField = ArArchiveInputStream.class.getDeclaredField("in");
                                                                                            inField.setAccessible(true);
                                                                                            InputStream wrappedStream = (InputStream) inField.get(result);
                                                                                            assertSame(mockIn, wrappedStream);
                                                                                            
                                                                                            // Clean up
                                                                                            result.close();
                                                                                        }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEncoding_ARJ() throws Exception {
                                                                                       String testEncoding = "UTF-8";
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInputStream);
                                                                                       assertTrue("Should create ArjArchiveInputStream with encoding", 
                                                                                                 result instanceof ArjArchiveInputStream);
                                                                                       // The mutant would create ArjArchiveInputStream without encoding parameter
                                                                                       assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                   }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEncoding_ZIP() throws Exception {
                                                                                       String testEncoding = "UTF-8";
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                                       assertTrue("Should create ZipArchiveInputStream with encoding", 
                                                                                                 result instanceof ZipArchiveInputStream);
                                                                                       assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                   }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEncoding_TAR() throws Exception {
                                                                                       String testEncoding = "UTF-8";
                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                       
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                       assertTrue("Should create TarArchiveInputStream with encoding", 
                                                                                                 result instanceof TarArchiveInputStream);
                                                                                       assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                   }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEncoding_JAR() throws Exception {
                                                                                       // Setup
                                                                                       String testEncoding = "UTF-8";
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       
                                                                                       // Test
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInputStream);
                                                                                       
                                                                                       // Verify
                                                                                       assertTrue("Should create JarArchiveInputStream with encoding", 
                                                                                                 result instanceof JarArchiveInputStream);
                                                                                       assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                   }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEncoding_CPIO() throws Exception {
                                                                                       String testEncoding = "UTF-8";
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                                                                                       assertTrue("Should create CpioArchiveInputStream with encoding", 
                                                                                                 result instanceof CpioArchiveInputStream);
                                                                                       assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                   }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEncoding_DUMP() throws Exception {
                                                                                       String testEncoding = "UTF-8";
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInputStream);
                                                                                       assertTrue("Should create DumpArchiveInputStream with encoding", 
                                                                                                 result instanceof DumpArchiveInputStream);
                                                                                       assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                   }

    @Test
                                                                                   public void testCreateArchiveInputStreamWithEntryEncoding() throws Exception {
                                                                                       // Setup
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                       factory.setEntryEncoding("UTF-8"); // Set non-null encoding
                                                                                       
                                                                                       // Create a mock input stream that will identify as ZIP format
                                                                                       InputStream mockIn = mock(InputStream.class);
                                                                                       when(mockIn.markSupported()).thenReturn(true);
                                                                                       
                                                                                       // Setup signature reading for ZIP format
                                                                                       byte[] zipSignature = new byte[12];
                                                                                       System.arraycopy(new byte[] {0x50, 0x4B, 0x03, 0x04}, 0, zipSignature, 0, 4); // ZIP signature
                                                                                       when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                           Object[] args = invocation.getArguments();
                                                                                           byte[] buf = (byte[]) args[0];
                                                                                           System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                           return zipSignature.length;
                                                                                       });
                                                                                       
                                                                                       // Test
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                       
                                                                                       // Verify
                                                                                       assertTrue(result instanceof ZipArchiveInputStream);
                                                                                       // The key assertion - verify encoding was properly passed through
                                                                                       // Use reflection to get the encoding field from ZipArchiveInputStream
                                                                                       Field encodingField = ZipArchiveInputStream.class.getDeclaredField("encoding");
                                                                                       encodingField.setAccessible(true);
                                                                                       String actualEncoding = (String) encodingField.get(result);
                                                                                       assertEquals("UTF-8", actualEncoding);
                                                                                       
                                                                                       verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                       verify(mockIn, atLeastOnce()).reset();
                                                                                   }

    @Test
                                                                               public void testCreateArjArchiveInputStreamWithCustomEncoding() throws Exception {
                                                                                   // Setup
                                                                                   String testEncoding = "ISO-8859-1";
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                   
                                                                                   // Test
                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInputStream);
                                                                                   
                                                                                   // Verify
                                                                                   assertTrue(result instanceof ArjArchiveInputStream);
                                                                                   
                                                                                   // This is the key assertion to catch the mutant
                                                                                   // The original code should use the specified encoding (testEncoding)
                                                                                   // The mutant would hardcode "UTF-8" instead
                                                                                   Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                                   encodingField.setAccessible(true);
                                                                                   String actualEncoding = (String) encodingField.get(result);
                                                                                   assertEquals(testEncoding, actualEncoding);
                                                                               }

    @Test
                                                                              public void testCreateArchiveInputStreamForArjWithCustomEncoding() throws Exception {
                                                                                  // Setup
                                                                                  String testEncoding = "ISO-8859-1";
                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                  
                                                                                  // Mock input stream that matches ARJ signature
                                                                                  InputStream mockIn = mock(InputStream.class);
                                                                                  when(mockIn.markSupported()).thenReturn(true);
                                                                                  
                                                                                  // Setup signature reading behavior
                                                                                  byte[] arjSignature = new byte[12];
                                                                                  // ARJ signature magic numbers
                                                                                  arjSignature[0] = (byte) 0x60;
                                                                                  arjSignature[1] = (byte) 0xEA;
                                                                                  
                                                                                  when(IOUtils.readFully(mockIn, any(byte[].class)))
                                                                                      .thenAnswer(invocation -> {
                                                                                          byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                          System.arraycopy(arjSignature, 0, buf, 0, Math.min(arjSignature.length, buf.length));
                                                                                          return arjSignature.length;
                                                                                      });
                                                                                  
                                                                                  // Create ARJ archive input stream with reflection to verify encoding
                                                                                  ArchiveInputStream ais = factory.createArchiveInputStream(mockIn);
                                                                                  
                                                                                  // Verify it's an ARJ stream
                                                                                  assertTrue(ais instanceof ArjArchiveInputStream);
                                                                                  
                                                                                  // Use reflection to verify the encoding was set correctly
                                                                                  Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                                  encodingField.setAccessible(true);
                                                                                  String actualEncoding = (String) encodingField.get(ais);
                                                                                  
                                                                                  // Assert the encoding matches what we set, not hardcoded UTF-8
                                                                                  assertEquals(testEncoding, actualEncoding);
                                                                              }

    @Test(expected = StreamingNotSupportedException.class)
                                                                          public void testCreateArchiveInputStream_SevenZSignature_ShouldThrowException() throws Exception {
                                                                              // Arrange
                                                                              byte[] sevenZSignature = {
                                                                                  (byte) 0x37, (byte) 0x7A, (byte) 0xBC, (byte) 0xAF, 
                                                                                  (byte) 0x27, (byte) 0x1C, 0x00, 0x00, 
                                                                                  0x00, 0x00, 0x00, 0x00
                                                                              };
                                                                              InputStream inputStream = new ByteArrayInputStream(sevenZSignature);
                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                              
                                                                              // Act - should throw StreamingNotSupportedException
                                                                              factory.createArchiveInputStream(inputStream);
                                                                              
                                                                              // Assert - handled by @Test(expected)
                                                                          }

    @Test
                                                                         public void testCreateArchiveInputStreamForSevenZShouldThrowException() throws Exception {
                                                                             // Define constant for SevenZ format
                                                                             final String SEVEN_Z = "7z";
                                                                             
                                                                             // Prepare test data
                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                             
                                                                             // Set expectation
                                                                             thrown.expect(StreamingNotSupportedException.class);
                                                                             thrown.expectMessage(SEVEN_Z);
                                                                             
                                                                             // Execute test
                                                                             factory.createArchiveInputStream(SEVEN_Z, mockInputStream);
                                                                         }

    @Test
                                                                         public void testCreateArArchiveInputStreamWithValidStream1() throws Exception {
                                                                             // Prepare test data
                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                             
                                                                             // Call the method
                                                                             Object result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                             
                                                                             // Verify the result
                                                                             assertNotNull("Result should not be null", result);
                                                                             assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                             
                                                                             // Additional verification to catch the mutant
                                                                             ArArchiveInputStream arStream = (ArArchiveInputStream) result;
                                                                             try {
                                                                                 // This is a bit tricky since ArArchiveInputStream doesn't expose its input stream
                                                                                 // We'll use reflection to verify the internal stream is our mock
                                                                                 java.lang.reflect.Field inField = ArArchiveInputStream.class.getDeclaredField("in");
                                                                                 inField.setAccessible(true);
                                                                                 InputStream internalStream = (InputStream) inField.get(arStream);
                                                                                 assertEquals("Input stream should be the one we provided", 
                                                                                             mockInputStream, internalStream);
                                                                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                 fail("Failed to verify internal stream: " + e.getMessage());
                                                                             }
                                                                         }

    @Test
                                                                     public void testCreateArArchiveInputStreamWithValidStream2() throws Exception {
                                                                         // Prepare test data
                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                         
                                                                         // Call the method
                                                                         Object result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                         
                                                                         // Verify the result
                                                                         assertNotNull("Result should not be null", result);
                                                                         assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                         
                                                                         // The mutant would pass null to ArArchiveInputStream constructor which would likely
                                                                         // cause it to throw an exception or fail later. We can verify the stream is usable
                                                                         // by attempting to read (though this depends on ArArchiveInputStream implementation)
                                                                         try {
                                                                             ((ArArchiveInputStream)result).read();
                                                                             // If we get here, the stream was probably properly initialized
                                                                         } catch (NullPointerException e) {
                                                                             fail("ArArchiveInputStream was created with null input stream (mutant behavior)");
                                                                         }
                                                                     }

    @Test
                                                    public void testCreateArchiveInputStreamForArFormat() throws Exception {
                                                        // Prepare AR signature
                                                        byte[] arSignature = new byte[12];
                                                        // AR signature starts with "!<arch>\n" (8 bytes) followed by file information
                                                        System.arraycopy("!<arch>\n".getBytes(), 0, arSignature, 0, 8);
                                                        
                                                        // Create a mock input stream that returns the AR signature
                                                        InputStream mockIn = mock(InputStream.class);
                                                        when(mockIn.markSupported()).thenReturn(true);
                                                        when(mockIn.read(any(byte[].class)))
                                                            .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                @Override
                                                                public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                    byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                    System.arraycopy(arSignature, 0, buf, 0, Math.min(arSignature.length, buf.length));
                                                                    return Math.min(arSignature.length, buf.length);
                                                                }
                                                            });
                                                        
                                                        // Create factory instance
                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                        
                                                        // Call the method
                                                        ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                        
                                                        // Verify the result is an AR archive stream
                                                        assertTrue(result instanceof ArArchiveInputStream);
                                                        
                                                        // Verify the stream was created with the original input stream (not null)
                                                        // We can do this by checking if we can read from it without NPE
                                                        try {
                                                            result.read();
                                                            // If we get here, the stream was properly initialized
                                                        } catch (NullPointerException e) {
                                                            fail("AR archive stream was initialized with null input");
                                                        }
                                                        
                                                        // Clean up
                                                        result.close();
                                                    }

    @Test
                                                    public void testCreateArchiveInputStreamAR() throws Exception {
                                                        // AR format doesn't support encoding, should always use simple constructor
                                                        InputStream inputStream = mock(InputStream.class);
                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                        
                                                        Object stream = factory.createArchiveInputStream(ArchiveStreamFactory.AR, inputStream);
                                                        assertNotNull(stream);
                                                        assertEquals(ArArchiveInputStream.class, stream.getClass());
                                                        
                                                        // Should work the same with null encoding
                                                        factory.setEntryEncoding(null);
                                                        stream = factory.createArchiveInputStream(ArchiveStreamFactory.AR, inputStream);
                                                        assertNotNull(stream);
                                                        assertEquals(ArArchiveInputStream.class, stream.getClass());
                                                    }

    @Test
                                           public void testCreateArchiveInputStreamWithEncoding() throws Exception {
                                               // Setup mock input stream that identifies as ZIP format
                                               InputStream mockIn = mock(InputStream.class);
                                               when(mockIn.markSupported()).thenReturn(true);
                                               
                                               // Mock the signature reading behavior
                                               byte[] zipSignature = new byte[] {(byte)0x50, (byte)0x4B, (byte)0x03, (byte)0x04}; // ZIP signature
                                               when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                   System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                   return zipSignature.length;
                                               });
                                               
                                               // Set non-null encoding
                                               String testEncoding = "UTF-8";
                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                               factory.setEntryEncoding(testEncoding);
                                               
                                               // First test - ZIP format
                                               ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                               assertTrue(result instanceof ZipArchiveInputStream);
                                               Field encodingField = ZipArchiveInputStream.class.getDeclaredField("encoding");
                                               encodingField.setAccessible(true);
                                               assertEquals(testEncoding, encodingField.get(result));
                                               
                                               // Reset mock for second test
                                               reset(mockIn);
                                               when(mockIn.markSupported()).thenReturn(true);
                                               when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                   System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                   return zipSignature.length;
                                               });
                                               
                                               // Second test - JAR format
                                               result = factory.createArchiveInputStream(mockIn);
                                               assertTrue(result instanceof JarArchiveInputStream);
                                               encodingField = JarArchiveInputStream.class.getDeclaredField("encoding");
                                               encodingField.setAccessible(true);
                                               assertEquals(testEncoding, encodingField.get(result));
                                               
                                               // Reset mock for third test
                                               reset(mockIn);
                                               when(mockIn.markSupported()).thenReturn(true);
                                               when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                   System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                   return zipSignature.length;
                                               });
                                               
                                               // Third test - CPIO format
                                               result = factory.createArchiveInputStream(mockIn);
                                               assertTrue(result instanceof CpioArchiveInputStream);
                                               encodingField = CpioArchiveInputStream.class.getDeclaredField("encoding");
                                               encodingField.setAccessible(true);
                                               assertEquals(testEncoding, encodingField.get(result));
                                               
                                               // Reset mock for fourth test
                                               reset(mockIn);
                                               when(mockIn.markSupported()).thenReturn(true);
                                               when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                   System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                   return zipSignature.length;
                                               });
                                               
                                               // Fourth test - ARJ format
                                               result = factory.createArchiveInputStream(mockIn);
                                               assertTrue(result instanceof ArjArchiveInputStream);
                                               encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                               encodingField.setAccessible(true);
                                               assertEquals(testEncoding, encodingField.get(result));
                                           }

    @Test
                                       public void testCreateArchiveInputStreamWithEncoding1() throws Exception {
                                           // Define format constants locally
                                           final String ARJ = "arj";
                                           final String ZIP = "zip";
                                           final String TAR = "tar";
                                           final String JAR = "jar";
                                           final String CPIO = "cpio";
                                           final String DUMP = "dump";
                                           
                                           // Setup
                                           InputStream inputStream = mock(InputStream.class);
                                           String encoding = "UTF-8";
                                           ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                           
                                           // Test each archive format that supports encoding
                                           ArchiveInputStream arjStream = factory.createArchiveInputStream(ARJ, inputStream);
                                           assertTrue(arjStream instanceof org.apache.commons.compress.archivers.arj.ArjArchiveInputStream);
                                           
                                           ArchiveInputStream zipStream = factory.createArchiveInputStream(ZIP, inputStream);
                                           assertTrue(zipStream instanceof org.apache.commons.compress.archivers.zip.ZipArchiveInputStream);
                                           
                                           ArchiveInputStream tarStream = factory.createArchiveInputStream(TAR, inputStream);
                                           assertTrue(tarStream instanceof org.apache.commons.compress.archivers.tar.TarArchiveInputStream);
                                           
                                           ArchiveInputStream jarStream = factory.createArchiveInputStream(JAR, inputStream);
                                           assertTrue(jarStream instanceof org.apache.commons.compress.archivers.jar.JarArchiveInputStream);
                                           
                                           ArchiveInputStream cpioStream = factory.createArchiveInputStream(CPIO, inputStream);
                                           assertTrue(cpioStream instanceof org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream);
                                           
                                           ArchiveInputStream dumpStream = factory.createArchiveInputStream(DUMP, inputStream);
                                           assertTrue(dumpStream instanceof org.apache.commons.compress.archivers.dump.DumpArchiveInputStream);
                                       }

    @Test
                          public void testCreateArjArchiveInputStreamWithCustomEncoding1() throws Exception {
                              // Setup
                              String testEncoding = "ISO-8859-1";
                              ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                              
                              // Create a mock input stream that will be recognized as ARJ
                              InputStream mockIn = mock(InputStream.class);
                              when(mockIn.markSupported()).thenReturn(true);
                              
                              // ARJ signature bytes
                              byte[] arjSignature = new byte[] { 
                                  (byte) 0x60, (byte) 0xEA, // ARJ magic number
                                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 // padding to 12 bytes
                              };
                              
                              // Mock the behavior for signature reading
                              when(IOUtils.readFully(mockIn, any(byte[].class))).thenAnswer(invocation -> {
                                  byte[] buffer = (byte[]) invocation.getArguments()[0];
                                  System.arraycopy(arjSignature, 0, buffer, 0, Math.min(arjSignature.length, buffer.length));
                                  return arjSignature.length;
                              });
                           
                              // Test
                              ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                              
                              // Verify
                              assertTrue(result instanceof ArjArchiveInputStream);
                              assertEquals(testEncoding, factory.getEntryEncoding());
                              
                              // Clean up
                              result.close();
                          }

    @Test
                      public void testCreateArjArchiveInputStreamWithCustomEncoding2() throws Exception {
                          // Setup
                          String testEncoding = "ISO-8859-1";
                          InputStream mockInputStream = mock(InputStream.class);
                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                          factory.setEntryEncoding(testEncoding);
                          
                          // Test
                          ArchiveInputStream result = factory.createArchiveInputStream("arj", mockInputStream);
                          
                          // Verify
                          assertTrue(result instanceof ArjArchiveInputStream);
                          // Verify the factory's encoding was set correctly
                          assertEquals(testEncoding, factory.getEntryEncoding());
                          
                          // Clean up
                          result.close();
                      }

    @Test
                      public void testCreateArjArchiveInputStreamWithoutEncodingUsesCorrectStream() throws Exception {
                          // Setup
                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                          InputStream mockInputStream = mock(InputStream.class);
                          
                          // Test
                          ArjArchiveInputStream result = (ArjArchiveInputStream) factory.createArchiveInputStream(
                              ArchiveStreamFactory.ARJ, mockInputStream);
                          
                          // Verify the created ArjArchiveInputStream is using our mock input stream
                          // This would fail for the mutant which passes null instead
                          assertNotNull("InputStream should not be null", result);
                          
                          // Additional verification that the stream is actually our mock
                          // This would throw NullPointerException for the mutant
                          try {
                              result.read();
                              verify(mockInputStream, atLeastOnce()).read();
                          } catch (NullPointerException e) {
                              fail("NullPointerException indicates the mutant was not caught");
                          }
                      }

    @Test
                 public void testCreateArchiveInputStreamForArjWithValidStream() throws Exception {
                     // Prepare ARJ signature bytes
                     byte[] arjSignature = new byte[12];
                     // ARJ signature starts with ARJ in first 3 bytes
                     arjSignature[0] = 'A';
                     arjSignature[1] = 'R';
                     arjSignature[2] = 'J';
                     
                     // Create mock input stream that supports mark/reset and returns ARJ signature
                     InputStream mockIn = mock(InputStream.class);
                     when(mockIn.markSupported()).thenReturn(true);
                     when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                         byte[] buf = (byte[]) invocation.getArguments()[0];
                         System.arraycopy(arjSignature, 0, buf, 0, Math.min(arjSignature.length, buf.length));
                         return arjSignature.length;
                     });
                     
                     // Create factory instance
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     
                     // Test the method
                     ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                     
                     // Verify the result is an ARJ archive stream
                     assertTrue(result instanceof ArjArchiveInputStream);
                     
                     // Verify the stream works by attempting to read (would fail if constructed with null)
                     try {
                         result.read();
                         // If we get here, the stream was properly constructed with our input stream
                     } catch (NullPointerException e) {
                         fail("ARJ archive stream was constructed with null input stream");
                     }
                     
                     // Verify the mock input stream was used properly
                     verify(mockIn, atLeastOnce()).mark(anyInt());
                     verify(mockIn, atLeastOnce()).reset();
                 }

    @Test
                 public void testCreateArchiveInputStream_SevenZ_ShouldThrowException() throws Exception {
                     // Arrange
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     InputStream mockInputStream = mock(InputStream.class);
                     
                     // Set expectation for the exception
                     thrown.expect(StreamingNotSupportedException.class);
                     thrown.expectMessage(ArchiveStreamFactory.SEVEN_Z);
                     
                     // Act
                     factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, mockInputStream);
                     
                     // Assert - exception is expected to be thrown
                 }

    @Test
                 public void testCreateArchiveInputStream_SevenZ_WithEncoding_ShouldThrowException() throws Exception {
                     // Arrange
                     ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                     InputStream mockInputStream = mock(InputStream.class);
                     
                     // Set expectation for the exception
                     thrown.expect(StreamingNotSupportedException.class);
                     thrown.expectMessage(ArchiveStreamFactory.SEVEN_Z);
                     
                     // Act
                     factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, mockInputStream);
                     
                     // Assert - exception is expected to be thrown
                 }

    @Test(expected = StreamingNotSupportedException.class)
    public void testCreateArchiveInputStream_SevenZSignature_ShouldThrowException1() throws Exception {
        // Arrange
        byte[] sevenZSignature = new byte[12];
        // Setup SevenZ signature (first 6 bytes are '7z' followed by 0xBC, 0xAF, 0x27, 0x1C)
        sevenZSignature[0] = '7';
        sevenZSignature[1] = 'z';
        sevenZSignature[2] = (byte) 0xBC;
        sevenZSignature[3] = (byte) 0xAF;
        sevenZSignature[4] = (byte) 0x27;
        sevenZSignature[5] = (byte) 0x1C;
        
        InputStream mockInput = mock(InputStream.class);
        when(mockInput.markSupported()).thenReturn(true);
        when(IOUtils.readFully(mockInput, any(byte[].class)))
            .thenAnswer(invocation -> {
                byte[] buf = invocation.getArgumentAt(0, byte[].class);
                System.arraycopy(sevenZSignature, 0, buf, 0, Math.min(sevenZSignature.length, buf.length));
                return sevenZSignature.length;
            });
        
        ArchiveStreamFactory factory = new ArchiveStreamFactory();
        
        // Act - should throw StreamingNotSupportedException
        factory.createArchiveInputStream(mockInput);
        
        // Assert - handled by @Test(expected)
    }


}
