package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.util.zip.ZipException;
 
public class Zip64ExtendedInformationExtraFieldTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                 public void testReparseCentralDirectoryData_OnlySizes() throws Exception {
                                                                                     final int DWORD = 8; // size of long in bytes
                                                                                     final int WORD = 4;  // size of int in bytes
                                                                                     
                                                                                     byte[] data = new byte[DWORD*2];
                                                                                     System.arraycopy(new ZipEightByteInteger(100L).getBytes(), 0, data, 0, DWORD);
                                                                                     System.arraycopy(new ZipEightByteInteger(200L).getBytes(), 0, data, DWORD, DWORD);
                                                                                     
                                                                                     Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                     
                                                                                     // Use reflection to set private field
                                                                                     Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                     rawDataField.setAccessible(true);
                                                                                     rawDataField.set(field, data);
                                                                                     
                                                                                     field.reparseCentralDirectoryData(true, true, false, false);
                                                                                     
                                                                                     assertEquals(100L, field.getSize().getLongValue());
                                                                                     assertEquals(200L, field.getCompressedSize().getLongValue());
                                                                                     assertNull(field.getRelativeHeaderOffset());
                                                                                     assertNull(field.getDiskStartNumber());
                                                                                 }

 @Test
                                                                                 public void testReparseCentralDirectoryData_InvalidLength() throws Exception {
                                                                                     final int DWORD = 8; // Define DWORD constant
                                                                                     byte[] shortData = new byte[DWORD-1]; // Too short for even one DWORD field
                                                                                     
                                                                                     thrown.expect(ZipException.class);
                                                                                     thrown.expectMessage("central directory zip64 extended information extra field's length doesn't match central directory data.");
                                                                                     
                                                                                     Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                     // Use reflection to set private field
                                                                                     Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                     rawDataField.setAccessible(true);
                                                                                     rawDataField.set(field, shortData);
                                                                                     
                                                                                     field.reparseCentralDirectoryData(true, false, false, false);
                                                                                 }

 @Test
                                                                                 public void testReparseCentralDirectoryData_NoFields() throws Exception {
                                                                                     byte[] data = new byte[0];
                                                                                     
                                                                                     Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                     
                                                                                     // Use reflection to set private field
                                                                                     Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class
                                                                                             .getDeclaredField("rawCentralDirectoryData");
                                                                                     rawCentralDirectoryDataField.setAccessible(true);
                                                                                     rawCentralDirectoryDataField.set(field, data);
                                                                                     
                                                                                     field.reparseCentralDirectoryData(false, false, false, false);
                                                                                     
                                                                                     assertNull(field.getSize());
                                                                                     assertNull(field.getCompressedSize());
                                                                                     assertNull(field.getRelativeHeaderOffset());
                                                                                     assertNull(field.getDiskStartNumber());
                                                                                 }

 @Test
                                                                             public void testReparseCentralDirectoryData_EdgeCaseValues() throws Exception {
                                                                                 final int DWORD = 8; // size of long
                                                                                 final int WORD = 4;  // size of int
                                                                                 
                                                                                 byte[] data = new byte[DWORD*2 + WORD];
                                                                                 // Max and min values
                                                                                 System.arraycopy(new ZipEightByteInteger(Long.MAX_VALUE).getBytes(), 0, data, 0, DWORD);
                                                                                 System.arraycopy(new ZipEightByteInteger(Long.MIN_VALUE).getBytes(), 0, data, DWORD, DWORD);
                                                                                 System.arraycopy(new ZipLong(Integer.MAX_VALUE).getBytes(), 0, data, DWORD*2, WORD);
                                                                                 
                                                                                 Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                 // Use reflection to set private field
                                                                                 Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                 rawDataField.setAccessible(true);
                                                                                 rawDataField.set(field, data);
                                                                                 
                                                                                 field.reparseCentralDirectoryData(true, true, false, true);
                                                                                 
                                                                                 assertEquals(Long.MAX_VALUE, field.getSize().getLongValue());
                                                                                 assertEquals(Long.MIN_VALUE, field.getCompressedSize().getLongValue());
                                                                                 assertNotNull(field.getDiskStartNumber());
                                                                                 assertEquals(Integer.MAX_VALUE, field.getDiskStartNumber().getValue());
                                                                             }

 @Test
                                                                         public void testReparseCentralDirectoryData_OnlyDiskStart() throws Exception {
                                                                             final int WORD = 4;
                                                                             
                                                                             byte[] data = new byte[WORD];
                                                                             System.arraycopy(new ZipLong(99).getBytes(), 0, data, 0, WORD);
                                                                             
                                                                             Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                             
                                                                             try {
                                                                                 // Use reflection to set private field
                                                                                 Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                 rawDataField.setAccessible(true);
                                                                                 rawDataField.set(field, data);
                                                                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                 fail("Failed to set rawCentralDirectoryData via reflection: " + e.getMessage());
                                                                             }
                                                                             
                                                                             field.reparseCentralDirectoryData(false, false, false, true);
                                                                             
                                                                             assertNull(field.getSize());
                                                                             assertNull(field.getCompressedSize());
                                                                             assertNull(field.getRelativeHeaderOffset());
                                                                             assertNotNull(field.getDiskStartNumber());
                                                                             assertEquals(99L, field.getDiskStartNumber().getValue());
                                                                         }

 @Test
                                                                     public void testReparseCentralDirectoryData_AllFieldsPresent() throws Exception {
                                                                         // Define constants
                                                                         final int DWORD = 8; // size of long in bytes
                                                                         final int WORD = 4;  // size of int in bytes
                                                                         
                                                                         // Create test data
                                                                         byte[] data = new byte[DWORD*3 + WORD];
                                                                         // Set test values
                                                                         System.arraycopy(new org.apache.commons.compress.archivers.zip.ZipEightByteInteger(123456789L).getBytes(), 
                                                                                         0, data, 0, DWORD);
                                                                         System.arraycopy(new org.apache.commons.compress.archivers.zip.ZipEightByteInteger(987654321L).getBytes(), 
                                                                                         0, data, DWORD, DWORD);
                                                                         System.arraycopy(new org.apache.commons.compress.archivers.zip.ZipEightByteInteger(555555555L).getBytes(), 
                                                                                         0, data, DWORD*2, DWORD);
                                                                         System.arraycopy(new org.apache.commons.compress.archivers.zip.ZipLong(42).getBytes(), 
                                                                                         0, data, DWORD*3, WORD);
                                                                         
                                                                         // Create field and set data via reflection
                                                                         org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField field = 
                                                                             new org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField();
                                                                         java.lang.reflect.Field rawDataField = org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField.class
                                                                             .getDeclaredField("rawCentralDirectoryData");
                                                                         rawDataField.setAccessible(true);
                                                                         rawDataField.set(field, data);
                                                                         
                                                                         // Test the method
                                                                         field.reparseCentralDirectoryData(true, true, true, true);
                                                                         
                                                                         // Verify results
                                                                         assertEquals(123456789L, field.getSize().getLongValue());
                                                                         assertEquals(987654321L, field.getCompressedSize().getLongValue());
                                                                         assertEquals(555555555L, field.getRelativeHeaderOffset().getLongValue());
                                                                         assertEquals(42, field.getDiskStartNumber().getValue());
                                                                     }

 @Test
                                         public void testReparseCentralDirectoryData_NullData() {
                                             Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                             try {
                                                 field.reparseCentralDirectoryData(true, true, true, true);
                                             } catch (ZipException e) {
                                                 fail("Should not throw ZipException for null data");
                                             }
                                             // Should not throw any exception
                                             assertNull(field.getSize());
                                             assertNull(field.getCompressedSize());
                                             assertNull(field.getRelativeHeaderOffset());
                                             assertNull(field.getDiskStartNumber());
                                         }

 @Test
 public void testReparseCentralDirectoryData_DetectsOffsetMutation() throws Exception {
     // Setup test data with both diskStart and relativeHeaderOffset
     byte[] testData = new byte[16]; // DWORD (8) + DWORD (8)
     System.arraycopy(new byte[]{1,2,3,4,5,6,7,8}, 0, testData, 0, 8); // diskStart
     System.arraycopy(new byte[]{9,10,11,12,13,14,15,16}, 0, testData, 8, 8); // relativeHeaderOffset
     
     Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
     
     // Use reflection to set private field for testing
     Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
     rawDataField.setAccessible(true);
     rawDataField.set(field, testData);
     
     // Call method with both diskStart and relativeHeaderOffset true
     field.reparseCentralDirectoryData(false, false, true, true);
     
     // Verify diskStart was read correctly (first 4 bytes)
     ZipLong diskStart = field.getDiskStartNumber();
     byte[] diskStartBytes = diskStart.getBytes();
     assertEquals(1, diskStartBytes[0]);
     assertEquals(2, diskStartBytes[1]);
     assertEquals(3, diskStartBytes[2]);
     assertEquals(4, diskStartBytes[3]);
     
     // Verify relativeHeaderOffset was read from correct position (bytes 8-15)
     // This will fail with mutation since it would read from bytes 2-9 instead
     ZipEightByteInteger rho = field.getRelativeHeaderOffset();
     byte[] rhoBytes = rho.getBytes();
     assertEquals(9, rhoBytes[0]);
     assertEquals(10, rhoBytes[1]);
     assertEquals(11, rhoBytes[2]);
     assertEquals(12, rhoBytes[3]);
     assertEquals(13, rhoBytes[4]);
     assertEquals(14, rhoBytes[5]);
     assertEquals(15, rhoBytes[6]);
     assertEquals(16, rhoBytes[7]);
 }

}
