package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                             public void testGetNextZipEntry_ClosedStream_ReturnsNull() throws Exception {
                                                 // Arrange
                                                 InputStream mockInputStream = mock(InputStream.class);
                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                 
                                                 // Act
                                                 zais.close();
                                                 
                                                 // Assert
                                                 assertNull(zais.getNextZipEntry());
                                             }

 @Test
                                             public void testGetNextZipEntry_HitCentralDirectory_ReturnsNull() throws Exception {
                                                 InputStream mockInputStream = mock(InputStream.class);
                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                 
                                                 // Set hitCentralDirectory to true through reflection
                                                 Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                                 hitCentralDirectoryField.setAccessible(true);
                                                 hitCentralDirectoryField.set(zais, true);
                                                 
                                                 assertNull(zais.getNextZipEntry());
                                             }

 @Test
                                             public void testGetNextZipEntry_InvalidSignature_ReturnsNull() throws Exception {
                                                 byte[] invalidSig = new byte[4];
                                                 System.arraycopy(new byte[]{1, 2, 3, 4}, 0, invalidSig, 0, 4);
                                                 
                                                 InputStream mockInputStream = new ByteArrayInputStream(invalidSig);
                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                 
                                                 assertNull(zais.getNextZipEntry());
                                             }

 @Test
                                             public void testGetNextZipEntry_WithDataDescriptor_Success() throws Exception {
                                                 // Define local constants that would normally be class fields
                                                 final byte[] LFH_SIG = new byte[] {0x50, 0x4b, 0x03, 0x04}; // Local file header signature
                                                 
                                                 byte[] mockLfh = new byte[30];
                                                 System.arraycopy(LFH_SIG, 0, mockLfh, 0, 4);
                                                 // Set version made by
                                                 mockLfh[4] = 0;
                                                 mockLfh[5] = 0;
                                                 // Set general purpose bit flag (with data descriptor)
                                                 mockLfh[6] = 8; // Bit 3 set for data descriptor
                                                 mockLfh[7] = 0;
                                                 // Set compression method (STORED)
                                                 mockLfh[8] = 0;
                                                 mockLfh[9] = 0;
                                                 // Set DOS time
                                                 System.arraycopy(ZipLong.getBytes(0), 0, mockLfh, 10, 4);
                                                 // Skip CRC, compressed size, uncompressed size (all zero)
                                                 // Set file name length (5)
                                                 System.arraycopy(ZipShort.getBytes(5), 0, mockLfh, 26, 2);
                                                 // Set extra field length (0)
                                                 System.arraycopy(ZipShort.getBytes(0), 0, mockLfh, 28, 2);
                                                 
                                                 // Build the mock input stream as a sequence of all required parts
                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                 baos.write(mockLfh);
                                                 baos.write("test1".getBytes());
                                                 baos.write(ZipLong.DD_SIG.getBytes());
                                                 baos.write(ZipLong.getBytes(1234)); // CRC
                                                 baos.write(ZipLong.getBytes(10)); // Compressed size
                                                 baos.write(ZipLong.getBytes(10)); // Uncompressed size
                                                 
                                                 InputStream mockInputStream = new ByteArrayInputStream(baos.toByteArray());
                                                 
                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, "UTF-8", true, true);
                                                 ZipArchiveEntry entry = zais.getNextZipEntry();
                                                 
                                                 assertNotNull(entry);
                                                 assertEquals("test1", entry.getName());
                                                 assertEquals(1234, entry.getCrc());
                                                 assertEquals(10, entry.getSize());
                                             }

 @Test
                                     public void testGetNextZipEntry_CentralDirectorySignature_SetsHitCentralDirectory() throws Exception {
                                         // Central Directory Header signature (CFH_SIG)
                                         byte[] CFH_SIG = new byte[] {0x50, 0x4b, 0x01, 0x02};
                                         ByteArrayInputStream mockInputStream = new ByteArrayInputStream(CFH_SIG);
                                         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                         
                                         assertNull(zais.getNextZipEntry());
                                         
                                         // Use reflection to check the internal hitCentralDirectory flag
                                         Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                         hitCentralDirectoryField.setAccessible(true);
                                         boolean hitCentralDirectory = hitCentralDirectoryField.getBoolean(zais);
                                         assertTrue(hitCentralDirectory);
                                     }

 @Test
                                     public void testGetNextZipEntry_NonFirstEntry_Success() throws Exception {
                                         // First create a mock stream with two entries
                                         
                                         // Create first mock entry
                                         String name1 = "entry1";
                                         byte[] nameBytes1 = name1.getBytes();
                                         byte[] mockLfh1 = new byte[30 + nameBytes1.length];
                                         // Signature
                                         mockLfh1[0] = (byte) 0x50; mockLfh1[1] = (byte) 0x4b; mockLfh1[2] = (byte) 0x03; mockLfh1[3] = (byte) 0x04;
                                         // Version needed to extract
                                         mockLfh1[4] = 20; mockLfh1[5] = 0;
                                         // General purpose bit flag
                                         mockLfh1[6] = 0; mockLfh1[7] = 0;
                                         // Compression method
                                         mockLfh1[8] = 0; mockLfh1[9] = 0;
                                         // Last mod file time
                                         mockLfh1[10] = 0; mockLfh1[11] = 0;
                                         // Last mod file date
                                         mockLfh1[12] = 0; mockLfh1[13] = 0;
                                         // CRC-32
                                         mockLfh1[14] = 0; mockLfh1[15] = 0; mockLfh1[16] = 0; mockLfh1[17] = 0;
                                         // Compressed size
                                         mockLfh1[18] = 10; mockLfh1[19] = 0; mockLfh1[20] = 0; mockLfh1[21] = 0;
                                         // Uncompressed size
                                         mockLfh1[22] = 10; mockLfh1[23] = 0; mockLfh1[24] = 0; mockLfh1[25] = 0;
                                         // File name length
                                         mockLfh1[26] = (byte) (nameBytes1.length & 0xff);
                                         mockLfh1[27] = (byte) ((nameBytes1.length >> 8) & 0xff);
                                         // Extra field length
                                         mockLfh1[28] = 0; mockLfh1[29] = 0;
                                         // File name
                                         System.arraycopy(nameBytes1, 0, mockLfh1, 30, nameBytes1.length);
                                         
                                         // Create second mock entry
                                         String name2 = "entry2";
                                         byte[] nameBytes2 = name2.getBytes();
                                         byte[] mockLfh2 = new byte[30 + nameBytes2.length];
                                         // Signature
                                         mockLfh2[0] = (byte) 0x50; mockLfh2[1] = (byte) 0x4b; mockLfh2[2] = (byte) 0x03; mockLfh2[3] = (byte) 0x04;
                                         // Version needed to extract
                                         mockLfh2[4] = 20; mockLfh2[5] = 0;
                                         // General purpose bit flag
                                         mockLfh2[6] = 0; mockLfh2[7] = 0;
                                         // Compression method
                                         mockLfh2[8] = 0; mockLfh2[9] = 0;
                                         // Last mod file time
                                         mockLfh2[10] = 0; mockLfh2[11] = 0;
                                         // Last mod file date
                                         mockLfh2[12] = 0; mockLfh2[13] = 0;
                                         // CRC-32
                                         mockLfh2[14] = 0; mockLfh2[15] = 0; mockLfh2[16] = 0; mockLfh2[17] = 0;
                                         // Compressed size
                                         mockLfh2[18] = 20; mockLfh2[19] = 0; mockLfh2[20] = 0; mockLfh2[21] = 0;
                                         // Uncompressed size
                                         mockLfh2[22] = 20; mockLfh2[23] = 0; mockLfh2[24] = 0; mockLfh2[25] = 0;
                                         // File name length
                                         mockLfh2[26] = (byte) (nameBytes2.length & 0xff);
                                         mockLfh2[27] = (byte) ((nameBytes2.length >> 8) & 0xff);
                                         // Extra field length
                                         mockLfh2[28] = 0; mockLfh2[29] = 0;
                                         // File name
                                         System.arraycopy(nameBytes2, 0, mockLfh2, 30, nameBytes2.length);
                                         
                                         // Create combined input stream
                                         java.io.SequenceInputStream mockInputStream = new java.io.SequenceInputStream(
                                             new java.io.SequenceInputStream(
                                                 new java.io.ByteArrayInputStream(mockLfh1),
                                                 new java.io.ByteArrayInputStream("entry1".getBytes())
                                             ),
                                             new java.io.SequenceInputStream(
                                                 new java.io.ByteArrayInputStream(mockLfh2),
                                                 new java.io.ByteArrayInputStream("entry2".getBytes())
                                             )
                                         );
                                         
                                         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                         
                                         // Read first entry
                                         ZipArchiveEntry entry1 = zais.getNextZipEntry();
                                         assertNotNull(entry1);
                                         assertEquals("entry1", entry1.getName());
                                         
                                         // Read second entry
                                         ZipArchiveEntry entry2 = zais.getNextZipEntry();
                                         assertNotNull(entry2);
                                         assertEquals("entry2", entry2.getName());
                                     }

 @Test
                                 public void testGetNextZipEntry_FirstEntry_Success() throws Exception {
                                     // Import required classes (these would be at class level in actual file)
                                     // import org.apache.commons.compress.archivers.zip.ZipLong;
                                     // import org.apache.commons.compress.archivers.zip.ZipShort;
                                     // import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
                                     // import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
                                     // import java.io.ByteArrayInputStream;
                                     // import java.io.SequenceInputStream;
                                     
                                     // Create mock local file header
                                     byte[] mockLfh = new byte[30];
                                     System.arraycopy(ZipLong.LFH_SIG.getBytes(), 0, mockLfh, 0, 4);
                                     // Set version made by
                                     mockLfh[4] = 0;
                                     mockLfh[5] = 0;
                                     // Set general purpose bit flag (no UTF-8)
                                     mockLfh[6] = 0;
                                     mockLfh[7] = 0;
                                     // Set compression method (STORED)
                                     mockLfh[8] = 0;
                                     mockLfh[9] = 0;
                                     // Set DOS time
                                     System.arraycopy(ZipLong.getBytes(0), 0, mockLfh, 10, 4);
                                     // Set CRC
                                     System.arraycopy(ZipLong.getBytes(0), 0, mockLfh, 14, 4);
                                     // Set compressed size
                                     System.arraycopy(ZipLong.getBytes(10), 0, mockLfh, 18, 4);
                                     // Set uncompressed size
                                     System.arraycopy(ZipLong.getBytes(10), 0, mockLfh, 22, 4);
                                     // Set file name length (5)
                                     System.arraycopy(ZipShort.getBytes(5), 0, mockLfh, 26, 2);
                                     // Set extra field length (0)
                                     System.arraycopy(ZipShort.getBytes(0), 0, mockLfh, 28, 2);
                                     
                                     // Create input stream with header and file name
                                     ByteArrayInputStream mockInputStream = new ByteArrayInputStream(mockLfh);
                                     java.io.SequenceInputStream sequenceInputStream = new java.io.SequenceInputStream(
                                         mockInputStream,
                                         new ByteArrayInputStream("test1".getBytes())
                                     );
                                     
                                     // Test the method
                                     ZipArchiveInputStream zais = new ZipArchiveInputStream(sequenceInputStream);
                                     ZipArchiveEntry entry = zais.getNextZipEntry();
                                     
                                     // Assertions
                                     assertNotNull(entry);
                                     assertEquals("test1", entry.getName());
                                     assertEquals(10, entry.getSize());
                                     assertEquals(0, entry.getMethod());
                                 }

 @Test
                             public void testGetNextZipEntry_WithUTF8Flag_SetsCorrectEncoding() throws Exception {
                                 // Define required constants and variables
                                 byte[] LFH_SIG = new byte[] {0x50, 0x4b, 0x03, 0x04}; // PK.. signature
                                 InputStream mockInputStream;
                                 ZipArchiveInputStream zais;
                                 
                                 byte[] mockLfh = new byte[30];
                                 System.arraycopy(LFH_SIG, 0, mockLfh, 0, 4);
                                 // Set version made by
                                 mockLfh[4] = 0;
                                 mockLfh[5] = 0;
                                 // Set general purpose bit flag (UTF-8)
                                 mockLfh[6] = 0;
                                 mockLfh[7] = 8; // Bit 11 set for UTF-8
                                 // Set compression method (STORED)
                                 mockLfh[8] = 0;
                                 mockLfh[9] = 0;
                                 // Set DOS time
                                 System.arraycopy(new byte[4], 0, mockLfh, 10, 4);
                                 // Set CRC
                                 System.arraycopy(new byte[4], 0, mockLfh, 14, 4);
                                 // Set compressed size
                                 System.arraycopy(new byte[] {10, 0, 0, 0}, 0, mockLfh, 18, 4);
                                 // Set uncompressed size
                                 System.arraycopy(new byte[] {10, 0, 0, 0}, 0, mockLfh, 22, 4);
                                 // Set file name length (5)
                                 System.arraycopy(new byte[] {5, 0}, 0, mockLfh, 26, 2);
                                 // Set extra field length (0)
                                 System.arraycopy(new byte[] {0, 0}, 0, mockLfh, 28, 2);
                                 
                                 mockInputStream = new java.io.SequenceInputStream(
                                     new java.io.ByteArrayInputStream(mockLfh),
                                     new java.io.ByteArrayInputStream("test1".getBytes("UTF-8"))
                                 );
                                 
                                 zais = new ZipArchiveInputStream(mockInputStream, "ISO-8859-1");
                                 ZipArchiveEntry entry = zais.getNextZipEntry();
                                 
                                 assertNotNull(entry);
                                 assertEquals("test1", entry.getName());
                                 
                                 // Verify UTF-8 encoding is used when flag is set
                                 Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                 nameField.setAccessible(true);
                                 String actualName = (String) nameField.get(entry);
                                 assertEquals("test1", actualName);
                             }

 @Test
            public void testPushbackInputStreamBufferSize() throws Exception {
                // Create a mock input stream
                InputStream mockInputStream = mock(InputStream.class);
                
                // Create a buffer with capacity > 1024
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] largeBuffer = new byte[2048]; // Larger than mutant's 1024
                bos.write(largeBuffer);
                ByteBuffer buf = ByteBuffer.wrap(bos.toByteArray());
                
                // Create the ZipArchiveInputStream
                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                
                // Use reflection to access the private 'in' field
                Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
                inField.setAccessible(true);
                PushbackInputStream pbis = (PushbackInputStream) inField.get(zais);
                
                // Use reflection to get the buffer size from PushbackInputStream
                Field bufField = PushbackInputStream.class.getDeclaredField("buf");
                bufField.setAccessible(true);
                byte[] buffer = (byte[]) bufField.get(pbis);
                
                // Verify buffer size matches original behavior (buf.capacity())
                // rather than mutant's fixed 1024
                assertTrue("PushbackInputStream buffer size should be >= original buffer capacity", 
                          buffer.length >= largeBuffer.length);
            }

 @Test
            public void testConstructorBufferSize() throws Exception {
                // Create mock input stream
                InputStream mockInput = mock(InputStream.class);
                
                // Create instance with default encoding
                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput, "UTF-8", true, false);
                
                // Use reflection to access private 'in' field
                Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
                inField.setAccessible(true);
                PushbackInputStream pushbackIn = (PushbackInputStream) inField.get(zais);
                
                // Use reflection to get buffer size from PushbackInputStream
                Field bufField = PushbackInputStream.class.getDeclaredField("buf");
                bufField.setAccessible(true);
                byte[] buffer = (byte[]) bufField.get(pushbackIn);
                
                // Verify buffer size is not the mutated value (1024)
                // We can't know the exact expected size since buf.capacity() isn't shown,
                // but we can verify it's not the mutated value
                assertTrue("Buffer size should not be 1024", buffer.length != 1024);
                
                // Additional test with known buffer capacity
                // This would require knowing the buf implementation, but we can test with
                // a custom input stream that reports specific capacity
                // (This part is commented as it requires more context about 'buf')
                /*
                ByteBuffer customBuf = ByteBuffer.allocate(2048);
                when(buf.capacity()).thenReturn(2048);
                zais = new ZipArchiveInputStream(mockInput, "UTF-8", true, false);
                pushbackIn = (PushbackInputStream) inField.get(zais);
                buffer = (byte[]) bufField.get(pushbackIn);
                assertEquals(2048, buffer.length);
                */
            }

 @Test
        public void testConstructorInitializesPushbackStreamWithCorrectBufferSize() throws Exception {
            // Create a mock InputStream
            InputStream mockInput = mock(InputStream.class);
            
            // Create a ByteBuffer with specific capacity for testing
            int testCapacity = 4096; // Different from 1024 to detect mutant
            ByteBuffer buf = ByteBuffer.allocate(testCapacity);
            
            // Use reflection to test the private field
            ZipArchiveInputStream zis = new ZipArchiveInputStream(
                mockInput, "UTF-8", true, false);
            
            // Get the private 'in' field using reflection
            Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
            inField.setAccessible(true);
            PushbackInputStream pushbackIn = (PushbackInputStream) inField.get(zis);
            
            // Get the buffer field from PushbackInputStream using reflection
            Field bufField = PushbackInputStream.class.getDeclaredField("buf");
            bufField.setAccessible(true);
            byte[] internalBuffer = (byte[]) bufField.get(pushbackIn);
            
            // Assert the buffer size matches the expected capacity
            // This will fail for the mutant which uses 1024 instead of buf.capacity()
            assertEquals("PushbackInputStream buffer size should match buf.capacity()", 
                testCapacity, internalBuffer.length);
        }

 @Test
        public void testPushbackInputStreamBufferSize1() throws Exception {
            // Create a buffer with capacity different from 1024
            ByteBuffer buf = ByteBuffer.allocate(2048); // Using 2048 to be clearly different from 1024
            
            // Create mock input stream
            InputStream mockInputStream = mock(InputStream.class);
            
            // Create instance using reflection since buf is likely private
            Constructor<ZipArchiveInputStream> constructor = ZipArchiveInputStream.class.getDeclaredConstructor(
                InputStream.class, String.class, boolean.class, boolean.class);
            constructor.setAccessible(true);
            
            // Create instance with our buffer size
            ZipArchiveInputStream zais = constructor.newInstance(
                mockInputStream, "UTF-8", true, false);
            
            // Get the 'in' field using reflection
            Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
            inField.setAccessible(true);
            PushbackInputStream pbis = (PushbackInputStream) inField.get(zais);
            
            // Get the buffer field from PushbackInputStream
            Field bufField = PushbackInputStream.class.getDeclaredField("buf");
            bufField.setAccessible(true);
            byte[] buffer = (byte[]) bufField.get(pbis);
            
            // Verify buffer size matches buf.capacity() (2048) not 1024
            assertEquals("PushbackInputStream buffer size should match buf.capacity()", 
                2048, buffer.length);
            
            // Additional check to ensure we're testing the right thing
            assertNotEquals("Test should use buffer size different from 1024", 
                1024, buffer.length);
        }

 @Test
           public void testCompressedSizeZeroShouldBeAccepted() throws IOException {
               // Create a mock entry with compressed size = 0
               ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
               when(entry.getCompressedSize()).thenReturn(0L);
               
               // Create a minimal zip input stream (empty)
               byte[] emptyZip = new byte[] {80, 75, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
               ByteArrayInputStream bais = new ByteArrayInputStream(emptyZip);
               ZipArchiveInputStream zais = new ZipArchiveInputStream(bais);
               
               // Use reflection to set the current entry (since it's private)
               // This is a bit hacky but necessary to test the condition
               try {
                   java.lang.reflect.Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                   currentField.setAccessible(true);
                   Object current = new Object(); // This would normally be a CurrentEntry instance
                   
                   // Create a mock CurrentEntry class structure
                   Object currentEntry = mock(Object.class);
                   java.lang.reflect.Field entryField = currentEntry.getClass().getDeclaredField("entry");
                   entryField.setAccessible(true);
                   entryField.set(currentEntry, entry);
                   
                   currentField.set(zais, currentEntry);
                   
                   // Try to read the entry - should work with original, fail with mutant
                   zais.getNextZipEntry();
                   
                   // If we get here, the test passes (original behavior)
                   // The mutant would fail because it rejects size=0
               } catch (Exception e) {
                   throw new RuntimeException("Test setup failed", e);
               } finally {
                   zais.close();
               }
           }

 @Test
       public void testCompressedSizeCheckWithZeroLengthEntry() throws Exception {
           // Create mock objects
           InputStream mockInputStream = mock(InputStream.class);
           ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
           
           // Setup mock behavior
           when(mockEntry.getCompressedSize()).thenReturn(0L);
           
           // Create test instance - we need to use reflection to set up internal state
           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
           
           // Use reflection to set current entry since it's private
           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
           currentField.setAccessible(true);
           
           // Create and set current entry holder
           Object current = new Object(); // Actual type would be CurrentEntry but we'll mock the behavior
           Field entryField = current.getClass().getDeclaredField("entry");
           entryField.setAccessible(true);
           entryField.set(current, mockEntry);
           
           currentField.set(zais, current);
           
           // The actual test - try to read the entry
           // The mutant will behave differently for size=0
           try {
               // This method should handle zero-length entries properly
               zais.read(new byte[10], 0, 10);
               
               // If we get here, original behavior passed (which is correct)
               // The mutant would throw an exception or behave differently
           } catch (Exception e) {
               // The mutant would likely throw an exception here for size=0
               fail("Original implementation should handle zero-length entries, but threw: " + e);
           }
           
           // Additional verification for other cases
           when(mockEntry.getCompressedSize()).thenReturn(-1L);
           try {
               zais.read(new byte[10], 0, 10);
               fail("Should not be able to read entry with compressed size -1");
           } catch (Exception expected) {
               // Expected behavior for both original and mutant
           }
           
           when(mockEntry.getCompressedSize()).thenReturn(100L);
           try {
               zais.read(new byte[10], 0, 10);
               // Should pass for both original and mutant
           } catch (Exception e) {
               fail("Should be able to read entry with positive compressed size");
           }
       }

 @Test
           public void testCompressedSizeCheck() throws Exception {
               // Mock input stream
               InputStream mockInput = mock(InputStream.class);
               
               // Create entries with different compressed sizes
               ZipArchiveEntry sizeMinusOne = mock(ZipArchiveEntry.class);
               when(sizeMinusOne.getCompressedSize()).thenReturn(-1L);
               
               ZipArchiveEntry sizeZero = mock(ZipArchiveEntry.class);
               when(sizeZero.getCompressedSize()).thenReturn(0L);
               
               ZipArchiveEntry sizePositive = mock(ZipArchiveEntry.class);
               when(sizePositive.getCompressedSize()).thenReturn(100L);
               
               ZipArchiveEntry sizeNegative = mock(ZipArchiveEntry.class);
               when(sizeNegative.getCompressedSize()).thenReturn(-5L);
               
               // Create test instance
               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
               
               // Use reflection to set current entry since it's private
               // This is needed to test the internal behavior
               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
               currentField.setAccessible(true);
               
               // Test case 1: size = -1 (both versions should skip)
               currentField.set(zais, new Object[]{sizeMinusOne});
               // The actual test would depend on what the method does with the result,
               // but we can verify it doesn't process it as a normal entry
               
               // Test case 2: size = 0 (original processes, mutant skips)
               currentField.set(zais, new Object[]{sizeZero});
               // This is the key test case that would catch the mutant
               // Original would process, mutant would skip
               // Need to verify the behavior difference
               
               // Test case 3: size > 0 (both process)
               currentField.set(zais, new Object[]{sizePositive});
               // Both versions should process
               
               // Test case 4: size < -1 (original processes, mutant skips)
               currentField.set(zais, new Object[]{sizeNegative});
               // Original would process, mutant would skip
               
               // The exact assertions would depend on what the method does with these cases
               // For example, if it affects read operations, we would verify:
               // - For size 0: original would attempt to read, mutant would skip
               // - For size -5: original would attempt to read, mutant would skip
               // We could verify this by checking if certain methods are called or not
               
               // Since we can't see the full method, this is a general approach
               // The key is that testing with size=0 would catch the mutant
           }

 @Test
           public void testCompressedSizeCheckDetectsMutant() throws IOException {
               // Create test input stream (empty since we're testing behavior, not actual reading)
               ByteArrayInputStream emptyStream = new ByteArrayInputStream(new byte[0]);
               
               // Create the stream under test
               ZipArchiveInputStream zais = new ZipArchiveInputStream(emptyStream);
               
               // Mock a ZipArchiveEntry with compressedSize = -1
               ZipArchiveEntry entryWithUnknownSize = mock(ZipArchiveEntry.class);
               when(entryWithUnknownSize.getCompressedSize()).thenReturn(-1L);
               
               // Mock a ZipArchiveEntry with compressedSize = 0
               ZipArchiveEntry entryWithZeroSize = mock(ZipArchiveEntry.class);
               when(entryWithZeroSize.getCompressedSize()).thenReturn(0L);
               
               // Mock a ZipArchiveEntry with compressedSize > 0
               ZipArchiveEntry entryWithPositiveSize = mock(ZipArchiveEntry.class);
               when(entryWithPositiveSize.getCompressedSize()).thenReturn(100L);
               
               // The actual test would need to exercise the method containing the if statement
               // Since the method isn't shown, we'll assume it's in getNextZipEntry()
               // This is where we'd need to set up the current.entry field
               
               // For demonstration, we'll show what the test would look like if we could access the field
               // In reality, we might need reflection to set private fields or the class might need modification
               
               // The key point is that the test needs to verify different behavior when:
               // compressedSize is -1 (original treats specially, mutant doesn't)
               // compressedSize is 0 (both treat same)
               // compressedSize is positive (both treat same)
               
               // Since we can't see the actual method being mutated, this test serves as a template
               // that would need to be adapted to the actual class structure
               
               // Clean up
               zais.close();
           }

 @Test
         public void testConstructorBufferSize1() throws Exception {
             // Create mock objects
             InputStream mockInputStream = mock(InputStream.class);
             
             // Create a buffer with capacity larger than 1024
             ByteBuffer buf = ByteBuffer.allocate(2048);
             
             // Create instance of class under test using reflection to inject our buffer
             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, "UTF-8", true, false);
             
             // Use reflection to get the private 'in' field
             Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
             inField.setAccessible(true);
             PushbackInputStream pushbackIn = (PushbackInputStream) inField.get(zais);
             
             // Use reflection to get the buffer size from PushbackInputStream
             Field bufField = PushbackInputStream.class.getDeclaredField("buf");
             bufField.setAccessible(true);
             byte[] buffer = (byte[]) bufField.get(pushbackIn);
             
             // Verify buffer size is not the mutated value (1024)
             // Original behavior would use buf.capacity() which we set to 2048
             assertNotEquals("Buffer size should not be 1024 (mutated value)", 1024, buffer.length);
             assertEquals("Buffer size should match buf.capacity()", buf.capacity(), buffer.length);
         }

 @Test
         public void testPushbackInputStreamBufferSize2() throws Exception {
             // Prepare test data
             InputStream mockInputStream = mock(InputStream.class);
             String encoding = "UTF-8";
             boolean useUnicodeExtraFields = true;
             boolean allowStoredEntriesWithDataDescriptor = false;
             
             // Create instance
             ZipArchiveInputStream zais = new ZipArchiveInputStream(
                 mockInputStream, encoding, useUnicodeExtraFields, allowStoredEntriesWithDataDescriptor);
             
             // Use reflection to access private field 'in'
             Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
             inField.setAccessible(true);
             PushbackInputStream pushbackIn = (PushbackInputStream) inField.get(zais);
             
             // Use reflection to get the buffer size from PushbackInputStream
             Field bufField = PushbackInputStream.class.getDeclaredField("buf");
             bufField.setAccessible(true);
             byte[] buffer = (byte[]) bufField.get(pushbackIn);
             
             // Get the buffer capacity from the ZipArchiveInputStream's buf
             Field bufFieldZais = ZipArchiveInputStream.class.getDeclaredField("buf");
             bufFieldZais.setAccessible(true);
             ByteBuffer zaisBuffer = (ByteBuffer) bufFieldZais.get(zais);
             int expectedCapacity = zaisBuffer.capacity();
             
             // Assert that the PushbackInputStream's buffer size matches the expected capacity
             assertEquals("PushbackInputStream buffer size should match ByteBuffer capacity", 
                        expectedCapacity, buffer.length);
         }

 @Test
         public void testPushbackBufferSize() throws Exception {
             // Create a mock input stream
             InputStream mockInput = new ByteArrayInputStream(new byte[0]);
             
             // Create the ZipArchiveInputStream with a known buffer size
             ZipArchiveInputStream zais = new ZipArchiveInputStream(
                 mockInput, "UTF-8", true, false);
             
             // Use reflection to access the private 'in' field
             Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
             inField.setAccessible(true);
             PushbackInputStream pushbackIn = (PushbackInputStream) inField.get(zais);
             
             // Use reflection to get the buffer size from PushbackInputStream
             Field bufField = PushbackInputStream.class.getDeclaredField("buf");
             bufField.setAccessible(true);
             byte[] buffer = (byte[]) bufField.get(pushbackIn);
             
             // Get the internal buffer's capacity (should match original buffer size)
             Field bufFieldZais = ZipArchiveInputStream.class.getDeclaredField("buf");
             bufFieldZais.setAccessible(true);
             ByteBuffer internalBuf = (ByteBuffer) bufFieldZais.get(zais);
             int expectedCapacity = internalBuf.capacity();
             
             // Verify the pushback buffer size matches the internal buffer capacity
             assertEquals("Pushback buffer size should match internal buffer capacity", 
                        expectedCapacity, buffer.length);
             
             // Additional check to ensure it's not the mutated value (1024)
             assertNotEquals("Pushback buffer should not be fixed at 1024", 
                           1024, buffer.length);
         }

 @Test
     public void testPushbackInputStreamBufferSize3() throws Exception {
         // Create a ByteBuffer with capacity different from 1024
         ByteBuffer buf = ByteBuffer.allocate(2048); // Different from mutant's 1024
         InputStream mockInputStream = mock(InputStream.class);
         
         // Use reflection to replace the buf field in ZipArchiveInputStream
         Constructor<ZipArchiveInputStream> constructor = ZipArchiveInputStream.class
             .getDeclaredConstructor(InputStream.class, String.class, 
                                    boolean.class, boolean.class);
         constructor.setAccessible(true);
         
         // Create instance with our custom buffer size
         ZipArchiveInputStream zais = constructor.newInstance(
             mockInputStream, "UTF-8", true, false);
         
         Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
         bufField.setAccessible(true);
         bufField.set(zais, buf);
         
         Field inField = ZipArchiveInputStream.class.getDeclaredField("in");
         inField.setAccessible(true);
         PushbackInputStream pbis = (PushbackInputStream) inField.get(zais);
         
         // Verify buffer size matches buf.capacity() not 1024
         Field bufFieldInPushback = PushbackInputStream.class.getDeclaredField("buf");
         bufFieldInPushback.setAccessible(true);
         byte[] pushbackBuffer = (byte[]) bufFieldInPushback.get(pbis);
         
         assertEquals("PushbackInputStream buffer size should match buf.capacity()", 
                     buf.capacity(), pushbackBuffer.length);
     }

 @Test
    public void testPlatformDetectionFromZipHeader() throws Exception {
        // Create a test ZIP file in memory with known platform (Unix = 3)
        byte[] zipData = new byte[] {
            // Local file header signature
            0x50, 0x4B, 0x03, 0x04,
            // Version made by (Unix = 0x03 << 8)
            0x14, 0x03,
            // Rest of local file header (minimal valid header)
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        };
        
        InputStream inputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
        
        // Get the entry which should trigger platform setting
        ZipArchiveEntry entry = zis.getNextZipEntry();
        
        // Verify platform was correctly set from versionMadeBy
        // Original code should return 3 (Unix), mutant will return 0
        assertEquals("Platform should be extracted from versionMadeBy", 
                     3, entry.getPlatform());
        
        zis.close();
    }

 @Test
    public void testPlatformDetection() throws Exception {
        // Create a test zip file with known platform (Unix = 3)
        byte[] zipData = new byte[] {
            // Local file header signature
            0x50, 0x4B, 0x03, 0x04,
            // Version needed to extract (2.0)
            0x14, 0x00,
            // General purpose bit flag
            0x00, 0x00,
            // Compression method (stored)
            0x00, 0x00,
            // Last mod file time
            0x00, 0x00,
            // Last mod file date
            0x00, 0x00,
            // CRC-32
            0x00, 0x00, 0x00, 0x00,
            // Compressed size
            0x00, 0x00, 0x00, 0x00,
            // Uncompressed size
            0x00, 0x00, 0x00, 0x00,
            // File name length
            0x01, 0x00,
            // Extra field length
            0x00, 0x00,
            // File name
            'a',
            // Central directory header will contain platform info
            0x50, 0x4B, 0x01, 0x02,
            // Version made by (Unix = 3 << 8)
            0x00, 0x03,
            // Rest of central directory header...
            0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 'a',
            // End of central directory
            0x50, 0x4B, 0x05, 0x06, 0x00, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x01, 0x00, 0x3A, 0x00, 0x00, 0x00,
            0x2A, 0x00, 0x00, 0x00, 0x00, 0x00
        };
    
        InputStream inputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream, "UTF-8");
        
        // Get the entry which should trigger the platform setting
        ZipArchiveEntry entry = zis.getNextZipEntry();
        
        // Verify platform is correctly set (should be 3 for Unix)
        // The mutant would set this to 0
        assertEquals("Platform should be correctly detected from versionMadeBy", 
                    3, entry.getPlatform());
        
        zis.close();
    }

 @Test
    public void testPlatformDetectionFromZipHeader1() throws Exception {
        // Create a mock input stream that returns a ZIP header with UNIX platform (3 << 8)
        byte[] mockHeader = new byte[30]; // Local file header size
        // Set version made by to UNIX (3) in the upper byte
        mockHeader[4] = 3; // version made by lower byte (unused)
        mockHeader[5] = 3; // version made by upper byte (platform)
        
        InputStream mockStream = new ByteArrayInputStream(mockHeader);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(mockStream);
        
        // Get the first entry which should trigger header parsing
        ZipArchiveEntry entry = zis.getNextZipEntry();
        
        // Verify platform is correctly set from header (should be 3 for UNIX)
        // This will fail with the mutant which always sets platform to 0
        assertEquals("Platform should be detected from ZIP header", 
                     3, entry.getPlatform());
        
        zis.close();
    }

 @Test
    public void testEntryPlatformIsSetCorrectly() throws Exception {
        // Setup test data
        int testVersionMadeBy = 0x0300; // UNIX platform (3) in upper byte
        byte[] mockHeader = new byte[30]; // Minimum local file header size
        // Set version made by in the mock header (offset 4)
        mockHeader[4] = (byte)(testVersionMadeBy & 0xFF);
        mockHeader[5] = (byte)(testVersionMadeBy >> 8);
        
        // Mock input stream that will return our test header
        InputStream mockInput = new ByteArrayInputStream(mockHeader);
        
        // Create the stream under test
        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
        
        // Get the first entry which will trigger header processing
        ZipArchiveEntry entry = zais.getNextZipEntry();
        
        // Verify platform was set correctly
        // Original: (0x0300 >> 8) & 0xF = 3
        // Mutant: always 0
        assertEquals("Platform should be derived from versionMadeBy", 
                     3, entry.getPlatform());
        
        zais.close();
    }

 @Test
      public void testShouldStopWhenHitCentralDirectory() throws IOException {
          // Setup
          InputStream mockInputStream = mock(InputStream.class);
          ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
          
          // Use reflection to set internal state since these are private fields
          // This is necessary to simulate hitting central directory without closing
          try {
              java.lang.reflect.Field hitCentralDirectoryField = 
                  ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
              hitCentralDirectoryField.setAccessible(true);
              hitCentralDirectoryField.set(zis, true);
              
              java.lang.reflect.Field closedField = 
                  ZipArchiveInputStream.class.getDeclaredField("closed");
              closedField.setAccessible(true);
              closedField.set(zis, false);
          } catch (Exception e) {
              throw new RuntimeException("Failed to set internal state via reflection", e);
          }
          
          // Test behavior that should be affected by the condition
          // For example, trying to read next entry when we've hit central directory
          // Original code should return null, mutant would try to continue
          ArchiveEntry entry = zis.getNextEntry();
          
          // Assert that we get null when hitting central directory (original behavior)
          // The mutant would continue trying to read and might throw exception or return wrong value
          assertNull("Should return null when hitCentralDirectory is true", entry);
          
          // Verify no interaction with the stream since we should have stopped
          verify(mockInputStream, never()).read(any(byte[].class));
          verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
      }

 @Test
  public void testShouldStopWhenHitCentralDirectory1() throws Exception {
      // Create a mock input stream with minimal zip data
      byte[] minimalZip = new byte[] {
          // Local file header signature
          0x50, 0x4B, 0x03, 0x04,
          // Rest of minimal zip data...
      };
      InputStream mockInput = new ByteArrayInputStream(minimalZip);
      
      // Create the stream with our mock input
      ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
      
      // Simulate hitting central directory without closing
      // This would normally be set by internal processing
      Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
      hitCentralDirectoryField.setAccessible(true);
      hitCentralDirectoryField.set(zis, true);
      
      // Try to read next entry - should return null when hitCentralDirectory is true
      // The mutant would continue trying to read entries
      ArchiveEntry entry = zis.getNextEntry();
      
      assertNull("Should return null when hitCentralDirectory is true", entry);
      
      // Clean up
      zis.close();
  }

 @Test
      public void testHitCentralDirectoryCondition() throws Exception {
          // Create mock input stream
          InputStream mockInput = mock(InputStream.class);
          
          // Create instance with mock input
          ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
          
          try {
              // Use reflection to access private field and set hitCentralDirectory=true
              java.lang.reflect.Field hitCentralDirectoryField = 
                  ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
              hitCentralDirectoryField.setAccessible(true);
              hitCentralDirectoryField.set(zais, true);
              
              // Set closed=false (default state)
              java.lang.reflect.Field closedField = 
                  ZipArchiveInputStream.class.getDeclaredField("closed");
              closedField.setAccessible(true);
              closedField.set(zais, false);
              
              // Try to read - should behave differently with mutant
              // In original, this would trigger the condition
              // In mutant, it would not
              byte[] buffer = new byte[10];
              int read = zais.read(buffer);
              
              // Verify behavior - with original code, this might throw exception or return -1
              // depending on implementation details not shown
              // For mutant, it would try to read from stream
              verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
              
          } finally {
              zais.close();
          }
      }

 @Test
  public void testReadAfterHitCentralDirectory() throws Exception {
      // Setup
      InputStream mockInput = mock(InputStream.class);
      ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
      
      // Use reflection to set hitCentralDirectory to true since it's not directly accessible
      Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
      hitCentralDirectoryField.setAccessible(true);
      hitCentralDirectoryField.setBoolean(zis, true);
      
      // Test read behavior - should return -1 when hitCentralDirectory is true
      // With original code, this would return -1
      // With mutant, it might try to read from stream
      assertEquals(-1, zis.read());
      
      // Verify no interaction with underlying stream should occur
      verify(mockInput, never()).read();
      verify(mockInput, never()).read(any(byte[].class));
      verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
  }

 @Test
     public void testCompressedSizeCheck1() throws Exception {
         // Mock the input stream
         InputStream mockInputStream = mock(InputStream.class);
         
         // Create test instance
         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
         
         // Use reflection to access private field 'current' (simplified for example)
         // In real test, you might need to properly set up the internal state
         
         // Case 1: compressedSize = 0 (should be accepted by original, rejected by mutant)
         ZipArchiveEntry zeroSizeEntry = new ZipArchiveEntry("test1");
         zeroSizeEntry.setCompressedSize(0);
         // Set up the internal state to use this entry
         // This would normally require reflection or proper method calls
         // For this test, we're assuming we can set this up properly
         
         // The behavior difference would be seen in methods that use this condition
         // For example, canReadEntryData might behave differently
         assertTrue("Should accept zero-size entry", zais.canReadEntryData(zeroSizeEntry));
         
         // Case 2: compressedSize = -1 (should be rejected by both)
         ZipArchiveEntry negativeSizeEntry = new ZipArchiveEntry("test2");
         negativeSizeEntry.setCompressedSize(-1);
         assertFalse("Should reject negative-size entry", zais.canReadEntryData(negativeSizeEntry));
         
         // Case 3: compressedSize > 0 (should be accepted by both)
         ZipArchiveEntry positiveSizeEntry = new ZipArchiveEntry("test3");
         positiveSizeEntry.setCompressedSize(100);
         assertTrue("Should accept positive-size entry", zais.canReadEntryData(positiveSizeEntry));
     }

 @Test
 public void testCompressedSizeCheckForNegativeOne() throws Exception {
     // Create mock objects
     InputStream mockInputStream = mock(InputStream.class);
     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
     
     // Setup the entry to return -1 for compressed size
     when(mockEntry.getCompressedSize()).thenReturn(-1L);
     
     // Create a test instance of ZipArchiveInputStream
     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
     
     // We need to set the current entry (using reflection since it's private)
     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
     currentField.setAccessible(true);
     
     // Create and set a CurrentEntry instance
     Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
     Constructor<?> constructor = currentEntryClass.getDeclaredConstructor(ZipArchiveEntry.class);
     constructor.setAccessible(true);
     Object currentEntry = constructor.newInstance(mockEntry);
     currentField.set(zais, currentEntry);
     
     // The actual test - try to read stored entry (which checks compressed size)
     Method readStoredEntryMethod = ZipArchiveInputStream.class.getDeclaredMethod("readStoredEntry");
     readStoredEntryMethod.setAccessible(true);
     
     // This should not throw exception for original code, but mutant would behave differently
     // We can't directly observe the difference, but we can verify subsequent behavior
     readStoredEntryMethod.invoke(zais);
     
     // Verify the behavior difference - original would process, mutant would skip
     // Since we can't directly observe, we'll check if available() behaves differently
     // Original would have processed and be ready to read, mutant would skip
     int available = zais.available();
     assertTrue("Available bytes should reflect entry processing", available >= 0);
     
     // Additional verification - check if entry was properly processed
     // This depends on implementation details not shown, but the key is that
     // the -1 case should be handled differently between original and mutant
 }

 @Test
 public void testCompressedSizeCheckForZeroSizedEntries() throws Exception {
     // Create a mock input stream that will return our test entry
     InputStream mockStream = mock(InputStream.class);
     
     // Create a mock entry with compressed size = 0
     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
     when(entry.getCompressedSize()).thenReturn(0L);
     
     // Mock the behavior to return our test entry
     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockStream);
     // Use reflection to set the current entry since it's private
     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
     currentField.setAccessible(true);
     Object current = new Object(); // Simplified for illustration
     Field entryField = current.getClass().getDeclaredField("entry");
     entryField.setAccessible(true);
     entryField.set(current, entry);
     currentField.set(zis, current);
     
     // Mock other necessary fields
     Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
     bufField.setAccessible(true);
     bufField.set(zis, ByteBuffer.allocate(1024));
     
     try {
         // This should attempt to read the entry in original, but skip in mutant
         Method readStoredMethod = ZipArchiveInputStream.class.getDeclaredMethod("readStored", byte[].class, int.class, int.class);
         readStoredMethod.setAccessible(true);
         
         byte[] buffer = new byte[1024];
         int result = (int) readStoredMethod.invoke(zis, buffer, 0, 1024);
         
         // In original: should process (return >= 0)
         // In mutant: should skip (return -1)
         // So we assert it processed (original behavior)
         assertTrue("Should process entry with size 0", result >= 0);
     } catch (Exception e) {
         fail("Should not throw exception for size 0 entries");
     }
 }

 @Test
 public void testCompressedSizeCheckDetectsMutant1() throws Exception {
     // Create test data
     byte[] zipData = new byte[100]; // dummy zip data
     ByteArrayInputStream bais = new ByteArrayInputStream(zipData);
     
     // Create mock entry with different compressed sizes
     ZipArchiveEntry sizeMinusOne = mock(ZipArchiveEntry.class);
     when(sizeMinusOne.getCompressedSize()).thenReturn(-1L);
     when(sizeMinusOne.getMethod()).thenReturn(ZipEntry.STORED);
     
     ZipArchiveEntry sizeZero = mock(ZipArchiveEntry.class);
     when(sizeZero.getCompressedSize()).thenReturn(0L);
     when(sizeZero.getMethod()).thenReturn(ZipEntry.STORED);
     
     ZipArchiveEntry sizePositive = mock(ZipArchiveEntry.class);
     when(sizePositive.getCompressedSize()).thenReturn(100L);
     when(sizePositive.getMethod()).thenReturn(ZipEntry.STORED);
     
     // Create test instance
     ZipArchiveInputStream zais = new ZipArchiveInputStream(bais);
     
     try {
         // Use reflection to access private method/field for testing
         Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
         currentEntryField.setAccessible(true);
         
         // Test case 1: compressedSize = -1
         currentEntryField.set(zais, sizeMinusOne);
         Method readStoredMethod = ZipArchiveInputStream.class.getDeclaredMethod("readStoredEntry");
         readStoredMethod.setAccessible(true);
         readStoredMethod.invoke(zais); // Should handle -1 specially
         
         // Test case 2: compressedSize = 0 (will detect the mutant)
         currentEntryField.set(zais, sizeZero);
         readStoredMethod.invoke(zais); // Original handles normally, mutant would skip
         
         // Test case 3: compressedSize > 0
         currentEntryField.set(zais, sizePositive);
         readStoredMethod.invoke(zais); // Both handle normally
         
         // Verify the behavior by checking if the stream was read properly
         // The mutant would fail when compressedSize = 0
     } finally {
         zais.close();
     }
 }

}
