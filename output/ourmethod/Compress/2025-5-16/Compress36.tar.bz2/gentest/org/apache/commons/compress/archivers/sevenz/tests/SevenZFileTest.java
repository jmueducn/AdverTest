package gentest.org.apache.commons.compress.archivers.sevenz.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.sevenz.*;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.LinkedList;
import java.util.zip.CRC32;
import org.apache.commons.compress.utils.BoundedInputStream;
import org.apache.commons.compress.utils.CRC32VerifyingInputStream;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class SevenZFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                   public void testGetCurrentStream_EmptyFileEntry() throws Exception {
                                                                                                                                                                                                                                                                       // Create a dummy 7z file
                                                                                                                                                                                                                                                                       File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                       tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Create SevenZFile instance
                                                                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                       filesField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object[] files = (Object[]) filesField.get(archive);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Create a mock file entry with size 0
                                                                                                                                                                                                                                                                       Object fileEntry = files[0].getClass().newInstance();
                                                                                                                                                                                                                                                                       Method setSizeMethod = fileEntry.getClass().getMethod("setSize", long.class);
                                                                                                                                                                                                                                                                       setSizeMethod.invoke(fileEntry, 0L);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Set the single file entry
                                                                                                                                                                                                                                                                       filesField.set(archive, new Object[]{fileEntry});
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Set current entry index
                                                                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                       currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Set empty deferred block streams
                                                                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Get the current stream using reflection
                                                                                                                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                                                       assertEquals(0, result.available());
                                                                                                                                                                                                                                                                       assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                   public void testGetCurrentStream_SingleDeferredBlock() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       File mockFile = mock(File.class);
                                                                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                                                                                       InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                       archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                       filesField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object fileEntry = mock(filesField.getType().getComponentType());
                                                                                                                                                                                                                                                                       filesField.set(archive, new Object[]{fileEntry});
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Method getSizeMethod = fileEntry.getClass().getMethod("getSize");
                                                                                                                                                                                                                                                                       when(getSizeMethod.invoke(fileEntry)).thenReturn(100L);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                       @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                       ArrayList<InputStream> streams = (ArrayList<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                                                                                                                                                                                                                                                                       if (streams == null) {
                                                                                                                                                                                                                                                                           streams = new ArrayList<>();
                                                                                                                                                                                                                                                                           deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                       streams.add(mockStream);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Execute
                                                                                                                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       assertSame(mockStream, result);
                                                                                                                                                                                                                                                                       assertEquals(1, streams.size()); // Should remain unchanged
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                   public void testGetCurrentStream_MultipleDeferredBlocks() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                       tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                                                                                                       InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                                                                                                       InputStream mockStream3 = mock(InputStream.class);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Set private fields using reflection
                                                                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                       streams.add(mockStream1);
                                                                                                                                                                                                                                                                       streams.add(mockStream2);
                                                                                                                                                                                                                                                                       streams.add(mockStream3);
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Create mock archive structure
                                                                                                                                                                                                                                                                       SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                                                                                                                       entry.setSize(100L);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                       filesField.setAccessible(true);
                                                                                                                                                                                                                                                                       filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                                                                                                                                                                                                                                                       archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Execute
                                                                                                                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       assertSame(mockStream3, result); // Last stream should remain
                                                                                                                                                                                                                                                                       assertEquals(1, streams.size()); // Others should be removed
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify streams were properly skipped and closed
                                                                                                                                                                                                                                                                       verify(mockStream1).skip(Long.MAX_VALUE);
                                                                                                                                                                                                                                                                       verify(mockStream1).close();
                                                                                                                                                                                                                                                                       verify(mockStream2).skip(Long.MAX_VALUE);
                                                                                                                                                                                                                                                                       verify(mockStream2).close();
                                                                                                                                                                                                                                                                       verify(mockStream3, never()).skip(anyLong());
                                                                                                                                                                                                                                                                       verify(mockStream3, never()).close();
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                   public void testGetCurrentStream_IOExceptionDuringCleanup() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                                       InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                                                                                                       InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                                       archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                       currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                                       filesField.setAccessible(true);
                                                                                                                                                                                                                                                                       Object fileEntry = mock(filesField.getType().getComponentType());
                                                                                                                                                                                                                                                                       filesField.set(archive, new Object[]{fileEntry});
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Method getSizeMethod = fileEntry.getClass().getMethod("getSize");
                                                                                                                                                                                                                                                                       when(getSizeMethod.invoke(fileEntry)).thenReturn(100L);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Make first stream throw IOException during skip
                                                                                                                                                                                                                                                                       doThrow(new IOException("Test exception")).when(mockStream1).skip(Long.MAX_VALUE);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                                       streams.add(mockStream1);
                                                                                                                                                                                                                                                                       streams.add(mockStream2);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                       deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                       // Get private method via reflection
                                                                                                                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Execute - should still work despite the IOException
                                                                                                                                                                                                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       assertSame(mockStream2, result);
                                                                                                                                                                                                                                                                       assertEquals(1, streams.size());
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify streams were attempted to be closed despite skip failure
                                                                                                                                                                                                                                                                       verify(mockStream1).close();
                                                                                                                                                                                                                                                                       verify(mockStream2, never()).skip(anyLong());
                                                                                                                                                                                                                                                                       verify(mockStream2, never()).close();
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                               public void testGetCurrentStream_NoCurrentEntry() throws Exception {
                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                   File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                   tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Use reflection to set private fields
                                                                                                                                                                                                                                                                   Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                                   archiveField.setAccessible(true);
                                                                                                                                                                                                                                                                   Object archive = new Object(); // We don't need real archive for this test
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                                   currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                                   currentEntryIndexField.setInt(sevenZFile, 0);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                                   deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                                   deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Get private method
                                                                                                                                                                                                                                                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                                   getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Execute and verify exception
                                                                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                                                                       getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                                       fail("Expected IllegalStateException");
                                                                                                                                                                                                                                                                   } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                       Throwable cause = e.getCause();
                                                                                                                                                                                                                                                                       assertTrue(cause instanceof IllegalStateException);
                                                                                                                                                                                                                                                                       assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                           public void testReadDetectsMutant() throws Exception {
                                                                                                                                                                                                                                                               // Setup mock stream that returns specific data
                                                                                                                                                                                                                                                               InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                               when(mockStream.read()).thenReturn(65); // Return 'A' when read
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create SevenZFile instance and inject mock stream
                                                                                                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                                                                                                               Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                                                               streamField.setAccessible(true);
                                                                                                                                                                                                                                                               streamField.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Call the read method
                                                                                                                                                                                                                                                               int result = sevenZFile.read();
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Verify the result - mutant would return 0, original would return 65
                                                                                                                                                                                                                                                               assertEquals("Read should return actual byte value from stream", 65, result);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Verify the mock was actually called - mutant wouldn't call it
                                                                                                                                                                                                                                                               verify(mockStream).read();
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                          public void testReadDetectsMutant1() throws Exception {
                                                                                                                                                                                                                                                              // Create mock InputStream that will return specific test values
                                                                                                                                                                                                                                                              InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                              when(mockStream.read()).thenReturn(65, -1); // First call returns 'A', second returns -1
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create real SevenZFile instance (we'll use reflection to set the private stream)
                                                                                                                                                                                                                                                              File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Use reflection to set the private currentStream field
                                                                                                                                                                                                                                                                  Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                                                                  currentStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                  currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // First read should return 65 ('A')
                                                                                                                                                                                                                                                                  assertEquals(65, sevenZFile.read());
                                                                                                                                                                                                                                                                  // Second read should return -1 (end of stream)
                                                                                                                                                                                                                                                                  assertEquals(-1, sevenZFile.read());
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify the stream was interacted with properly
                                                                                                                                                                                                                                                                  verify(mockStream, times(2)).read();
                                                                                                                                                                                                                                                              } finally {
                                                                                                                                                                                                                                                                  tempFile.delete();
                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testReadByteArrayShouldReturnActualBytesRead() throws Exception {
                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                              byte[] testData = new byte[10];
                                                                                                                                                                                                                                                              InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                              when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // Simulate reading 5 bytes
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                                              // Use reflection to access private getCurrentStream method
                                                                                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                              when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(mockStream);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Use reflection to make the read method accessible since it's private
                                                                                                                                                                                                                                                              Method readMethod = SevenZFile.class.getDeclaredMethod("read", byte[].class, int.class, int.class);
                                                                                                                                                                                                                                                              readMethod.setAccessible(true);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                              int bytesRead = (int) readMethod.invoke(sevenZFile, new byte[10], 0, 10);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                              assertEquals("Should return actual number of bytes read", 5, bytesRead);
                                                                                                                                                                                                                                                              verify(mockStream).read(any(byte[].class), eq(0), eq(10));
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                      public void testReadShouldReturnByteFromStreamNotJustMinusOne() throws Exception {
                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create a mock stream that will return data
                                                                                                                                                                                                                                                          InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                          when(mockStream.read()).thenReturn(65); // Return 'A' as test data
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                                                                                                          Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                                                                                                                          field.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test
                                                                                                                                                                                                                                                          int result = sevenZFile.read();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                                                          assertEquals("Should return the byte read from stream", 65, result);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Verify the stream was actually called
                                                                                                                                                                                                                                                          verify(mockStream).read();
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                     public void testReadShouldReturnByteFromStreamNotNegativeOne() throws Exception {
                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Create a mock InputStream that will be used by SevenZFile
                                                                                                                                                                                                                                                         InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                         when(mockStream.read()).thenReturn(65); // 'A' in ASCII
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Use reflection to inject our mock stream into the SevenZFile
                                                                                                                                                                                                                                                         // This is necessary because getCurrentStream() is private
                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                             Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                                                             currentStreamField.setAccessible(true);
                                                                                                                                                                                                                                                             currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                             fail("Failed to set currentStream field via reflection");
                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Test
                                                                                                                                                                                                                                                         int result = sevenZFile.read();
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                                         assertEquals("Should return the byte read from stream", 65, result);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Verify interaction with the stream
                                                                                                                                                                                                                                                         verify(mockStream).read();
                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                 public void testReadWithValidDataShouldReturnBytesRead() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                     InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Use reflection to set private field since we can't access it directly
                                                                                                                                                                                                                                                     Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                                                     field.setAccessible(true);
                                                                                                                                                                                                                                                     field.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     byte[] buffer = new byte[10];
                                                                                                                                                                                                                                                     int expectedBytesRead = 5;
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Mock the stream to return 5 bytes when read is called
                                                                                                                                                                                                                                                     when(mockStream.read(buffer, 0, 10)).thenReturn(expectedBytesRead);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                     int actualBytesRead = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                                                     assertEquals("Should return the same number of bytes as the underlying stream", 
                                                                                                                                                                                                                                                                 expectedBytesRead, actualBytesRead);
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                 public void testReadAtEndOfStreamShouldReturnMinusOne() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                     InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Use reflection to set private field
                                                                                                                                                                                                                                                     Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                                                     field.setAccessible(true);
                                                                                                                                                                                                                                                     field.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     byte[] buffer = new byte[10];
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Mock the stream to return -1 (end of stream)
                                                                                                                                                                                                                                                     when(mockStream.read(buffer, 0, 10)).thenReturn(-1);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                     int result = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                                                     assertEquals("Should return -1 when stream is exhausted", -1, result);
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                 public void testReadWithPartialBuffer() throws IOException {
                                                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                     InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                                         // Use reflection to set private field
                                                                                                                                                                                                                                                         Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                                                                         field.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                                     } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                                                                                         fail("Failed to set private field via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     byte[] buffer = new byte[20];
                                                                                                                                                                                                                                                     int expectedBytesRead = 3;
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Mock the stream to return 3 bytes when reading from offset 5
                                                                                                                                                                                                                                                     when(mockStream.read(buffer, 5, 10)).thenReturn(expectedBytesRead);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                     int actualBytesRead = sevenZFile.read(buffer, 5, 10);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                                                     assertEquals("Should return correct number of bytes for partial read", 
                                                                                                                                                                                                                                                                 expectedBytesRead, actualBytesRead);
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                            public void testReadWithNonEmptyFileShouldReadFromStream() throws Exception {
                                                                                                                                                                                                                                                // Setup mocks
                                                                                                                                                                                                                                                SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                                InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Set up test data
                                                                                                                                                                                                                                                when(inputStream.read()).thenReturn(42); // sample data
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to set private fields and mock private method
                                                                                                                                                                                                                                                Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                                                currentStreamField.setAccessible(true);
                                                                                                                                                                                                                                                currentStreamField.set(sevenZFile, inputStream);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Call real method on partial mock
                                                                                                                                                                                                                                                when(sevenZFile.read()).thenCallRealMethod();
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test non-empty file case
                                                                                                                                                                                                                                                int result = sevenZFile.read();
                                                                                                                                                                                                                                                assertEquals(42, result);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the stream was actually read
                                                                                                                                                                                                                                                verify(inputStream).read();
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testReadWithZeroSizeEntryShouldBeHandledDifferently() throws Exception {
                                                                                                                                                                                                                                                // Setup mock objects
                                                                                                                                                                                                                                                SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                                SevenZArchiveEntry entry1 = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                SevenZArchiveEntry entry2 = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Create array of files with one zero-size and one non-zero entry
                                                                                                                                                                                                                                                SevenZArchiveEntry[] files = new SevenZArchiveEntry[]{entry1, entry2};
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Set sizes - first entry has size 0, second has size 100
                                                                                                                                                                                                                                                when(entry1.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                                when(entry2.getSize()).thenReturn(100L);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                archiveField.setAccessible(true);
                                                                                                                                                                                                                                                Object archive = mock(archiveField.getType());
                                                                                                                                                                                                                                                Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                filesField.setAccessible(true);
                                                                                                                                                                                                                                                filesField.set(archive, files);
                                                                                                                                                                                                                                                archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Mock the actual read operation
                                                                                                                                                                                                                                                byte[] buffer = new byte[1024];
                                                                                                                                                                                                                                                when(sevenZFile.read(buffer, 0, buffer.length)).thenCallRealMethod();
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // For zero-size entry, original would return -1, mutant would try to read
                                                                                                                                                                                                                                                int result = sevenZFile.read(buffer);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify behavior - original would return -1 for zero-size
                                                                                                                                                                                                                                                assertEquals("Should return -1 for zero-size entry", -1, result);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Now test with non-zero size entry
                                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 1);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to mock getCurrentStream()
                                                                                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(new ByteArrayInputStream(new byte[100]));
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                result = sevenZFile.read(buffer);
                                                                                                                                                                                                                                                assertTrue("Should read data for non-zero entry", result > 0);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testReadWithEmptyFileEntry() throws Exception {
                                                                                                                                                                                                                                                // Setup test data
                                                                                                                                                                                                                                                byte[] buffer = new byte[10];
                                                                                                                                                                                                                                                int offset = 0;
                                                                                                                                                                                                                                                int length = 10;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Create mock objects
                                                                                                                                                                                                                                                SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                                SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to set private fields if needed
                                                                                                                                                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Configure mocks
                                                                                                                                                                                                                                                when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                                when(sevenZFile.getNextEntry()).thenReturn(entry);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Mock the private getCurrentStream method behavior
                                                                                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(emptyStream);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Call real method on partial mock
                                                                                                                                                                                                                                                when(sevenZFile.read(buffer, offset, length)).thenCallRealMethod();
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Execute and verify
                                                                                                                                                                                                                                                int result = sevenZFile.read(buffer, offset, length);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Assertions
                                                                                                                                                                                                                                                assertEquals("Should return -1 for empty file", -1, result);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                        public void testReadWithEmptyFileShouldReturnMinusOne() throws Exception {
                                                                                                                                                                                                                                            // Create a temporary empty file
                                                                                                                                                                                                                                            File emptyFile = File.createTempFile("empty", ".7z");
                                                                                                                                                                                                                                            emptyFile.deleteOnExit();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Create real SevenZFile instance
                                                                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(emptyFile);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to set private fields needed for the test
                                                                                                                                                                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                            archiveField.setAccessible(true);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Create mock entry with size 0
                                                                                                                                                                                                                                            SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                            when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Create mock archive with our empty entry
                                                                                                                                                                                                                                            Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                                                                                                                            Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                            filesField.setAccessible(true);
                                                                                                                                                                                                                                            filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                                                                                                                                                                                                                            archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Mock the input stream to return -1
                                                                                                                                                                                                                                            InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                            when(inputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Set the current stream via reflection
                                                                                                                                                                                                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                                            currentStreamField.setAccessible(true);
                                                                                                                                                                                                                                            currentStreamField.set(sevenZFile, inputStream);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Test empty file case
                                                                                                                                                                                                                                            int result = sevenZFile.read();
                                                                                                                                                                                                                                            assertEquals(-1, result);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify the mutant would fail here - original would handle size 0 differently
                                                                                                                                                                                                                                            verify(inputStream, never()).read();
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                   public void testReadWithNonEmptyEntryShouldReadData() throws Exception {
                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                       byte[] buffer = new byte[10];
                                                                                                                                                                                                                                       Arrays.fill(buffer, (byte) 1); // Fill with non-zero data
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Mock the SevenZFile
                                                                                                                                                                                                                                       SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Mock the actual read operation to return some data
                                                                                                                                                                                                                                       when(sevenZFile.read(buffer, 0, buffer.length)).thenReturn(5);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Call the method
                                                                                                                                                                                                                                       int result = sevenZFile.read(buffer);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                       assertEquals(5, result); // Should return number of bytes read
                                                                                                                                                                                                                                       verify(sevenZFile).read(buffer, 0, buffer.length); // Should have attempted to read
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // The mutant would skip reading and return -1, failing this test
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testReadWithEmptyFileShouldNotCallStreamRead() throws Exception {
                                                                                                                                                                                                                                       // Setup test data
                                                                                                                                                                                                                                       byte[] buffer = new byte[10];
                                                                                                                                                                                                                                       int offset = 0;
                                                                                                                                                                                                                                       int length = 10;
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Mock dependencies
                                                                                                                                                                                                                                       SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                       SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                       InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Configure mocks
                                                                                                                                                                                                                                       when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Use reflection to set private fields since we can't use real constructor
                                                                                                                                                                                                                                       // Set currentEntryIndex
                                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Set currentStream
                                                                                                                                                                                                                                       Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                                       currentStreamField.setAccessible(true);
                                                                                                                                                                                                                                       currentStreamField.set(sevenZFile, inputStream);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Set currentEntry
                                                                                                                                                                                                                                       Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntry");
                                                                                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                       currentEntryField.set(sevenZFile, entry);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Call real method on partial mock
                                                                                                                                                                                                                                       when(sevenZFile.read(buffer, offset, length)).thenCallRealMethod();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Execute
                                                                                                                                                                                                                                       int result = sevenZFile.read(buffer, offset, length);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify - should not call stream.read() for empty file
                                                                                                                                                                                                                                       verify(inputStream, never()).read(buffer, offset, length);
                                                                                                                                                                                                                                       assertEquals(0, result);  // Should return 0 for empty file
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                               public void testReadWithNonEmptyFileShouldNotTreatAsEmpty() throws Exception {
                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create a mock entry with non-zero size
                                                                                                                                                                                                                                   SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                   when(mockEntry.getSize()).thenReturn(100L); // Non-zero size
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Use reflection to set current entry
                                                                                                                                                                                                                                   Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntry");
                                                                                                                                                                                                                                   currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                   currentEntryField.set(sevenZFile, mockEntry);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Set currentEntryIndex to 0
                                                                                                                                                                                                                                   Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                   currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                   currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Mock the current stream to return some data
                                                                                                                                                                                                                                   InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                   when(mockStream.read()).thenReturn(42); // Some data
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Use reflection to set the current stream directly
                                                                                                                                                                                                                                   Field currentInputStreamField = SevenZFile.class.getDeclaredField("currentInputStream");
                                                                                                                                                                                                                                   currentInputStreamField.setAccessible(true);
                                                                                                                                                                                                                                   currentInputStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Test
                                                                                                                                                                                                                                   int result = sevenZFile.read();
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                                                   assertEquals("Should return data from stream for non-empty file", 42, result);
                                                                                                                                                                                                                                   verify(mockStream).read(); // Verify the stream was actually read from
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                               public void testReadWithEmptyEntryShouldReturnImmediately() throws Exception {
                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                   byte[] buffer = new byte[10];
                                                                                                                                                                                                                                   byte[] originalBuffer = Arrays.copyOf(buffer, buffer.length);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Mock the SevenZFile and its entry
                                                                                                                                                                                                                                   SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                                   SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Set up mock behavior
                                                                                                                                                                                                                                   when(sevenZFile.getNextEntry()).thenReturn(entry);
                                                                                                                                                                                                                                   when(entry.getSize()).thenReturn(0L); // Zero size
                                                                                                                                                                                                                                   when(sevenZFile.read(buffer, 0, buffer.length)).thenReturn(-1);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Call the method
                                                                                                                                                                                                                                   int result = sevenZFile.read(buffer);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                                                   assertEquals(-1, result); // Should return -1 for empty entry
                                                                                                                                                                                                                                   assertArrayEquals(originalBuffer, buffer); // Buffer should remain unchanged
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify the read was called with correct parameters
                                                                                                                                                                                                                                   verify(sevenZFile).read(buffer, 0, buffer.length);
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                           public void testReadReturnsNonNullStream() throws Exception {
                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                               byte[] buffer = new byte[1024];
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Exercise
                                                                                                                                                                                                                               int result = sevenZFile.read(buffer);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                               // The exact value depends on implementation, but we mainly care that it doesn't return null
                                                                                                                                                                                                                               // For this test, we just want to ensure the method doesn't return null-like behavior
                                                                                                                                                                                                                               assertTrue("Read should return a valid result (not indicate null stream)", 
                                                                                                                                                                                                                                          result >= -1); // -1 is EOF, positive is bytes read
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Additional verification that the buffer was potentially modified
                                                                                                                                                                                                                               // (though with mocked objects, this might not be reliable)
                                                                                                                                                                                                                               assertNotNull("Buffer should not be null after read", buffer);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Cleanup
                                                                                                                                                                                                                               sevenZFile.close();
                                                                                                                                                                                                                           }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                           public void testReadWithNullBuffer() throws Exception {
                                                                                                                                                                                                                               // This test verifies the method's behavior with invalid input
                                                                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                   sevenZFile.read(null);
                                                                                                                                                                                                                               } finally {
                                                                                                                                                                                                                                   sevenZFile.close();
                                                                                                                                                                                                                               }
                                                                                                                                                                                                                           }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                          public void testReadWhenCurrentStreamIsNull() throws Exception {
                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                              // Create a temporary empty 7z file
                                                                                                                                                                                                                              File tempFile = File.createTempFile("empty", ".7z");
                                                                                                                                                                                                                              tempFile.deleteOnExit();
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Create a real SevenZFile object
                                                                                                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Don't call getNextEntry() so currentStream remains null
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                              // This should throw NullPointerException when trying to call read() on null
                                                                                                                                                                                                                              sevenZFile.read();
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Assertion is handled by the expected exception in the @Test annotation
                                                                                                                                                                                                                          }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                          public void testReadWithNullCurrentStream() throws Exception {
                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                              SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to mock the private getCurrentStream method
                                                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                              when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(null);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // This should throw NullPointerException when getCurrentStream() returns null
                                                                                                                                                                                                                              sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                     public void testReadWithEmptyStream() throws Exception {
                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Mock the current stream to return our test stream
                                                                                                                                                                                                                         // In original: new ByteArrayInputStream(new byte[0])
                                                                                                                                                                                                                         // In mutant: new ByteArrayInputStream(new byte[1])
                                                                                                                                                                                                                         InputStream mockStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Use reflection to set private field
                                                                                                                                                                                                                         Field field = sevenZFile.getClass().getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                                         field.set(sevenZFile, mockStream);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test buffer
                                                                                                                                                                                                                         byte[] buffer = new byte[10];
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                         int bytesRead = sevenZFile.read(buffer);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                         // Original should return -1 (end of stream)
                                                                                                                                                                                                                         // Mutant would return 1 (reads the 0 byte)
                                                                                                                                                                                                                         assertEquals("Should return -1 for empty stream", -1, bytesRead);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Additional verification that no bytes were written to buffer
                                                                                                                                                                                                                         for (byte b : buffer) {
                                                                                                                                                                                                                             assertEquals("Buffer should remain unchanged", 0, b);
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                     public void testReadWithEmptyStreamShouldReturnMinusOne() throws Exception {
                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                         byte[] buffer = new byte[10];
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Get the private field and make it accessible
                                                                                                                                                                                                                         Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Mock the current stream to be empty (original behavior)
                                                                                                                                                                                                                         InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                         field.set(sevenZFile, emptyStream);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test
                                                                                                                                                                                                                         int result = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                         assertEquals("Reading from empty stream should return -1", -1, result);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Now test with mutant behavior
                                                                                                                                                                                                                         InputStream oneByteStream = new ByteArrayInputStream(new byte[1]);
                                                                                                                                                                                                                         field.set(sevenZFile, oneByteStream);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // This would pass with mutant but fail with original
                                                                                                                                                                                                                         int mutantResult = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                                                         assertNotEquals("Mutant would return 1 instead of -1", 1, mutantResult);
                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                 public void testReadWithEmptyStream1() throws Exception {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                     tempFile.deleteOnExit();
                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private getCurrentStream method
                                                                                                                                                                                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                     getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private currentStream field
                                                                                                                                                                                                                     Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                     currentStreamField.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test empty stream
                                                                                                                                                                                                                     InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                     currentStreamField.set(sevenZFile, emptyStream);
                                                                                                                                                                                                                     int result = sevenZFile.read();
                                                                                                                                                                                                                     assertEquals("Reading from empty stream should return -1", -1, result);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test mutant stream (1 byte)
                                                                                                                                                                                                                     InputStream mutantStream = new ByteArrayInputStream(new byte[1]);
                                                                                                                                                                                                                     currentStreamField.set(sevenZFile, mutantStream);
                                                                                                                                                                                                                     int mutantResult = sevenZFile.read();
                                                                                                                                                                                                                     // This assertion would fail for the mutant
                                                                                                                                                                                                                     assertEquals("Reading from empty stream should return -1", -1, mutantResult);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     sevenZFile.close();
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                             public void testReadWithDeferredStreams() throws Exception {
                                                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                                                 byte[] buffer = new byte[10];
                                                                                                                                                                                                                 byte[] expectedData = {1, 2, 3, 4, 5};
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create mock streams
                                                                                                                                                                                                                 InputStream currentFolderStream = mock(InputStream.class);
                                                                                                                                                                                                                 when(currentFolderStream.read(buffer, 0, buffer.length)).thenReturn(expectedData.length);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 InputStream deferredStream = mock(InputStream.class);
                                                                                                                                                                                                                 when(deferredStream.read(buffer, 0, buffer.length)).thenReturn(expectedData.length);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Case 1: deferredBlockStreams is empty - should read from currentFolderStream
                                                                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                 // Use reflection to set private fields since we need to test internal behavior
                                                                                                                                                                                                                 Field currentFolderStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                 currentFolderStreamField.setAccessible(true);
                                                                                                                                                                                                                 currentFolderStreamField.set(sevenZFile, currentFolderStream);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                 deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                                 deferredStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test read
                                                                                                                                                                                                                 int bytesRead = sevenZFile.read(buffer);
                                                                                                                                                                                                                 assertEquals(expectedData.length, bytesRead);
                                                                                                                                                                                                                 verify(currentFolderStream).read(buffer, 0, buffer.length);
                                                                                                                                                                                                                 verify(deferredStream, never()).read(buffer, 0, buffer.length);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Case 2: deferredBlockStreams is NOT empty - should read from deferred streams
                                                                                                                                                                                                                 ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                                 deferredStreams.add(deferredStream);
                                                                                                                                                                                                                 deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 bytesRead = sevenZFile.read(buffer);
                                                                                                                                                                                                                 assertEquals(expectedData.length, bytesRead);
                                                                                                                                                                                                                 verify(deferredStream).read(buffer, 0, buffer.length);
                                                                                                                                                                                                                 // Current folder stream should not be called again
                                                                                                                                                                                                                 verify(currentFolderStream, times(1)).read(buffer, 0, buffer.length);
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                            public void testReadWithEmptyAndNonEmptyDeferredStreams() throws Exception {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to access private fields
                                                                                                                                                                                                                Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                                                currentStreamField.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create mock streams
                                                                                                                                                                                                                InputStream mockCurrentStream = mock(InputStream.class);
                                                                                                                                                                                                                InputStream mockDeferredStream = mock(InputStream.class);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test case 1: Empty deferred streams - should read from current stream
                                                                                                                                                                                                                when(mockCurrentStream.read()).thenReturn(42);
                                                                                                                                                                                                                ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                                                                                                                                                deferredStreamsField.set(sevenZFile, emptyList);
                                                                                                                                                                                                                currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify behavior with empty deferred streams
                                                                                                                                                                                                                assertEquals(42, sevenZFile.read());
                                                                                                                                                                                                                verify(mockCurrentStream).read();
                                                                                                                                                                                                                verify(mockDeferredStream, never()).read();
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test case 2: Non-empty deferred streams - should NOT read from current stream
                                                                                                                                                                                                                ArrayList<InputStream> nonEmptyList = new ArrayList<>();
                                                                                                                                                                                                                nonEmptyList.add(mockDeferredStream);
                                                                                                                                                                                                                deferredStreamsField.set(sevenZFile, nonEmptyList);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Reset mocks
                                                                                                                                                                                                                reset(mockCurrentStream, mockDeferredStream);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // The original code should skip reading when deferred streams exist
                                                                                                                                                                                                                // The mutant would try to read when deferred streams exist
                                                                                                                                                                                                                when(mockCurrentStream.read()).thenReturn(42);
                                                                                                                                                                                                                when(mockDeferredStream.read()).thenReturn(99);
                                                                                                                                                                                                                currentStreamField.set(sevenZFile, mockDeferredStream);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // This assertion would fail with the mutant
                                                                                                                                                                                                                assertEquals(99, sevenZFile.read());
                                                                                                                                                                                                                verify(mockDeferredStream).read();
                                                                                                                                                                                                                verify(mockCurrentStream, never()).read();
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testReadWithEmptyAndNonEmptyDeferredStreams1() throws Exception {
                                                                                                                                                                                                                // Setup test data
                                                                                                                                                                                                                byte[] buffer = new byte[10];
                                                                                                                                                                                                                int offset = 0;
                                                                                                                                                                                                                int length = 10;
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create mock streams
                                                                                                                                                                                                                InputStream currentFolderStream = mock(InputStream.class);
                                                                                                                                                                                                                InputStream deferredStream1 = mock(InputStream.class);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Setup expected behaviors
                                                                                                                                                                                                                when(currentFolderStream.read(buffer, offset, length)).thenReturn(5);
                                                                                                                                                                                                                when(deferredStream1.read(buffer, offset, length)).thenReturn(3);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create SevenZFile instance
                                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to access private fields
                                                                                                                                                                                                                Field currentFolderInputStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                                currentFolderInputStreamField.setAccessible(true);
                                                                                                                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test case 1: Empty deferredBlockStreams (should use currentFolderInputStream)
                                                                                                                                                                                                                currentFolderInputStreamField.set(sevenZFile, currentFolderStream);
                                                                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                                                                                                                                                                                                
                                                                                                                                                                                                                int result = sevenZFile.read(buffer, offset, length);
                                                                                                                                                                                                                assertEquals(5, result);
                                                                                                                                                                                                                verify(currentFolderStream).read(buffer, offset, length);
                                                                                                                                                                                                                verify(deferredStream1, never()).read(buffer, offset, length);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test case 2: Non-empty deferredBlockStreams (should use first deferred stream)
                                                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                                                List<InputStream> deferredStreams = (List<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                                                                                                                                                                                                                deferredStreams.add(deferredStream1);
                                                                                                                                                                                                                
                                                                                                                                                                                                                result = sevenZFile.read(buffer, offset, length);
                                                                                                                                                                                                                assertEquals(3, result);
                                                                                                                                                                                                                verify(deferredStream1).read(buffer, offset, length);
                                                                                                                                                                                                                // Current folder stream should not be used in this case
                                                                                                                                                                                                                verify(currentFolderStream, times(1)).read(buffer, offset, length); // Only called once before
                                                                                                                                                                                                                
                                                                                                                                                                                                                // This test will fail if the mutant is present because:
                                                                                                                                                                                                                // - With mutant, empty deferredBlockStreams would skip currentFolderInputStream
                                                                                                                                                                                                                // - With mutant, non-empty would incorrectly use currentFolderInputStream
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testReadShouldCheckDeferredStreamsFirst() throws Exception {
                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create mock streams
                                                                                                                                                                                                            InputStream deferredStream1 = mock(InputStream.class);
                                                                                                                                                                                                            when(deferredStream1.read()).thenReturn(42);
                                                                                                                                                                                                            InputStream currentStream = mock(InputStream.class);
                                                                                                                                                                                                            when(currentStream.read()).thenReturn(99);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to inject our mock streams since fields are private
                                                                                                                                                                                                            Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                            deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                            ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                            deferredStreams.add(deferredStream1);
                                                                                                                                                                                                            deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                            
                                                                                                                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                            currentStreamField.setAccessible(true);
                                                                                                                                                                                                            currentStreamField.set(sevenZFile, currentStream);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test - should read from deferred stream first
                                                                                                                                                                                                            int result = sevenZFile.read();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify - should read from deferred stream (42) not current stream (99)
                                                                                                                                                                                                            assertEquals(42, result);
                                                                                                                                                                                                            verify(deferredStream1).read();
                                                                                                                                                                                                            verify(currentStream, never()).read();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Clean up reflection access
                                                                                                                                                                                                            deferredStreamsField.setAccessible(false);
                                                                                                                                                                                                            currentStreamField.setAccessible(false);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testReadWithDeferredStreams1() throws Exception {
                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                            File mockFile = mock(File.class);
                                                                                                                                                                                                            when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                                                            
                                                                                                                                                                                                            RandomAccessFile mockRAF = mock(RandomAccessFile.class);
                                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Mock the deferredBlockStreams to contain an item
                                                                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                            when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to access private field
                                                                                                                                                                                                            Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                            deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                            ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                                                                                                                                                                            deferredStreams.add(mockStream);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test with non-empty deferred streams
                                                                                                                                                                                                            byte[] buffer = new byte[100];
                                                                                                                                                                                                            int result = sevenZFile.read(buffer);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify the read was delegated to the deferred stream
                                                                                                                                                                                                            assertEquals(10, result);
                                                                                                                                                                                                            verify(mockStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Clear deferred streams and test again
                                                                                                                                                                                                            deferredStreams.clear();
                                                                                                                                                                                                            result = sevenZFile.read(buffer);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // The original implementation would behave differently here
                                                                                                                                                                                                            // The mutant would still try to read from deferred streams (but they're empty)
                                                                                                                                                                                                            // This assertion would fail with the mutant
                                                                                                                                                                                                            assertNotEquals(-1, result); // Expect some valid read operation
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testReadWithNonEmptyDeferredStreams() throws Exception {
                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                            byte[] buffer = new byte[10];
                                                                                                                                                                                                            int offset = 0;
                                                                                                                                                                                                            int length = 10;
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create mock streams
                                                                                                                                                                                                            InputStream currentStreamMock = mock(InputStream.class);
                                                                                                                                                                                                            InputStream deferredStreamMock = mock(InputStream.class);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Setup expected behavior
                                                                                                                                                                                                            when(currentStreamMock.read(buffer, offset, length)).thenReturn(5);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create test instance and inject mocks
                                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to inject our test values since fields are private
                                                                                                                                                                                                            Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                            deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                            ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                            deferredStreams.add(deferredStreamMock);
                                                                                                                                                                                                            deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                            
                                                                                                                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                            currentStreamField.setAccessible(true);
                                                                                                                                                                                                            currentStreamField.set(sevenZFile, currentStreamMock);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Call method under test
                                                                                                                                                                                                            int result = sevenZFile.read(buffer, offset, length);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify behavior
                                                                                                                                                                                                            assertEquals(5, result);
                                                                                                                                                                                                            verify(currentStreamMock).read(buffer, offset, length);
                                                                                                                                                                                                            verify(deferredStreamMock, never()).read(buffer, offset, length);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Clean up
                                                                                                                                                                                                            deferredStreamsField.setAccessible(false);
                                                                                                                                                                                                            currentStreamField.setAccessible(false);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                       public void testReadWithoutCurrentEntryThrowsIllegalStateException() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           File mockFile = mock(File.class);
                                                                                                                                                                                                           when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                                                           RandomAccessFile mockRAF = mock(RandomAccessFile.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to set currentFolderInputStream to null
                                                                                                                                                                                                           Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                           field.setAccessible(true);
                                                                                                                                                                                                           field.set(sevenZFile, null);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Expect IllegalStateException
                                                                                                                                                                                                           thrown.expect(IllegalStateException.class);
                                                                                                                                                                                                           thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Test
                                                                                                                                                                                                           sevenZFile.read();
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                      public void testReadWithoutCurrentEntryThrowsIllegalStateException1() throws Exception {
                                                                                                                                                                                                          // Setup - create a SevenZFile with mocked dependencies
                                                                                                                                                                                                          File mockFile = mock(File.class);
                                                                                                                                                                                                          when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                                                          RandomAccessFile mockRAF = mock(RandomAccessFile.class);
                                                                                                                                                                                                          
                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to set the private currentFolderInputStream to null
                                                                                                                                                                                                          Field currentFolderInputStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                          currentFolderInputStreamField.setAccessible(true);
                                                                                                                                                                                                          currentFolderInputStreamField.set(sevenZFile, null);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Expect IllegalStateException
                                                                                                                                                                                                          thrown.expect(IllegalStateException.class);
                                                                                                                                                                                                          thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Test
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              sevenZFile.read();
                                                                                                                                                                                                          } finally {
                                                                                                                                                                                                              sevenZFile.close();
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testReadWithoutCurrentEntryShouldThrowIllegalStateException() throws Exception {
                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                          File mockFile = mock(File.class);
                                                                                                                                                                                                          when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Create SevenZFile instance without calling getNextEntry()
                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                          
                                                                                                                                                                                                          byte[] buffer = new byte[10];
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Act & Assert
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                                              fail("Expected IllegalStateException to be thrown");
                                                                                                                                                                                                          } catch (IllegalStateException e) {
                                                                                                                                                                                                              assertEquals("No current 7z entry (call getNextEntry() first).", e.getMessage());
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                  public void testReadWithoutCurrentEntryThrowsIllegalStateException2() throws Exception {
                                                                                                                                                                                                      // Arrange
                                                                                                                                                                                                      File mockFile = mock(File.class);
                                                                                                                                                                                                      when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                                                      
                                                                                                                                                                                                      RandomAccessFile mockRaf = mock(RandomAccessFile.class);
                                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Use reflection to simulate no current entry
                                                                                                                                                                                                      Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntry");
                                                                                                                                                                                                      currentEntryField.setAccessible(true);
                                                                                                                                                                                                      currentEntryField.set(sevenZFile, null);
                                                                                                                                                                                                      
                                                                                                                                                                                                      byte[] buffer = new byte[10];
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Act & Assert (expecting IllegalStateException)
                                                                                                                                                                                                      sevenZFile.read(buffer);
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                              public void testReadWithSingleDeferredStream() throws Exception {
                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                  File mockFile = mock(File.class);
                                                                                                                                                                                                  when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create a real SevenZFile instance with mocked dependencies
                                                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create a single deferred block stream
                                                                                                                                                                                                  InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                  when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10); // return 10 bytes read
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to set the private deferredBlockStreams field
                                                                                                                                                                                                  Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                  deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                  ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                  streams.add(mockStream);
                                                                                                                                                                                                  deferredStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Also set currentFolderInputStream to ensure we test the right path
                                                                                                                                                                                                  Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                  currentStreamField.setAccessible(true);
                                                                                                                                                                                                  currentStreamField.set(sevenZFile, null); // force use of deferred streams
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test
                                                                                                                                                                                                  byte[] buffer = new byte[100];
                                                                                                                                                                                                  int bytesRead = sevenZFile.read(buffer);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                  assertEquals(10, bytesRead); // Should read from the single stream directly
                                                                                                                                                                                                  verify(mockStream, times(1)).read(buffer, 0, 100); // Should only read once
                                                                                                                                                                                                  
                                                                                                                                                                                                  // The key assertion - with original code, we should never enter the while loop
                                                                                                                                                                                                  // With mutated code (>=1), it would try to process the single stream in a loop
                                                                                                                                                                                                  // This test will fail for the mutated version
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                              public void testReadWithSingleDeferredStream1() throws Exception {
                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create mock input streams
                                                                                                                                                                                                  InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                                  when(mockStream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Set up deferredBlockStreams with exactly 1 stream
                                                                                                                                                                                                  ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                  deferredStreams.add(mockStream1);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to inject our test deferredBlockStreams
                                                                                                                                                                                                  Field deferredField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                  deferredField.setAccessible(true);
                                                                                                                                                                                                  deferredField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Also mock currentFolderInputStream since it's used in getCurrentStream()
                                                                                                                                                                                                  InputStream mockFolderStream = mock(InputStream.class);
                                                                                                                                                                                                  when(mockFolderStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Field folderStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                                  folderStreamField.setAccessible(true);
                                                                                                                                                                                                  folderStreamField.set(sevenZFile, mockFolderStream);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test
                                                                                                                                                                                                  byte[] buffer = new byte[100];
                                                                                                                                                                                                  int bytesRead = sevenZFile.read(buffer, 0, 100);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                  assertEquals(5, bytesRead); // Should read from currentFolderInputStream, not deferred
                                                                                                                                                                                                  verify(mockStream1, never()).read(any(byte[].class), anyInt(), anyInt()); // Should not touch deferred stream
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Clean up
                                                                                                                                                                                                  sevenZFile.close();
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                             public void testReadWithSingleDeferredStream2() throws Exception {
                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Mock the deferredBlockStreams to contain exactly 1 stream
                                                                                                                                                                                                 ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                 InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                 when(mockStream.read()).thenReturn(42); // Return some test value
                                                                                                                                                                                                 deferredStreams.add(mockStream);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Use reflection to inject our mock deferredBlockStreams
                                                                                                                                                                                                 Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                 deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                 deferredBlockStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Test
                                                                                                                                                                                                 int result = sevenZFile.read();
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                 assertEquals(42, result);
                                                                                                                                                                                                 // Verify that the deferred stream was actually used
                                                                                                                                                                                                 verify(mockStream).read();
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                 deferredBlockStreamsField.setAccessible(false);
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                         public void testRead_ShouldRemoveStreamFromDeferredBlockStreams() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private field since we need to test implementation detail
                                                                                                                                                                                             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Create mock streams
                                                                                                                                                                                             InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                             InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                             when(mockStream1.read()).thenReturn(1);
                                                                                                                                                                                             when(mockStream2.read()).thenReturn(2);
                                                                                                                                                                                             
                                                                                                                                                                                             // Initialize deferredBlockStreams with our mock streams
                                                                                                                                                                                             ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                             streams.add(mockStream1);
                                                                                                                                                                                             streams.add(mockStream2);
                                                                                                                                                                                             deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                             
                                                                                                                                                                                             // First read - should remove first stream
                                                                                                                                                                                             int firstRead = sevenZFile.read();
                                                                                                                                                                                             assertEquals(1, firstRead);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify deferredBlockStreams size decreased by 1
                                                                                                                                                                                             ArrayList<InputStream> remainingStreams = (ArrayList<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                                                                                                                                                                                             assertEquals(1, remainingStreams.size());
                                                                                                                                                                                             assertSame(mockStream2, remainingStreams.get(0));
                                                                                                                                                                                             
                                                                                                                                                                                             // Second read - should remove second stream
                                                                                                                                                                                             int secondRead = sevenZFile.read();
                                                                                                                                                                                             assertEquals(2, secondRead);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify deferredBlockStreams is now empty
                                                                                                                                                                                             remainingStreams = (ArrayList<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                                                                                                                                                                                             assertTrue(remainingStreams.isEmpty());
                                                                                                                                                                                             
                                                                                                                                                                                             // Clean up
                                                                                                                                                                                             deferredBlockStreamsField.setAccessible(false);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testReadConsumesStreamsFromDeferredBlockStreams() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                             
                                                                                                                                                                                             // Create mock input streams with different behaviors
                                                                                                                                                                                             InputStream firstStream = mock(InputStream.class);
                                                                                                                                                                                             when(firstStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                 .thenReturn(10); // First read returns 10 bytes
                                                                                                                                                                                             
                                                                                                                                                                                             InputStream secondStream = mock(InputStream.class);
                                                                                                                                                                                             when(secondStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                 .thenReturn(20); // Second read returns 20 bytes
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private field deferredBlockStreams
                                                                                                                                                                                             Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                             deferredStreamsField.setAccessible(true);
                                                                                                                                                                                             ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                             deferredStreams.add(firstStream);
                                                                                                                                                                                             deferredStreams.add(secondStream);
                                                                                                                                                                                             deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test - first read
                                                                                                                                                                                             byte[] buffer = new byte[100];
                                                                                                                                                                                             int read1 = sevenZFile.read(buffer);
                                                                                                                                                                                             assertEquals(10, read1);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify first stream was removed (original behavior)
                                                                                                                                                                                             assertEquals(1, deferredStreams.size());
                                                                                                                                                                                             assertSame(secondStream, deferredStreams.get(0));
                                                                                                                                                                                             
                                                                                                                                                                                             // Test - second read
                                                                                                                                                                                             int read2 = sevenZFile.read(buffer);
                                                                                                                                                                                             assertEquals(20, read2);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify second stream was removed (original behavior)
                                                                                                                                                                                             assertTrue(deferredStreams.isEmpty());
                                                                                                                                                                                             
                                                                                                                                                                                             // Clean up
                                                                                                                                                                                             deferredStreamsField.setAccessible(false);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                         public void testReadRemovesStreamFromDeferredBlockStreams() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                             
                                                                                                                                                                                             // Create mock streams
                                                                                                                                                                                             InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                             InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                             
                                                                                                                                                                                             // Configure mock behaviors
                                                                                                                                                                                             when(mockStream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                                                                                             when(mockStream2.read(any(byte[].class), anyInt(), anyInt())).thenReturn(20);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private field deferredBlockStreams
                                                                                                                                                                                             Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                             deferredStreamsField.setAccessible(true);
                                                                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                                                                             ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                                                                                                                                                             
                                                                                                                                                                                             // Add our mock streams
                                                                                                                                                                                             deferredStreams.add(mockStream1);
                                                                                                                                                                                             deferredStreams.add(mockStream2);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test reading
                                                                                                                                                                                             byte[] buffer = new byte[100];
                                                                                                                                                                                             sevenZFile.read(buffer, 0, 100); // Should read from first stream and remove it
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify
                                                                                                                                                                                             assertEquals(1, deferredStreams.size()); // Original would have 1 left, mutant would have 2
                                                                                                                                                                                             assertSame(mockStream2, deferredStreams.get(0)); // Only second stream should remain
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify mock interactions
                                                                                                                                                                                             verify(mockStream1).read(eq(buffer), eq(0), eq(100));
                                                                                                                                                                                             verify(mockStream2, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                        public void testReadWithStreamSkip() throws Exception {
                                                                                                                                                                                            // Setup mock stream with test data
                                                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                            when(mockStream.read()).thenReturn(1, 2, 3, -1);
                                                                                                                                                                                            
                                                                                                                                                                                            // Create SevenZFile instance and inject mock stream
                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                            currentStreamField.setAccessible(true);
                                                                                                                                                                                            currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                                            
                                                                                                                                                                                            // First read should return first byte
                                                                                                                                                                                            assertEquals(1, sevenZFile.read());
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify skip was called with Long.MAX_VALUE (original behavior)
                                                                                                                                                                                            // The mutant would call skip(0) instead
                                                                                                                                                                                            verify(mockStream).skip(Long.MAX_VALUE);
                                                                                                                                                                                            
                                                                                                                                                                                            // Subsequent reads should return following bytes
                                                                                                                                                                                            assertEquals(2, sevenZFile.read());
                                                                                                                                                                                            assertEquals(3, sevenZFile.read());
                                                                                                                                                                                            assertEquals(-1, sevenZFile.read());
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify total interactions
                                                                                                                                                                                            verify(mockStream, times(4)).read();
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testReadWithSkipping() throws Exception {
                                                                                                                                                                                            // Create a temporary 7z file with known content
                                                                                                                                                                                            File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                            try {
                                                                                                                                                                                                // Create a simple 7z file with some content (in real test would use actual 7z file)
                                                                                                                                                                                                try (RandomAccessFile raf = new RandomAccessFile(tempFile, "rw")) {
                                                                                                                                                                                                    raf.write(new byte[1024]); // Some header/data
                                                                                                                                                                                                    raf.write("TESTDATA".getBytes()); // Content we want to read
                                                                                                                                                                                                    raf.write(new byte[1024]); // More data to skip
                                                                                                                                                                                                }
                                                                                                                                                                                        
                                                                                                                                                                                                // Test the read operation that should involve skipping
                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                try {
                                                                                                                                                                                                    // First read some data
                                                                                                                                                                                                    byte[] buffer = new byte[8];
                                                                                                                                                                                                    int read = sevenZFile.read(buffer);
                                                                                                                                                                                                    assertEquals(8, read);
                                                                                                                                                                                                    assertEquals("TESTDATA", new String(buffer));
                                                                                                                                                                                        
                                                                                                                                                                                                    // Now test that skipping works properly
                                                                                                                                                                                                    // The mutation would fail here because it wouldn't skip properly
                                                                                                                                                                                                    byte[] afterSkip = new byte[1024];
                                                                                                                                                                                                    read = sevenZFile.read(afterSkip);
                                                                                                                                                                                                    // Original behavior would skip to end and return -1
                                                                                                                                                                                                    // Mutated behavior would try to read the remaining data
                                                                                                                                                                                                    assertEquals(-1, read); // Should have skipped to end
                                                                                                                                                                                                } finally {
                                                                                                                                                                                                    sevenZFile.close();
                                                                                                                                                                                                }
                                                                                                                                                                                            } finally {
                                                                                                                                                                                                tempFile.delete();
                                                                                                                                                                                            }
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testReadWithStreamSkip1() throws Exception {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            byte[] testData = "Test data for SevenZFile".getBytes();
                                                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                            
                                                                                                                                                                                            // Configure mock behavior
                                                                                                                                                                                            when(mockStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                .thenReturn(testData.length);
                                                                                                                                                                                            
                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                            
                                                                                                                                                                                            // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                                            Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                            streamField.setAccessible(true);
                                                                                                                                                                                            streamField.set(sevenZFile, mockStream);
                                                                                                                                                                                            
                                                                                                                                                                                            // Test data buffer
                                                                                                                                                                                            byte[] buffer = new byte[1024];
                                                                                                                                                                                            
                                                                                                                                                                                            // Call the method
                                                                                                                                                                                            int bytesRead = sevenZFile.read(buffer, 0, buffer.length);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify the skip operation was called with Long.MAX_VALUE
                                                                                                                                                                                            // This is the key assertion that will catch the mutant
                                                                                                                                                                                            verify(mockStream).skip(Long.MAX_VALUE);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify the read operation
                                                                                                                                                                                            verify(mockStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                                                                                                                            assertEquals(testData.length, bytesRead);
                                                                                                                                                                                            
                                                                                                                                                                                            // Clean up
                                                                                                                                                                                            sevenZFile.close();
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                       public void testReadShouldCloseStreamAfterOperation() throws Exception {
                                                                                                                                                                                           // Setup
                                                                                                                                                                                           byte[] testData = new byte[10];
                                                                                                                                                                                           InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                           when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                                                                                           
                                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                           // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                                           Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                           streamField.setAccessible(true);
                                                                                                                                                                                           streamField.set(sevenZFile, mockStream);
                                                                                                                                                                                           
                                                                                                                                                                                           // Test
                                                                                                                                                                                           sevenZFile.read(testData);
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify
                                                                                                                                                                                           verify(mockStream, times(1)).close();
                                                                                                                                                                                           
                                                                                                                                                                                           // Cleanup
                                                                                                                                                                                           streamField.setAccessible(false);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                       public void testReadShouldCloseStreamAfterReading() throws Exception {
                                                                                                                                                                                           // Setup
                                                                                                                                                                                           byte[] buffer = new byte[10];
                                                                                                                                                                                           InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                           when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                                                           
                                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                           // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                                           Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                           streamField.setAccessible(true);
                                                                                                                                                                                           streamField.set(sevenZFile, mockStream);
                                                                                                                                                                                           
                                                                                                                                                                                           // Exercise
                                                                                                                                                                                           sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify
                                                                                                                                                                                           verify(mockStream).close();  // This will fail if the mutant is present
                                                                                                                                                                                           
                                                                                                                                                                                           // Cleanup
                                                                                                                                                                                           streamField.setAccessible(false);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                      public void testReadShouldCloseStreamWhenDone() throws Exception {
                                                                                                                                                                                          // Setup
                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                          InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock behavior
                                                                                                                                                                                          when(mockStream.read()).thenReturn(-1); // Simulate EOF
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to set the current stream
                                                                                                                                                                                          Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                                          currentStreamField.setAccessible(true);
                                                                                                                                                                                          currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                                          
                                                                                                                                                                                          // Execute
                                                                                                                                                                                          sevenZFile.read();
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify stream was closed
                                                                                                                                                                                          verify(mockStream).close();
                                                                                                                                                                                          
                                                                                                                                                                                          // Cleanup
                                                                                                                                                                                          sevenZFile.close();
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                  public void testReadShouldUseFirstDeferredBlockStream() throws Exception {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                      
                                                                                                                                                                                      // Create a mock input stream that will return test data
                                                                                                                                                                                      InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                      when(mockStream.read()).thenReturn(42); // Return test data
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to inject our mock stream into deferredBlockStreams
                                                                                                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                      ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                      streams.add(mockStream);
                                                                                                                                                                                      deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      int result = sevenZFile.read();
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      assertEquals("Should return data from the first deferred block stream", 42, result);
                                                                                                                                                                                      verify(mockStream).read(); // Verify the stream was actually used
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                  public void testReadByteArrayShouldReturnBytesReadNotStream() throws Exception {
                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                      byte[] testBuffer = new byte[10];
                                                                                                                                                                                      byte[] mockData = {1, 2, 3, 4, 5};
                                                                                                                                                                                      
                                                                                                                                                                                      // Create mock objects
                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                      InputStream mockStream = new ByteArrayInputStream(mockData);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to inject our mock stream since the field is private
                                                                                                                                                                                      Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                      field.setAccessible(true);
                                                                                                                                                                                      field.set(sevenZFile, mockStream);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test the method
                                                                                                                                                                                      int bytesRead = sevenZFile.read(testBuffer);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify behavior
                                                                                                                                                                                      assertEquals("Should return number of bytes read", mockData.length, bytesRead);
                                                                                                                                                                                      assertArrayEquals("Buffer should contain read data", 
                                                                                                                                                                                                       Arrays.copyOf(mockData, mockData.length), 
                                                                                                                                                                                                       Arrays.copyOf(testBuffer, mockData.length));
                                                                                                                                                                                      
                                                                                                                                                                                      // Additional verification that we're not returning a stream
                                                                                                                                                                                      assertFalse("Return value should not be an InputStream", 
                                                                                                                                                                                                 InputStream.class.isInstance(bytesRead));
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                  public void testReadWithDeferredBlockStreams() throws Exception {
                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                      byte[] buffer = new byte[10];
                                                                                                                                                                                      int offset = 0;
                                                                                                                                                                                      int length = 10;
                                                                                                                                                                                      
                                                                                                                                                                                      // Create mock InputStream that will be returned by getCurrentStream()
                                                                                                                                                                                      InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                      when(mockStream.read(buffer, offset, length)).thenReturn(length);
                                                                                                                                                                                      
                                                                                                                                                                                      // Create SevenZFile with deferred block streams
                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to access private field deferredBlockStreams since it's private
                                                                                                                                                                                      Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                      deferredStreamsField.setAccessible(true);
                                                                                                                                                                                      @SuppressWarnings("unchecked")
                                                                                                                                                                                      ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                                                                                                                                                      deferredStreams.add(mockStream);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test the read operation
                                                                                                                                                                                      int bytesRead = sevenZFile.read(buffer, offset, length);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify results
                                                                                                                                                                                      assertEquals("Should have read all requested bytes", length, bytesRead);
                                                                                                                                                                                      verify(mockStream).read(buffer, offset, length);
                                                                                                                                                                                      
                                                                                                                                                                                      // This test would fail if getCurrentStream() returns null,
                                                                                                                                                                                      // as it would throw NullPointerException when trying to read
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                 public void testReadShouldUseFirstStreamFromDeferredBlockStreams() throws Exception {
                                                                                                                                                                                     // Arrange
                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                     
                                                                                                                                                                                     // Create mock streams with different behaviors
                                                                                                                                                                                     InputStream firstStream = mock(InputStream.class);
                                                                                                                                                                                     InputStream lastStream = mock(InputStream.class);
                                                                                                                                                                                     
                                                                                                                                                                                     // Set up different return values to distinguish which stream was read
                                                                                                                                                                                     when(firstStream.read()).thenReturn(1);
                                                                                                                                                                                     when(lastStream.read()).thenReturn(2);
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to inject our mock streams since deferredBlockStreams is private
                                                                                                                                                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                     deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                     ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                     streams.add(firstStream);
                                                                                                                                                                                     streams.add(mock(InputStream.class)); // middle stream
                                                                                                                                                                                     streams.add(lastStream);
                                                                                                                                                                                     deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                     
                                                                                                                                                                                     // Also mock current stream to return our first stream
                                                                                                                                                                                     InputStream currentStream = mock(InputStream.class);
                                                                                                                                                                                     when(currentStream.read()).thenReturn(1);
                                                                                                                                                                                     Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                                     currentStreamField.setAccessible(true);
                                                                                                                                                                                     currentStreamField.set(sevenZFile, currentStream);
                                                                                                                                                                                     
                                                                                                                                                                                     // Act
                                                                                                                                                                                     int result = sevenZFile.read();
                                                                                                                                                                                     
                                                                                                                                                                                     // Assert
                                                                                                                                                                                     assertEquals(1, result); // Should read from first stream
                                                                                                                                                                                     verify(firstStream).read(); // Verify first stream was read
                                                                                                                                                                                     verify(lastStream, never()).read(); // Verify last stream wasn't read
                                                                                                                                                                                     
                                                                                                                                                                                     // Clean up
                                                                                                                                                                                     deferredBlockStreamsField.setAccessible(false);
                                                                                                                                                                                     currentStreamField.setAccessible(false);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                public void testReadShouldUseFirstStreamWhenMultipleStreamsExist() throws Exception {
                                                                                                                                                                                    // Setup mock streams with different behaviors
                                                                                                                                                                                    InputStream firstStream = mock(InputStream.class);
                                                                                                                                                                                    InputStream lastStream = mock(InputStream.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Make them return different values when read is called
                                                                                                                                                                                    when(firstStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                                                                                    when(lastStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(20);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create test object and set up multiple streams
                                                                                                                                                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                    ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                    streams.add(firstStream);
                                                                                                                                                                                    streams.add(lastStream);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set private field since there's no setter
                                                                                                                                                                                    Field field = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                                                    field.set(sevenZFile, streams);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test the read method
                                                                                                                                                                                    byte[] buffer = new byte[100];
                                                                                                                                                                                    int result = sevenZFile.read(buffer);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify it used the first stream (original behavior)
                                                                                                                                                                                    assertEquals(10, result); // Should be 10 if using first stream, 20 if using last
                                                                                                                                                                                    verify(firstStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                                                                                                                    verify(lastStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                    
                                                                                                                                                                                    // Clean up
                                                                                                                                                                                    field.setAccessible(false);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                            public void testGetCurrentStreamReturnsFirstStream() throws Exception {
                                                                                                                                                                                // Setup - create multiple mock streams
                                                                                                                                                                                InputStream firstStream = mock(InputStream.class);
                                                                                                                                                                                InputStream lastStream = mock(InputStream.class);
                                                                                                                                                                                
                                                                                                                                                                                // Create SevenZFile instance using reflection since constructor needs file access
                                                                                                                                                                                SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                
                                                                                                                                                                                // Set up deferredBlockStreams with multiple streams
                                                                                                                                                                                ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                streams.add(firstStream);
                                                                                                                                                                                streams.add(mock(InputStream.class)); // middle stream
                                                                                                                                                                                streams.add(lastStream);
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to set private field since it's final
                                                                                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                
                                                                                                                                                                                // Get the private getCurrentStream method via reflection
                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Test by invoking the private method
                                                                                                                                                                                InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                
                                                                                                                                                                                // Verify
                                                                                                                                                                                assertSame("Should return first stream from deferredBlockStreams", 
                                                                                                                                                                                          firstStream, result);
                                                                                                                                                                                assertNotSame("Should not return last stream (mutant behavior)",
                                                                                                                                                                                             lastStream, result);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                        public void testReadDelegatesToCurrentStream() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                            Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            field.set(sevenZFile, mockStream);
                                                                                                                                                                            
                                                                                                                                                                            // Test case 1: Normal read returns bytes
                                                                                                                                                                            when(mockStream.read()).thenReturn(42);
                                                                                                                                                                            assertEquals("Should return same value as underlying stream", 
                                                                                                                                                                                        42, sevenZFile.read());
                                                                                                                                                                            
                                                                                                                                                                            // Test case 2: EOF condition
                                                                                                                                                                            when(mockStream.read()).thenReturn(-1);
                                                                                                                                                                            assertEquals("Should return -1 for EOF", 
                                                                                                                                                                                        -1, sevenZFile.read());
                                                                                                                                                                            
                                                                                                                                                                            // Verify interactions
                                                                                                                                                                            verify(mockStream, times(2)).read();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testReadByteArrayShouldReturnActualBytesRead1() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                            byte[] buffer = new byte[5];
                                                                                                                                                                            
                                                                                                                                                                            // Create a mock InputStream that will return 3 bytes when read is called
                                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                            when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(3);
                                                                                                                                                                            
                                                                                                                                                                            // Create a SevenZFile instance and inject our mock stream
                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                            // Use reflection to set the private currentFolderInputStream field
                                                                                                                                                                            Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                            field.set(sevenZFile, mockStream);
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            int bytesRead = sevenZFile.read(buffer, 0, 5);
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            // The original implementation would return 3 (from mock), mutant returns 0
                                                                                                                                                                            assertEquals("Should return actual number of bytes read", 3, bytesRead);
                                                                                                                                                                            
                                                                                                                                                                            // Verify the mock was called correctly
                                                                                                                                                                            verify(mockStream).read(eq(buffer), eq(0), eq(5));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                       public void testReadShouldReturnActualByteFromStream() throws Exception {
                                                                                                                                                                           // Setup
                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                           InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                           
                                                                                                                                                                           // Mock the stream to return specific byte values
                                                                                                                                                                           when(mockStream.read()).thenReturn(42, -1); // First read returns 42, then EOF
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to set the private currentStream field
                                                                                                                                                                           Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                           currentStreamField.setAccessible(true);
                                                                                                                                                                           currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                           
                                                                                                                                                                           // Test
                                                                                                                                                                           int firstByte = sevenZFile.read();
                                                                                                                                                                           int eofByte = sevenZFile.read();
                                                                                                                                                                           
                                                                                                                                                                           // Verify
                                                                                                                                                                           assertEquals("First byte should be 42", 42, firstByte);
                                                                                                                                                                           assertEquals("EOF should return -1", -1, eofByte);
                                                                                                                                                                           
                                                                                                                                                                           // Verify interactions
                                                                                                                                                                           verify(mockStream, times(2)).read();
                                                                                                                                                                       }

    @Test
                                                                                                                                                                   public void testReadShouldReturnByteFromStreamNotJustMinusOne1() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                       
                                                                                                                                                                       // Create a mock stream that will return data
                                                                                                                                                                       InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                       when(mockStream.read()).thenReturn(42); // Return some test data
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                       Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                       field.setAccessible(true);
                                                                                                                                                                       field.set(sevenZFile, mockStream);
                                                                                                                                                                       
                                                                                                                                                                       // Test
                                                                                                                                                                       int result = sevenZFile.read();
                                                                                                                                                                       
                                                                                                                                                                       // Verify
                                                                                                                                                                       assertEquals("Should return the byte read from stream", 42, result);
                                                                                                                                                                       
                                                                                                                                                                       // Additional verification that we actually tried to read from the stream
                                                                                                                                                                       verify(mockStream).read();
                                                                                                                                                                   }

    @Test
                                                                                                                                                                  public void testReadShouldReturnByteFromStreamNotAlwaysMinusOne() throws Exception {
                                                                                                                                                                      // Setup mock stream that returns specific bytes
                                                                                                                                                                      InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                      when(mockStream.read())
                                                                                                                                                                          .thenReturn(65)  // first byte 'A'
                                                                                                                                                                          .thenReturn(66)  // second byte 'B'
                                                                                                                                                                          .thenReturn(-1); // end of stream
                                                                                                                                                                      
                                                                                                                                                                      // Create real SevenZFile instance (using a dummy file)
                                                                                                                                                                      File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                      tempFile.deleteOnExit();
                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set the private currentStream field
                                                                                                                                                                      Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                                      currentStreamField.setAccessible(true);
                                                                                                                                                                      currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                      
                                                                                                                                                                      // First read should return 65 ('A')
                                                                                                                                                                      assertEquals(65, sevenZFile.read());
                                                                                                                                                                      
                                                                                                                                                                      // Second read should return 66 ('B')
                                                                                                                                                                      assertEquals(66, sevenZFile.read());
                                                                                                                                                                      
                                                                                                                                                                      // Third read should return -1 (end of stream)
                                                                                                                                                                      assertEquals(-1, sevenZFile.read());
                                                                                                                                                                      
                                                                                                                                                                      // Verify the stream was called exactly 3 times
                                                                                                                                                                      verify(mockStream, times(3)).read();
                                                                                                                                                                      
                                                                                                                                                                      sevenZFile.close();
                                                                                                                                                                  }

    @Test
                                                                                                                                                                  public void testReadWithAvailableDataShouldReturnBytesRead() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      byte[] testData = {1, 2, 3, 4, 5};
                                                                                                                                                                      byte[] buffer = new byte[5];
                                                                                                                                                                      
                                                                                                                                                                      // Mock the current stream to return actual data
                                                                                                                                                                      InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                      when(mockStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                          .thenAnswer(invocation -> {
                                                                                                                                                                              byte[] b = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                              int off = (Integer) invocation.getArguments()[1];
                                                                                                                                                                              int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                              System.arraycopy(testData, 0, b, off, Math.min(len, testData.length));
                                                                                                                                                                              return Math.min(len, testData.length);
                                                                                                                                                                          });
                                                                                                                                                                      
                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                      // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                                                                      Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                      field.setAccessible(true);
                                                                                                                                                                      field.set(sevenZFile, mockStream);
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      int bytesRead = sevenZFile.read(buffer, 0, buffer.length);
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      assertNotEquals("Should not return -1 when data is available", -1, bytesRead);
                                                                                                                                                                      assertEquals("Should read all available bytes", testData.length, bytesRead);
                                                                                                                                                                      assertArrayEquals("Buffer should contain read data", testData, buffer);
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testReadWithZeroSizedFileShouldHandleSpecially() throws Exception {
                                                                                                                                                                 // Setup
                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                 
                                                                                                                                                                 // Create a zero-sized entry
                                                                                                                                                                 SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                 when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set the current entry and index
                                                                                                                                                                 Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntry");
                                                                                                                                                                 currentEntryField.setAccessible(true);
                                                                                                                                                                 currentEntryField.set(sevenZFile, entry);
                                                                                                                                                                 
                                                                                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Mock the current stream to return -1 (or throw if mutant is active)
                                                                                                                                                                 InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                 when(mockStream.read()).thenReturn(-1);
                                                                                                                                                                 
                                                                                                                                                                 Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                 currentStreamField.setAccessible(true);
                                                                                                                                                                 currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                 
                                                                                                                                                                 // Test
                                                                                                                                                                 int result = sevenZFile.read();
                                                                                                                                                                 
                                                                                                                                                                 // Verify - original would return -1 for zero-sized file
                                                                                                                                                                 // Mutant would try to read from stream (which we mocked to return -1)
                                                                                                                                                                 // So we need to verify stream interaction
                                                                                                                                                                 verify(mockStream, never()).read(); // Original shouldn't call read()
                                                                                                                                                                 assertEquals(-1, result); // Original should return -1 directly
                                                                                                                                                             }

    @Test
                                                                                                                                                             public void testReadWithEmptyFileEntry1() throws Exception {
                                                                                                                                                                 // Create a temporary empty 7z file
                                                                                                                                                                 File emptyFile = File.createTempFile("empty", ".7z");
                                                                                                                                                                 emptyFile.deleteOnExit();
                                                                                                                                                                 
                                                                                                                                                                 // Create SevenZFile instance with the empty file
                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(emptyFile);
                                                                                                                                                                 
                                                                                                                                                                 // Setup test data
                                                                                                                                                                 byte[] buffer = new byte[1024];
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set currentEntryIndex to 0
                                                                                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                 
                                                                                                                                                                 // The read should return -1 for empty file
                                                                                                                                                                 int result = sevenZFile.read(buffer);
                                                                                                                                                                 
                                                                                                                                                                 // Verify the result
                                                                                                                                                                 assertEquals("Should return -1 for empty file", -1, result);
                                                                                                                                                                 
                                                                                                                                                                 // Clean up
                                                                                                                                                                 sevenZFile.close();
                                                                                                                                                             }

    @Test
                                                                                                                                                             public void testReadWithZeroSizedFileShouldHandleDifferently() throws Exception {
                                                                                                                                                                 // Setup - create a temporary empty 7z file
                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                 tempFile.deleteOnExit();
                                                                                                                                                                 
                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                 
                                                                                                                                                                 // Create a mock entry
                                                                                                                                                                 SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                 when(mockEntry.getSize()).thenReturn(0L);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set private fields since we need to test internal behavior
                                                                                                                                                                 Field entriesField = SevenZFile.class.getDeclaredField("entries");
                                                                                                                                                                 entriesField.setAccessible(true);
                                                                                                                                                                 entriesField.set(sevenZFile, new SevenZArchiveEntry[]{mockEntry});
                                                                                                                                                                 
                                                                                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Test with zero-sized file (should return -1)
                                                                                                                                                                 byte[] buffer = new byte[10];
                                                                                                                                                                 int result = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                 assertEquals("Should return -1 for zero-sized file", -1, result);
                                                                                                                                                                 
                                                                                                                                                                 // Test with non-zero sized file for completeness
                                                                                                                                                                 when(mockEntry.getSize()).thenReturn(100L);
                                                                                                                                                                 InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                 when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                                 
                                                                                                                                                                 Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                                 currentStreamField.setAccessible(true);
                                                                                                                                                                 currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                                                 
                                                                                                                                                                 result = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                                 assertEquals("Should return actual bytes read for non-zero file", 5, result);
                                                                                                                                                                 
                                                                                                                                                                 sevenZFile.close();
                                                                                                                                                             }

    @Test
                                                                                                                                                        public void testReadWithEmptyFileShouldReturnMinusOne1() throws Exception {
                                                                                                                                                            // Setup mock objects
                                                                                                                                                            SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                            InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set private currentStream field
                                                                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                            currentStreamField.setAccessible(true);
                                                                                                                                                            currentStreamField.set(sevenZFile, emptyStream);
                                                                                                                                                            
                                                                                                                                                            // Call the real read method (not mocked)
                                                                                                                                                            when(sevenZFile.read()).thenCallRealMethod();
                                                                                                                                                            
                                                                                                                                                            // Test that reading from empty file returns -1
                                                                                                                                                            int result = sevenZFile.read();
                                                                                                                                                            assertEquals(-1, result);
                                                                                                                                                            
                                                                                                                                                            // Verify the stream was read
                                                                                                                                                            verify(sevenZFile).read();
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testReadWithNonZeroSizeEntry() throws Exception {
                                                                                                                                                            // Setup test data
                                                                                                                                                            byte[] buffer = new byte[10];
                                                                                                                                                            SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                            when(mockEntry.getSize()).thenReturn(5L); // Non-zero size
                                                                                                                                                            
                                                                                                                                                            // Mock input stream that would return data
                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                            when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                            
                                                                                                                                                            // Create SevenZFile instance with mocks using reflection
                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                            archiveField.setAccessible(true);
                                                                                                                                                            Object mockArchive = mock(archiveField.getType());
                                                                                                                                                            when(mockArchive.getClass().getMethod("getFiles").invoke(mockArchive))
                                                                                                                                                                .thenReturn(new SevenZArchiveEntry[]{mockEntry});
                                                                                                                                                            archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                            
                                                                                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                            
                                                                                                                                                            Field currentFolderInputStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                            currentFolderInputStreamField.setAccessible(true);
                                                                                                                                                            currentFolderInputStreamField.set(sevenZFile, mockStream);
                                                                                                                                                            
                                                                                                                                                            // Test the read operation
                                                                                                                                                            int bytesRead = sevenZFile.read(buffer);
                                                                                                                                                            
                                                                                                                                                            // Verify behavior
                                                                                                                                                            assertEquals("Should have read 5 bytes", 5, bytesRead);
                                                                                                                                                            verify(mockStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                                                                                                                            
                                                                                                                                                            // Additional check to ensure the if condition was properly evaluated
                                                                                                                                                            assertTrue("Should have read some data", bytesRead > 0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testReadWithNonZeroSizeEntryShouldCallStreamRead() throws Exception {
                                                                                                                                                            // Setup test data
                                                                                                                                                            byte[] buffer = new byte[10];
                                                                                                                                                            int offset = 0;
                                                                                                                                                            int length = 10;
                                                                                                                                                            
                                                                                                                                                            // Mock dependencies
                                                                                                                                                            SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                            when(mockEntry.getSize()).thenReturn(100L); // Non-zero size
                                                                                                                                                            
                                                                                                                                                            // Create test instance
                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                            archiveField.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Create a mock archive structure
                                                                                                                                                            Object mockArchive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                                            Field filesField = mockArchive.getClass().getDeclaredField("files");
                                                                                                                                                            filesField.setAccessible(true);
                                                                                                                                                            filesField.set(mockArchive, new SevenZArchiveEntry[]{mockEntry});
                                                                                                                                                            
                                                                                                                                                            archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                            
                                                                                                                                                            Field entryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                            entryIndexField.setAccessible(true);
                                                                                                                                                            entryIndexField.set(sevenZFile, 0);
                                                                                                                                                            
                                                                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                                                                            when(mockStream.read(buffer, offset, length)).thenReturn(5); // Simulate reading 5 bytes
                                                                                                                                                            
                                                                                                                                                            // Use reflection to inject the mock stream since it's private
                                                                                                                                                            Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                            streamField.setAccessible(true);
                                                                                                                                                            streamField.set(sevenZFile, mockStream);
                                                                                                                                                            
                                                                                                                                                            // Call method under test
                                                                                                                                                            int result = sevenZFile.read(buffer, offset, length);
                                                                                                                                                            
                                                                                                                                                            // Verify behavior
                                                                                                                                                            verify(mockStream).read(buffer, offset, length);
                                                                                                                                                            assertEquals(5, result); // Verify return value
                                                                                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                                                                                   public void testReadWhenCurrentStreamIsNull1() throws Exception {
                                                                                                                                                       // Create a real SevenZFile instance with a dummy file
                                                                                                                                                       File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                       tempFile.deleteOnExit();
                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set the private currentStream field to null
                                                                                                                                                       Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                       currentStreamField.setAccessible(true);
                                                                                                                                                       currentStreamField.set(sevenZFile, null);
                                                                                                                                                       
                                                                                                                                                       // This should throw NullPointerException
                                                                                                                                                       sevenZFile.read();
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testReadReturnsNonNullStream1() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       byte[] testBuffer = new byte[10];
                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                       
                                                                                                                                                       // Mock the internal stream to return empty data
                                                                                                                                                       InputStream mockStream = mock(InputStream.class);
                                                                                                                                                       when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set the private currentFolderInputStream field
                                                                                                                                                       Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                       field.setAccessible(true);
                                                                                                                                                       field.set(sevenZFile, mockStream);
                                                                                                                                                       
                                                                                                                                                       // Test
                                                                                                                                                       int result = sevenZFile.read(testBuffer);
                                                                                                                                                       
                                                                                                                                                       // Verify
                                                                                                                                                       // Use reflection to get the private currentFolderInputStream field
                                                                                                                                                       InputStream currentStream = (InputStream) field.get(sevenZFile);
                                                                                                                                                       assertNotNull("Returned stream should not be null", currentStream);
                                                                                                                                                       assertEquals("Should return 0 bytes read", 0, result);
                                                                                                                                                       
                                                                                                                                                       // Clean up
                                                                                                                                                       sevenZFile.close();
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testReadWithNullCurrentStream1() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                       byte[] buffer = new byte[10];
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set the current stream to null
                                                                                                                                                       Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                       currentStreamField.setAccessible(true);
                                                                                                                                                       currentStreamField.set(sevenZFile, null);
                                                                                                                                                       
                                                                                                                                                       try {
                                                                                                                                                           sevenZFile.read(buffer, 0, 10);
                                                                                                                                                           // If we reach here, the test fails (original behavior didn't throw)
                                                                                                                                                           fail("Expected NullPointerException when current stream is null");
                                                                                                                                                       } catch (NullPointerException e) {
                                                                                                                                                           // Expected exception
                                                                                                                                                       }
                                                                                                                                                   }

    @Test
                                                                                                                                               public void testReadWithEmptyStream2() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                   byte[] buffer = new byte[10];
                                                                                                                                                   
                                                                                                                                                   // Mock the current stream to return empty stream (original behavior)
                                                                                                                                                   InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                   InputStream oneByteStream = new ByteArrayInputStream(new byte[1]);
                                                                                                                                                   
                                                                                                                                                   // Use reflection to inject our test stream since currentFolderInputStream is private
                                                                                                                                                   Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                                   field.setAccessible(true);
                                                                                                                                                   
                                                                                                                                                   // Test original behavior (should read 0 bytes)
                                                                                                                                                   field.set(sevenZFile, emptyStream);
                                                                                                                                                   int bytesRead = sevenZFile.read(buffer);
                                                                                                                                                   assertEquals(0, bytesRead);
                                                                                                                                                   
                                                                                                                                                   // Test mutated behavior (should read 1 byte)
                                                                                                                                                   field.set(sevenZFile, oneByteStream);
                                                                                                                                                   bytesRead = sevenZFile.read(buffer);
                                                                                                                                                   assertEquals(1, bytesRead);  // This will fail if mutant returns empty stream
                                                                                                                                                   assertEquals(0, buffer[0]);  // Verify the byte value is 0
                                                                                                                                                   
                                                                                                                                                   // Clean up
                                                                                                                                                   sevenZFile.close();
                                                                                                                                               }

    @Test
                                                                                                                                              public void testReadWithEmptyStream3() throws Exception {
                                                                                                                                                  // Setup
                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                  InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                  
                                                                                                                                                  // Use reflection to access private getCurrentStream method
                                                                                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                  
                                                                                                                                                  // Create a spy that will use our empty stream
                                                                                                                                                  SevenZFile spySevenZFile = spy(sevenZFile);
                                                                                                                                                  doReturn(emptyStream).when(spySevenZFile).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                  
                                                                                                                                                  // Test
                                                                                                                                                  int result = spySevenZFile.read();
                                                                                                                                                  
                                                                                                                                                  // Verify
                                                                                                                                                  assertEquals("read() should return -1 for empty stream", -1, result);
                                                                                                                                                  
                                                                                                                                                  // Additional verification that subsequent reads also return -1
                                                                                                                                                  assertEquals("subsequent read() should still return -1", -1, spySevenZFile.read());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testReadWithEmptyStream4() throws Exception {
                                                                                                                                                  // Setup
                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                  
                                                                                                                                                  // Use reflection to access private currentStream field
                                                                                                                                                  Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                                  currentStreamField.setAccessible(true);
                                                                                                                                                  
                                                                                                                                                  // Test with empty stream
                                                                                                                                                  InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                  currentStreamField.set(sevenZFile, emptyStream);
                                                                                                                                                  
                                                                                                                                                  // Test read with buffer
                                                                                                                                                  byte[] buffer = new byte[10];
                                                                                                                                                  int bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                  
                                                                                                                                                  // Verify - should return -1 for empty stream
                                                                                                                                                  assertEquals("Should return -1 for empty stream", -1, bytesRead);
                                                                                                                                                  
                                                                                                                                                  // Now test with mutant behavior (stream with 1 byte)
                                                                                                                                                  InputStream oneByteStream = new ByteArrayInputStream(new byte[1]);
                                                                                                                                                  currentStreamField.set(sevenZFile, oneByteStream);
                                                                                                                                                  
                                                                                                                                                  bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                                                                                                  
                                                                                                                                                  // Verify - should read 0 or 1 bytes (not -1) for non-empty stream
                                                                                                                                                  assertNotEquals("Should not return -1 for non-empty stream", -1, bytesRead);
                                                                                                                                                  assertTrue("Should read between 0 and 1 bytes", bytesRead >= 0 && bytesRead <= 1);
                                                                                                                                              }

    @Test
                                                                                                                                          public void testReadWithEmptyDeferredStreams() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                              
                                                                                                                                              // Use reflection to access private fields since we need to test internal behavior
                                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                                              ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                              deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                              
                                                                                                                                              Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                              currentStreamField.setAccessible(true);
                                                                                                                                              InputStream mockCurrentStream = mock(InputStream.class);
                                                                                                                                              when(mockCurrentStream.read()).thenReturn(42);
                                                                                                                                              currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                                                                                              
                                                                                                                                              // Test
                                                                                                                                              int result = sevenZFile.read();
                                                                                                                                              
                                                                                                                                              // Verify
                                                                                                                                              assertEquals(42, result);
                                                                                                                                              verify(mockCurrentStream).read();
                                                                                                                                          }

    @Test
                                                                                                                                          public void testReadWithNonEmptyDeferredStreams1() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                              
                                                                                                                                              // Use reflection to access private fields
                                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                                              ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                              InputStream mockDeferredStream = mock(InputStream.class);
                                                                                                                                              when(mockDeferredStream.read()).thenReturn(99);
                                                                                                                                              deferredStreams.add(mockDeferredStream);
                                                                                                                                              deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                              
                                                                                                                                              Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                              currentStreamField.setAccessible(true);
                                                                                                                                              InputStream mockCurrentStream = mock(InputStream.class);
                                                                                                                                              currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                                                                                              
                                                                                                                                              // Test
                                                                                                                                              int result = sevenZFile.read();
                                                                                                                                              
                                                                                                                                              // Verify - this will catch the mutant since the mutant would read from currentStream instead
                                                                                                                                              assertEquals(99, result);
                                                                                                                                              verify(mockDeferredStream).read();
                                                                                                                                              verify(mockCurrentStream, never()).read();
                                                                                                                                          }

    @Test
                                                                                                                                          public void testReadWithEmptyAndNonEmptyDeferredStreams2() throws Exception {
                                                                                                                                              // Setup test file
                                                                                                                                              File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                              tempFile.deleteOnExit();
                                                                                                                                              
                                                                                                                                              // Create mock streams
                                                                                                                                              InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                              InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                              when(mockStream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                              when(mockStream2.read(any(byte[].class), anyInt(), anyInt())).thenReturn(3);
                                                                                                                                              
                                                                                                                                              // Test case 1: Empty deferredBlockStreams
                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                                              ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                                                                              deferredStreamsField.set(sevenZFile, emptyList);
                                                                                                                                              
                                                                                                                                              Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                              currentStreamField.setAccessible(true);
                                                                                                                                              currentStreamField.set(sevenZFile, mockStream1);
                                                                                                                                              
                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                              assertEquals(5, sevenZFile.read(buffer));  // Should read from currentFolderInputStream
                                                                                                                                              
                                                                                                                                              // Test case 2: Non-empty deferredBlockStreams
                                                                                                                                              ArrayList<InputStream> nonEmptyList = new ArrayList<>();
                                                                                                                                              nonEmptyList.add(mockStream2);
                                                                                                                                              deferredStreamsField.set(sevenZFile, nonEmptyList);
                                                                                                                                              
                                                                                                                                              assertEquals(3, sevenZFile.read(buffer));  // Should read from deferredBlockStreams
                                                                                                                                              
                                                                                                                                              // Clean up
                                                                                                                                              sevenZFile.close();
                                                                                                                                          }

    @Test
                                                                                                                                          public void testReadWithEmptyDeferredStreams1() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                              
                                                                                                                                              // Mock the streams
                                                                                                                                              InputStream mainStream = mock(InputStream.class);
                                                                                                                                              when(mainStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                                              
                                                                                                                                              // Use reflection to set private fields since we need to test internal behavior
                                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                                              ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                              deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                              
                                                                                                                                              Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                              currentStreamField.setAccessible(true);
                                                                                                                                              currentStreamField.set(sevenZFile, mainStream);
                                                                                                                                              
                                                                                                                                              // Test
                                                                                                                                              byte[] buffer = new byte[100];
                                                                                                                                              int result = sevenZFile.read(buffer, 0, 100);
                                                                                                                                              
                                                                                                                                              // Verify
                                                                                                                                              assertEquals(10, result);
                                                                                                                                              verify(mainStream).read(buffer, 0, 100);
                                                                                                                                              // This test would fail with the mutant since it would try to read from deferred streams (empty)
                                                                                                                                          }

    @Test
                                                                                                                                          public void testReadWithNonEmptyDeferredStreams2() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                              
                                                                                                                                              // Mock the streams
                                                                                                                                              InputStream deferredStream = mock(InputStream.class);
                                                                                                                                              when(deferredStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                              
                                                                                                                                              // Use reflection to set private fields
                                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                                              ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                              deferredStreams.add(deferredStream);
                                                                                                                                              deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                              
                                                                                                                                              Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                              currentStreamField.setAccessible(true);
                                                                                                                                              currentStreamField.set(sevenZFile, mock(InputStream.class));
                                                                                                                                              
                                                                                                                                              // Test
                                                                                                                                              byte[] buffer = new byte[100];
                                                                                                                                              int result = sevenZFile.read(buffer, 0, 100);
                                                                                                                                              
                                                                                                                                              // Verify
                                                                                                                                              assertEquals(5, result);
                                                                                                                                              verify(deferredStream).read(buffer, 0, 100);
                                                                                                                                              // This test would fail with the mutant since it would try to read from main stream instead
                                                                                                                                          }

    @Test
                                                                                                                                         public void testReadWithDeferredBlocksShouldNotUseCurrentStream() throws Exception {
                                                                                                                                             // Setup test data
                                                                                                                                             byte[] buffer = new byte[10];
                                                                                                                                             int offset = 0;
                                                                                                                                             int length = 10;
                                                                                                                                             
                                                                                                                                             // Create mock streams
                                                                                                                                             InputStream currentStreamMock = mock(InputStream.class);
                                                                                                                                             InputStream deferredStreamMock = mock(InputStream.class);
                                                                                                                                             
                                                                                                                                             // Setup SevenZFile instance
                                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                             
                                                                                                                                             // Use reflection to set private fields since we need to test internal behavior
                                                                                                                                             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                                                                                             ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                                                                                             deferredBlockStreams.add(deferredStreamMock);
                                                                                                                                             deferredBlockStreamsField.set(sevenZFile, deferredBlockStreams);
                                                                                                                                             
                                                                                                                                             Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                             currentStreamField.setAccessible(true);
                                                                                                                                             currentStreamField.set(sevenZFile, currentStreamMock);
                                                                                                                                             
                                                                                                                                             // Set expectations
                                                                                                                                             when(deferredStreamMock.read(buffer, offset, length)).thenReturn(length);
                                                                                                                                             
                                                                                                                                             // Execute
                                                                                                                                             int result = sevenZFile.read(buffer, offset, length);
                                                                                                                                             
                                                                                                                                             // Verify
                                                                                                                                             assertEquals(length, result);
                                                                                                                                             verify(deferredStreamMock, times(1)).read(buffer, offset, length);
                                                                                                                                             verify(currentStreamMock, never()).read(buffer, offset, length);
                                                                                                                                             
                                                                                                                                             // Clean up
                                                                                                                                             deferredBlockStreamsField.setAccessible(false);
                                                                                                                                             currentStreamField.setAccessible(false);
                                                                                                                                         }

    @Test
                                                                                                                                        public void testReadWithDeferredBlocksShouldNotUseCurrentStream1() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                            
                                                                                                                                            // Create mock streams
                                                                                                                                            InputStream deferredStream = mock(InputStream.class);
                                                                                                                                            InputStream currentStream = mock(InputStream.class);
                                                                                                                                            
                                                                                                                                            // Setup deferred blocks
                                                                                                                                            ArrayList<InputStream> deferredBlocks = new ArrayList<>();
                                                                                                                                            deferredBlocks.add(deferredStream);
                                                                                                                                            // Use reflection to set private field since it's final
                                                                                                                                            Field deferredField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                            deferredField.setAccessible(true);
                                                                                                                                            deferredField.set(sevenZFile, deferredBlocks);
                                                                                                                                            
                                                                                                                                            // Use reflection to set current stream
                                                                                                                                            Field currentField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                            currentField.setAccessible(true);
                                                                                                                                            currentField.set(sevenZFile, currentStream);
                                                                                                                                            
                                                                                                                                            // Mock behavior
                                                                                                                                            when(deferredStream.read()).thenReturn(42);
                                                                                                                                            when(currentStream.read()).thenReturn(99);
                                                                                                                                            
                                                                                                                                            // Test - should read from deferred stream, not current stream
                                                                                                                                            int result = sevenZFile.read();
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertEquals(42, result);
                                                                                                                                            verify(deferredStream).read();
                                                                                                                                            verify(currentStream, never()).read();
                                                                                                                                            
                                                                                                                                            // This test would fail with the mutant since it would always try to read
                                                                                                                                            // from currentStream regardless of deferred blocks
                                                                                                                                        }

    @Test
                                                                                                                                        public void testReadWithDeferredStreamsShouldProcessDeferredFirst() throws Exception {
                                                                                                                                            // Setup test data
                                                                                                                                            byte[] buffer = new byte[10];
                                                                                                                                            byte[] deferredData = {1, 2, 3, 4, 5};
                                                                                                                                            
                                                                                                                                            // Create deferred stream
                                                                                                                                            InputStream deferredStream = new ByteArrayInputStream(deferredData);
                                                                                                                                            ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                                                                                            deferredBlockStreams.add(deferredStream);
                                                                                                                                            
                                                                                                                                            // Create real SevenZFile object
                                                                                                                                            SevenZFile realFile = new SevenZFile(new File("test.7z"));
                                                                                                                                            
                                                                                                                                            // Use reflection to set private fields
                                                                                                                                            Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                            deferredStreamsField.setAccessible(true);
                                                                                                                                            deferredStreamsField.set(realFile, deferredBlockStreams);
                                                                                                                                            
                                                                                                                                            // Set current stream to null using reflection
                                                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                                                            currentStreamField.setAccessible(true);
                                                                                                                                            currentStreamField.set(realFile, null);
                                                                                                                                            
                                                                                                                                            // Call the real read method
                                                                                                                                            int bytesRead = realFile.read(buffer);
                                                                                                                                            
                                                                                                                                            // Verify behavior
                                                                                                                                            assertEquals(deferredData.length, bytesRead);
                                                                                                                                            assertArrayEquals(deferredData, Arrays.copyOf(buffer, bytesRead));
                                                                                                                                            assertTrue(deferredBlockStreams.isEmpty()); // Should be consumed
                                                                                                                                        }

    @Test(expected = IllegalStateException.class)
                                                                                                                                    public void testReadWithoutCurrentEntryThrowsIllegalStateException3() throws Exception {
                                                                                                                                        // Arrange
                                                                                                                                        File mockFile = mock(File.class);
                                                                                                                                        when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                        
                                                                                                                                        RandomAccessFile mockRaf = mock(RandomAccessFile.class);
                                                                                                                                        SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                        
                                                                                                                                        // Mock the internal state to have no current entry
                                                                                                                                        // (currentFolderInputStream would be null in this case)
                                                                                                                                        
                                                                                                                                        byte[] buffer = new byte[1024];
                                                                                                                                        
                                                                                                                                        // Act & Assert
                                                                                                                                        sevenZFile.read(buffer);
                                                                                                                                        
                                                                                                                                        // The test will pass if IllegalStateException is thrown,
                                                                                                                                        // and fail if IOException is thrown or no exception occurs
                                                                                                                                    }

    @Test
                                                                                                                                   public void testReadWithoutCurrentEntryThrowsIllegalStateException4() throws Exception {
                                                                                                                                       // Setup - create a SevenZFile with a mocked file
                                                                                                                                       File mockFile = mock(File.class);
                                                                                                                                       when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                       
                                                                                                                                       // Create real SevenZFile but with mocked dependencies
                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                       
                                                                                                                                       // Set up expected exception
                                                                                                                                       ExpectedException exception = ExpectedException.none();
                                                                                                                                       exception.expect(IllegalStateException.class);
                                                                                                                                       exception.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                       
                                                                                                                                       // Trigger the test - call read() without first calling getNextEntry()
                                                                                                                                       sevenZFile.read();
                                                                                                                                       
                                                                                                                                       // Verification is handled by the ExpectedException rule
                                                                                                                                   }

    @Test
                                                                                                                                   public void testReadThrowsIllegalStateWhenNoCurrentEntry() throws Exception {
                                                                                                                                       // Setup
                                                                                                                                       File mockFile = mock(File.class);
                                                                                                                                       when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                       
                                                                                                                                       // Create SevenZFile with mocked dependencies
                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                       
                                                                                                                                       // Ensure no current entry by not calling getNextEntry()
                                                                                                                                       // and mock getCurrentStream() to return null or throw
                                                                                                                                       // (implementation detail depends on actual class)
                                                                                                                                       
                                                                                                                                       // Test and verify exception
                                                                                                                                       byte[] buffer = new byte[10];
                                                                                                                                       try {
                                                                                                                                           sevenZFile.read(buffer, 0, 10);
                                                                                                                                           fail("Expected IllegalStateException");
                                                                                                                                       } catch (IllegalStateException e) {
                                                                                                                                           assertEquals("No current 7z entry (call getNextEntry() first).", e.getMessage());
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // If the mutant is present, this will fail because it throws IOException instead
                                                                                                                                   }

    @Test
                                                                                                                               public void testReadWithSingleDeferredStream3() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                   
                                                                                                                                   // Mock the deferredBlockStreams with exactly 1 element
                                                                                                                                   ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                   InputStream mockStream = mock(InputStream.class);
                                                                                                                                   when(mockStream.read()).thenReturn(42); // sample data
                                                                                                                                   deferredStreams.add(mockStream);
                                                                                                                                   
                                                                                                                                   // Use reflection to inject our mock deferredBlockStreams
                                                                                                                                   Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                   deferredStreamsField.setAccessible(true);
                                                                                                                                   deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                   
                                                                                                                                   // Also mock current stream to return -1 to force deferred stream processing
                                                                                                                                   InputStream mockCurrentStream = mock(InputStream.class);
                                                                                                                                   when(mockCurrentStream.read()).thenReturn(-1);
                                                                                                                                   
                                                                                                                                   Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                   currentStreamField.setAccessible(true);
                                                                                                                                   currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   int result = sevenZFile.read();
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   // Original behavior (size > 1) would return -1 since it wouldn't process the single deferred stream
                                                                                                                                   // Mutated behavior (size >= 1) would return 42 from the deferred stream
                                                                                                                                   assertEquals("Should return -1 when only one deferred stream exists", -1, result);
                                                                                                                                   
                                                                                                                                   // Verify the deferred stream was NOT read (original behavior)
                                                                                                                                   verify(mockStream, never()).read();
                                                                                                                                   
                                                                                                                                   // Cleanup
                                                                                                                                   sevenZFile.close();
                                                                                                                               }

    @Test
                                                                                                                               public void testReadWithSingleDeferredStream4() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   File mockFile = mock(File.class);
                                                                                                                                   when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                   
                                                                                                                                   // Create SevenZFile with mocked components
                                                                                                                                   SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                   
                                                                                                                                   // Create single deferred stream
                                                                                                                                   InputStream mockStream = mock(InputStream.class);
                                                                                                                                   ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                   deferredStreams.add(mockStream);
                                                                                                                                   
                                                                                                                                   // Inject the single deferred stream using reflection
                                                                                                                                   Field deferredField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                   deferredField.setAccessible(true);
                                                                                                                                   deferredField.set(sevenZFile, deferredStreams);
                                                                                                                                   
                                                                                                                                   // Mock current stream behavior
                                                                                                                                   InputStream mockCurrentStream = mock(InputStream.class);
                                                                                                                                   when(mockCurrentStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                   
                                                                                                                                   Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                   currentStreamField.setAccessible(true);
                                                                                                                                   currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   byte[] buffer = new byte[1024];
                                                                                                                                   int result = sevenZFile.read(buffer);
                                                                                                                                   
                                                                                                                                   // Verify - in original code, single stream shouldn't be processed
                                                                                                                                   // So read should return -1 (no data)
                                                                                                                                   assertEquals(-1, result);
                                                                                                                                   
                                                                                                                                   // Verify deferred stream wasn't touched
                                                                                                                                   verify(mockStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                   
                                                                                                                                   // In mutated code, this would try to process the single stream
                                                                                                                                   // So this test would fail as result would be different
                                                                                                                               }

    @Test
                                                                                                                              public void testReadWithSingleDeferredStream5() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                  
                                                                                                                                  // Create mock input stream that will return specific data
                                                                                                                                  InputStream mockStream = mock(InputStream.class);
                                                                                                                                  when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                  
                                                                                                                                  // Use reflection to inject our single deferred stream
                                                                                                                                  Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                  deferredStreamsField.setAccessible(true);
                                                                                                                                  ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                  deferredStreams.add(mockStream);
                                                                                                                                  deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                  
                                                                                                                                  // Also mock currentFolderInputStream to return our mock stream
                                                                                                                                  Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                                  currentStreamField.setAccessible(true);
                                                                                                                                  currentStreamField.set(sevenZFile, mockStream);
                                                                                                                                  
                                                                                                                                  // Test
                                                                                                                                  byte[] buffer = new byte[10];
                                                                                                                                  int bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  assertEquals(5, bytesRead); // Should read from the stream
                                                                                                                                  
                                                                                                                                  // Critical assertion - verify the deferred stream was NOT removed
                                                                                                                                  assertEquals(1, deferredStreams.size()); // Original would keep it, mutant would remove it
                                                                                                                                  
                                                                                                                                  verify(mockStream).read(eq(buffer), eq(0), eq(10));
                                                                                                                              }

    @Test
                                                                                                                          public void testReadShouldRemoveStreamFromDeferredBlockStreams() throws Exception {
                                                                                                                              // Setup
                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                              
                                                                                                                              // Create mock input streams
                                                                                                                              InputStream mockStream1 = mock(InputStream.class);
                                                                                                                              InputStream mockStream2 = mock(InputStream.class);
                                                                                                                              when(mockStream1.read()).thenReturn(1);
                                                                                                                              when(mockStream2.read()).thenReturn(2);
                                                                                                                              
                                                                                                                              // Use reflection to access private deferredBlockStreams
                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                              ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                              deferredStreams.add(mockStream1);
                                                                                                                              deferredStreams.add(mockStream2);
                                                                                                                              deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                              
                                                                                                                              // First read should use and remove first stream
                                                                                                                              int firstRead = sevenZFile.read();
                                                                                                                              assertEquals(1, firstRead);
                                                                                                                              assertEquals(1, deferredStreams.size()); // Should decrease if original, stay same if mutant
                                                                                                                              
                                                                                                                              // Second read should use second stream (original) or first stream again (mutant)
                                                                                                                              int secondRead = sevenZFile.read();
                                                                                                                              assertEquals(2, secondRead); // Would fail with mutant which would return 1 again
                                                                                                                              assertEquals(0, deferredStreams.size()); // Should be empty now for original
                                                                                                                          }

    @Test
                                                                                                                         public void testReadShouldRemoveConsumedStreamFromDeferredBlockStreams() throws Exception {
                                                                                                                             // Setup test data
                                                                                                                             byte[] buffer = new byte[1024];
                                                                                                                             InputStream mockStream1 = mock(InputStream.class);
                                                                                                                             InputStream mockStream2 = mock(InputStream.class);
                                                                                                                             when(mockStream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(100);
                                                                                                                             when(mockStream2.read(any(byte[].class), anyInt(), anyInt())).thenReturn(100);
                                                                                                                             
                                                                                                                             // Create SevenZFile instance with mocked components
                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                             
                                                                                                                             // Use reflection to access private field deferredBlockStreams
                                                                                                                             Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                             deferredStreamsField.setAccessible(true);
                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                             ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                                                                                             
                                                                                                                             // Add our test streams
                                                                                                                             deferredStreams.add(mockStream1);
                                                                                                                             deferredStreams.add(mockStream2);
                                                                                                                             
                                                                                                                             // First read operation
                                                                                                                             sevenZFile.read(buffer);
                                                                                                                             
                                                                                                                             // Verify stream was removed (original behavior) or remains (mutant)
                                                                                                                             assertEquals("After first read, only one stream should remain", 1, deferredStreams.size());
                                                                                                                             assertSame("Remaining stream should be the second one", mockStream2, deferredStreams.get(0));
                                                                                                                             
                                                                                                                             // Second read operation
                                                                                                                             sevenZFile.read(buffer);
                                                                                                                             
                                                                                                                             // Verify all streams were consumed
                                                                                                                             assertTrue("After all reads, deferredBlockStreams should be empty", deferredStreams.isEmpty());
                                                                                                                             
                                                                                                                             // Verify streams were actually read from
                                                                                                                             verify(mockStream1).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                             verify(mockStream2).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                         }

    @Test
                                                                                                                         public void testReadRemovesStreamFromDeferredBlockStreams1() throws Exception {
                                                                                                                             // Setup - create mock input streams
                                                                                                                             InputStream mockStream1 = mock(InputStream.class);
                                                                                                                             InputStream mockStream2 = mock(InputStream.class);
                                                                                                                             when(mockStream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                                                                                             
                                                                                                                             // Create test SevenZFile with mocked streams
                                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                             ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                             streams.add(mockStream1);
                                                                                                                             streams.add(mockStream2);
                                                                                                                             
                                                                                                                             // Use reflection to inject our test streams since deferredBlockStreams is private
                                                                                                                             Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                             deferredStreamsField.setAccessible(true);
                                                                                                                             deferredStreamsField.set(sevenZFile, streams);
                                                                                                                             
                                                                                                                             // Test - perform read operation
                                                                                                                             byte[] buffer = new byte[100];
                                                                                                                             int read = sevenZFile.read(buffer, 0, 100);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(10, read); // Verify read operation worked
                                                                                                                             assertEquals(1, streams.size()); // Original would remove the stream
                                                                                                                             assertSame(mockStream2, streams.get(0)); // Original would leave the second stream
                                                                                                                             
                                                                                                                             // Additional verification that we actually called the first stream
                                                                                                                             verify(mockStream1).read(any(byte[].class), eq(0), eq(100));
                                                                                                                         }

    @Test
                                                                                                                     public void testReadProcessesStreamsInCorrectOrder() throws Exception {
                                                                                                                         // Setup - create mock streams that will return different values
                                                                                                                         InputStream firstStream = mock(InputStream.class);
                                                                                                                         InputStream secondStream = mock(InputStream.class);
                                                                                                                         
                                                                                                                         // Setup return values to distinguish which stream is being read
                                                                                                                         when(firstStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(1);
                                                                                                                         when(secondStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(2);
                                                                                                                         
                                                                                                                         // Create test instance and inject our streams
                                                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                         
                                                                                                                         // Use reflection to access private field deferredBlockStreams
                                                                                                                         Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                         deferredStreamsField.setAccessible(true);
                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                         ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                                                                                         
                                                                                                                         // Add our test streams in specific order
                                                                                                                         deferredStreams.add(firstStream);
                                                                                                                         deferredStreams.add(secondStream);
                                                                                                                         
                                                                                                                         // Test - read should process first stream first (FIFO)
                                                                                                                         byte[] buffer = new byte[10];
                                                                                                                         int result = sevenZFile.read(buffer, 0, 10);
                                                                                                                         
                                                                                                                         // Verify - original should read from first stream (return 1)
                                                                                                                         // Mutant would read from last stream (return 2)
                                                                                                                         assertEquals("Should read from first stream first (FIFO order)", 1, result);
                                                                                                                         
                                                                                                                         // Verify the correct stream was removed
                                                                                                                         assertEquals("Should have one stream left", 1, deferredStreams.size());
                                                                                                                         assertSame("Should have second stream remaining", secondStream, deferredStreams.get(0));
                                                                                                                         
                                                                                                                         // Clean up
                                                                                                                         deferredStreamsField.setAccessible(false);
                                                                                                                     }

    @Test
                                                                                                                    public void testGetCurrentStreamReturnsStreamsInCorrectOrder() throws Exception {
                                                                                                                        // Setup
                                                                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                        
                                                                                                                        // Create mock input streams with different behaviors to distinguish them
                                                                                                                        InputStream firstStream = mock(InputStream.class);
                                                                                                                        when(firstStream.read()).thenReturn(1);
                                                                                                                        InputStream secondStream = mock(InputStream.class);
                                                                                                                        when(secondStream.read()).thenReturn(2);
                                                                                                                        
                                                                                                                        // Use reflection to access private field deferredBlockStreams
                                                                                                                        Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                        deferredStreamsField.setAccessible(true);
                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                        ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                                                                                        
                                                                                                                        // Add streams in specific order
                                                                                                                        deferredStreams.add(firstStream);
                                                                                                                        deferredStreams.add(secondStream);
                                                                                                                        
                                                                                                                        // Get private getCurrentStream method via reflection
                                                                                                                        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                        getCurrentStreamMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Test - first call should return first stream (returns 1)
                                                                                                                        InputStream result1 = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                        assertEquals(1, result1.read());
                                                                                                                        
                                                                                                                        // Test - second call should return second stream (returns 2)
                                                                                                                        InputStream result2 = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                        assertEquals(2, result2.read());
                                                                                                                        
                                                                                                                        // Verify streams were removed (list should be empty)
                                                                                                                        assertTrue(deferredStreams.isEmpty());
                                                                                                                        
                                                                                                                        // Clean up
                                                                                                                        deferredStreamsField.setAccessible(false);
                                                                                                                        getCurrentStreamMethod.setAccessible(false);
                                                                                                                    }

    @Test
                                                                                                                public void testReadByteArrayShouldProcessStreamsInFIFOOrder() throws Exception {
                                                                                                                    // Setup - create mock input streams with different content
                                                                                                                    InputStream stream1 = mock(InputStream.class);
                                                                                                                    InputStream stream2 = mock(InputStream.class);
                                                                                                                    
                                                                                                                    // Setup expected behaviors
                                                                                                                    byte[] expectedData1 = "FirstStream".getBytes();
                                                                                                                    byte[] expectedData2 = "SecondStream".getBytes();
                                                                                                                    
                                                                                                                    when(stream1.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                        .thenAnswer(inv -> {
                                                                                                                            byte[] b = (byte[]) inv.getArguments()[0];
                                                                                                                            System.arraycopy(expectedData1, 0, b, 0, Math.min(expectedData1.length, b.length));
                                                                                                                            return expectedData1.length;
                                                                                                                        });
                                                                                                                    
                                                                                                                    when(stream2.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                        .thenAnswer(inv -> {
                                                                                                                            byte[] b = (byte[]) inv.getArguments()[0];
                                                                                                                            System.arraycopy(expectedData2, 0, b, 0, Math.min(expectedData2.length, b.length));
                                                                                                                            return expectedData2.length;
                                                                                                                        });
                                                                                                                    
                                                                                                                    // Create test instance and populate deferredBlockStreams
                                                                                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                    ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                    streams.add(stream1);
                                                                                                                    streams.add(stream2);
                                                                                                                    
                                                                                                                    // Use reflection to set private field for testing
                                                                                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                    deferredBlockStreamsField.setAccessible(true);
                                                                                                                    deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                    
                                                                                                                    // Test - read from first stream
                                                                                                                    byte[] buffer = new byte[100];
                                                                                                                    int read = sevenZFile.read(buffer);
                                                                                                                    assertEquals(expectedData1.length, read);
                                                                                                                    assertArrayEquals(expectedData1, Arrays.copyOf(buffer, read));
                                                                                                                    
                                                                                                                    // Test - read from second stream
                                                                                                                    read = sevenZFile.read(buffer);
                                                                                                                    assertEquals(expectedData2.length, read);
                                                                                                                    assertArrayEquals(expectedData2, Arrays.copyOf(buffer, read));
                                                                                                                    
                                                                                                                    // Verify mock interactions
                                                                                                                    verify(stream1).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                    verify(stream2).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                }

    @Test
                                                                                                            public void testReadClosesStream() throws Exception {
                                                                                                                // Setup
                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                InputStream mockStream = mock(InputStream.class);
                                                                                                                
                                                                                                                // Mock the behavior
                                                                                                                when(mockStream.read()).thenReturn(65); // 'A'
                                                                                                                
                                                                                                                // Use reflection to inject our mock stream since currentFolderInputStream is private
                                                                                                                Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(sevenZFile, mockStream);
                                                                                                                
                                                                                                                // Test
                                                                                                                int result = sevenZFile.read();
                                                                                                                
                                                                                                                // Verify
                                                                                                                assertEquals("Should return correct byte", 65, result);
                                                                                                                verify(mockStream, times(1)).close(); // This will fail if the mutant survives
                                                                                                            }

    @Test
                                                                                                            public void testReadClosesStream1() throws Exception {
                                                                                                                // Setup
                                                                                                                byte[] buffer = new byte[10];
                                                                                                                InputStream mockStream = mock(InputStream.class);
                                                                                                                when(mockStream.read(buffer, 0, buffer.length)).thenReturn(buffer.length);
                                                                                                                
                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                // Use reflection to set private field since there's no setter
                                                                                                                Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(sevenZFile, mockStream);
                                                                                                                
                                                                                                                // Test
                                                                                                                sevenZFile.read(buffer);
                                                                                                                
                                                                                                                // Verify
                                                                                                                verify(mockStream).close();  // This will fail if the stream wasn't closed
                                                                                                            }

    @Test
                                                                                                            public void testReadShouldCloseStreamAfterReading1() throws Exception {
                                                                                                                // Setup
                                                                                                                byte[] buffer = new byte[10];
                                                                                                                InputStream mockStream = mock(InputStream.class);
                                                                                                                when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                
                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                try {
                                                                                                                    // Use reflection to inject our mock stream since getCurrentStream() is private
                                                                                                                    Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                                    streamField.setAccessible(true);
                                                                                                                    streamField.set(sevenZFile, mockStream);
                                                                                                                    
                                                                                                                    // Act
                                                                                                                    sevenZFile.read(buffer, 0, 10);
                                                                                                                    
                                                                                                                    // Verify the stream was closed
                                                                                                                    verify(mockStream).close();
                                                                                                                } finally {
                                                                                                                    sevenZFile.close();
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                           public void testRead_ShouldReturnFromFirstDeferredBlockStream() throws Exception {
                                                                                                               // Setup
                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                               InputStream mockStream = mock(InputStream.class);
                                                                                                               when(mockStream.read()).thenReturn(42); // sample return value
                                                                                                               
                                                                                                               // Use reflection to access private field deferredBlockStreams
                                                                                                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                               deferredBlockStreamsField.setAccessible(true);
                                                                                                               ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                                                               deferredBlockStreams.add(mockStream);
                                                                                                               deferredBlockStreamsField.set(sevenZFile, deferredBlockStreams);
                                                                                                               
                                                                                                               // Test
                                                                                                               int result = sevenZFile.read();
                                                                                                               
                                                                                                               // Verify
                                                                                                               assertEquals("Should return value from first deferred block stream", 42, result);
                                                                                                               verify(mockStream).read(); // Verify interaction with the correct stream
                                                                                                               
                                                                                                               // Clean up
                                                                                                               deferredBlockStreamsField.setAccessible(false);
                                                                                                           }

    @Test
                                                                                                           public void testReadByteArrayShouldNotReturnNull() throws Exception {
                                                                                                               // Setup
                                                                                                               byte[] testBuffer = new byte[10];
                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                               
                                                                                                               // Mock the internal stream to return some data
                                                                                                               InputStream mockStream = mock(InputStream.class);
                                                                                                               when(mockStream.read(testBuffer, 0, testBuffer.length)).thenReturn(5);
                                                                                                               
                                                                                                               // Inject the mock stream into deferredBlockStreams using reflection
                                                                                                               Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                               deferredStreamsField.setAccessible(true);
                                                                                                               ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                               streams.add(mockStream);
                                                                                                               deferredStreamsField.set(sevenZFile, streams);
                                                                                                               
                                                                                                               // Test
                                                                                                               int bytesRead = sevenZFile.read(testBuffer);
                                                                                                               
                                                                                                               // Verify
                                                                                                               assertNotNull("Method should not return null", bytesRead);
                                                                                                               assertEquals("Should return correct number of bytes read", 5, bytesRead);
                                                                                                               
                                                                                                               // Clean up
                                                                                                               sevenZFile.close();
                                                                                                           }

    @Test
                                                                                                           public void testReadWithDeferredBlockStreams1() throws Exception {
                                                                                                               // Setup
                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                               
                                                                                                               // Create a mock input stream to be returned as the first deferred block stream
                                                                                                               InputStream mockStream = mock(InputStream.class);
                                                                                                               when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                               
                                                                                                               // Use reflection to inject our mock stream into the deferredBlockStreams
                                                                                                               Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                               deferredStreamsField.setAccessible(true);
                                                                                                               ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                               deferredStreams.add(mockStream);
                                                                                                               deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                               
                                                                                                               // Test
                                                                                                               byte[] buffer = new byte[10];
                                                                                                               int bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                                                               
                                                                                                               // Verify
                                                                                                               assertEquals(5, bytesRead);
                                                                                                               verify(mockStream).read(buffer, 0, 10);
                                                                                                               
                                                                                                               // Clean up
                                                                                                               sevenZFile.close();
                                                                                                           }

    @Test
                                                                                                          public void testReadShouldUseFirstStreamFromDeferredBlockStreams1() throws Exception {
                                                                                                              // Create mock input streams with different behaviors
                                                                                                              InputStream firstStream = mock(InputStream.class);
                                                                                                              InputStream lastStream = mock(InputStream.class);
                                                                                                              
                                                                                                              // Setup different return values to distinguish which stream was called
                                                                                                              when(firstStream.read()).thenReturn(1);
                                                                                                              when(lastStream.read()).thenReturn(2);
                                                                                                              
                                                                                                              // Create the SevenZFile instance and inject our mock streams
                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                              
                                                                                                              // Use reflection to access private field deferredBlockStreams since it's private
                                                                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                              deferredBlockStreamsField.setAccessible(true);
                                                                                                              
                                                                                                              // Create a list with our mock streams
                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                              streams.add(firstStream);
                                                                                                              streams.add(mock(InputStream.class)); // middle stream (not important)
                                                                                                              streams.add(lastStream);
                                                                                                              
                                                                                                              // Set the field value
                                                                                                              deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                              
                                                                                                              // Call the read method
                                                                                                              int result = sevenZFile.read();
                                                                                                              
                                                                                                              // Verify it read from the first stream (original behavior)
                                                                                                              assertEquals(1, result);
                                                                                                              
                                                                                                              // Verify the first stream was called exactly once
                                                                                                              verify(firstStream, times(1)).read();
                                                                                                              
                                                                                                              // Verify no interactions with the last stream
                                                                                                              verify(lastStream, never()).read();
                                                                                                          }

    @Test
                                                                                                          public void testReadByteArrayShouldUseFirstStreamWhenMultipleStreamsExist() throws Exception {
                                                                                                              // Setup
                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                              
                                                                                                              // Create mock streams with different behaviors
                                                                                                              InputStream firstStream = mock(InputStream.class);
                                                                                                              InputStream lastStream = mock(InputStream.class);
                                                                                                              
                                                                                                              // Prepare test data
                                                                                                              byte[] expectedData = new byte[]{1, 2, 3};
                                                                                                              byte[] unexpectedData = new byte[]{4, 5, 6};
                                                                                                              byte[] buffer = new byte[3];
                                                                                                              
                                                                                                              // Set up mock behaviors
                                                                                                              when(firstStream.read(buffer, 0, buffer.length)).thenAnswer(inv -> {
                                                                                                                  System.arraycopy(expectedData, 0, buffer, 0, expectedData.length);
                                                                                                                  return expectedData.length;
                                                                                                              });
                                                                                                              when(lastStream.read(buffer, 0, buffer.length)).thenAnswer(inv -> {
                                                                                                                  System.arraycopy(unexpectedData, 0, buffer, 0, unexpectedData.length);
                                                                                                                  return unexpectedData.length;
                                                                                                              });
                                                                                                              
                                                                                                              // Inject mock streams into the object (using reflection since deferredBlockStreams is private)
                                                                                                              Field streamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                              streamsField.setAccessible(true);
                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                              streams.add(firstStream);
                                                                                                              streams.add(lastStream);
                                                                                                              streamsField.set(sevenZFile, streams);
                                                                                                              
                                                                                                              // Test
                                                                                                              int bytesRead = sevenZFile.read(buffer);
                                                                                                              
                                                                                                              // Verify
                                                                                                              assertEquals(expectedData.length, bytesRead);
                                                                                                              assertArrayEquals(expectedData, buffer);
                                                                                                              
                                                                                                              // Additional verification that we read from first stream, not last
                                                                                                              verify(firstStream).read(buffer, 0, buffer.length);
                                                                                                              verify(lastStream, never()).read(buffer, 0, buffer.length);
                                                                                                          }

    @Test
                                                                                                          public void testGetCurrentStreamReturnsFirstStream1() throws Exception {
                                                                                                              // Setup
                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                              
                                                                                                              // Create mock streams
                                                                                                              InputStream firstStream = mock(InputStream.class);
                                                                                                              InputStream lastStream = mock(InputStream.class);
                                                                                                              
                                                                                                              // Use reflection to set the private deferredBlockStreams field
                                                                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                              deferredBlockStreamsField.setAccessible(true);
                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                              streams.add(firstStream);
                                                                                                              streams.add(mock(InputStream.class)); // middle stream
                                                                                                              streams.add(lastStream);
                                                                                                              deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                              
                                                                                                              // Test
                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                              
                                                                                                              // Verify
                                                                                                              assertSame("Should return first stream from deferredBlockStreams", 
                                                                                                                        firstStream, result);
                                                                                                              
                                                                                                              // Clean up
                                                                                                              sevenZFile.close();
                                                                                                          }

    @Test
                                                                                                         public void testReadDetectsMutant2() throws Exception {
                                                                                                             // Setup
                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                             
                                                                                                             // Mock the current stream to return 5 bytes when read() is called
                                                                                                             InputStream mockStream = mock(InputStream.class);
                                                                                                             when(mockStream.read()).thenReturn(1, 2, 3, 4, 5);
                                                                                                             
                                                                                                             // Inject the mock stream using reflection since currentFolderInputStream is private
                                                                                                             Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                             field.setAccessible(true);
                                                                                                             field.set(sevenZFile, mockStream);
                                                                                                             
                                                                                                             // Test the read() method
                                                                                                             int result = sevenZFile.read();
                                                                                                             
                                                                                                             // Verify - original should return the byte value (1), mutant would return 0
                                                                                                             assertNotEquals("Mutant detected - read() should not return 0 when data is available", 
                                                                                                                            0, result);
                                                                                                             
                                                                                                             // Additional verification that we got the expected value from stream
                                                                                                             assertEquals(1, result);
                                                                                                             
                                                                                                             // Clean up
                                                                                                             sevenZFile.close();
                                                                                                         }

    @Test
                                                                                                         public void testReadByteArrayWithOffsetAndLength_ShouldReturnActualBytesRead() throws Exception {
                                                                                                             // Arrange
                                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                             
                                                                                                             // Create a mock InputStream that will return 5 bytes when read is called
                                                                                                             InputStream mockStream = mock(InputStream.class);
                                                                                                             when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                             
                                                                                                             // Use reflection to inject the mock stream since currentFolderInputStream is private
                                                                                                             Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                             field.setAccessible(true);
                                                                                                             field.set(sevenZFile, mockStream);
                                                                                                             
                                                                                                             byte[] buffer = new byte[10];
                                                                                                             
                                                                                                             // Act
                                                                                                             int bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                                                             
                                                                                                             // Assert
                                                                                                             // Original implementation should return 5 (from mock), mutant will return 0
                                                                                                             assertEquals("Should return actual number of bytes read", 5, bytesRead);
                                                                                                             
                                                                                                             // Verify the mock was called
                                                                                                             verify(mockStream).read(any(byte[].class), eq(0), eq(10));
                                                                                                         }

    @Test
                                                                                                        public void testReadShouldReturnByteFromStream() throws Exception {
                                                                                                            // Setup
                                                                                                            SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                            
                                                                                                            // Use reflection to access private getCurrentStream field/method
                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                            currentStreamField.setAccessible(true);
                                                                                                            currentStreamField.set(sevenZFile, mockStream);
                                                                                                            
                                                                                                            // Configure mock behavior
                                                                                                            when(mockStream.read()).thenReturn(65); // 'A' character
                                                                                                            
                                                                                                            // Call real method for read()
                                                                                                            when(sevenZFile.read()).thenCallRealMethod();
                                                                                                            
                                                                                                            // Test
                                                                                                            int result = sevenZFile.read();
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertEquals("Should return the byte read from stream", 65, result);
                                                                                                        }

    @Test
                                                                                                        public void testReadShouldReturnMinusOneAtEndOfStream() throws Exception {
                                                                                                            // Setup
                                                                                                            File mockFile = mock(File.class);
                                                                                                            SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                            InputStream mockStream = mock(InputStream.class);
                                                                                                            
                                                                                                            // Use reflection to set private currentStream field
                                                                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                            currentStreamField.setAccessible(true);
                                                                                                            currentStreamField.set(sevenZFile, mockStream);
                                                                                                            
                                                                                                            // Configure mock behavior
                                                                                                            when(mockStream.read()).thenReturn(-1); // End of stream
                                                                                                            
                                                                                                            // Test
                                                                                                            int result = sevenZFile.read();
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertEquals("Should return -1 at end of stream", -1, result);
                                                                                                        }

    @Test
                                                                                                    public void testReadShouldReturnByteFromStreamNotNegativeOne1() throws Exception {
                                                                                                        // Arrange
                                                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                        
                                                                                                        // Mock the current stream to return a specific byte (e.g., 42)
                                                                                                        InputStream mockStream = mock(InputStream.class);
                                                                                                        when(mockStream.read()).thenReturn(42);
                                                                                                        
                                                                                                        // Use reflection to inject the mock stream since currentFolderInputStream is private
                                                                                                        Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                        streamField.setAccessible(true);
                                                                                                        streamField.set(sevenZFile, mockStream);
                                                                                                        
                                                                                                        // Act
                                                                                                        int result = sevenZFile.read();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertEquals("Should return the byte read from stream", 42, result);
                                                                                                        
                                                                                                        // Verify the stream was actually called
                                                                                                        verify(mockStream).read();
                                                                                                    }

    @Test
                                                                                                    public void testRead_ShouldReturnByteFromStream_NotAlwaysMinusOne() throws Exception {
                                                                                                        // Arrange
                                                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                        
                                                                                                        // Mock the current stream to return a test byte
                                                                                                        InputStream mockStream = mock(InputStream.class);
                                                                                                        when(mockStream.read()).thenReturn(42); // Return test byte 42
                                                                                                        
                                                                                                        // Use reflection to inject the mock stream since currentFolderInputStream is private
                                                                                                        Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                        field.setAccessible(true);
                                                                                                        field.set(sevenZFile, mockStream);
                                                                                                        
                                                                                                        // Act
                                                                                                        int result = sevenZFile.read();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertEquals("Should return the byte read from stream", 42, result);
                                                                                                        
                                                                                                        // Verify the stream was actually called
                                                                                                        verify(mockStream).read();
                                                                                                    }

    @Test
                                                                                                   public void testReadWithAvailableDataShouldNotReturnNegativeOne() throws Exception {
                                                                                                       // Setup
                                                                                                       byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                       InputStream mockStream = mock(InputStream.class);
                                                                                                       when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(testData.length);
                                                                                                       
                                                                                                       SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                       
                                                                                                       // Use reflection to set up getCurrentStream() behavior
                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                       when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(mockStream);
                                                                                                       
                                                                                                       // Use reflection to set up read method behavior
                                                                                                       Method readMethod = SevenZFile.class.getDeclaredMethod("read", byte[].class, int.class, int.class);
                                                                                                       readMethod.setAccessible(true);
                                                                                                       when(sevenZFile.read(any(byte[].class), anyInt(), anyInt())).thenCallRealMethod();
                                                                                                       
                                                                                                       // Test
                                                                                                       byte[] buffer = new byte[10];
                                                                                                       int bytesRead = (int) readMethod.invoke(sevenZFile, buffer, 0, buffer.length);
                                                                                                       
                                                                                                       // Verify
                                                                                                       assertNotEquals("Should not return -1 when data is available", -1, bytesRead);
                                                                                                       assertEquals("Should return correct number of bytes read", testData.length, bytesRead);
                                                                                                   }

    @Test
                                                                                                   public void testReadWithAvailableDataShouldNotReturnNegativeOne1() throws Exception {
                                                                                                       // Setup mock stream that returns actual data
                                                                                                       InputStream mockStream = mock(InputStream.class);
                                                                                                       when(mockStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                           .thenReturn(5); // simulate reading 5 bytes
                                                                                                       
                                                                                                       // Create a real SevenZFile object (using a dummy file)
                                                                                                       File tempFile = File.createTempFile("test", ".7z");
                                                                                                       try {
                                                                                                           SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                           
                                                                                                           // Use reflection to set the private currentStream field
                                                                                                           Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                                                           currentStreamField.setAccessible(true);
                                                                                                           currentStreamField.set(sevenZFile, mockStream);
                                                                                                           
                                                                                                           // Test
                                                                                                           byte[] buffer = new byte[10];
                                                                                                           int bytesRead = sevenZFile.read(buffer, 0, buffer.length);
                                                                                                           
                                                                                                           // Verify
                                                                                                           assertNotEquals("Method should not return -1 when data is available", 
                                                                                                                          -1, bytesRead);
                                                                                                           assertEquals("Should return correct number of bytes read", 
                                                                                                                       5, bytesRead);
                                                                                                       } finally {
                                                                                                           tempFile.delete();
                                                                                                       }
                                                                                                   }

    @Test
                                                                                              public void testReadWithEmptyFileEntry2() throws Exception {
                                                                                                  // Setup test objects
                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                  
                                                                                                  // Use reflection to access private fields since we need to set up the test scenario
                                                                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                  archiveField.setAccessible(true);
                                                                                                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                                  
                                                                                                  // Create mock archive with one empty file entry using reflection
                                                                                                  Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                  Object mockArchive = mock(archiveClass);
                                                                                                  SevenZArchiveEntry[] files = new SevenZArchiveEntry[1];
                                                                                                  files[0] = mock(SevenZArchiveEntry.class);
                                                                                                  when(files[0].getSize()).thenReturn(0L); // Empty file
                                                                                                  Field filesField = archiveClass.getDeclaredField("files");
                                                                                                  filesField.setAccessible(true);
                                                                                                  filesField.set(mockArchive, files);
                                                                                                  
                                                                                                  // Set the mock archive and index to point to our empty file
                                                                                                  archiveField.set(sevenZFile, mockArchive);
                                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                                  
                                                                                                  // Mock the current stream to return -1 (EOF)
                                                                                                  InputStream mockStream = mock(InputStream.class);
                                                                                                  when(mockStream.read()).thenReturn(-1);
                                                                                                  
                                                                                                  // Use reflection to mock getCurrentStream
                                                                                                  SevenZFile spySevenZFile = spy(sevenZFile);
                                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                                  when(getCurrentStreamMethod.invoke(spySevenZFile)).thenReturn(mockStream);
                                                                                                  
                                                                                                  // Test the behavior
                                                                                                  int result = spySevenZFile.read();
                                                                                                  
                                                                                                  // Verify the behavior - original would handle empty file properly,
                                                                                                  // mutant would try to read from empty file
                                                                                                  assertEquals("Should return -1 for empty file entry", -1, result);
                                                                                                  
                                                                                                  // Verify the stream was not attempted to be read for empty file (original behavior)
                                                                                                  verify(mockStream, never()).read();
                                                                                              }

    @Test
                                                                                              public void testReadWithEmptyFileEntry3() throws Exception {
                                                                                                  // Setup mock objects
                                                                                                  SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                  SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                  
                                                                                                  // Configure mocks
                                                                                                  when(entry.getSize()).thenReturn(0L);
                                                                                                  
                                                                                                  // Set up test object state using reflection since fields are private
                                                                                                  // Create a real Archive object (can't mock it directly)
                                                                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                  archiveField.setAccessible(true);
                                                                                                  
                                                                                                  // Create a minimal Archive object with reflection
                                                                                                  Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                  Constructor<?> archiveConstructor = archiveClass.getDeclaredConstructor();
                                                                                                  archiveConstructor.setAccessible(true);
                                                                                                  Object archive = archiveConstructor.newInstance();
                                                                                                  
                                                                                                  // Set the files field in the Archive object
                                                                                                  Field filesField = archiveClass.getDeclaredField("files");
                                                                                                  filesField.setAccessible(true);
                                                                                                  filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                                                                                  
                                                                                                  // Set the archive field in SevenZFile
                                                                                                  archiveField.set(sevenZFile, archive);
                                                                                                  
                                                                                                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                                  
                                                                                                  // Mock the actual read method we're testing
                                                                                                  when(sevenZFile.read(any(byte[].class), anyInt(), anyInt())).thenCallRealMethod();
                                                                                                  
                                                                                                  // Create test buffer
                                                                                                  byte[] buffer = new byte[1024];
                                                                                                  
                                                                                                  // Test the read
                                                                                                  int result = sevenZFile.read(buffer);
                                                                                                  
                                                                                                  // Verify behavior - original should return -1 for empty file
                                                                                                  assertEquals("Should return -1 for empty file", -1, result);
                                                                                                  
                                                                                                  // Instead of verifying private method, verify no bytes were read by checking buffer wasn't modified
                                                                                                  byte[] expected = new byte[1024];
                                                                                                  assertArrayEquals(expected, buffer);
                                                                                              }

    @Test
                                                                                              public void testReadWithZeroSizeFileShouldHandleSpecially() throws Exception {
                                                                                                  // Setup test data
                                                                                                  byte[] buffer = new byte[10];
                                                                                                  int offset = 0;
                                                                                                  int length = 10;
                                                                                                  
                                                                                                  // Mock the entry and stream
                                                                                                  SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                  InputStream mockStream = mock(InputStream.class);
                                                                                                  
                                                                                                  // Configure mocks
                                                                                                  when(mockEntry.getSize()).thenReturn(0L); // Zero-sized file
                                                                                                  when(mockStream.read(buffer, offset, length)).thenReturn(-1);
                                                                                                  
                                                                                                  // Create instance
                                                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                  
                                                                                                  // Use reflection to set private fields
                                                                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                  archiveField.setAccessible(true);
                                                                                                  Object archive = new Object(); // We don't need the actual Archive class
                                                                                                  archiveField.set(sevenZFile, archive);
                                                                                                  
                                                                                                  Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                  filesField.setAccessible(true);
                                                                                                  filesField.set(archive, new SevenZArchiveEntry[]{mockEntry});
                                                                                                  
                                                                                                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                                  
                                                                                                  Field currentFolderInputStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                                  currentFolderInputStreamField.setAccessible(true);
                                                                                                  currentFolderInputStreamField.set(sevenZFile, mockStream);
                                                                                                  
                                                                                                  // Test the read operation
                                                                                                  int result = sevenZFile.read(buffer, offset, length);
                                                                                                  
                                                                                                  // Verify behavior
                                                                                                  assertEquals("Should return -1 for zero-sized file", -1, result);
                                                                                                  
                                                                                                  // Verify stream interaction - shouldn't try to read
                                                                                                  verify(mockStream, never()).read(buffer, offset, length);
                                                                                              }

    @Test
                                                                                         public void testReadWithNonEmptyFileShouldCallRead() throws Exception {
                                                                                             // Setup test objects
                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                             
                                                                                             // Use reflection to access private fields since we need to set up the test scenario
                                                                                             Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                             archiveField.setAccessible(true);
                                                                                             Object archive = mock(Object.class); // Use Object instead of Archive
                                                                                             archiveField.set(sevenZFile, archive);
                                                                                             
                                                                                             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                             currentEntryIndexField.setAccessible(true);
                                                                                             currentEntryIndexField.set(sevenZFile, 0);
                                                                                             
                                                                                             // Mock the files array and entry using reflection
                                                                                             Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                             Object[] files = (Object[]) Array.newInstance(fileClass, 1);
                                                                                             files[0] = mock(fileClass);
                                                                                             when(archive.getClass().getDeclaredField("files").get(archive)).thenReturn(files);
                                                                                             
                                                                                             // Mock file size
                                                                                             Method getSizeMethod = fileClass.getDeclaredMethod("getSize");
                                                                                             when(getSizeMethod.invoke(files[0])).thenReturn(100L); // Non-empty file
                                                                                             
                                                                                             // Mock the current stream
                                                                                             InputStream mockStream = mock(InputStream.class);
                                                                                             when(mockStream.read()).thenReturn(42); // Return some data
                                                                                             
                                                                                             Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                             currentStreamField.setAccessible(true);
                                                                                             currentStreamField.set(sevenZFile, mockStream);
                                                                                             
                                                                                             // Call the method
                                                                                             int result = sevenZFile.read();
                                                                                             
                                                                                             // Verify behavior
                                                                                             assertEquals(42, result); // Should return the data from stream
                                                                                             verify(mockStream).read(); // Should have called read() since file is not empty
                                                                                             
                                                                                             // Clean up
                                                                                             archiveField.setAccessible(false);
                                                                                             currentEntryIndexField.setAccessible(false);
                                                                                             currentStreamField.setAccessible(false);
                                                                                         }

    @Test
                                                                                         public void testReadWithNonEmptyFileShouldReturnBytesRead() throws Exception {
                                                                                             // Setup test data
                                                                                             byte[] buffer = new byte[1024];
                                                                                             
                                                                                             // Mock the SevenZFile
                                                                                             SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                             
                                                                                             // Mock the actual read operation to return some bytes
                                                                                             when(sevenZFile.read(buffer, 0, buffer.length)).thenReturn(50);
                                                                                             
                                                                                             // Call the method under test
                                                                                             int bytesRead = sevenZFile.read(buffer);
                                                                                             
                                                                                             // Verify the behavior
                                                                                             assertEquals(50, bytesRead); // Should return actual bytes read
                                                                                             
                                                                                             // Verify the read was called with correct parameters
                                                                                             verify(sevenZFile).read(buffer, 0, buffer.length);
                                                                                         }

    @Test
                                                                                         public void testReadWithNonZeroSizeEntryShouldCallStreamRead1() throws Exception {
                                                                                             // Setup test data
                                                                                             byte[] buffer = new byte[10];
                                                                                             int offset = 0;
                                                                                             int length = 10;
                                                                                             
                                                                                             // Mock dependencies
                                                                                             SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                             when(mockEntry.getSize()).thenReturn(100L); // Non-zero size
                                                                                             
                                                                                             // Create real Archive object and set its fields through reflection
                                                                                             Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                             Object archive = archiveClass.getDeclaredConstructor().newInstance();
                                                                                             
                                                                                             // Set the files field in Archive
                                                                                             Field filesField = archiveClass.getDeclaredField("files");
                                                                                             filesField.setAccessible(true);
                                                                                             filesField.set(archive, new SevenZArchiveEntry[]{mockEntry});
                                                                                             
                                                                                             InputStream mockStream = mock(InputStream.class);
                                                                                             when(mockStream.read(buffer, offset, length)).thenReturn(length);
                                                                                             
                                                                                             // Create test instance
                                                                                             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                             
                                                                                             // Use reflection to set private fields for testing
                                                                                             Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                             archiveField.setAccessible(true);
                                                                                             archiveField.set(sevenZFile, archive);
                                                                                             
                                                                                             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                             currentEntryIndexField.setAccessible(true);
                                                                                             currentEntryIndexField.set(sevenZFile, 0);
                                                                                             
                                                                                             Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                             currentStreamField.setAccessible(true);
                                                                                             currentStreamField.set(sevenZFile, mockStream);
                                                                                             
                                                                                             // Test the method
                                                                                             int result = sevenZFile.read(buffer, offset, length);
                                                                                             
                                                                                             // Verify behavior
                                                                                             assertEquals(length, result); // Should read successfully
                                                                                             verify(mockStream).read(buffer, offset, length); // Should call stream read
                                                                                             
                                                                                             // The mutant would fail this test because:
                                                                                             // 1. With if(true), it would skip the read operation
                                                                                             // 2. The verify would fail since read wasn't called
                                                                                             // 3. The return value would be different (likely -1)
                                                                                         }

    @Test(expected = NullPointerException.class)
                                                                                     public void testReadWhenCurrentStreamIsNull2() throws Exception {
                                                                                         // Setup
                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                         
                                                                                         // Use reflection to inject null as currentFolderInputStream since it's private
                                                                                         Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                         field.setAccessible(true);
                                                                                         field.set(sevenZFile, null);
                                                                                         
                                                                                         // Also set currentEntryIndex to a valid value to avoid other exceptions
                                                                                         field = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                         field.setAccessible(true);
                                                                                         field.set(sevenZFile, 0);
                                                                                         
                                                                                         // Test - should throw NPE when trying to read from null stream
                                                                                         sevenZFile.read();
                                                                                     }

    @Test
                                                                                     public void testReadWithEmptyStreamShouldReturnMinusOne1() throws Exception {
                                                                                         // Setup
                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                         
                                                                                         // Set up empty stream (original behavior)
                                                                                         Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                         field.setAccessible(true);
                                                                                         field.set(sevenZFile, new ByteArrayInputStream(new byte[0]));
                                                                                         
                                                                                         byte[] buffer = new byte[1024];
                                                                                         
                                                                                         // Act
                                                                                         int result = sevenZFile.read(buffer);
                                                                                         
                                                                                         // Assert
                                                                                         assertEquals("Should return -1 for empty stream", -1, result);
                                                                                     }

    @Test(expected = NullPointerException.class)
                                                                                    public void testReadWhenCurrentStreamIsNull3() throws Exception {
                                                                                        // Setup
                                                                                        SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                        
                                                                                        // Use reflection to mock the private getCurrentStream() method
                                                                                        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                        getCurrentStreamMethod.setAccessible(true);
                                                                                        when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(null);
                                                                                        
                                                                                        // Mock the public read() method to call real method
                                                                                        when(sevenZFile.read()).thenCallRealMethod();
                                                                                        
                                                                                        // Test - should throw NPE
                                                                                        sevenZFile.read();
                                                                                    }

    @Test
                                                                            public void testReadWithEmptyStreamShouldReturnZero() throws Exception {
                                                                                // Setup
                                                                                SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                byte[] buffer = new byte[10];
                                                                                
                                                                                // Mock the read method to return 0 (empty stream behavior)
                                                                                when(sevenZFile.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                
                                                                                // Test
                                                                                int result = sevenZFile.read(buffer, 0, 10);
                                                                                
                                                                                // Verify
                                                                                assertEquals(0, result);
                                                                            }

    @Test
                                                                            public void testReadWithNullStreamShouldThrowException() throws Exception {
                                                                                // Setup
                                                                                SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                byte[] buffer = new byte[10];
                                                                                
                                                                                // Use reflection to set up the private getCurrentStream() to return null
                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(null);
                                                                                
                                                                                // Mock read to call real method (which will use getCurrentStream)
                                                                                when(sevenZFile.read(any(byte[].class), anyInt(), anyInt()))
                                                                                    .thenCallRealMethod();
                                                                                
                                                                                // Expect exception
                                                                                thrown.expect(NullPointerException.class);
                                                                                
                                                                                // Test
                                                                                sevenZFile.read(buffer, 0, 10);
                                                                            }

    @Test
                                                                        public void testReadWithNullStreamShouldThrowException1() throws IOException {
                                                                            // Setup
                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                            byte[] buffer = new byte[1024];
                                                                            
                                                                            try {
                                                                                // Use reflection to set private field since we need to test the mutant behavior
                                                                                Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                                field.setAccessible(true);
                                                                                field.set(sevenZFile, null); // Simulate the mutant behavior
                                                                                
                                                                                // This should throw NullPointerException when trying to read from null stream
                                                                                sevenZFile.read(buffer);
                                                                                
                                                                                // If we reach here, the test fails (no exception was thrown)
                                                                                fail("Expected NullPointerException when reading from null stream");
                                                                            } catch (NoSuchFieldException e) {
                                                                                fail("Failed to access currentFolderInputStream field: " + e.getMessage());
                                                                            } catch (IllegalAccessException e) {
                                                                                fail("Failed to set currentFolderInputStream field: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                    public void testReadWhenCurrentStreamNull() throws Exception {
                                                                        // Setup
                                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                        
                                                                        // Use reflection to set currentFolderInputStream to null since it's private
                                                                        Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                        field.setAccessible(true);
                                                                        field.set(sevenZFile, null);
                                                                        
                                                                        // Test with empty buffer
                                                                        byte[] buffer = new byte[10];
                                                                        int bytesRead = sevenZFile.read(buffer);
                                                                        
                                                                        // Verify
                                                                        assertEquals("Should read 0 bytes from empty stream", 0, bytesRead);
                                                                        
                                                                        // Additional verification that no bytes were written to buffer
                                                                        byte[] expected = new byte[10]; // all zeros
                                                                        assertArrayEquals("Buffer should remain unchanged", expected, buffer);
                                                                        
                                                                        // Test with non-empty buffer
                                                                        Arrays.fill(buffer, (byte)1); // fill with 1s
                                                                        bytesRead = sevenZFile.read(buffer);
                                                                        assertEquals("Should still read 0 bytes from empty stream", 0, bytesRead);
                                                                        assertArrayEquals("Buffer should remain unchanged", expected, buffer);
                                                                    }

    @Test
                                                                   public void testReadWithEmptyStream5() throws Exception {
                                                                       // Setup
                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                       
                                                                       // Get the private getCurrentStream method via reflection
                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                       
                                                                       // Mock the getCurrentStream() to return empty stream (original behavior)
                                                                       InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                       Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                                       currentStreamField.setAccessible(true);
                                                                       currentStreamField.set(sevenZFile, emptyStream);
                                                                       
                                                                       // Test original behavior - should return -1 immediately
                                                                       int result1 = sevenZFile.read();
                                                                       int result2 = sevenZFile.read();
                                                                       
                                                                       // Verify
                                                                       assertEquals("First read on empty stream should return -1", -1, result1);
                                                                       assertEquals("Subsequent read on empty stream should return -1", -1, result2);
                                                                       
                                                                       // Now test with mutant behavior (stream with 1 byte)
                                                                       InputStream oneByteStream = new ByteArrayInputStream(new byte[1]);
                                                                       currentStreamField.set(sevenZFile, oneByteStream);
                                                                       
                                                                       // Test mutant behavior - should return 0 then -1
                                                                       int mutantResult1 = sevenZFile.read();
                                                                       int mutantResult2 = sevenZFile.read();
                                                                       
                                                                       // Verify mutant would be caught here
                                                                       assertEquals("First read on one-byte stream should return 0", 0, mutantResult1);
                                                                       assertEquals("Second read on one-byte stream should return -1", -1, mutantResult2);
                                                                       
                                                                       // Clean up
                                                                       emptyStream.close();
                                                                       oneByteStream.close();
                                                                   }

    @Test
                                                                   public void testReadWithEmptyStream6() throws Exception {
                                                                       // Setup
                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                       
                                                                       // Use reflection to access the private currentInputStream field
                                                                       Field currentInputStreamField = SevenZFile.class.getDeclaredField("currentInputStream");
                                                                       currentInputStreamField.setAccessible(true);
                                                                       
                                                                       // Test with empty stream
                                                                       InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
                                                                       currentInputStreamField.set(sevenZFile, emptyStream);
                                                                       
                                                                       // Test reading from empty stream
                                                                       byte[] buffer = new byte[10];
                                                                       int bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                       
                                                                       // Verify
                                                                       assertEquals("Should return -1 for empty stream", -1, bytesRead);
                                                                       
                                                                       // Now test with 1-byte stream
                                                                       InputStream oneByteStream = new ByteArrayInputStream(new byte[1]);
                                                                       currentInputStreamField.set(sevenZFile, oneByteStream);
                                                                       
                                                                       bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                       
                                                                       // This assertion will fail if mutant is present
                                                                       assertEquals("Should return 1 for stream with 1 byte", 1, bytesRead);
                                                                       
                                                                       // Verify the mutant by checking subsequent read
                                                                       bytesRead = sevenZFile.read(buffer, 0, 10);
                                                                       assertEquals("Subsequent read should return -1", -1, bytesRead);
                                                                   }

    @Test
                                                               public void testReadWithEmptyDeferredStreams2() throws Exception {
                                                                   // Setup
                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                   
                                                                   // Mock the current folder input stream to return specific value
                                                                   InputStream mockCurrentStream = mock(InputStream.class);
                                                                   when(mockCurrentStream.read()).thenReturn(42);
                                                                   
                                                                   // Use reflection to set private fields since we need to test internal behavior
                                                                   Field currentFolderStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                   currentFolderStreamField.setAccessible(true);
                                                                   currentFolderStreamField.set(sevenZFile, mockCurrentStream);
                                                                   
                                                                   Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                   deferredStreamsField.setAccessible(true);
                                                                   deferredStreamsField.set(sevenZFile, new ArrayList<InputStream>()); // empty list
                                                                   
                                                                   // Test
                                                                   int result = sevenZFile.read();
                                                                   
                                                                   // Verify
                                                                   assertEquals(42, result);
                                                                   verify(mockCurrentStream).read(); // Verify correct stream was used
                                                               }

    @Test
                                                               public void testReadWithNonEmptyDeferredStreams3() throws Exception {
                                                                   // Setup
                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                   
                                                                   // Mock streams
                                                                   InputStream mockDeferredStream = mock(InputStream.class);
                                                                   when(mockDeferredStream.read()).thenReturn(99);
                                                                   
                                                                   InputStream mockCurrentStream = mock(InputStream.class);
                                                                   
                                                                   // Use reflection to set private fields
                                                                   Field currentFolderStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                   currentFolderStreamField.setAccessible(true);
                                                                   currentFolderStreamField.set(sevenZFile, mockCurrentStream);
                                                                   
                                                                   Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                   deferredStreamsField.setAccessible(true);
                                                                   ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                   deferredStreams.add(mockDeferredStream);
                                                                   deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                   
                                                                   // Test
                                                                   int result = sevenZFile.read();
                                                                   
                                                                   // Verify
                                                                   assertEquals(99, result);
                                                                   verify(mockDeferredStream).read(); // Verify deferred stream was used
                                                                   verify(mockCurrentStream, never()).read(); // Current stream should not be used
                                                               }

    @Test
                                                               public void testReadWithEmptyAndNonEmptyDeferredStreams3() throws Exception {
                                                                   // Create test byte array
                                                                   byte[] buffer = new byte[1024];
                                                                   
                                                                   // Case 1: Test with empty deferredBlockStreams (original behavior)
                                                                   SevenZFile sevenZFileEmpty = new SevenZFile(new File("test.7z"));
                                                                   try {
                                                                       // Use reflection to access private field for testing
                                                                       Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                       deferredStreamsField.setAccessible(true);
                                                                       ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                       deferredStreamsField.set(sevenZFileEmpty, emptyList);
                                                                       
                                                                       // Mock current stream to return known data
                                                                       InputStream mockStream = mock(InputStream.class);
                                                                       when(mockStream.read(buffer, 0, buffer.length)).thenReturn(buffer.length);
                                                                       
                                                                       Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                       currentStreamField.setAccessible(true);
                                                                       currentStreamField.set(sevenZFileEmpty, mockStream);
                                                                       
                                                                       // Should read from currentFolderInputStream
                                                                       int bytesRead = sevenZFileEmpty.read(buffer);
                                                                       assertEquals(buffer.length, bytesRead);
                                                                       verify(mockStream).read(buffer, 0, buffer.length);
                                                                   } finally {
                                                                       sevenZFileEmpty.close();
                                                                   }
                                                                   
                                                                   // Case 2: Test with non-empty deferredBlockStreams (to catch mutant)
                                                                   SevenZFile sevenZFileNonEmpty = new SevenZFile(new File("test.7z"));
                                                                   try {
                                                                       Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                       deferredStreamsField.setAccessible(true);
                                                                       ArrayList<InputStream> nonEmptyList = new ArrayList<>();
                                                                       InputStream mockDeferredStream = mock(InputStream.class);
                                                                       when(mockDeferredStream.read(buffer, 0, buffer.length)).thenReturn(buffer.length/2);
                                                                       nonEmptyList.add(mockDeferredStream);
                                                                       deferredStreamsField.set(sevenZFileNonEmpty, nonEmptyList);
                                                                       
                                                                       // Should read from deferred stream
                                                                       int bytesRead = sevenZFileNonEmpty.read(buffer);
                                                                       assertEquals(buffer.length/2, bytesRead);
                                                                       verify(mockDeferredStream).read(buffer, 0, buffer.length);
                                                                   } finally {
                                                                       sevenZFileNonEmpty.close();
                                                                   }
                                                               }

    @Test
                                                               public void testReadWithEmptyAndNonEmptyDeferredStreams4() throws Exception {
                                                                   // Setup test data
                                                                   byte[] buffer = new byte[10];
                                                                   int offset = 0;
                                                                   int length = 10;
                                                                   
                                                                   // Create mock streams
                                                                   InputStream mockFolderStream = mock(InputStream.class);
                                                                   InputStream mockDeferredStream = mock(InputStream.class);
                                                                   
                                                                   // Create test instance
                                                                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                   
                                                                   // Case 1: Test with empty deferredBlockStreams
                                                                   // Inject mocks using reflection since fields are private
                                                                   Field folderStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                   folderStreamField.setAccessible(true);
                                                                   folderStreamField.set(sevenZFile, mockFolderStream);
                                                                   
                                                                   Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                   deferredStreamsField.setAccessible(true);
                                                                   ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                   deferredStreamsField.set(sevenZFile, emptyList);
                                                                   
                                                                   // Set expectations - should use folder stream
                                                                   when(mockFolderStream.read(buffer, offset, length)).thenReturn(length);
                                                                   
                                                                   // Execute
                                                                   int result = sevenZFile.read(buffer, offset, length);
                                                                   
                                                                   // Verify
                                                                   assertEquals(length, result);
                                                                   verify(mockFolderStream).read(buffer, offset, length);
                                                                   verify(mockDeferredStream, never()).read(buffer, offset, length);
                                                                   
                                                                   // Case 2: Test with non-empty deferredBlockStreams
                                                                   ArrayList<InputStream> nonEmptyList = new ArrayList<>();
                                                                   nonEmptyList.add(mockDeferredStream);
                                                                   deferredStreamsField.set(sevenZFile, nonEmptyList);
                                                                   
                                                                   // Set expectations - should use deferred stream
                                                                   when(mockDeferredStream.read(buffer, offset, length)).thenReturn(length);
                                                                   
                                                                   // Execute
                                                                   result = sevenZFile.read(buffer, offset, length);
                                                                   
                                                                   // Verify
                                                                   assertEquals(length, result);
                                                                   verify(mockDeferredStream).read(buffer, offset, length);
                                                                   // The mockFolderStream should not be called again in this case
                                                                   verify(mockFolderStream, times(1)).read(buffer, offset, length);
                                                               }

    @Test
                                                              public void testReadWithDeferredBlockStreamsShouldNotReadDirectly() throws Exception {
                                                                  // Setup
                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                  
                                                                  // Create mock deferred block streams
                                                                  InputStream mockStream1 = mock(InputStream.class);
                                                                  InputStream mockStream2 = mock(InputStream.class);
                                                                  
                                                                  // Use reflection to inject non-empty deferredBlockStreams since it's private
                                                                  Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                  deferredStreamsField.setAccessible(true);
                                                                  ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                  deferredStreams.add(mockStream1);
                                                                  deferredStreams.add(mockStream2);
                                                                  deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                  
                                                                  // Mock the current stream to verify it's not called
                                                                  InputStream mockCurrentStream = mock(InputStream.class);
                                                                  Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                  currentStreamField.setAccessible(true);
                                                                  currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                  
                                                                  // Test data
                                                                  byte[] buffer = new byte[10];
                                                                  
                                                                  // Original behavior should not call read on currentFolderInputStream
                                                                  // because deferredBlockStreams is not empty
                                                                  int result = sevenZFile.read(buffer);
                                                                  
                                                                  // Verify - in original code, should return -1 or handle deferred streams
                                                                  // Mutated code would try to read from currentFolderInputStream directly
                                                                  verify(mockCurrentStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                  
                                                                  // Clean up
                                                                  sevenZFile.close();
                                                              }

    @Test
                                                              public void testReadWithDeferredStreamsShouldNotUseCurrentStream() throws Exception {
                                                                  // Setup test data
                                                                  byte[] buffer = new byte[10];
                                                                  int offset = 0;
                                                                  int length = 10;
                                                                  
                                                                  // Create mock streams
                                                                  InputStream currentStreamMock = mock(InputStream.class);
                                                                  InputStream deferredStreamMock = mock(InputStream.class);
                                                                  
                                                                  // Configure mocks
                                                                  when(currentStreamMock.read(buffer, offset, length)).thenReturn(5);
                                                                  when(deferredStreamMock.read(buffer, offset, length)).thenReturn(5);
                                                                  
                                                                  // Create SevenZFile instance and set internal state
                                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                  
                                                                  // Use reflection to set private fields since we need to test internal behavior
                                                                  Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                                  currentStreamField.setAccessible(true);
                                                                  currentStreamField.set(sevenZFile, currentStreamMock);
                                                                  
                                                                  Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                  deferredStreamsField.setAccessible(true);
                                                                  ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                  deferredStreams.add(deferredStreamMock);
                                                                  deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                  
                                                                  // Call the method - with original code, this should use deferred stream
                                                                  int result = sevenZFile.read(buffer, offset, length);
                                                                  
                                                                  // Verify behavior - should NOT call current stream when deferred streams exist
                                                                  verify(currentStreamMock, never()).read(buffer, offset, length);
                                                                  // Should call deferred stream
                                                                  verify(deferredStreamMock, times(1)).read(buffer, offset, length);
                                                                  assertEquals(5, result);
                                                              }

    @Test
                                                             public void testReadWithDeferredStreams2() throws Exception {
                                                                 // Setup
                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                 
                                                                 // Create mock streams
                                                                 InputStream mockCurrentStream = mock(InputStream.class);
                                                                 InputStream mockDeferredStream = mock(InputStream.class);
                                                                 
                                                                 // Set expectations
                                                                 when(mockCurrentStream.read()).thenReturn(1);
                                                                 when(mockDeferredStream.read()).thenReturn(2);
                                                                 
                                                                 // Use reflection to inject our mock deferred streams
                                                                 Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                 deferredStreamsField.setAccessible(true);
                                                                 ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                 deferredStreams.add(mockDeferredStream);
                                                                 deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                 
                                                                 // Use reflection to inject our mock current stream
                                                                 Field currentStreamField = SevenZFile.class.getDeclaredField("currentInputStream");
                                                                 currentStreamField.setAccessible(true);
                                                                 currentStreamField.set(sevenZFile, mockCurrentStream);
                                                                 
                                                                 // Test - should read from deferred stream first
                                                                 int result = sevenZFile.read();
                                                                 
                                                                 // Verify - in original code should read from deferred stream (2)
                                                                 // Mutated code would read from current stream (1)
                                                                 assertEquals("Should read from deferred stream first", 2, result);
                                                                 
                                                                 // Verify the deferred stream was called
                                                                 verify(mockDeferredStream).read();
                                                                 verify(mockCurrentStream, never()).read();
                                                             }

    @Test(expected = IllegalStateException.class)
                                                         public void testReadWithoutCurrentEntryThrowsIllegalStateException5() throws Exception {
                                                             // Arrange
                                                             File mockFile = mock(File.class);
                                                             when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                             
                                                             RandomAccessFile mockRaf = mock(RandomAccessFile.class);
                                                             SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                             
                                                             // Mock the internal state to have no current entry
                                                             // This is the state before getNextEntry() is called
                                                             byte[] buffer = new byte[10];
                                                             
                                                             // Act & Assert
                                                             sevenZFile.read(buffer);
                                                             // Should throw IllegalStateException, test will fail if IOException is thrown
                                                         }

    @Test
                                                             public void testReadBeforeGetNextEntryThrowsIllegalStateException() throws Exception {
                                                                 // Arrange
                                                                 File mockFile = mock(File.class);
                                                                 when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                 
                                                                 // Create SevenZFile instance without calling getNextEntry()
                                                                 SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                 
                                                                 byte[] buffer = new byte[10];
                                                                 
                                                                 // Set expectation for the original behavior
                                                                 thrown.expect(IllegalStateException.class);
                                                                 thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                 
                                                                 // Act
                                                                 sevenZFile.read(buffer, 0, 10);
                                                                 
                                                                 // Assertion is handled by ExpectedException rule
                                                             }

    @Test(expected = IllegalStateException.class)
                                                        public void testReadWithoutCurrentEntryThrowsIllegalStateException6() throws Exception {
                                                            // Arrange
                                                            File mockFile = mock(File.class);
                                                            when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                            
                                                            RandomAccessFile mockRaf = mock(RandomAccessFile.class);
                                                            SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                            
                                                            // Use reflection to set currentStream to null
                                                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                            currentStreamField.setAccessible(true);
                                                            currentStreamField.set(sevenZFile, null);
                                                            
                                                            // Act - should throw IllegalStateException
                                                            sevenZFile.read();
                                                        }

    @Test
                                                    public void testReadWithSingleDeferredStream6() throws Exception {
                                                        // Setup
                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                        
                                                        // Use reflection to access private field since we need to test internal behavior
                                                        Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                        deferredStreamsField.setAccessible(true);
                                                        
                                                        // Create a mock InputStream for the deferred block
                                                        InputStream mockStream = mock(InputStream.class);
                                                        when(mockStream.read()).thenReturn(42); // Return some test data
                                                        
                                                        // Set up the deferredBlockStreams with exactly 1 stream
                                                        ArrayList<InputStream> streams = new ArrayList<>();
                                                        streams.add(mockStream);
                                                        deferredStreamsField.set(sevenZFile, streams);
                                                        
                                                        // Also mock the currentFolderInputStream to return our mock stream
                                                        Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                        currentStreamField.setAccessible(true);
                                                        currentStreamField.set(sevenZFile, mockStream);
                                                        
                                                        // Test the read operation
                                                        int result = sevenZFile.read();
                                                        
                                                        // Verify behavior - should read from the stream exactly once
                                                        assertEquals(42, result);
                                                        verify(mockStream, times(1)).read();
                                                        
                                                        // The key assertion - after reading, deferredBlockStreams should be empty
                                                        // This catches the mutant because with ">=" it might try to process the stream again
                                                        assertTrue(((ArrayList<?>)deferredStreamsField.get(sevenZFile)).isEmpty());
                                                        
                                                        // Clean up
                                                        deferredStreamsField.setAccessible(false);
                                                        currentStreamField.setAccessible(false);
                                                    }

    @Test
                                                    public void testReadWithSingleDeferredStream7() throws Exception {
                                                        // Setup
                                                        File mockFile = mock(File.class);
                                                        when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                        
                                                        SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                        
                                                        // Create a single deferred stream
                                                        InputStream mockStream = mock(InputStream.class);
                                                        ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                        deferredStreams.add(mockStream);
                                                        
                                                        // Use reflection to inject our test deferred streams
                                                        Field deferredField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                        deferredField.setAccessible(true);
                                                        deferredField.set(sevenZFile, deferredStreams);
                                                        
                                                        // Mock current stream to return some data
                                                        InputStream mockCurrentStream = mock(InputStream.class);
                                                        when(mockCurrentStream.read(any(byte[].class), anyInt(), anyInt()))
                                                            .thenReturn(10); // return 10 bytes read
                                                        
                                                        Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                        currentStreamField.setAccessible(true);
                                                        currentStreamField.set(sevenZFile, mockCurrentStream);
                                                        
                                                        // Test
                                                        byte[] buffer = new byte[100];
                                                        int bytesRead = sevenZFile.read(buffer);
                                                        
                                                        // Verify
                                                        assertEquals(10, bytesRead);
                                                        
                                                        // Key assertion: verify deferred stream was NOT processed (mock not interacted with)
                                                        verify(mockStream, never()).close();
                                                        verify(mockStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                        
                                                        // Cleanup
                                                        sevenZFile.close();
                                                    }

    @Test
                                                    public void testReadWithSingleDeferredStream8() throws Exception {
                                                        // Setup
                                                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                        
                                                        // Mock the deferredBlockStreams to contain exactly 1 stream
                                                        InputStream mockStream = mock(InputStream.class);
                                                        when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                        
                                                        // Use reflection to access private field since we need to test internal behavior
                                                        Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                        deferredStreamsField.setAccessible(true);
                                                        ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                        deferredStreams.add(mockStream);
                                                        deferredStreamsField.set(sevenZFile, deferredStreams);
                                                        
                                                        // Mock current stream to return our mock stream
                                                        InputStream currentStream = mock(InputStream.class);
                                                        when(currentStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                        
                                                        Field currentStreamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                                                        currentStreamField.setAccessible(true);
                                                        currentStreamField.set(sevenZFile, currentStream);
                                                        
                                                        // Test
                                                        byte[] buffer = new byte[10];
                                                        int result = sevenZFile.read(buffer, 0, 10);
                                                        
                                                        // Verify
                                                        assertEquals(5, result); // Should read from current stream, not deferred
                                                        verify(currentStream, times(1)).read(buffer, 0, 10);
                                                        verify(mockStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                        
                                                        // Clean up
                                                        deferredStreamsField.setAccessible(false);
                                                        currentStreamField.setAccessible(false);
                                                    }

    @Test
                                                   public void testRead_ShouldRemoveStreamFromDeferredBlockStreams1() throws Exception {
                                                       // Setup
                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                       
                                                       // Mock the streams and add them to deferredBlockStreams
                                                       InputStream stream1 = mock(InputStream.class);
                                                       InputStream stream2 = mock(InputStream.class);
                                                       when(stream1.read()).thenReturn(1);
                                                       when(stream2.read()).thenReturn(2);
                                                       
                                                       // Use reflection to access private field deferredBlockStreams
                                                       Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                       deferredStreamsField.setAccessible(true);
                                                       @SuppressWarnings("unchecked")
                                                       ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                       deferredStreams.add(stream1);
                                                       deferredStreams.add(stream2);
                                                       
                                                       // Also mock getCurrentStream to return our mocked streams
                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                       getCurrentStreamMethod.setAccessible(true);
                                                       when(getCurrentStreamMethod.invoke(sevenZFile)).thenReturn(stream1).thenReturn(stream2);
                                                       
                                                       // Test - first read
                                                       int result1 = sevenZFile.read();
                                                       assertEquals(1, result1);
                                                       assertEquals(1, deferredStreams.size()); // Should be 1 if remove(0) was used
                                                       
                                                       // Test - second read
                                                       int result2 = sevenZFile.read();
                                                       assertEquals(2, result2);
                                                       assertEquals(0, deferredStreams.size()); // Should be 0 if remove(0) was used
                                                       
                                                       // Verify the streams were actually read
                                                       verify(stream1).read();
                                                       verify(stream2).read();
                                                   }

    @Test
                                                   public void testReadConsumesStreams() throws Exception {
                                                       // Setup - create mock input streams
                                                       InputStream stream1 = mock(InputStream.class);
                                                       InputStream stream2 = mock(InputStream.class);
                                                       when(stream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                       when(stream2.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                       
                                                       // Create test instance and inject our streams
                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                       ArrayList<InputStream> streams = new ArrayList<>();
                                                       streams.add(stream1);
                                                       streams.add(stream2);
                                                       
                                                       // Use reflection to set private field since there's no setter
                                                       Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                       deferredStreamsField.setAccessible(true);
                                                       deferredStreamsField.set(sevenZFile, streams);
                                                       
                                                       // First read - should consume first stream in original, but not in mutant
                                                       byte[] buffer = new byte[100];
                                                       sevenZFile.read(buffer);
                                                       
                                                       // Verify streams list size changed (original) or didn't change (mutant)
                                                       assertEquals("Stream should be consumed after read", 1, streams.size());
                                                       
                                                       // Second read - should consume second stream in original
                                                       sevenZFile.read(buffer);
                                                       assertEquals("All streams should be consumed after reads", 0, streams.size());
                                                   }

    @Test
                                                   public void testReadRemovesStreamFromDeferredBlockStreams2() throws Exception {
                                                       // Setup
                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                       InputStream mockStream1 = mock(InputStream.class);
                                                       InputStream mockStream2 = mock(InputStream.class);
                                                       
                                                       // Use reflection to access private field since we need to test internal behavior
                                                       Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                       deferredStreamsField.setAccessible(true);
                                                       @SuppressWarnings("unchecked")
                                                       ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                       
                                                       // Add our mock streams
                                                       deferredStreams.add(mockStream1);
                                                       deferredStreams.add(mockStream2);
                                                       
                                                       // Mock behavior for the read operation
                                                       when(mockStream1.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                                                       
                                                       // Record initial size
                                                       int initialSize = deferredStreams.size();
                                                       
                                                       // Test
                                                       byte[] buffer = new byte[100];
                                                       sevenZFile.read(buffer, 0, 100);
                                                       
                                                       // Verify
                                                       int finalSize = deferredStreams.size();
                                                       assertNotEquals("Stream should be removed from deferredBlockStreams after reading", 
                                                                      initialSize, finalSize);
                                                       assertEquals("Only one stream should be removed", initialSize - 1, finalSize);
                                                       
                                                       // Clean up
                                                       deferredStreamsField.setAccessible(false);
                                                   }

    @Test
                                                  public void testReadProcessesStreamsInCorrectOrder1() throws Exception {
                                                      // Setup mock streams with different return values
                                                      InputStream firstStream = mock(InputStream.class);
                                                      InputStream secondStream = mock(InputStream.class);
                                                      
                                                      // Setup mock behavior - each stream returns different values when read
                                                      when(firstStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(1);
                                                      when(secondStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(2);
                                                      
                                                      // Create test instance and inject our streams
                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                      
                                                      // Use reflection to access private field deferredBlockStreams
                                                      Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                      deferredStreamsField.setAccessible(true);
                                                      @SuppressWarnings("unchecked")
                                                      ArrayList<InputStream> deferredStreams = (ArrayList<InputStream>) deferredStreamsField.get(sevenZFile);
                                                      
                                                      // Add our test streams in specific order
                                                      deferredStreams.add(firstStream);
                                                      deferredStreams.add(secondStream);
                                                      
                                                      // Test data
                                                      byte[] buffer = new byte[10];
                                                      
                                                      // First read should use first stream (FIFO order)
                                                      int result1 = sevenZFile.read(buffer, 0, 10);
                                                      assertEquals(1, result1);
                                                      
                                                      // Second read should use second stream
                                                      int result2 = sevenZFile.read(buffer, 0, 10);
                                                      assertEquals(2, result2);
                                                      
                                                      // Verify mock interactions
                                                      verify(firstStream).read(eq(buffer), eq(0), eq(10));
                                                      verify(secondStream).read(eq(buffer), eq(0), eq(10));
                                                      
                                                      // The mutant would process streams in reverse order (LIFO), 
                                                      // so this test would fail as it would get 2 then 1 instead of 1 then 2
                                                  }

    @Test
                                                 public void testGetCurrentStreamReturnsStreamsInCorrectOrder1() throws Exception {
                                                     // Setup
                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                     
                                                     // Create mock input streams with different behaviors so we can identify them
                                                     InputStream firstStream = mock(InputStream.class);
                                                     when(firstStream.read()).thenReturn(1);
                                                     InputStream secondStream = mock(InputStream.class);
                                                     when(secondStream.read()).thenReturn(2);
                                                     
                                                     // Use reflection to access private field deferredBlockStreams
                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                     deferredBlockStreamsField.setAccessible(true);
                                                     @SuppressWarnings("unchecked")
                                                     ArrayList<InputStream> deferredBlockStreams = (ArrayList<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                                                     
                                                     // Add streams in specific order
                                                     deferredBlockStreams.add(firstStream);
                                                     deferredBlockStreams.add(secondStream);
                                                     
                                                     // Get private getCurrentStream method via reflection
                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                     getCurrentStreamMethod.setAccessible(true);
                                                     
                                                     // Test - first call should return first stream (reads 1)
                                                     InputStream currentStream = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                     assertEquals(1, currentStream.read());
                                                     
                                                     // Test - second call should return second stream (reads 2)
                                                     currentStream = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                     assertEquals(2, currentStream.read());
                                                     
                                                     // Verify streams were removed (list should be empty)
                                                     assertTrue(deferredBlockStreams.isEmpty());
                                                     
                                                     // Clean up
                                                     getCurrentStreamMethod.setAccessible(false);
                                                     deferredBlockStreamsField.setAccessible(false);
                                                 }

    @Test
                                                 public void testReadOrderFromDeferredBlockStreams() throws Exception {
                                                     // Create mock input streams that will return different values
                                                     InputStream firstStream = mock(InputStream.class);
                                                     InputStream secondStream = mock(InputStream.class);
                                                     
                                                     // Setup mock behaviors
                                                     when(firstStream.read(any(byte[].class), anyInt(), anyInt()))
                                                         .thenReturn(1); // First stream returns 1
                                                     when(secondStream.read(any(byte[].class), anyInt(), anyInt()))
                                                         .thenReturn(2); // Second stream returns 2
                                                     
                                                     // Create test instance
                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                     
                                                     // Use reflection to access private field
                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                     deferredBlockStreamsField.setAccessible(true);
                                                     
                                                     // Create and populate the deferredBlockStreams list
                                                     List<InputStream> streams = new ArrayList<>();
                                                     streams.add(firstStream);
                                                     streams.add(secondStream);
                                                     deferredBlockStreamsField.set(sevenZFile, streams);
                                                     
                                                     // Test reading - should use first stream first (FIFO)
                                                     byte[] buffer = new byte[10];
                                                     int result = sevenZFile.read(buffer);
                                                     
                                                     // Verify FIFO behavior - first stream should be called
                                                     assertEquals(1, result);
                                                     verify(firstStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                     
                                                     // Second read should use second stream
                                                     result = sevenZFile.read(buffer);
                                                     assertEquals(2, result);
                                                     verify(secondStream).read(eq(buffer), eq(0), eq(buffer.length));
                                                     
                                                     // Verify no more streams left by checking read returns -1
                                                     result = sevenZFile.read(buffer);
                                                     assertEquals(-1, result);
                                                 }

    @Test
                                            public void testReadSkipsRemainingBytes() throws Exception {
                                                // Create a temporary test file with known content
                                                File tempFile = File.createTempFile("test7z", ".7z");
                                                try {
                                                    // Write test data - more than we'll read in one go
                                                    byte[] testData = new byte[1024]; // 1KB of data
                                                    Arrays.fill(testData, (byte)1);
                                                    try (RandomAccessFile raf = new RandomAccessFile(tempFile, "rw")) {
                                                        raf.write(testData);
                                                    }
                                                
                                                    // Create SevenZFile instance
                                                    SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                    
                                                    // Read partial data (smaller than total file size)
                                                    byte[] buffer = new byte[100];
                                                    int bytesRead = sevenZFile.read(buffer);
                                                    
                                                    // Use reflection to access private file field
                                                    Field fileField = SevenZFile.class.getDeclaredField("file");
                                                    fileField.setAccessible(true);
                                                    RandomAccessFile file = (RandomAccessFile) fileField.get(sevenZFile);
                                                    
                                                    // Verify the file pointer was advanced to end of file (original behavior)
                                                    assertEquals("File should be fully consumed", 
                                                                 testData.length, 
                                                                 file.getFilePointer());
                                                    
                                                    sevenZFile.close();
                                                } finally {
                                                    tempFile.delete();
                                                }
                                            }

    @Test
                                            public void testReadShouldSkipToEndOfStreamWhenNeeded() throws Exception {
                                                // Setup
                                                byte[] testData = "test data".getBytes();
                                                InputStream mockStream = mock(InputStream.class);
                                                when(mockStream.read(any(byte[].class), anyInt(), anyInt()))
                                                    .thenReturn(testData.length);
                                                
                                                // Create real SevenZFile instance
                                                File tempFile = File.createTempFile("test", ".7z");
                                                try {
                                                    SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                    
                                                    // Use reflection to set the current stream
                                                    Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                                                    currentStreamField.setAccessible(true);
                                                    currentStreamField.set(sevenZFile, mockStream);
                                                    
                                                    // Set deferredBlockStreams
                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                    deferredBlockStreamsField.setAccessible(true);
                                                    deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                    
                                                    // Test
                                                    byte[] buffer = new byte[1024];
                                                    int bytesRead = sevenZFile.read(buffer, 0, buffer.length);
                                                    
                                                    // Verify
                                                    assertEquals(testData.length, bytesRead);
                                                    verify(mockStream).skip(Long.MAX_VALUE);  // Would fail if mutant (skip(0)) is present
                                                    
                                                    // Clean up
                                                    currentStreamField.setAccessible(false);
                                                    deferredBlockStreamsField.setAccessible(false);
                                                } finally {
                                                    tempFile.delete();
                                                }
                                            }

    @Test
                        public void testReadDetectsSkipMutant() throws Exception {
                            // Setup mock stream
                            InputStream mockStream = mock(InputStream.class);
                            
                            // Configure mock behavior
                            when(mockStream.read()).thenReturn(65); // 'A'
                            when(mockStream.skip(anyLong())).thenAnswer(invocation -> {
                                long bytesToSkip = (Long)invocation.getArguments()[0];
                                // Verify skip was called with Long.MAX_VALUE (original behavior)
                                assertEquals(Long.MAX_VALUE, bytesToSkip);
                                return bytesToSkip; // Return the same value to indicate full skip
                            });
                            
                            // Create real SevenZFile instance with mock file
                            File mockFile = mock(File.class);
                            SevenZFile sevenZFile = new SevenZFile(mockFile);
                            
                            // Use reflection to set the private currentStream field
                            Field currentStreamField = SevenZFile.class.getDeclaredField("currentStream");
                            currentStreamField.setAccessible(true);
                            currentStreamField.set(sevenZFile, mockStream);
                            
                            // Call the read method
                            int result = sevenZFile.read();
                            
                            // Verify interactions
                            verify(mockStream).skip(Long.MAX_VALUE); // This will fail if mutant is present
                            verify(mockStream).read();
                            
                            // Verify result
                            assertEquals(65, result);
                            
                            // Additional verification for stream state
                            verify(mockStream, never()).skip(0); // Ensure mutant behavior isn't present
                        }

    @Test
                    public void testReadShouldSkipAllRemainingBytes() throws Exception {
                        // Create a mock input stream with more than 1 byte of data
                        InputStream mockStream = mock(InputStream.class);
                        when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                        
                        // Create a SevenZFile instance and inject our mock stream
                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                        // Use reflection to set the private currentFolderInputStream field
                        Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                        field.setAccessible(true);
                        field.set(sevenZFile, mockStream);
                        
                        // Create a test buffer
                        byte[] buffer = new byte[1024];
                        
                        // Call the read method
                        sevenZFile.read(buffer);
                        
                        // Verify that skip was called with Long.MAX_VALUE (original behavior)
                        // The mutant would call skip with 1 instead
                        verify(mockStream).skip(Long.MAX_VALUE);
                        
                        // Also verify the read was attempted
                        verify(mockStream).read(eq(buffer), eq(0), eq(buffer.length));
                    }

    @Test
                    public void testReadShouldSkipMaxBytesWhenNeeded() throws Exception {
                        // Setup
                        InputStream mockStream = mock(InputStream.class);
                        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                        
                        // Use reflection to inject our mock stream since currentFolderInputStream is private
                        Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                        streamField.setAccessible(true);
                        streamField.set(sevenZFile, mockStream);
                        
                        // Setup mock behavior
                        byte[] testData = new byte[10];
                        when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(10);
                        
                        // Test the read operation
                        sevenZFile.read(testData, 0, 10);
                        
                        // Verify that skip was called with Long.MAX_VALUE (original behavior)
                        // This will fail if mutant (skip 1) is present
                        verify(mockStream).skip(Long.MAX_VALUE);
                        
                        // Clean up
                        sevenZFile.close();
                    }

    @Test
                   public void testReadSkipsCorrectAmountOfBytes() throws Exception {
                       // Create mock input stream that will track skip operations
                       InputStream mockStream = mock(InputStream.class);
                       
                       // Setup mock behavior
                       when(mockStream.read()).thenReturn(42); // return some test value
                       when(mockStream.skip(anyLong())).thenReturn(Long.MAX_VALUE); // accept any skip
                       
                       // Create SevenZFile with mock behavior
                       SevenZFile sevenZFile = mock(SevenZFile.class);
                       // Instead of mocking private getCurrentStream(), mock the read() method to use our mock stream
                       when(sevenZFile.read()).thenAnswer(invocation -> mockStream.read());
                       
                       // Call the read method
                       int result = sevenZFile.read();
                       
                       // Verify correct behavior
                       assertEquals(42, result); // verify we got expected value
                       verify(mockStream).skip(Long.MAX_VALUE); // verify full skip was attempted
                   }

    @Test
               public void testReadShouldCloseStreamAfterOperation1() throws Exception {
                   // Setup
                   byte[] testData = new byte[]{1, 2, 3};
                   InputStream mockStream = mock(InputStream.class);
                   when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(testData.length);
                   
                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                   // Use reflection to inject our mock stream since currentFolderInputStream is private
                   Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                   streamField.setAccessible(true);
                   streamField.set(sevenZFile, mockStream);
                   
                   // Test
                   byte[] buffer = new byte[10];
                   sevenZFile.read(buffer);
                   
                   // Verify
                   verify(mockStream, times(1)).close();
                   
                   // Cleanup
                   sevenZFile.close();
               }

    @Test
               public void testReadShouldCloseStreamAfterOperation2() throws Exception {
                   // Setup
                   byte[] buffer = new byte[10];
                   InputStream mockStream = mock(InputStream.class);
                   when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                   
                   SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                   // Use reflection to set private field since we need to test internal behavior
                   Field streamField = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                   streamField.setAccessible(true);
                   streamField.set(sevenZFile, mockStream);
                   
                   // Execute
                   sevenZFile.read(buffer, 0, 10);
                   
                   // Verify - this will fail for the mutant but pass for original
                   verify(mockStream).close();
                   
                   // Clean up
                   streamField.setAccessible(false);
               }

    @Test
              public void testReadClosesStream2() throws Exception {
                  // Setup
                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                  InputStream mockStream = mock(InputStream.class);
                  
                  // Mock the behavior of getCurrentStream()
                  when(mockStream.read()).thenReturn(42); // Return some dummy byte
                  
                  // Use reflection to set private field
                  Field field = SevenZFile.class.getDeclaredField("currentFolderInputStream");
                  field.setAccessible(true);
                  field.set(sevenZFile, mockStream);
                  
                  // Execute
                  int result = sevenZFile.read();
                  
                  // Verify
                  assertEquals(42, result); // Verify correct reading
                  verify(mockStream).close(); // This will fail if the mutant is present
                  
                  // Clean up (in case test fails)
                  try {
                      sevenZFile.close();
                  } catch (Exception e) {
                      // Ignore cleanup errors
                  }
              }

    @Test
          public void testReadShouldNotReturnNullWhenStreamsAvailable() throws Exception {
              // Setup
              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
              InputStream mockStream = mock(InputStream.class);
              
              // Use reflection to access private field since deferredBlockStreams is private
              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
              deferredBlockStreamsField.setAccessible(true);
              @SuppressWarnings("unchecked")
              ArrayList<InputStream> deferredBlockStreams = (ArrayList<InputStream>) deferredBlockStreamsField.get(sevenZFile);
              deferredBlockStreams.add(mockStream);
              
              // Mock the read operation
              when(mockStream.read()).thenReturn(42); // return some test value
              
              // Test
              int result = sevenZFile.read();
              
              // Verify
              assertNotNull("read() should not return null when streams are available", result);
              
              // Clean up
              deferredBlockStreamsField.setAccessible(false);
          }

    @Test
          public void testReadByteArrayShouldReturnIntNotNull() throws Exception {
              // Setup test data
              byte[] testData = "test data".getBytes();
              byte[] buffer = new byte[testData.length];
              
              // Create a mock InputStream for deferredBlockStreams
              InputStream mockStream = new ByteArrayInputStream(testData);
              
              // Create SevenZFile instance and inject our mock stream
              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
              // Use reflection to access private field since there's no setter
              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
              deferredStreamsField.setAccessible(true);
              ArrayList<InputStream> streams = new ArrayList<>();
              streams.add(mockStream);
              deferredStreamsField.set(sevenZFile, streams);
              
              // Test the read method
              int bytesRead = sevenZFile.read(buffer);
              
              // Verify the result
              assertNotNull("Return value should not be null", bytesRead);
              assertEquals("Should read all bytes", testData.length, bytesRead);
              assertArrayEquals("Buffer should contain read data", testData, buffer);
              
              // Clean up
              sevenZFile.close();
          }

    @Test(expected = NullPointerException.class)
          public void testReadWithNullStream() throws Exception {
              // Setup - don't add any streams to deferredBlockStreams
              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
              
              // Use reflection to set empty deferredBlockStreams
              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
              deferredBlockStreamsField.setAccessible(true);
              deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
              
              // Test - this should throw NPE with the mutant
              byte[] buffer = new byte[10];
              sevenZFile.read(buffer, 0, 10);
          }

    @Test
         public void testReadWithDeferredBlockStream() throws Exception {
             // Setup
             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
             
             // Mock the deferredBlockStreams with a real input stream
             InputStream mockStream = mock(InputStream.class);
             when(mockStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // return 5 bytes read
             
             // Use reflection to set the private deferredBlockStreams field
             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
             deferredBlockStreamsField.setAccessible(true);
             ArrayList<InputStream> streams = new ArrayList<>();
             streams.add(mockStream);
             deferredBlockStreamsField.set(sevenZFile, streams);
             
             // Test
             byte[] buffer = new byte[10];
             int bytesRead = sevenZFile.read(buffer, 0, 10);
             
             // Verify
             assertNotEquals(-1, bytesRead); // Should have read some bytes
             assertEquals(5, bytesRead); // Should match our mock return value
             
             // Verify the stream was actually used
             verify(mockStream).read(eq(buffer), eq(0), eq(10));
         }

    @Test
     public void testReadShouldGetFromFirstStreamWhenMultipleStreamsExist() throws Exception {
         // Arrange
         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
         
         // Create mock streams with different return values
         InputStream firstStream = mock(InputStream.class);
         when(firstStream.read()).thenReturn(10);
         
         InputStream lastStream = mock(InputStream.class);
         when(lastStream.read()).thenReturn(20);
         
         // Use reflection to set the deferredBlockStreams field since it's private
         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
         deferredBlockStreamsField.setAccessible(true);
         ArrayList<InputStream> streams = new ArrayList<>();
         streams.add(firstStream);
         streams.add(lastStream);
         deferredBlockStreamsField.set(sevenZFile, streams);
         
         // Act
         int result = sevenZFile.read();
         
         // Assert
         assertEquals("Should return value from first stream", 10, result);
         verify(firstStream).read();  // Verify first stream was read
         verify(lastStream, never()).read();  // Verify last stream wasn't read
         
         // Clean up
         deferredBlockStreamsField.setAccessible(false);
     }

    @Test
     public void testGetCurrentStreamReturnsFirstStream3() throws Exception {
         // Setup - create mock streams
         InputStream firstStream = mock(InputStream.class);
         InputStream lastStream = mock(InputStream.class);
         
         // Create SevenZFile instance (mocking dependencies)
         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
         
         // Use reflection to access private deferredBlockStreams field
         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
         deferredBlockStreamsField.setAccessible(true);
         
         // Add our mock streams to the deferredBlockStreams
         ArrayList<InputStream> streams = new ArrayList<>();
         streams.add(firstStream);
         streams.add(lastStream);
         deferredBlockStreamsField.set(sevenZFile, streams);
         
         // Get the method to test
         Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
         getCurrentStreamMethod.setAccessible(true);
         
         // Verify the returned stream is the first one (not last)
         InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
         assertSame("Should return first stream from deferredBlockStreams", 
                   firstStream, result);
         
         // Additional verification that it's not the last stream
         assertNotSame("Should not return last stream from deferredBlockStreams",
                      lastStream, result);
     }

    @Test
    public void testGetCurrentStreamReturnsFirstStream2() throws Exception {
        // Setup - create mock input streams with different content
        InputStream firstStream = mock(InputStream.class);
        InputStream lastStream = mock(InputStream.class);
        
        // Create a SevenZFile instance (we'll need to use reflection since constructor does file operations)
        SevenZFile sevenZFile = mock(SevenZFile.class);
        
        // Set up deferredBlockStreams with multiple streams
        ArrayList<InputStream> streams = new ArrayList<>();
        streams.add(firstStream);
        streams.add(lastStream);
        
        // Use reflection to set the private field deferredBlockStreams
        Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
        deferredBlockStreamsField.setAccessible(true);
        deferredBlockStreamsField.set(sevenZFile, streams);
        
        // Use reflection to access the private getCurrentStream method
        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
        getCurrentStreamMethod.setAccessible(true);
        
        // Invoke the private method
        InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
        
        // Verify the returned stream is the first one
        assertSame("Should return first stream from deferredBlockStreams", firstStream, result);
        
        // Additional verification that it's not the last stream
        assertNotSame("Should not return last stream from deferredBlockStreams", lastStream, result);
    }


}
