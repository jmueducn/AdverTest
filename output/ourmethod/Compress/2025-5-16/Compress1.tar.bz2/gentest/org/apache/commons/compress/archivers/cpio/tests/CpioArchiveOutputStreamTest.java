package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class CpioArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                       public void testClose_WhenAlreadyClosed_DoesNothing() throws IOException {
                                                                                                                           // Arrange
                                                                                                                           OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                           CpioArchiveOutputStream testStream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                           
                                                                                                                           // First close to set closed=true
                                                                                                                           testStream.close();
                                                                                                                           reset(mockOutputStream); // Clear any previous interactions
                                                                                                                       
                                                                                                                           // Act
                                                                                                                           testStream.close();
                                                                                                                       
                                                                                                                           // Assert
                                                                                                                           verify(mockOutputStream, never()).close();
                                                                                                                           // No need to verify finish() as it would have been called in first close
                                                                                                                       }

    @Test
                                                                                                                       public void testClose_WhenNotClosed_CallsFinishAndSuperClose() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                           CpioArchiveOutputStream testStream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                           
                                                                                                                           // Use reflection to access private 'closed' field
                                                                                                                           Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                           closedField.setAccessible(true);
                                                                                                                           
                                                                                                                           // Act
                                                                                                                           testStream.close();
                                                                                                                           
                                                                                                                           // Assert
                                                                                                                           verify(mockOutputStream).close(); // Verify super.close() was called
                                                                                                                           assertTrue((boolean) closedField.get(testStream)); // Verify state was updated
                                                                                                                           // Note: We can't directly verify finish() was called since it's not mockable,
                                                                                                                           // but we can verify its side effects if any
                                                                                                                       }

    @Test
                                                                                                                       public void testClose_WhenFinishThrowsException_StillClosesAndPropagates() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                           CpioArchiveOutputStream testStream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                           CpioArchiveOutputStream spyStream = spy(testStream);
                                                                                                                           doThrow(new IOException("Finish failed")).when(spyStream).finish();
                                                                                                                           
                                                                                                                           // Act & Assert
                                                                                                                           try {
                                                                                                                               spyStream.close();
                                                                                                                               fail("Expected IOException");
                                                                                                                           } catch (IOException e) {
                                                                                                                               assertEquals("Finish failed", e.getMessage());
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Verify super.close() was still called
                                                                                                                           verify(mockOutputStream).close();
                                                                                                                           
                                                                                                                           // Verify closed flag is set using reflection
                                                                                                                           Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                           closedField.setAccessible(true);
                                                                                                                           assertTrue((boolean) closedField.get(spyStream));
                                                                                                                       }

    @Test
                                                                                                                       public void testClose_WhenNotClosed_SetsClosedFlag() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                           CpioArchiveOutputStream testStream = new CpioArchiveOutputStream(out);
                                                                                                                           
                                                                                                                           // Get the closed field via reflection since it's likely private
                                                                                                                           Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                           closedField.setAccessible(true);
                                                                                                                           
                                                                                                                           // Verify initial state
                                                                                                                           assertFalse((boolean) closedField.get(testStream));
                                                                                                                           
                                                                                                                           // Act
                                                                                                                           testStream.close();
                                                                                                                           
                                                                                                                           // Assert
                                                                                                                           assertTrue((boolean) closedField.get(testStream));
                                                                                                                       }

    @Test
                                                                                                                   public void testClose_WhenSuperCloseThrowsException_StillMarksAsClosed() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                       // Arrange
                                                                                                                       OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                       doThrow(new IOException("Close failed")).when(mockOutputStream).close();
                                                                                                                       
                                                                                                                       // Create test stream with mocked output stream
                                                                                                                       CpioArchiveOutputStream testStream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                       
                                                                                                                       // Use reflection to access the closed field since it's likely private
                                                                                                                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                       closedField.setAccessible(true);
                                                                                                                       closedField.set(testStream, false); // Ensure it starts as not closed
                                                                                                                       
                                                                                                                       // Act & Assert
                                                                                                                       try {
                                                                                                                           testStream.close();
                                                                                                                           fail("Expected IOException");
                                                                                                                       } catch (IOException e) {
                                                                                                                           assertEquals("Close failed", e.getMessage());
                                                                                                                       }
                                                                                                                       
                                                                                                                       // Verify state was still updated
                                                                                                                       assertTrue((boolean) closedField.get(testStream));
                                                                                                                   }

    @Test
                                                                                                                   public void testPadWhenSkipIsZeroShouldNotWrite() throws Exception {
                                                                                                                       // Arrange
                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                       CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                                                                                                                       long count = 100L;
                                                                                                                       int border = 100; // count % border = 0
                                                                                                                       
                                                                                                                       // Act
                                                                                                                       // Using reflection to access private method for testing
                                                                                                                       java.lang.reflect.Method method = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                                                       method.setAccessible(true);
                                                                                                                       method.invoke(sut, count, border);
                                                                                                                       
                                                                                                                       // Assert
                                                                                                                       verify(mockOut, never()).write(any(byte[].class));
                                                                                                                   }

    @Test
                                                                                                                   public void testPadWhenSkipGreaterThanZeroShouldWrite() throws Exception {
                                                                                                                       // Arrange
                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                       CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                                                                                                                       long count = 105L;
                                                                                                                       int border = 100; // count % border = 5
                                                                                                                       
                                                                                                                       // Act
                                                                                                                       java.lang.reflect.Method method = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                                                       method.setAccessible(true);
                                                                                                                       method.invoke(sut, count, border);
                                                                                                                       
                                                                                                                       // Assert
                                                                                                                       verify(mockOut).write(any(byte[].class));
                                                                                                                   }

    @Test
                                                                                                             public void testWriteAsciiLongRadixHandling() throws Exception {
                                                                                                                 // Setup
                                                                                                                 ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                 CpioArchiveOutputStream out = new CpioArchiveOutputStream(byteOut);
                                                                                                                 long number = 255L; // Test value that would be affected by padding
                                                                                                                 int length = 8; // Sufficient length to show padding differences
                                                                                                                 
                                                                                                                 // Get private method via reflection
                                                                                                                 Method writeAsciiLong = CpioArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                     "writeAsciiLong", long.class, int.class, int.class);
                                                                                                                 writeAsciiLong.setAccessible(true);
                                                                                                                 
                                                                                                                 // Test case 1: radix=16 (hexadecimal) - should apply padding
                                                                                                                 writeAsciiLong.invoke(out, number, length, 16);
                                                                                                                 byte[] hexOutput = byteOut.toByteArray();
                                                                                                                 byteOut.reset();
                                                                                                                 
                                                                                                                 // Test case 2: radix=10 (decimal) - should not apply padding
                                                                                                                 writeAsciiLong.invoke(out, number, length, 10);
                                                                                                                 byte[] decOutput = byteOut.toByteArray();
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 // Original behavior: hex output should be longer due to padding
                                                                                                                 // Mutant behavior: would be the opposite
                                                                                                                 assertTrue("Hexadecimal output should be longer than decimal due to padding", 
                                                                                                                            hexOutput.length > decOutput.length);
                                                                                                                 
                                                                                                                 // Additional verification for exact expected behavior
                                                                                                                 // For radix=16, expect padding bytes (typically zeros)
                                                                                                                 assertEquals("Incorrect padding for hexadecimal", 
                                                                                                                             length, hexOutput.length);
                                                                                                                 // For radix=10, expect just the number representation
                                                                                                                 assertEquals("Incorrect output length for decimal", 
                                                                                                                             String.valueOf(number).length(), decOutput.length);
                                                                                                             }

    @Test
                                                                                                        public void testPad_ShouldWritePaddingWhenCountNotDivisibleByBorder() throws Exception {
                                                                                                            // Setup mocks and test objects
                                                                                                            OutputStream mockOut = mock(OutputStream.class);
                                                                                                            CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                            
                                                                                                            // Use reflection to access private pad method
                                                                                                            Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                                            padMethod.setAccessible(true);
                                                                                                        
                                                                                                            // Test when count is less than border (should pad)
                                                                                                            padMethod.invoke(stream, 3L, 5);
                                                                                                            verify(mockOut).write(new byte[2]); // 5-3=2 bytes padding
                                                                                                            
                                                                                                            // Test when count equals border (no padding)
                                                                                                            reset(mockOut);
                                                                                                            padMethod.invoke(stream, 5L, 5);
                                                                                                            verify(mockOut, never()).write(any(byte[].class));
                                                                                                            
                                                                                                            // Test when count is greater than border but not multiple (should pad)
                                                                                                            reset(mockOut);
                                                                                                            padMethod.invoke(stream, 7L, 5);
                                                                                                            verify(mockOut).write(new byte[3]); // 5-2=3 bytes padding (7%5=2)
                                                                                                            
                                                                                                            // Test when count is multiple of border (no padding)
                                                                                                            reset(mockOut);
                                                                                                            padMethod.invoke(stream, 10L, 5);
                                                                                                            verify(mockOut, never()).write(any(byte[].class));
                                                                                                            
                                                                                                            // Test edge case with border=1 (should never pad)
                                                                                                            reset(mockOut);
                                                                                                            padMethod.invoke(stream, 999L, 1);
                                                                                                            verify(mockOut, never()).write(any(byte[].class));
                                                                                                        }

    @Test
                                                                                                   public void testPadWithExactBorderLength() throws Exception {
                                                                                                       // Setup
                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                       CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
                                                                                                       long count = 10;
                                                                                                       int border = 5;
                                                                                                       
                                                                                                       // Get the private pad method via reflection
                                                                                                       Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                                       padMethod.setAccessible(true);
                                                                                                       
                                                                                                       // When count % border = 0, skip = 0, so border - skip = border
                                                                                                       // Original would write border bytes, mutant would skip
                                                                                                       padMethod.invoke(cpioOut, count, border);
                                                                                                       
                                                                                                       // Verify the padding was written (exactly border bytes)
                                                                                                       byte[] expectedPadding = new byte[border];
                                                                                                       verify(mockOut).write(expectedPadding);
                                                                                                       
                                                                                                       // Test edge case where count % border gives exact border length
                                                                                                       count = 15; // 15 % 5 = 0
                                                                                                       padMethod.invoke(cpioOut, count, border);
                                                                                                       verify(mockOut, times(2)).write(expectedPadding);
                                                                                                   }

    @Test
                                                                                              public void testPadWritesFullPaddingBytes() throws Exception {
                                                                                                  // Arrange
                                                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                                                  CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
                                                                                                  
                                                                                                  // Test case where count % border != 0
                                                                                                  long count = 5;
                                                                                                  int border = 3;
                                                                                                  long expectedSkip = count % border; // 2
                                                                                                  int expectedPaddingLength = (int)(border - expectedSkip); // 1
                                                                                                  
                                                                                                  // Act
                                                                                                  // Using reflection to access private method for testing
                                                                                                  Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                                  padMethod.setAccessible(true);
                                                                                                  padMethod.invoke(cpioOut, count, border);
                                                                                                  
                                                                                                  // Assert
                                                                                                  // Verify that write was called with the correct length
                                                                                                  byte[] expectedBytes = new byte[expectedPaddingLength];
                                                                                                  verify(mockOut).write(expectedBytes);
                                                                                                  
                                                                                                  // Additional verification that the full array was written
                                                                                                  verify(mockOut).write(expectedBytes, 0, expectedBytes.length);
                                                                                              }

    @Test
                                                                                         public void testPadWhenCountIsMultipleOfBorder() throws Exception {
                                                                                             // Arrange
                                                                                             long count = 100L;
                                                                                             int border = 100;
                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                             CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
                                                                                             
                                                                                             // Get the private pad method via reflection
                                                                                             Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                             padMethod.setAccessible(true);
                                                                                             
                                                                                             // Act - count is exactly divisible by border (skip = 0)
                                                                                             padMethod.invoke(cpioOut, count, border);
                                                                                             
                                                                                             // Assert - verify no bytes were written to the output stream
                                                                                             verify(mockOut, never()).write(any(byte[].class));
                                                                                             
                                                                                             // Additional test case where skip would be > 0 to ensure original functionality
                                                                                             count = 150L;
                                                                                             border = 100;
                                                                                             padMethod.invoke(cpioOut, count, border);
                                                                                             verify(mockOut).write(any(byte[].class));
                                                                                         }

    @Test
                                                                                public void testPadDetectsBorderSkipMutation() throws Exception {
                                                                                    // Setup
                                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                                    CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
                                                                                    
                                                                                    // Test case where count % border != 0 to trigger the padding logic
                                                                                    long count = 5;
                                                                                    int border = 8;
                                                                                    
                                                                                    // Calculate expected values
                                                                                    long skip = count % border;  // 5 % 8 = 5
                                                                                    int expectedBytes = (int) (border - skip);  // 8 - 5 = 3
                                                                                    int mutatedBytes = (int) (border + skip);  // 8 + 5 = 13
                                                                                    
                                                                                    // Use reflection to access private pad method
                                                                                    Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                                    padMethod.setAccessible(true);
                                                                                    padMethod.invoke(cpioOut, count, border);
                                                                                    
                                                                                    // Verify the correct number of bytes were written
                                                                                    // This will catch the mutant because:
                                                                                    // - Original: writes 3 bytes (correct)
                                                                                    // - Mutant: writes 13 bytes (incorrect)
                                                                                    verify(mockOut).write(any(byte[].class), eq(0), eq(expectedBytes));
                                                                                    
                                                                                    // Alternative verification without ArgumentCaptor
                                                                                    // We can trust the previous verification that checks the length parameter
                                                                                    // and add a separate verification that write was called with a non-null array
                                                                                    verify(mockOut).write(isNotNull(byte[].class), eq(0), eq(expectedBytes));
                                                                                }

    @Test
                                                                           public void testWriteAsciiLongRadix() throws Exception {
                                                                               // Setup
                                                                               ByteArrayOutputStream mockOut = new ByteArrayOutputStream();
                                                                               CpioArchiveOutputStream cos = new CpioArchiveOutputStream(mockOut);
                                                                               long testNumber = 255L; // FF in hex
                                                                               
                                                                               // Get private method via reflection
                                                                               Method writeAsciiLong = CpioArchiveOutputStream.class.getDeclaredMethod(
                                                                                   "writeAsciiLong", long.class, int.class, int.class);
                                                                               writeAsciiLong.setAccessible(true);
                                                                               
                                                                               // Test radix=16 (should use special formatting)
                                                                               writeAsciiLong.invoke(cos, testNumber, 8, 16);
                                                                               byte[] hexOutput = mockOut.toByteArray();
                                                                               mockOut.reset();
                                                                               
                                                                               // Test radix=10 (should use default formatting)
                                                                               writeAsciiLong.invoke(cos, testNumber, 8, 10);
                                                                               byte[] decimalOutput = mockOut.toByteArray();
                                                                               
                                                                               // Verify outputs are different (would fail with mutant)
                                                                               assertFalse("Hex and decimal outputs should differ", 
                                                                                          java.util.Arrays.equals(hexOutput, decimalOutput));
                                                                               
                                                                               // Additional verification for hex format specifically
                                                                               String hexString = new String(hexOutput).trim();
                                                                               assertEquals("FF", hexString); // Expected hex representation
                                                                           }

    @Test
                                                                      public void testPad_NoPaddingNeeded() throws Exception {
                                                                          // Create mock OutputStream
                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                          
                                                                          // Create CpioArchiveOutputStream instance
                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                          
                                                                          // When count is exactly divisible by border (skip = 0)
                                                                          long count = 100;
                                                                          int border = 10;
                                                                          
                                                                          // Use reflection to access private pad method
                                                                          Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                          padMethod.setAccessible(true);
                                                                          padMethod.invoke(stream, count, border);
                                                                          
                                                                          // Verify no bytes were written
                                                                          verify(mockOut, never()).write(any(byte[].class));
                                                                      }

    @Test
                                                                      public void testPad_PaddingNeeded() throws Exception {
                                                                          // Create mock OutputStream
                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                          // Create CpioArchiveOutputStream with mock OutputStream
                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                          
                                                                          // When count is not divisible by border (skip > 0)
                                                                          long count = 103;
                                                                          int border = 10;
                                                                          
                                                                          // Use reflection to access private pad method
                                                                          Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                          padMethod.setAccessible(true);
                                                                          padMethod.invoke(stream, count, border);
                                                                          
                                                                          // Should write 7 bytes (10 - 3)
                                                                          verify(mockOut).write(new byte[7]);
                                                                      }

    @Test
                                                                      public void testPad_BorderLargerThanCount() throws Exception {
                                                                          // Create mock OutputStream
                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                          
                                                                          // Create CpioArchiveOutputStream instance
                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                          
                                                                          // Get private pad method via reflection
                                                                          Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                          padMethod.setAccessible(true);
                                                                          
                                                                          // When border is larger than count
                                                                          long count = 5;
                                                                          int border = 10;
                                                                          
                                                                          // Call the pad method
                                                                          padMethod.invoke(stream, count, border);
                                                                          
                                                                          // Should write 5 bytes (10 - 5)
                                                                          verify(mockOut).write(new byte[5]);
                                                                      }

    @Test
                                                                      public void testPad_CountZero() throws Exception {
                                                                          // When count is 0
                                                                          long count = 0;
                                                                          int border = 10;
                                                                          
                                                                          // Create mock output stream
                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                          
                                                                          // Create CpioArchiveOutputStream with mock
                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                          
                                                                          // Get private pad method via reflection
                                                                          Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                          padMethod.setAccessible(true);
                                                                          
                                                                          // Call pad method
                                                                          padMethod.invoke(stream, count, border);
                                                                          
                                                                          // Should write 10 bytes (10 - 0)
                                                                          verify(mockOut).write(new byte[10]);
                                                                      }

    @Test
                                                                      public void testPad_BorderOne() throws Exception {
                                                                          // Setup
                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                          
                                                                          // When border is 1 (smallest possible border)
                                                                          long count = 100;
                                                                          int border = 1;
                                                                          
                                                                          // Use reflection to access private pad method
                                                                          Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                                          padMethod.setAccessible(true);
                                                                          padMethod.invoke(stream, count, border);
                                                                          
                                                                          // Should write nothing since any count % 1 is 0
                                                                          verify(mockOut, never()).write(any(byte[].class));
                                                                      }

    @Test
                                                     public void testPadWhenLengthEqualsBorderMinusSkip() throws Exception {
                                                         // Setup
                                                         OutputStream mockOut = mock(OutputStream.class);
                                                         CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
                                                         
                                                         // Test case where (border - skip) equals the comparison length
                                                         long count = 10;
                                                         int border = 4;
                                                         
                                                         // skip = 10 % 4 = 2
                                                         // tmp.length = border - skip = 4 - 2 = 2
                                                         // The original would pass (2 <= 2), mutant would fail (2 < 2)
                                                         
                                                         // Use reflection to access private pad method
                                                         Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                         padMethod.setAccessible(true);
                                                         
                                                         // Act
                                                         padMethod.invoke(cpioOut, count, border);
                                                         
                                                         // Verify
                                                         // Should write an array of size 2
                                                         verify(mockOut).write(any(byte[].class));
                                                         verify(mockOut).write(argThat(new org.mockito.ArgumentMatcher<byte[]>() {
                                                             @Override
                                                             public boolean matches(Object argument) {
                                                                 return argument instanceof byte[] && ((byte[]) argument).length == 2;
                                                             }
                                                         }));
                                                         
                                                         // Additional verification that all bytes are zero
                                                         verify(mockOut).write(argThat(new org.mockito.ArgumentMatcher<byte[]>() {
                                                             @Override
                                                             public boolean matches(Object argument) {
                                                                 if (!(argument instanceof byte[])) return false;
                                                                 byte[] bytes = (byte[]) argument;
                                                                 for (byte b : bytes) {
                                                                     if (b != 0) return false;
                                                                 }
                                                                 return true;
                                                             }
                                                         }));
                                                     }

    @Test
                                                public void testPadWritesZeroBytes() throws Exception {
                                                    // Arrange
                                                    // Create a mock output stream that captures written bytes
                                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                    OutputStream mockOut = mock(OutputStream.class);
                                                    
                                                    // Use doAnswer to capture the written bytes
                                                    doAnswer(invocation -> {
                                                        byte[] bytes = (byte[]) invocation.getArguments()[0];
                                                        byteArrayOutputStream.write(bytes);
                                                        return null;
                                                    }).when(mockOut).write(any(byte[].class));
                                                    
                                                    // Create instance and inject mock output stream
                                                    CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
                                                    
                                                    // Values that will trigger padding (count % border != 0)
                                                    long count = 5;
                                                    int border = 3;
                                                    
                                                    // Expected padding size: border - (count % border) = 3 - (5%3) = 3-2 = 1
                                                    byte[] expectedPadding = new byte[1]; // Default byte array is all zeros
                                                    
                                                    // Act
                                                    // Use reflection to access private pad method
                                                    Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                                    padMethod.setAccessible(true);
                                                    padMethod.invoke(cpioOut, count, border);
                                                    
                                                    // Assert
                                                    byte[] actualPadding = byteArrayOutputStream.toByteArray();
                                                    assertArrayEquals("Padding bytes should be all zeros", expectedPadding, actualPadding);
                                                }

    @Test
                                                public void testPadWritesCorrectZeroBytes() throws Exception {
                                                    // Arrange
                                                    OutputStream mockOut = mock(OutputStream.class);
                                                    CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                                                    long count = 5;
                                                    int border = 8;
                                                    
                                                    // Expected padding size: 8 - (5 % 8) = 3 bytes
                                                    byte[] expectedPadding = new byte[3]; // All zeros by default
                                                    
                                                    // Act
                                                    // Using reflection to access private method for testing
                                                    java.lang.reflect.Method padMethod = CpioArchiveOutputStream.class
                                                        .getDeclaredMethod("pad", long.class, int.class);
                                                    padMethod.setAccessible(true);
                                                    padMethod.invoke(sut, count, border);
                                                    
                                                    // Assert
                                                    verify(mockOut).write(expectedPadding);
                                                    // This will catch the mutant because:
                                                    // Original: writes expectedPadding (byte array)
                                                    // Mutant: tries to write "expectedPadding1" (string concatenation)
                                                }

    @Test(expected = Exception.class)
                                                public void testPadWithMutationShouldFail() throws Exception {
                                                    // This test expects the mutant to fail when trying to add 1 to byte array
                                                    OutputStream mockOut = mock(OutputStream.class);
                                                    CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                                                    long count = 5;
                                                    int border = 8;
                                                    
                                                    // Force the mutant behavior by mocking the write method to throw exception
                                                    // when given something other than a pure byte array
                                                    doThrow(new IllegalArgumentException())
                                                        .when(mockOut).write(any()); // Any non-byte array input
                                                    
                                                    java.lang.reflect.Method padMethod = CpioArchiveOutputStream.class
                                                        .getDeclaredMethod("pad", long.class, int.class);
                                                    padMethod.setAccessible(true);
                                                    padMethod.invoke(sut, count, border);
                                                }

    @Test
                                           public void testPadWhenCountIsMultipleOfBorderShouldNotWrite() throws Exception {
                                               // Arrange
                                               long count = 100L;
                                               int border = 10;
                                               OutputStream mockOut = mock(OutputStream.class);
                                               CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                                               
                                               // Act - count is exactly divisible by border (100 % 10 = 0)
                                               // Using reflection to access private method
                                               Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                               padMethod.setAccessible(true);
                                               padMethod.invoke(sut, count, border);
                                               
                                               // Assert - verify no write operation occurred
                                               verify(mockOut, never()).write(any(byte[].class));
                                               
                                               // Clean up
                                               padMethod.setAccessible(false);
                                           }

    @Test
                                         public void testPadWithExactBorderShouldNotWrite() throws Exception {
                                             // Setup
                                             OutputStream mockOut = mock(OutputStream.class);
                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                             
                                             // Test values where count % border == 0
                                             long count = 8;
                                             int border = 8;
                                             
                                             // Use reflection to access private pad method
                                             Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                             padMethod.setAccessible(true);
                                             padMethod.invoke(stream, count, border);
                                             
                                             // Verify no bytes were written
                                             verify(mockOut, never()).write(any(byte[].class));
                                         }

    @Test
                                 public void testPadShouldWriteCorrectNumberOfBytes() throws Exception {
                                     // Setup
                                     OutputStream mockOut = mock(OutputStream.class);
                                     CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                     
                                     // Test values where count % border > 0
                                     long count = 5;
                                     int border = 8;
                                     long expectedSkip = count % border; // 5
                                     int expectedBytesToWrite = (int)(border - expectedSkip); // 3
                                     
                                     // Use reflection to access private pad method
                                     Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                                     padMethod.setAccessible(true);
                                     
                                     // Call the method via reflection
                                     padMethod.invoke(stream, count, border);
                                     
                                     // Verify the correct number of bytes were written
                                     verify(mockOut).write(eq(new byte[expectedBytesToWrite]), eq(0), eq(expectedBytesToWrite));
                                     
                                     // The mutant would create an array of size border + skip (8+5=13)
                                     // which would fail this verification
                                 }

    @Test
                            public void testWriteAsciiLongPaddingBehavior() throws Exception {
                                // Create mock output stream
                                OutputStream mockOut = mock(OutputStream.class);
                                OutputStream spyOut = spy(mockOut);
                                
                                // Create CpioArchiveOutputStream instance
                                CpioArchiveOutputStream cos = new CpioArchiveOutputStream(spyOut);
                                
                                // Create a dummy entry
                                CpioArchiveEntry entry = new CpioArchiveEntry("test");
                                cos.putNextEntry(entry);
                                
                                // Verify that padding was attempted for radix 16
                                verify(spyOut, atLeastOnce()).write(any(byte[].class));
                                
                                // Test with radix 10 (decimal) - should NOT trigger padding
                                reset(spyOut);
                                // Setup new test with different radix
                                // Need to find a way to exercise writeAsciiLong with radix 10
                                // This might require creating a specific test entry
                                
                                // Verify no padding was written for radix 10
                                verify(spyOut, never()).write(any(byte[].class));
                            }

    @Test
                       public void testPadWhenCountExactlyDivisibleByBorder() throws Exception {
                           // Arrange
                           OutputStream mockOut = mock(OutputStream.class);
                           CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                           long count = 100L;
                           int border = 10;
                           
                           // Get the private pad method via reflection
                           Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                           padMethod.setAccessible(true);
                           
                           // Act - count is exactly divisible by border (100 % 10 = 0)
                           padMethod.invoke(sut, count, border);
                           
                           // Assert - verify no bytes were written
                           verify(mockOut, never()).write(any(byte[].class));
                       }

    @Test
                       public void testPadWhenCountNotDivisibleByBorder() throws Exception {
                           // Arrange
                           OutputStream mockOut = mock(OutputStream.class);
                           CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                           long count = 105L;
                           int border = 10;
                           
                           // Get the private pad method via reflection
                           Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                           padMethod.setAccessible(true);
                           
                           // Act - count not divisible by border (105 % 10 = 5)
                           padMethod.invoke(sut, count, border);
                           
                           // Assert - verify padding bytes were written
                           verify(mockOut).write(any(byte[].class));
                       }

    @Test
                       public void testPadWithZeroCount() throws Exception {
                           // Arrange
                           OutputStream mockOut = mock(OutputStream.class);
                           CpioArchiveOutputStream sut = new CpioArchiveOutputStream(mockOut);
                           long count = 0L;
                           int border = 10;
                           
                           // Get the private pad method via reflection
                           Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                           padMethod.setAccessible(true);
                           
                           // Act - count is 0 (0 % 10 = 0)
                           padMethod.invoke(sut, count, border);
                           
                           // Assert - verify no bytes were written
                           verify(mockOut, never()).write(any(byte[].class));
                       }

    @Test
                  public void testPadWhenBorderMinusSkipEqualsLength() throws Exception {
                      // Create mock OutputStream
                      OutputStream mockOut = mock(OutputStream.class);
                      
                      // Create CpioArchiveOutputStream instance with mocked OutputStream
                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                      
                      // Setup: count % border = 1, border - skip = 10 (tmp.length = 10)
                      // We want to test when tmp.length exactly equals some boundary length (10)
                      long count = 21;  // 21 % 10 = 1
                      int border = 10;  // border - skip = 9 (but we need to adjust for test)
                      
                      // The test needs to be adjusted to hit the boundary condition
                      // Let's modify border to make border - skip = 10
                      count = 31;  // 31 % 11 = 9 (since 11*2=22, 31-22=9)
                      border = 11; // border - skip = 11 - 9 = 2 (not working)
                      
                      // Better approach: directly test the boundary case where tmp.length equals some length
                      // Since we can't see the length parameter in the original code, we'll assume it's 
                      // checking against border - skip
                      
                      // Test case where tmp.length would equal border - skip
                      count = 11; // 11 % 10 = 1
                      border = 10; // border - skip = 9
                      
                      // Use reflection to access private pad method
                      Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                      padMethod.setAccessible(true);
                      padMethod.invoke(stream, count, border);
                      
                      // Verify the padding was written (would fail for mutant)
                      verify(mockOut).write(any(byte[].class));
                  }

    @Test
              public void testPadWhenSkipIsBorderMinusOne() throws Exception {
                  // Create mock output stream
                  OutputStream mockOut = mock(OutputStream.class);
                  
                  // Create CpioArchiveOutputStream with mock
                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                  
                  // This creates a case where tmp.length = 1 (border - skip = 10 - 9 = 1)
                  long count = 9;  // 9 % 10 = 9
                  int border = 10; // border - skip = 1
                  
                  // Use reflection to access private pad method
                  Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
                  padMethod.setAccessible(true);
                  padMethod.invoke(stream, count, border);
                  
                  // Verify padding of size 1 was written
                  verify(mockOut).write(any(byte[].class), eq(0), eq(1));
                  
                  // This would catch the mutant because:
                  // Original: if (1 <= length) would execute
                  // Mutant: if (1 < length) might not execute if length == 1
              }

    @Test
         public void testPadWritesCorrectNumberOfBytes() throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
             // Setup
             OutputStream mockOut = mock(OutputStream.class);
             CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
             
             // Test case where count % border = 2 (so padding needed is border - 2)
             long count = 10;
             int border = 4;
             long expectedPaddingSize = border - (count % border); // 4 - 2 = 2
             
             // Call the method (using reflection since pad is private)
             Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
             padMethod.setAccessible(true);
             padMethod.invoke(cpioOut, count, border);
             
             // Verify exactly expectedPaddingSize bytes were written
             verify(mockOut).write(any(byte[].class), eq(0), eq((int)expectedPaddingSize));
             
             // This will catch the mutant because:
             // Original: writes full array (2 bytes)
             // Mutant: writes array.length-1 (1 byte)
             // Test expects exactly 2 bytes
         }

    @Test
    public void testPadWritesCorrectByteArray() throws Exception {
        // Setup
        OutputStream mockOut = mock(OutputStream.class);
        CpioArchiveOutputStream cpioOut = new CpioArchiveOutputStream(mockOut);
        
        // Test data - border=10, count=13 (so skip=3, should write 7 bytes)
        long count = 13;
        int border = 10;
        byte[] expectedBytes = new byte[7]; // border - skip = 10 - 3 = 7
        
        // Use reflection to access private pad method
        Method padMethod = CpioArchiveOutputStream.class.getDeclaredMethod("pad", long.class, int.class);
        padMethod.setAccessible(true);
        
        // Call method
        padMethod.invoke(cpioOut, count, border);
        
        // Verify
        verify(mockOut).write(expectedBytes); // Verify exact array was written
        
        // Additional verification that no other writes occurred
        verifyNoMoreInteractions(mockOut);
    }


}
