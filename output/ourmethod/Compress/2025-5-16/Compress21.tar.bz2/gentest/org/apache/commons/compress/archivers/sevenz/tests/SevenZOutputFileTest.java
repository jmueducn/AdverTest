package gentest.org.apache.commons.compress.archivers.sevenz.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.sevenz.*;
import java.io.ByteArrayOutputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Date;
import java.util.List;
import java.util.zip.CRC32;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class SevenZOutputFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_EmptyBitSet() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create mock DataOutput
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Create BitSet with no bits set
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet();
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Create SevenZOutputFile instance (using temporary file)
                                                                                                                                                                                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                                                                 tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Use reflection to access private writeBits method
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Test the method
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 0);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify no write operations were performed
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput, never()).write(anyInt());
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_SingleByteComplete() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create mock DataOutput
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Initialize SevenZOutputFile (using a temporary file)
                                                                                                                                                                                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Configure BitSet with test values (10100000)
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet(8);
                                                                                                                                                                                                                                                                                                                                 bits.set(0); // MSB (bit 7 in byte)
                                                                                                                                                                                                                                                                                                                                 bits.set(2); // bit 5 in byte
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Get the private writeBits method using reflection
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Test the method
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 8);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify the expected byte was written (10100000 in binary = 0xA0 in hex)
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b10100000);
                                                                                                                                                                                                                                                                                                                                 verifyNoMoreInteractions(mockDataOutput);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 tempFile.delete();
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_MultipleCompleteBytes() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Set up test data
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet(16);
                                                                                                                                                                                                                                                                                                                                 // First byte: 10101010
                                                                                                                                                                                                                                                                                                                                 bits.set(0);
                                                                                                                                                                                                                                                                                                                                 bits.set(2);
                                                                                                                                                                                                                                                                                                                                 bits.set(4);
                                                                                                                                                                                                                                                                                                                                 bits.set(6);
                                                                                                                                                                                                                                                                                                                                 // Second byte: 11001100
                                                                                                                                                                                                                                                                                                                                 bits.set(8);
                                                                                                                                                                                                                                                                                                                                 bits.set(9);
                                                                                                                                                                                                                                                                                                                                 bits.set(12);
                                                                                                                                                                                                                                                                                                                                 bits.set(13);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Use reflection to access private method
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 16);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify results
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b10101010);
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b11001100);
                                                                                                                                                                                                                                                                                                                                 verifyNoMoreInteractions(mockDataOutput);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_PartialByteAtEnd() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet(10);
                                                                                                                                                                                                                                                                                                                                 // First byte: 10101010
                                                                                                                                                                                                                                                                                                                                 bits.set(0);
                                                                                                                                                                                                                                                                                                                                 bits.set(2);
                                                                                                                                                                                                                                                                                                                                 bits.set(4);
                                                                                                                                                                                                                                                                                                                                 bits.set(6);
                                                                                                                                                                                                                                                                                                                                 // Remaining 2 bits: 10
                                                                                                                                                                                                                                                                                                                                 bits.set(8);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Get the private method using reflection
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Call method under test
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 10);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify interactions
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b10101010);
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b10000000); // Only first bit set, shifted left by 6
                                                                                                                                                                                                                                                                                                                                 verifyNoMoreInteractions(mockDataOutput);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_AllBitsSet() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Set up test data
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet(24);
                                                                                                                                                                                                                                                                                                                                 bits.set(0, 24); // Set all 24 bits
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Use reflection to access private method
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Call method under test
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 24);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify results
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b11111111);
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b11111111);
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b11111111);
                                                                                                                                                                                                                                                                                                                                 verifyNoMoreInteractions(mockDataOutput);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_AllBitsUnset() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Setup test objects
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet(16);
                                                                                                                                                                                                                                                                                                                                 // All bits remain false
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Get the private method using reflection
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Call method under test
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 16);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify behavior
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b00000000);
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b00000000);
                                                                                                                                                                                                                                                                                                                                 verifyNoMoreInteractions(mockDataOutput);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Cleanup
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_IOExceptionFromDataOutput() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                                                                 BitSet bits = new BitSet(8);
                                                                                                                                                                                                                                                                                                                                 bits.set(0, 8);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Mock behavior
                                                                                                                                                                                                                                                                                                                                 doThrow(new IOException("Test exception")).when(mockDataOutput).write(anyInt());
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Expected exception
                                                                                                                                                                                                                                                                                                                                 ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                                                                                 expectedException.expect(IOException.class);
                                                                                                                                                                                                                                                                                                                                 expectedException.expectMessage("Test exception");
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Get private method via reflection
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                                                                     writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 8);
                                                                                                                                                                                                                                                                                                                                 } finally {
                                                                                                                                                                                                                                                                                                                                     // Cleanup
                                                                                                                                                                                                                                                                                                                                     sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                     new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_NullBitSet() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Setup test rule for expected exception
                                                                                                                                                                                                                                                                                                                                 ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                                                                                 expectedException.expect(NullPointerException.class);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                                 DataOutput mockDataOutput = new DataOutputStream(new ByteArrayOutputStream());
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Get the private writeBits method using reflection
                                                                                                                                                                                                                                                                                                                                 Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                     "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Execute test
                                                                                                                                                                                                                                                                                                                                 writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, null, 8);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                             }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                                                                             public void testWriteBits_NegativeLength() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create temporary file for SevenZOutputFile
                                                                                                                                                                                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                                                                 tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                                                                     DataOutput mockDataOutput = new DataOutputStream(new ByteArrayOutputStream());
                                                                                                                                                                                                                                                                                                                                     BitSet bits = new BitSet();
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     // Use reflection to access private method
                                                                                                                                                                                                                                                                                                                                     Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                         "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                     writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     // Invoke the method with negative length
                                                                                                                                                                                                                                                                                                                                     writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, -1);
                                                                                                                                                                                                                                                                                                                                 } finally {
                                                                                                                                                                                                                                                                                                                                     sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                         public void testWriteBits_LengthLargerThanBitSet() throws IOException {
                                                                                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                                                                                             DataOutput mockDataOutput = mock(DataOutput.class);
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             // Create test BitSet with 8 bits set
                                                                                                                                                                                                                                                                                                                             BitSet bits = new BitSet(8);
                                                                                                                                                                                                                                                                                                                             bits.set(0, 8); // Set first 8 bits
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             // Create SevenZOutputFile instance (we'll use reflection to test private method)
                                                                                                                                                                                                                                                                                                                             SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                                                                     // Get private writeBits method
                                                                                                                                                                                                                                                                                                                                     Method writeBitsMethod = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                         "writeBits", DataOutput.class, BitSet.class, int.class);
                                                                                                                                                                                                                                                                                                                                     writeBitsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     // Invoke the method
                                                                                                                                                                                                                                                                                                                                     writeBitsMethod.invoke(sevenZOutputFile, mockDataOutput, bits, 16);
                                                                                                                                                                                                                                                                                                                                 } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                                                     fail("Failed to access or invoke private writeBits method: " + e.getMessage());
                                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify the writes
                                                                                                                                                                                                                                                                                                                                 // First 8 bits (all set)
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b11111111);
                                                                                                                                                                                                                                                                                                                                 // Next 8 bits (all unset)
                                                                                                                                                                                                                                                                                                                                 verify(mockDataOutput).write(0b00000000);
                                                                                                                                                                                                                                                                                                                                 verifyNoMoreInteractions(mockDataOutput);
                                                                                                                                                                                                                                                                                                                             } finally {
                                                                                                                                                                                                                                                                                                                                 // Clean up
                                                                                                                                                                                                                                                                                                                                 sevenZOutputFile.close();
                                                                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                public void testGetCurrentOutputStream_doesNotReinitializeWhenNotNull() throws Exception {
                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                    SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(mock(File.class));
                                                                                                                                                                                                                                                                                                                    CountingOutputStream existingStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Set currentOutputStream to non-null via reflection
                                                                                                                                                                                                                                                                                                                    Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                                                    currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                    currentOutputStreamField.set(sevenZOutputFile, existingStream);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Get the getCurrentOutputStream method via reflection
                                                                                                                                                                                                                                                                                                                    Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                                                                                                                    getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Test
                                                                                                                                                                                                                                                                                                                    OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                                                                                    assertSame(existingStream, result);
                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                            public void testGetCurrentOutputStream_initializesWhenNull() throws Exception {
                                                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                                                SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(mock(File.class));
                                                                                                                                                                                                                                                                                                                CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Set currentOutputStream to null via reflection since it's private
                                                                                                                                                                                                                                                                                                                Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                                                currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                currentOutputStreamField.set(sevenZOutputFile, null);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Set the mock stream directly through reflection
                                                                                                                                                                                                                                                                                                                Field setupFileOutputStreamField = SevenZOutputFile.class.getDeclaredField("setupFileOutputStream");
                                                                                                                                                                                                                                                                                                                setupFileOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                setupFileOutputStreamField.set(sevenZOutputFile, mockStream);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Get the private getCurrentOutputStream method
                                                                                                                                                                                                                                                                                                                Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                                                                                                                getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Test
                                                                                                                                                                                                                                                                                                                OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                                                                assertSame(mockStream, result);
                                                                                                                                                                                                                                                                                                                assertSame(mockStream, currentOutputStreamField.get(sevenZOutputFile));
                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                       public void testGetCurrentOutputStreamInitializesWhenNull() throws Exception {
                                                                                                                                                                                                                                                                                                           // Create a real SevenZOutputFile object with a temporary file
                                                                                                                                                                                                                                                                                                           File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                                           tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                                                           SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                           // Use reflection to set currentOutputStream to null since it's private
                                                                                                                                                                                                                                                                                                           Field outputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                                           outputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                                           outputStreamField.set(sevenZOutput, null);
                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                           // Use reflection to get and call the private method
                                                                                                                                                                                                                                                                                                           Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                                                                                                           getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                           OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutput);
                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                           // Verify the stream was initialized (not null)
                                                                                                                                                                                                                                                                                                           assertNotNull("getCurrentOutputStream should initialize and return a non-null stream when current is null", result);
                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                           // Clean up
                                                                                                                                                                                                                                                                                                           sevenZOutput.close();
                                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                                  public void testGetCurrentOutputStreamDetectsNullMutant() throws Exception {
                                                                                                                                                                                                                                                                                                      // Create a temporary file for testing
                                                                                                                                                                                                                                                                                                      File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                                      tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      // Create instance with the temp file
                                                                                                                                                                                                                                                                                                      SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                                                          // Use reflection to access private field for verification
                                                                                                                                                                                                                                                                                                          Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                                          currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Verify initial state is null
                                                                                                                                                                                                                                                                                                          assertNull(currentOutputStreamField.get(sevenZOutput));
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Get the private method using reflection
                                                                                                                                                                                                                                                                                                          Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                                                                                                          getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // First call - should initialize the stream
                                                                                                                                                                                                                                                                                                          OutputStream firstStream = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutput);
                                                                                                                                                                                                                                                                                                          assertNotNull("Stream should not be null", firstStream);
                                                                                                                                                                                                                                                                                                          assertTrue("Should return CountingOutputStream", 
                                                                                                                                                                                                                                                                                                                    firstStream instanceof CountingOutputStream);
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Verify field was set
                                                                                                                                                                                                                                                                                                          assertNotNull(currentOutputStreamField.get(sevenZOutput));
                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                          // Subsequent call should return same instance
                                                                                                                                                                                                                                                                                                          OutputStream secondStream = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutput);
                                                                                                                                                                                                                                                                                                          assertSame("Should return same stream instance", firstStream, secondStream);
                                                                                                                                                                                                                                                                                                      } finally {
                                                                                                                                                                                                                                                                                                          // Clean up
                                                                                                                                                                                                                                                                                                          sevenZOutput.close();
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                             public void testWriteIntCallsSuperWrite() throws Exception {
                                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Create a spy to verify super.write() calls
                                                                                                                                                                                                                                                                                                 SevenZOutputFile spyOutput = spy(sevenZOutput);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Mock the CountingOutputStream
                                                                                                                                                                                                                                                                                                 CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Use reflection to set the private currentOutputStream field directly
                                                                                                                                                                                                                                                                                                 Field field = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                                 field.setAccessible(true);
                                                                                                                                                                                                                                                                                                 field.set(spyOutput, mockStream);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Test data
                                                                                                                                                                                                                                                                                                 int testByte = 42;
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Execute
                                                                                                                                                                                                                                                                                                 spyOutput.write(testByte);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                                 // This would fail if super.write() is commented out (mutated)
                                                                                                                                                                                                                                                                                                 verify(mockStream).write(testByte);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Cleanup
                                                                                                                                                                                                                                                                                                 spyOutput.close();
                                                                                                                                                                                                                                                                                                 tempFile.delete();
                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                        public void testWriteUpdatesCrc() throws Exception {
                                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                                            File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                            SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Get crc32 field via reflection
                                                                                                                                                                                                                                                                                            Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                                                                                                                                                                                                            crc32Field.setAccessible(true);
                                                                                                                                                                                                                                                                                            CRC32 crc32 = (CRC32) crc32Field.get(sevenZOutput);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Test data
                                                                                                                                                                                                                                                                                            byte[] testData = "test data".getBytes();
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Get initial CRC32 value
                                                                                                                                                                                                                                                                                            long initialCrc = crc32.getValue();
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Action - write data
                                                                                                                                                                                                                                                                                            sevenZOutput.write(testData);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Verification
                                                                                                                                                                                                                                                                                            // Calculate expected CRC32
                                                                                                                                                                                                                                                                                            CRC32 expectedCrc = new CRC32();
                                                                                                                                                                                                                                                                                            expectedCrc.update(testData);
                                                                                                                                                                                                                                                                                            long expectedValue = expectedCrc.getValue();
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Get updated CRC32 value via reflection
                                                                                                                                                                                                                                                                                            long actualCrc = crc32.getValue();
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // If the mutation is present (crc32.update commented out), 
                                                                                                                                                                                                                                                                                            // the actual CRC will still be the initial value (0)
                                                                                                                                                                                                                                                                                            assertNotEquals("CRC32 should have been updated", initialCrc, actualCrc);
                                                                                                                                                                                                                                                                                            assertEquals("CRC32 value mismatch", expectedValue, actualCrc);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Cleanup
                                                                                                                                                                                                                                                                                            sevenZOutput.close();
                                                                                                                                                                                                                                                                                            tempFile.delete();
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                    public void testWriteByteArrayCallsCorrectOverload() throws Exception {
                                                                                                                                                                                                                                                                                        // Create a test file
                                                                                                                                                                                                                                                                                        File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                        tempFile.deleteOnExit();
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Create a spy of SevenZOutputFile to monitor method calls
                                                                                                                                                                                                                                                                                        SevenZOutputFile outputFile = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                        SevenZOutputFile spyOutputFile = spy(outputFile);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Prepare test data
                                                                                                                                                                                                                                                                                        byte[] testData = "test data".getBytes();
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Call the write method
                                                                                                                                                                                                                                                                                        spyOutputFile.write(testData);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify the correct write method was called
                                                                                                                                                                                                                                                                                        verify(spyOutputFile).write(eq(testData));
                                                                                                                                                                                                                                                                                        verify(spyOutputFile, never()).write(eq(testData), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Additional verification that the data was actually written
                                                                                                                                                                                                                                                                                        spyOutputFile.close();
                                                                                                                                                                                                                                                                                        assertTrue(tempFile.length() > 0);
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                  public void testWriteUpdatesCrc32Correctly() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                                      SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Test data - we'll use partial array writes
                                                                                                                                                                                                                                                                                      byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                      byte[] partialData = new byte[10];
                                                                                                                                                                                                                                                                                      System.arraycopy(testData, 0, partialData, 2, testData.length); // [0,0,1,2,3,4,5,0,0,0]
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Action - write using different write methods
                                                                                                                                                                                                                                                                                      sevenZOutput.write(testData); // writes entire array
                                                                                                                                                                                                                                                                                      sevenZOutput.write(partialData, 2, testData.length); // writes same data but as partial array
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify CRC32 was updated correctly
                                                                                                                                                                                                                                                                                      // Original would have same checksum for both writes
                                                                                                                                                                                                                                                                                      // Mutant would have different checksum for partial write
                                                                                                                                                                                                                                                                                      long expectedChecksum = 0; // Calculate expected checksum value
                                                                                                                                                                                                                                                                                      CRC32 calc = new CRC32();
                                                                                                                                                                                                                                                                                      calc.update(testData);
                                                                                                                                                                                                                                                                                      calc.update(testData); // same data written twice
                                                                                                                                                                                                                                                                                      expectedChecksum = calc.getValue();
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to access private crc32 field
                                                                                                                                                                                                                                                                                      Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                                                                                                                                                                                                      crc32Field.setAccessible(true);
                                                                                                                                                                                                                                                                                      CRC32 actualCrc32 = (CRC32) crc32Field.get(sevenZOutput);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertEquals("CRC32 checksum should match expected value", 
                                                                                                                                                                                                                                                                                                  expectedChecksum, actualCrc32.getValue());
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Cleanup
                                                                                                                                                                                                                                                                                      sevenZOutput.close();
                                                                                                                                                                                                                                                                                      tempFile.delete();
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                             public void testWriteWithOffsetShouldOnlyWriteFromSpecifiedOffset() throws Exception {
                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                 SevenZOutputFile outputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                 byte[] data = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                 int offset = 2;
                                                                                                                                                                                                                                                                                 int length = 2;
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Mock the CountingOutputStream to verify write operations
                                                                                                                                                                                                                                                                                 CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Use reflection to set the private currentOutputStream field
                                                                                                                                                                                                                                                                                 Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                 currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                 currentOutputStreamField.set(outputFile, mockStream);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                                                 outputFile.write(data, offset, length);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                 // Should call write with the exact offset and length parameters
                                                                                                                                                                                                                                                                                 verify(mockStream).write(data, offset, length);
                                                                                                                                                                                                                                                                                 // Should NOT call write with offset 0
                                                                                                                                                                                                                                                                                 verify(mockStream, never()).write(data, 0, length);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Cleanup
                                                                                                                                                                                                                                                                                 outputFile.close();
                                                                                                                                                                                                                                                                                 // Delete the test file
                                                                                                                                                                                                                                                                                 new File("test.7z").delete();
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                             public void testWriteWithOffsetShouldNotWriteFromZero() throws Exception {
                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                 SevenZOutputFile outputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                                 byte[] data = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                 byte[] expectedData = new byte[]{3, 4}; // expected portion
                                                                                                                                                                                                                                                                                 int offset = 2;
                                                                                                                                                                                                                                                                                 int length = 2;
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Use a real output stream to capture the written data
                                                                                                                                                                                                                                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                 CountingOutputStream cos = new CountingOutputStream(baos);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Use reflection to set private field
                                                                                                                                                                                                                                                                                 Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                                                 currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                                                 currentOutputStreamField.set(outputFile, cos);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                     // Test
                                                                                                                                                                                                                                                                                     outputFile.write(data, offset, length);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     byte[] writtenData = baos.toByteArray();
                                                                                                                                                                                                                                                                                     assertArrayEquals(expectedData, writtenData);
                                                                                                                                                                                                                                                                                     assertEquals(length, cos.getBytesWritten());
                                                                                                                                                                                                                                                                                 } finally {
                                                                                                                                                                                                                                                                                     // Cleanup
                                                                                                                                                                                                                                                                                     outputFile.close();
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                        public void testWriteWithOffsetUpdatesCrc32Correctly() throws Exception {
                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                            SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                            byte[] testData = new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                                                                                                                                                                                                                                                            int offset = 3;
                                                                                                                                                                                                                                                                            int length = 4;
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Expected CRC32 when using correct offset (should be for bytes 4,5,6,7)
                                                                                                                                                                                                                                                                            CRC32 expectedCrc = new CRC32();
                                                                                                                                                                                                                                                                            expectedCrc.update(testData, offset, length);
                                                                                                                                                                                                                                                                            long expectedChecksum = expectedCrc.getValue();
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Mutant CRC32 (would use bytes 1,2,3,4 instead)
                                                                                                                                                                                                                                                                            CRC32 mutantCrc = new CRC32();
                                                                                                                                                                                                                                                                            mutantCrc.update(testData, 0, length);
                                                                                                                                                                                                                                                                            long mutantChecksum = mutantCrc.getValue();
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Action - write with offset
                                                                                                                                                                                                                                                                            sevenZOutput.write(testData, offset, length);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Verification
                                                                                                                                                                                                                                                                            // Get the actual CRC32 from the class using reflection (should use correct offset)
                                                                                                                                                                                                                                                                            Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                                                                                                                                                                                            crc32Field.setAccessible(true);
                                                                                                                                                                                                                                                                            CRC32 actualCrc = (CRC32) crc32Field.get(sevenZOutput);
                                                                                                                                                                                                                                                                            long actualChecksum = actualCrc.getValue();
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Verify against expected (this will fail for the mutant)
                                                                                                                                                                                                                                                                            assertEquals("CRC32 checksum should be calculated from correct offset", 
                                                                                                                                                                                                                                                                                        expectedChecksum, actualChecksum);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Also verify it's different from what mutant would produce
                                                                                                                                                                                                                                                                            assertNotEquals("CRC32 checksum should not match mutant calculation", 
                                                                                                                                                                                                                                                                                           mutantChecksum, actualChecksum);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Cleanup
                                                                                                                                                                                                                                                                            sevenZOutput.close();
                                                                                                                                                                                                                                                                            new File("test.7z").delete();
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                    public void testOutputFileContainsHeaderSignature() throws Exception {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        File testFile = new File("test.7z");
                                                                                                                                                                                                                                                                        testFile.delete(); // Clean up if exists
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Create a valid 7z file
                                                                                                                                                                                                                                                                        SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(testFile);
                                                                                                                                                                                                                                                                        sevenZOutputFile.finish();
                                                                                                                                                                                                                                                                        sevenZOutputFile.close();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify file contains header signature
                                                                                                                                                                                                                                                                        RandomAccessFile raf = new RandomAccessFile(testFile, "r");
                                                                                                                                                                                                                                                                        byte[] signature = new byte[6];
                                                                                                                                                                                                                                                                        raf.read(signature);
                                                                                                                                                                                                                                                                        raf.close();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // 7z signature is '7z' followed by 0xBC, 0xAF, 0x27, 0x1C
                                                                                                                                                                                                                                                                        byte[] expectedSignature = new byte[]{'7', 'z', (byte)0xBC, (byte)0xAF, 0x27, 0x1C};
                                                                                                                                                                                                                                                                        assertArrayEquals("File header signature doesn't match", expectedSignature, signature);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Clean up
                                                                                                                                                                                                                                                                        testFile.delete();
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                   public void testWriteHeaderWritesHeaderIdentifier() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                                                       DataOutput mockedHeader = mock(DataOutput.class);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to access private method since it's not exposed
                                                                                                                                                                                                                                                                       Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                                                                                                                                                                                                       writeHeaderMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Action
                                                                                                                                                                                                                                                                       writeHeaderMethod.invoke(sevenZOutputFile, mockedHeader);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verification
                                                                                                                                                                                                                                                                       // 0x0A is the byte value for header identifier in 7z format
                                                                                                                                                                                                                                                                       verify(mockedHeader).write((byte)0x0A);
                                                                                                                                                                                                                                                                       // Verify other header writes if needed
                                                                                                                                                                                                                                                                       verify(mockedHeader, atLeastOnce()).write(any(byte[].class));
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                              public void testHeaderContainsMainStreamsInfo() throws Exception {
                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                  File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                                  SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Write some data to create streams
                                                                                                                                                                                                                                                                  SevenZArchiveEntry entry = sevenZOutput.createArchiveEntry(tempFile, "testEntry");
                                                                                                                                                                                                                                                                  sevenZOutput.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                  sevenZOutput.write(new byte[]{1, 2, 3});
                                                                                                                                                                                                                                                                  sevenZOutput.closeArchiveEntry();
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Close to trigger header writing
                                                                                                                                                                                                                                                                  sevenZOutput.close();
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify header contents
                                                                                                                                                                                                                                                                  RandomAccessFile raf = new RandomAccessFile(tempFile, "r");
                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                      // Seek to header position (after signature)
                                                                                                                                                                                                                                                                      // 7z signature is 32 bytes (6 bytes for signature + 2 bytes for version + 24 bytes for start header CRC)
                                                                                                                                                                                                                                                                      raf.seek(32);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Read header bytes
                                                                                                                                                                                                                                                                      byte[] headerBytes = new byte[32]; // Enough to contain the NID we're looking for
                                                                                                                                                                                                                                                                      raf.read(headerBytes);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify kMainStreamsInfo (0x08) exists in header
                                                                                                                                                                                                                                                                      boolean found = false;
                                                                                                                                                                                                                                                                      for (byte b : headerBytes) {
                                                                                                                                                                                                                                                                          if (b == 0x08) { // NID.kMainStreamsInfo value
                                                                                                                                                                                                                                                                              found = true;
                                                                                                                                                                                                                                                                              break;
                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                      assertTrue("Header should contain kMainStreamsInfo NID", found);
                                                                                                                                                                                                                                                                  } finally {
                                                                                                                                                                                                                                                                      raf.close();
                                                                                                                                                                                                                                                                      tempFile.delete();
                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                             public void testGetCurrentOutputStreamCallsWriteStreamsInfo() throws Exception {
                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                                 SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Mock the header to verify writeStreamsInfo is called
                                                                                                                                                                                                                                                 DataOutput mockHeader = mock(DataOutput.class);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Use reflection to access private currentOutputStream and set it to null
                                                                                                                                                                                                                                                 Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                                 currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                                 currentOutputStreamField.set(sevenZOutput, null);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Get the writeStreamsInfo method
                                                                                                                                                                                                                                                 Method writeStreamsInfoMethod = SevenZOutputFile.class.getDeclaredMethod("writeStreamsInfo", DataOutput.class);
                                                                                                                                                                                                                                                 writeStreamsInfoMethod.setAccessible(true);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Create a spy to track method calls
                                                                                                                                                                                                                                                 SevenZOutputFile spyOutput = spy(sevenZOutput);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Get the getCurrentOutputStream method
                                                                                                                                                                                                                                                 Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                                                 getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                 getCurrentOutputStreamMethod.invoke(spyOutput);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify that currentOutputStream is no longer null (indirect verification that setupFileOutputStream was called)
                                                                                                                                                                                                                                                 assertNotNull(currentOutputStreamField.get(spyOutput));
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Cleanup
                                                                                                                                                                                                                                                 tempFile.delete();
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                         public void testWriteFilesInfoIsCalledWhenRequired() throws Exception {
                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                             SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                                                                             DataOutput mockHeader = mock(DataOutput.class);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Use reflection to access private method since it's not directly callable
                                                                                                                                                                                                                                             Method writeFilesInfoMethod = SevenZOutputFile.class.getDeclaredMethod("writeFilesInfo", DataOutput.class);
                                                                                                                                                                                                                                             writeFilesInfoMethod.setAccessible(true);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Act - call the method that should trigger writeFilesInfo
                                                                                                                                                                                                                                             writeFilesInfoMethod.invoke(sevenZOutputFile, mockHeader);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Assert - verify writeFilesInfo actually wrote data to header
                                                                                                                                                                                                                                             // We can verify any expected interaction with the mock header
                                                                                                                                                                                                                                             // For example, verify at least one write method was called
                                                                                                                                                                                                                                             verify(mockHeader, atLeastOnce()).write(any(byte[].class));
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Alternatively, if we know specific expected calls:
                                                                                                                                                                                                                                             // verify(mockHeader).writeInt(anyInt());
                                                                                                                                                                                                                                             // verify(mockHeader).writeLong(anyLong());
                                                                                                                                                                                                                                             // etc.
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                   public void testGetCurrentOutputStreamReturnsExistingStream() throws Exception {
                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                       SevenZOutputFile sevenZFile = new SevenZOutputFile(mock(File.class));
                                                                                                                                                                                                                                       CountingOutputStream existingStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Set private field currentOutputStream using reflection
                                                                                                                                                                                                                                       Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                                       currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                                       currentOutputStreamField.set(sevenZFile, existingStream);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Test by calling private method getCurrentOutputStream using reflection
                                                                                                                                                                                                                                       Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                                       getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                       OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                       assertSame(existingStream, result);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Clean up
                                                                                                                                                                                                                                       currentOutputStreamField.setAccessible(false);
                                                                                                                                                                                                                                       getCurrentOutputStreamMethod.setAccessible(false);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                           public void testGetCurrentOutputStreamInitializesWhenNull1() throws Exception {
                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                               SevenZOutputFile sevenZFile = new SevenZOutputFile(mock(File.class));
                                                                                                                                                                                                                               CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create spy
                                                                                                                                                                                                                               SevenZOutputFile spy = spy(sevenZFile);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Use reflection to access and set private field
                                                                                                                                                                                                                               Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                               currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                               currentOutputStreamField.set(spy, null);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Instead of mocking private method, set up the field directly
                                                                                                                                                                                                                               Field setupFileOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                               setupFileOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                               setupFileOutputStreamField.set(spy, mockStream);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Call the private method using reflection
                                                                                                                                                                                                                               Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                               getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                               OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(spy);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                               assertSame(mockStream, result);
                                                                                                                                                                                                                               assertSame(mockStream, currentOutputStreamField.get(spy));
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                      public void testGetCurrentOutputStreamWithZeroNonEmptyStreams() throws Exception {
                                                                                                                                                                                                                          // Create a real SevenZOutputFile instance
                                                                                                                                                                                                                          File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                          SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              // Use reflection to access private field numNonEmptyStreams
                                                                                                                                                                                                                              Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                                                                                                                                                                                                              numNonEmptyStreamsField.setAccessible(true);
                                                                                                                                                                                                                              numNonEmptyStreamsField.set(sevenZOutputFile, 0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                              currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify initial state
                                                                                                                                                                                                                              assertNull(currentOutputStreamField.get(sevenZOutputFile));
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to call private method
                                                                                                                                                                                                                              Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                              getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                              OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify behavior - should remain null with original code
                                                                                                                                                                                                                              assertNull(currentOutputStreamField.get(sevenZOutputFile));
                                                                                                                                                                                                                              assertNull(result);
                                                                                                                                                                                                                          } finally {
                                                                                                                                                                                                                              // Clean up
                                                                                                                                                                                                                              tempFile.delete();
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                 public void testGetCurrentOutputStreamWhenNotNull() throws Exception {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(mock(File.class));
                                                                                                                                                                                                                     CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Set existing stream using reflection
                                                                                                                                                                                                                     Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                                                     currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                                                     currentOutputStreamField.set(sevenZOutputFile, mockStream);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create spy
                                                                                                                                                                                                                     SevenZOutputFile spy = spy(sevenZOutputFile);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test by calling private method via reflection
                                                                                                                                                                                                                     Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                                                     getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                                                     OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(spy);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify setupFileOutputStream was never called by checking the stream is still our mock
                                                                                                                                                                                                                     assertEquals(mockStream, result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                         public void testGetCurrentOutputStreamWhenNull() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(mock(File.class));
                                                                                                                                                                                             CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                                             
                                                                                                                                                                                             // Get private methods via reflection
                                                                                                                                                                                             Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                                             getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Get field via reflection
                                                                                                                                                                                             Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                                             currentOutputStreamField.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Create spy
                                                                                                                                                                                             SevenZOutputFile spy = spy(sevenZOutputFile);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set currentOutputStream to null
                                                                                                                                                                                             currentOutputStreamField.set(spy, null);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify currentOutputStream is null initially
                                                                                                                                                                                             assertNull(getCurrentOutputStreamMethod.invoke(spy));
                                                                                                                                                                                             
                                                                                                                                                                                             // Set mock stream directly through reflection
                                                                                                                                                                                             currentOutputStreamField.set(spy, mockStream);
                                                                                                                                                                                             
                                                                                                                                                                                             // Test
                                                                                                                                                                                             OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(spy);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify mock was returned
                                                                                                                                                                                             assertEquals(mockStream, result);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                     public void testWriteUnpackInfoIsCalled() throws Exception {
                                                                                                                                                                                         // Setup
                                                                                                                                                                                         SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                                         DataOutput mockedHeader = mock(DataOutput.class);
                                                                                                                                                                                         
                                                                                                                                                                                         // Create a non-empty archive entry to trigger unpack info writing
                                                                                                                                                                                         SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                                         entry.setHasStream(true);
                                                                                                                                                                                         sevenZOutputFile.putArchiveEntry(entry);
                                                                                                                                                                                         sevenZOutputFile.write(new byte[]{1, 2, 3});
                                                                                                                                                                                         sevenZOutputFile.closeArchiveEntry();
                                                                                                                                                                                         
                                                                                                                                                                                         // Action - this should call writeUnpackInfo
                                                                                                                                                                                         sevenZOutputFile.finish();
                                                                                                                                                                                         
                                                                                                                                                                                         // Verification
                                                                                                                                                                                         // Verify that writeUnpackInfo was called on the header
                                                                                                                                                                                         // The mutant would fail this verification since it comments out the call
                                                                                                                                                                                         verify(mockedHeader, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                         // Additional verification for specific unpack info patterns if known
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                   public void testWriteSubStreamsInfoIsCalled() throws Exception {
                                                                                                                                                                                       // Create a temporary file for testing
                                                                                                                                                                                       File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                       tempFile.deleteOnExit();
                                                                                                                                                                                       
                                                                                                                                                                                       // Create the output file
                                                                                                                                                                                       SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                       
                                                                                                                                                                                       // Create and add an archive entry
                                                                                                                                                                                       SevenZArchiveEntry entry = sevenZOutput.createArchiveEntry(tempFile, "testEntry");
                                                                                                                                                                                       sevenZOutput.putArchiveEntry(entry);
                                                                                                                                                                                       
                                                                                                                                                                                       // Write some test data
                                                                                                                                                                                       byte[] testData = "test data".getBytes();
                                                                                                                                                                                       sevenZOutput.write(testData);
                                                                                                                                                                                       
                                                                                                                                                                                       // Close the entry and finish the archive
                                                                                                                                                                                       sevenZOutput.closeArchiveEntry();
                                                                                                                                                                                       sevenZOutput.finish();
                                                                                                                                                                                       sevenZOutput.close();
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify the archive contains substream info by checking file size
                                                                                                                                                                                       // Using 32 as minimum reasonable size for signature + basic headers
                                                                                                                                                                                       assertTrue("File too small - substream info likely missing", 
                                                                                                                                                                                                  tempFile.length() > 32);
                                                                                                                                                                                       
                                                                                                                                                                                       // Open the file and verify its structure
                                                                                                                                                                                       SevenZFile sevenZInput = null;
                                                                                                                                                                                       try {
                                                                                                                                                                                           sevenZInput = new SevenZFile(tempFile);
                                                                                                                                                                                           // Verify the file has the expected number of streams
                                                                                                                                                                                           assertTrue("No substreams found", 
                                                                                                                                                                                                      sevenZInput.getNextEntry() != null);
                                                                                                                                                                                       } finally {
                                                                                                                                                                                           if (sevenZInput != null) {
                                                                                                                                                                                               sevenZInput.close();
                                                                                                                                                                                           }
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                              public void testHeaderWrittenWithCorrectNID() throws Exception {
                                                                                                                                                                                  // Setup
                                                                                                                                                                                  File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                  SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                                  
                                                                                                                                                                                  // Create a mock entry
                                                                                                                                                                                  SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                                  entry.setName("test.txt");
                                                                                                                                                                                  
                                                                                                                                                                                  // Write some data
                                                                                                                                                                                  sevenZOutput.putArchiveEntry(entry);
                                                                                                                                                                                  sevenZOutput.write("test data".getBytes());
                                                                                                                                                                                  sevenZOutput.closeArchiveEntry();
                                                                                                                                                                                  sevenZOutput.finish();
                                                                                                                                                                                  sevenZOutput.close();
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify the header was written correctly
                                                                                                                                                                                  try (RandomAccessFile raf = new RandomAccessFile(tempFile, "r")) {
                                                                                                                                                                                      // Skip signature header (32 bytes)
                                                                                                                                                                                      raf.seek(32);
                                                                                                                                                                                      
                                                                                                                                                                                      // Read header start marker (should be kHeader - 0x17 in 7z format)
                                                                                                                                                                                      byte[] headerStart = new byte[1];
                                                                                                                                                                                      raf.read(headerStart);
                                                                                                                                                                                      assertEquals((byte)0x17, headerStart[0]);
                                                                                                                                                                                      
                                                                                                                                                                                      // Skip to end of header (implementation specific, but we know kEnd should be there)
                                                                                                                                                                                      // In real implementation, would need to parse the header properly
                                                                                                                                                                                      // This is simplified for the test case
                                                                                                                                                                                      raf.seek(raf.length() - 1);
                                                                                                                                                                                      byte[] headerEnd = new byte[1];
                                                                                                                                                                                      raf.read(headerEnd);
                                                                                                                                                                                      assertEquals((byte)0x00, headerEnd[0]); // This would catch the mutant
                                                                                                                                                                                  }
                                                                                                                                                                                  
                                                                                                                                                                                  // Cleanup
                                                                                                                                                                                  tempFile.delete();
                                                                                                                                                                              }

    @Test
                                                                                                                                                                          public void testHeaderWriteUint64Value() throws IOException {
                                                                                                                                                                              // Create a temporary file for testing
                                                                                                                                                                              File tempFile = File.createTempFile("test7z", ".7z");
                                                                                                                                                                              tempFile.deleteOnExit();
                                                                                                                                                                              
                                                                                                                                                                              // Create SevenZOutputFile instance
                                                                                                                                                                              SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                                              
                                                                                                                                                                              // Create and add a simple archive entry
                                                                                                                                                                              SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                              entry.setName("test.txt");
                                                                                                                                                                              sevenZOutput.putArchiveEntry(entry);
                                                                                                                                                                              
                                                                                                                                                                              // Write some data to ensure header will be written
                                                                                                                                                                              byte[] testData = "test data".getBytes();
                                                                                                                                                                              sevenZOutput.write(testData);
                                                                                                                                                                              sevenZOutput.closeArchiveEntry();
                                                                                                                                                                              
                                                                                                                                                                              // Finish writing to trigger header writing
                                                                                                                                                                              sevenZOutput.finish();
                                                                                                                                                                              sevenZOutput.close();
                                                                                                                                                                              
                                                                                                                                                                              // Read back the file to verify header
                                                                                                                                                                              RandomAccessFile raf = new RandomAccessFile(tempFile, "r");
                                                                                                                                                                              try {
                                                                                                                                                                                  // Skip signature header (32 bytes)
                                                                                                                                                                                  raf.seek(32);
                                                                                                                                                                                  
                                                                                                                                                                                  // Read the next 8 bytes which should contain the uint64 value
                                                                                                                                                                                  byte[] headerValue = new byte[8];
                                                                                                                                                                                  raf.read(headerValue);
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify the value is 0 (original behavior)
                                                                                                                                                                                  // The mutant would write 1 here instead
                                                                                                                                                                                  for (int i = 0; i < 7; i++) {
                                                                                                                                                                                      assertEquals(0, headerValue[i]);
                                                                                                                                                                                  }
                                                                                                                                                                                  // Last byte might be non-zero depending on implementation
                                                                                                                                                                              } finally {
                                                                                                                                                                                  raf.close();
                                                                                                                                                                              }
                                                                                                                                                                          }

    @Test
                                                                                                                                                                        public void testWriteUint64HandlesNumNonEmptyStreamsCorrectly() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                            DataOutput mockHeader = mock(DataOutput.class);
                                                                                                                                                                            
                                                                                                                                                                            // Get private fields and methods via reflection
                                                                                                                                                                            Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                                                                                                                                                            numNonEmptyStreamsField.setAccessible(true);
                                                                                                                                                                            Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                                                                                                            writeHeaderMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Test case 1: Positive number within 32-bit range
                                                                                                                                                                            numNonEmptyStreamsField.set(sevenZOutputFile, 12345);
                                                                                                                                                                            writeHeaderMethod.invoke(sevenZOutputFile, mockHeader);
                                                                                                                                                                            verify(mockHeader).writeLong(12345L); // Changed from writeUint64 to writeLong
                                                                                                                                                                            
                                                                                                                                                                            // Test case 2: Negative number
                                                                                                                                                                            numNonEmptyStreamsField.set(sevenZOutputFile, -1);
                                                                                                                                                                            writeHeaderMethod.invoke(sevenZOutputFile, mockHeader);
                                                                                                                                                                            verify(mockHeader).writeLong(4294967295L); // Changed from writeUint64 to writeLong
                                                                                                                                                                            
                                                                                                                                                                            // Test case 3: Number larger than 32 bits
                                                                                                                                                                            numNonEmptyStreamsField.set(sevenZOutputFile, Integer.MAX_VALUE + 1L);
                                                                                                                                                                            writeHeaderMethod.invoke(sevenZOutputFile, mockHeader);
                                                                                                                                                                            verify(mockHeader).writeLong(0L); // Changed from writeUint64 to writeLong
                                                                                                                                                                            
                                                                                                                                                                            // Reset mock for clearer verification
                                                                                                                                                                            reset(mockHeader);
                                                                                                                                                                            
                                                                                                                                                                            // Test case 4: Maximum 32-bit unsigned value
                                                                                                                                                                            numNonEmptyStreamsField.set(sevenZOutputFile, -1); // Same as 0xFFFFFFFF unsigned
                                                                                                                                                                            writeHeaderMethod.invoke(sevenZOutputFile, mockHeader);
                                                                                                                                                                            verify(mockHeader).writeLong(4294967295L); // Changed from writeUint64 to writeLong
                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testWriteHeaderWritesSizeInformation() throws Exception {
                                                                                                                                                                        // Setup
                                                                                                                                                                        SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                        DataOutput mockedHeader = mock(DataOutput.class);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method since we need to test it
                                                                                                                                                                        Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                                                                                                        writeHeaderMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Execute
                                                                                                                                                                        writeHeaderMethod.invoke(sevenZOutputFile, mockedHeader);
                                                                                                                                                                        
                                                                                                                                                                        // Verify that header.write(NID.kSize) was called
                                                                                                                                                                        // We can't verify the exact value since NID.kSize is private, but we can verify a write was called
                                                                                                                                                                        verify(mockedHeader, atLeastOnce()).write(anyInt());
                                                                                                                                                                        
                                                                                                                                                                        // Clean up
                                                                                                                                                                        sevenZOutputFile.close();
                                                                                                                                                                        new File("test.7z").delete();
                                                                                                                                                                    }

    @Test
                                                                                                                                                                   public void testGetCurrentOutputStreamInitializesWhenNull2() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set currentOutputStream to null
                                                                                                                                                                       Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                       currentOutputStreamField.setAccessible(true);
                                                                                                                                                                       currentOutputStreamField.set(sevenZOutputFile, null);
                                                                                                                                                                       
                                                                                                                                                                       // Mock the setup method
                                                                                                                                                                       CountingOutputStream mockStream = mock(CountingOutputStream.class);
                                                                                                                                                                       Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                                                                                       setupMethod.setAccessible(true);
                                                                                                                                                                       when(setupMethod.invoke(sevenZOutputFile)).thenReturn(mockStream);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to call getCurrentOutputStream
                                                                                                                                                                       Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                       getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                       OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                       
                                                                                                                                                                       // Verify
                                                                                                                                                                       assertNotNull("OutputStream should not be null", result);
                                                                                                                                                                       assertEquals("Should return the mock stream", mockStream, result);
                                                                                                                                                                       verify(setupMethod, times(1)).invoke(sevenZOutputFile);
                                                                                                                                                                       
                                                                                                                                                                       // Clean up
                                                                                                                                                                       sevenZOutputFile.close();
                                                                                                                                                                       new File("test.7z").delete();
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testGetCurrentOutputStreamReturnsExistingStream1() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                                       CountingOutputStream existingStream = mock(CountingOutputStream.class);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set currentOutputStream
                                                                                                                                                                       Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                                                       currentOutputStreamField.setAccessible(true);
                                                                                                                                                                       currentOutputStreamField.set(sevenZOutputFile, existingStream);
                                                                                                                                                                       
                                                                                                                                                                       // Mock the setup method (shouldn't be called)
                                                                                                                                                                       Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                                                                                       setupMethod.setAccessible(true);
                                                                                                                                                                       when(setupMethod.invoke(sevenZOutputFile)).thenReturn(mock(CountingOutputStream.class));
                                                                                                                                                                       
                                                                                                                                                                       // Get the private method via reflection
                                                                                                                                                                       Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                       getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                       
                                                                                                                                                                       // Test
                                                                                                                                                                       OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                       
                                                                                                                                                                       // Verify
                                                                                                                                                                       assertNotNull("OutputStream should not be null", result);
                                                                                                                                                                       assertEquals("Should return the existing stream", existingStream, result);
                                                                                                                                                                       verify(setupMethod, never()).invoke(sevenZOutputFile);
                                                                                                                                                                       
                                                                                                                                                                       // Clean up
                                                                                                                                                                       sevenZOutputFile.close();
                                                                                                                                                                       new File("test.7z").delete();
                                                                                                                                                                   }

    @Test
                                                                                                                                                              public void testGetCurrentOutputStreamWithAndWithoutStreams() throws Exception {
                                                                                                                                                                  // Setup test file
                                                                                                                                                                  File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                  tempFile.deleteOnExit();
                                                                                                                                                                  
                                                                                                                                                                  // Create test instance
                                                                                                                                                                  SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                                                                                                                                                  
                                                                                                                                                                  // Create mock entries
                                                                                                                                                                  SevenZArchiveEntry withStream = new SevenZArchiveEntry();
                                                                                                                                                                  SevenZArchiveEntry withoutStream = new SevenZArchiveEntry();
                                                                                                                                                                  
                                                                                                                                                                  // Mock the hasStream() behavior - this is where the mutation occurs
                                                                                                                                                                  // Original would call hasStream(), mutant calls !hasStream()
                                                                                                                                                                  when(withStream.hasStream()).thenReturn(true);
                                                                                                                                                                  when(withoutStream.hasStream()).thenReturn(false);
                                                                                                                                                                  
                                                                                                                                                                  // Get the private method using reflection
                                                                                                                                                                  Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                                                  getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                                                  
                                                                                                                                                                  // Test case 1: Entry with stream should initialize output stream
                                                                                                                                                                  sevenZOutputFile.putArchiveEntry(withStream);
                                                                                                                                                                  OutputStream stream1 = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                  assertNotNull("OutputStream should be created for entry with stream", stream1);
                                                                                                                                                                  
                                                                                                                                                                  // Test case 2: Entry without stream should not initialize output stream
                                                                                                                                                                  sevenZOutputFile.putArchiveEntry(withoutStream);
                                                                                                                                                                  OutputStream stream2 = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                                                  assertNull("OutputStream should not be created for entry without stream", stream2);
                                                                                                                                                                  
                                                                                                                                                                  // Clean up
                                                                                                                                                                  sevenZOutputFile.close();
                                                                                                                                                              }

    @Test
                                                                                                                                                         public void testHeaderWritesCompressedSizeNotOriginalSize() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                             SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                             
                                                                                                                                                             // Create an entry with different compressed and original sizes
                                                                                                                                                             SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                             entry.setSize(1000L);  // Original size
                                                                                                                                                             
                                                                                                                                                             // Use reflection to set compressed size since setCompressedSize is not public
                                                                                                                                                             Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
                                                                                                                                                             compressedSizeField.setAccessible(true);
                                                                                                                                                             compressedSizeField.set(entry, 500L);  // Compressed size
                                                                                                                                                             
                                                                                                                                                             // Add entry to the archive
                                                                                                                                                             sevenZOutput.putArchiveEntry(entry);
                                                                                                                                                             
                                                                                                                                                             // Mock the DataOutput to verify what gets written
                                                                                                                                                             ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                             DataOutput header = new DataOutputStream(baos);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to call private writeHeader method
                                                                                                                                                             Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                                                                                             writeHeaderMethod.setAccessible(true);
                                                                                                                                                             writeHeaderMethod.invoke(sevenZOutput, header);
                                                                                                                                                             
                                                                                                                                                             // Verify the written data contains the compressed size (500) not original size (1000)
                                                                                                                                                             byte[] headerBytes = baos.toByteArray();
                                                                                                                                                             boolean foundCompressedSize = false;
                                                                                                                                                             
                                                                                                                                                             // Search for the compressed size value in the header (simplified check)
                                                                                                                                                             // In real implementation, would need to know exact header format
                                                                                                                                                             for (int i = 0; i < headerBytes.length - 8; i++) {
                                                                                                                                                                 long value = 0;
                                                                                                                                                                 for (int j = 0; j < 8; j++) {
                                                                                                                                                                     value |= (headerBytes[i + j] & 0xFFL) << (8 * j);
                                                                                                                                                                 }
                                                                                                                                                                 if (value == 500L) {
                                                                                                                                                                     foundCompressedSize = true;
                                                                                                                                                                     break;
                                                                                                                                                                 }
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             assertTrue("Header should contain compressed size", foundCompressedSize);
                                                                                                                                                             
                                                                                                                                                             // Cleanup
                                                                                                                                                             sevenZOutput.close();
                                                                                                                                                             tempFile.delete();
                                                                                                                                                         }

    @Test
                                                                                                                                                         public void testWriteUint64UsesCompressedSize() throws Exception {
                                                                                                                                                             // Setup
                                                                                                                                                             File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                             SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                                                             
                                                                                                                                                             SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                             entry.setSize(1000L);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to set compressed size since it's not public
                                                                                                                                                             Method setCompressedSize = SevenZArchiveEntry.class.getDeclaredMethod("setCompressedSize", long.class);
                                                                                                                                                             setCompressedSize.setAccessible(true);
                                                                                                                                                             setCompressedSize.invoke(entry, 500L);
                                                                                                                                                             
                                                                                                                                                             sevenZOutput.putArchiveEntry(entry);
                                                                                                                                                             
                                                                                                                                                             // Write some data to trigger header writing
                                                                                                                                                             sevenZOutput.write(new byte[100]);
                                                                                                                                                             sevenZOutput.closeArchiveEntry();
                                                                                                                                                             sevenZOutput.finish();
                                                                                                                                                             
                                                                                                                                                             // Verify by checking file size - compressed size should affect header
                                                                                                                                                             // This is indirect verification since we can't access private methods
                                                                                                                                                             long fileSize = tempFile.length();
                                                                                                                                                             assertTrue("File size should reflect compressed size usage", fileSize > 0);
                                                                                                                                                             
                                                                                                                                                             sevenZOutput.close();
                                                                                                                                                             tempFile.delete();
                                                                                                                                                         }

    @Test
                                                                                                                                                    public void testWriteHeaderIncludesCRC() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                        DataOutput header = mock(DataOutput.class);
                                                                                                                                                        
                                                                                                                                                        // Get private writeHeader method via reflection
                                                                                                                                                        Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                                                                                        writeHeaderMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        writeHeaderMethod.invoke(sevenZOutputFile, header);
                                                                                                                                                        
                                                                                                                                                        // Verify CRC was written - since we can't access NID.kCRC directly, we verify any write with int value 10
                                                                                                                                                        // (assuming kCRC has value 10 based on common 7z header format)
                                                                                                                                                        verify(header).write(10);
                                                                                                                                                        
                                                                                                                                                        // Cleanup
                                                                                                                                                        sevenZOutputFile.close();
                                                                                                                                                        new File("test.7z").delete();
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testHeaderWriteValue() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                                                                   DataOutput mockHeader = mock(DataOutput.class);
                                                                                                                                                   
                                                                                                                                                   // Get the private writeHeader method using reflection
                                                                                                                                                   Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                                                                                   writeHeaderMethod.setAccessible(true);
                                                                                                                                                   
                                                                                                                                                   // Execute
                                                                                                                                                   writeHeaderMethod.invoke(sevenZOutputFile, mockHeader);
                                                                                                                                                   
                                                                                                                                                   // Verify - this will catch the mutant that writes 0 instead of 1
                                                                                                                                                   verify(mockHeader).write(1); // Original should write 1, mutant writes 0
                                                                                                                                                   
                                                                                                                                                   // Cleanup
                                                                                                                                                   sevenZOutputFile.close();
                                                                                                                                                   new File("test.7z").delete();
                                                                                                                                               }

    @Test
                                                                                                                                      public void testGetCurrentOutputStream_WhenNotNull_DoesNotCallSetup() throws Exception {
                                                                                                                                          // Arrange - set existing stream
                                                                                                                                          SevenZOutputFile sevenZOutputFile = mock(SevenZOutputFile.class);
                                                                                                                                          OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                          
                                                                                                                                          // Use reflection to set private field
                                                                                                                                          Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                          currentOutputStreamField.setAccessible(true);
                                                                                                                                          currentOutputStreamField.set(sevenZOutputFile, mockOutputStream);
                                                                                                                                          
                                                                                                                                          // Get the private method
                                                                                                                                          Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                          getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act - call the private method via reflection
                                                                                                                                          OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          // Verify setupFileOutputStream was never called by checking no new stream was created
                                                                                                                                          assertEquals(mockOutputStream, result);
                                                                                                                                          
                                                                                                                                          // Verify no new stream was set (indirect verification that setup wasn't called)
                                                                                                                                          OutputStream currentStream = (OutputStream) currentOutputStreamField.get(sevenZOutputFile);
                                                                                                                                          assertEquals(mockOutputStream, currentStream);
                                                                                                                                      }

    @Test
                                                                                                                                  public void testGetCurrentOutputStream_WhenNull_CallsSetup() throws Exception {
                                                                                                                                      // Arrange
                                                                                                                                      File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                      SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                                                                                                                      
                                                                                                                                      // Get private methods via reflection
                                                                                                                                      Method getCurrentOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("getCurrentOutputStream");
                                                                                                                                      getCurrentOutputStreamMethod.setAccessible(true);
                                                                                                                                      
                                                                                                                                      // Set currentOutputStream to null via reflection
                                                                                                                                      Field currentOutputStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                                      currentOutputStreamField.setAccessible(true);
                                                                                                                                      currentOutputStreamField.set(sevenZOutputFile, null);
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      OutputStream result = (OutputStream) getCurrentOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      // Verify that currentOutputStream is no longer null
                                                                                                                                      assertNotNull(currentOutputStreamField.get(sevenZOutputFile));
                                                                                                                                      // Verify the returned stream is the same as the one stored in currentOutputStream
                                                                                                                                      assertEquals(currentOutputStreamField.get(sevenZOutputFile), result);
                                                                                                                                      
                                                                                                                                      // Cleanup
                                                                                                                                      tempFile.delete();
                                                                                                                                  }

    @Test
                                                                                                                         public void testSetupFileOutputStream_writeSingleByte() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                             // Setup
                                                                                                                             SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                                                             
                                                                                                                             // Use reflection to inject our mock stream and reset CRC
                                                                                                                             Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                                             crcField.setAccessible(true);
                                                                                                                             crcField.set(sevenZOutput, new CRC32());
                                                                                                                             
                                                                                                                             Field currentStreamField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                                                                             currentStreamField.setAccessible(true);
                                                                                                                             
                                                                                                                             // Create a real CountingOutputStream wrapping our mock
                                                                                                                             CountingOutputStream cos = new CountingOutputStream(mockOut) {
                                                                                                                                 @Override
                                                                                                                                 public void write(int b) throws IOException {
                                                                                                                                     super.write(b);
                                                                                                                                     try {
                                                                                                                                         ((CRC32)crcField.get(sevenZOutput)).update(b);
                                                                                                                                     } catch (IllegalAccessException e) {
                                                                                                                                         throw new IOException("Failed to update CRC", e);
                                                                                                                                     }
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             currentStreamField.set(sevenZOutput, cos);
                                                                                                                             
                                                                                                                             // Test data
                                                                                                                             int testByte = 0x42;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             sevenZOutput.write(testByte);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             // 1. Check that the mock received the write call
                                                                                                                             verify(mockOut).write(testByte);
                                                                                                                             
                                                                                                                             // 2. Check that CRC was updated
                                                                                                                             CRC32 crc = (CRC32)crcField.get(sevenZOutput);
                                                                                                                             assertNotEquals(0L, crc.getValue());  // CRC should be updated
                                                                                                                             
                                                                                                                             // Cleanup
                                                                                                                             sevenZOutput.close();
                                                                                                                         }

    @Test
                                                                                                                    public void testSetupFileOutputStream_CRC32UpdateForByteArray() throws IOException {
                                                                                                                        // Setup
                                                                                                                        File tempFile = File.createTempFile("test", ".7z");
                                                                                                                        SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                                        
                                                                                                                        try {
                                                                                                                            // Get the output stream using reflection
                                                                                                                            Method setupFileOutputStream = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                                            setupFileOutputStream.setAccessible(true);
                                                                                                                            CountingOutputStream cos = (CountingOutputStream) setupFileOutputStream.invoke(sevenZOutput);
                                                                                                                            
                                                                                                                            // Get crc32 field using reflection
                                                                                                                            Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                                            crc32Field.setAccessible(true);
                                                                                                                            CRC32 crc32 = (CRC32) crc32Field.get(sevenZOutput);
                                                                                                                            
                                                                                                                            // Test data
                                                                                                                            byte[] testData = "Test data for CRC32".getBytes();
                                                                                                                            
                                                                                                                            // Write single byte to establish baseline CRC
                                                                                                                            cos.write(testData[0]);
                                                                                                                            long expectedCRC = crc32.getValue();
                                                                                                                            
                                                                                                                            // Write remaining data as array
                                                                                                                            cos.write(testData, 1, testData.length - 1);
                                                                                                                            
                                                                                                                            // Calculate expected CRC manually
                                                                                                                            CRC32 manualCRC = new CRC32();
                                                                                                                            manualCRC.update(testData);
                                                                                                                            long expectedFullCRC = manualCRC.getValue();
                                                                                                                            
                                                                                                                            // Verify CRC was updated properly
                                                                                                                            assertEquals("CRC32 should be updated after byte array write", 
                                                                                                                                        expectedFullCRC, crc32.getValue());
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                                                        } finally {
                                                                                                                            // Cleanup
                                                                                                                            tempFile.delete();
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                               public void testSetupFileOutputStream_writeByteArray() throws Exception {
                                                                                                                   // Setup
                                                                                                                   SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                                                                   
                                                                                                                   // Use reflection to access private setupFileOutputStream method
                                                                                                                   Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                                   setupMethod.setAccessible(true);
                                                                                                                   CountingOutputStream cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                                                                                   
                                                                                                                   ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                   Field field = CountingOutputStream.class.getDeclaredField("out");
                                                                                                                   field.setAccessible(true);
                                                                                                                   field.set(cos, baos); // Replace the actual output stream with our test stream
                                                                                                                   
                                                                                                                   // Use reflection to access private crc32 field
                                                                                                                   Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                                   crcField.setAccessible(true);
                                                                                                                   CRC32 crc32 = (CRC32) crcField.get(sevenZOutput);
                                                                                                                   
                                                                                                                   // Test normal byte array write
                                                                                                                   byte[] testData = "test data".getBytes();
                                                                                                                   cos.write(testData);
                                                                                                                   
                                                                                                                   // Verify both the output and CRC32 were updated correctly
                                                                                                                   assertArrayEquals(testData, baos.toByteArray());
                                                                                                                   assertEquals(2848628632L, crc32.getValue()); // Pre-calculated CRC32
                                                                                                                   
                                                                                                                   // Test empty byte array write
                                                                                                                   baos.reset();
                                                                                                                   crc32.reset();
                                                                                                                   byte[] emptyData = new byte[0];
                                                                                                                   cos.write(emptyData);
                                                                                                                   
                                                                                                                   // Verify empty array didn't write anything but CRC32 was updated (with 0 bytes)
                                                                                                                   assertArrayEquals(emptyData, baos.toByteArray());
                                                                                                                   assertEquals(0L, crc32.getValue());
                                                                                                                   
                                                                                                                   // Test null byte array write
                                                                                                                   try {
                                                                                                                       cos.write(null);
                                                                                                                       fail("Expected NullPointerException");
                                                                                                                   } catch (NullPointerException e) {
                                                                                                                       // Expected behavior
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Additional test to catch the mutant - verify write method calls
                                                                                                                   // Mock the underlying stream to verify write method called
                                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                                   field.set(cos, mockOut);
                                                                                                                   byte[] testBytes = {1, 2, 3};
                                                                                                                   cos.write(testBytes);
                                                                                                                   
                                                                                                                   // Verify the original would call write(byte[]) while mutant calls write(byte[], int, int)
                                                                                                                   verify(mockOut).write(testBytes); // This will fail if mutant is present
                                                                                                                   verify(mockOut, never()).write(testBytes, 0, testBytes.length); // This will pass only for original
                                                                                                               }

    @Test
                                                                                                          public void testSetupFileOutputStream_writeByteArray_checksumsOnlyWrittenPortion() throws Exception {
                                                                                                              // Setup
                                                                                                              File tempFile = File.createTempFile("test", ".7z");
                                                                                                              SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                                              
                                                                                                              // Create a byte array with different content before and after our test data
                                                                                                              byte[] testData = new byte[10];
                                                                                                              java.util.Arrays.fill(testData, 0, 3, (byte) 0xAA);  // Unwritten prefix
                                                                                                              java.util.Arrays.fill(testData, 3, 7, (byte) 0xBB);  // Data we'll write
                                                                                                              java.util.Arrays.fill(testData, 7, 10, (byte) 0xCC); // Unwritten suffix
                                                                                                              
                                                                                                              // Get the output stream using reflection
                                                                                                              Method setupFileOutputStream = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                              setupFileOutputStream.setAccessible(true);
                                                                                                              CountingOutputStream cos = (CountingOutputStream) setupFileOutputStream.invoke(sevenZOutput);
                                                                                                              
                                                                                                              // Calculate expected CRC32 - only for the portion we're writing (index 3-6)
                                                                                                              CRC32 expectedCrc = new CRC32();
                                                                                                              expectedCrc.update(testData, 3, 4);
                                                                                                              long expectedChecksum = expectedCrc.getValue();
                                                                                                              
                                                                                                              // Write only portion of the array (index 3-6, length 4)
                                                                                                              cos.write(testData, 3, 4);
                                                                                                              
                                                                                                              // Verify CRC32 only calculated for written portion using reflection
                                                                                                              Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                              crc32Field.setAccessible(true);
                                                                                                              CRC32 actualCrc = (CRC32) crc32Field.get(sevenZOutput);
                                                                                                              
                                                                                                              assertEquals("CRC32 should only reflect written bytes", 
                                                                                                                          expectedChecksum, 
                                                                                                                          actualCrc.getValue());
                                                                                                              
                                                                                                              // Cleanup
                                                                                                              tempFile.delete();
                                                                                                          }

    @Test
                                                                                                     public void testWriteWithOffsetDetectsMutant() throws Exception {
                                                                                                         // Setup
                                                                                                         SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                                                         
                                                                                                         // Use reflection to access private setupFileOutputStream()
                                                                                                         Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                         setupMethod.setAccessible(true);
                                                                                                         CountingOutputStream cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                                                                         
                                                                                                         // Test data - first 5 bytes are different from next 5
                                                                                                         byte[] testData = new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                                                                                         int offset = 5;
                                                                                                         int len = 5;
                                                                                                         
                                                                                                         // Mock the underlying output stream to verify writes
                                                                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                         
                                                                                                         // Use reflection to replace the wrapped stream with our mock
                                                                                                         Field outField = CountingOutputStream.class.getDeclaredField("out");
                                                                                                         outField.setAccessible(true);
                                                                                                         outField.set(cos, baos);
                                                                                                         
                                                                                                         // Action
                                                                                                         cos.write(testData, offset, len);
                                                                                                         
                                                                                                         // Verification
                                                                                                         byte[] writtenBytes = baos.toByteArray();
                                                                                                         
                                                                                                         // Verify correct bytes were written (should be bytes 5-9)
                                                                                                         assertEquals(len, writtenBytes.length);
                                                                                                         for (int i = 0; i < len; i++) {
                                                                                                             assertEquals(testData[offset + i], writtenBytes[i]);
                                                                                                         }
                                                                                                         
                                                                                                         // Verify CRC32 was calculated on correct bytes
                                                                                                         CRC32 expectedCrc = new CRC32();
                                                                                                         expectedCrc.update(testData, offset, len);
                                                                                                         
                                                                                                         // Use reflection to access private crc32 field
                                                                                                         Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                         crcField.setAccessible(true);
                                                                                                         CRC32 actualCrc = (CRC32) crcField.get(sevenZOutput);
                                                                                                         
                                                                                                         assertEquals(expectedCrc.getValue(), actualCrc.getValue());
                                                                                                     }

    @Test
                                                                                                public void testSetupFileOutputStreamWithZeroNonEmptyStreams() throws Exception {
                                                                                                    // Setup
                                                                                                    SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                                                                                    
                                                                                                    // Use reflection to set private field numNonEmptyStreams to 0
                                                                                                    Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                                                                                    numNonEmptyStreamsField.setAccessible(true);
                                                                                                    numNonEmptyStreamsField.set(sevenZOutputFile, 0);
                                                                                                    
                                                                                                    // Also set required compression method
                                                                                                    Field contentCompressionField = SevenZOutputFile.class.getDeclaredField("contentCompression");
                                                                                                    contentCompressionField.setAccessible(true);
                                                                                                    contentCompressionField.set(sevenZOutputFile, SevenZMethod.LZMA2);
                                                                                                    
                                                                                                    // Test - use reflection to call private method
                                                                                                    Method setupFileOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                                                    setupFileOutputStreamMethod.setAccessible(true);
                                                                                                    CountingOutputStream result = (CountingOutputStream) setupFileOutputStreamMethod.invoke(sevenZOutputFile);
                                                                                                    
                                                                                                    // Verify - with original code (>0), this should return null or behave differently
                                                                                                    // With mutant (>=0), it will create output stream when numNonEmptyStreams is 0
                                                                                                    assertNotNull("Output stream should not be null for numNonEmptyStreams=0", result);
                                                                                                    
                                                                                                    // Verify CRC32 is properly initialized
                                                                                                    Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                                                    crc32Field.setAccessible(true);
                                                                                                    CRC32 crc32 = (CRC32) crc32Field.get(sevenZOutputFile);
                                                                                                    assertNotNull("CRC32 should be initialized", crc32);
                                                                                                    
                                                                                                    // Clean up
                                                                                                    result.close();
                                                                                                    sevenZOutputFile.close();
                                                                                                    new File("test.7z").delete();
                                                                                                }

    @Test
                                                                                           public void testWriteUint() throws IOException {
                                                                                               // Setup
                                                                                               SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                                               DataOutput mockOutput = mock(DataOutput.class);
                                                                                               
                                                                                               try {
                                                                                                   // Use reflection to access private writeUint64 method
                                                                                                   Method writeUint64 = SevenZOutputFile.class.getDeclaredMethod("writeUint64", DataOutput.class, long.class);
                                                                                                   writeUint64.setAccessible(true);
                                                                                                   writeUint64.invoke(sevenZOutput, mockOutput, 0L);
                                                                                                   
                                                                                                   // Verify the correct value (0) was written
                                                                                                   verify(mockOutput).writeLong(0L);
                                                                                                   
                                                                                                   // Additional verification to catch the mutant
                                                                                                   try {
                                                                                                       verify(mockOutput, never()).writeLong(1L);
                                                                                                   } catch (AssertionError e) {
                                                                                                       // This will fail if the mutant is present (writing 1 instead of 0)
                                                                                                       throw new AssertionError("Mutant detected: writeUint64 wrote 1 instead of 0");
                                                                                                   }
                                                                                               } catch (Exception e) {
                                                                                                   throw new RuntimeException("Failed to test private writeUint64 method", e);
                                                                                               } finally {
                                                                                                   // Clean up
                                                                                                   sevenZOutput.close();
                                                                                                   new File("test.7z").delete();
                                                                                               }
                                                                                           }

    @Test
                                                                                           public void testWriteUint64WithNonZeroValue() throws Exception {
                                                                                               // Setup
                                                                                               SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                                               DataOutput mockOutput = mock(DataOutput.class);
                                                                                               
                                                                                               // Get the private writeUint64 method using reflection
                                                                                               Method writeUint64Method = SevenZOutputFile.class.getDeclaredMethod(
                                                                                                   "writeUint64", DataOutput.class, long.class);
                                                                                               writeUint64Method.setAccessible(true);
                                                                                               
                                                                                               // Test with a non-zero value
                                                                                               long testValue = 123456789L;
                                                                                               writeUint64Method.invoke(sevenZOutput, mockOutput, testValue);
                                                                                               
                                                                                               // Verify the correct value was written
                                                                                               verify(mockOutput).writeLong(testValue);
                                                                                               
                                                                                               // Clean up
                                                                                               sevenZOutput.close();
                                                                                               new File("test.7z").delete();
                                                                                           }

    @Test
                                                                                      public void testWriteUint64WithNumNonEmptyStreams() throws Exception {
                                                                                          // Create test file
                                                                                          File tempFile = File.createTempFile("test", ".7z");
                                                                                          tempFile.deleteOnExit();
                                                                                          
                                                                                          // Create SevenZOutputFile instance
                                                                                          SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                          
                                                                                          try {
                                                                                              // Get private numNonEmptyStreams field using reflection
                                                                                              Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                                                                              numNonEmptyStreamsField.setAccessible(true);
                                                                                              
                                                                                              // Test case 1: Positive value within 32-bit range
                                                                                              numNonEmptyStreamsField.set(sevenZOutput, 12345);
                                                                                              sevenZOutput.finish(); // This will trigger writeHeader which calls writeUint64
                                                                                              
                                                                                              // Test case 2: Negative value (should be masked to positive)
                                                                                              numNonEmptyStreamsField.set(sevenZOutput, -1);
                                                                                              sevenZOutput.finish();
                                                                                              
                                                                                              // Test case 3: Value exceeding 32-bit range
                                                                                              // Need to use setLong since we're setting a long value
                                                                                              numNonEmptyStreamsField.setLong(sevenZOutput, Integer.MAX_VALUE + 1L);
                                                                                              sevenZOutput.finish();
                                                                                              
                                                                                              // Verify the written values by reading back the file
                                                                                              RandomAccessFile raf = new RandomAccessFile(tempFile, "r");
                                                                                              try {
                                                                                                  // Skip signature header (32 bytes for 7z signature)
                                                                                                  raf.seek(32);
                                                                                                  
                                                                                                  // The actual verification would need to parse the 7z file format,
                                                                                                  // but for this test we're focusing on catching the mutation
                                                                                                  
                                                                                                  // If we reach here without the mutant being caught, the test fails
                                                                                                  fail("The test should have caught the writeUint64 mutation");
                                                                                              } finally {
                                                                                                  raf.close();
                                                                                              }
                                                                                          } finally {
                                                                                              sevenZOutput.close();
                                                                                          }
                                                                                      }

    @Test
                                                                             public void testHeaderWritesCompressedSizeNotUncompressedSize() throws Exception {
                                                                                 // Setup test file and output file
                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                 SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                                 
                                                                                 // Create test entry with uncompressed size
                                                                                 SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                 entry.setName("test.txt");
                                                                                 entry.setSize(1000L);  // Uncompressed size
                                                                                 
                                                                                 // Mock DataOutput to verify what's written
                                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                 DataOutput header = new DataOutputStream(baos);
                                                                                 
                                                                                 // Add entry and trigger header writing
                                                                                 sevenZOutput.putArchiveEntry(entry);
                                                                                 byte[] testData = new byte[500]; // Write data that will be compressed
                                                                                 java.util.Arrays.fill(testData, (byte)1); // Fill with some data to ensure compression
                                                                                 sevenZOutput.write(testData);
                                                                                 sevenZOutput.closeArchiveEntry();
                                                                                 
                                                                                 // Use reflection to access private writeHeader method
                                                                                 Method writeHeader = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                 writeHeader.setAccessible(true);
                                                                                 writeHeader.invoke(sevenZOutput, header);
                                                                                 
                                                                                 // Verify the header contains the compressed size (should be less than uncompressed size)
                                                                                 byte[] headerBytes = baos.toByteArray();
                                                                                 boolean foundCompressedSize = false;
                                                                                 
                                                                                 // Search for a size value in the header that's less than uncompressed size
                                                                                 // In actual 7z format, the size would be written as a 64-bit little-endian value
                                                                                 for (int i = 0; i < headerBytes.length - 8; i++) {
                                                                                     long value = 0;
                                                                                     for (int j = 0; j < 8; j++) {
                                                                                         value |= (headerBytes[i + j] & 0xFFL) << (8 * j);
                                                                                     }
                                                                                     if (value > 0 && value < 1000L) {
                                                                                         foundCompressedSize = true;
                                                                                         break;
                                                                                     }
                                                                                 }
                                                                                 
                                                                                 assertTrue("Header should contain compressed size less than uncompressed size", foundCompressedSize);
                                                                                 
                                                                                 // Clean up
                                                                                 sevenZOutput.close();
                                                                                 tempFile.delete();
                                                                             }

    @Test
                                                                        public void testSetupFileOutputStreamWritesCRCToHeader() throws IOException {
                                                                            // Setup
                                                                            File tempFile = File.createTempFile("test", ".7z");
                                                                            tempFile.deleteOnExit();
                                                                            
                                                                            SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                                            SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                            entry.setName("test.txt");
                                                                            
                                                                            // Mock the header to verify CRC writing
                                                                            DataOutput mockedHeader = mock(DataOutput.class);
                                                                            
                                                                            // Act
                                                                            sevenZOutput.putArchiveEntry(entry);
                                                                            sevenZOutput.write("test data".getBytes());
                                                                            sevenZOutput.closeArchiveEntry();
                                                                            
                                                                            // Use reflection to access private writeHeader method
                                                                            try {
                                                                                java.lang.reflect.Method writeHeader = SevenZOutputFile.class
                                                                                    .getDeclaredMethod("writeHeader", DataOutput.class);
                                                                                writeHeader.setAccessible(true);
                                                                                writeHeader.invoke(sevenZOutput, mockedHeader);
                                                                            } catch (Exception e) {
                                                                                fail("Reflection failed: " + e.getMessage());
                                                                            }
                                                                            
                                                                            // Assert that CRC was written to header
                                                                            // 0x04 is the standard CRC ID in 7z format
                                                                            verify(mockedHeader).write(0x04);
                                                                            
                                                                            // Clean up
                                                                            sevenZOutput.close();
                                                                        }

    @Test
                                                                   public void testSetupFileOutputStream_WithAndWithoutStream() throws Exception {
                                                                       // Setup
                                                                       SevenZOutputFile outputFile = new SevenZOutputFile(new File("test.7z"));
                                                                       SevenZArchiveEntry withStream = mock(SevenZArchiveEntry.class);
                                                                       SevenZArchiveEntry withoutStream = mock(SevenZArchiveEntry.class);
                                                                       
                                                                       when(withStream.hasStream()).thenReturn(true);
                                                                       when(withoutStream.hasStream()).thenReturn(false);
                                                                       
                                                                       // Get private methods/fields via reflection
                                                                       Method setupFileOutputStream = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                                       setupFileOutputStream.setAccessible(true);
                                                                       
                                                                       Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                                                       numNonEmptyStreamsField.setAccessible(true);
                                                                       
                                                                       Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                       crc32Field.setAccessible(true);
                                                                       
                                                                       // Test with entry that has stream
                                                                       outputFile.putArchiveEntry(withStream);
                                                                       CountingOutputStream streamWith = (CountingOutputStream) setupFileOutputStream.invoke(outputFile);
                                                                       assertNotNull(streamWith);
                                                                       assertEquals(1, numNonEmptyStreamsField.getInt(outputFile));
                                                                       
                                                                       // Verify CRC32 is updated when writing
                                                                       byte[] testData = {1, 2, 3};
                                                                       streamWith.write(testData);
                                                                       CRC32 crc32 = (CRC32) crc32Field.get(outputFile);
                                                                       assertNotEquals(0, crc32.getValue());
                                                                       
                                                                       // Test with entry that has no stream
                                                                       outputFile.putArchiveEntry(withoutStream);
                                                                       CountingOutputStream streamWithout = (CountingOutputStream) setupFileOutputStream.invoke(outputFile);
                                                                       assertNull(streamWithout);
                                                                       // numNonEmptyStreams shouldn't increment for entries without streams
                                                                       assertEquals(1, numNonEmptyStreamsField.getInt(outputFile));
                                                                       
                                                                       // Cleanup
                                                                       if (streamWith != null) {
                                                                           streamWith.close();
                                                                       }
                                                                       outputFile.close();
                                                                   }

    @Test
                                                              public void testSetupFileOutputStream_writeSingleByte1() throws IOException {
                                                                  // Setup
                                                                  SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                  
                                                                  // Use reflection to inject our mock stream and reset CRC
                                                                  try {
                                                                      Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                      crcField.setAccessible(true);
                                                                      crcField.set(sevenZOutput, new CRC32());
                                                                      
                                                                      Field outField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                                      outField.setAccessible(true);
                                                                      
                                                                      // Create a wrapper that will use our mock stream
                                                                      CountingOutputStream cos = new CountingOutputStream(mockOut) {
                                                                          @Override
                                                                          public void write(int b) throws IOException {
                                                                              super.write(b);
                                                                              try {
                                                                                  ((CRC32)crcField.get(sevenZOutput)).update(b);
                                                                              } catch (IllegalAccessException e) {
                                                                                  throw new IOException("Failed to update CRC", e);
                                                                              }
                                                                          }
                                                                      };
                                                                      outField.set(sevenZOutput, cos);
                                                                  } catch (Exception e) {
                                                                      fail("Reflection setup failed: " + e.getMessage());
                                                                  }
                                                                  
                                                                  // Test data
                                                                  int testByte = 0x42;
                                                                  
                                                                  // Execute
                                                                  sevenZOutput.write(testByte);
                                                                  
                                                                  // Verify
                                                                  // 1. The data was actually written to the stream
                                                                  verify(mockOut).write(testByte);
                                                                  
                                                                  // 2. The CRC was updated (bonus check)
                                                                  try {
                                                                      Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                                      crcField.setAccessible(true);
                                                                      CRC32 crc = (CRC32)crcField.get(sevenZOutput);
                                                                      assertNotEquals(0, crc.getValue());
                                                                  } catch (Exception e) {
                                                                      fail("CRC verification failed: " + e.getMessage());
                                                                  }
                                                                  
                                                                  // Cleanup
                                                                  sevenZOutput.close();
                                                                  new File("test.7z").delete();
                                                              }

    @Test
                                                         public void testSetupFileOutputStream_byteArrayWriteUpdatesCrc() throws Exception {
                                                             // Setup
                                                             File tempFile = File.createTempFile("test", ".7z");
                                                             SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                                             
                                                             // Get private crc32 field using reflection
                                                             Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                                             crc32Field.setAccessible(true);
                                                             CRC32 crc32 = (CRC32) crc32Field.get(sevenZOutput);
                                                             
                                                             // Get initial CRC value
                                                             long initialCrc = crc32.getValue();
                                                             
                                                             // Create test data
                                                             byte[] testData = "Test data for CRC32 calculation".getBytes();
                                                             
                                                             // Get private setupFileOutputStream method using reflection
                                                             Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                             setupMethod.setAccessible(true);
                                                             CountingOutputStream cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                             
                                                             // Action - write byte array
                                                             cos.write(testData);
                                                             
                                                             // Verify
                                                             // Calculate expected CRC32 value
                                                             CRC32 expectedCrc = new CRC32();
                                                             expectedCrc.update(testData);
                                                             long expectedValue = expectedCrc.getValue();
                                                             
                                                             // Get actual CRC32 value
                                                             long actualValue = crc32.getValue();
                                                             
                                                             // Assertions
                                                             assertEquals("Initial CRC should be 0", 0, initialCrc);
                                                             assertNotEquals("CRC should have changed after write", initialCrc, actualValue);
                                                             assertEquals("CRC32 should match expected value after byte array write", 
                                                                         expectedValue, actualValue);
                                                             
                                                             // Cleanup
                                                             cos.close();
                                                             sevenZOutput.close();
                                                             tempFile.delete();
                                                         }

    @Test
                                                    public void testSetupFileOutputStream_writeByteArray_partialWrite() throws Exception {
                                                        // Setup
                                                        SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                        
                                                        // Create mock OutputStreamWrapper
                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                        
                                                        // Use reflection to access private setupFileOutputStream method
                                                        Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                        setupMethod.setAccessible(true);
                                                        
                                                        // Replace the actual output stream with our mock
                                                        Field outField = SevenZOutputFile.class.getDeclaredField("currentOutputStream");
                                                        outField.setAccessible(true);
                                                        outField.set(sevenZOutput, mockOutputStream);
                                                        
                                                        CountingOutputStream cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                        
                                                        // Create a byte array with extra data
                                                        byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                        byte[] partialData = new byte[10];
                                                        System.arraycopy(testData, 0, partialData, 2, testData.length);
                                                        
                                                        // Act - write only portion of the array
                                                        cos.write(partialData, 2, testData.length);
                                                        
                                                        // Verify
                                                        // Should call the exact write method with correct parameters
                                                        verify(mockOutputStream).write(testData, 0, testData.length);
                                                        
                                                        // Verify CRC32 is calculated only for the written portion
                                                        CRC32 expectedCrc = new CRC32();
                                                        expectedCrc.update(testData, 0, testData.length);
                                                        
                                                        // Get CRC32 field using reflection
                                                        Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                        crcField.setAccessible(true);
                                                        CRC32 actualCrc = (CRC32) crcField.get(sevenZOutput);
                                                        
                                                        assertEquals(expectedCrc.getValue(), actualCrc.getValue());
                                                    }

    @Test
                                                    public void testSetupFileOutputStream_writeByteArray_emptyArray() throws Exception {
                                                        // Setup
                                                        SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                        
                                                        // Use reflection to access private setupFileOutputStream method
                                                        Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                        setupMethod.setAccessible(true);
                                                        CountingOutputStream cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                        
                                                        // Get the underlying OutputStreamWrapper
                                                        Field outField = CountingOutputStream.class.getDeclaredField("out");
                                                        outField.setAccessible(true);
                                                        OutputStream out = (OutputStream) outField.get(cos);
                                                        
                                                        // Create a spy of the actual OutputStreamWrapper
                                                        OutputStream spyOut = spy(out);
                                                        outField.set(cos, spyOut);
                                                        
                                                        // Act - write empty array
                                                        byte[] emptyData = new byte[0];
                                                        cos.write(emptyData);
                                                        
                                                        // Verify
                                                        // Should call write with empty array
                                                        verify(spyOut).write(emptyData);
                                                        
                                                        // Use reflection to access private crc32 field
                                                        Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                        crcField.setAccessible(true);
                                                        CRC32 crc32 = (CRC32) crcField.get(sevenZOutput);
                                                        
                                                        // CRC32 should remain unchanged (0)
                                                        assertEquals(0L, crc32.getValue());
                                                        
                                                        // Clean up
                                                        sevenZOutput.close();
                                                        new File("test.7z").delete();
                                                    }

    @Test
                                               public void testSetupFileOutputStream_writeByteArrayUpdatesCrcCorrectly() throws IOException {
                                                   // Setup
                                                   SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                                   
                                                   // Use reflection to access private setupFileOutputStream method
                                                   CountingOutputStream cos;
                                                   try {
                                                       Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                       setupMethod.setAccessible(true);
                                                       cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                   } catch (Exception e) {
                                                       throw new RuntimeException("Failed to access setupFileOutputStream", e);
                                                   }
                                                   
                                                   // Test data - using non-zero values and partial array to catch offset/length issues
                                                   byte[] testData = new byte[] {1, 2, 3, 4, 5, 0, 0, 0}; // Last 3 bytes are zero
                                                   byte[] expectedData = new byte[] {1, 2, 3, 4, 5}; // Only these should be checksummed
                                                   
                                                   // Calculate expected CRC
                                                   CRC32 expectedCrc = new CRC32();
                                                   expectedCrc.update(expectedData); // Original behavior - uses exact array
                                                   
                                                   // Action
                                                   cos.write(testData, 0, 5); // Write first 5 bytes only
                                                   cos.close();
                                                   
                                                   // Verification - use reflection to access private crc32 field
                                                   try {
                                                       Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                       crcField.setAccessible(true);
                                                       CRC32 actualCrc = (CRC32) crcField.get(sevenZOutput);
                                                       
                                                       assertEquals("CRC32 should match expected value", 
                                                                   expectedCrc.getValue(), 
                                                                   actualCrc.getValue());
                                                   } catch (Exception e) {
                                                       throw new RuntimeException("Failed to access crc32 field", e);
                                                   }
                                                   
                                                   // Additional test with full array write
                                                   sevenZOutput = new SevenZOutputFile(new File("test2.7z"));
                                                   try {
                                                       Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                                       setupMethod.setAccessible(true);
                                                       cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                                   } catch (Exception e) {
                                                       throw new RuntimeException("Failed to access setupFileOutputStream", e);
                                                   }
                                                   
                                                   byte[] fullTestData = new byte[] {1, 2, 3, 4, 5};
                                                   expectedCrc = new CRC32();
                                                   expectedCrc.update(fullTestData);
                                                   
                                                   cos.write(fullTestData);
                                                   cos.close();
                                                   
                                                   try {
                                                       Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                                       crcField.setAccessible(true);
                                                       CRC32 actualCrc = (CRC32) crcField.get(sevenZOutput);
                                                       
                                                       assertEquals("CRC32 should match for full array write",
                                                                  expectedCrc.getValue(),
                                                                  actualCrc.getValue());
                                                   } catch (Exception e) {
                                                       throw new RuntimeException("Failed to access crc32 field", e);
                                                   }
                                                   
                                                   // Clean up test files
                                                   new File("test.7z").delete();
                                                   new File("test2.7z").delete();
                                               }

    @Test
                                          public void testWriteWithOffsetDetectsMutant1() throws Exception {
                                              // Setup
                                              SevenZOutputFile sevenZOutput = new SevenZOutputFile(new File("test.7z"));
                                              
                                              // Use reflection to call private setupFileOutputStream()
                                              Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                              setupMethod.setAccessible(true);
                                              CountingOutputStream cos = (CountingOutputStream) setupMethod.invoke(sevenZOutput);
                                              
                                              // Create simple OutputStreamWrapper implementation
                                              class OutputStreamWrapper extends OutputStream {
                                                  private OutputStream out;
                                                  public OutputStreamWrapper() {}
                                                  public OutputStreamWrapper(OutputStream out) { this.out = out; }
                                                  @Override public void write(int b) throws IOException { out.write(b); }
                                                  @Override public void write(byte[] b) throws IOException { out.write(b); }
                                                  @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); }
                                              }
                                              
                                              // Mock the underlying OutputStream to verify writes
                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                              OutputStreamWrapper mockWrapper = mock(OutputStreamWrapper.class);
                                              doAnswer(invocation -> {
                                                  byte[] data = (byte[]) invocation.getArguments()[0];
                                                  int off = (int) invocation.getArguments()[1];
                                                  int len = (int) invocation.getArguments()[2];
                                                  baos.write(data, off, len);
                                                  return null;
                                              }).when(mockWrapper).write(any(byte[].class), anyInt(), anyInt());
                                              
                                              // Use reflection to replace the wrapped stream with our mock
                                              Field outField = CountingOutputStream.class.getDeclaredField("out");
                                              outField.setAccessible(true);
                                              outField.set(cos, mockWrapper);
                                              
                                              // Test data with non-zero offset
                                              byte[] testData = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                              int offset = 3;
                                              int length = 4;
                                              
                                              // Expected CRC32 for the slice
                                              CRC32 expectedCrc = new CRC32();
                                              expectedCrc.update(testData, offset, length);
                                              
                                              // Action
                                              cos.write(testData, offset, length);
                                              
                                              // Verification
                                              // 1. Verify correct bytes were written to underlying stream
                                              byte[] writtenBytes = baos.toByteArray();
                                              assertArrayEquals(java.util.Arrays.copyOfRange(testData, offset, offset + length), 
                                                               writtenBytes);
                                              
                                              // 2. Verify CRC was calculated on correct bytes
                                              Field crcField = SevenZOutputFile.class.getDeclaredField("crc32");
                                              crcField.setAccessible(true);
                                              CRC32 actualCrc = (CRC32) crcField.get(sevenZOutput);
                                              assertEquals(expectedCrc.getValue(), actualCrc.getValue());
                                              
                                              // 3. Verify mock was called with correct parameters
                                              verify(mockWrapper).write(testData, offset, length);
                                          }

    @Test
                                     public void testSetupFileOutputStreamWithZeroNonEmptyStreams1() throws Exception {
                                         // Setup
                                         File tempFile = File.createTempFile("test", ".7z");
                                         SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
                                         
                                         // Set numNonEmptyStreams to 0 to test the boundary condition
                                         // Using reflection since numNonEmptyStreams is private
                                         Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                         numNonEmptyStreamsField.setAccessible(true);
                                         numNonEmptyStreamsField.set(sevenZOutputFile, 0);
                                         
                                         // Also need to set contentCompression to avoid NPE
                                         Field contentCompressionField = SevenZOutputFile.class.getDeclaredField("contentCompression");
                                         contentCompressionField.setAccessible(true);
                                         contentCompressionField.set(sevenZOutputFile, SevenZMethod.LZMA2);
                                         
                                         // Execute - use reflection to access private method
                                         Method setupFileOutputStreamMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
                                         setupFileOutputStreamMethod.setAccessible(true);
                                         CountingOutputStream outputStream = (CountingOutputStream) setupFileOutputStreamMethod.invoke(sevenZOutputFile);
                                         
                                         // Verify - the original code should still create a valid output stream
                                         assertNotNull("OutputStream should not be null", outputStream);
                                         
                                         // Write some test data to verify CRC32 is being updated (original behavior)
                                         byte[] testData = "test".getBytes();
                                         outputStream.write(testData);
                                         
                                         // Verify CRC32 was updated (this would fail if the mutant prevented stream creation)
                                         Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                         crc32Field.setAccessible(true);
                                         CRC32 crc32 = (CRC32) crc32Field.get(sevenZOutputFile);
                                         assertNotEquals("CRC32 should have been updated", 0, crc32.getValue());
                                         
                                         // Cleanup
                                         outputStream.close();
                                         sevenZOutputFile.close();
                                         tempFile.delete();
                                     }

    @Test
                                public void testSetupFileOutputStream_HeaderWrittenWithZero() throws Exception {
                                    // Setup
                                    File tempFile = File.createTempFile("test", ".7z");
                                    SevenZOutputFile sevenZOutput = new SevenZOutputFile(tempFile);
                                    
                                    // Create a mock DataOutput to verify writeUint64 calls
                                    DataOutput mockHeader = mock(DataOutput.class);
                                    
                                    try {
                                        // Write a test entry
                                        SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                        entry.setName("test.txt");
                                        sevenZOutput.putArchiveEntry(entry);
                                        sevenZOutput.write("test data".getBytes());
                                        sevenZOutput.closeArchiveEntry();
                                        
                                        // Verify header is written with 0 values
                                        sevenZOutput.finish(); // This will trigger header writing
                                        
                                        // Verify writeUint64 was called with 0 for header values
                                        verify(mockHeader, atLeastOnce()).writeLong(eq(0L));
                                        
                                        // Additional verification of CRC32 values using reflection
                                        Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
                                        crc32Field.setAccessible(true);
                                        CRC32 crc32 = (CRC32) crc32Field.get(sevenZOutput);
                                        assertNotEquals(0, crc32.getValue()); // CRC should be updated
                                    } finally {
                                        sevenZOutput.close();
                                        tempFile.delete();
                                    }
                                }

    @Test
                            public void testWriteUint64WithLargeNumNonEmptyStreams() throws Exception {
                                // Setup
                                SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                
                                // Set numNonEmptyStreams to a value that exceeds 32 bits
                                Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                numNonEmptyStreamsField.setAccessible(true);
                                numNonEmptyStreamsField.set(sevenZOutputFile, Integer.MAX_VALUE + 1L);
                                
                                // Mock DataOutput to verify the written value
                                DataOutput mockHeader = mock(DataOutput.class);
                                
                                // Call private writeUint64 method using reflection
                                Method writeUint64Method = SevenZOutputFile.class.getDeclaredMethod("writeUint64", 
                                    DataOutput.class, long.class);
                                writeUint64Method.setAccessible(true);
                                writeUint64Method.invoke(sevenZOutputFile, mockHeader, Integer.MAX_VALUE + 1L);
                                
                                // Verify the masked value was written (original behavior)
                                verify(mockHeader).writeLong(0xffffFFFFL & (Integer.MAX_VALUE + 1L));
                                
                                // The mutant would fail this test because it would write the full value without masking
                            }

    @Test
                            public void testWriteUint64WithNegativeNumNonEmptyStreams() throws Exception {
                                // Setup
                                SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                                
                                // Set numNonEmptyStreams to negative value
                                Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                                numNonEmptyStreamsField.setAccessible(true);
                                numNonEmptyStreamsField.set(sevenZOutputFile, -1);
                                
                                // Mock DataOutput to verify the written value
                                DataOutput mockHeader = mock(DataOutput.class);
                                
                                // Call private writeUint64 method using reflection
                                Method writeUint64Method = SevenZOutputFile.class.getDeclaredMethod("writeUint64", 
                                    DataOutput.class, long.class);
                                writeUint64Method.setAccessible(true);
                                writeUint64Method.invoke(sevenZOutputFile, mockHeader, -1L);
                                
                                // Verify the masked value was written (original behavior)
                                verify(mockHeader).writeLong(0xffffFFFFL & -1L); // Should write 4294967295
                                
                                // The mutant would fail this test because it would write -1 directly
                            }

    @Test
                          public void testWriteHeaderUsesCompressedSizeNotSize() throws Exception {
                              // Setup test data
                              SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
                              SevenZArchiveEntry entry = new SevenZArchiveEntry();
                              entry.setSize(1000L);  // Uncompressed size
                              
                              // Use reflection to set compressed size since method is not public
                              Method setCompressedSizeMethod = SevenZArchiveEntry.class.getDeclaredMethod("setCompressedSize", long.class);
                              setCompressedSizeMethod.setAccessible(true);
                              setCompressedSizeMethod.invoke(entry, 500L);  // Compressed size
                              
                              // Add entry to files list (using reflection since files is private)
                              Field filesField = SevenZOutputFile.class.getDeclaredField("files");
                              filesField.setAccessible(true);
                              @SuppressWarnings("unchecked")
                              List<SevenZArchiveEntry> files = (List<SevenZArchiveEntry>) filesField.get(sevenZOutputFile);
                              files.add(entry);
                              
                              // Set non-empty streams count
                              Field numNonEmptyStreamsField = SevenZOutputFile.class.getDeclaredField("numNonEmptyStreams");
                              numNonEmptyStreamsField.setAccessible(true);
                              numNonEmptyStreamsField.set(sevenZOutputFile, 1);
                              
                              // Mock DataOutput to verify written values
                              DataOutput mockedHeader = mock(DataOutput.class);
                              
                              // Call the method that contains the mutation
                              Method writeHeaderMethod = SevenZOutputFile.class.getDeclaredMethod("writeHeader", DataOutput.class);
                              writeHeaderMethod.setAccessible(true);
                              writeHeaderMethod.invoke(sevenZOutputFile, mockedHeader);
                              
                              // Verify the correct size was written (compressed size, not uncompressed size)
                              verify(mockedHeader).writeLong(eq(500L));  // Should fail if mutant is present
                              
                              // Clean up
                              sevenZOutputFile.close();
                              new File("test.7z").delete();
                          }

    @Test
         public void testSetupFileOutputStreamWritesCRCToHeader1() throws IOException {
             // Create temp file for testing
             File tempFile = File.createTempFile("test", ".7z");
             tempFile.deleteOnExit();
             
             // Create SevenZOutputFile instance
             SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(tempFile);
             
             // Create a mock header to verify writes
             DataOutput mockHeader = mock(DataOutput.class);
             
             // Use reflection to inject mock header for testing
             try {
                 Field headerField = SevenZOutputFile.class.getDeclaredField("header");
                 headerField.setAccessible(true);
                 headerField.set(sevenZOutputFile, mockHeader);
             } catch (Exception e) {
                 fail("Failed to inject mock header");
             }
             
             // Create a test entry and add it to the archive
             SevenZArchiveEntry entry = new SevenZArchiveEntry();
             entry.setName("test.txt");
             sevenZOutputFile.putArchiveEntry(entry);
             
             // Write some test data to force CRC calculation
             byte[] testData = "Test data for CRC".getBytes();
             sevenZOutputFile.write(testData);
             sevenZOutputFile.closeArchiveEntry();
             
             // This will trigger header writing internally
             sevenZOutputFile.finish();
             
             // Verify that CRC was written to the header
             // Using direct value 0x04 which is the ID for CRC32 in 7z format
             verify(mockHeader, atLeastOnce()).write(0x04);
             
             // Clean up
             sevenZOutputFile.close();
         }

    @Test
    public void testSetupFileOutputStream_ShouldOnlyProcessStreamEntries() throws Exception {
        // Setup
        SevenZOutputFile sevenZOutputFile = new SevenZOutputFile(new File("test.7z"));
        SevenZArchiveEntry withStream = new SevenZArchiveEntry();
        withStream.setHasStream(true);
        SevenZArchiveEntry withoutStream = new SevenZArchiveEntry();
        withoutStream.setHasStream(false);
        
        // Mock CRC32 to verify updates
        CRC32 mockCrc = mock(CRC32.class);
        
        // Use reflection to set private crc32 field
        Field crc32Field = SevenZOutputFile.class.getDeclaredField("crc32");
        crc32Field.setAccessible(true);
        crc32Field.set(sevenZOutputFile, mockCrc);
        
        // Test with entry that has stream
        sevenZOutputFile.putArchiveEntry(withStream);
        
        // Use reflection to call private setupFileOutputStream method
        Method setupMethod = SevenZOutputFile.class.getDeclaredMethod("setupFileOutputStream");
        setupMethod.setAccessible(true);
        CountingOutputStream cosWithStream = (CountingOutputStream) setupMethod.invoke(sevenZOutputFile);
        
        cosWithStream.write(1); // Write test byte
        
        // Verify CRC was updated
        verify(mockCrc).update(1);
        
        // Test with entry that has no stream
        reset(mockCrc);
        sevenZOutputFile.putArchiveEntry(withoutStream);
        
        CountingOutputStream cosWithoutStream = (CountingOutputStream) setupMethod.invoke(sevenZOutputFile);
        cosWithoutStream.write(1); // Write test byte
        
        // Verify CRC was NOT updated for non-stream entry
        verify(mockCrc, never()).update(1);
        
        // Cleanup
        sevenZOutputFile.close();
        crc32Field.setAccessible(false);
        setupMethod.setAccessible(false);
    }


}
