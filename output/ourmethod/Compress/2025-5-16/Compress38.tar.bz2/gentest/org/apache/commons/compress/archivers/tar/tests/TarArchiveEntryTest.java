package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.utils.ArchiveUtils;
 
public class TarArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                              public void testIsDirectory_WhenFileIsNotNullAndIsDirectory() {
                                  File mockFile = mock(File.class);
                                  when(mockFile.isDirectory()).thenReturn(true);
                                  
                                  TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testDir/");
                                  assertTrue(entry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenFileIsNotNullAndIsNotDirectory() {
                                  File mockFile = mock(File.class);
                                  when(mockFile.isDirectory()).thenReturn(false);
                                  
                                  TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testFile");
                                  assertFalse(entry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenFileIsNullAndNameEndsWithSlash() {
                                  TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                  assertTrue(entry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenFileIsNullAndNameEndsWithSlashButPaxHeader() {
                                  TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                  // Mock isPaxHeader to return true
                                  TarArchiveEntry spyEntry = spy(entry);
                                  when(spyEntry.isPaxHeader()).thenReturn(true);
                                  
                                  assertFalse(spyEntry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenFileIsNullAndNameEndsWithSlashButGlobalPaxHeader() {
                                  TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                  // Mock isGlobalPaxHeader to return true
                                  TarArchiveEntry spyEntry = spy(entry);
                                  when(spyEntry.isGlobalPaxHeader()).thenReturn(true);
                                  
                                  assertFalse(spyEntry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenFileIsNullAndNotDirectoryCase() {
                                  TarArchiveEntry entry = new TarArchiveEntry("testFile");
                                  assertFalse(entry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenConstructedWithDirectoryFile() {
                                  File mockFile = mock(File.class);
                                  when(mockFile.isDirectory()).thenReturn(true);
                                  when(mockFile.lastModified()).thenReturn(System.currentTimeMillis());
                                  
                                  TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testDir");
                                  assertTrue(entry.isDirectory());
                              }

 @Test
                              public void testIsDirectory_WhenConstructedWithNormalFile() {
                                  File mockFile = mock(File.class);
                                  when(mockFile.isDirectory()).thenReturn(false);
                                  when(mockFile.length()).thenReturn(1024L);
                                  when(mockFile.lastModified()).thenReturn(System.currentTimeMillis());
                                  
                                  TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testFile");
                                  assertFalse(entry.isDirectory());
                              }

 @Test
                      public void testIsDirectory_WhenFileIsNullAndLinkFlagIsDir() {
                          // Define the directory link flag constant (LF_DIR = 53)
                          final byte LF_DIR = 53;
                          // Create entry with directory link flag
                          TarArchiveEntry entry = new TarArchiveEntry("testDir", LF_DIR);
                          assertTrue(entry.isDirectory());
                      }

 @Test
                      public void testIsDirectory_WhenNameEndsWithSlashButLinkFlagNotDir() {
                          byte LF_NORMAL = (byte) '0'; // Normal file type in tar format
                          TarArchiveEntry entry = new TarArchiveEntry("testDir/", LF_NORMAL);
                          assertTrue(entry.isDirectory()); // Still true because name ends with /
                      }

 @Test
             public void testIsDirectoryWithNonDirectoryFile() throws Exception {
                 // Create a mock file that is NOT a directory
                 File mockFile = mock(File.class);
                 when(mockFile.isDirectory()).thenReturn(false);
                 when(mockFile.getPath()).thenReturn("test.txt");
                 when(mockFile.lastModified()).thenReturn(System.currentTimeMillis());
                 
                 // Create TarArchiveEntry with this file
                 TarArchiveEntry entry = new TarArchiveEntry(mockFile, "test.txt");
                 
                 // Set name to ensure it doesn't end with / (which would indicate directory)
                 entry.setName("test.txt");
                 
                 // Verify the method returns false (original behavior)
                 // Mutant would return true here
                 assertFalse(entry.isDirectory());
                 
                 // Verify interactions
                 verify(mockFile).isDirectory();
             }

 @Test
             public void testIsDirectoryWithDirectoryFile() throws Exception {
                 // Create a mock directory file
                 File mockDir = mock(File.class);
                 when(mockDir.isDirectory()).thenReturn(true);
                 when(mockDir.getPath()).thenReturn("/test/dir");
                 
                 // Create TarArchiveEntry with the directory file
                 TarArchiveEntry entry = new TarArchiveEntry(mockDir, "testDir");
                 
                 // This should return true for original code, but mutant returns false
                 assertTrue("Should return true for directory file", entry.isDirectory());
                 
                 // Verify the mock was called (ensures we tested the right path)
                 verify(mockDir).isDirectory();
             }

 @Test
             public void testIsDirectoryWithNonDirectoryFile1() throws Exception {
                 // Create a mock regular file
                 File mockFile = mock(File.class);
                 when(mockFile.isDirectory()).thenReturn(false);
                 when(mockFile.getPath()).thenReturn("/test/file.txt");
                 
                 // Create TarArchiveEntry with the regular file
                 TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testFile");
                 
                 // Should return false in both original and mutant
                 assertFalse("Should return false for regular file", entry.isDirectory());
             }

 @Test
            public void testIsDirectoryWithFileObject() throws Exception {
                // Test case for when file is a directory
                File mockDirectory = mock(File.class);
                when(mockDirectory.isDirectory()).thenReturn(true);
                TarArchiveEntry entryWithDir = new TarArchiveEntry(mockDirectory, "testDir/");
                assertTrue("Should return true for directory", entryWithDir.isDirectory());
        
                // Test case for when file is not a directory
                File mockFile = mock(File.class);
                when(mockFile.isDirectory()).thenReturn(false);
                TarArchiveEntry entryWithFile = new TarArchiveEntry(mockFile, "testFile");
                assertFalse("Should return false for non-directory", entryWithFile.isDirectory());
            }

 @Test
       public void testIsDirectoryWithFileObjectShouldDetectMutant() throws Exception {
           // Create test files (we'll mock them)
           File mockDirectory = mock(File.class);
           File mockFile = mock(File.class);
           
           // Set up mock behaviors
           when(mockDirectory.isDirectory()).thenReturn(true);
           when(mockDirectory.isFile()).thenReturn(false);
           when(mockFile.isDirectory()).thenReturn(false);
           when(mockFile.isFile()).thenReturn(true);
           
           // Create TarArchiveEntry instances with these files
           TarArchiveEntry dirEntry = new TarArchiveEntry(mockDirectory, "testDir");
           TarArchiveEntry fileEntry = new TarArchiveEntry(mockFile, "testFile");
           
           // Test directory case - should return true for original, false for mutant
           assertTrue("Directory should be recognized as directory", dirEntry.isDirectory());
           
           // Test file case - should return false for original, true for mutant
           assertFalse("File should not be recognized as directory", fileEntry.isDirectory());
       }

 @Test
     public void testIsDirectoryWithFileObject1() throws Exception {
         // Create a temporary directory
         File tempFile = File.createTempFile("temp", Long.toString(System.nanoTime()));
         tempFile.delete();
         tempFile.mkdir();
         File tempDir = tempFile;
         
         try {
             // Create TarArchiveEntry with the directory
             TarArchiveEntry entry = new TarArchiveEntry(tempDir);
             
             // Verify isDirectory() returns true for directory
             assertTrue("Should return true for directory", entry.isDirectory());
             
             // The mutant would return false here because it inverts file.isDirectory()
         } finally {
             // Clean up
             tempDir.delete();
         }
     }

 @Test
     public void testIsDirectoryWithFileObject2() throws Exception {
         // Create a mock directory file
         File mockDirectory = mock(File.class);
         when(mockDirectory.isDirectory()).thenReturn(true);
         when(mockDirectory.isFile()).thenReturn(false);
         
         // Create a TarArchiveEntry with the mock directory
         TarArchiveEntry entry = new TarArchiveEntry(mockDirectory, "testDir/");
         
         // Test the directory case - should return true
         assertTrue("Should return true for directory", entry.isDirectory());
         
         // Verify the mock interactions
         verify(mockDirectory).isDirectory();
         
         // Create a mock regular file
         File mockFile = mock(File.class);
         when(mockFile.isDirectory()).thenReturn(false);
         when(mockFile.isFile()).thenReturn(true);
         
         // Create a TarArchiveEntry with the mock file
         TarArchiveEntry fileEntry = new TarArchiveEntry(mockFile, "testFile");
         
         // Test the file case - should return false
         assertFalse("Should return false for regular file", fileEntry.isDirectory());
         
         // Verify the mock interactions
         verify(mockFile).isDirectory();
     }

}
