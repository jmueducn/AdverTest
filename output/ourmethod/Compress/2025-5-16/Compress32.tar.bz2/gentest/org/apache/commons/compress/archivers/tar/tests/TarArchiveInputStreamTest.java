package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class TarArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_AllHeaderTypes() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                                                                                                        Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                        setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                        headers.put("path", "new/path");
                                                                                                                                                                                                                                                                                        headers.put("linkpath", "link/path");
                                                                                                                                                                                                                                                                                        headers.put("gid", "1001");
                                                                                                                                                                                                                                                                                        headers.put("gname", "testgroup");
                                                                                                                                                                                                                                                                                        headers.put("uid", "1002");
                                                                                                                                                                                                                                                                                        headers.put("uname", "testuser");
                                                                                                                                                                                                                                                                                        headers.put("size", "1024");
                                                                                                                                                                                                                                                                                        headers.put("mtime", "1234567890.123");
                                                                                                                                                                                                                                                                                        headers.put("SCHILY.devminor", "1");
                                                                                                                                                                                                                                                                                        headers.put("SCHILY.devmajor", "2");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                                                        Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                        applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                                        assertEquals("new/path", entry.getName());
                                                                                                                                                                                                                                                                                        assertEquals("link/path", entry.getLinkName());
                                                                                                                                                                                                                                                                                        assertEquals(1001L, entry.getGroupId());
                                                                                                                                                                                                                                                                                        assertEquals("testgroup", entry.getGroupName());
                                                                                                                                                                                                                                                                                        assertEquals(1002L, entry.getUserId());
                                                                                                                                                                                                                                                                                        assertEquals("testuser", entry.getUserName());
                                                                                                                                                                                                                                                                                        assertEquals(1024L, entry.getSize());
                                                                                                                                                                                                                                                                                        assertEquals(1234567890123L, entry.getModTime());
                                                                                                                                                                                                                                                                                        assertEquals(1, entry.getDevMinor());
                                                                                                                                                                                                                                                                                        assertEquals(2, entry.getDevMajor());
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_EmptyHeaders() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                                                                                                                                        TarArchiveEntry originalEntry = new TarArchiveEntry("original");
                                                                                                                                                                                                                                                                                        originalEntry.setSize(500L);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                                                        setCurrentEntry.invoke(tarInput, originalEntry);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Execute - use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.invoke(tarInput, new HashMap<>());
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify - entry should remain unchanged
                                                                                                                                                                                                                                                                                        assertEquals("original", originalEntry.getName());
                                                                                                                                                                                                                                                                                        assertEquals(500L, originalEntry.getSize());
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_UnknownHeaders() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                                                        setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                        headers.put("unknown", "value");
                                                                                                                                                                                                                                                                                        headers.put("another", "123");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify - entry should remain unchanged except for known headers
                                                                                                                                                                                                                                                                                        assertEquals("test", entry.getName());
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_PartialUpdates() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("original");
                                                                                                                                                                                                                                                                                        entry.setSize(1000L);
                                                                                                                                                                                                                                                                                        entry.setUserId(500L);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                                                        setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                        headers.put("path", "updated/path");
                                                                                                                                                                                                                                                                                        headers.put("size", "2000");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify - only specified fields should be updated
                                                                                                                                                                                                                                                                                        assertEquals("updated/path", entry.getName());
                                                                                                                                                                                                                                                                                        assertEquals(2000L, entry.getSize());
                                                                                                                                                                                                                                                                                        assertEquals(500L, entry.getUserId()); // Should remain unchanged
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_MtimePrecision() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                                                        setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                        headers.put("mtime", "1234567890.987");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                        applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify - fractional seconds should be converted to milliseconds
                                                                                                                                                                                                                                                                                        assertEquals(1234567890987L, entry.getModTime());
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_EmptyStringValues() throws Exception {
                                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                                                                                                        Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                        setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                        headers.put("path", "");
                                                                                                                                                                                                                                                                                        headers.put("uname", "");
                                                                                                                                                                                                                                                                                        headers.put("gid", "123");
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                                                        Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                        applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                        applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                                        assertEquals("", entry.getName());
                                                                                                                                                                                                                                                                                        assertEquals("", entry.getUserName());
                                                                                                                                                                                                                                                                                        assertEquals(123L, entry.getGroupId());
                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                            public void testApplyPaxHeadersToCurrentEntry_InvalidNumberFormat() throws Exception {
                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                                                TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to set current entry (protected method)
                                                                                                                                                                                                                                                Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                headers.put("gid", "notanumber");
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to call private method and verify exception
                                                                                                                                                                                                                                                Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                    applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                                                                    fail("Expected NumberFormatException");
                                                                                                                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                    assertTrue(e.getCause() instanceof NumberFormatException);
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_DetectsKeyMutation() throws Exception {
                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                       TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                       TarArchiveEntry currEntry = new TarArchiveEntry("test");
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                       Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                       setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                       setCurrentEntryMethod.invoke(tarInput, currEntry);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create headers with multiple key types that should be processed
                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                       headers.put("path", "testPath");
                                                                                                                                                                                                       headers.put("gid", "123");
                                                                                                                                                                                                       headers.put("uname", "testUser");
                                                                                                                                                                                                       headers.put("size", "456");
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                       Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                       applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                       applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify - check that values were actually set
                                                                                                                                                                                                       // If mutation exists, none of these will match
                                                                                                                                                                                                       assertEquals("testPath", currEntry.getName());
                                                                                                                                                                                                       assertEquals(123L, currEntry.getGroupId());
                                                                                                                                                                                                       assertEquals("testUser", currEntry.getUserName());
                                                                                                                                                                                                       assertEquals(456L, currEntry.getSize());
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                              public void testApplyPaxHeadersToCurrentEntry_DetectsValueMutation() throws Exception {
                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                  TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                  Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                      "setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                  setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                  setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create headers with various non-empty values
                                                                                                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                  headers.put("path", "test/path"); // String
                                                                                                                                                                                                  headers.put("gid", "123"); // long
                                                                                                                                                                                                  headers.put("SCHILY.devminor", "456"); // int
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Call method
                                                                                                                                                                                                  Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                      "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                  method.invoke(tarInput, headers);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify values were properly set (would fail with mutant)
                                                                                                                                                                                                  assertEquals("test/path", entry.getName());
                                                                                                                                                                                                  assertEquals(123L, entry.getGroupId());
                                                                                                                                                                                                  assertEquals(456, entry.getDevMinor());
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Also verify no other values were set (would fail if mutant set empty values)
                                                                                                                                                                                                  assertEquals(0L, entry.getSize()); // wasn't in headers
                                                                                                                                                                                                  assertEquals(0, entry.getDevMajor()); // wasn't in headers
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_ShouldOnlySetNameForPathKey() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                             TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to set current entry
                                                                                                                                                                                             Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                             setCurrentEntry.setAccessible(true);
                                                                                                                                                                                             setCurrentEntry.invoke(inputStream, entry);
                                                                                                                                                                                             
                                                                                                                                                                                             // Create headers with both path and non-path entries
                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                             headers.put("path", "correct/path");  // Should set name
                                                                                                                                                                                             headers.put("linkpath", "some/link"); // Should not set name
                                                                                                                                                                                             headers.put("gid", "123");            // Should not set name
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to call private method
                                                                                                                                                                                             Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                             applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                             applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify
                                                                                                                                                                                             // Should only call setName once with the correct path value
                                                                                                                                                                                             verify(entry, times(1)).setName("correct/path");
                                                                                                                                                                                             // Verify no other setName calls were made
                                                                                                                                                                                             verify(entry, never()).setName(anyString());
                                                                                                                                                                                             // Verify other setters were called as expected
                                                                                                                                                                                             verify(entry).setLinkName("some/link");
                                                                                                                                                                                             verify(entry).setGroupId(123L);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_ShouldSetNameWhenPathHeaderExists() throws Exception {
                                                                                                                                                                                        // Setup
                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("originalName");
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to set current entry
                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                        setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                        
                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                        String expectedName = "test/path/name";
                                                                                                                                                                                        headers.put("path", expectedName);
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to call private method
                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                            "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                        applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify
                                                                                                                                                                                        assertEquals("Entry name should be set from path header", 
                                                                                                                                                                                                     expectedName, 
                                                                                                                                                                                                     entry.getName());
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                               public void testApplyPaxHeadersToCurrentEntry_ShouldSetCorrectPathName() throws Exception {
                                                                                                                                                                                   // Setup
                                                                                                                                                                                   TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                   TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                   
                                                                                                                                                                                   // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                   Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                   setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                   setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                                                                                                   
                                                                                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                   String expectedPath = "test/path/value";
                                                                                                                                                                                   headers.put("path", expectedPath);
                                                                                                                                                                                   
                                                                                                                                                                                   // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                   Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                   applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                   applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify
                                                                                                                                                                                   verify(mockEntry).setName(expectedPath);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                          public void testApplyPaxHeadersToCurrentEntry_ShouldOnlySetLinkNameForLinkpathKey() throws Exception {
                                                                                                                                                                              // Setup
                                                                                                                                                                              TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                              TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                              
                                                                                                                                                                              // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                              Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                              setCurrentEntry.setAccessible(true);
                                                                                                                                                                              setCurrentEntry.invoke(inputStream, entry);
                                                                                                                                                                              
                                                                                                                                                                              // Create headers with both linkpath and another key that would match 'true'
                                                                                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                                                                                              headers.put("linkpath", "correct-link");
                                                                                                                                                                              headers.put("gid", "incorrect-link"); // This should NOT set link name
                                                                                                                                                                              
                                                                                                                                                                              // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                              Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                              applyPaxHeaders.setAccessible(true);
                                                                                                                                                                              applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                                                                              
                                                                                                                                                                              // Verify
                                                                                                                                                                              assertEquals("correct-link", entry.getLinkName());
                                                                                                                                                                              // Additional verification that gid was processed correctly
                                                                                                                                                                              assertNotEquals("incorrect-link", entry.getLinkName());
                                                                                                                                                                              // The mutant would set link name to "incorrect-link" because of the 'true' condition
                                                                                                                                                                          }

    @Test
                                                                                                                                                                     public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldBeSetCorrectly() throws Exception {
                                                                                                                                                                         // Setup
                                                                                                                                                                         TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                         TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                         
                                                                                                                                                                         // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                         setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                                                                                         
                                                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                                                         String expectedLinkPath = "test/link/path";
                                                                                                                                                                         headers.put("linkpath", expectedLinkPath);
                                                                                                                                                                         
                                                                                                                                                                         // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                         Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                         applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                         applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                                                         
                                                                                                                                                                         // Verify
                                                                                                                                                                         verify(mockEntry).setLinkName(expectedLinkPath);
                                                                                                                                                                         // The mutant would set empty string instead, so this verification would fail
                                                                                                                                                                     }

    @Test
                                                                                                                                                                public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupId_WhenGidHeaderPresent() throws Exception {
                                                                                                                                                                    // Arrange
                                                                                                                                                                    TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                    TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                    Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                    setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                    setCurrentEntryMethod.invoke(tarInputStream, mockEntry);
                                                                                                                                                                    
                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                    headers.put("gid", "1234");  // Valid group ID
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                    Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                    applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Act
                                                                                                                                                                    applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                                                    
                                                                                                                                                                    // Assert
                                                                                                                                                                    verify(mockEntry).setGroupId(1234L);  // Verify group ID was set with parsed value
                                                                                                                                                                    // Also verify no other unexpected interactions
                                                                                                                                                                    verify(mockEntry, never()).setName(any());
                                                                                                                                                                    verify(mockEntry, never()).setLinkName(any());
                                                                                                                                                                    verify(mockEntry, never()).setGroupName(any());
                                                                                                                                                                    verify(mockEntry, never()).setUserId(anyLong());
                                                                                                                                                                    verify(mockEntry, never()).setUserName(any());
                                                                                                                                                                    verify(mockEntry, never()).setSize(anyLong());
                                                                                                                                                                    verify(mockEntry, never()).setModTime(anyLong());
                                                                                                                                                                    verify(mockEntry, never()).setDevMinor(anyInt());
                                                                                                                                                                    verify(mockEntry, never()).setDevMajor(anyInt());
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testApplyPaxHeadersToCurrentEntry_ShouldSetCorrectGroupId() throws Exception {
                                                                                                                                                                // Create test objects
                                                                                                                                                                TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                                String testGid = "12345";
                                                                                                                                                                headers.put("gid", testGid);
                                                                                                                                                                
                                                                                                                                                                // Create instance of class under test
                                                                                                                                                                TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                
                                                                                                                                                                // Set the current entry using reflection since setCurrentEntry is protected
                                                                                                                                                                Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                currEntryField.setAccessible(true);
                                                                                                                                                                currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                
                                                                                                                                                                // Call the method under test
                                                                                                                                                                Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                method.invoke(tarInputStream, headers);
                                                                                                                                                                
                                                                                                                                                                // Verify the group ID was set with the correct value
                                                                                                                                                                verify(mockEntry).setGroupId(Long.parseLong(testGid));
                                                                                                                                                                
                                                                                                                                                                // Additional verification that no other group ID was set
                                                                                                                                                                verify(mockEntry, never()).setGroupId(0);
                                                                                                                                                            }

    @Test
                                                                                                                                                          public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetGroupNameForNonGnameKey() throws Exception {
                                                                                                                                                              // Setup
                                                                                                                                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                              TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                              
                                                                                                                                                              // Use reflection to call protected setCurrentEntry method
                                                                                                                                                              Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                              setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                              setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                              
                                                                                                                                                              // Create headers with a key that doesn't match any condition before gname
                                                                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                                                                              String randomKey = "randomKey";
                                                                                                                                                              String randomValue = "randomValue";
                                                                                                                                                              headers.put(randomKey, randomValue);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                              Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                              applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                              applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                              
                                                                                                                                                              // Verify - group name should NOT be set for random key
                                                                                                                                                              assertNull("Group name should not be set for non-gname key", entry.getGroupName());
                                                                                                                                                              
                                                                                                                                                              // Additional verification that other fields weren't affected
                                                                                                                                                              assertEquals("test", entry.getName());
                                                                                                                                                              assertNull(entry.getLinkName());
                                                                                                                                                              assertEquals(0, entry.getUserId());
                                                                                                                                                              assertEquals(0, entry.getGroupId());
                                                                                                                                                          }

    @Test
                                                                                                                                                     public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameCorrectly() throws Exception {
                                                                                                                                                         // Create test data
                                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                                         String expectedGroupName = "testgroup";
                                                                                                                                                         headers.put("gname", expectedGroupName);
                                                                                                                                                         
                                                                                                                                                         // Create mock objects
                                                                                                                                                         TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                         
                                                                                                                                                         // Create instance
                                                                                                                                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                         
                                                                                                                                                         // Use reflection to set current entry
                                                                                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                         setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to call applyPaxHeadersToCurrentEntry
                                                                                                                                                         Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                         applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                         applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                         
                                                                                                                                                         // Verify the group name was set correctly
                                                                                                                                                         verify(mockEntry).setGroupName(expectedGroupName);
                                                                                                                                                         
                                                                                                                                                         // Additional verification that it wasn't set to empty string
                                                                                                                                                         verify(mockEntry, never()).setGroupName("");
                                                                                                                                                     }

    @Test
                                                                                                                                                public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserId_WhenUidHeaderPresent() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                    TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to call protected setCurrentEntry method
                                                                                                                                                    Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                    setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                    setCurrentEntryMethod.invoke(inputStream, currEntry);
                                                                                                                                                    
                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                    headers.put("uid", "1234");  // uid header with numeric value
                                                                                                                                                    
                                                                                                                                                    // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                    Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                    applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                    applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    verify(currEntry).setUserId(1234L);  // Verify userId was set with parsed value
                                                                                                                                                    // Additional verifications that other methods weren't called unexpectedly
                                                                                                                                                    verify(currEntry, never()).setName(any());
                                                                                                                                                    verify(currEntry, never()).setLinkName(any());
                                                                                                                                                    verify(currEntry, never()).setGroupId(anyLong());
                                                                                                                                                    verify(currEntry, never()).setGroupName(anyString());
                                                                                                                                                    verify(currEntry, never()).setUserName(anyString());
                                                                                                                                                    verify(currEntry, never()).setSize(anyLong());
                                                                                                                                                    verify(currEntry, never()).setModTime(anyLong());
                                                                                                                                                    verify(currEntry, never()).setDevMinor(anyInt());
                                                                                                                                                    verify(currEntry, never()).setDevMajor(anyInt());
                                                                                                                                                }

    @Test
                                                                                                                                            public void testApplyPaxHeadersToCurrentEntry_UserIdShouldBeSetFromHeader() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                
                                                                                                                                                // Use reflection to set the private currEntry field since there's no setter
                                                                                                                                                Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                currEntryField.setAccessible(true);
                                                                                                                                                currEntryField.set(tarInput, mockEntry);
                                                                                                                                                
                                                                                                                                                // Prepare test data with a non-zero uid
                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                headers.put("uid", "1234");  // Non-zero value
                                                                                                                                                
                                                                                                                                                // Call method
                                                                                                                                                Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                method.setAccessible(true);
                                                                                                                                                method.invoke(tarInput, headers);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                verify(mockEntry).setUserId(1234L);  // Should fail if mutant is present (would expect 0)
                                                                                                                                                
                                                                                                                                                // Clean up
                                                                                                                                                currEntryField.setAccessible(false);
                                                                                                                                            }

    @Test
                                                                                                                                          public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetUserNameForNonUnameKeys() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                              TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                              
                                                                                                                                              // Use reflection to access protected setCurrentEntry method
                                                                                                                                              Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                              setCurrentEntry.setAccessible(true);
                                                                                                                                              setCurrentEntry.invoke(inputStream, entry);
                                                                                                                                              
                                                                                                                                              // Create headers with a key that should NOT set userName
                                                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                                                              headers.put("someOtherKey", "wrongUserName");
                                                                                                                                              
                                                                                                                                              // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                              Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                              applyPaxHeaders.setAccessible(true);
                                                                                                                                              
                                                                                                                                              // Execute with non-uname key
                                                                                                                                              applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                                              
                                                                                                                                              // Verify - userName should NOT be set for non-"uname" keys
                                                                                                                                              assertNull("UserName should not be set for non-uname keys", entry.getUserName());
                                                                                                                                              
                                                                                                                                              // Additional verification with actual uname key
                                                                                                                                              headers.put("uname", "correctUserName");
                                                                                                                                              applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                                              assertEquals("UserName should be set for uname key", "correctUserName", entry.getUserName());
                                                                                                                                          }

    @Test
                                                                                                                                     public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserName_WhenUnameHeaderPresent() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                         TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                         
                                                                                                                                         // Use reflection to access protected setCurrentEntry method
                                                                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                                                                         setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                                                         
                                                                                                                                         // Prepare test data
                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                         String expectedUserName = "testuser";
                                                                                                                                         headers.put("uname", expectedUserName);
                                                                                                                                         
                                                                                                                                         // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                         Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                         applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                         applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                         
                                                                                                                                         // Verify
                                                                                                                                         verify(mockEntry).setUserName(expectedUserName);
                                                                                                                                     }

    @Test
                                                                                                                                 public void testApplyPaxHeadersToCurrentEntry_ShouldSetSizeWhenSizeHeaderPresent() throws Exception {
                                                                                                                                     // Setup
                                                                                                                                     TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                     
                                                                                                                                     // Use reflection to set the private currEntry field since there's no setter
                                                                                                                                     Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                     currEntryField.setAccessible(true);
                                                                                                                                     currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                     
                                                                                                                                     // Prepare headers with size value
                                                                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                                                                     String expectedSize = "1024";
                                                                                                                                     headers.put("size", expectedSize);
                                                                                                                                     
                                                                                                                                     // Call method
                                                                                                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                     method.setAccessible(true);
                                                                                                                                     method.invoke(tarInputStream, headers);
                                                                                                                                     
                                                                                                                                     // Verify
                                                                                                                                     verify(mockEntry).setSize(Long.parseLong(expectedSize));
                                                                                                                                 }

    @Test
                                                                                                                               public void testApplyPaxHeadersToCurrentEntry_SizeHeader_ShouldSetCorrectSize() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                   TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                   
                                                                                                                                   // Use reflection to call protected setCurrentEntry method
                                                                                                                                   Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                   setCurrentEntryMethod.setAccessible(true);
                                                                                                                                   setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                   
                                                                                                                                   // Create headers with a size value
                                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                                   String testSize = "12345";
                                                                                                                                   headers.put("size", testSize);
                                                                                                                                   
                                                                                                                                   // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                   Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                   applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                   applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertEquals("Entry size should be set to the parsed header value", 
                                                                                                                                               Long.parseLong(testSize), 
                                                                                                                                               entry.getSize());
                                                                                                                                   
                                                                                                                                   // Additional verification that no other properties were affected
                                                                                                                                   assertEquals("test", entry.getName());
                                                                                                                                   assertEquals(0, entry.getUserId());
                                                                                                                                   assertEquals(0, entry.getGroupId());
                                                                                                                                   assertEquals(0, entry.getDevMajor());
                                                                                                                                   assertEquals(0, entry.getDevMinor());
                                                                                                                               }

    @Test
                                                                                                                          public void testApplyPaxHeadersToCurrentEntry_ShouldNotProcessUnknownKeyAsMtime() throws Exception {
                                                                                                                              // Setup
                                                                                                                              TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                              TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                              
                                                                                                                              // Use reflection to set current entry (protected method)
                                                                                                                              Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                              setCurrentEntry.setAccessible(true);
                                                                                                                              setCurrentEntry.invoke(inputStream, entry);
                                                                                                                              
                                                                                                                              // Create headers with an unknown key that should NOT be processed as mtime
                                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                                              headers.put("unknown_key", "123.456"); // This should not be treated as mtime
                                                                                                                              
                                                                                                                              // Use reflection to call applyPaxHeadersToCurrentEntry (private method)
                                                                                                                              Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                              applyPaxHeaders.setAccessible(true);
                                                                                                                              applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                              
                                                                                                                              // Verification
                                                                                                                              // Original behavior: mtime remains 0 (default) since "unknown_key" is not processed
                                                                                                                              // Mutant behavior: would set mtime to 123456 (123.456 * 1000)
                                                                                                                              assertEquals(0, entry.getModTime());
                                                                                                                              
                                                                                                                              // Additional verification that no other properties were set
                                                                                                                              assertNull(entry.getLinkName());
                                                                                                                              assertEquals(0, entry.getUserId());
                                                                                                                              assertEquals(0, entry.getGroupId());
                                                                                                                              // ... other properties should remain at default values
                                                                                                                          }

    @Test
                                                                                                                     public void testApplyPaxHeadersToCurrentEntry_ModTimeConversion() throws Exception {
                                                                                                                         // Setup
                                                                                                                         TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                         TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                         
                                                                                                                         // Use reflection to call protected setCurrentEntry method
                                                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                                                         setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                                         
                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                         String testTime = "1.5"; // Should convert to 1500 milliseconds
                                                                                                                         headers.put("mtime", testTime);
                                                                                                                         
                                                                                                                         // Expected calculation
                                                                                                                         long expectedTime = (long)(Double.parseDouble(testTime) * 1000);
                                                                                                                         
                                                                                                                         // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                         Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                         applyPaxHeadersMethod.setAccessible(true);
                                                                                                                         applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                         
                                                                                                                         // Verify
                                                                                                                         verify(mockEntry).setModTime(expectedTime);
                                                                                                                         
                                                                                                                         // Additional verification that it's not setting to 0
                                                                                                                         verify(mockEntry, never()).setModTime(0);
                                                                                                                     }

    @Test
                                                                                                                public void testApplyPaxHeadersToCurrentEntry_ShouldSetDevMinorWhenSCHILYDevminorHeaderPresent() throws Exception {
                                                                                                                    // Setup
                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                    TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setCurrentEntry method
                                                                                                                    Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                        "setCurrentEntry", TarArchiveEntry.class);
                                                                                                                    setCurrentEntryMethod.setAccessible(true);
                                                                                                                    setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                    
                                                                                                                    // Create headers with SCHILY.devminor
                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                    headers.put("SCHILY.devminor", "123");
                                                                                                                    
                                                                                                                    // Mock the entry to verify setDevMinor is called
                                                                                                                    TarArchiveEntry spyEntry = spy(entry);
                                                                                                                    setCurrentEntryMethod.invoke(tarInput, spyEntry);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                        "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                    method.setAccessible(true);
                                                                                                                    method.invoke(tarInput, headers);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    verify(spyEntry).setDevMinor(123);
                                                                                                                    
                                                                                                                    // Also verify the value was actually set
                                                                                                                    assertEquals(123, entry.getDevMinor());
                                                                                                                }

    @Test
                                                                                                           public void testApplyPaxHeadersToCurrentEntry_DevMinor() throws Exception {
                                                                                                               // Create test data
                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                               headers.put("SCHILY.devminor", "123"); // Non-zero test value
                                                                                                               
                                                                                                               // Create mock objects
                                                                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                               
                                                                                                               // Create instance of class under test
                                                                                                               TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                               
                                                                                                               // Use reflection to set current entry
                                                                                                               Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                   "setCurrentEntry", TarArchiveEntry.class);
                                                                                                               setCurrentEntryMethod.setAccessible(true);
                                                                                                               setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                               
                                                                                                               // Call the method under test
                                                                                                               Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                   "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                               method.setAccessible(true);
                                                                                                               method.invoke(tarInput, headers);
                                                                                                               
                                                                                                               // Verify the behavior - should call setDevMinor with parsed value (123)
                                                                                                               verify(mockEntry).setDevMinor(123);
                                                                                                               
                                                                                                               // Additional verification that other methods weren't called unexpectedly
                                                                                                               verify(mockEntry, never()).setDevMinor(0);
                                                                                                           }

    @Test
                                                                                                      public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetDevMajorForUnrelatedKey() throws Exception {
                                                                                                          // Setup
                                                                                                          TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                          TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                          
                                                                                                          // Use reflection to call protected setCurrentEntry method
                                                                                                          Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                          setCurrentEntry.setAccessible(true);
                                                                                                          setCurrentEntry.invoke(inputStream, entry);
                                                                                                          
                                                                                                          // Create headers with an unrelated key that should not set devMajor
                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                          headers.put("unrelated_key", "123");  // This should not trigger devMajor setting
                                                                                                          
                                                                                                          // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                          Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                          applyPaxHeaders.setAccessible(true);
                                                                                                          applyPaxHeaders.invoke(inputStream, headers);
                                                                                                          
                                                                                                          // Verify - original code would leave devMajor as 0, mutant would set it to 123
                                                                                                          assertEquals(0, entry.getDevMajor());
                                                                                                          
                                                                                                          // Additional verification that other fields weren't affected
                                                                                                          assertEquals("test", entry.getName());  // Original name should remain
                                                                                                          assertEquals(0, entry.getDevMinor());   // DevMinor should remain unset
                                                                                                      }

    @Test
                                                                                                  public void testApplyPaxHeadersToCurrentEntry_LinkPath() throws Exception {
                                                                                                      // Setup
                                                                                                      TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                      TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                      
                                                                                                      // Use reflection to set the private currEntry field since there's no setter
                                                                                                      Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                      currEntryField.setAccessible(true);
                                                                                                      currEntryField.set(inputStream, mockEntry);
                                                                                                      
                                                                                                      Map<String, String> headers = new HashMap<>();
                                                                                                      String expectedLinkPath = "test/link/path";
                                                                                                      headers.put("linkpath", expectedLinkPath);
                                                                                                      
                                                                                                      // Exercise
                                                                                                      Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                      method.setAccessible(true);
                                                                                                      method.invoke(inputStream, headers);
                                                                                                      
                                                                                                      // Verify
                                                                                                      verify(mockEntry).setLinkName(expectedLinkPath);  // This will fail if the mutant is present
                                                                                                  }

    @Test
                                                                                                 public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameCorrectly1() throws Exception {
                                                                                                     // Setup
                                                                                                     TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                     
                                                                                                     // Use reflection to set the private currEntry field since there's no setter
                                                                                                     Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                     currEntryField.setAccessible(true);
                                                                                                     currEntryField.set(inputStream, mockEntry);
                                                                                                     
                                                                                                     // Prepare headers with gname entry
                                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                                     String expectedGroupName = "testgroup";
                                                                                                     headers.put("gname", expectedGroupName);
                                                                                                     
                                                                                                     // Call method
                                                                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                     method.setAccessible(true);
                                                                                                     method.invoke(inputStream, headers);
                                                                                                     
                                                                                                     // Verify group name was set correctly
                                                                                                     verify(mockEntry).setGroupName(expectedGroupName);
                                                                                                     
                                                                                                     // Additional verification that it wasn't set to empty string
                                                                                                     verify(mockEntry, never()).setGroupName("");
                                                                                                 }

    @Test
                                                                                               public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserId_WhenUidHeaderPresent1() throws Exception {
                                                                                                   // Setup
                                                                                                   TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                   TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                   
                                                                                                   // Use reflection to call protected setCurrentEntry method
                                                                                                   Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                   setCurrentEntryMethod.setAccessible(true);
                                                                                                   setCurrentEntryMethod.invoke(inputStream, currEntry);
                                                                                                   
                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                   headers.put("uid", "1234");  // Test with a valid user ID
                                                                                                   
                                                                                                   // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                   Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                   applyPaxHeadersMethod.setAccessible(true);
                                                                                                   applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                   
                                                                                                   // Verify
                                                                                                   verify(currEntry).setUserId(1234L);  // Verify the user ID was set correctly
                                                                                                   // If mutant is present, this verification will fail since setUserId won't be called
                                                                                               }

    @Test
                                                                                          public void testApplyPaxHeadersToCurrentEntry_UserId_ShouldSetCorrectValue() throws Exception {
                                                                                              // Setup
                                                                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                              TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                              
                                                                                              // Use reflection to access protected setCurrentEntry method
                                                                                              Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                              setCurrentEntryMethod.setAccessible(true);
                                                                                              setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                              
                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                              headers.put("uid", "1234"); // Non-zero user ID
                                                                                              
                                                                                              // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                              Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                              applyPaxHeadersMethod.setAccessible(true);
                                                                                              applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                              
                                                                                              // Verify
                                                                                              verify(mockEntry).setUserId(1234L); // Should fail if mutant is present (would expect 0)
                                                                                              
                                                                                              // Additional verification that no other unexpected interactions occurred
                                                                                              verify(mockEntry, times(1)).setUserId(anyLong());
                                                                                              verifyNoMoreInteractions(mockEntry);
                                                                                          }

    @Test
                                                                                      public void testApplyPaxHeadersToCurrentEntry_ShouldSetCorrectModTime() throws Exception {
                                                                                          // Setup
                                                                                          TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                          TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                          
                                                                                          // Use reflection to set the private currEntry field since there's no setter
                                                                                          Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                          currEntryField.setAccessible(true);
                                                                                          currEntryField.set(tarInputStream, mockEntry);
                                                                                          
                                                                                          // Prepare test data
                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                          String testTime = "123456.789"; // Should become 123456789 after conversion
                                                                                          headers.put("mtime", testTime);
                                                                                          
                                                                                          // Call method
                                                                                          Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                          method.setAccessible(true);
                                                                                          method.invoke(tarInputStream, headers);
                                                                                          
                                                                                          // Verify
                                                                                          verify(mockEntry).setModTime(123456789L); // This will fail if mutant is present (would expect 0)
                                                                                      }

    @Test
                                                                                    public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldBeSetCorrectly1() throws Exception {
                                                                                        // Setup
                                                                                        TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                        TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                        
                                                                                        // Use reflection to call protected setCurrentEntry
                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                        setCurrentEntry.setAccessible(true);
                                                                                        setCurrentEntry.invoke(inputStream, mockEntry);
                                                                                        
                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                        String expectedLinkPath = "test/link/path";
                                                                                        headers.put("linkpath", expectedLinkPath);
                                                                                        
                                                                                        // Use reflection to call private applyPaxHeadersToCurrentEntry
                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                        applyPaxHeaders.invoke(inputStream, headers);
                                                                                        
                                                                                        // Verify
                                                                                        verify(mockEntry).setLinkName(eq(expectedLinkPath));
                                                                                        // This will fail if the mutant is present since it would call setLinkName(null) instead
                                                                                    }

    @Test
                                                                                public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldUseActualValue() throws Exception {
                                                                                    // Setup
                                                                                    TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                    TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                    
                                                                                    // Use reflection to set the private currEntry field since there's no setter
                                                                                    Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                    currEntryField.setAccessible(true);
                                                                                    currEntryField.set(tarInputStream, mockEntry);
                                                                                    
                                                                                    // Prepare test data
                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                    String expectedLinkPath = "test/link/path";
                                                                                    headers.put("linkpath", expectedLinkPath);
                                                                                    
                                                                                    // Call method
                                                                                    Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(tarInputStream, headers);
                                                                                    
                                                                                    // Verify
                                                                                    verify(mockEntry).setLinkName(eq(expectedLinkPath)); // This will fail if mutant is present
                                                                                    verify(mockEntry, never()).setLinkName(eq("mutated_value")); // Explicit check for mutant
                                                                                }

    @Test
                                                                              public void testApplyPaxHeadersToCurrentEntryWithNullKey() {
                                                                                  // Setup
                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                  headers.put(null, "123"); // Add null key to test NPE safety
                                                                                  
                                                                                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                  
                                                                                  // Use reflection to set the private currEntry field since there's no setter
                                                                                  try {
                                                                                      Field field = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                      field.setAccessible(true);
                                                                                      field.set(tarInput, mockEntry);
                                                                                  } catch (Exception e) {
                                                                                      fail("Failed to set currEntry field via reflection");
                                                                                  }
                                                                                  
                                                                                  // Execute - should not throw exception
                                                                                  try {
                                                                                      // Use reflection to access private method
                                                                                      Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                          "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                      method.setAccessible(true);
                                                                                      method.invoke(tarInput, headers);
                                                                                  } catch (NullPointerException e) {
                                                                                      fail("Method threw NullPointerException when handling null key - mutant detected!");
                                                                                  } catch (Exception e) {
                                                                                      fail("Failed to invoke applyPaxHeadersToCurrentEntry via reflection: " + e.getMessage());
                                                                                  }
                                                                                  
                                                                                  // Verify no interactions occurred for null key
                                                                                  verify(mockEntry, never()).setUserId(anyLong());
                                                                                  verify(mockEntry, never()).setUserName(anyString());
                                                                                  // Verify no other unexpected interactions
                                                                                  verifyNoMoreInteractions(mockEntry);
                                                                              }

    @Test
                                                                         public void testApplyPaxHeadersToCurrentEntry_UserId() throws Exception {
                                                                             // Create test data
                                                                             Map<String, String> headers = new HashMap<>();
                                                                             headers.put("uid", "1001");  // Test with a specific user ID
                                                                             
                                                                             // Create mock for currEntry
                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                             
                                                                             // Create instance of class under test
                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                             
                                                                             // Use reflection to set current entry
                                                                             Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                             setCurrentEntryMethod.setAccessible(true);
                                                                             setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                             
                                                                             // Use reflection to call private method
                                                                             Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                             applyPaxHeadersMethod.setAccessible(true);
                                                                             applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                             
                                                                             // Verify the userId was set exactly to the value from headers (not value+1)
                                                                             verify(mockEntry).setUserId(1001L);  // This will fail if mutant exists (would expect 1002)
                                                                             
                                                                             // Additional verification that no other unexpected interactions occurred
                                                                             verifyNoMoreInteractions(mockEntry);
                                                                         }

    @Test
                                                                    public void testApplyPaxHeadersToCurrentEntry_uidShouldUseHeaderValue() throws Exception {
                                                                        // Setup
                                                                        TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                        TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                        
                                                                        // Use reflection to access protected setCurrentEntry method
                                                                        Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                        setCurrentEntryMethod.setAccessible(true);
                                                                        setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                        
                                                                        // Prepare test data with non-zero uid
                                                                        Map<String, String> headers = new HashMap<>();
                                                                        headers.put("uid", "1001");  // Non-zero test value
                                                                        
                                                                        // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                        Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                        applyPaxHeadersMethod.setAccessible(true);
                                                                        applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                        
                                                                        // Verify
                                                                        verify(mockEntry).setUserId(1001L);  // Should use the value from headers
                                                                        // If mutant exists, this would fail as it would expect setUserId(0L)
                                                                    }

    @Test
                                                           public void testApplyPaxHeadersToCurrentEntry_ModTimeCalculation() throws Exception {
                                                               // Setup
                                                               TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                               
                                                               // Use reflection to set current entry (protected method)
                                                               Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                               setCurrentEntryMethod.setAccessible(true);
                                                               setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                               
                                                               Map<String, String> headers = new HashMap<>();
                                                               String testTime = "1.234"; // 1.234 seconds
                                                               headers.put("mtime", testTime);
                                                               
                                                               // Expected value calculation (original behavior)
                                                               long expectedMillis = (long)(Double.parseDouble(testTime) * 1000);
                                                               
                                                               // Use reflection to call private method
                                                               Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                               applyPaxHeadersMethod.setAccessible(true);
                                                               applyPaxHeadersMethod.invoke(tarInput, headers);
                                                               
                                                               // Verify
                                                               verify(mockEntry).setModTime(expectedMillis);
                                                               
                                                               // Also verify no other unexpected interactions
                                                               verifyNoMoreInteractions(mockEntry);
                                                           }

    @Test
                                                      public void testApplyPaxHeadersToCurrentEntry_ModTimeConversion1() throws Exception {
                                                          // Setup
                                                          TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                          TarArchiveEntry entry = new TarArchiveEntry("test");
                                                          
                                                          // Use reflection to call protected setCurrentEntry method
                                                          Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                          setCurrentEntryMethod.setAccessible(true);
                                                          setCurrentEntryMethod.invoke(inputStream, entry);
                                                          
                                                          // Create headers with mtime value (1.5 seconds)
                                                          Map<String, String> headers = new HashMap<>();
                                                          headers.put("mtime", "1.5");
                                                          
                                                          // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                          Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                          applyPaxHeadersMethod.setAccessible(true);
                                                          applyPaxHeadersMethod.invoke(inputStream, headers);
                                                          
                                                          // Verify
                                                          // Original should convert seconds to milliseconds (1.5 * 1000 = 1500)
                                                          // Mutant would keep it as 1 (1.5 cast to long)
                                                          assertEquals(1500L, entry.getModTime());
                                                          
                                                          // Additional verification that other headers aren't affected
                                                          assertEquals("test", entry.getName()); // name shouldn't change
                                                      }

    @Test
                                                 public void testApplyPaxHeadersToCurrentEntry_DevMajor() throws Exception {
                                                     // Setup
                                                     TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                     
                                                     // Use reflection to access protected setCurrentEntry method
                                                     Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                         "setCurrentEntry", TarArchiveEntry.class);
                                                     setCurrentEntryMethod.setAccessible(true);
                                                     setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                     
                                                     Map<String, String> headers = new HashMap<>();
                                                     headers.put("SCHILY.devmajor", "12345");
                                                     
                                                     // Execute
                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                         "applyPaxHeadersToCurrentEntry", Map.class);
                                                     method.setAccessible(true);
                                                     method.invoke(tarInput, headers);
                                                     
                                                     // Verify
                                                     verify(mockEntry).setDevMajor(12345); // This would fail if using valueOf() instead of parseInt()
                                                     
                                                     // Additional test with edge case value
                                                     headers.put("SCHILY.devmajor", "0");
                                                     method.invoke(tarInput, headers);
                                                     verify(mockEntry).setDevMajor(0);
                                                     
                                                     // Test with minimum integer value
                                                     headers.put("SCHILY.devmajor", String.valueOf(Integer.MIN_VALUE));
                                                     method.invoke(tarInput, headers);
                                                     verify(mockEntry).setDevMajor(Integer.MIN_VALUE);
                                                 }

    @Test
                                            public void testApplyPaxHeadersToCurrentEntry_DevMajorWithDecimal_ShouldDetectMutant() throws Exception {
                                                // Setup
                                                TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                
                                                // Use reflection to access protected setCurrentEntry method
                                                Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                setCurrentEntryMethod.setAccessible(true);
                                                setCurrentEntryMethod.invoke(inputStream, currEntry);
                                                
                                                Map<String, String> headers = new HashMap<>();
                                                // This value will expose the mutant:
                                                // - Integer.parseInt("123.45") throws NumberFormatException
                                                // - (int)Double.parseDouble("123.45") returns 123
                                                headers.put("SCHILY.devmajor", "123.45");
                                                
                                                // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                applyPaxHeadersMethod.setAccessible(true);
                                                
                                                // Execute
                                                try {
                                                    applyPaxHeadersMethod.invoke(inputStream, headers);
                                                    // If we get here, the mutant survived (parseDouble worked)
                                                    fail("Expected NumberFormatException not thrown - mutant survived");
                                                } catch (InvocationTargetException e) {
                                                    if (!(e.getCause() instanceof NumberFormatException)) {
                                                        fail("Expected NumberFormatException but got " + e.getCause().getClass());
                                                    }
                                                    // This is expected for original code
                                                    // Verify no interaction with currEntry since parsing failed
                                                    verify(currEntry, never()).setDevMajor(anyInt());
                                                }
                                                
                                                // Additional test case for scientific notation
                                                headers.put("SCHILY.devmajor", "1.23e2");
                                                try {
                                                    applyPaxHeadersMethod.invoke(inputStream, headers);
                                                    fail("Expected NumberFormatException not thrown - mutant survived");
                                                } catch (InvocationTargetException e) {
                                                    if (!(e.getCause() instanceof NumberFormatException)) {
                                                        fail("Expected NumberFormatException but got " + e.getCause().getClass());
                                                    }
                                                    verify(currEntry, never()).setDevMajor(anyInt());
                                                }
                                                
                                                // Test with valid integer to ensure normal case works
                                                headers.put("SCHILY.devmajor", "123");
                                                applyPaxHeadersMethod.invoke(inputStream, headers);
                                                verify(currEntry).setDevMajor(123);
                                            }

    @Test
                                       public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldBeSet() throws Exception {
                                           // Setup
                                           TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                           TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                           
                                           // Use reflection to set current entry (protected method)
                                           Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                           setCurrentEntryMethod.setAccessible(true);
                                           setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                           
                                           // Prepare test data
                                           Map<String, String> headers = new HashMap<>();
                                           String testLinkPath = "test/link/path";
                                           headers.put("linkpath", testLinkPath);
                                           
                                           // Use reflection to call private method
                                           Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                           applyPaxHeadersMethod.setAccessible(true);
                                           applyPaxHeadersMethod.invoke(inputStream, headers);
                                           
                                           // Verify
                                           verify(mockEntry).setLinkName(testLinkPath);  // This will fail if mutant is present
                                       }

    @Test
                                  public void testApplyPaxHeadersToCurrentEntry_LinkPathWithWhitespace() throws Exception {
                                      // Setup
                                      TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                      TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                      
                                      // Use reflection to call protected setCurrentEntry method
                                      Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                      setCurrentEntryMethod.setAccessible(true);
                                      setCurrentEntryMethod.invoke(tarInput, currEntry);
                                      
                                      // Create headers with linkpath containing whitespace
                                      Map<String, String> headers = new HashMap<>();
                                      String linkPathWithSpaces = "  symlink  ";
                                      headers.put("linkpath", linkPathWithSpaces);
                                      
                                      // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                      Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                      applyPaxHeadersMethod.setAccessible(true);
                                      applyPaxHeadersMethod.invoke(tarInput, headers);
                                      
                                      // Verify
                                      // Original version should preserve spaces, mutated version would trim
                                      verify(currEntry).setLinkName(eq(linkPathWithSpaces));  // Fails if mutant exists (would expect trimmed version)
                                      
                                      // Additional verification that no other unexpected calls were made
                                      verifyNoMoreInteractions(currEntry);
                                  }

    @Test
                             public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupName_WhenGnameHeaderPresent() {
                                 // Arrange
                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                 TarArchiveEntry currEntry = new TarArchiveEntry("testEntry");
                                 
                                 // Use reflection to set current entry
                                 try {
                                     Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                         "setCurrentEntry", TarArchiveEntry.class);
                                     setCurrentEntryMethod.setAccessible(true);
                                     setCurrentEntryMethod.invoke(tarInput, currEntry);
                                 } catch (Exception e) {
                                     fail("Failed to set current entry via reflection: " + e.getMessage());
                                 }
                                 
                                 Map<String, String> headers = new HashMap<>();
                                 String expectedGroupName = "testGroup";
                                 headers.put("gname", expectedGroupName);
                                 
                                 // Act - using reflection to test private method
                                 try {
                                     Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                         "applyPaxHeadersToCurrentEntry", Map.class);
                                     method.setAccessible(true);
                                     method.invoke(tarInput, headers);
                                 } catch (Exception e) {
                                     fail("Failed to invoke method via reflection: " + e.getMessage());
                                 }
                                 
                                 // Assert
                                 assertEquals("Group name should be set to the provided value", 
                                            expectedGroupName, currEntry.getGroupName());
                             }

    @Test
                             public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupName_WhenGnameHeaderPresent1() throws Exception {
                                 // Arrange
                                 InputStream dummyStream = new ByteArrayInputStream(new byte[0]);
                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(dummyStream);
                                 TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                 
                                 // Use reflection to access protected setCurrentEntry method
                                 Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                 setCurrentEntryMethod.setAccessible(true);
                                 setCurrentEntryMethod.invoke(tarInput, currEntry);
                                 
                                 Map<String, String> headers = new HashMap<>();
                                 String expectedGroupName = "testGroup";
                                 headers.put("gname", expectedGroupName);
                                 
                                 // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                 Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                 applyPaxHeadersMethod.setAccessible(true);
                                 
                                 // Act
                                 applyPaxHeadersMethod.invoke(tarInput, headers);
                                 
                                 // Assert
                                 verify(currEntry).setGroupName(expectedGroupName);
                             }

    @Test
                         public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameFromHeaders() throws Exception {
                             // Setup
                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                             
                             // Use reflection to set the private currEntry field since there's no public setter
                             Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                             currEntryField.setAccessible(true);
                             currEntryField.set(tarInputStream, mockEntry);
                             
                             // Prepare test data
                             Map<String, String> headers = new HashMap<>();
                             String expectedGroupName = "testGroup";
                             headers.put("gname", expectedGroupName);
                             
                             // Call method
                             Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                             method.setAccessible(true);
                             method.invoke(tarInputStream, headers);
                             
                             // Verify
                             verify(mockEntry).setGroupName(expectedGroupName);  // This will fail if the mutant is present
                             // Also verify no other unexpected interactions
                             verifyNoMoreInteractions(mockEntry);
                         }

    @Test
                       public void testApplyPaxHeadersToCurrentEntry_UserIdHandling() throws Exception {
                           // Setup
                           TarArchiveInputStream stream = new TarArchiveInputStream(mock(InputStream.class));
                           TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                           
                           // Use reflection to call protected setCurrentEntry
                           Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                           setCurrentEntry.setAccessible(true);
                           setCurrentEntry.invoke(stream, mockEntry);
                           
                           // Get the private applyPaxHeadersToCurrentEntry method
                           Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                           applyPaxHeaders.setAccessible(true);
                           
                           // Test case 1: Normal case (within int range)
                           Map<String, String> headers1 = new HashMap<>();
                           headers1.put("uid", "12345");
                           applyPaxHeaders.invoke(stream, headers1);
                           verify(mockEntry).setUserId(12345L);  // Should parse as long
                           
                           // Test case 2: Edge case (exactly Integer.MAX_VALUE)
                           Map<String, String> headers2 = new HashMap<>();
                           headers2.put("uid", "2147483647");  // Integer.MAX_VALUE
                           applyPaxHeaders.invoke(stream, headers2);
                           verify(mockEntry).setUserId(2147483647L);
                           
                           // Test case 3: Large value case (exceeds Integer.MAX_VALUE)
                           Map<String, String> headers3 = new HashMap<>();
                           String largeUid = "2147483648";  // Integer.MAX_VALUE + 1
                           headers3.put("uid", largeUid);
                           applyPaxHeaders.invoke(stream, headers3);
                           verify(mockEntry).setUserId(2147483648L);
                           
                           // Test case 4: Very large value case
                           Map<String, String> headers4 = new HashMap<>();
                           String veryLargeUid = "9223372036854775807";  // Long.MAX_VALUE
                           headers4.put("uid", veryLargeUid);
                           applyPaxHeaders.invoke(stream, headers4);
                           verify(mockEntry).setUserId(Long.MAX_VALUE);
                       }

    @Test
              public void testApplyPaxHeadersToCurrentEntry_uidWithWhitespace_shouldThrowException() throws Exception {
                  // Prepare test data
                  Map<String, String> headers = new HashMap<>();
                  headers.put("uid", " 123 ");  // Value with whitespace
                  
                  // Create mock objects
                  InputStream mockInputStream = mock(InputStream.class);
                  TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                  
                  // Use reflection to set currentEntry since it's private
                  Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                  currentEntryField.setAccessible(true);
                  currentEntryField.set(tarInputStream, mockEntry);
                  
                  // Get the private method using reflection
                  Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                      "applyPaxHeadersToCurrentEntry", Map.class);
                  applyPaxHeadersMethod.setAccessible(true);
                  
                  try {
                      // Invoke the private method
                      applyPaxHeadersMethod.invoke(tarInputStream, headers);
                      fail("Expected NumberFormatException to be thrown");
                  } catch (InvocationTargetException e) {
                      // Check if the cause is NumberFormatException
                      assertTrue(e.getCause() instanceof NumberFormatException);
                  }
                  
                  // Verify setUserId was never called (since exception should be thrown first)
                  verify(mockEntry, never()).setUserId(anyLong());
              }

    @Test
              public void testApplyPaxHeadersToCurrentEntry_uidWithoutWhitespace_shouldSetCorrectValue() throws Exception {
                  // Prepare test data
                  Map<String, String> headers = new HashMap<>();
                  headers.put("uid", "123");  // Value without whitespace
                  
                  // Create mock objects
                  InputStream mockInputStream = mock(InputStream.class);
                  TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                  
                  // Use reflection to set the current entry (private field)
                  Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                  currentEntryField.setAccessible(true);
                  currentEntryField.set(tarInputStream, mockEntry);
                  
                  // Use reflection to access the private method
                  Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                      "applyPaxHeadersToCurrentEntry", Map.class);
                  applyPaxHeadersMethod.setAccessible(true);
                  
                  // Call the method under test using reflection
                  applyPaxHeadersMethod.invoke(tarInputStream, headers);
                  
                  // Verify setUserId was called with the correct parsed value
                  verify(mockEntry).setUserId(123L);
              }

    @Test
         public void testApplyPaxHeadersToCurrentEntry_ShouldCorrectlyConvertMtime() throws Exception {
             // Setup
             TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
             TarArchiveEntry entry = mock(TarArchiveEntry.class);
             
             // Use reflection to call protected setCurrentEntry method
             Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
             setCurrentEntryMethod.setAccessible(true);
             setCurrentEntryMethod.invoke(tarInput, entry);
             
             Map<String, String> headers = new HashMap<>();
             headers.put("mtime", "1.5"); // 1.5 seconds
             
             // Use reflection to call private applyPaxHeadersToCurrentEntry method
             Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
             applyPaxHeadersMethod.setAccessible(true);
             applyPaxHeadersMethod.invoke(tarInput, headers);
             
             // Verify
             // Original should convert to 1500 milliseconds (1.5 * 1000)
             // Mutant would convert to 150 (1.5 * 100)
             verify(entry).setModTime(1500L);
             
             // Additional verification that no other time-related fields are set
             verify(entry, never()).setModTime(150L); // Explicitly check mutant would fail
         }

    @Test
    public void testApplyPaxHeadersToCurrentEntry_ShouldHandleDecimalMtime() throws Exception {
        // Setup
        TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
        TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
        
        // Use reflection to set current entry
        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
        setCurrentEntry.setAccessible(true);
        setCurrentEntry.invoke(inputStream, mockEntry);
        
        Map<String, String> headers = new HashMap<>();
        String decimalTime = "123.456";
        headers.put("mtime", decimalTime);
        
        // Expected calculation
        double expectedSeconds = Double.parseDouble(decimalTime);
        long expectedMillis = (long)(expectedSeconds * 1000);
        
        // Use reflection to call private method
        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
        applyPaxHeaders.setAccessible(true);
        applyPaxHeaders.invoke(inputStream, headers);
        
        // Verify
        verify(mockEntry).setModTime(expectedMillis);
        
        // Additional test with pure integer to ensure both formats work
        headers.put("mtime", "123");
        expectedMillis = 123L * 1000;
        applyPaxHeaders.invoke(inputStream, headers);
        verify(mockEntry).setModTime(expectedMillis);
    }


}
