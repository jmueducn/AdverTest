package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                                     public void testFinish_WithNullBuffer_DoesNotThrow() throws Exception {
                                                                                                                                                                                         // Setup
                                                                                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                         
                                                                                                                                                                                         // Set buffer to null
                                                                                                                                                                                         java.lang.reflect.Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                         bufferField.setAccessible(true);
                                                                                                                                                                                         bufferField.set(tarOut, null);
                                                                                                                                                                                 
                                                                                                                                                                                         // Ensure haveUnclosedEntry is false
                                                                                                                                                                                         java.lang.reflect.Field unclosedField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                         unclosedField.setAccessible(true);
                                                                                                                                                                                         unclosedField.set(tarOut, false);
                                                                                                                                                                                 
                                                                                                                                                                                         // Test - should complete without throwing
                                                                                                                                                                                         tarOut.finish();
                                                                                                                                                                                     }

 @Test
                                                                                                                                                                             public void testFinish_WithClosedEntry_WritesTwoEOFRecords() throws Exception {
                                                                                                                                                                                 // Setup - use real output stream to verify writes
                                                                                                                                                                                 ByteArrayOutputStream realOut = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(realOut);
                                                                                                                                                                                 
                                                                                                                                                                                 // Ensure haveUnclosedEntry is false (default)
                                                                                                                                                                                 java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 field.setAccessible(true);
                                                                                                                                                                                 field.set(tarOut, false);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test
                                                                                                                                                                                 tarOut.finish();
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify two EOF records were written (each EOF record is 512 bytes of zeros)
                                                                                                                                                                                 byte[] output = realOut.toByteArray();
                                                                                                                                                                                 assertEquals(1024, output.length); // Two 512-byte records
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify first 512 bytes are zeros
                                                                                                                                                                                 for (int i = 0; i < 512; i++) {
                                                                                                                                                                                     assertEquals(0, output[i]);
                                                                                                                                                                                 }
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify second 512 bytes are zeros
                                                                                                                                                                                 for (int i = 512; i < 1024; i++) {
                                                                                                                                                                                     assertEquals(0, output[i]);
                                                                                                                                                                                 }
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testFinish_WhenAlreadyClosed_DoesNothing() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                 
                                                                                                                                                                                 // Set closed flag to true
                                                                                                                                                                                 java.lang.reflect.Field closedField = TarArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                                                                 closedField.set(tarOut, true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test
                                                                                                                                                                                 tarOut.finish();
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify no writes occurred to the output stream
                                                                                                                                                                                 verify(mockOut, never()).write(any(byte[].class));
                                                                                                                                                                                 verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testPutArchiveEntry_ShortFilename() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                                 TarArchiveEntry entry = new TarArchiveEntry("shortname.txt");
                                                                                                                                                                                 entry.setSize(100);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test
                                                                                                                                                                                 tos.putArchiveEntry(entry);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to access private fields
                                                                                                                                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                 Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                 currNameField.setAccessible(true);
                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify
                                                                                                                                                                                 assertTrue((boolean) haveUnclosedEntryField.get(tos));
                                                                                                                                                                                 assertEquals(100L, currSizeField.get(tos));
                                                                                                                                                                                 assertEquals("shortname.txt", currNameField.get(tos));
                                                                                                                                                                                 assertEquals(0L, currBytesField.get(tos));
                                                                                                                                                                                 // Verify record was written to buffer
                                                                                                                                                                                 assertTrue(bos.size() > 0);
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testPutArchiveEntry_LongFilename_TruncateMode() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                                 tos.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
                                                                                                                                                                                 
                                                                                                                                                                                 // Create a long filename
                                                                                                                                                                                 StringBuilder longName = new StringBuilder();
                                                                                                                                                                                 for (int i = 0; i < TarConstants.NAMELEN + 10; i++) {
                                                                                                                                                                                     longName.append("a");
                                                                                                                                                                                 }
                                                                                                                                                                                 TarArchiveEntry entry = new TarArchiveEntry(longName.toString());
                                                                                                                                                                                 entry.setSize(300);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test
                                                                                                                                                                                 tos.putArchiveEntry(entry);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify using reflection to access private fields
                                                                                                                                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                 assertTrue((boolean) haveUnclosedEntryField.get(tos));
                                                                                                                                                                                 
                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                 assertEquals(300L, currSizeField.get(tos));
                                                                                                                                                                                 
                                                                                                                                                                                 Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                 currNameField.setAccessible(true);
                                                                                                                                                                                 String currName = (String) currNameField.get(tos);
                                                                                                                                                                                 assertEquals(TarConstants.NAMELEN, currName.length());
                                                                                                                                                                                 
                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                 assertEquals(0L, currBytesField.get(tos));
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testPutArchiveEntry_LongFilename_ErrorMode() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                                 tos.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
                                                                                                                                                                                 
                                                                                                                                                                                 // Create a long filename (NAMELEN is typically 100 in TAR format)
                                                                                                                                                                                 StringBuilder longName = new StringBuilder();
                                                                                                                                                                                 for (int i = 0; i < 100 + 10; i++) {
                                                                                                                                                                                     longName.append("a");
                                                                                                                                                                                 }
                                                                                                                                                                                 TarArchiveEntry entry = new TarArchiveEntry(longName.toString());
                                                                                                                                                                             
                                                                                                                                                                                 // Test and verify exception
                                                                                                                                                                                 try {
                                                                                                                                                                                     tos.putArchiveEntry(entry);
                                                                                                                                                                                     fail("Expected RuntimeException for long filename");
                                                                                                                                                                                 } catch (RuntimeException e) {
                                                                                                                                                                                     assertEquals("file name '" + longName.toString() + "' is too long ( > " + 100 + " bytes)", 
                                                                                                                                                                                                  e.getMessage());
                                                                                                                                                                                 }
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testPutArchiveEntry_Directory() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                                 TarArchiveEntry entry = new TarArchiveEntry("mydir/");
                                                                                                                                                                                 entry.setSize(500); // Size should be ignored for directories
                                                                                                                                                                                 
                                                                                                                                                                                 // Test
                                                                                                                                                                                 tos.putArchiveEntry(entry);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify using reflection to access private fields
                                                                                                                                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                 boolean haveUnclosedEntry = (boolean) haveUnclosedEntryField.get(tos);
                                                                                                                                                                                 assertTrue(haveUnclosedEntry);
                                                                                                                                                                                 
                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                 long currSize = (long) currSizeField.get(tos);
                                                                                                                                                                                 assertEquals(0, currSize); // Should be 0 for directories
                                                                                                                                                                                 
                                                                                                                                                                                 Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                 currNameField.setAccessible(true);
                                                                                                                                                                                 String currName = (String) currNameField.get(tos);
                                                                                                                                                                                 assertEquals("mydir/", currName);
                                                                                                                                                                                 
                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                 long currBytes = (long) currBytesField.get(tos);
                                                                                                                                                                                 assertEquals(0, currBytes);
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testPutArchiveEntry_UnclosedPreviousEntry() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                                 TarArchiveEntry entry1 = new TarArchiveEntry("first.txt");
                                                                                                                                                                                 TarArchiveEntry entry2 = new TarArchiveEntry("second.txt");
                                                                                                                                                                                 
                                                                                                                                                                                 // First entry - don't close it
                                                                                                                                                                                 tos.putArchiveEntry(entry1);
                                                                                                                                                                                 
                                                                                                                                                                                 // Setup exception expectation
                                                                                                                                                                                 ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                 expectedException.expect(IOException.class);
                                                                                                                                                                                 expectedException.expectMessage("previous entry has not been closed");
                                                                                                                                                                             
                                                                                                                                                                                 // Test - try to add second entry without closing first
                                                                                                                                                                                 tos.putArchiveEntry(entry2);
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testCloseArchiveEntry_WithoutAssembledData() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                 Class<?> tarOutClass = tarOut.getClass();
                                                                                                                                                                                 
                                                                                                                                                                                 Field assemLenField = tarOutClass.getDeclaredField("assemLen");
                                                                                                                                                                                 assemLenField.setAccessible(true);
                                                                                                                                                                                 assemLenField.set(tarOut, 0); // no assembled data
                                                                                                                                                                                 
                                                                                                                                                                                 Field currBytesField = tarOutClass.getDeclaredField("currBytes");
                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                 currBytesField.set(tarOut, 100L);
                                                                                                                                                                                 
                                                                                                                                                                                 Field currSizeField = tarOutClass.getDeclaredField("currSize");
                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                 currSizeField.set(tarOut, 100L);
                                                                                                                                                                                 
                                                                                                                                                                                 Field haveUnclosedEntryField = tarOutClass.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                 haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                             
                                                                                                                                                                                 // Execute
                                                                                                                                                                                 tarOut.closeArchiveEntry();
                                                                                                                                                                             
                                                                                                                                                                                 // Verify
                                                                                                                                                                                 // Since we can't mock the buffer, we verify the output stream wasn't written to
                                                                                                                                                                                 verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                 
                                                                                                                                                                                 boolean haveUnclosedEntry = (boolean) haveUnclosedEntryField.get(tarOut);
                                                                                                                                                                                 assertFalse(haveUnclosedEntry);
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testCloseArchiveEntry_ExactByteCount() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                 bufferField.setAccessible(true);
                                                                                                                                                                                 bufferField.set(tarOut, new byte[1024]); // Use actual byte array instead of mocking TarBuffer
                                                                                                                                                                                 
                                                                                                                                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                 assemLenField.setAccessible(true);
                                                                                                                                                                                 assemLenField.set(tarOut, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                 currBytesField.set(tarOut, 100L);
                                                                                                                                                                                 
                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                 currSizeField.set(tarOut, 100L); // exact match
                                                                                                                                                                                 
                                                                                                                                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                 haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Execute
                                                                                                                                                                                 tarOut.closeArchiveEntry();
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify
                                                                                                                                                                                 assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                             }

 @Test
                                                                                                                                                                             public void testCloseArchiveEntry_MoreBytesThanExpected() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                 bufferField.setAccessible(true);
                                                                                                                                                                                 Object buffer = bufferField.get(tarOut);
                                                                                                                                                                                 
                                                                                                                                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                 assemLenField.setAccessible(true);
                                                                                                                                                                                 assemLenField.set(tarOut, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                 currBytesField.set(tarOut, 110L); // more than currSize
                                                                                                                                                                                 
                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                 currSizeField.set(tarOut, 100L);
                                                                                                                                                                                 
                                                                                                                                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                 haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Execute - should not throw
                                                                                                                                                                                 tarOut.closeArchiveEntry();
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify
                                                                                                                                                                                 assertFalse((boolean)haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                             }

 @Test(expected = IOException.class)
                                                                                                                                                                         public void testPutArchiveEntry_ClosedStream() throws Exception {
                                                                                                                                                                             // Setup
                                                                                                                                                                             ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                             TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                             TarArchiveEntry entry = new TarArchiveEntry("test.txt");
                                                                                                                                                                             tos.close();
                                                                                                                                                                             
                                                                                                                                                                             // Test - should throw IOException with message "Stream has already been finished"
                                                                                                                                                                             tos.putArchiveEntry(entry);
                                                                                                                                                                         }

 @Test
                                                                                                                                                                     public void testPutArchiveEntry_LongFilename_GnuMode() throws Exception {
                                                                                                                                                                         // Setup
                                                                                                                                                                         ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                         TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
                                                                                                                                                                         tos.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                                                                                                                                                                         
                                                                                                                                                                         // Create a long filename
                                                                                                                                                                         StringBuilder longName = new StringBuilder();
                                                                                                                                                                         for (int i = 0; i < 256; i++) {  // Using fixed length instead of TarConstants.NAMELEN
                                                                                                                                                                             longName.append("a");
                                                                                                                                                                         }
                                                                                                                                                                         TarArchiveEntry entry = new TarArchiveEntry(longName.toString());
                                                                                                                                                                         entry.setSize(200);
                                                                                                                                                                      
                                                                                                                                                                         // Test
                                                                                                                                                                         tos.putArchiveEntry(entry);
                                                                                                                                                                      
                                                                                                                                                                         // Verify using reflection to access private fields
                                                                                                                                                                         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                         haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                         assertTrue((boolean) haveUnclosedEntryField.get(tos));
                                                                                                                                                                      
                                                                                                                                                                         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                         currSizeField.setAccessible(true);
                                                                                                                                                                         assertEquals(200L, (long) currSizeField.get(tos));
                                                                                                                                                                      
                                                                                                                                                                         Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                         currNameField.setAccessible(true);
                                                                                                                                                                         assertEquals(longName.toString(), (String) currNameField.get(tos));
                                                                                                                                                                      
                                                                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                                                                         assertEquals(0L, (long) currBytesField.get(tos));
                                                                                                                                                                      
                                                                                                                                                                         // Should have written both the long link entry and the actual entry
                                                                                                                                                                         assertTrue(bos.size() > 512);  // Using default record size instead of TarConstants.DEFAULT_RCDSIZE
                                                                                                                                                                     }

 @Test
                                                                                                                                                                     public void testCloseArchiveEntry_WithAssembledData() throws Exception {
                                                                                                                                                                         // Setup
                                                                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                         
                                                                                                                                                                         // Set private fields using reflection
                                                                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                                                                         assemLenField.set(tarOut, 10);
                                                                                                                                                                         
                                                                                                                                                                         Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                         assemBufField.setAccessible(true);
                                                                                                                                                                         assemBufField.set(tarOut, new byte[512]);
                                                                                                                                                                         
                                                                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                                                                         currBytesField.set(tarOut, 100L);
                                                                                                                                                                         
                                                                                                                                                                         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                         currSizeField.setAccessible(true);
                                                                                                                                                                         currSizeField.set(tarOut, 100L);
                                                                                                                                                                         
                                                                                                                                                                         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                         haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                         haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                         
                                                                                                                                                                         // Mock buffer behavior through the output stream
                                                                                                                                                                         doNothing().when(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                         
                                                                                                                                                                         // Execute
                                                                                                                                                                         tarOut.closeArchiveEntry();
                                                                                                                                                                         
                                                                                                                                                                         // Verify
                                                                                                                                                                         verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                         assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                         assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                         assertEquals(100L, currBytesField.get(tarOut));
                                                                                                                                                                     }

 @Test
                                                                                                                                     public void testCloseArchiveEntry_ThrowsWhenIncomplete() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                         
                                                                                                                                         // Set private fields using reflection
                                                                                                                                         Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                         currNameField.setAccessible(true);
                                                                                                                                         currNameField.set(tarOut, "test.txt");
                                                                                                                                         
                                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                                         currBytesField.set(tarOut, 90L); // less than currSize
                                                                                                                                         
                                                                                                                                         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                         currSizeField.setAccessible(true);
                                                                                                                                         currSizeField.set(tarOut, 100L);
                                                                                                                                         
                                                                                                                                         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                         haveUnclosedEntryField.setAccessible(true);
                                                                                                                                         haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                      
                                                                                                                                         // Execute and verify exception
                                                                                                                                         try {
                                                                                                                                             tarOut.closeArchiveEntry();
                                                                                                                                             fail("Expected IOException");
                                                                                                                                         } catch (IOException e) {
                                                                                                                                             assertEquals("entry 'test.txt' closed at '90' before the '100' bytes specified in the header were written", 
                                                                                                                                                        e.getMessage());
                                                                                                                                         }
                                                                                                                                     }

 @Test
                                                                                                                                 public void testFinish_WithUnclosedEntry_ThrowsIOException() throws Exception {
                                                                                                                                     // Setup
                                                                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                     
                                                                                                                                     // Using reflection to set the private haveUnclosedEntry field to true
                                                                                                                                     // This is necessary to test the exception case
                                                                                                                                     java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                     field.setAccessible(true);
                                                                                                                                     field.set(tarOut, true);
                                                                                                                                     
                                                                                                                                     // Test and verify exception
                                                                                                                                     try {
                                                                                                                                         tarOut.finish();
                                                                                                                                         fail("Expected IOException to be thrown");
                                                                                                                                     } catch (IOException e) {
                                                                                                                                         assertEquals("This archives contains unclosed entries.", e.getMessage());
                                                                                                                                     }
                                                                                                                                 }

 @Test
                                                                                        public void testCloseArchiveEntryWithZeroAssemLen() throws Exception {
                                                                                            // Setup
                                                                                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                            
                                                                                            // Create test entry and add it to the stream
                                                                                            TarArchiveEntry entry = new TarArchiveEntry("testEntry");
                                                                                            entry.setSize(100L);
                                                                                            tarOut.putArchiveEntry(entry);
                                                                                            
                                                                                            // Write all bytes (100 bytes)
                                                                                            byte[] data = new byte[100];
                                                                                            tarOut.write(data);
                                                                                            
                                                                                            // Use reflection to verify internal state before close
                                                                                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                            assemLenField.setAccessible(true);
                                                                                            assertEquals(0, assemLenField.get(tarOut));
                                                                                            
                                                                                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                            currBytesField.setAccessible(true);
                                                                                            assertEquals(100L, currBytesField.get(tarOut));
                                                                                            
                                                                                            // Save original assemBuf for comparison
                                                                                            Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                            assemBufField.setAccessible(true);
                                                                                            byte[] originalAssemBuf = java.util.Arrays.copyOf((byte[])assemBufField.get(tarOut), 
                                                                                                                                  ((byte[])assemBufField.get(tarOut)).length);
                                                                                            
                                                                                            // Execute
                                                                                            tarOut.closeArchiveEntry();
                                                                                            
                                                                                            // Verify
                                                                                            // 1. No additional records should be written (only the header and data records)
                                                                                            byte[] output = out.toByteArray();
                                                                                            assertEquals(2 * 512, output.length); // Header + data records
                                                                                            
                                                                                            // 2. assemBuf should remain unchanged
                                                                                            assertArrayEquals(originalAssemBuf, (byte[])assemBufField.get(tarOut));
                                                                                            
                                                                                            // 3. currBytes should remain unchanged
                                                                                            assertEquals(100L, currBytesField.get(tarOut));
                                                                                            
                                                                                            // 4. assemLen should remain 0
                                                                                            assertEquals(0, assemLenField.get(tarOut));
                                                                                            
                                                                                            // 5. haveUnclosedEntry should be false
                                                                                            Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                            haveUnclosedEntryField.setAccessible(true);
                                                                                            assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                                                                        }

 @Test
                                                                                   public void testCloseArchiveEntryWithAssemLenEquals() throws IOException {
                                                                                       // Setup
                                                                                       ByteArrayOutputStream os = new ByteArrayOutputStream();
                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                                       
                                                                                       // Use reflection to access private fields since we need to test specific conditions
                                                                                       try {
                                                                                           // Set assemLen to 1 (the boundary case for the mutation)
                                                                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                           assemLenField.setAccessible(true);
                                                                                           assemLenField.set(tarOut, 1);
                                                                                           
                                                                                           // Set currBytes and currSize to avoid the size check exception
                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                           currBytesField.setAccessible(true);
                                                                                           currBytesField.set(tarOut, 10L);
                                                                                           
                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                           currSizeField.setAccessible(true);
                                                                                           currSizeField.set(tarOut, 10L);
                                                                                           
                                                                                           // Get the actual buffer instance instead of mocking
                                                                                           Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                           bufferField.setAccessible(true);
                                                                                           Object buffer = bufferField.get(tarOut);
                                                                                           
                                                                                           // Get assemBuf to verify its contents
                                                                                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                           assemBufField.setAccessible(true);
                                                                                           byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                           
                                                                                           // Execute
                                                                                           tarOut.closeArchiveEntry();
                                                                                           
                                                                                           // Verify
                                                                                           // Since we can't mock the buffer, we verify the side effects instead
                                                                                           // Check that assemBuf was modified (filled with zeros)
                                                                                           for (int i = 1; i < assemBuf.length; i++) {
                                                                                               assertEquals(0, assemBuf[i]);
                                                                                           }
                                                                                           
                                                                                           // Verify assemLen was reset
                                                                                           assertEquals(0, assemLenField.get(tarOut));
                                                                                           
                                                                                           // Verify haveUnclosedEntry was set to false
                                                                                           Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                           haveUnclosedEntryField.setAccessible(true);
                                                                                           assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                       } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                           fail("Failed to access private fields for testing: " + e.getMessage());
                                                                                       }
                                                                                   }

 @Test
                                                                              public void testCloseArchiveEntry_ArrayBounds() throws Exception {
                                                                                  // Setup
                                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                  
                                                                                  // Use reflection to set private fields
                                                                                  Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                  currNameField.setAccessible(true);
                                                                                  currNameField.set(tarOut, "testEntry");
                                                                                  
                                                                                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                  currSizeField.setAccessible(true);
                                                                                  currSizeField.set(tarOut, 100L);
                                                                                  
                                                                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                  currBytesField.setAccessible(true);
                                                                                  currBytesField.set(tarOut, 50L);
                                                                                  
                                                                                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                  assemLenField.setAccessible(true);
                                                                                  assemLenField.set(tarOut, 10);
                                                                                  
                                                                                  Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                  assemBufField.setAccessible(true);
                                                                                  assemBufField.set(tarOut, new byte[512]);
                                                                                  
                                                                                  // This should not throw ArrayIndexOutOfBoundsException with original code
                                                                                  // But would throw with the mutated code (i <= assemBuf.length)
                                                                                  tarOut.closeArchiveEntry();
                                                                                  
                                                                                  // Verify buffer was written (indirectly confirms loop completed successfully)
                                                                                  verify(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                                  
                                                                                  // Verify state was updated correctly using reflection
                                                                                  assertEquals(60L, currBytesField.get(tarOut)); // 50 + 10
                                                                                  assertEquals(0, assemLenField.get(tarOut));
                                                                                  
                                                                                  Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                  haveUnclosedEntryField.setAccessible(true);
                                                                                  assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                                                              }

 @Test
                                                                         public void testCloseArchiveEntry_ZeroesOnlyRemainingBuffer() throws Exception {
                                                                             // Setup
                                                                             ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                             
                                                                             // Set up test data - buffer with some content
                                                                             byte[] testData = {1, 2, 3, 4, 5, 6, 7, 8};
                                                                             Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                             assemBufField.setAccessible(true);
                                                                             byte[] originalBuf = (byte[]) assemBufField.get(tarOut);
                                                                             System.arraycopy(testData, 0, originalBuf, 0, testData.length);
                                                                             
                                                                             // Set assemLen to 4 (so only positions 4-7 should be zeroed)
                                                                             Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                             assemLenField.setAccessible(true);
                                                                             assemLenField.set(tarOut, 4);
                                                                             
                                                                             // Set other required fields
                                                                             Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                             currBytesField.setAccessible(true);
                                                                             currBytesField.set(tarOut, 100L);
                                                                             
                                                                             Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                             currSizeField.setAccessible(true);
                                                                             currSizeField.set(tarOut, 100L);
                                                                             
                                                                             // Execute
                                                                             tarOut.closeArchiveEntry();
                                                                             
                                                                             // Verify
                                                                             byte[] modifiedBuf = (byte[]) assemBufField.get(tarOut);
                                                                             
                                                                             // Original behavior: positions 0-3 should remain unchanged, 4-7 zeroed
                                                                             // Mutant behavior: all positions would be zeroed
                                                                             assertNotEquals(0, modifiedBuf[0]); // Would fail if mutant (all zeroed)
                                                                             assertNotEquals(0, modifiedBuf[1]);
                                                                             assertNotEquals(0, modifiedBuf[2]);
                                                                             assertNotEquals(0, modifiedBuf[3]);
                                                                             assertEquals(0, modifiedBuf[4]);
                                                                             assertEquals(0, modifiedBuf[5]);
                                                                             assertEquals(0, modifiedBuf[6]);
                                                                             assertEquals(0, modifiedBuf[7]);
                                                                             
                                                                             // Verify the output stream was written to (indirect verification of buffer write)
                                                                             assertTrue(out.toByteArray().length > 0);
                                                                         }

 @Test
                                            public void testCloseArchiveEntry_ZeroesOutRemainingBuffer() throws Exception {
                                                // Setup
                                                OutputStream mockOut = mock(OutputStream.class);
                                                ByteArrayOutputStream realOut = new ByteArrayOutputStream();
                                                doAnswer(invocation -> {
                                                    byte[] data = (byte[]) invocation.getArguments()[0];
                                                    int offset = (Integer) invocation.getArguments()[1];
                                                    int length = (Integer) invocation.getArguments()[2];
                                                    realOut.write(data, offset, length);
                                                    return null;
                                                }).when(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                
                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                
                                                // Use reflection to set private fields
                                                Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                assemBufField.setAccessible(true);
                                                byte[] assemBuf = new byte[20];
                                                assemBufField.set(tarOut, assemBuf);
                                                
                                                Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                assemLenField.setAccessible(true);
                                                assemLenField.set(tarOut, 10);
                                                
                                                // Put some test data in first 10 bytes
                                                System.arraycopy(new byte[]{1,2,3,4,5,6,7,8,9,10}, 0, assemBuf, 0, 10);
                                                
                                                Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                currSizeField.setAccessible(true);
                                                currSizeField.set(tarOut, 20);
                                                
                                                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                currBytesField.setAccessible(true);
                                                currBytesField.set(tarOut, 10);
                                                
                                                Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                haveUnclosedEntryField.setAccessible(true);
                                                haveUnclosedEntryField.set(tarOut, true);
                                                
                                                // Execute
                                                tarOut.closeArchiveEntry();
                                                
                                                // Verify the buffer was properly zeroed out
                                                byte[] modifiedAssemBuf = (byte[]) assemBufField.get(tarOut);
                                                for (int i = 10; i < 20; i++) {
                                                    assertEquals(0, modifiedAssemBuf[i]);
                                                }
                                                
                                                // Verify the buffer was written (check via mock output)
                                                verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                
                                                // Verify other state changes
                                                assertEquals(20, currBytesField.get(tarOut));
                                                assertEquals(0, assemLenField.get(tarOut));
                                                assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                            }

 @Test
                                   public void testCloseArchiveEntry_WritesAssembledBuffer() throws IOException, NoSuchFieldException, IllegalAccessException {
                                       // Setup test data
                                       byte[] testData = new byte[]{1, 2, 3, 0, 0}; // Last two bytes should be zeroed
                                       int recordSize = testData.length;
                                       
                                       // Create mock objects
                                       OutputStream mockOut = mock(OutputStream.class);
                                       
                                       // Create instance and inject mocks using reflection
                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                       
                                       // Set private fields using reflection
                                       Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                       assemBufField.setAccessible(true);
                                       assemBufField.set(tarOut, testData.clone());
                                       
                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                       assemLenField.setAccessible(true);
                                       assemLenField.set(tarOut, 3); // First 3 bytes are valid
                                       
                                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                       currBytesField.setAccessible(true);
                                       currBytesField.set(tarOut, 10L);
                                       
                                       Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                       currSizeField.setAccessible(true);
                                       currSizeField.set(tarOut, 10L);
                                       
                                       // Expected buffer after zeroing
                                       byte[] expectedBuffer = new byte[]{1, 2, 3, 0, 0};
                                       
                                       // Call method
                                       tarOut.closeArchiveEntry();
                                       
                                       // Verify output stream was called with the expected buffer
                                       verify(mockOut, atLeastOnce()).write(eq(expectedBuffer), anyInt(), anyInt());
                                       
                                       // Verify assemLen was reset
                                       assertEquals(0, assemLenField.get(tarOut));
                                       
                                       // Verify haveUnclosedEntry was set to false
                                       Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                       haveUnclosedEntryField.setAccessible(true);
                                       assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                   }

 @Test
                              public void testCloseArchiveEntry_AccumulatesBytesCorrectly() throws Exception {
                                  // Setup
                                  OutputStream mockOut = mock(OutputStream.class);
                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                  
                                  // Use reflection to set private fields
                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                  currBytesField.setAccessible(true);
                                  currBytesField.set(tarOut, 100L);
                                  
                                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                  assemLenField.setAccessible(true);
                                  assemLenField.set(tarOut, 50);
                                  
                                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                  currSizeField.setAccessible(true);
                                  currSizeField.set(tarOut, 150L);
                                  
                                  Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                  assemBufField.setAccessible(true);
                                  assemBufField.set(tarOut, new byte[512]);
                                  
                                  // Execute
                                  tarOut.closeArchiveEntry();
                                  
                                  // Verify - critical assertion to catch the mutant
                                  assertEquals("currBytes should accumulate assemLen", 150L, currBytesField.get(tarOut));
                                  
                                  // Additional verifications for completeness
                                  assertEquals("assemLen should be reset", 0, assemLenField.get(tarOut));
                                  
                                  Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                  haveUnclosedEntryField.setAccessible(true);
                                  assertFalse("haveUnclosedEntry should be false", haveUnclosedEntryField.getBoolean(tarOut));
                                  
                                  verify(mockOut).write(any(byte[].class), anyInt(), anyInt()); // Verify buffer was written
                              }

 @Test
                     public void testCloseArchiveEntry_DetectsCurrBytesMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                         // Setup test data
                         int initialCurrBytes = 100;
                         int assemLen = 50;
                         int recordSize = 512;
                         byte[] testAssemBuf = new byte[recordSize];
                         
                         // Create mock objects
                         OutputStream mockOut = mock(OutputStream.class);
                         
                         // Create instance - this will create a real TarBuffer internally
                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut, recordSize, recordSize);
                         
                         // Set private fields
                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                         currBytesField.setAccessible(true);
                         currBytesField.set(tarOut, (long)initialCurrBytes);
                         
                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                         assemLenField.setAccessible(true);
                         assemLenField.set(tarOut, assemLen);
                         
                         Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                         assemBufField.setAccessible(true);
                         assemBufField.set(tarOut, testAssemBuf);
                         
                         // Set currSize to avoid exception
                         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                         currSizeField.setAccessible(true);
                         currSizeField.set(tarOut, (long)0); // Set to 0 to bypass size check
                         
                         // Execute method
                         tarOut.closeArchiveEntry();
                         
                         // Verify currBytes was updated correctly
                         long finalCurrBytes = (long)currBytesField.get(tarOut);
                         assertEquals("currBytes should be increased by assemLen", 
                                      initialCurrBytes + assemLen, 
                                      finalCurrBytes);
                         
                         // Verify buffer was written - since we can't spy on TarBuffer directly,
                         // we verify that the mock OutputStream received the expected writes
                         verify(mockOut).write(testAssemBuf, 0, assemLen);
                         verify(mockOut).write(new byte[recordSize - assemLen], 0, recordSize - assemLen);
                     }

 @Test
                public void testCloseArchiveEntry_ResetsAssemLenToZero() throws Exception {
                    // Setup
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                    
                    // Use reflection to access private fields
                    Class<?> tarOutClass = tarOut.getClass();
                    
                    // Set initial state where we have assembled data
                    Field assemLenField = tarOutClass.getDeclaredField("assemLen");
                    assemLenField.setAccessible(true);
                    assemLenField.set(tarOut, 10); // Some non-zero value
                    
                    Field currBytesField = tarOutClass.getDeclaredField("currBytes");
                    currBytesField.setAccessible(true);
                    currBytesField.set(tarOut, 100L);
                    
                    Field currSizeField = tarOutClass.getDeclaredField("currSize");
                    currSizeField.setAccessible(true);
                    currSizeField.set(tarOut, 100L); // Make sure we don't hit the size check
                    
                    // Action
                    tarOut.closeArchiveEntry();
                    
                    // Verification
                    // The key assertion - should be 0, mutant would make it 1
                    assertEquals("assemLen should be reset to 0", 0, assemLenField.get(tarOut));
                    
                    // Additional sanity checks
                    Field haveUnclosedEntryField = tarOutClass.getDeclaredField("haveUnclosedEntry");
                    haveUnclosedEntryField.setAccessible(true);
                    assertFalse("haveUnclosedEntry should be false", haveUnclosedEntryField.getBoolean(tarOut));
                    
                    assertEquals("currBytes should remain unchanged", 100L, currBytesField.get(tarOut));
                }

 @Test
           public void testCloseArchiveEntry_ExactByteCount_ShouldNotThrow() throws Exception {
               // Setup
               ByteArrayOutputStream out = new ByteArrayOutputStream();
               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
               
               // Set up state where currBytes exactly equals currSize using reflection
               Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
               currNameField.setAccessible(true);
               currNameField.set(tarOut, "testEntry");
               
               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
               currSizeField.setAccessible(true);
               currSizeField.set(tarOut, 100L);
               
               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
               currBytesField.setAccessible(true);
               currBytesField.set(tarOut, 100L);  // Exactly equals currSize
               
               Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
               haveUnclosedEntryField.setAccessible(true);
               haveUnclosedEntryField.set(tarOut, true);
               
               // Clear any assembled buffer
               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
               assemLenField.setAccessible(true);
               assemLenField.set(tarOut, 0);
               
               // Execute and verify - should not throw exception
               tarOut.closeArchiveEntry();
               
               // Verify state was updated
               assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
           }

 @Test
           public void testCloseArchiveEntry_LessThanByteCount_ShouldThrow() throws Exception {
               // Setup
               ByteArrayOutputStream out = new ByteArrayOutputStream();
               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
               
               // Use reflection to access private fields
               Class<?> tarOutClass = tarOut.getClass();
               
               // Set currName
               Field currNameField = tarOutClass.getDeclaredField("currName");
               currNameField.setAccessible(true);
               currNameField.set(tarOut, "testEntry");
               
               // Set currSize
               Field currSizeField = tarOutClass.getDeclaredField("currSize");
               currSizeField.setAccessible(true);
               currSizeField.set(tarOut, 100L);
               
               // Set currBytes (one less than currSize)
               Field currBytesField = tarOutClass.getDeclaredField("currBytes");
               currBytesField.setAccessible(true);
               currBytesField.set(tarOut, 99L);
               
               // Set haveUnclosedEntry
               Field haveUnclosedEntryField = tarOutClass.getDeclaredField("haveUnclosedEntry");
               haveUnclosedEntryField.setAccessible(true);
               haveUnclosedEntryField.set(tarOut, true);
               
               // Clear any assembled buffer
               Field assemLenField = tarOutClass.getDeclaredField("assemLen");
               assemLenField.setAccessible(true);
               assemLenField.set(tarOut, 0);
               
               // Execute - should throw IOException
               try {
                   tarOut.closeArchiveEntry();
                   fail("Expected IOException to be thrown");
               } catch (IOException e) {
                   // Verify the exception message
                   assertTrue(e.getMessage().contains("closed at '99' before the '100' bytes"));
               }
           }

 @Test
      public void testCloseArchiveEntry_ShouldNotThrowWhenBytesMatchSize() throws Exception {
          // Setup
          ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(outputStream);
          
          // Use reflection to access private fields
          Class<?> tarOutClass = tarOut.getClass();
          
          // Set up valid state where bytes written match expected size
          Field currNameField = tarOutClass.getDeclaredField("currName");
          currNameField.setAccessible(true);
          currNameField.set(tarOut, "testEntry");
          
          Field currSizeField = tarOutClass.getDeclaredField("currSize");
          currSizeField.setAccessible(true);
          currSizeField.set(tarOut, 100L);
          
          Field currBytesField = tarOutClass.getDeclaredField("currBytes");
          currBytesField.setAccessible(true);
          currBytesField.set(tarOut, 100L);  // Matches currSize
          
          Field haveUnclosedEntryField = tarOutClass.getDeclaredField("haveUnclosedEntry");
          haveUnclosedEntryField.setAccessible(true);
          haveUnclosedEntryField.set(tarOut, true);
          
          // Clear assembled buffer to avoid that code path
          Field assemLenField = tarOutClass.getDeclaredField("assemLen");
          assemLenField.setAccessible(true);
          assemLenField.set(tarOut, 0);
          
          try {
              // This should not throw an exception in original code
              tarOut.closeArchiveEntry();
              
              // Verify state was updated correctly
              assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
          } catch (IOException e) {
              // If we get here, the mutant was detected
              fail("Should not throw IOException when currBytes == currSize");
          } finally {
              // Reset accessibility
              currNameField.setAccessible(false);
              currSizeField.setAccessible(false);
              currBytesField.setAccessible(false);
              haveUnclosedEntryField.setAccessible(false);
              assemLenField.setAccessible(false);
          }
      }

 @Test
      public void testCloseArchiveEntrySetsHaveUnclosedEntryToFalse() throws IOException {
          // Setup
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(byteArrayOutputStream);
          
          // Initialize necessary fields to simulate a valid entry state
          // We need to set currBytes and currSize to avoid the IOException
          // Using reflection to set private fields since they're not accessible otherwise
          try {
              java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
              currBytesField.setAccessible(true);
              currBytesField.set(tarOutput, 100L);
              
              java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
              currSizeField.setAccessible(true);
              currSizeField.set(tarOutput, 100L);
              
              java.lang.reflect.Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
              haveUnclosedEntryField.setAccessible(true);
              // Set initial state to true to ensure we test the change
              haveUnclosedEntryField.set(tarOutput, true);
              
              // Execute
              tarOutput.closeArchiveEntry();
              
              // Verify
              assertFalse("haveUnclosedEntry should be set to false after closing entry", 
                         (boolean)haveUnclosedEntryField.get(tarOutput));
              
          } catch (NoSuchFieldException | IllegalAccessException e) {
              fail("Failed to access private fields for testing: " + e.getMessage());
          }
      }

 @Test
     public void testCloseArchiveEntryResetsUnclosedEntryFlag() throws Exception {
         // Setup
         ByteArrayOutputStream bos = new ByteArrayOutputStream();
         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
         
         // Set initial state with an unclosed entry
         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
         haveUnclosedEntryField.setAccessible(true);
         haveUnclosedEntryField.set(tarOut, true);
         
         // Set other required fields to avoid exceptions
         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
         currSizeField.setAccessible(true);
         currSizeField.set(tarOut, 0L);
         
         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
         currBytesField.setAccessible(true);
         currBytesField.set(tarOut, 0L);
         
         // Execute
         tarOut.closeArchiveEntry();
         
         // Verify
         assertFalse("haveUnclosedEntry should be false after closing entry", 
                    (boolean) haveUnclosedEntryField.get(tarOut));
     }

}
