package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                            public void testParseOctal_ValidInput() {
                                                                byte[] buffer = {' ', '1', '2', '3', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                            }

 @Test
                                                            public void testParseOctal_LeadingZero() {
                                                                byte[] buffer = {'0', '1', '2', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 5);
                                                                assertEquals(0L, result);
                                                            }

 @Test
                                                            public void testParseOctal_LeadingSpaces() {
                                                                byte[] buffer = {' ', ' ', '7', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 5);
                                                                assertEquals(7L, result);
                                                            }

 @Test
                                                            public void testParseOctal_MultipleTrailingSpaces() {
                                                                byte[] buffer = {'1', '2', ' ', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 5);
                                                                assertEquals(10L, result); // 1*8 + 2 = 10
                                                            }

 @Test
                                                            public void testParseOctal_MaxValidOctal() {
                                                                byte[] buffer = {'7', '7', '7', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 5);
                                                                assertEquals(511L, result); // 7*64 + 7*8 + 7 = 511
                                                            }

 @Test
                                                            public void testParseOctal_EmptyWithSpaces() {
                                                                byte[] buffer = {' ', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 3);
                                                                assertEquals(0L, result);
                                                            }

 @Test
                                                            public void testParseOctal_OffsetParameter() {
                                                                byte[] buffer = {'x', 'x', '1', '2', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 2, 4);
                                                                assertEquals(10L, result); // 1*8 + 2 = 10
                                                            }

 @Test
                                                            public void testParseOctal_SingleDigit() {
                                                                byte[] buffer = {'5', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 3);
                                                                assertEquals(5L, result);
                                                            }

 @Test
                                                            public void testParseOctal_OnlySpaces() {
                                                                byte[] buffer = {' ', ' ', ' ', 0};
                                                                long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                assertEquals(0L, result);
                                                            }

 @Test
                                                    public void testParseOctal_InvalidLength() {
                                                        byte[] buffer = {'1', 0};
                                                        try {
                                                            TarUtils.parseOctal(buffer, 0, 1);
                                                            fail("Expected IllegalArgumentException");
                                                        } catch (IllegalArgumentException e) {
                                                            assertEquals("Length 1 must be at least 2", e.getMessage());
                                                        }
                                                    }

 @Test
                                                    public void testParseOctal_InvalidOctalDigit() {
                                                        org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                        exceptionRule.expect(IllegalArgumentException.class);
                                                        byte[] buffer = {'1', '8', ' ', 0};
                                                        TarUtils.parseOctal(buffer, 0, 4);
                                                    }

 @Test
            public void testParseOctalWithLength2ShouldNotThrowException() {
                // Arrange
                byte[] buffer = {' ', '1', '2', ' '}; // Valid octal "12" with spaces
                int offset = 1; // Points to '1'
                int length = 2; // Exactly 2 characters ('1' and '2')
                
                // Act & Assert
                try {
                    long result = TarUtils.parseOctal(buffer, offset, length);
                    // If we get here, the test passes (original behavior)
                    assertEquals(10L, result); // "12" in octal is 10 in decimal
                } catch (IllegalArgumentException e) {
                    // If we get here, the mutant is detected
                    fail("Length=2 should be valid but threw exception: " + e.getMessage());
                }
            }

 @Test
           public void testParseOctalWithLeadingZeroReturnsZero() {
               // Arrange
               byte[] buffer = {0, '1', '2', ' '}; // Buffer starts with 0
               int offset = 0;
               int length = 4;
               
               // Act
               long result = TarUtils.parseOctal(buffer, offset, length);
               
               // Assert
               assertEquals("Method should return 0 when first byte is 0", 0L, result);
           }

 @Test
              public void testParseOctalWithLeadingZero() {
                  // Test case to catch the return 0L -> return -1L mutant
                  byte[] buffer = new byte[]{'0', ' ', ' ', ' '}; // Buffer starting with 0
                  
                  // Should return 0 for leading zero, mutant would return -1
                  long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                  assertEquals("Method should return 0 for buffer starting with 0", 0L, result);
                  
                  // Additional test to ensure normal parsing still works
                  byte[] normalBuffer = new byte[]{'1', '2', '3', ' '};
                  long normalResult = TarUtils.parseOctal(normalBuffer, 0, normalBuffer.length);
                  assertEquals("Method should correctly parse octal numbers", 83L, normalResult); // 123 in octal is 83 in decimal
              }

 @Test(expected = IllegalArgumentException.class)
              public void testParseOctalInvalidLength() {
                  // Test that length < 2 throws exception
                  byte[] buffer = new byte[]{'1'};
                  TarUtils.parseOctal(buffer, 0, buffer.length);
              }

 @Test
              public void testParseOctalWithSpaces() {
                  // Test with leading and trailing spaces
                  byte[] buffer = new byte[]{' ', ' ', '7', '5', ' ', ' '};
                  long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                  assertEquals("Method should correctly parse with spaces", 61L, result); // 75 in octal is 61 in decimal
              }

 @Test
        public void testParseOctalWithLeadingZeroReturnsZero1() {
            // Arrange
            byte[] buffer = {0, '1', '2', ' '}; // First byte is 0
            int offset = 0;
            int length = 4;
            
            // Act
            long result = TarUtils.parseOctal(buffer, offset, length);
            
            // Assert
            assertEquals("Method should return 0 when first byte is 0", 0L, result);
        }

 @Test
       public void testParseOctalWithLeadingZeroReturnsZero2() {
           // Arrange
           byte[] buffer = new byte[]{0, ' ', '1', '2'}; // First byte is 0
           int offset = 0;
           int length = 4;
           
           // Act
           long result = TarUtils.parseOctal(buffer, offset, length);
           
           // Assert
           assertEquals("Method should return 0 when first byte is 0", 0L, result);
       }

 @Test
     public void testParseOctalThrowsIllegalArgumentExceptionForInvalidTrailer() {
         // Arrange
         byte[] invalidBuffer = {'1', '2', '3', 'x'}; // Invalid trailer 'x'
         int offset = 0;
         int length = 4;
         
         // Setup expected exception
         ExpectedException exceptionRule = ExpectedException.none();
         exceptionRule.expect(IllegalArgumentException.class);
         exceptionRule.expectMessage("Trailing characters");
         
         // Act
         TarUtils.parseOctal(invalidBuffer, offset, length);
     }

 @Test
     public void testParseOctalThrowsIllegalArgumentExceptionForInvalidDigit() {
         // Arrange
         byte[] invalidBuffer = {'1', '2', '8', ' '}; // '8' is invalid in octal
         int offset = 0;
         int length = 4;
         
         // Setup exception expectation
         ExpectedException exceptionRule = ExpectedException.none();
         exceptionRule.expect(IllegalArgumentException.class);
         exceptionRule.expectMessage("Invalid octal digit");
         
         // Act
         TarUtils.parseOctal(invalidBuffer, offset, length);
     }

 @Test
     public void testParseOctalThrowsIllegalArgumentExceptionForShortLength() {
         // Arrange
         byte[] shortBuffer = {'1'};
         int offset = 0;
         int length = 1;
         
         try {
             // Act
             TarUtils.parseOctal(shortBuffer, offset, length);
             fail("Expected IllegalArgumentException to be thrown");
         } catch (IllegalArgumentException e) {
             // Assert
             assertEquals("Length 1 must be at least 2", e.getMessage());
         }
     }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctal_InvalidTrailer_ThrowsIllegalArgumentException() {
     // Arrange
     byte[] buffer = {'1', '2', '3', 'x'}; // Invalid trailer 'x'
     int offset = 0;
     int length = 4;
     
     // Act & Assert
     TarUtils.parseOctal(buffer, offset, length);
 }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctal_InvalidDigit_ThrowsIllegalArgumentException() {
     // Arrange
     byte[] buffer = {'1', '2', '9', ' '}; // Invalid digit '9'
     int offset = 0;
     int length = 4;
     
     // Act & Assert
     TarUtils.parseOctal(buffer, offset, length);
 }

}
