package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test(expected = NullPointerException.class)
                                                        public void testVerifyCheckSum_NullHeader() {
                                                            TarUtils.verifyCheckSum(null);
                                                        }

 @Test
                                                public void testVerifyCheckSum_UnsignedSumMatches() {
                                                    // Define tar header constants
                                                    final int CHKSUM_OFFSET = 148; // Standard tar checksum offset
                                                    final int CHKSUMLEN = 8;       // Standard tar checksum length
                                                    
                                                    // Create a header where unsigned sum will match stored checksum
                                                    byte[] header = new byte[300];
                                                    // Set some values outside checksum area
                                                    header[0] = 10;
                                                    header[100] = 20;
                                                    header[200] = 30;
                                                    // Calculate expected unsigned sum (0xff & each byte)
                                                    long expectedSum = (0xff & 10) + (0xff & 20) + (0xff & 30);
                                                    // Set the checksum field with the expected sum using proper method
                                                    TarUtils.formatCheckSumOctalBytes(expectedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                    
                                                    assertTrue(TarUtils.verifyCheckSum(header));
                                                }

 @Test
                                                public void testVerifyCheckSum_SignedSumMatches() {
                                                    // Define constants that would normally be in the class
                                                    final int CHKSUM_OFFSET = 148;
                                                    final int CHKSUMLEN = 8;
                                                    
                                                    // Create a header where signed sum will match stored checksum
                                                    byte[] header = new byte[300];
                                                    // Set some values with negative bytes to test signed sum
                                                    header[0] = -10;
                                                    header[100] = 20;
                                                    header[200] = -30;
                                                    // Calculate expected signed sum
                                                    long expectedSum = -10 + 20 + -30;
                                                    // Set the checksum field with the expected sum
                                                    TarUtils.formatOctalBytes(expectedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                    
                                                    assertTrue(TarUtils.verifyCheckSum(header));
                                                }

 @Test
                                                public void testVerifyCheckSum_NeitherSumMatches() {
                                                    // Define constants for checksum offset and length
                                                    final int CHKSUM_OFFSET = 148;
                                                    final int CHKSUMLEN = 8;
                                                    
                                                    // Create a header where neither sum matches
                                                    byte[] header = new byte[300];
                                                    // Set some values
                                                    header[0] = 10;
                                                    header[100] = 20;
                                                    header[200] = 30;
                                                    // Set a checksum that won't match either sum
                                                    TarUtils.formatOctalBytes(999999, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                    
                                                    assertFalse(TarUtils.verifyCheckSum(header));
                                                }

 @Test
                                                public void testVerifyCheckSum_EmptyHeader() {
                                                    // Define constants locally
                                                    final int CHKSUM_OFFSET = 148;
                                                    final int CHKSUMLEN = 8;
                                                    
                                                    // Test with empty header (should still work if checksum is 0)
                                                    byte[] header = new byte[CHKSUM_OFFSET + CHKSUMLEN];
                                                    // Set checksum to 0
                                                    TarUtils.formatOctalBytes(0, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                    
                                                    assertTrue(TarUtils.verifyCheckSum(header));
                                                }

 @Test
                                                public void testVerifyCheckSum_ChecksumAtBoundaries() {
                                                    // Define constants that would normally be in the class
                                                    final int CHKSUM_OFFSET = 148; // Standard tar checksum offset
                                                    final int CHKSUMLEN = 8; // Standard tar checksum length
                                                    
                                                    // Test with checksum at the boundaries of the header
                                                    byte[] header = new byte[CHKSUM_OFFSET + CHKSUMLEN];
                                                    // Set values just before and after checksum area
                                                    header[CHKSUM_OFFSET - 1] = 10;
                                                    header[CHKSUM_OFFSET + CHKSUMLEN] = 20;
                                                    // Calculate expected sum
                                                    long expectedSum = (0xff & 10) + (0xff & 20);
                                                    // Set checksum
                                                    TarUtils.formatOctalBytes(expectedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                    
                                                    assertTrue(TarUtils.verifyCheckSum(header));
                                                }

 @Test
                                                public void testVerifyCheckSum_NonAsciiBytes() {
                                                    // Define constants for checksum offset and length
                                                    final int CHKSUM_OFFSET = 148;
                                                    final int CHKSUMLEN = 8;
                                                    
                                                    // Test with non-ASCII bytes
                                                    byte[] header = new byte[300];
                                                    // Set some non-ASCII values
                                                    header[0] = (byte) 0xFF;
                                                    header[100] = (byte) 0x80;
                                                    header[200] = (byte) 0x7F;
                                                    // Calculate expected unsigned sum
                                                    long unsignedSum = (0xff & 0xFF) + (0xff & 0x80) + (0xff & 0x7F);
                                                    // Set checksum to match unsigned sum
                                                    TarUtils.formatOctalBytes(unsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                    
                                                    assertTrue(TarUtils.verifyCheckSum(header));
                                                }

 @Test
        public void testVerifyCheckSumWithNegativeBytesDetectsMutant() {
            // Constants from the class (assuming typical tar values)
            final int CHKSUM_OFFSET = 148;
            final int CHKSUMLEN = 8;
            
            // Create a header with some negative bytes outside checksum area
            byte[] header = new byte[512]; // Standard tar block size
            header[100] = (byte) 0x80; // Negative byte (-128)
            header[200] = (byte) 0xFF; // Negative byte (-1)
            
            // Calculate expected signed sum (original behavior)
            long expectedSignedSum = 0;
            for (int i = 0; i < header.length; i++) {
                byte b = header[i];
                if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                    b = ' ';
                }
                expectedSignedSum += b; // Original signed addition
            }
            
            // Mock parseOctal to return our expected signed sum
            // (This would normally be in a @Before method, but keeping it self-contained)
            TarUtils mocked = mock(TarUtils.class);
            when(mocked.parseOctal(any(byte[].class), eq(CHKSUM_OFFSET), eq(CHKSUMLEN)))
                .thenReturn(expectedSignedSum);
            when(mocked.verifyCheckSum(any(byte[].class))).thenCallRealMethod();
            
            // Test - should pass with original but fail with mutant
            assertTrue(mocked.verifyCheckSum(header));
            
            // Verify the mutant would fail by checking the unsigned sum isn't equal
            long unsignedSum = 0;
            for (int i = 0; i < header.length; i++) {
                byte b = header[i];
                if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                    b = ' ';
                }
                unsignedSum += 0xff & b;
            }
            assertNotEquals(expectedSignedSum, unsignedSum);
        }

 @Test
       public void testVerifyCheckSum_ShouldPassWhenUnsignedSumMatches() {
           // Constants from the class (assuming typical tar values)
           final int CHKSUM_OFFSET = 148;
           final int CHKSUMLEN = 8;
           
           // Create a header where:
           // - The checksum field (offset 148-155) will be set to spaces during calculation
           // - Other bytes are chosen to make unsignedSum != signedSum
           byte[] header = new byte[512]; // Typical tar header size
           
           // Set some bytes that will produce different unsigned/signed sums
           // Byte values > 127 will be negative when signed but positive when unsigned
           header[0] = (byte) 0xFF; // -1 signed, 255 unsigned
           header[1] = (byte) 0x80; // -128 signed, 128 unsigned
           
           // Calculate what the unsigned sum would be (excluding checksum field)
           long unsignedSum = (0xFF & header[0]) + (0xFF & header[1]);
           
           // Set the stored checksum to match the unsigned sum
           String checksumStr = String.format("%06o", unsignedSum); // Octal format
           byte[] checksumBytes = checksumStr.getBytes();
           System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, checksumBytes.length);
           
           // Test - should pass with original code, fail with mutant
           assertTrue(TarUtils.verifyCheckSum(header));
           
           // Additional verification that signed sum doesn't match
           long signedSum = header[0] + header[1];
           assertNotEquals(unsignedSum, signedSum);
       }

 @Test
      public void testVerifyCheckSumDetectsMutatedStoredSum() {
          // Constants that would normally be in the class
          final int CHKSUM_OFFSET = 148; // Typical checksum offset in tar header
          final int CHKSUMLEN = 8; // Typical checksum length
          
          // Create a header with known checksum (1234 in octal)
          byte[] header = new byte[512]; // Standard tar header size
          // Set some non-zero bytes outside checksum range
          header[0] = 1;
          header[100] = 2;
          header[200] = 3;
          // Set checksum field (octal "0001234" + space)
          byte[] checksumBytes = {' ', ' ', ' ', '1', '2', '3', '4', ' '};
          System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, CHKSUMLEN);
          
          // Mock parseOctal to return the expected checksum (668 in decimal for 1234 octal)
          // Note: In real test, we'd need to mock the static parseOctal method
          // Since we can't easily mock static methods in JUnit 4 without PowerMock,
          // we'll instead verify that with the real parseOctal, the test would catch the mutant
          
          // Calculate expected sums
          long unsignedSum = 0;
          long signedSum = 0;
          for (int i = 0; i < header.length; i++) {
              byte b = header[i];
              if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                  b = ' ';
              }
              unsignedSum += 0xff & b;
              signedSum += b;
          }
          
          // Verify neither sum is 0 (so mutation would fail)
          assertNotEquals(0, unsignedSum);
          assertNotEquals(0, signedSum);
          
          // Test with original method (should pass)
          boolean result = TarUtils.verifyCheckSum(header);
          assertTrue(result);
          
          // With the mutation (storedSum=0), the method would return false
          // This assertion shows what we expect from the original vs mutated code
          assertNotEquals("Mutation should be detected", 
                         false, // What mutated version would return
                         result); // What original version returns
      }

 @Test
         public void testVerifyCheckSum_ValidChecksum() {
             // Create a header with known values
             byte[] header = new byte[512];
             // Fill header with some data
             for (int i = 0; i < header.length; i++) {
                 header[i] = (byte)(i % 256);
             }
             
             // Compute expected checksum
             long unsignedSum = 0;
             long signedSum = 0;
             for (int i = 0; i < header.length; i++) {
                 byte b = header[i];
                 if (148 <= i && i < 148 + 8) { // CHKSUM_OFFSET and CHKSUMLEN assumed
                     b = ' ';
                 }
                 unsignedSum += 0xff & b;
                 signedSum += b;
             }
             
             // Replace checksum field with octal representation of unsignedSum
             TarUtils.formatCheckSumOctalBytes(unsignedSum, header, 148, 8);
             
             assertTrue(TarUtils.verifyCheckSum(header));
         }

 @Test
         public void testVerifyCheckSum_InvalidChecksum() {
             byte[] header = new byte[512];
             // Fill header with some data
             for (int i = 0; i < header.length; i++) {
                 header[i] = (byte)(i % 256);
             }
             
             // Set an obviously wrong checksum
             TarUtils.formatCheckSumOctalBytes(0, header, 148, 8);
             
             assertFalse(TarUtils.verifyCheckSum(header));
         }

 @Test
         public void testVerifyCheckSum_EdgeCaseEmptyHeader() {
             byte[] emptyHeader = new byte[512]; // initialized to zeros
             // Set checksum field to zero
             TarUtils.formatCheckSumOctalBytes(0, emptyHeader, 148, 8);
             
             // Should pass because zero checksum matches computed zero sum
             assertTrue(TarUtils.verifyCheckSum(emptyHeader));
         }

 @Test
         public void testVerifyCheckSum_SignedSumMatch() {
             byte[] header = new byte[512];
             // Fill with values that will make signed sum interesting
             for (int i = 0; i < header.length; i++) {
                 header[i] = (byte)((i % 2 == 0) ? 1 : -1);
             }
             
             // Compute signed sum
             long signedSum = 0;
             for (int i = 0; i < header.length; i++) {
                 byte b = header[i];
                 if (148 <= i && i < 148 + 8) {
                     b = ' ';
                 }
                 signedSum += b;
             }
             
             // Set checksum to signed sum value
             TarUtils.formatCheckSumOctalBytes(signedSum, header, 148, 8);
             
             assertTrue(TarUtils.verifyCheckSum(header));
         }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
        public void testVerifyCheckSumWithMutatedLoopCondition() {
            // Constants from the class (assuming typical tar header values)
            final int CHKSUM_OFFSET = 148;
            final int CHKSUMLEN = 8;
            
            // Create a sample header array (size larger than checksum offset)
            byte[] header = new byte[512]; // Typical tar header size
            
            // Fill with some dummy data
            for (int i = 0; i < header.length; i++) {
                header[i] = (byte)(i % 256);
            }
            
            // Set a dummy checksum value in the checksum field
            String dummyChecksum = "0000000";
            System.arraycopy(dummyChecksum.getBytes(), 0, header, CHKSUM_OFFSET, dummyChecksum.length());
            
            // This test will pass if the mutated version throws ArrayIndexOutOfBoundsException
            // The original version would complete successfully
            TarUtils.verifyCheckSum(header);
        }

 @Test
   public void testVerifyCheckSum_DetectsSignedSumMutation() {
       // Setup test data with negative bytes that would produce different signed/unsigned sums
       byte[] header = new byte[512]; // Standard tar header size
       // Fill header with some data including negative bytes
       for (int i = 0; i < header.length; i++) {
           header[i] = (byte)(i % 256); // This will create negative values when i > 127
       }
       
       // Set a checksum value that would only pass with original signed sum calculation
       // First calculate what the original method would compute
       long unsignedSum = 0;
       long originalSignedSum = 0;
       for (int i = 0; i < header.length; i++) {
           byte b = header[i];
           if (148 <= i && i < 148 + 8) { // CHKSUM_OFFSET=148, CHKSUMLEN=8
               b = ' ';
           }
           unsignedSum += 0xff & b;
           originalSignedSum += b;
       }
       
       // Now set the stored checksum to match only the original signed sum
       // This should pass original but fail mutated version
       TarUtils.formatCheckSumOctalBytes(originalSignedSum, header, 148, 8);
       
       // Test - should pass with original code but fail with mutated code
       assertTrue(TarUtils.verifyCheckSum(header));
       
       // Additional verification that unsigned sum is different
       // (to ensure we're testing the right scenario)
       assertNotEquals(unsignedSum, originalSignedSum);
   }

 @Test
  public void testVerifyCheckSum_ShouldPassWhenSignedSumMatchesButUnsignedDoesNot() {
      // Constants from the class (assuming typical tar header values)
      final int CHKSUM_OFFSET = 148;
      final int CHKSUMLEN = 8;
      
      // Create a header where:
      // - The stored checksum (at offset 148) will be set to match the signed sum
      // - The other bytes will be arranged to make signed and unsigned sums different
      byte[] header = new byte[512]; // Standard tar header size
      
      // Set some bytes that will produce different signed and unsigned sums
      // Using negative bytes since they differ in signed vs unsigned interpretation
      header[0] = (byte) 0x80; // -128 in signed, 128 in unsigned
      header[1] = (byte) 0xFF; // -1 in signed, 255 in unsigned
      
      // Calculate what the signed sum would be (just these two bytes for simplicity)
      long signedSum = header[0] + header[1]; // -128 + -1 = -129
      long unsignedSum = (0xff & header[0]) + (0xff & header[1]); // 128 + 255 = 383
      
      // Set the stored checksum to match the signed sum (-129)
      // We need to format this as octal in the checksum field
      String checksumStr = String.format("%06o", signedSum & 0xFFFFFFFFL); // Format as octal
      byte[] checksumBytes = checksumStr.getBytes();
      System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, Math.min(checksumBytes.length, CHKSUMLEN));
      
      // Test - should return true in original, false in mutated
      assertTrue(TarUtils.verifyCheckSum(header));
      
      // Additional assertion to verify our test setup
      // The stored sum should not equal the unsigned sum
      long storedSum = TarUtils.parseOctal(header, CHKSUM_OFFSET, CHKSUMLEN);
      assertNotEquals(storedSum, unsignedSum);
      assertEquals(storedSum, signedSum);
  }

 @Test
 public void testVerifyCheckSum_ShouldPassWhenUnsignedSumMatchesButSignedDoesNot() {
     // Constants from TarUtils (assuming typical values)
     final int CHKSUM_OFFSET = 148;
     final int CHKSUMLEN = 8;
     
     // Create a header where:
     // - The stored checksum will be 1000 (unsigned sum)
     // - The unsigned sum calculation will be 1000
     // - The signed sum calculation will be different (e.g., -1000)
     byte[] header = new byte[512]; // Typical tar header size
     
     // Set some bytes to create the checksum difference
     // Bytes outside checksum field will contribute to both sums
     header[0] = (byte) 0xFF; // Unsigned: 255, Signed: -1
     header[1] = (byte) 0x01; // Unsigned: 1, Signed: 1
     
     // Set the stored checksum field to 1000 (unsigned sum)
     // 1000 in octal is 01750
     String checksumOctal = "0001750 ";
     System.arraycopy(checksumOctal.getBytes(), 0, header, CHKSUM_OFFSET, CHKSUMLEN);
     
     // Expected behavior:
     // unsignedSum = 255 + 1 = 256
     // But we blanked checksum field (8 spaces = 8*32=256)
     // So unsignedSum = 256 - 256 + (sum of checksum field as spaces) = 256
     // storedSum = 1000 (doesn't match)
     // Need to adjust our test values...
     
     // Let's recalculate:
     // We need unsignedSum to match storedSum (1000)
     // Each 0xFF byte adds 255 to unsignedSum but -1 to signedSum
     // Each 0x01 byte adds 1 to both sums
     // Need to create a difference of 2000 between sums (1000 vs -1000)
     // For n 0xFF bytes: unsignedSum = 255n, signedSum = -n
     // We want 255n = 1000 => n ≈ 4
     header = new byte[512];
     for (int i = 0; i < 4; i++) {
         header[i] = (byte) 0xFF; // Each adds 255 unsigned, -1 signed
     }
     // Total so far: unsigned=1020, signed=-4
     // Add checksum field (8 spaces = 256)
     System.arraycopy("        ".getBytes(), 0, header, CHKSUM_OFFSET, CHKSUMLEN);
     // unsignedSum = 1020 - 1020 (checksum field original) + 256 = 256
     // Need unsignedSum = 1000, so add 744 more (1000-256)
     // Add bytes that contribute equally to both sums
     for (int i = 4; i < 4 + 744; i++) {
         header[i] = 0x01; // Each adds 1 to both sums
     }
     // Now:
     // unsignedSum = 256 (from above) + 744 = 1000
     // signedSum = -4 (from 0xFF) + 744 = 740
     // Set stored checksum to 1000
     checksumOctal = "0001750 ";
     System.arraycopy(checksumOctal.getBytes(), 0, header, CHKSUM_OFFSET, CHKSUMLEN);
     
     // Test
     assertTrue(TarUtils.verifyCheckSum(header));
     
     // This will pass with original code (1000 == 1000 unsigned)
     // But fail with mutated code (1000 != 740 signed)
 }

}
