package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testParseOctal_ValidInput() {
                                                    byte[] buffer = {' ', '1', '2', '3', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 6);
                                                    assertEquals(83L, result); // 123 in octal is 83 in decimal
                                                }

    @Test
                                                public void testParseOctal_LeadingSpaces() {
                                                    byte[] buffer = {' ', ' ', '7', '5', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 6);
                                                    assertEquals(61L, result); // 75 in octal is 61 in decimal
                                                }

    @Test
                                                public void testParseOctal_TrailingSpace() {
                                                    byte[] buffer = {'1', '0', '0', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, 4);
                                                    assertEquals(64L, result); // 100 in octal is 64 in decimal
                                                }

    @Test
                                                public void testParseOctal_TrailingNUL() {
                                                    byte[] buffer = {'1', '2', '7', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 4);
                                                    assertEquals(87L, result); // 127 in octal is 87 in decimal
                                                }

    @Test
                                                public void testParseOctal_DoubleTrailingSeparators() {
                                                    byte[] buffer = {'1', '5', ' ', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, 4);
                                                    assertEquals(13L, result); // 15 in octal is 13 in decimal
                                                }

    @Test
                                                public void testParseOctal_AllNULBytes() {
                                                    byte[] buffer = {0, 0, 0, 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 4);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctal_MaxValue() {
                                                    byte[] buffer = {'1', '7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 11);
                                                    assertEquals(Long.parseLong("17777777777", 8), result);
                                                }

    @Test
                                                public void testParseOctal_WithOffset() {
                                                    byte[] buffer = {'x', 'x', ' ', '6', '4', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 2, 5);
                                                    assertEquals(52L, result); // 64 in octal is 52 in decimal
                                                }

    @Test
                                                public void testParseOctal_EmptyAfterTrim() {
                                                    byte[] buffer = {' ', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 3);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                        public void testParseOctal_InvalidLength() {
                                            byte[] buffer = {'1'};
                                            org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                            exceptionRule.expect(IllegalArgumentException.class);
                                            exceptionRule.expectMessage("Length 1 must be at least 2");
                                            TarUtils.parseOctal(buffer, 0, 1);
                                        }

                                        public void testParseOctal_InvalidTrailer() {
                                            byte[] buffer = {'1', '2', '3', 'x'};
                                            TarUtils.parseOctal(buffer, 0, 4);
                                        }

    @Test(expected = IllegalArgumentException.class)
                                    public void testParseOctal_InvalidDigit() {
                                        byte[] buffer = {'1', '8', ' ', 0};
                                        TarUtils.parseOctal(buffer, 0, 4);
                                    }


}
