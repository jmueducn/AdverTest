package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                    public void testParseOctal_ValidInput() {
                                                        byte[] buffer = {' ', '1', '2', '3', ' ', '4', '5', '6', ' ', ' '};
                                                        long result = TarUtils.parseOctal(buffer, 0, 10);
                                                        assertEquals(123456L, result);
                                                    }

 @Test
                                                    public void testParseOctal_LeadingZeros() {
                                                        byte[] buffer = {'0', '0', '0', '7', '5', '3'};
                                                        long result = TarUtils.parseOctal(buffer, 0, 6);
                                                        assertEquals(753L, result);
                                                    }

 @Test
                                                    public void testParseOctal_AllZeros() {
                                                        byte[] buffer = {'0', '0', '0', '0', '0', '0'};
                                                        long result = TarUtils.parseOctal(buffer, 0, 6);
                                                        assertEquals(0L, result);
                                                    }

 @Test
                                                    public void testParseOctal_FirstByteZero() {
                                                        byte[] buffer = {'0', '1', '2', '3', '4'};
                                                        long result = TarUtils.parseOctal(buffer, 0, 5);
                                                        assertEquals(0L, result);
                                                    }

 @Test
                                                    public void testParseOctal_LeadingAndTrailingSpaces() {
                                                        byte[] buffer = {' ', ' ', '7', '5', ' ', ' '};
                                                        long result = TarUtils.parseOctal(buffer, 0, 6);
                                                        assertEquals(75L, result);
                                                    }

 @Test
                                                    public void testParseOctal_MaxOctalValue() {
                                                        byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                        long result = TarUtils.parseOctal(buffer, 0, 11);
                                                        assertEquals(077777777777L, result);
                                                    }

 @Test
                                                    public void testParseOctal_WithOffset() {
                                                        byte[] buffer = {'x', 'x', ' ', '6', '4', ' ', 'x', 'x'};
                                                        long result = TarUtils.parseOctal(buffer, 2, 4);
                                                        assertEquals(64L, result);
                                                    }

 @Test
                                                    public void testParseOctal_TrailingNulls() {
                                                        byte[] buffer = {'1', '2', '3', 0, 0, 0};
                                                        long result = TarUtils.parseOctal(buffer, 0, 6);
                                                        assertEquals(123L, result);
                                                    }

 @Test
                                                    public void testParseOctal_MixedTrailingChars() {
                                                        byte[] buffer = {'7', '5', ' ', 0, ' '};
                                                        long result = TarUtils.parseOctal(buffer, 0, 5);
                                                        assertEquals(75L, result);
                                                    }

 @Test
                                            public void testParseOctal_LengthTooShort() {
                                                byte[] buffer = {'1'};
                                                ExpectedException exceptionRule = ExpectedException.none();
                                                exceptionRule.expect(IllegalArgumentException.class);
                                                exceptionRule.expectMessage("Length 1 must be at least 2");
                                                TarUtils.parseOctal(buffer, 0, 1);
                                            }

 @Test
                                            public void testParseOctal_EmptyBuffer() {
                                                byte[] buffer = {};
                                                try {
                                                    TarUtils.parseOctal(buffer, 0, 0);
                                                    fail("Expected IllegalArgumentException");
                                                } catch (IllegalArgumentException e) {
                                                    assertEquals("Length 0 must be at least 2", e.getMessage());
                                                }
                                            }

 @Test(expected = IllegalArgumentException.class)
                                        public void testParseOctal_InvalidCharacter() {
                                            byte[] buffer = {'1', '2', '8', '4'}; // '8' is invalid in octal
                                            TarUtils.parseOctal(buffer, 0, 4);
                                        }

 @Test
                                    public void testParseOctal_AllSpaces() {
                                        byte[] buffer = {' ', ' ', ' ', ' '};
                                        try {
                                            TarUtils.parseOctal(buffer, 0, 4);
                                            fail("Expected IllegalArgumentException to be thrown");
                                        } catch (IllegalArgumentException e) {
                                            // expected exception
                                        }
                                    }

 @Test
    public void testParseOctalWithLength2ShouldNotThrowException() {
        // Arrange
        byte[] buffer = new byte[] {'1', '2'}; // Valid octal "12"
        int offset = 0;
        int length = 2;
        
        // Act
        long result = TarUtils.parseOctal(buffer, offset, length);
        
        // Assert
        assertEquals(10L, result); // 12 in octal is 10 in decimal
    }

 @Test(expected = IllegalArgumentException.class)
    public void testParseOctalWithLength1ShouldThrowException() {
        // Arrange
        byte[] buffer = new byte[] {'1'};
        int offset = 0;
        int length = 1;
        
        // Act
        TarUtils.parseOctal(buffer, offset, length);
    }

 @Test
    public void testParseOctalWithLengthGreaterThan2ShouldWork() {
        // Arrange
        byte[] buffer = new byte[] {'1', '2', '3'}; // Valid octal "123"
        int offset = 0;
        int length = 3;
        
        // Act
        long result = TarUtils.parseOctal(buffer, offset, length);
        
        // Assert
        assertEquals(83L, result); // 123 in octal is 83 in decimal
    }

 @Test
   public void testParseOctal_ReturnsZeroWhenFirstByteIsZero() {
       // Arrange
       byte[] buffer = new byte[] {0, '1', '2', '3'}; // First byte is 0
       int offset = 0;
       int length = 4;
       
       // Act
       long result = TarUtils.parseOctal(buffer, offset, length);
       
       // Assert
       assertEquals("Method should return 0L when first byte is 0", 0L, result);
       
       // Additional verification that no processing was done
       // If mutation exists, it would try to process the remaining bytes
       // and might throw exception for invalid octal digits
       // So we can also verify no exception was thrown
   }

 @Test
  public void testParseOctalWithTrailingSpaceShouldTrim() {
      byte[] buffer = {' ', '1', '2', '3', ' '}; // leading and trailing space
      long result = TarUtils.parseOctal(buffer, 0, buffer.length);
      assertEquals(83L, result); // 123 in octal is 83 in decimal
  }

 @Test
  public void testParseOctalWithTrailingNullShouldTrim() {
      byte[] buffer = {'1', '2', '3', 0, 0}; // trailing nulls
      long result = TarUtils.parseOctal(buffer, 0, buffer.length);
      assertEquals(83L, result); // 123 in octal is 83 in decimal
  }

 @Test
  public void testParseOctalWithTrailingSpaceAndNullShouldTrim() {
      byte[] buffer = {'1', '2', '3', ' ', 0}; // mixed trailing space and null
      long result = TarUtils.parseOctal(buffer, 0, buffer.length);
      assertEquals(83L, result); // 123 in octal is 83 in decimal
  }

 @Test
 public void testParseOctalWithTrailingSpacesDetectsEndDecrementMutant() {
     // Setup test data with trailing spaces that should be trimmed
     byte[] buffer = {' ', '1', '2', '3', ' ', ' '};
     int offset = 0;
     int length = buffer.length;
     
     // Expected behavior: trailing spaces should be trimmed and "123" parsed as 83 (octal)
     long expected = 83L;
     
     try {
         long result = TarUtils.parseOctal(buffer, offset, length);
         
         // Verify correct parsing (would fail with mutant due to end++ including spaces)
         assertEquals("Should parse octal number ignoring trailing spaces", 
                     expected, result);
     } catch (IndexOutOfBoundsException e) {
         // Mutant would throw this when end++ goes past buffer length
         fail("Mutant detected: end++ caused IndexOutOfBoundsException");
     } catch (IllegalArgumentException e) {
         // Mutant might throw this if spaces included in parsing
         fail("Mutant detected: spaces were not properly trimmed");
     }
 }

 @Test
 public void testParseOctalWithTrailingNullsDetectsEndDecrementMutant() {
     // Setup test data with trailing nulls that should be trimmed
     byte[] buffer = {'0', '7', '5', 0, 0};
     int offset = 0;
     int length = buffer.length;
     
     // Expected behavior: trailing nulls should be trimmed and "075" parsed as 61 (octal)
     long expected = 61L;
     
     try {
         long result = TarUtils.parseOctal(buffer, offset, length);
         
         // Verify correct parsing (would fail with mutant due to end++ including nulls)
         assertEquals("Should parse octal number ignoring trailing nulls", 
                     expected, result);
     } catch (IndexOutOfBoundsException e) {
         // Mutant would throw this when end++ goes past buffer length
         fail("Mutant detected: end++ caused IndexOutOfBoundsException");
     } catch (IllegalArgumentException e) {
         // Mutant might throw this if nulls included in parsing
         fail("Mutant detected: nulls were not properly trimmed");
     }
 }

}
