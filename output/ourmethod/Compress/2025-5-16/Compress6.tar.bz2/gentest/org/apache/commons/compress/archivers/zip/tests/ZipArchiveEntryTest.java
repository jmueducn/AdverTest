package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                            public void testEquals_Reflexive() {
                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                assertTrue(entry.equals(entry));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_Symmetric() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                assertTrue(entry1.equals(entry2));
                                                                                                                assertTrue(entry2.equals(entry1));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_Transitive() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                ZipArchiveEntry entry3 = new ZipArchiveEntry("test.txt");
                                                                                                                assertTrue(entry1.equals(entry2));
                                                                                                                assertTrue(entry2.equals(entry3));
                                                                                                                assertTrue(entry1.equals(entry3));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_NullComparison() {
                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                assertFalse(entry.equals(null));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_DifferentClass() {
                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                Object other = new Object();
                                                                                                                assertFalse(entry.equals(other));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_DifferentNames() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                                                                                assertFalse(entry1.equals(entry2));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_SameNames() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                assertTrue(entry1.equals(entry2));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_CaseSensitiveNames() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("TEST.TXT");
                                                                                                                assertFalse(entry1.equals(entry2));
                                                                                                            }

 @Test
                                                                                                            public void testEquals_WithDifferentMethods() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                entry1.setMethod(8);
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                entry2.setMethod(0);
                                                                                                                assertTrue(entry1.equals(entry2)); // Method shouldn't affect equality
                                                                                                            }

 @Test
                                                                                                            public void testEquals_WithDifferentExtraFields() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                // Mocking extra fields since we don't have the actual implementation
                                                                                                                entry1.setExtraFields(new ZipExtraField[]{mock(ZipExtraField.class)});
                                                                                                                entry2.setExtraFields(new ZipExtraField[]{mock(ZipExtraField.class)});
                                                                                                                assertTrue(entry1.equals(entry2)); // Extra fields shouldn't affect equality
                                                                                                            }

 @Test
                                                                                                    public void testEquals_BothNamesNull() throws Exception {
                                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                        setNameMethod.setAccessible(true);
                                                                                                        setNameMethod.invoke(entry1, (String)null);
                                                                                                        
                                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                                                                        setNameMethod.invoke(entry2, (String)null);
                                                                                                        
                                                                                                        assertTrue(entry1.equals(entry2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNameNull() throws Exception {
                                                                                                        // Create entry with null name using reflection
                                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                        setNameMethod.setAccessible(true);
                                                                                                        setNameMethod.invoke(entry1, new Object[] { null });
                                                                                                        
                                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                        assertFalse(entry1.equals(entry2));
                                                                                                        assertFalse(entry2.equals(entry1));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_WithDifferentPlatforms() throws Exception {
                                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                        
                                                                                                        // Use reflection to set platform since setPlatform is protected
                                                                                                        Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                        setPlatformMethod.setAccessible(true);
                                                                                                        setPlatformMethod.invoke(entry1, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                        setPlatformMethod.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                        
                                                                                                        assertTrue(entry1.equals(entry2)); // Platform shouldn't affect equality
                                                                                                    }

 @Test
                                                                                                public void testEquals_ReferenceEquality() {
                                                                                                    // Create a ZipArchiveEntry object
                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                    
                                                                                                    // Test reference equality - should return true
                                                                                                    assertTrue("Object should equal itself", entry.equals(entry));
                                                                                                    
                                                                                                    // Test with different object of same class - should return false
                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                    assertFalse("Different objects should not be equal by reference", 
                                                                                                               entry.equals(entry2));
                                                                                                    
                                                                                                    // Test with null - should return false
                                                                                                    assertFalse("Should not equal null", entry.equals(null));
                                                                                                    
                                                                                                    // Test with different class - should return false
                                                                                                    assertFalse("Should not equal different class", 
                                                                                                               entry.equals(new Object()));
                                                                                                }

 @Test
                                                                                              public void testEqualsWhenFirstNameNullAndSecondNameNotNull() {
                                                                                                  // Create first entry with non-null name (we'll set it to null via reflection)
                                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                                  // Use reflection to set private name field to null since there's no setter
                                                                                                  try {
                                                                                                      Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                      nameField.setAccessible(true);
                                                                                                      nameField.set(entry1, null);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to set name field via reflection");
                                                                                                  }
                                                                                              
                                                                                                  // Create second entry with non-null name
                                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("testName");
                                                                                              
                                                                                                  // Verify equals returns false (original behavior would return false,
                                                                                                  // mutated version would return true)
                                                                                                  assertFalse("Should return false when first name is null and second is not", 
                                                                                                             entry1.equals(entry2));
                                                                                              }

 @Test
                                                                                         public void testEqualsWithOneNullName() throws Exception {
                                                                                             // Create two entries using public constructor
                                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                                             
                                                                                             // Use reflection to access protected setName method
                                                                                             Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                             setName.setAccessible(true);
                                                                                             
                                                                                             // Set names - one null, one not null
                                                                                             setName.invoke(entry1, null);
                                                                                             setName.invoke(entry2, "someName");
                                                                                             
                                                                                             // Test both directions since equals should be symmetric
                                                                                             assertFalse("Entry with null name should not equal entry with non-null name", 
                                                                                                        entry1.equals(entry2));
                                                                                             assertFalse("Entry with non-null name should not equal entry with null name", 
                                                                                                        entry2.equals(entry1));
                                                                                             
                                                                                             // Also test case where both names are null (should be equal)
                                                                                             setName.invoke(entry2, null);
                                                                                             assertTrue("Both entries with null names should be equal", 
                                                                                                       entry1.equals(entry2));
                                                                                         }

 @Test
                                                                                         public void testEqualsWithSameNames() {
                                                                                             // Create two entries with same names
                                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                             
                                                                                             assertTrue("Entries with same names should be equal",
                                                                                                       entry1.equals(entry2));
                                                                                         }

 @Test
                                                                                         public void testEqualsWithDifferentNames() {
                                                                                             // Create two entries with different names
                                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                                                                                             
                                                                                             assertFalse("Entries with different names should not be equal",
                                                                                                        entry1.equals(entry2));
                                                                                         }

 @Test
                                                                                    public void testEqualsWithNullNameVsNonNullName() throws Exception {
                                                                                        // Create two entries - one with null name, one with non-null name
                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                        // Use reflection to set name to null
                                                                                        Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                        nameField.setAccessible(true);
                                                                                        nameField.set(entry1, null);
                                                                                        
                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                        
                                                                                        // The original code would return false here because:
                                                                                        // entry1.name is null, entry2.name is "test"
                                                                                        // So !false would be true, but the comparison should fail
                                                                                        assertFalse("Entries with null and non-null names should not be equal", 
                                                                                                   entry1.equals(entry2));
                                                                                        
                                                                                        // Also test the reverse case
                                                                                        assertFalse("Entries with non-null and null names should not be equal",
                                                                                                   entry2.equals(entry1));
                                                                                    }

 @Test
                                                                                    public void testEqualsWithBothNullNames() throws Exception {
                                                                                        // Create two entries with dummy names first
                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                                                                                        
                                                                                        // Use reflection to set names to null
                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                        setNameMethod.setAccessible(true);
                                                                                        setNameMethod.invoke(entry1, (String)null);
                                                                                        setNameMethod.invoke(entry2, (String)null);
                                                                                        
                                                                                        assertTrue("Entries with both null names should be equal",
                                                                                                  entry1.equals(entry2));
                                                                                    }

 @Test
                                                                                    public void testEquals_SameObjectReference_ShouldReturnTrue() {
                                                                                        // Arrange
                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                        
                                                                                        // Act
                                                                                        boolean result = entry.equals(entry);
                                                                                        
                                                                                        // Assert
                                                                                        assertTrue("Comparing an object to itself should return true", result);
                                                                                        
                                                                                        // This test will fail with the mutant because:
                                                                                        // Original code: returns true immediately in self-comparison
                                                                                        // Mutant code: skips self-comparison check and does full comparison
                                                                                        // While both may return true, the mutant version does unnecessary work
                                                                                        // A proper test suite should detect this behavioral difference
                                                                                    }

 @Test
                                                                                    public void testEquals_NullObject_ShouldReturnFalse() {
                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                        assertFalse(entry.equals(null));
                                                                                    }

 @Test
                                                                                    public void testEquals_DifferentClass_ShouldReturnFalse() {
                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                        assertFalse(entry.equals(new Object()));
                                                                                    }

 @Test
                                                                                    public void testEquals_DifferentNames_ShouldReturnFalse() {
                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                                                        assertFalse(entry1.equals(entry2));
                                                                                    }

 @Test
                                                                                    public void testEquals_SameNames_ShouldReturnTrue() {
                                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                        assertTrue(entry1.equals(entry2));
                                                                                    }

 @Test
                                                                              public void testEqualsWithNullNameShouldReturnFalseWhenOtherNameNotNull() {
                                                                                  // Create first entry with a dummy name (will be set to null via reflection)
                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                  // Use reflection to set private name field to null since setName() might prevent null
                                                                                  try {
                                                                                      java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                      nameField.setAccessible(true);
                                                                                      nameField.set(entry1, null);
                                                                                  } catch (Exception e) {
                                                                                      fail("Failed to set name field to null via reflection");
                                                                                  }
                                                                                  
                                                                                  // Create second entry with non-null name
                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                  
                                                                                  // Original should return false, mutant would return true
                                                                                  assertFalse("Should return false when comparing null name with non-null name", 
                                                                                             entry1.equals(entry2));
                                                                              }

 @Test
                                                                              public void testEqualsWithNonNullNameShouldReturnFalseWhenOtherNameNull() {
                                                                                  // Create first entry with non-null name
                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                                  
                                                                                  // Create second entry with a dummy name first
                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                                  try {
                                                                                      // Then set the name to null via reflection
                                                                                      java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                      nameField.setAccessible(true);
                                                                                      nameField.set(entry2, null);
                                                                                  } catch (Exception e) {
                                                                                      fail("Failed to set name field to null via reflection");
                                                                                  }
                                                                                  
                                                                                  // Original should return false, mutant would return true
                                                                                  assertFalse("Should return false when comparing non-null name with null name", 
                                                                                             entry1.equals(entry2));
                                                                              }

 @Test
                                                                         public void testEqualsWithNullNameVsNonNullName1() throws Exception {
                                                                             // Create two entries using public constructors
                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                             
                                                                             // Use reflection to access protected setName() method
                                                                             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                             setNameMethod.setAccessible(true);
                                                                             
                                                                             // Set names - one null, one non-null
                                                                             setNameMethod.invoke(entry1, (String)null);
                                                                             setNameMethod.invoke(entry2, "someName");
                                                                             
                                                                             // They should NOT be equal (original behavior)
                                                                             // The mutant will return true here
                                                                             assertFalse("Entries with null name and non-null name should not be equal", 
                                                                                        entry1.equals(entry2));
                                                                             
                                                                             // Also test reverse case for completeness
                                                                             assertFalse("Entries with non-null name and null name should not be equal",
                                                                                        entry2.equals(entry1));
                                                                         }

 @Test
                                                                    public void testEqualsWithNullOtherName() {
                                                                        // Create first entry with non-null name
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                        
                                                                        // Create second entry with dummy name (we'll set it to null via reflection)
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                        // Need to set name to null through reflection since setName is protected
                                                                        try {
                                                                            java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                            nameField.setAccessible(true);
                                                                            nameField.set(entry2, null);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set name to null via reflection");
                                                                        }
                                                                        
                                                                        // Original behavior: should return false
                                                                        // Mutated behavior: would throw NullPointerException
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

 @Test
                                                                    public void testEqualsWithSameObjectReference() {
                                                                        // Create a ZipArchiveEntry instance
                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                        
                                                                        // Test reference equality - should return true
                                                                        assertTrue("Object should be equal to itself", entry.equals(entry));
                                                                        
                                                                        // Also test with null
                                                                        assertFalse("Should return false when comparing with null", entry.equals(null));
                                                                        
                                                                        // Test with different object type
                                                                        assertFalse("Should return false when comparing with different type", 
                                                                                   entry.equals(new Object()));
                                                                    }

 @Test
                                                                    public void testEqualsWithDifferentInstances() {
                                                                        // Create two entries with same name
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        
                                                                        // Should return true as names are equal
                                                                        assertTrue("Entries with same name should be equal", entry1.equals(entry2));
                                                                        
                                                                        // Create entry with different name
                                                                        ZipArchiveEntry entry3 = new ZipArchiveEntry("different.txt");
                                                                        assertFalse("Entries with different names should not be equal", 
                                                                                  entry1.equals(entry3));
                                                                    }

 @Test
                                                               public void testEqualsWithNullName() {
                                                                   // Create entry with null name
                                                                   ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
                                                                   ZipArchiveEntry entry2 = new ZipArchiveEntry((String) null);
                                                                   
                                                                   // Both have null names - should be equal
                                                                   assertTrue("Entries with null names should be equal", entry1.equals(entry2));
                                                                   
                                                                   // Compare with entry having non-null name
                                                                   ZipArchiveEntry entry3 = new ZipArchiveEntry("test.txt");
                                                                   assertFalse("Entry with null name should not equal entry with name", 
                                                                             entry1.equals(entry3));
                                                               }

 @Test
                                                          public void testEqualsWithNameNullVsNonNull() {
                                                              // Create first entry with null name
                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                              // Use reflection to set private name field to null since there's no setter
                                                              try {
                                                                  Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                  nameField.setAccessible(true);
                                                                  nameField.set(entry1, null);
                                                              } catch (Exception e) {
                                                                  fail("Failed to set name field via reflection");
                                                              }
                                                           
                                                              // Create second entry with non-null name
                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                           
                                                              // Test both directions
                                                              assertFalse("Entry with null name should not equal entry with non-null name", 
                                                                          entry1.equals(entry2));
                                                              assertFalse("Entry with non-null name should not equal entry with null name", 
                                                                          entry2.equals(entry1));
                                                              
                                                              // Also test case where both names are null
                                                              ZipArchiveEntry entry3 = new ZipArchiveEntry("");
                                                              try {
                                                                  Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                  nameField.setAccessible(true);
                                                                  nameField.set(entry3, null);
                                                              } catch (Exception e) {
                                                                  fail("Failed to set name field via reflection");
                                                              }
                                                              assertTrue("Two entries with null names should be equal", 
                                                                         entry1.equals(entry3));
                                                          }

 @Test
                                                     public void testEqualsWithNullNameVsNonNullName2() throws Exception {
                                                         // Create two entries
                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                         
                                                         // Use reflection to set name since it's private
                                                         Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                         nameField.setAccessible(true);
                                                         
                                                         // Set entry1's name to null and entry2's name to non-null
                                                         nameField.set(entry1, null);
                                                         nameField.set(entry2, "testName");
                                                         
                                                         // Test equals in both directions
                                                         assertTrue("Entry with null name should equal entry with non-null name", 
                                                                    entry1.equals(entry2));
                                                         assertTrue("Entry with non-null name should equal entry with null name", 
                                                                    entry2.equals(entry1));
                                                         
                                                         // Clean up
                                                         nameField.setAccessible(false);
                                                     }

 @Test
                                                public void testEqualsWithNullAndNonNullNames() {
                                                    // Create first entry with null name
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                    // Use reflection to set the private name field to null since there's no setter
                                                    try {
                                                        java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                        nameField.setAccessible(true);
                                                        nameField.set(entry1, null);
                                                    } catch (Exception e) {
                                                        fail("Failed to set name field via reflection");
                                                    }
                                                    
                                                    // Create second entry with non-null name
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                    
                                                    // The mutated version would still pass this test since both return true,
                                                    // but we want to ensure the original logic with !false is preserved
                                                    assertFalse("Entries with null and non-null names should not be equal", 
                                                               entry1.equals(entry2));
                                                    
                                                    // Additional test case where both names are null
                                                    ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                                    try {
                                                        java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                        nameField.setAccessible(true);
                                                        nameField.set(entry3, null);
                                                    } catch (Exception e) {
                                                        fail("Failed to set name field via reflection");
                                                    }
                                                    assertTrue("Entries with both null names should be equal", 
                                                              entry1.equals(entry3));
                                                }

 @Test
                                                public void testEqualsWithSameObject() {
                                                    // Create a ZipArchiveEntry object
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    
                                                    // Set some properties to ensure it's not empty
                                                    entry.setMethod(8);
                                                    entry.setInternalAttributes(1);
                                                    entry.setExternalAttributes(123L);
                                                    
                                                    // Test equality with itself
                                                    assertTrue("An object should be equal to itself", entry.equals(entry));
                                                    
                                                    // Additional checks to ensure the test is thorough
                                                    // The mutated version would proceed to name comparison
                                                    assertEquals("test.txt", entry.getName());
                                                    assertTrue(entry.getName().equals(entry.getName()));
                                                }

 @Test
                                                public void testEqualsWithDifferentObjectsSameName() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("same.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("same.txt");
                                                    
                                                    // Different objects with same name should be equal
                                                    assertTrue(entry1.equals(entry2));
                                                }

 @Test
                                                public void testEqualsWithDifferentNames1() {
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("file1.txt");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("file2.txt");
                                                    
                                                    // Different names should not be equal
                                                    assertFalse(entry1.equals(entry2));
                                                }

 @Test
                                                public void testEqualsWithNull() {
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    
                                                    // Comparison with null should return false
                                                    assertFalse(entry.equals(null));
                                                }

 @Test
                                                public void testEqualsWithDifferentClass() {
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                    Object obj = new Object();
                                                    
                                                    // Comparison with different class should return false
                                                    assertFalse(entry.equals(obj));
                                                }

 @Test
                                          public void testEqualsWithNullNameShouldReturnFalseWhenOtherNameNotNull1() {
                                              // Create first entry with non-null name (we'll set it to null via reflection)
                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                              // Use reflection to set private name field to null since setName() might prevent null
                                              try {
                                                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                  nameField.setAccessible(true);
                                                  nameField.set(entry1, null);
                                              } catch (Exception e) {
                                                  fail("Failed to set name field to null via reflection");
                                              }
                                              
                                              // Create second entry with non-null name
                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                              
                                              // Original should return false, mutant would either return true or throw NPE
                                              assertFalse(entry1.equals(entry2));
                                          }

 @Test
                                          public void testEqualsWithNonNullNameShouldReturnFalseWhenOtherNameIsNull() {
                                              // Create first entry with non-null name
                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                              
                                              // Create second entry with dummy name (will be set to null via reflection)
                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                              try {
                                                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                  nameField.setAccessible(true);
                                                  nameField.set(entry2, null);
                                              } catch (Exception e) {
                                                  fail("Failed to set name field to null via reflection");
                                              }
                                              
                                              // Original should return false, mutant would throw NPE when calling equals on null
                                              assertFalse(entry1.equals(entry2));
                                          }

 @Test
                                     public void testEqualsWithNullNameAndNonNullNameShouldReturnFalse() {
                                         // Create first entry with null name using reflection
                                         ZipArchiveEntry entry1;
                                         try {
                                             Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                             constructor.setAccessible(true);
                                             entry1 = constructor.newInstance();
                                             
                                             // Use reflection to set null name since setName is protected
                                             Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                             nameField.setAccessible(true);
                                             nameField.set(entry1, null);
                                         } catch (Exception e) {
                                             fail("Failed to create entry or set name field via reflection");
                                             return;
                                         }
                                         
                                         // Create second entry with non-null name
                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                         
                                         // Test equality - should return false since one name is null and other isn't
                                         assertFalse("Entries with null and non-null names should not be equal", 
                                                    entry1.equals(entry2));
                                         
                                         // Also test reverse comparison
                                         assertFalse("Entries with non-null and null names should not be equal",
                                                    entry2.equals(entry1));
                                     }

 @Test
                                public void testEqualsWithNullNameCombinations() throws Exception {
                                    // Create two entries with different name states
                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                    // Use reflection to set null name for first entry
                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                    setNameMethod.setAccessible(true);
                                    setNameMethod.invoke(entry1, new Object[] { null });
                                    
                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");  // Second entry has non-null name
                                    
                                    // Test both combinations
                                    // Case 1: entry1 (null) vs entry2 (non-null)
                                    assertFalse("Should return false when comparing null name with non-null", 
                                               entry1.equals(entry2));
                                    
                                    // Case 2: entry2 (non-null) vs entry1 (null)
                                    assertFalse("Should return false when comparing non-null name with null", 
                                               entry2.equals(entry1));
                                    
                                    // Also test with both null names
                                    ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                    setNameMethod.invoke(entry3, new Object[] { null });
                                    assertTrue("Should return true when both names are null", 
                                              entry1.equals(entry3));
                                }

 @Test
                                public void testEqualsWithSameObjectReference1() {
                                    // Create a ZipArchiveEntry object
                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                    
                                    // Test that object equals itself (reference equality)
                                    assertTrue("Object should equal itself", entry.equals(entry));
                                    
                                    // Additional check that the equals method is reflexive
                                    assertTrue("Equals should be reflexive", entry.equals(entry));
                                }

 @Test
                                public void testEqualsContract() {
                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("file1.txt");
                                    ZipArchiveEntry entry2 = entry1;
                                    
                                    // This would fail if the mutant changes the reference equality check
                                    assertTrue("Same reference objects should be equal", entry1.equals(entry2));
                                }

 @Test
                          public void testEqualsWhenFirstNameNullAndSecondNameNotNull1() {
                              // Create first entry with null name
                              ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                              // Use reflection to set the private name field to null since there's no setter
                              try {
                                  Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                  nameField.setAccessible(true);
                                  nameField.set(entry1, null);
                              } catch (Exception e) {
                                  fail("Failed to set name field via reflection");
                              }
                              
                              // Create second entry with non-null name
                              ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                              
                              // Test the equals method
                              assertFalse("Should return false when first name is null and second is not", 
                                          entry1.equals(entry2));
                              
                              // Also test the reverse case for completeness
                              assertFalse("Should return false when second name is null and first is not",
                                          entry2.equals(entry1));
                          }

 @Test
                     public void testEqualsWithOneNullName1() {
                         // Create two entries with dummy names
                         ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                         ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                         
                         // Set entry1's name to null (using reflection since name is private)
                         try {
                             java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                             nameField.setAccessible(true);
                             nameField.set(entry1, null);
                             nameField.set(entry2, "someName");
                         } catch (Exception e) {
                             fail("Failed to set name fields via reflection");
                         }
                         
                         // Test the equals behavior
                         // Original should return true (!false), mutant returns false
                         assertTrue("Entries with one null name should be considered equal", 
                                   entry1.equals(entry2));
                         
                         // Also test reverse case (otherName null, myName not null)
                         try {
                             java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                             nameField.setAccessible(true);
                             nameField.set(entry1, "someName");
                             nameField.set(entry2, null);
                         } catch (Exception e) {
                             fail("Failed to set name fields via reflection");
                         }
                         
                         assertTrue("Entries with one null name should be considered equal", 
                                   entry1.equals(entry2));
                     }

 @Test
                public void testEqualsWithOneNullName2() throws Exception {
                    // Create two entries with dummy names first
                    ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                    ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                    
                    // Use reflection to access protected setName method
                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                    setNameMethod.setAccessible(true);
                    
                    // Set one name to null and other to non-null
                    setNameMethod.invoke(entry1, (String)null);
                    setNameMethod.invoke(entry2, "test.txt");
                    
                    // Verify equals returns false when one name is null and other isn't
                    assertFalse("Entries with one null name should not be equal", 
                               entry1.equals(entry2));
                    assertFalse("Entries with one null name should not be equal (reverse)", 
                               entry2.equals(entry1));
                    
                    // Also test case where both names are null
                    setNameMethod.invoke(entry2, (String)null);
                    assertTrue("Entries with both names null should be equal", 
                              entry1.equals(entry2));
                }

 @Test
            public void testEqualsWithSameObjectShouldReturnTrue() {
                // Create a ZipArchiveEntry object
                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                
                // Test equality with itself
                // This should return true immediately in original code
                // But mutant will skip this check and go through full comparison
                assertTrue("Object should be equal to itself", entry.equals(entry));
                
                // Additional verification that name comparison would also pass
                // This ensures we're not getting a false positive
                assertEquals("test.txt", entry.getName());
            }

 @Test
          public void testEqualsWithNullNameShouldReturnFalseWhenOtherNameNotNull2() {
              // Create first entry with null name
              ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
              // Use reflection to set private name field to null since setName() might prevent null
              try {
                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                  nameField.setAccessible(true);
                  nameField.set(entry1, null);
              } catch (Exception e) {
                  fail("Failed to set name field to null via reflection");
              }
              
              // Create second entry with non-null name
              ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
              
              // Original should return false, mutant would throw NullPointerException
              assertFalse(entry1.equals(entry2));
          }

 @Test
          public void testEqualsWithNonNullNameShouldReturnFalseWhenOtherNameIsNull1() {
              // Create first entry with non-null name
              ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
              
              // Create second entry with a dummy name first
              ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
              try {
                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                  nameField.setAccessible(true);
                  nameField.set(entry2, null);
              } catch (Exception e) {
                  fail("Failed to set name field to null via reflection");
              }
              
              // Original should return false, mutant would proceed to equals check
              assertFalse(entry1.equals(entry2));
          }

 @Test
     public void testEqualsWithNameNullVsNonNull1() throws Exception {
         // Create first entry with null name using reflection
         Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
         constructor.setAccessible(true);
         ZipArchiveEntry entry1 = constructor.newInstance();
         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
         setNameMethod.setAccessible(true);
         setNameMethod.invoke(entry1, (String)null);
         
         // Create second entry with non-null name using public constructor
         ZipArchiveEntry entry2 = new ZipArchiveEntry("someName");
         
         // Original would return false (since one name is null and other isn't)
         // Mutated would return true (due to if(true) instead of if(otherName != null))
         assertFalse("Entries with null vs non-null names should not be equal", 
                    entry1.equals(entry2));
         
         // Also test reverse case
         assertFalse("Entries with non-null vs null names should not be equal",
                    entry2.equals(entry1));
     }

 @Test
     public void testEqualsWithBothNamesNull() throws Exception {
         // Create two entries with null names using reflection
         ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
         setNameMethod.setAccessible(true);
         setNameMethod.invoke(entry1, new Object[] { null });
         
         ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
         setNameMethod.invoke(entry2, new Object[] { null });
         
         // Both original and mutated should return true
         assertTrue("Entries with both null names should be equal",
                   entry1.equals(entry2));
     }

 @Test
     public void testEqualsWithNonNullNames() throws Exception {
         // Create two entries with same non-null names
         ZipArchiveEntry entry1 = new ZipArchiveEntry("sameName");
         ZipArchiveEntry entry2 = new ZipArchiveEntry("sameName");
         
         assertTrue("Entries with same names should be equal",
                   entry1.equals(entry2));
         
         // Create entry with different name
         ZipArchiveEntry entry3 = new ZipArchiveEntry("differentName");
         
         assertFalse("Entries with different names should not be equal",
                    entry1.equals(entry3));
     }

 @Test
     public void testEqualsWithNullOtherName1() {
         // Create first entry with non-null name
         ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
         
         // Create second entry with null name using protected constructor
         ZipArchiveEntry entry2 = new ZipArchiveEntry() {
             @Override
             public String getName() {
                 return null;
             }
         };
         
         // Test equality in both directions
         assertFalse("Entries should not be equal when one name is null", 
                    entry1.equals(entry2));
         assertFalse("Entries should not be equal when one name is null (reverse)", 
                    entry2.equals(entry1));
     }

 @Test
     public void testEqualsWithBothNullNames1() {
         // Create two entries with null names using protected constructor
         ZipArchiveEntry entry1 = new ZipArchiveEntry() {
             @Override
             public String getName() {
                 return null;
             }
         };
         
         ZipArchiveEntry entry2 = new ZipArchiveEntry() {
             @Override
             public String getName() {
                 return null;
             }
         };
         
         assertTrue("Entries should be equal when both names are null", 
                   entry1.equals(entry2));
     }

 @Test
     public void testEqualsWithDifferentNonNullNames() {
         ZipArchiveEntry entry1 = new ZipArchiveEntry("name1");
         ZipArchiveEntry entry2 = new ZipArchiveEntry("name2");
         
         assertFalse("Entries should not be equal with different names", 
                    entry1.equals(entry2));
     }

 @Test
     public void testEqualsWithSameNonNullNames() {
         ZipArchiveEntry entry1 = new ZipArchiveEntry("name");
         ZipArchiveEntry entry2 = new ZipArchiveEntry("name");
         
         assertTrue("Entries should be equal with same names", 
                   entry1.equals(entry2));
     }

}
