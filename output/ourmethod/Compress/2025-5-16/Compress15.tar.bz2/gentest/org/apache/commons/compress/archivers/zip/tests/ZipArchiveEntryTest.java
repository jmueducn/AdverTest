package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                    public void testEquals_Reflexive() {
                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                        assertTrue(entry.equals(entry));
                                                                    }

    @Test
                                                                    public void testEquals_NullComparison() {
                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                        assertFalse(entry.equals(null));
                                                                    }

    @Test
                                                                    public void testEquals_DifferentClass() {
                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                        assertFalse(entry.equals("string object"));
                                                                    }

    @Test
                                                                    public void testEquals_SameNameDifferentAttributes() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        entry1.setMethod(1);
                                                                        entry1.setSize(100);
                                                                        entry1.setInternalAttributes(2);
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        entry2.setMethod(2);
                                                                        entry2.setSize(200);
                                                                        entry2.setInternalAttributes(3);
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_DifferentNameSameAttributes() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                                        
                                                                        // Set all other attributes the same
                                                                        entry1.setMethod(1);
                                                                        entry2.setMethod(1);
                                                                        entry1.setSize(100);
                                                                        entry2.setSize(100);
                                                                        // ... set other attributes the same
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_AllAttributesSame() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        entry1.setMethod(1);
                                                                        entry1.setSize(100);
                                                                        entry1.setInternalAttributes(2);
                                                                        entry1.setExternalAttributes(123L);
                                                                        entry1.setTime(new Date().getTime());
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        entry2.setMethod(1);
                                                                        entry2.setSize(100);
                                                                        entry2.setInternalAttributes(2);
                                                                        entry2.setExternalAttributes(123L);
                                                                        entry2.setTime(entry1.getTime());
                                                                        
                                                                        assertTrue(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_DifferentTime() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        entry1.setTime(1000L);
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        entry2.setTime(2000L);
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_DifferentComments() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        entry1.setComment("comment1");
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        entry2.setComment("comment2");
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_NullComments() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        entry1.setComment(null);
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        entry2.setComment("comment");
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                        
                                                                        ZipArchiveEntry entry3 = new ZipArchiveEntry("test.txt");
                                                                        entry3.setComment(null);
                                                                        
                                                                        assertTrue(entry1.equals(entry3));
                                                                    }

    @Test
                                                                    public void testEquals_DifferentExtraFields() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        entry1.setExtra(new byte[]{1, 2, 3});
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        entry2.setExtra(new byte[]{4, 5, 6});
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_DifferentGeneralPurposeBit() {
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                        GeneralPurposeBit gpb1 = mock(GeneralPurposeBit.class);
                                                                        when(gpb1.equals(any())).thenReturn(false);
                                                                        entry1.setGeneralPurposeBit(gpb1);
                                                                        
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                        GeneralPurposeBit gpb2 = mock(GeneralPurposeBit.class);
                                                                        entry2.setGeneralPurposeBit(gpb2);
                                                                        
                                                                        assertFalse(entry1.equals(entry2));
                                                                    }

    @Test
                                                                    public void testEquals_FileConstructor() throws Exception {
                                                                        File tempFile = File.createTempFile("test", ".txt");
                                                                        tempFile.deleteOnExit();
                                                                        
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry(tempFile, "test.txt");
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry(tempFile, "test.txt");
                                                                        
                                                                        assertTrue(entry1.equals(entry2));
                                                                    }

    @Test
                                                            public void testEquals_NullNameComparison() {
                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                                
                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                
                                                                assertFalse(entry1.equals(entry2));
                                                                
                                                                ZipArchiveEntry entry3 = new ZipArchiveEntry((String)null);
                                                                
                                                                assertTrue(entry1.equals(entry3));
                                                            }

    @Test
                                                       public void testEqualsWithSameObjectShouldUseReferenceEquality() {
                                                           // Create a real ZipArchiveEntry object
                                                           ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                           
                                                           // Mock the expensive operations that shouldn't be called
                                                           byte[] mockExtra = new byte[0];
                                                           entry.setCentralDirectoryExtra(mockExtra);
                                                           entry.setExtra(mockExtra);
                                                           
                                                           // Mock GeneralPurposeBit to verify it's not called
                                                           GeneralPurposeBit mockGpb = mock(GeneralPurposeBit.class);
                                                           entry.setGeneralPurposeBit(mockGpb);
                                                           
                                                           // Test equality with itself
                                                           assertTrue("Object should be equal to itself", entry.equals(entry));
                                                           
                                                           // Verify no expensive operations were called
                                                           verify(mockGpb, never()).equals(any());
                                                           // Note: In original code, these verifications would pass because reference equality shortcut works
                                                           // In mutated code, these verifications would fail because full comparison is performed
                                                       }

    @Test
                                                  public void testEqualsWithNullNameShouldDetectMutant() {
                                                      // Create first entry with null name
                                                      ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                      // Use reflection to set the private name field to null since there's no public setter
                                                      try {
                                                          Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                          nameField.setAccessible(true);
                                                          nameField.set(entry1, null);
                                                      } catch (Exception e) {
                                                          fail("Failed to set name field via reflection");
                                                      }
                                                      
                                                      // Create second entry with non-null name
                                                      ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                      
                                                      // Test equality - should return false since one name is null and other isn't
                                                      assertFalse("Entries with null and non-null names should not be equal", entry1.equals(entry2));
                                                      
                                                      // Also test case where both names are null
                                                      ZipArchiveEntry entry3 = new ZipArchiveEntry("");
                                                      try {
                                                          Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                          nameField.setAccessible(true);
                                                          nameField.set(entry3, null);
                                                      } catch (Exception e) {
                                                          fail("Failed to set name field via reflection");
                                                      }
                                                      
                                                      // Should return true only if all other fields match (we'll set them to match)
                                                      entry1.setTime(1000);
                                                      entry3.setTime(1000);
                                                      assertTrue("Entries with both null names should be equal if other fields match", entry1.equals(entry3));
                                                  }

    @Test
                                             public void testEqualsWithNullNameVsNonNullName() throws Exception {
                                                 // Create two entries with different name scenarios
                                                 ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                 // Use reflection to set name to null
                                                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                 setNameMethod.setAccessible(true);
                                                 setNameMethod.invoke(entry1, (String)null);
                                                 
                                                 ZipArchiveEntry entry2 = new ZipArchiveEntry("testEntry");
                                                 setNameMethod.invoke(entry2, "nonNullName");
                                                 
                                                 // Set all other fields equal to ensure only name comparison affects result
                                                 entry1.setTime(entry2.getTime());
                                                 entry1.setComment(entry2.getComment());
                                                 entry1.setInternalAttributes(entry2.getInternalAttributes());
                                                 // Use reflection to set platform
                                                 Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                 setPlatformMethod.setAccessible(true);
                                                 setPlatformMethod.invoke(entry1, entry2.getPlatform());
                                                 entry1.setExternalAttributes(entry2.getExternalAttributes());
                                                 entry1.setMethod(entry2.getMethod());
                                                 entry1.setSize(entry2.getSize());
                                                 entry1.setCrc(entry2.getCrc());
                                                 entry1.setCompressedSize(entry2.getCompressedSize());
                                                 entry1.setCentralDirectoryExtra(entry2.getCentralDirectoryExtra());
                                                 entry1.setExtra(entry2.getLocalFileDataExtra()); // Using setExtra instead
                                                 entry1.setGeneralPurposeBit(entry2.getGeneralPurposeBit());
                                                 
                                                 // Original should return false since one name is null and other isn't
                                                 // Mutant will continue checking other fields and might return true
                                                 assertFalse("Entries with null vs non-null names should not be equal", 
                                                            entry1.equals(entry2));
                                             }

    @Test
                                        public void testEqualsWithDifferentCommentsShouldReturnFalse() {
                                            // Create first entry with non-null comment
                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                            entry1.setComment("comment1");
                                            
                                            // Create second entry with different non-null comment
                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
                                            entry2.setComment("comment2");
                                            
                                            // Set all other fields to be equal
                                            entry1.setTime(12345L);
                                            entry2.setTime(12345L);
                                            entry1.setInternalAttributes(1);
                                            entry2.setInternalAttributes(1);
                                            
                                            // Use reflection to set protected platform field
                                            try {
                                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                setPlatform.setAccessible(true);
                                                setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                                setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                            } catch (Exception e) {
                                                fail("Failed to set platform via reflection: " + e.getMessage());
                                            }
                                            
                                            entry1.setExternalAttributes(2L);
                                            entry2.setExternalAttributes(2L);
                                            entry1.setMethod(3);
                                            entry2.setMethod(3);
                                            entry1.setSize(100L);
                                            entry2.setSize(100L);
                                            entry1.setCrc(123456L);
                                            entry2.setCrc(123456L);
                                            entry1.setCompressedSize(80L);
                                            entry2.setCompressedSize(80L);
                                            entry1.setExtra(new byte[0]);
                                            entry2.setExtra(new byte[0]);
                                            
                                            // Create mock GeneralPurposeBit with equals returning true
                                            GeneralPurposeBit mockBit = mock(GeneralPurposeBit.class);
                                            when(mockBit.equals(any(GeneralPurposeBit.class))).thenReturn(true);
                                            entry1.setGeneralPurposeBit(mockBit);
                                            entry2.setGeneralPurposeBit(mockBit);
                                            
                                            // Original should return false since comments differ
                                            // Mutated version would return true
                                            assertFalse("Entries with different comments should not be equal", 
                                                       entry1.equals(entry2));
                                        }

    @Test
                                   public void testEqualsDetectsDifferentInternalAttributes() throws Exception {
                                       // Create two entries with same name (other fields will be default)
                                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                       
                                       // Set different internal attributes
                                       entry1.setInternalAttributes(1);
                                       entry2.setInternalAttributes(2);
                                       
                                       // Set all other compared fields to be equal
                                       entry1.setTime(1000L);
                                       entry2.setTime(1000L);
                                       entry1.setComment("comment");
                                       entry2.setComment("comment");
                                       
                                       // Use reflection to set platform since setPlatform is protected
                                       Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                       setPlatform.setAccessible(true);
                                       setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                       setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                       
                                       entry1.setExternalAttributes(123L);
                                       entry2.setExternalAttributes(123L);
                                       entry1.setMethod(8);
                                       entry2.setMethod(8);
                                       entry1.setSize(100L);
                                       entry2.setSize(100L);
                                       // Assume other fields remain equal by default
                                       
                                       // Verify they are not equal due to different internal attributes
                                       assertFalse("Entries with different internal attributes should not be equal", 
                                                   entry1.equals(entry2));
                                       
                                       // Additional verification that internal attributes are indeed different
                                       assertNotEquals(entry1.getInternalAttributes(), entry2.getInternalAttributes());
                                   }

    @Test
                              public void testEquals_shouldReturnFalseWhenPlatformsDiffer() throws Exception {
                                  // Create two entries with same name but different platforms
                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                  
                                  // Set all other attributes to be equal
                                  entry1.setTime(123456789L);
                                  entry2.setTime(123456789L);
                                  entry1.setSize(100L);
                                  entry2.setSize(100L);
                                  entry1.setMethod(8);
                                  entry2.setMethod(8);
                                  entry1.setInternalAttributes(1);
                                  entry2.setInternalAttributes(1);
                                  entry1.setExternalAttributes(2L);
                                  entry2.setExternalAttributes(2L);
                                  
                                  // Set different platforms using reflection
                                  Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                  setPlatform.setAccessible(true);
                                  setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_UNIX);
                                  setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                  
                                  // Verify they are not equal due to platform difference
                                  assertFalse("Entries with different platforms should not be equal", 
                                             entry1.equals(entry2));
                                  
                                  // Also verify symmetry
                                  assertFalse("Entries with different platforms should not be equal", 
                                             entry2.equals(entry1));
                              }

    @Test
                         public void testEqualsWithDifferentExternalAttributes() {
                             // Create two entries with same name (required for equality check)
                             ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                             ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                             
                             // Set all other fields to be equal
                             entry1.setTime(System.currentTimeMillis());
                             entry2.setTime(entry1.getTime());
                             entry1.setSize(100L);
                             entry2.setSize(100L);
                             entry1.setMethod(8);
                             entry2.setMethod(8);
                             entry1.setInternalAttributes(0);
                             entry2.setInternalAttributes(0);
                             
                             // Set platform using reflection since setPlatform is protected
                             try {
                                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                 setPlatform.setAccessible(true);
                                 setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                 setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                             } catch (Exception e) {
                                 fail("Failed to set platform via reflection: " + e.getMessage());
                             }
                             
                             entry1.setComment(null);
                             entry2.setComment(null);
                             
                             // Set different external attributes
                             entry1.setExternalAttributes(1L);
                             entry2.setExternalAttributes(2L);
                             
                             // Verify they are not equal (original behavior)
                             assertFalse(entry1.equals(entry2));
                             
                             // With the mutation (&& true instead of comparing external attributes), 
                             // this would incorrectly return true
                         }

    @Test
                    public void testEquals_differentMethods_shouldReturnFalse() throws Exception {
                        // Create two entries with same attributes except method
                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
                        
                        // Set all other fields to be equal
                        entry1.setTime(123456789L);
                        entry2.setTime(123456789L);
                        entry1.setInternalAttributes(1);
                        entry2.setInternalAttributes(1);
                        
                        // Use reflection to set protected platform field
                        Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                        setPlatform.setAccessible(true);
                        setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                        setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                        
                        entry1.setExternalAttributes(2L);
                        entry2.setExternalAttributes(2L);
                        entry1.setSize(100L);
                        entry2.setSize(100L);
                        entry1.setComment("comment");
                        entry2.setComment("comment");
                        
                        // Set different methods
                        entry1.setMethod(8);  // Different compression method
                        entry2.setMethod(0);  // Stored (no compression)
                        
                        // Verify they are not equal
                        assertFalse(entry1.equals(entry2));
                        
                        // Also verify symmetry
                        assertFalse(entry2.equals(entry1));
                    }

    @Test
               public void testEquals_shouldReturnFalseWhenSizesDiffer() {
                   // Create two entries with same name but different sizes
                   ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                   entry1.setSize(100L);
                   
                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                   entry2.setSize(200L);  // Different size
                   
                   // Set all other fields to be equal
                   entry1.setTime(entry2.getTime());
                   entry1.setMethod(entry2.getMethod());
                   entry1.setInternalAttributes(entry2.getInternalAttributes());
                   entry1.setExternalAttributes(entry2.getExternalAttributes());
                   entry1.setComment(entry2.getComment());
                   entry1.setGeneralPurposeBit(entry2.getGeneralPurposeBit());
                   
                   // Verify they are not equal due to size difference
                   assertFalse("Entries with different sizes should not be equal", 
                              entry1.equals(entry2));
                   
                   // Additional verification that size is the only difference
                   entry2.setSize(entry1.getSize());
                   assertTrue("Entries should be equal when sizes match", 
                             entry1.equals(entry2));
               }

    @Test
          public void testEquals_ShouldReturnFalseWhenCrcValuesDiffer() throws Exception {
              // Create first entry with default values
              ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
              entry1.setSize(100L);
              entry1.setMethod(8);
              entry1.setCrc(12345L);  // Assuming there's a setCrc method
              
              // Create second entry with same values except CRC
              ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
              entry2.setSize(100L);
              entry2.setMethod(8);
              entry2.setCrc(54321L);  // Different CRC value
              
              // Set all other attributes to be equal
              entry1.setInternalAttributes(0);
              entry2.setInternalAttributes(0);
              entry1.setExternalAttributes(0L);
              entry2.setExternalAttributes(0L);
              entry1.setUnixMode(0); // This will set platform to PLATFORM_FAT internally
              entry2.setUnixMode(0); // This will set platform to PLATFORM_FAT internally
              entry1.setComment("");
              entry2.setComment("");
              entry1.setTime(System.currentTimeMillis());
              entry2.setTime(entry1.getTime());
              
              // Mock GeneralPurposeBit to return equal objects
              GeneralPurposeBit gpb1 = mock(GeneralPurposeBit.class);
              GeneralPurposeBit gpb2 = mock(GeneralPurposeBit.class);
              when(gpb1.equals(gpb2)).thenReturn(true);
              entry1.setGeneralPurposeBit(gpb1);
              entry2.setGeneralPurposeBit(gpb2);
              
              // Set empty extra fields
              entry1.setExtra(new byte[0]);
              entry2.setExtra(new byte[0]);
              
              // Verify that entries are not equal due to different CRC values
              assertFalse("Entries with different CRC values should not be equal", 
                         entry1.equals(entry2));
          }

    @Test
      public void testEquals_shouldReturnFalseWhenCompressedSizesDiffer() {
          // Create two entries with same name (minimum required for equals comparison)
          ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
          ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
          
          // Set all other relevant fields to be equal
          entry1.setTime(123456789L);
          entry2.setTime(123456789L);
          entry1.setSize(1000L);
          entry2.setSize(1000L);
          entry1.setCrc(12345L);
          entry2.setCrc(12345L);
          entry1.setMethod(8);
          entry2.setMethod(8);
          
          // Set different compressed sizes
          entry1.setCompressedSize(500L);
          entry2.setCompressedSize(600L); // Different from entry1
          
          // Verify they are not equal
          assertFalse("Entries with different compressed sizes should not be equal", 
                     entry1.equals(entry2));
          
          // Also verify symmetry
          assertFalse("Entries with different compressed sizes should not be equal (symmetry check)",
                     entry2.equals(entry1));
      }

    @Test
    public void testEquals_ShouldReturnFalseWhenGeneralPurposeBitsDiffer() throws Exception {
        // Create two entries with same properties but different gpb
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
        
        // Mock GeneralPurposeBit objects with different equals behavior
        GeneralPurposeBit gpb1 = mock(GeneralPurposeBit.class);
        GeneralPurposeBit gpb2 = mock(GeneralPurposeBit.class);
        
        // Set up the entries to be identical except for gpb
        entry1.setGeneralPurposeBit(gpb1);
        entry2.setGeneralPurposeBit(gpb2);
        
        // Make all other fields equal
        entry1.setTime(123456789L);
        entry2.setTime(123456789L);
        entry1.setSize(100L);
        entry2.setSize(100L);
        entry1.setMethod(8);
        entry2.setMethod(8);
        entry1.setInternalAttributes(1);
        entry2.setInternalAttributes(1);
        entry1.setExternalAttributes(2L);
        entry2.setExternalAttributes(2L);
        
        // Configure gpb.equals to return false when comparing to each other
        when(gpb1.equals(gpb2)).thenReturn(false);
        
        // The original equals should return false because gpb differs
        assertFalse(entry1.equals(entry2));
        
        // Verify the interaction - this ensures gpb.equals was actually called
        verify(gpb1).equals(gpb2);
    }


}
