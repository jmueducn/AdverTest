package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Checksum;
 
public class ChecksumCalculatingInputStreamTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

       @Test
                                                     public void testConstructor_ValidParameters_SuccessfullyInitializes() {
                                                         // Arrange
                                                         Checksum mockChecksum = mock(Checksum.class);
                                                         InputStream mockInputStream = mock(InputStream.class);
                                                 
                                                         // Act
                                                         ChecksumCalculatingInputStream stream = new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                 
                                                         // Assert - No exception thrown means success
                                                         // We can't directly verify private fields, but the constructor should complete successfully
                                                     }

 @Test
                                                     public void testConstructor_NullChecksum_ThrowsNullPointerException() {
                                                         // Arrange
                                                         InputStream mockInputStream = mock(InputStream.class);
                                                         
                                                         // Expect exception
                                                         thrown.expect(NullPointerException.class);
                                                         thrown.expectMessage("Parameter checksum must not be null");
                                                 
                                                         // Act
                                                         new ChecksumCalculatingInputStream(null, mockInputStream);
                                                     }

 @Test
                                                     public void testConstructor_NullInputStream_ThrowsNullPointerException() {
                                                         // Arrange
                                                         Checksum mockChecksum = mock(Checksum.class);
                                                         
                                                         // Expect exception
                                                         thrown.expect(NullPointerException.class);
                                                         thrown.expectMessage("Parameter in must not be null");
                                                 
                                                         // Act
                                                         new ChecksumCalculatingInputStream(mockChecksum, null);
                                                     }

 @Test
                                                     public void testConstructor_BothParametersNull_ThrowsNullPointerExceptionForChecksumFirst() {
                                                         // Arrange
                                                         // Expect exception for checksum parameter first
                                                         thrown.expect(NullPointerException.class);
                                                         thrown.expectMessage("Parameter checksum must not be null");
                                                 
                                                         // Act
                                                         new ChecksumCalculatingInputStream(null, null);
                                                     }

 @Test
                                                public void testConstructorWithNullInputStreamShouldThrowException() {
                                                    // Setup
                                                    Checksum mockChecksum = mock(Checksum.class);
                                                    InputStream nullInputStream = null;
                                                    
                                                    // Expect exception
                                                    thrown.expect(NullPointerException.class);
                                                    thrown.expectMessage("Parameter in must not be null");
                                                    
                                                    // Test
                                                    new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                }

 @Test
                                                public void testConstructorWithNonNullInputStreamShouldNotThrowException() {
                                                    // Setup
                                                    Checksum mockChecksum = mock(Checksum.class);
                                                    InputStream mockInputStream = mock(InputStream.class);
                                                    
                                                    // Test - should not throw exception
                                                    new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                }

 @Test
                                                public void testConstructorWithNullChecksumShouldThrowException() {
                                                    // Setup
                                                    Checksum nullChecksum = null;
                                                    InputStream mockInputStream = mock(InputStream.class);
                                                    
                                                    // Expect exception
                                                    thrown.expect(NullPointerException.class);
                                                    thrown.expectMessage("Parameter checksum must not be null");
                                                    
                                                    // Test
                                                    new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                }

 @Test
                                               public void testConstructorShouldThrowWhenInputStreamIsNull() {
                                                   // Prepare test data
                                                   Checksum mockChecksum = mock(Checksum.class);
                                                   InputStream nullInputStream = null;
                                           
                                                   // Set expectation
                                                   thrown.expect(NullPointerException.class);
                                                   thrown.expectMessage("Parameter in must not be null");
                                           
                                                   // Execute test
                                                   new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                               }

 @Test
                                               public void testConstructorShouldThrowWhenChecksumIsNull() {
                                                   // Prepare test data
                                                   Checksum nullChecksum = null;
                                                   InputStream mockInputStream = mock(InputStream.class);
                                           
                                                   // Set expectation
                                                   thrown.expect(NullPointerException.class);
                                                   thrown.expectMessage("Parameter checksum must not be null");
                                           
                                                   // Execute test
                                                   new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                               }

 @Test
                                               public void testConstructorShouldNotThrowWhenBothParametersAreValid() {
                                                   // Prepare test data
                                                   Checksum mockChecksum = mock(Checksum.class);
                                                   InputStream mockInputStream = mock(InputStream.class);
                                           
                                                   // Execute test - should not throw any exception
                                                   new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                               }

 @Test
                                              public void testConstructorShouldThrowWhenInputStreamIsNull1() {
                                                  // Prepare
                                                  Checksum mockChecksum = mock(Checksum.class);
                                                  InputStream nullInputStream = null;
                                                  
                                                  // Expect
                                                  thrown.expect(NullPointerException.class);
                                                  thrown.expectMessage("Parameter in must not be null");
                                                  
                                                  // Execute
                                                  new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                              }

 @Test
                                              public void testConstructorShouldThrowWhenChecksumIsNull1() {
                                                  // Prepare
                                                  Checksum nullChecksum = null;
                                                  InputStream mockInputStream = mock(InputStream.class);
                                                  
                                                  // Expect
                                                  thrown.expect(NullPointerException.class);
                                                  thrown.expectMessage("Parameter checksum must not be null");
                                                  
                                                  // Execute
                                                  new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                              }

 @Test
                                              public void testConstructorShouldNotThrowWhenParametersAreValid() {
                                                  // Prepare
                                                  Checksum mockChecksum = mock(Checksum.class);
                                                  InputStream mockInputStream = mock(InputStream.class);
                                                  
                                                  // Execute (should not throw)
                                                  new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                              }

 @Test
                                             public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull() {
                                                 // Setup
                                                 Checksum mockChecksum = mock(Checksum.class);
                                                 
                                                 // Expect exception
                                                 thrown.expect(NullPointerException.class);
                                                 thrown.expectMessage("Parameter in must not be null");
                                                 
                                                 // Test - this should throw NullPointerException
                                                 new ChecksumCalculatingInputStream(mockChecksum, null);
                                             }

 @Test
                                             public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull() {
                                                 // Setup
                                                 InputStream mockInputStream = mock(InputStream.class);
                                                 
                                                 // Expect exception
                                                 thrown.expect(NullPointerException.class);
                                                 thrown.expectMessage("Parameter checksum must not be null");
                                                 
                                                 // Test - this should throw NullPointerException
                                                 new ChecksumCalculatingInputStream(null, mockInputStream);
                                             }

 @Test
                                            public void testConstructorSetsChecksumField() throws Exception {
                                                // Arrange
                                                Checksum mockChecksum = mock(Checksum.class);
                                                InputStream mockInputStream = mock(InputStream.class);
                                                
                                                // Act
                                                ChecksumCalculatingInputStream stream = new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                
                                                // Assert that the checksum field was set properly by calling getValue()
                                                // which should use the checksum we provided
                                                when(mockChecksum.getValue()).thenReturn(123L);
                                                long result = stream.getValue();
                                                
                                                assertEquals(123L, result);
                                                verify(mockChecksum).getValue();
                                            }

 @Test(expected = NullPointerException.class)
                                            public void testConstructorThrowsWhenChecksumIsNull() {
                                                InputStream mockInputStream = mock(InputStream.class);
                                                new ChecksumCalculatingInputStream(null, mockInputStream);
                                            }

 @Test(expected = NullPointerException.class)
                                            public void testConstructorThrowsWhenInputStreamIsNull() {
                                                Checksum mockChecksum = mock(Checksum.class);
                                                new ChecksumCalculatingInputStream(mockChecksum, null);
                                            }

 @Test
                                           public void testConstructorSetsInputStreamFieldCorrectly() throws Exception {
                                               // Prepare test data
                                               Checksum mockChecksum = mock(Checksum.class);
                                               InputStream testInputStream = new ByteArrayInputStream("test".getBytes());
                                               
                                               // Create instance
                                               ChecksumCalculatingInputStream stream = 
                                                   new ChecksumCalculatingInputStream(mockChecksum, testInputStream);
                                                   
                                               // Verify the field was set correctly by attempting to read
                                               // If the mutant is present (in=null), this will throw NullPointerException
                                               byte[] buffer = new byte[4];
                                               int bytesRead = stream.read(buffer);
                                               
                                               // Additional verification
                                               assertEquals(4, bytesRead); // Verify read worked
                                               assertArrayEquals("test".getBytes(), buffer); // Verify correct data was read
                                           }

 @Test(expected = NullPointerException.class)
                                           public void testConstructorThrowsWhenChecksumIsNull1() {
                                               InputStream testInputStream = new ByteArrayInputStream("test".getBytes());
                                               new ChecksumCalculatingInputStream(null, testInputStream);
                                           }

 @Test(expected = NullPointerException.class)
                                           public void testConstructorThrowsWhenInputStreamIsNull1() {
                                               Checksum mockChecksum = mock(Checksum.class);
                                               new ChecksumCalculatingInputStream(mockChecksum, null);
                                           }

 @Test(expected = NullPointerException.class)
                                      public void testConstructorWithNonNullChecksumShouldNotThrowExceptionButMutantDoes() throws Exception {
                                          // Arrange
                                          Checksum mockChecksum = mock(Checksum.class);
                                          InputStream mockInputStream = mock(InputStream.class);
                                          
                                          // Act - This should not throw exception in original code, but will throw in mutated version
                                          new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                          
                                          // Assert - If we reach here in original code, test passes (no exception)
                                          // If exception is thrown (mutant case), the @Test(expected) will catch it
                                      }

 @Test
                                    public void testConstructorWithNonNullInputStreamShouldNotThrowException1() {
                                        // Prepare test data
                                        Checksum checksum = mock(Checksum.class);
                                        InputStream inputStream = mock(InputStream.class);
                                        
                                        // Test and verify
                                        try {
                                            ChecksumCalculatingInputStream stream = 
                                                new ChecksumCalculatingInputStream(checksum, inputStream);
                                            // If we get here, constructor worked as expected
                                            assertNotNull(stream);
                                            
                                            // Use reflection to verify fields were set correctly
                                            Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                            checksumField.setAccessible(true);
                                            assertEquals(checksum, checksumField.get(stream));
                                            
                                            Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                            inField.setAccessible(true);
                                            assertEquals(inputStream, inField.get(stream));
                                        } catch (NullPointerException e) {
                                            fail("Constructor threw NullPointerException with valid non-null parameters");
                                        } catch (Exception e) {
                                            fail("Unexpected exception occurred: " + e.getMessage());
                                        }
                                    }

 @Test
                                    public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull() {
                                        // Arrange
                                        Checksum checksum = mock(Checksum.class);
                                        
                                        // Expect exception
                                        thrown.expect(NullPointerException.class);
                                        thrown.expectMessage("Parameter in must not be null");
                                        
                                        // Act - this should throw NullPointerException
                                        new ChecksumCalculatingInputStream(checksum, null);
                                    }

 @Test
                                    public void testConstructorShouldThrowNullPointerExceptionWhenChecksumIsNull() {
                                        // Arrange
                                        InputStream inputStream = mock(InputStream.class);
                                        
                                        // Expect exception
                                        thrown.expect(NullPointerException.class);
                                        thrown.expectMessage("Parameter checksum must not be null");
                                        
                                        // Act - this should throw NullPointerException
                                        new ChecksumCalculatingInputStream(null, inputStream);
                                    }

 @Test
                                    public void testConstructorShouldNotThrowExceptionWhenParametersAreValid() {
                                        // Arrange
                                        Checksum checksum = mock(Checksum.class);
                                        InputStream inputStream = mock(InputStream.class);
                                        
                                        // Act - should not throw any exception
                                        new ChecksumCalculatingInputStream(checksum, inputStream);
                                        
                                        // No exception means test passes
                                    }

 @Test
                                   public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull1() {
                                       // Prepare test data
                                       Checksum mockChecksum = mock(Checksum.class);
                                       InputStream nullInputStream = null;
                                       
                                       // Set expectations
                                       thrown.expect(NullPointerException.class);
                                       thrown.expectMessage("Parameter in must not be null");
                                       
                                       // Execute test
                                       new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                   }

 @Test
                                   public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull1() {
                                       // Prepare test data
                                       Checksum nullChecksum = null;
                                       InputStream mockInputStream = mock(InputStream.class);
                                       
                                       // Set expectations
                                       thrown.expect(NullPointerException.class);
                                       thrown.expectMessage("Parameter checksum must not be null");
                                       
                                       // Execute test
                                       new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                   }

 @Test
                                 public void testConstructorThrowsNPEWhenInputStreamIsNull() {
                                     // Setup
                                     Checksum mockChecksum = mock(Checksum.class);
                                     
                                     // Expect exception
                                     thrown.expect(NullPointerException.class);
                                     thrown.expectMessage("Parameter in must not be null");
                                     
                                     // Test
                                     new ChecksumCalculatingInputStream(mockChecksum, null);
                                 }

 @Test
                                 public void testConstructorThrowsNPEWhenChecksumIsNull() {
                                     // Setup
                                     InputStream mockInputStream = mock(InputStream.class);
                                     
                                     // Expect exception
                                     thrown.expect(NullPointerException.class);
                                     thrown.expectMessage("Parameter checksum must not be null");
                                     
                                     // Test
                                     new ChecksumCalculatingInputStream(null, mockInputStream);
                                 }

 @Test
                                 public void testConstructorSucceedsWithValidParameters() {
                                     // Setup
                                     Checksum mockChecksum = mock(Checksum.class);
                                     InputStream mockInputStream = mock(InputStream.class);
                                     
                                     // Test - should not throw any exception
                                     new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                 }

 @Test
                                public void testConstructorWithNonNullInputStreamShouldNotThrowException2() {
                                    // Prepare test data
                                    Checksum mockChecksum = mock(Checksum.class);
                                    InputStream mockInputStream = mock(InputStream.class);
                                    
                                    // This test will pass with original code but fail with mutated code
                                    try {
                                        ChecksumCalculatingInputStream stream = 
                                            new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                        // If we get here, the test passes (original behavior)
                                        assertNotNull(stream);
                                    } catch (NullPointerException e) {
                                        // If we get here, the test fails (mutated behavior)
                                        fail("Constructor threw NullPointerException with non-null InputStream");
                                    }
                                }

 @Test(expected = NullPointerException.class)
                                public void testConstructorWithNullChecksumShouldThrowException1() {
                                    InputStream mockInputStream = mock(InputStream.class);
                                    new ChecksumCalculatingInputStream(null, mockInputStream);
                                }

 @Test(expected = NullPointerException.class)
                                public void testConstructorWithNullInputStreamShouldThrowException1() {
                                    Checksum mockChecksum = mock(Checksum.class);
                                    new ChecksumCalculatingInputStream(mockChecksum, null);
                                }

 @Test
                               public void testConstructorShouldThrowWhenInputStreamIsNull2() {
                                   // Prepare
                                   Checksum mockChecksum = mock(Checksum.class);
                                   InputStream nullInputStream = null;
                                   
                                   // Expect
                                   thrown.expect(NullPointerException.class);
                                   thrown.expectMessage("Parameter in must not be null");
                                   
                                   // Execute
                                   new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                               }

 @Test
                              public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull2() {
                                  // Prepare test data
                                  Checksum mockChecksum = mock(Checksum.class);
                                  InputStream nullInputStream = null;
                          
                                  // Set expectation for the exception
                                  thrown.expect(NullPointerException.class);
                                  thrown.expectMessage("Parameter in must not be null");
                          
                                  // Execute the test
                                  new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                              }

 @Test
                              public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull2() {
                                  // Prepare test data
                                  Checksum nullChecksum = null;
                                  InputStream mockInputStream = mock(InputStream.class);
                          
                                  // Set expectation for the exception
                                  thrown.expect(NullPointerException.class);
                                  thrown.expectMessage("Parameter checksum must not be null");
                          
                                  // Execute the test
                                  new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                              }

 @Test
                         public void testConstructorSetsChecksumFieldCorrectly() throws Exception {
                             // Arrange
                             Checksum mockChecksum = mock(Checksum.class);
                             InputStream mockInputStream = mock(InputStream.class);
                             
                             // Act
                             ChecksumCalculatingInputStream stream = 
                                 new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                             
                             // Assert that the checksum field was set properly (not null)
                             // We verify this by checking interaction with the mock checksum
                             stream.getValue(); // This should use the checksum field
                             verify(mockChecksum).getValue(); // Verify the mock was actually used
                             
                             // Alternative assertion if we can access the field via reflection
                             try {
                                 Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                 checksumField.setAccessible(true);
                                 Checksum actualChecksum = (Checksum) checksumField.get(stream);
                                 assertSame("Checksum field should be set to the provided checksum object", 
                                           mockChecksum, actualChecksum);
                             } catch (Exception e) {
                                 fail("Failed to verify checksum field via reflection");
                             }
                         }

 @Test
                         public void testConstructorSetsChecksumFieldCorrectly1() throws Exception {
                             // Arrange
                             Checksum mockChecksum = mock(Checksum.class);
                             InputStream mockInputStream = mock(InputStream.class);
                             when(mockChecksum.getValue()).thenReturn(123L);
                             
                             // Act
                             ChecksumCalculatingInputStream stream = 
                                 new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                             long result = stream.getValue();
                             
                             // Assert
                             assertEquals("Should return value from the provided checksum", 123L, result);
                             verify(mockChecksum).getValue();
                         }

 @Test
                            public void testConstructorSetsInputStreamFieldCorrectly1() throws Exception {
                                // Prepare test data
                                Checksum mockChecksum = mock(Checksum.class);
                                InputStream mockInputStream = mock(InputStream.class);
                                
                                // Configure mock behavior
                                when(mockInputStream.read()).thenReturn(42); // Return some test value
                                
                                // Create instance - this is what we're testing
                                ChecksumCalculatingInputStream stream = 
                                    new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                
                                // Verify the field was set correctly by testing its behavior
                                // If the mutant is present (setting in=null), this will throw NullPointerException
                                int result = stream.read();
                                
                                // Additional verification that the mock was actually used
                                verify(mockInputStream).read();
                            }

 @Test(expected = NullPointerException.class)
                            public void testConstructorThrowsOnNullChecksum() {
                                new ChecksumCalculatingInputStream(null, mock(InputStream.class));
                            }

 @Test(expected = NullPointerException.class)
                            public void testConstructorThrowsOnNullInputStream() {
                                new ChecksumCalculatingInputStream(mock(Checksum.class), null);
                            }

 @Test(expected = NullPointerException.class)
                       public void testConstructorWithNonNullChecksumShouldNotThrowExceptionButMutantDoes1() {
                           // Arrange
                           Checksum mockChecksum = mock(Checksum.class);
                           InputStream mockInputStream = mock(InputStream.class);
                           
                           // Act - This should not throw exception in original code, but will throw in mutated version
                           new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                           
                           // Assert - If we reach here in original code, test passes (no exception)
                           // In mutated version, exception will be thrown and caught by @Test(expected)
                           // This verifies the mutant is detected
                       }

 @Test
                          public void testConstructorWithValidInputStreamShouldNotThrowException() {
                              // Prepare test data
                              Checksum mockChecksum = mock(Checksum.class);
                              InputStream mockInputStream = mock(InputStream.class);
                              
                              // This should not throw any exception with original code
                              // But will throw NPE with mutated code
                              new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                              
                              // If we reach here, the test passes (no exception thrown)
                              // The mutant would have thrown NPE before reaching here
                          }

 @Test(expected = NullPointerException.class)
                          public void testConstructorWithNullChecksumShouldThrowException2() {
                              InputStream mockInputStream = mock(InputStream.class);
                              new ChecksumCalculatingInputStream(null, mockInputStream);
                          }

 @Test(expected = NullPointerException.class)
                          public void testConstructorWithNullInputStreamShouldThrowException2() {
                              Checksum mockChecksum = mock(Checksum.class);
                              new ChecksumCalculatingInputStream(mockChecksum, null);
                          }

 @Test
                         public void testConstructorShouldThrowWhenInputStreamIsNull3() {
                             // Prepare test data
                             Checksum mockChecksum = mock(Checksum.class);
                             InputStream nullInputStream = null;
                     
                             // Set expectation
                             thrown.expect(NullPointerException.class);
                             thrown.expectMessage("Parameter in must not be null");
                     
                             // Execute test
                             new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                         }

 @Test
                         public void testConstructorShouldThrowWhenChecksumIsNull2() {
                             // Prepare test data
                             Checksum nullChecksum = null;
                             InputStream mockInputStream = mock(InputStream.class);
                     
                             // Set expectation
                             thrown.expect(NullPointerException.class);
                             thrown.expectMessage("Parameter checksum must not be null");
                     
                             // Execute test
                             new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                         }

 @Test
                         public void testConstructorShouldNotThrowWhenBothParametersAreValid1() {
                             // Prepare test data
                             Checksum mockChecksum = mock(Checksum.class);
                             InputStream mockInputStream = mock(InputStream.class);
                     
                             // Execute test - should not throw any exception
                             new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                         }

 @Test
                        public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull3() {
                            // Prepare
                            Checksum mockChecksum = mock(Checksum.class);
                            
                            // Expect
                            thrown.expect(NullPointerException.class);
                            thrown.expectMessage("Parameter in must not be null");
                            
                            // Test
                            new ChecksumCalculatingInputStream(mockChecksum, null);
                        }

 @Test
                      public void testConstructorShouldThrowWhenInputStreamIsNull4() {
                          // Setup
                          Checksum mockChecksum = mock(Checksum.class);
                          
                          // Expect exception
                          thrown.expect(NullPointerException.class);
                          thrown.expectMessage("Parameter in must not be null");
                          
                          // Test - this should throw in original code but pass in mutated code
                          new ChecksumCalculatingInputStream(mockChecksum, null);
                      }

 @Test
                      public void testConstructorShouldNotThrowWhenInputStreamIsNotNull() {
                          // Setup
                          Checksum mockChecksum = mock(Checksum.class);
                          InputStream mockInputStream = mock(InputStream.class);
                          
                          // Test - this should pass in original code but throw in mutated code
                          new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                          
                          // No exception expected - if we reach here, test passes for original code
                          // Mutated code would throw exception here
                      }

 @Test
                      public void testConstructorShouldThrowWhenChecksumIsNull3() {
                          // Setup
                          InputStream mockInputStream = mock(InputStream.class);
                          
                          // Expect exception
                          thrown.expect(NullPointerException.class);
                          thrown.expectMessage("Parameter checksum must not be null");
                          
                          // Test
                          new ChecksumCalculatingInputStream(null, mockInputStream);
                      }

 @Test
                     public void testConstructorShouldNotThrowExceptionWhenInputStreamIsNotNull() {
                         // Prepare non-null mocks for both parameters
                         Checksum mockChecksum = mock(Checksum.class);
                         InputStream mockInputStream = mock(InputStream.class);
                         
                         // Original code should work fine with non-null parameters
                         // Mutated code would throw exception here
                         new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                         
                         // No exception expected - if exception is thrown, test will fail
                     }

 @Test
                     public void testConstructorShouldThrowCorrectExceptionWhenInputStreamIsNull() {
                         Checksum mockChecksum = mock(Checksum.class);
                         
                         // Set up expectation for exception
                         thrown.expect(NullPointerException.class);
                         thrown.expectMessage("Parameter in must not be null");
                         
                         // This should throw in both original and mutated code
                         new ChecksumCalculatingInputStream(mockChecksum, null);
                     }

 @Test
                    public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull4() {
                        // Arrange
                        Checksum mockChecksum = mock(Checksum.class);
                        InputStream nullInputStream = null;
                        
                        // Expect exception
                        thrown.expect(NullPointerException.class);
                        thrown.expectMessage("Parameter in must not be null");
                        
                        // Act
                        new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                    }

 @Test
                    public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull3() {
                        // Arrange
                        Checksum nullChecksum = null;
                        InputStream mockInputStream = mock(InputStream.class);
                        
                        // Expect exception
                        thrown.expect(NullPointerException.class);
                        thrown.expectMessage("Parameter checksum must not be null");
                        
                        // Act
                        new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                    }

 @Test
                    public void testConstructorSucceedsWithValidParameters1() throws Exception {
                        // Arrange
                        Checksum mockChecksum = mock(Checksum.class);
                        InputStream mockInputStream = mock(InputStream.class);
                        
                        // Act (should not throw)
                        new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                        
                        // No assertion needed as we're just verifying no exception is thrown
                    }

 @Test
                   public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull1() {
                       // Arrange
                       Checksum mockChecksum = mock(Checksum.class);
                       InputStream nullInputStream = null;
                       
                       // Set expectation for the exception
                       thrown.expect(NullPointerException.class);
                       thrown.expectMessage("Parameter in must not be null");
                       
                       // Act
                       new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                   }

 @Test
                   public void testConstructorShouldThrowNullPointerExceptionWhenChecksumIsNull1() {
                       // Arrange
                       Checksum nullChecksum = null;
                       InputStream mockInputStream = mock(InputStream.class);
                       
                       // Set expectation for the exception
                       thrown.expect(NullPointerException.class);
                       thrown.expectMessage("Parameter checksum must not be null");
                       
                       // Act
                       new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                   }

 @Test
              public void testConstructorShouldInitializeFieldsWhenParametersAreValid() throws Exception {
                  // Arrange
                  Checksum mockChecksum = mock(Checksum.class);
                  InputStream mockInputStream = mock(InputStream.class);
                  
                  // Act
                  ChecksumCalculatingInputStream stream = 
                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                  
                  // Assert
                  // Use reflection to access private fields
                  Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                  checksumField.setAccessible(true);
                  Field inputStreamField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                  inputStreamField.setAccessible(true);
                  
                  assertSame(mockChecksum, checksumField.get(stream));
                  assertSame(mockInputStream, inputStreamField.get(stream));
              }

 @Test
              public void testConstructorSetsChecksumFieldCorrectly2() throws Exception {
                  // Prepare test data
                  Checksum mockChecksum = mock(Checksum.class);
                  InputStream mockInputStream = mock(InputStream.class);
                  
                  // Create instance - this should store the checksum properly
                  ChecksumCalculatingInputStream stream = 
                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                      
                  // Verify the checksum was stored properly by calling getValue()
                  // which presumably uses the stored checksum
                  stream.getValue();
                  
                  // Verify the checksum was used (would fail if checksum was null)
                  verify(mockChecksum).getValue();
                  
                  // Alternative verification using reflection to check field directly
                  try {
                      java.lang.reflect.Field checksumField = 
                          ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                      checksumField.setAccessible(true);
                      Checksum actualChecksum = (Checksum) checksumField.get(stream);
                      assertSame("Checksum field should contain the provided checksum object",
                                mockChecksum, actualChecksum);
                  } catch (NoSuchFieldException | IllegalAccessException e) {
                      fail("Reflection failed: " + e.getMessage());
                  }
              }

 @Test
             public void testConstructorSetsInputStreamFieldCorrectly2() throws Exception {
                 // Prepare test data
                 Checksum mockChecksum = mock(Checksum.class);
                 InputStream mockInputStream = mock(InputStream.class);
                 
                 // Create instance
                 ChecksumCalculatingInputStream stream = 
                     new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                 
                 // Verify the field was set correctly by testing subsequent behavior
                 // The read() method should delegate to our mock input stream
                 when(mockInputStream.read()).thenReturn(123);
                 
                 int result = stream.read();
                 
                 // If the mutant is present (in=null), this would throw NullPointerException
                 assertEquals(123, result);
                 verify(mockInputStream).read();
             }

 @Test(expected = NullPointerException.class)
             public void testConstructorThrowsWhenChecksumIsNull2() {
                 InputStream mockInputStream = mock(InputStream.class);
                 new ChecksumCalculatingInputStream(null, mockInputStream);
             }

 @Test(expected = NullPointerException.class)
             public void testConstructorThrowsWhenInputStreamIsNull2() {
                 Checksum mockChecksum = mock(Checksum.class);
                 new ChecksumCalculatingInputStream(mockChecksum, null);
             }

 @Test
       public void testConstructorWithNonNullChecksumShouldNotThrowException() throws Exception {
           // Prepare test data - non-null checksum and input stream
           Checksum mockChecksum = mock(Checksum.class);
           InputStream mockInputStream = mock(InputStream.class);
           
           // This should not throw exception in original code, but mutant will throw
           ChecksumCalculatingInputStream stream = 
               new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
           
           // Use reflection to verify private fields were properly set
           Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
           checksumField.setAccessible(true);
           assertSame(mockChecksum, checksumField.get(stream));
           
           Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
           inField.setAccessible(true);
           assertSame(mockInputStream, inField.get(stream));
       }

 @Test
       public void testConstructorWithValidParameters() throws Exception {
           // Prepare test data - non-null parameters
           Checksum mockChecksum = mock(Checksum.class);
           InputStream mockInputStream = mock(InputStream.class);
           
           // Test the constructor - should not throw exception with original code
           // Will throw exception with mutated code
           ChecksumCalculatingInputStream stream = 
               new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
               
           // Verify fields were properly set
           assertSame(mockChecksum, stream.getValue()); // Assuming getValue() returns checksum
           // Additional verification that object was properly constructed
           assertNotNull(stream);
       }

 @Test(expected = NullPointerException.class)
       public void testConstructorWithNullChecksum() {
           InputStream mockInputStream = mock(InputStream.class);
           new ChecksumCalculatingInputStream(null, mockInputStream);
       }

 @Test(expected = NullPointerException.class)
       public void testConstructorWithNullInputStream() {
           Checksum mockChecksum = mock(Checksum.class);
           new ChecksumCalculatingInputStream(mockChecksum, null);
       }

 @Test
      public void testConstructorShouldThrowWhenInputStreamIsNull5() {
          // Prepare
          Checksum mockChecksum = mock(Checksum.class);
          InputStream nullInputStream = null;
          
          // Expect exception
          thrown.expect(NullPointerException.class);
          thrown.expectMessage("Parameter in must not be null");
          
          // Test
          new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
      }

 @Test
     public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull2() {
         // Arrange
         Checksum mockChecksum = mock(Checksum.class);
         
         // Set expectation for exact exception type and message
         thrown.expect(NullPointerException.class);
         thrown.expectMessage("Parameter in must not be null");
         
         // Act - this should throw the exception
         new ChecksumCalculatingInputStream(mockChecksum, null);
     }

}
