package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithNormalEntryNameAndHeaders() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream);
                                                                                                                                                                                                                                    String entryName = "testfile.txt";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    headers.put("path", "test/path");
                                                                                                                                                                                                                                    headers.put("size", "1234");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act - Use reflection to access the private method
                                                                                                                                                                                                                                    Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                        "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                    writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                    writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                                                                                                                                                                                                    tarOutput.close();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert - Verify the output contains the expected PAX headers
                                                                                                                                                                                                                                    byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                                    String outputStr = new String(output, "UTF-8");
                                                                                                                                                                                                                                    assertTrue(outputStr.contains("path=test/path"));
                                                                                                                                                                                                                                    assertTrue(outputStr.contains("size=1234"));
                                                                                                                                                                                                                                    assertTrue(outputStr.startsWith("./PaxHeaders.X/testfile.txt"));
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithEntryNameEndingWithSlash() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream);
                                                                                                                                                                                                                                    String entryName = "directory/";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    headers.put("path", "test/dir");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to access the private method
                                                                                                                                                                                                                                    Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                        "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                    writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                    writePaxHeaders.invoke(tarOutput, entryName, headers);
                                                                                                                                                                                                                                    tarOutput.close();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert - Verify trailing slash was removed
                                                                                                                                                                                                                                    byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                                    String outputStr = new String(output, "UTF-8");
                                                                                                                                                                                                                                    assertTrue(outputStr.startsWith("./PaxHeaders.X/directory"));
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithNonAsciiCharacters() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream);
                                                                                                                                                                                                                                    String entryName = "résumé.txt";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    headers.put("comment", "café");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act - Use reflection to access the private method
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                        writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                        writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to invoke writePaxHeaders via reflection: " + e.getMessage());
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    tarOutput.close();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert - Verify UTF-8 encoding handled correctly
                                                                                                                                                                                                                                    byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                                    String outputStr = new String(output, "UTF-8");
                                                                                                                                                                                                                                    assertTrue(outputStr.contains("comment=café"));
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithEmptyHeaders() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream);
                                                                                                                                                                                                                                    String entryName = "empty.txt";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to access the private writePaxHeaders method
                                                                                                                                                                                                                                    Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                        "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                    writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                    writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                                                                                                                                                                                                    tarOutput.close();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert - Verify empty output (just the header entry)
                                                                                                                                                                                                                                    byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                                    assertTrue(output.length > 0); // Should still create the entry
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithHeaderLengthAdjustment() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream);
                                                                                                                                                                                                                                    String entryName = "adjust.txt";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    // This will force length adjustment from single-digit to double-digit
                                                                                                                                                                                                                                    headers.put("k", "v");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act - Use reflection to access the private method
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                        writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                        writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                                                                                                                                                                                                        tarOutput.close();
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to invoke writePaxHeaders method via reflection: " + e.getMessage());
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert - Verify the length was properly adjusted
                                                                                                                                                                                                                                    byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                                    String outputStr = new String(output, "UTF-8");
                                                                                                                                                                                                                                    assertTrue(outputStr.matches("\\d+ k=v\\n"));
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WhenOutputStreamThrowsIOException() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    OutputStream failingStream = mock(OutputStream.class);
                                                                                                                                                                                                                                    doThrow(new IOException("Write failed")).when(failingStream).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                    TarArchiveOutputStream failingTarOutput = new TarArchiveOutputStream(failingStream);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    String entryName = "fail.txt";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                    headers.put("key", "value");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to access package-private method
                                                                                                                                                                                                                                    Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                        "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                    writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Expected exception
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        writePaxHeaders.invoke(failingTarOutput, entryName, headers);
                                                                                                                                                                                                                                        fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                        Throwable cause = e.getCause();
                                                                                                                                                                                                                                        assertTrue(cause instanceof IOException);
                                                                                                                                                                                                                                        assertEquals("Write failed", cause.getMessage());
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithNullEntryName() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(bos);
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    headers.put("key", "value");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Get the writePaxHeaders method via reflection
                                                                                                                                                                                                                                    Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                        "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                    writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act & Assert
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        writePaxHeadersMethod.invoke(tarOutput, null, headers);
                                                                                                                                                                                                                                        fail("Expected NullPointerException to be thrown");
                                                                                                                                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                        assertTrue(e.getCause() instanceof NullPointerException);
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testWritePaxHeaders_WithVeryLongHeaderValue() throws Exception {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                                    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream);
                                                                                                                                                                                                                                    String entryName = "longvalue.txt";
                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Create a 1000-character string in Java 8 compatible way
                                                                                                                                                                                                                                    char[] chars = new char[1000];
                                                                                                                                                                                                                                    java.util.Arrays.fill(chars, 'x');
                                                                                                                                                                                                                                    String longValue = new String(chars);
                                                                                                                                                                                                                                    headers.put("longkey", longValue);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        // Act - Use reflection to access package-private method
                                                                                                                                                                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                        writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                        writePaxHeaders.invoke(tarOutput, entryName, headers);
                                                                                                                                                                                                                                        tarOutput.close();
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Assert - Verify the long value was properly written
                                                                                                                                                                                                                                        byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                                        String outputStr = new String(output, org.apache.commons.compress.utils.CharsetNames.UTF_8);
                                                                                                                                                                                                                                        assertTrue(outputStr.contains("longkey=" + longValue));
                                                                                                                                                                                                                                    } finally {
                                                                                                                                                                                                                                        tarOutput.close();
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                        public void testWritePaxHeaders_WithNullHeaders() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String entryName = "nullheaders.txt";
                                                                                                                                                                                                                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                                                            TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(bos);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Get the writePaxHeaders method via reflection
                                                                                                                                                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                            writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Act & Assert
                                                                                                                                                                                                                            writePaxHeaders.invoke(tarOutput, entryName, null);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                    public void testWritePaxHeaders_WithVeryLongEntryName() throws Exception {
                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                                        try (TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(outputStream)) {
                                                                                                                                                                                                                            // Use default name length if reflection fails
                                                                                                                                                                                                                            int nameLen = 100; // Default value if we can't get via reflection
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                Class<?> tarConstantsClass = Class.forName("org.apache.commons.compress.archivers.tar.TarConstants");
                                                                                                                                                                                                                                nameLen = tarConstantsClass.getField("NAMELEN").getInt(null);
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                // Use default value
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            String longName = new String(new char[nameLen * 2]).replace('\0', 'a');
                                                                                                                                                                                                                            Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                            headers.put("key", "value");
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Act - Access writePaxHeaders via reflection
                                                                                                                                                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                            writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                            writePaxHeaders.invoke(tarOutput, longName, headers);
                                                                                                                                                                                                                            tarOutput.close();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Assert - Verify the output contains the pax header
                                                                                                                                                                                                                            byte[] output = outputStream.toByteArray();
                                                                                                                                                                                                                            String outputStr = new String(output, "UTF-8");
                                                                                                                                                                                                                            assertTrue(outputStr.contains("key=value"));
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                   public void testWritePaxHeaders_ExactlyMaxLengthNameShouldBeTruncated() throws Exception {
                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                       headers.put("key", "value");
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create a name that's exactly NAMELEN characters long
                                                                                                                                                                                                       int nameLen = org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN;
                                                                                                                                                                                                       int prefixLength = "./PaxHeaders.X/".length();
                                                                                                                                                                                                       StringBuilder sb = new StringBuilder();
                                                                                                                                                                                                       for (int i = 0; i < nameLen - prefixLength; i++) {
                                                                                                                                                                                                           sb.append("a");
                                                                                                                                                                                                       }
                                                                                                                                                                                                       String longName = sb.toString();
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create spy
                                                                                                                                                                                                       TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Instead of mocking the private method, we'll let it execute normally
                                                                                                                                                                                                       // and verify the behavior through the actual method calls
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to call writePaxHeaders
                                                                                                                                                                                                       Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                           "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                       writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                       writePaxHeaders.invoke(spyTarOut, longName, headers);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify the created entry name was truncated (should be NAMELEN-1)
                                                                                                                                                                                                       org.mockito.ArgumentCaptor<org.apache.commons.compress.archivers.tar.TarArchiveEntry> entryCaptor = 
                                                                                                                                                                                                           org.mockito.ArgumentCaptor.forClass(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class);
                                                                                                                                                                                                       verify(spyTarOut).putArchiveEntry(entryCaptor.capture());
                                                                                                                                                                                                       
                                                                                                                                                                                                       String actualName = entryCaptor.getValue().getName();
                                                                                                                                                                                                       assertTrue("Name should be truncated when exactly NAMELEN long",
                                                                                                                                                                                                                  actualName.length() == org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN - 1);
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                               public void testWritePaxHeaders_DetectsLengthCalculationMutant() throws Exception {
                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                   String entryName = "testEntry";
                                                                                                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                   headers.put("key1", "value1"); // Simple ASCII key-value
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create output stream that captures written data
                                                                                                                                                                                                   ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Calculate expected length manually with correct +3
                                                                                                                                                                                                   String expectedLine = "key1=value1\n";
                                                                                                                                                                                                   int expectedLen = "key1".length() + "value1".length() + 3;
                                                                                                                                                                                                   String expectedFullLine = expectedLen + " " + expectedLine;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Call method
                                                                                                                                                                                                   Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                       "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                   writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                   writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                   tarOut.flush();
                                                                                                                                                                                                   String writtenData = baos.toString("UTF-8");
                                                                                                                                                                                                   
                                                                                                                                                                                                   // The mutation would cause the initial length to be 3 less than expected
                                                                                                                                                                                                   // The adjustment loop would eventually fix it, but we can verify the correct format
                                                                                                                                                                                                   assertTrue("Written data should contain properly formatted line",
                                                                                                                                                                                                              writtenData.contains(expectedFullLine));
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Specifically check the length prefix is correct
                                                                                                                                                                                                   String[] lines = writtenData.split("\n");
                                                                                                                                                                                                   for (String line : lines) {
                                                                                                                                                                                                       if (line.contains("key1=value1")) {
                                                                                                                                                                                                           String lengthPart = line.substring(0, line.indexOf(' '));
                                                                                                                                                                                                           assertEquals("Length calculation should account for 3 extra chars",
                                                                                                                                                                                                                        String.valueOf(expectedLen), lengthPart);
                                                                                                                                                                                                       }
                                                                                                                                                                                                   }
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                             public void testWritePaxHeadersDetectsLengthEstimationMutant() throws Exception {
                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                 String entryName = "testEntry";
                                                                                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                 // This header will be sensitive to the length estimation difference
                                                                                                                                                                                                 headers.put("path", "a/path/with/unicode/üñîçødê"); // non-ASCII chars affect UTF-8 length
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create output stream with mock
                                                                                                                                                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Call method
                                                                                                                                                                                                 Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                     "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                 writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                 writePaxHeaders.invoke(tos, entryName, headers);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                 byte[] output = baos.toByteArray();
                                                                                                                                                                                                 String outputStr = new String(output, "UTF-8");
                                                                                                                                                                                                 
                                                                                                                                                                                                 // The key assertion that would fail with the mutant:
                                                                                                                                                                                                 // With +2 estimate, first line would be something like "36 path=a/path/with/unicode/üñîçødê\n"
                                                                                                                                                                                                 // With +10 estimate, the initial length would be wrong and require more loop iterations
                                                                                                                                                                                                 // We check that the length prefix matches actual line length
                                                                                                                                                                                                 String firstLine = outputStr.split("\n")[0];
                                                                                                                                                                                                 int declaredLength = Integer.parseInt(firstLine.split(" ")[0]);
                                                                                                                                                                                                 int actualLength = firstLine.getBytes("UTF-8").length + 1; // +1 for newline
                                                                                                                                                                                                 
                                                                                                                                                                                                 assertEquals("Length prefix should match actual UTF-8 encoded length", 
                                                                                                                                                                                                             declaredLength, actualLength);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Additional verification that the correction loop worked properly
                                                                                                                                                                                                 assertFalse("Output should contain the header", outputStr.isEmpty());
                                                                                                                                                                                                 assertTrue("Output should contain the path", outputStr.contains("path="));
                                                                                                                                                                                                 assertTrue("Output should contain the unicode chars", 
                                                                                                                                                                                                            outputStr.contains("üñîçødê"));
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                         public void testWritePaxHeadersFormatWithSpaceAfterLength() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             String entryName = "testEntry";
                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                             headers.put("key1", "value1");
                                                                                                                                                                                             headers.put("key2", "value2");
                                                                                                                                                                                             
                                                                                                                                                                                             // Mock the output stream to capture written data
                                                                                                                                                                                             ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private method since it's package-private
                                                                                                                                                                                             Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                 "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                             writePaxHeaders.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Execute
                                                                                                                                                                                             writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                             tarOut.close();
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify
                                                                                                                                                                                             String writtenData = baos.toString("UTF-8");
                                                                                                                                                                                             String[] lines = writtenData.split("\n");
                                                                                                                                                                                             
                                                                                                                                                                                             for (String line : lines) {
                                                                                                                                                                                                 if (line.isEmpty()) continue;
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Check format has space after length
                                                                                                                                                                                                 assertTrue("Line should start with length followed by space",
                                                                                                                                                                                                     line.matches("^\\d+\\s.+"));
                                                                                                                                                                                                     
                                                                                                                                                                                                 // Verify the space is present in the actual output
                                                                                                                                                                                                 int firstSpace = line.indexOf(' ');
                                                                                                                                                                                                 assertTrue("Space should exist after length", firstSpace > 0);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Check the key=value part starts after the space
                                                                                                                                                                                                 String rest = line.substring(firstSpace + 1);
                                                                                                                                                                                                 assertTrue("Remaining part should be key=value", 
                                                                                                                                                                                                     rest.matches("^[^=]+=[^=]+$"));
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             // Additional check for byte length calculation
                                                                                                                                                                                             for (Map.Entry<String, String> h : headers.entrySet()) {
                                                                                                                                                                                                 String expectedLineFormat = "%d %s=%s\n";
                                                                                                                                                                                                 String key = h.getKey();
                                                                                                                                                                                                 String value = h.getValue();
                                                                                                                                                                                                 String expectedLine = String.format(expectedLineFormat, 
                                                                                                                                                                                                     expectedLineFormat.length() - 2 + key.length() + value.length(),
                                                                                                                                                                                                     key, value);
                                                                                                                                                                                                 
                                                                                                                                                                                                 assertTrue("Output should contain properly formatted line",
                                                                                                                                                                                                     writtenData.contains(expectedLine));
                                                                                                                                                                                             }
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                        public void testWritePaxHeadersWithNonAsciiCharsDetectsMutant() throws Exception {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            String entryName = "testEntry";
                                                                                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                            // Using a non-ASCII character (Japanese) that takes 3 bytes in UTF-8
                                                                                                                                                                                            headers.put("path", "/path/with/日本語");
                                                                                                                                                                                            
                                                                                                                                                                                            // Mock the output stream to capture what's written
                                                                                                                                                                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                            
                                                                                                                                                                                            // Call method
                                                                                                                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                            writePaxHeaders.setAccessible(true);
                                                                                                                                                                                            writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify
                                                                                                                                                                                            byte[] writtenData = baos.toByteArray();
                                                                                                                                                                                            
                                                                                                                                                                                            // Calculate expected length - the line should be:
                                                                                                                                                                                            // "length path=/path/with/日本語\n"
                                                                                                                                                                                            String expectedLine = "path=/path/with/日本語";
                                                                                                                                                                                            // 3 bytes per Japanese char (3 chars) + ASCII chars (17) = 26 bytes for value part
                                                                                                                                                                                            int expectedValueBytes = 17 + (3 * 3); 
                                                                                                                                                                                            // Total line format: "NN path=/path/with/日本語\n"
                                                                                                                                                                                            int expectedLineLength = expectedValueBytes + 3; // +3 for space, =, and \n
                                                                                                                                                                                            String lengthPrefix = String.valueOf(expectedLineLength);
                                                                                                                                                                                            int totalExpectedBytes = (lengthPrefix + " " + expectedLine + "\n").getBytes(CharsetNames.UTF_8).length;
                                                                                                                                                                                            
                                                                                                                                                                                            // The mutant would calculate length based on character count (20 chars) rather than bytes (26)
                                                                                                                                                                                            // So we verify the actual written bytes match proper UTF-8 length
                                                                                                                                                                                            assertTrue("Written data should contain proper UTF-8 bytes", 
                                                                                                                                                                                                      writtenData.length >= totalExpectedBytes);
                                                                                                                                                                                            
                                                                                                                                                                                            // Additional verification that the length prefix is correct
                                                                                                                                                                                            String writtenString = new String(writtenData, CharsetNames.UTF_8);
                                                                                                                                                                                            String[] lines = writtenString.split("\n");
                                                                                                                                                                                            String firstLine = lines[0];
                                                                                                                                                                                            String[] parts = firstLine.split(" ", 2);
                                                                                                                                                                                            int declaredLength = Integer.parseInt(parts[0]);
                                                                                                                                                                                            assertEquals("Declared length should match actual UTF-8 bytes", 
                                                                                                                                                                                                        firstLine.getBytes(CharsetNames.UTF_8).length, 
                                                                                                                                                                                                        declaredLength);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                      public void testWritePaxHeadersWithOverestimatedLength() throws Exception {
                                                                                                                                                                                          // Setup
                                                                                                                                                                                          String entryName = "testEntry";
                                                                                                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                          // Using a key-value pair where the initial length calculation will be larger than actual UTF-8 bytes
                                                                                                                                                                                          // This happens when the length prefix digits decrease (e.g., from "100" to "99")
                                                                                                                                                                                          headers.put("key", "value");
                                                                                                                                                                                          
                                                                                                                                                                                          // Create a mock output stream to capture the written data
                                                                                                                                                                                          ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                          
                                                                                                                                                                                          // Method to test - should adjust the length down
                                                                                                                                                                                          Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                              "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                          writePaxHeaders.setAccessible(true);
                                                                                                                                                                                          writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify the written data
                                                                                                                                                                                          byte[] writtenData = baos.toByteArray();
                                                                                                                                                                                          String writtenString = new String(writtenData, "UTF-8");
                                                                                                                                                                                          
                                                                                                                                                                                          // The original code would adjust the length down if needed
                                                                                                                                                                                          // The mutant would skip this adjustment when len > actualLength
                                                                                                                                                                                          // Check that the line starts with the correct adjusted length
                                                                                                                                                                                          assertTrue("Should contain properly adjusted length",
                                                                                                                                                                                                     writtenString.startsWith("15 key=value\n") || 
                                                                                                                                                                                                     writtenString.contains("\n15 key=value\n"));
                                                                                                                                                                                          
                                                                                                                                                                                          // Additional verification for the exact case we're testing
                                                                                                                                                                                          // Create a case where initial len > actualLength
                                                                                                                                                                                          headers.clear();
                                                                                                                                                                                          headers.put("k", "v"); // Small key-value pair
                                                                                                                                                                                          baos.reset();
                                                                                                                                                                                          writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                          writtenData = baos.toByteArray();
                                                                                                                                                                                          writtenString = new String(writtenData, "UTF-8");
                                                                                                                                                                                          
                                                                                                                                                                                          // Initial len would be 9 (1+1+3+2+2), actual would be less
                                                                                                                                                                                          // Original would adjust, mutant would not
                                                                                                                                                                                          assertTrue("Should handle overestimated length cases",
                                                                                                                                                                                                     writtenString.startsWith("9 k=v\n") || 
                                                                                                                                                                                                     writtenString.contains("\n9 k=v\n"));
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testWritePaxHeaders_DetectsMissingNewlineMutant() throws Exception {
                                                                                                                                                                                     // Setup
                                                                                                                                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(baos);
                                                                                                                                                                                     
                                                                                                                                                                                     Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                     headers.put("testkey", "testvalue");
                                                                                                                                                                                     headers.put("anotherkey", "anothervalue");
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to access private method
                                                                                                                                                                                     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                     writePaxHeaders.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test
                                                                                                                                                                                     writePaxHeaders.invoke(tarOutput, "testentry", headers);
                                                                                                                                                                                     tarOutput.finish();
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify
                                                                                                                                                                                     byte[] writtenData = baos.toByteArray();
                                                                                                                                                                                     String writtenString = new String(writtenData, "UTF-8");
                                                                                                                                                                                     
                                                                                                                                                                                     // Check that each header line ends with newline
                                                                                                                                                                                     // This will fail if the mutant (missing newline) is present
                                                                                                                                                                                     for (Map.Entry<String, String> entry : headers.entrySet()) {
                                                                                                                                                                                         String expectedLineEnd = entry.getKey() + "=" + entry.getValue() + "\n";
                                                                                                                                                                                         assertTrue("Each header line should end with newline",
                                                                                                                                                                                                   writtenString.contains(expectedLineEnd));
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Additional verification that newlines separate entries
                                                                                                                                                                                     int newlineCount = 0;
                                                                                                                                                                                     for (byte b : writtenData) {
                                                                                                                                                                                         if (b == '\n') {
                                                                                                                                                                                             newlineCount++;
                                                                                                                                                                                         }
                                                                                                                                                                                     }
                                                                                                                                                                                     assertTrue("Should have at least one newline per header entry",
                                                                                                                                                                                               newlineCount >= headers.size());
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                            public void testWritePaxHeadersWithNonAsciiCharactersDetectsEncodingMutation() throws Exception {
                                                                                                                                                                                // Setup
                                                                                                                                                                                String entryName = "testEntry";
                                                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                // Using a non-ASCII character (€ symbol) which takes 3 bytes in UTF-8 but 1 in ISO-8859-1
                                                                                                                                                                                headers.put("testKey", "€100"); 
                                                                                                                                                                                
                                                                                                                                                                                // Create a mock output stream to capture the written data
                                                                                                                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                
                                                                                                                                                                                // Call the method
                                                                                                                                                                                Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                    "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                writePaxHeaders.setAccessible(true);
                                                                                                                                                                                writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                
                                                                                                                                                                                // Verify the written data
                                                                                                                                                                                byte[] writtenData = baos.toByteArray();
                                                                                                                                                                                String writtenString = new String(writtenData, CharsetNames.UTF_8);
                                                                                                                                                                                
                                                                                                                                                                                // The key assertion - check the length prefix accounts for UTF-8 encoding
                                                                                                                                                                                // Original calculation with UTF-8 would be:
                                                                                                                                                                                // "testKey=€100\n" in UTF-8 is 7 (testKey=) + 3 (€) + 3 (100\n) = 13 bytes
                                                                                                                                                                                // Plus the length prefix "13 " (3 bytes) = 16 total
                                                                                                                                                                                // So we expect to see "16 testKey=€100\n" in the output
                                                                                                                                                                                assertTrue("Should contain properly length-prefixed line with UTF-8 encoding",
                                                                                                                                                                                          writtenString.contains("16 testKey=€100\n"));
                                                                                                                                                                                
                                                                                                                                                                                // If the mutant using ISO-8859-1 was present, it would calculate:
                                                                                                                                                                                // "testKey=€100\n" as 7 + 1 + 3 = 11 bytes
                                                                                                                                                                                // Plus length prefix "11 " = 14 total
                                                                                                                                                                                // And would write "14 testKey=€100\n" which would fail our assertion
                                                                                                                                                                            }

    @Test
                                                                                                                                                                        public void testWritePaxHeadersWithNonAsciiCharacters() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            String entryName = "testEntry";
                                                                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                                                                            // Using a non-ASCII character (€ symbol) to force UTF-8 encoding difference
                                                                                                                                                                            headers.put("testKey", "testValue€");
                                                                                                                                                                            
                                                                                                                                                                            // Mock the output stream to capture written bytes
                                                                                                                                                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos, "UTF-8");
                                                                                                                                                                            
                                                                                                                                                                            // Call the method
                                                                                                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                            writePaxHeaders.setAccessible(true);
                                                                                                                                                                            writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                            
                                                                                                                                                                            // Get the written bytes
                                                                                                                                                                            byte[] writtenBytes = baos.toByteArray();
                                                                                                                                                                            
                                                                                                                                                                            // Expected bytes - manually create what UTF-8 encoded version should look like
                                                                                                                                                                            String expectedLine = "21 testKey=testValue€\n";  // 21 is the length in UTF-8
                                                                                                                                                                            byte[] expectedBytes = expectedLine.getBytes(CharsetNames.UTF_8);
                                                                                                                                                                            
                                                                                                                                                                            // Verify the written bytes contain our properly UTF-8 encoded string
                                                                                                                                                                            // Search for our expected bytes in the written output
                                                                                                                                                                            boolean found = false;
                                                                                                                                                                            for (int i = 0; i <= writtenBytes.length - expectedBytes.length; i++) {
                                                                                                                                                                                boolean match = true;
                                                                                                                                                                                for (int j = 0; j < expectedBytes.length; j++) {
                                                                                                                                                                                    if (writtenBytes[i + j] != expectedBytes[j]) {
                                                                                                                                                                                        match = false;
                                                                                                                                                                                        break;
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                                if (match) {
                                                                                                                                                                                    found = true;
                                                                                                                                                                                    break;
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            assertTrue("The output should contain the properly UTF-8 encoded header line", found);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                      public void testWritePaxHeadersWithNonAsciiCharacters1() throws Exception {
                                                                                                                                                                          // Setup
                                                                                                                                                                          ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                          tarOut.setAddPaxHeadersForNonAsciiNames(true);
                                                                                                                                                                          
                                                                                                                                                                          String entryName = "téstFîle"; // Contains non-ASCII characters
                                                                                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                                                                                          headers.put("path", "test/path");
                                                                                                                                                                          headers.put("size", "1234");
                                                                                                                                                                          
                                                                                                                                                                          // Expected behavior: non-ASCII chars should be stripped to 7-bit ASCII
                                                                                                                                                                          String expectedNameStart = "./PaxHeaders.X/testFile"; // Note stripped chars
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to access private method
                                                                                                                                                                          Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                              "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                          writePaxHeaders.setAccessible(true);
                                                                                                                                                                          writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                          
                                                                                                                                                                          tarOut.finish();
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          byte[] output = baos.toByteArray();
                                                                                                                                                                          String outputStr = new String(output, "UTF-8");
                                                                                                                                                                          
                                                                                                                                                                          // Check that the entry name contains only ASCII characters
                                                                                                                                                                          assertTrue("Entry name should only contain ASCII characters",
                                                                                                                                                                              outputStr.contains(expectedNameStart));
                                                                                                                                                                          
                                                                                                                                                                          // Verify no raw non-ASCII characters appear in the output
                                                                                                                                                                          for (byte b : output) {
                                                                                                                                                                              assertTrue("All bytes should be 7-bit ASCII", (b & 0x80) == 0);
                                                                                                                                                                          }
                                                                                                                                                                          
                                                                                                                                                                          // Verify headers were written correctly
                                                                                                                                                                          assertTrue(outputStr.contains("path=test/path"));
                                                                                                                                                                          assertTrue(outputStr.contains("size=1234"));
                                                                                                                                                                      }

    @Test
                                                                                                                                                             public void testWritePaxHeadersWithExactMaxLengthName() throws Exception {
                                                                                                                                                                 // Setup
                                                                                                                                                                 int prefixLength = "./PaxHeaders.X/".length();
                                                                                                                                                                 StringBuilder sb = new StringBuilder();
                                                                                                                                                                 for (int i = 0; i < org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN - prefixLength; i++) {
                                                                                                                                                                     sb.append("a");
                                                                                                                                                                 }
                                                                                                                                                                 String entryName = sb.toString();
                                                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                                                 headers.put("key", "value");
                                                                                                                                                                 
                                                                                                                                                                 // Mock dependencies
                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                                 
                                                                                                                                                                 // Spy on the tarOut to verify the entry creation
                                                                                                                                                                 TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to access private method
                                                                                                                                                                 Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                     "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                 writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                 
                                                                                                                                                                 // Test
                                                                                                                                                                 writePaxHeadersMethod.invoke(spyTarOut, entryName, headers);
                                                                                                                                                                 
                                                                                                                                                                 // Verify the entry name was properly truncated (should be NAMELEN-1)
                                                                                                                                                                 org.mockito.ArgumentCaptor<org.apache.commons.compress.archivers.tar.TarArchiveEntry> entryCaptor = 
                                                                                                                                                                     org.mockito.ArgumentCaptor.forClass(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class);
                                                                                                                                                                 verify(spyTarOut).putArchiveEntry(entryCaptor.capture());
                                                                                                                                                                 
                                                                                                                                                                 String actualName = entryCaptor.getValue().getName();
                                                                                                                                                                 assertTrue("Name should be truncated when length equals NAMELEN",
                                                                                                                                                                            actualName.length() < org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN);
                                                                                                                                                                 assertEquals("Name should be exactly NAMELEN-1 characters long",
                                                                                                                                                                             org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN - 1, actualName.length());
                                                                                                                                                                 
                                                                                                                                                                 // Verify the rest of the flow
                                                                                                                                                                 verify(spyTarOut).write(any(byte[].class));
                                                                                                                                                                 verify(spyTarOut).closeArchiveEntry();
                                                                                                                                                             }

    @Test
                                                                                                                                                        public void testWritePaxHeadersDetectsLengthCalculationMutant() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String entryName = "testEntry";
                                                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                                                            headers.put("key1", "shortValue");  // key shorter than value
                                                                                                                                                            headers.put("longKey", "val");      // key longer than value
                                                                                                                                                            headers.put("equal", "equal");      // key and value same length
                                                                                                                                                            
                                                                                                                                                            // Mock the output stream to capture written data
                                                                                                                                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                            
                                                                                                                                                            // Call method
                                                                                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                                                                                            writePaxHeaders.setAccessible(true);
                                                                                                                                                            writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            byte[] writtenData = baos.toByteArray();
                                                                                                                                                            String writtenString = new String(writtenData, java.nio.charset.Charset.forName("UTF-8"));
                                                                                                                                                            
                                                                                                                                                            // Check each header line has correct format and length prefix
                                                                                                                                                            String[] lines = writtenString.split("\\n");
                                                                                                                                                            for (String line : lines) {
                                                                                                                                                                if (line.isEmpty()) continue;
                                                                                                                                                                
                                                                                                                                                                // Split into length and content
                                                                                                                                                                int spacePos = line.indexOf(' ');
                                                                                                                                                                String lengthStr = line.substring(0, spacePos);
                                                                                                                                                                String content = line.substring(spacePos + 1);
                                                                                                                                                                
                                                                                                                                                                // Verify length matches actual UTF-8 bytes
                                                                                                                                                                int declaredLength = Integer.parseInt(lengthStr);
                                                                                                                                                                int actualLength = (content + "\n").getBytes(java.nio.charset.Charset.forName("UTF-8")).length;
                                                                                                                                                                assertEquals("Length prefix should match actual line length", 
                                                                                                                                                                    declaredLength, actualLength);
                                                                                                                                                                
                                                                                                                                                                // Verify line format: key=value
                                                                                                                                                                assertTrue("Line should contain key=value format", 
                                                                                                                                                                    content.matches(".+=.+"));
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Specifically check the mutant would fail:
                                                                                                                                                            // For key1=shortValue, original would calculate len=5+10=15
                                                                                                                                                            // Mutant would calculate len=5-10=-5 (which would fail)
                                                                                                                                                            boolean foundShortValue = false;
                                                                                                                                                            for (String line : lines) {
                                                                                                                                                                if (line.contains("key1=shortValue")) {
                                                                                                                                                                    foundShortValue = true;
                                                                                                                                                                    assertTrue("Line length should be positive", 
                                                                                                                                                                        Integer.parseInt(line.substring(0, line.indexOf(' '))) > 0);
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                            assertTrue("Should contain key1=shortValue", foundShortValue);
                                                                                                                                                        }

    @Test
                                                                                                                       public void testWritePaxHeadersDetectsLengthCalculationMutant1() throws Exception {
                                                                                                                           // Setup
                                                                                                                           ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                           Map<String, String> headers = new HashMap<>();
                                                                                                                           
                                                                                                                           // Add a header where the +3 vs +0 makes a difference in initial calculation
                                                                                                                           // Key and value are chosen so that key.length() + value.length() + 2 = 9
                                                                                                                           // With +3 it becomes 12, with +0 it becomes 9
                                                                                                                           // UTF-8 encoding will make the actual length different
                                                                                                                           headers.put("k", "val"); // k=val -> "k=val" is 5 chars + formatting
                                                                                                                           
                                                                                                                           // Mock the actual tar writing since we're testing the length calculation
                                                                                                                           TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                           doNothing().when(spyTarOut).putArchiveEntry(
                                                                                                                               any(org.apache.commons.compress.archivers.ArchiveEntry.class));
                                                                                                                           doNothing().when(spyTarOut).write(
                                                                                                                               any(byte[].class));
                                                                                                                           doNothing().when(spyTarOut).closeArchiveEntry();
                                                                                                                           
                                                                                                                           // Use reflection to access the private method
                                                                                                                           java.lang.reflect.Method writePaxHeadersMethod = TarArchiveOutputStream.class
                                                                                                                                   .getDeclaredMethod("writePaxHeaders", String.class, Map.class);
                                                                                                                           writePaxHeadersMethod.setAccessible(true);
                                                                                                                           writePaxHeadersMethod.invoke(spyTarOut, "testEntry", headers);
                                                                                                                           
                                                                                                                           // Verify the length calculation was correct by checking write() was called with properly formatted data
                                                                                                                           org.mockito.ArgumentCaptor<byte[]> dataCaptor = org.mockito.ArgumentCaptor.forClass(byte[].class);
                                                                                                                           verify(spyTarOut).write(dataCaptor.capture());
                                                                                                                           
                                                                                                                           String writtenData = new String(dataCaptor.getValue(), java.nio.charset.StandardCharsets.UTF_8);
                                                                                                                           assertTrue("Written data should contain properly formatted header", 
                                                                                                                                      writtenData.matches("\\d+ k=val\\n"));
                                                                                                                           
                                                                                                                           // Specifically check the length prefix is correct
                                                                                                                           String expectedLine = "k=val\n";
                                                                                                                           int expectedLength = expectedLine.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                                                                                                                           assertTrue("Length prefix should account for all characters",
                                                                                                                                      writtenData.startsWith(expectedLength + " "));
                                                                                                                           
                                                                                                                           // Cleanup
                                                                                                                           spyTarOut.close();
                                                                                                                       }

    @Test
                                                                                                              public void testWritePaxHeadersDetectsLengthCalculationMutant2() throws Exception {
                                                                                                                  // Setup
                                                                                                                  ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                  
                                                                                                                  // Create test headers with varying lengths and UTF-8 chars
                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                  headers.put("key1", "value1");  // ASCII, short
                                                                                                                  headers.put("path", "/ümlaut/"); // UTF-8 (2 bytes per special char)
                                                                                                                  headers.put("longkey", new String(new char[50]).replace("\0", "a")); // Long ASCII
                                                                                                                  
                                                                                                                  // Mock the actual write operations to capture output
                                                                                                                  ByteArrayOutputStream captureStream = new ByteArrayOutputStream();
                                                                                                                  TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                  doAnswer(invocation -> {
                                                                                                                      byte[] data = (byte[]) invocation.getArguments()[0];
                                                                                                                      captureStream.write(data);
                                                                                                                      return null;
                                                                                                                  }).when(spyTarOut).write(any(byte[].class));
                                                                                                                  
                                                                                                                  // Execute
                                                                                                                  Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                      "writePaxHeaders", String.class, Map.class);
                                                                                                                  writePaxHeaders.setAccessible(true);
                                                                                                                  writePaxHeaders.invoke(spyTarOut, "testEntry", headers);
                                                                                                                  
                                                                                                                  // Verify
                                                                                                                  byte[] writtenData = captureStream.toByteArray();
                                                                                                                  String writtenString = new String(writtenData, java.nio.charset.StandardCharsets.UTF_8);
                                                                                                                  
                                                                                                                  // Check that length calculations are correct by examining the written lines
                                                                                                                  // The mutant would produce incorrect initial length prefixes
                                                                                                                  String[] lines = writtenString.split("\\n");
                                                                                                                  for (String line : lines) {
                                                                                                                      if (!line.isEmpty()) {
                                                                                                                          // Extract the length prefix (digits before space)
                                                                                                                          String lengthStr = line.substring(0, line.indexOf(" "));
                                                                                                                          int declaredLength = Integer.parseInt(lengthStr);
                                                                                                                          
                                                                                                                          // Calculate actual byte length (line + newline)
                                                                                                                          byte[] lineBytes = (line + "\n").getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                                                                                                          
                                                                                                                          // Verify declared length matches actual bytes
                                                                                                                          // This would fail with the mutant since initial length calculation is wrong
                                                                                                                          assertEquals("Length prefix doesn't match actual bytes", 
                                                                                                                                      lineBytes.length, declaredLength);
                                                                                                                      }
                                                                                                                  }
                                                                                                                  
                                                                                                                  // Additional check for specific line with UTF-8 chars
                                                                                                                  String utf8Line = java.util.Arrays.stream(lines)
                                                                                                                                            .filter(l -> l.contains("ümlaut"))
                                                                                                                                            .findFirst()
                                                                                                                                            .orElse("");
                                                                                                                  assertFalse("UTF-8 test line not found", utf8Line.isEmpty());
                                                                                                                  int utf8DeclaredLength = Integer.parseInt(utf8Line.substring(0, utf8Line.indexOf(" ")));
                                                                                                                  byte[] utf8LineBytes = (utf8Line + "\n").getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                                                                                                  assertEquals("UTF-8 line length incorrect", 
                                                                                                                              utf8LineBytes.length, utf8DeclaredLength);
                                                                                                              }

    @Test
                                                                                                         public void testWritePaxHeadersFormatWithSpaceAfterLength1() throws Exception {
                                                                                                             // Setup
                                                                                                             String entryName = "testEntry";
                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                             headers.put("key1", "value1"); // Simple ASCII case
                                                                                                             headers.put("path", "/ümlaut/path"); // UTF-8 case
                                                                                                             
                                                                                                             // Mock the output stream to capture written data
                                                                                                             ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                             
                                                                                                             // Call method
                                                                                                             Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                 "writePaxHeaders", String.class, Map.class);
                                                                                                             writePaxHeaders.setAccessible(true);
                                                                                                             writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                             
                                                                                                             // Verify
                                                                                                             byte[] writtenData = baos.toByteArray();
                                                                                                             String writtenString = new String(writtenData, "UTF-8");
                                                                                                             
                                                                                                             // Check that each line has the proper format with space after length
                                                                                                             String[] lines = writtenString.split("\\n");
                                                                                                             for (String line : lines) {
                                                                                                                 if (!line.isEmpty()) {
                                                                                                                     // Split into length and rest
                                                                                                                     int spacePos = line.indexOf(' ');
                                                                                                                     assertTrue("Line should contain space after length", spacePos > 0);
                                                                                                                     
                                                                                                                     // Verify length matches actual line length
                                                                                                                     String lengthStr = line.substring(0, spacePos);
                                                                                                                     try {
                                                                                                                         int declaredLength = Integer.parseInt(lengthStr);
                                                                                                                         // +1 for the newline that was removed by split()
                                                                                                                         assertEquals("Declared length should match actual length", 
                                                                                                                             line.length() + 1, declaredLength);
                                                                                                                     } catch (NumberFormatException e) {
                                                                                                                         fail("First part of line should be a number");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Verify the rest of the format
                                                                                                                     String rest = line.substring(spacePos + 1);
                                                                                                                     assertTrue("Line should contain key=value", rest.contains("="));
                                                                                                                 }
                                                                                                             }
                                                                                                             
                                                                                                             // Specifically check that the space is present in the format
                                                                                                             assertTrue("Output should contain lines with space after length", 
                                                                                                                 writtenString.contains(" key1=value1\n") || 
                                                                                                                 writtenString.contains(" path=/ümlaut/path\n"));
                                                                                                         }

    @Test
                                                                                                    public void testWritePaxHeadersWithNonAsciiCharsDetectsByteLengthMutant() throws Exception {
                                                                                                        // Setup
                                                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                        
                                                                                                        // Create headers with non-ASCII characters (UTF-8 will use 2 bytes per char)
                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                        headers.put("test", "üöä"); // German umlauts (each is 2 bytes in UTF-8)
                                                                                                        
                                                                                                        // Expected line format: "length key=value\n"
                                                                                                        // Original would calculate byte length correctly (accounting for 2-byte chars)
                                                                                                        // Mutant would use String.length() which undercounts for non-ASCII
                                                                                                        
                                                                                                        // Act
                                                                                                        // Using reflection to access private method since it's not public
                                                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                            "writePaxHeaders", String.class, Map.class);
                                                                                                        writePaxHeaders.setAccessible(true);
                                                                                                        writePaxHeaders.invoke(tarOut, "testEntry", headers);
                                                                                                        
                                                                                                        // Assert
                                                                                                        byte[] writtenData = baos.toByteArray();
                                                                                                        String writtenString = new String(writtenData, "UTF-8");
                                                                                                        
                                                                                                        // Verify the length prefix matches actual byte length
                                                                                                        // The line should be in format: "length key=value\n"
                                                                                                        String[] lines = writtenString.split("\n");
                                                                                                        for (String line : lines) {
                                                                                                            if (line.isEmpty()) continue;
                                                                                                            
                                                                                                            // Get the length prefix (number before first space)
                                                                                                            int spacePos = line.indexOf(' ');
                                                                                                            String lengthStr = line.substring(0, spacePos);
                                                                                                            int declaredLength = Integer.parseInt(lengthStr);
                                                                                                            
                                                                                                            // Get the actual content (including newline)
                                                                                                            String content = line.substring(spacePos) + "\n";
                                                                                                            int actualByteLength = content.getBytes("UTF-8").length;
                                                                                                            
                                                                                                            // This assertion will fail with the mutant
                                                                                                            assertEquals("Length prefix should match actual byte length", 
                                                                                                                actualByteLength, declaredLength);
                                                                                                        }
                                                                                                        
                                                                                                        // Clean up
                                                                                                        writePaxHeaders.setAccessible(false);
                                                                                                    }

    @Test
                                                                                               public void testWritePaxHeadersWithOverestimatedLength1() throws Exception {
                                                                                                   // Setup
                                                                                                   String entryName = "testEntry";
                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                   // Using a character that takes fewer bytes in UTF-8 than its length would suggest
                                                                                                   headers.put("key", "~"); // '~' is 1 byte in UTF-8
                                                                                                   
                                                                                                   // Create a mock output stream to capture the written data
                                                                                                   ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                   
                                                                                                   // Use reflection to access the private method
                                                                                                   Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                       "writePaxHeaders", String.class, Map.class);
                                                                                                   writePaxHeadersMethod.setAccessible(true);
                                                                                                   writePaxHeadersMethod.invoke(tarOut, entryName, headers);
                                                                                                   tarOut.close();
                                                                                                   
                                                                                                   // Verify
                                                                                                   byte[] writtenData = baos.toByteArray();
                                                                                                   String writtenString = new String(writtenData, "UTF-8");
                                                                                                   
                                                                                                   // The original code would adjust the length from initial overestimation (3 + 3 + 3 + 2 = 11)
                                                                                                   // to actual length (1 + 1 + 3 + 2 = 7)
                                                                                                   // The mutant would keep the overestimated length
                                                                                                   assertFalse("Should not contain overestimated length", 
                                                                                                              writtenString.contains("11 key=~"));
                                                                                                   assertTrue("Should contain corrected length", 
                                                                                                             writtenString.contains("7 key=~"));
                                                                                                   
                                                                                                   // Additional verification for the entry name handling
                                                                                                   assertTrue(writtenString.contains("key=~"));
                                                                                               }

    @Test
                                                                                      public void testWritePaxHeaders_DetectsMissingNewlineMutant1() throws Exception {
                                                                                          // Setup
                                                                                          String entryName = "testEntry";
                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                          headers.put("key1", "value1");
                                                                                          headers.put("key2", "value2");
                                                                                          
                                                                                          // Create a mock output stream to capture the written data
                                                                                          ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                          
                                                                                          // Method under test
                                                                                          Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                              "writePaxHeaders", String.class, Map.class);
                                                                                          writePaxHeaders.setAccessible(true);
                                                                                          writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                          
                                                                                          // Get the written data
                                                                                          byte[] writtenData = baos.toByteArray();
                                                                                          String writtenString = new String(writtenData, "UTF-8");
                                                                                          
                                                                                          // Verify each header line ends with newline
                                                                                          String[] lines = writtenString.split("\\n");
                                                                                          for (String line : lines) {
                                                                                              if (line.isEmpty()) continue; // Skip empty lines
                                                                                              // Check that the line starts with length followed by space
                                                                                              String[] parts = line.split(" ", 2);
                                                                                              assertTrue("Line should start with length", parts.length > 0);
                                                                                              try {
                                                                                                  int declaredLength = Integer.parseInt(parts[0]);
                                                                                                  // Verify the declared length matches actual bytes including newline
                                                                                                  int actualLength = (line + "\n").getBytes("UTF-8").length;
                                                                                                  assertEquals("Declared length should match actual bytes including newline", 
                                                                                                              declaredLength, actualLength);
                                                                                              } catch (NumberFormatException e) {
                                                                                                  fail("First part of line should be length number");
                                                                                              }
                                                                                          }
                                                                                          
                                                                                          // Verify the total structure
                                                                                          assertTrue("Output should contain newlines between entries", 
                                                                                                    writtenString.contains("\n"));
                                                                                          
                                                                                          // Verify the exact byte count would catch the mutant
                                                                                          // For key1=value1, original would be "21 key1=value1\n" (21 bytes)
                                                                                          // Mutant would be "20 key1=value1" (20 bytes)
                                                                                          boolean foundCorrectFormat = false;
                                                                                          for (String line : lines) {
                                                                                              if (line.startsWith("21 ") && line.endsWith("key1=value1")) {
                                                                                                  foundCorrectFormat = true;
                                                                                                  break;
                                                                                              }
                                                                                          }
                                                                                          assertTrue("Should find properly formatted line with correct length", foundCorrectFormat);
                                                                                      }

    @Test
                                                                                 public void testWritePaxHeadersWithNonAsciiCharacters2() throws Exception {
                                                                                     // Setup
                                                                                     String entryName = "testEntry";
                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                     // Using a string with non-ASCII characters (UTF-8 will use 2 bytes per character)
                                                                                     String nonAsciiValue = "ümlaut";  // 'ü' is 2 bytes in UTF-8
                                                                                     headers.put("testKey", nonAsciiValue);
                                                                                     
                                                                                     // Create a mock output stream to capture the written data
                                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                     
                                                                                     // Calculate expected length manually (UTF-8 encoding)
                                                                                     String expectedLine = "testKey=" + nonAsciiValue + "\n";
                                                                                     int expectedLen = expectedLine.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                                                                                     String expectedFullLine = expectedLen + " " + expectedLine;
                                                                                     
                                                                                     // Act - call the method through reflection since it's package-private
                                                                                     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                     writePaxHeaders.setAccessible(true);
                                                                                     writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                     
                                                                                     // Assert
                                                                                     byte[] writtenData = baos.toByteArray();
                                                                                     String writtenString = new String(writtenData, java.nio.charset.StandardCharsets.UTF_8);
                                                                                     
                                                                                     // Verify the line contains the correct length prefix
                                                                                     // The mutant would calculate length incorrectly with ISO-8859-1
                                                                                     assertTrue("Written data should contain correct length prefix",
                                                                                                writtenString.contains(expectedLen + " testKey=" + nonAsciiValue));
                                                                                     
                                                                                     // Verify the actual byte length matches UTF-8 expectations
                                                                                     // This is where the mutant would fail - ISO-8859-1 would produce different byte count
                                                                                     assertEquals("Byte length should match UTF-8 encoding",
                                                                                                 expectedFullLine.getBytes(java.nio.charset.StandardCharsets.UTF_8).length,
                                                                                                 writtenString.getBytes(java.nio.charset.StandardCharsets.UTF_8).length);
                                                                                     
                                                                                     // Clean up
                                                                                     writePaxHeaders.setAccessible(false);
                                                                                 }

    @Test
                                                                            public void testWritePaxHeadersWithNonAsciiCharacters3() throws Exception {
                                                                                // Setup
                                                                                String entryName = "testEntry";
                                                                                Map<String, String> headers = new HashMap<>();
                                                                                // Using a non-ASCII character (€ symbol) which has different UTF-8 encoding
                                                                                headers.put("currency", "€");
                                                                                
                                                                                // Mock the output stream to capture written bytes
                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos, "UTF-8");
                                                                                
                                                                                // Expected UTF-8 encoded bytes for "3 currency=€\n"
                                                                                // € in UTF-8 is 0xE2 0x82 0xAC
                                                                                byte[] expectedBytes = "14 currency=€\n".getBytes(CharsetNames.UTF_8);
                                                                                
                                                                                // Execute
                                                                                // Using reflection to access private method since it's not public
                                                                                Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writePaxHeaders", String.class, Map.class);
                                                                                writePaxHeaders.setAccessible(true);
                                                                                writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                
                                                                                // Verify
                                                                                byte[] actualBytes = baos.toByteArray();
                                                                                // We need to skip the tar header part (512 bytes) to get to our data
                                                                                byte[] writtenData = java.util.Arrays.copyOfRange(actualBytes, 512, 512 + expectedBytes.length);
                                                                                
                                                                                // This will fail if getBytes() without UTF-8 is used, as the platform default encoding
                                                                                // might handle the € symbol differently
                                                                                assertArrayEquals("Bytes should be UTF-8 encoded", expectedBytes, writtenData);
                                                                                
                                                                                // Clean up
                                                                                writePaxHeaders.setAccessible(false);
                                                                            }

    @Test
                                                                   public void testWritePaxHeadersWithNonAsciiCharacters4() throws Exception {
                                                                       // Setup
                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                       Map<String, String> headers = new HashMap<>();
                                                                       headers.put("testkey", "testvalue");
                                                                       
                                                                       // Test with entry name containing non-ASCII characters
                                                                       String entryName = "testéñtry";
                                                                       
                                                                       // Use reflection to access the private writePaxHeaders method
                                                                       Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                           "writePaxHeaders", String.class, Map.class);
                                                                       writePaxHeadersMethod.setAccessible(true);
                                                                       
                                                                       // Execute
                                                                       writePaxHeadersMethod.invoke(tarOut, entryName, headers);
                                                                       tarOut.close();
                                                                       
                                                                       // Verify
                                                                       byte[] output = baos.toByteArray();
                                                                       String outputStr = new String(output, java.nio.charset.StandardCharsets.UTF_8);
                                                                       
                                                                       // The test verifies non-ASCII chars are preserved in the header name
                                                                       assertTrue(outputStr.contains("testéñtry"));
                                                                       
                                                                       // Verify the header was properly written
                                                                       assertTrue(outputStr.contains("testkey=testvalue"));
                                                                       
                                                                       // Verify the length adjustment worked
                                                                       assertTrue(outputStr.matches("\\d+ testkey=testvalue\\n"));
                                                                   }

    @Test
                                                              public void testWritePaxHeadersWithExactNameLength() throws Exception {
                                                                  // Setup
                                                                  int NAMELEN = 100; // Assuming TarConstants.NAMELEN is 100
                                                                  int prefixLength = "./PaxHeaders.X/".length();
                                                                  StringBuilder sb = new StringBuilder();
                                                                  for (int i = 0; i < NAMELEN - prefixLength; i++) {
                                                                      sb.append("a");
                                                                  }
                                                                  String exactLengthName = sb.toString();
                                                                  Map<String, String> headers = new HashMap<>();
                                                                  headers.put("key", "value");
                                                                  
                                                                  // Mock dependencies
                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new ByteArrayOutputStream());
                                                                  
                                                                  // Use reflection to access private method
                                                                  Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                      "writePaxHeaders", String.class, Map.class);
                                                                  writePaxHeaders.setAccessible(true);
                                                                  
                                                                  // Test
                                                                  writePaxHeaders.invoke(tarOut, exactLengthName, headers);
                                                                  
                                                                  // Verify the name was truncated (original behavior)
                                                                  // In original: name length should be NAMELEN-1 (99)
                                                                  // In mutant: name length would be NAMELEN (100)
                                                                  // We can verify through the created entry's name length
                                                                  
                                                                  // Since we can't directly access the created entry, we need to verify the behavior
                                                                  // through side effects or mock verification. For this test, we'll assume
                                                                  // the entry creation would fail if name is too long.
                                                                  
                                                                  // Alternative approach: test with reflection to verify internal state
                                                                  Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                  currNameField.setAccessible(true);
                                                                  String createdName = (String) currNameField.get(tarOut);
                                                                  
                                                                  // Assert the name was properly truncated
                                                                  assertTrue("Name should be truncated when length equals NAMELEN",
                                                                             createdName.length() < NAMELEN);
                                                              }

    @Test
                                                 public void testWritePaxHeaders_ShouldUseLowerCaseHeaderType() throws Exception {
                                                     // Arrange
                                                     String entryName = "testEntry";
                                                     Map<String, String> headers = new HashMap<String, String>();
                                                     headers.put("key1", "value1");
                                                     headers.put("key2", "value2");
                                                     
                                                     // Mock dependencies
                                                     OutputStream mockOutputStream = mock(OutputStream.class);
                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                     
                                                     // Use reflection to access private method for verification
                                                     Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                         "writePaxHeaders", String.class, Map.class);
                                                     writePaxHeadersMethod.setAccessible(true);
                                                     
                                                     // Act
                                                     writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                     
                                                     // Assert - verify the created entry has lowercase type
                                                     org.mockito.ArgumentCaptor<ArchiveEntry> entryCaptor = org.mockito.ArgumentCaptor.forClass(ArchiveEntry.class);
                                                     verify(tarOutput).putArchiveEntry(entryCaptor.capture());
                                                     
                                                     TarArchiveEntry createdEntry = (TarArchiveEntry) entryCaptor.getValue();
                                                     assertEquals("Header type should be lowercase", 
                                                                'x',  // LF_PAX_EXTENDED_HEADER_LC is typically 'x' for lowercase
                                                                createdEntry.getLinkName().charAt(0));
                                                     
                                                     // Verify other expected behaviors
                                                     assertTrue("Entry name should start with PaxHeaders prefix",
                                                               createdEntry.getName().startsWith("./PaxHeaders.X/"));
                                                     assertFalse("Entry name should not end with slash",
                                                                createdEntry.getName().endsWith("/"));
                                                 }

    @Test
                                            public void testWritePaxHeadersDetectsLengthCalculationMutant3() throws Exception {
                                                // Setup
                                                String entryName = "testEntry";
                                                Map<String, String> headers = new HashMap<>();
                                                headers.put("key1", "value1"); // key and value same length (5)
                                                headers.put("longkey", "val");  // key longer than value (7 vs 3)
                                                headers.put("k", "longvalue");  // value longer than key (1 vs 8)
                                                
                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                
                                                // Use reflection to access private method
                                                Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                    "writePaxHeaders", String.class, Map.class);
                                                writePaxHeaders.setAccessible(true);
                                                
                                                // Method under test
                                                writePaxHeaders.invoke(tarOut, entryName, headers);
                                                tarOut.flush();
                                                
                                                // Verify
                                                byte[] output = baos.toByteArray();
                                                String outputStr = new String(output, "UTF-8");
                                                
                                                // Check that length prefixes are correct (original + vs mutant -)
                                                // For "key1=value1\n" - should be length 11 (5+5+1 for '=')
                                                assertTrue(outputStr.contains("11 key1=value1\n"));
                                                
                                                // For "longkey=val\n" - should be length 10 (7+3+0 for '=')
                                                assertTrue(outputStr.contains("10 longkey=val\n"));
                                                
                                                // For "k=longvalue\n" - should be length 10 (1+8+1 for '=')
                                                assertTrue(outputStr.contains("10 k=longvalue\n"));
                                                
                                                // Verify no negative lengths appear in output
                                                assertFalse(outputStr.contains("-"));
                                            }

    @Test
                                       public void testWritePaxHeadersDetectsLengthCalculationMutant4() throws Exception {
                                           // Setup
                                           String entryName = "testEntry";
                                           Map<String, String> headers = new HashMap<>();
                                           headers.put("key1", "value1");  // Simple ASCII case
                                           headers.put("key2", "välüé2");  // Non-ASCII case to test UTF-8
                                           
                                           // Create output stream that captures the written data
                                           ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                           
                                           // Call method
                                           Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                               "writePaxHeaders", String.class, Map.class);
                                           writePaxHeaders.setAccessible(true);
                                           writePaxHeaders.invoke(tarOut, entryName, headers);
                                           
                                           // Verify
                                           byte[] output = baos.toByteArray();
                                           
                                           // Calculate expected length manually with correct +3 calculation
                                           int expectedLength = 0;
                                           for (Map.Entry<String, String> h : headers.entrySet()) {
                                               String key = h.getKey();
                                               String value = h.getValue();
                                               String line = (key.length() + value.length() + 3 + 2) + " " + key + "=" + value + "\n";
                                               expectedLength += line.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                                           }
                                           
                                           // The mutant would produce a different length due to +0 instead of +3
                                           assertEquals("Output length should match correct calculation", 
                                                       expectedLength, output.length);
                                           
                                           // Additional verification that the output contains the expected headers
                                           String outputStr = new String(output, "UTF-8");
                                           assertTrue("Output should contain first header", outputStr.contains("key1=value1"));
                                           assertTrue("Output should contain second header", outputStr.contains("key2=välüé2"));
                                       }

    @Test
                                  public void testWritePaxHeadersDetectsLengthEstimationMutant1() throws Exception {
                                      // Setup
                                      String entryName = "testEntry";
                                      Map<String, String> headers = new HashMap<>();
                                      // This header is designed so the +2 vs +10 difference will affect the length calculation
                                      headers.put("key", "value");
                                      
                                      // Create a mock output stream to capture the written data
                                      ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                      
                                      // Call the method
                                      Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                          "writePaxHeaders", String.class, Map.class);
                                      writePaxHeaders.setAccessible(true);
                                      writePaxHeaders.invoke(tarOut, entryName, headers);
                                      
                                      // Get the written data
                                      byte[] writtenData = baos.toByteArray();
                                      String writtenString = new String(writtenData, "UTF-8");
                                      
                                      // Verify the header line format
                                      // Original would produce: "18 key=value\n" (3+3+3+3+2=14 + 3 spaces/equals/newline + 2 buffer = 19, but UTF-8 makes it 18)
                                      // Mutant would produce wrong length due to +10 instead of +2
                                      assertTrue("Written data should contain properly formatted header line",
                                                 writtenString.matches("\\d+ key=value\\n"));
                                      
                                      // Specifically check the length prefix is correct (18 for this case)
                                      String expectedLine = "18 key=value\n";
                                      assertTrue("Header line length should be correctly calculated",
                                                 writtenString.contains(expectedLine));
                                      
                                      // Verify the exact output matches expected
                                      assertEquals("Full output should match expected format",
                                                   expectedLine, writtenString);
                                  }

    @Test
                             public void testWritePaxHeadersFormatWithSpace() throws Exception {
                                 // Setup
                                 String entryName = "testEntry";
                                 Map<String, String> headers = new HashMap<>();
                                 headers.put("key1", "value1"); // Simple ASCII case
                                 headers.put("ümlaut", "valüe"); // UTF-8 case
                                 
                                 // Mock output stream to capture written data
                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                 TarArchiveOutputStream tos = new TarArchiveOutputStream(baos);
                                 
                                 // Use reflection to access private method since it's package-private
                                 Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                     "writePaxHeaders", String.class, Map.class);
                                 writePaxHeaders.setAccessible(true);
                                 
                                 // Execute
                                 writePaxHeaders.invoke(tos, entryName, headers);
                                 
                                 // Verify
                                 byte[] written = baos.toByteArray();
                                 String writtenStr = new String(written, "UTF-8");
                                 
                                 // Check that each line has the correct format with space after length
                                 for (String line : writtenStr.split("\\n")) {
                                     if (!line.isEmpty()) {
                                         // Split into length and rest
                                         int spacePos = line.indexOf(' ');
                                         assertTrue("Line should contain space after length", spacePos > 0);
                                         
                                         // Verify length matches actual line length (including space)
                                         String lenStr = line.substring(0, spacePos);
                                         int declaredLen = Integer.parseInt(lenStr);
                                         assertEquals("Declared length should match actual line length", 
                                             declaredLen, line.length());
                                         
                                         // Verify key=value format after length
                                         String rest = line.substring(spacePos + 1);
                                         assertTrue("Rest should be in key=value format", 
                                             rest.matches(".+=.+"));
                                     }
                                 }
                                 
                                 // Verify the space is present in the actual bytes
                                 assertTrue("Output should contain space after length numbers",
                                     writtenStr.contains(" key1=value1"));
                                 assertTrue("Output should contain space after length numbers for UTF-8",
                                     writtenStr.contains(" ümlaut=valüe"));
                             }

    @Test
                        public void testWritePaxHeadersWithNonAsciiCharacters5() throws Exception {
                            // Setup
                            String entryName = "testEntry";
                            Map<String, String> headers = new HashMap<>();
                            // Using a non-ASCII character (€ takes 3 bytes in UTF-8)
                            headers.put("testKey", "€100"); 
                            
                            // Mock the output stream to capture written data
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                            
                            // Use reflection to call private method
                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                "writePaxHeaders", String.class, Map.class);
                            writePaxHeaders.setAccessible(true);
                            writePaxHeaders.invoke(tarOut, entryName, headers);
                            tarOut.close();
                            
                            // Verify
                            byte[] writtenData = baos.toByteArray();
                            String writtenString = new String(writtenData, "UTF-8");
                            
                            // The line should be in format "length key=value\n"
                            // For "testKey=€100", the UTF-8 byte length is:
                            // "testKey".length() = 7
                            // "€100".getBytes(UTF_8).length = 5 (€ is 3 bytes + '1''0''0')
                            // Plus 3 for " =", plus 1 for "\n" = total 16 bytes
                            // So line should start with "16 testKey=€100\n"
                            assertTrue("Written data should start with correct length prefix",
                                       writtenString.startsWith("16 testKey=€100\n"));
                            
                            // Additional verification that the length prefix matches actual byte length
                            String expectedLine = "16 testKey=€100\n";
                            assertEquals("Length prefix should match actual byte length",
                                        expectedLine.getBytes("UTF-8").length,
                                        Integer.parseInt(expectedLine.split(" ")[0]));
                        }

    @Test
                   public void testWritePaxHeadersWithOverestimatedLength2() throws Exception {
                       // Setup
                       String entryName = "testEntry";
                       Map<String, String> headers = new HashMap<>();
                       // Create a header where UTF-8 encoding will make actual length shorter than estimate
                       // Using a multi-byte UTF-8 character that counts as 1 in string length but more in bytes
                       headers.put("path", "正常"); // "正常" is 2 chars but 6 bytes in UTF-8
                       
                       // Mock dependencies
                       OutputStream mockOut = mock(OutputStream.class);
                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                       
                       // Capture the written data
                       ByteArrayOutputStream capturedData = new ByteArrayOutputStream();
                       doAnswer(invocation -> {
                           byte[] data = (byte[]) invocation.getArguments()[0];
                           capturedData.write(data);
                           return null;
                       }).when(mockOut).write(any(byte[].class));
                       
                       // Use reflection to access private method
                       Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                           "writePaxHeaders", String.class, Map.class);
                       writePaxHeaders.setAccessible(true);
                       
                       // Execute
                       writePaxHeaders.invoke(tarOut, entryName, headers);
                       
                       // Verify
                       String writtenData = capturedData.toString("UTF-8");
                       // Check that the length was properly adjusted (original would adjust, mutant wouldn't)
                       // The line should look like "length path=正常\n" with correct length
                       assertTrue(writtenData.matches("\\d+ path=正常\\n"));
                       
                       // Verify the length prefix matches the actual line length in bytes
                       String[] lines = writtenData.split("\n");
                       for (String line : lines) {
                           if (line.isEmpty()) continue;
                           String[] parts = line.split(" ", 2);
                           int declaredLength = Integer.parseInt(parts[0]);
                           int actualLength = (parts[1] + "\n").getBytes("UTF-8").length;
                           assertEquals("Declared length should match actual byte length", 
                                       declaredLength, actualLength);
                       }
                   }

    @Test
              public void testWritePaxHeadersWithNonAsciiCharactersDetectsEncodingMutant() throws Exception {
                  // Setup
                  ByteArrayOutputStream baos = new ByteArrayOutputStream();
                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                  
                  // Create headers with non-ASCII characters that have different UTF-8 vs ISO-8859-1 lengths
                  Map<String, String> headers = new HashMap<>();
                  String key = "test";
                  String value = "ü";  // ü is 2 bytes in UTF-8, 1 byte in ISO-8859-1
                  headers.put(key, value);
                  
                  // Expected line format: "length key=value\n"
                  // For UTF-8: "9 test=ü\n" would be:
                  // - '9' (1) + ' ' (1) + 'test' (4) + '=' (1) + 'ü' (2) + '\n' (1) = 10 bytes
                  // So the correct adjusted line should be "10 test=ü\n" (10 bytes)
                  
                  // Call method
                  Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                      "writePaxHeaders", String.class, Map.class);
                  writePaxHeaders.setAccessible(true);
                  writePaxHeaders.invoke(tarOut, "testEntry", headers);
                  
                  // Verify
                  byte[] writtenData = baos.toByteArray();
                  String writtenString = new String(writtenData, CharsetNames.UTF_8);
                  
                  // The correct line should start with "10 " (UTF-8 encoding)
                  // If mutant uses ISO-8859-1, it would start with "9 " instead
                  assertTrue("Header line should start with correct UTF-8 length", 
                      writtenString.startsWith("10 " + key + "=" + value + "\n"));
                  
                  // Verify the actual byte length matches the prefix
                  int newlinePos = writtenString.indexOf('\n');
                  String line = writtenString.substring(0, newlinePos + 1);
                  int declaredLength = Integer.parseInt(line.substring(0, line.indexOf(' ')));
                  int actualLength = line.getBytes(CharsetNames.UTF_8).length;
                  assertEquals("Declared length should match actual UTF-8 bytes", 
                      declaredLength, actualLength);
              }

    @Test
          public void testWritePaxHeadersWithNonAsciiCharacters6() throws Exception {
              // Setup
              String entryName = "testEntry";
              Map<String, String> headers = new HashMap<>();
              // Using a non-ASCII character (€ symbol) which has different UTF-8 vs default encoding
              headers.put("testKey", "valueWith€Symbol");
              
              // Create a mock output stream to capture the written bytes
              ByteArrayOutputStream baos = new ByteArrayOutputStream();
              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos, "UTF-8");
              
              // Method under test
              Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                  "writePaxHeaders", String.class, Map.class);
              writePaxHeaders.setAccessible(true);
              writePaxHeaders.invoke(tarOut, entryName, headers);
              
              // Get the written bytes
              byte[] actualBytes = baos.toByteArray();
              
              // Expected bytes - manually create what UTF-8 encoding should produce
              String expectedLine = "24 testKey=valueWith€Symbol\n"; // Note: 24 is the UTF-8 byte length
              byte[] expectedBytes = expectedLine.getBytes(CharsetNames.UTF_8);
              
              // Verify the bytes match UTF-8 encoding
              // The actual output will have more bytes (tar headers etc), but should contain our UTF-8 encoded line
              boolean found = false;
              for (int i = 0; i <= actualBytes.length - expectedBytes.length; i++) {
                  boolean match = true;
                  for (int j = 0; j < expectedBytes.length; j++) {
                      if (actualBytes[i + j] != expectedBytes[j]) {
                          match = false;
                          break;
                      }
                  }
                  if (match) {
                      found = true;
                      break;
                  }
              }
              
              assertTrue("Output should contain the UTF-8 encoded line", found);
              
              // Additional verification - check the line length prefix matches UTF-8 byte count
              // The line should start with the correct byte length (24 in this case)
              String outputString = new String(actualBytes, CharsetNames.UTF_8);
              assertTrue("Output should contain correct length prefix", 
                         outputString.contains("24 testKey=valueWith€Symbol"));
          }

    @Test
    public void testWritePaxHeadersWithNonAsciiName() throws Exception {
        // Setup
        String entryName = "tést-file-ñame"; // Contains non-ASCII characters
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("path", "some/path");
        headers.put("size", "1234");
        
        // Mock dependencies
        OutputStream mockOutputStream = mock(OutputStream.class);
        TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
        
        // Capture the written data
        ByteArrayOutputStream capturedData = new ByteArrayOutputStream();
        doAnswer(invocation -> {
            byte[] data = (byte[]) invocation.getArguments()[0];
            int off = (int) invocation.getArguments()[1];
            int len = (int) invocation.getArguments()[2];
            capturedData.write(data, off, len);
            return null;
        }).when(mockOutputStream).write(any(byte[].class), anyInt(), anyInt());
        
        // Use reflection to call private method
        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
            "writePaxHeaders", String.class, Map.class);
        writePaxHeaders.setAccessible(true);
        writePaxHeaders.invoke(tarOutput, entryName, headers);
        
        // Verify results
        byte[] writtenData = capturedData.toByteArray();
        
        // 1. Verify the entry name was properly processed
        String writtenString = new String(writtenData, java.nio.charset.StandardCharsets.UTF_8);
        assertFalse("Non-ASCII characters should be stripped from entry name",
                   writtenString.contains("tést") || writtenString.contains("ñame"));
        
        // 2. Verify the PAX headers were written correctly
        assertTrue(writtenString.contains("path=some/path"));
        assertTrue(writtenString.contains("size=1234"));
        
        // 3. Verify the length prefixes are correct
        String[] lines = writtenString.split("\\\\n");
        for (String line : lines) {
            if (line.isEmpty()) continue;
            // Check length prefix matches actual line length
            int spacePos = line.indexOf(' ');
            if (spacePos > 0) {
                String lenStr = line.substring(0, spacePos);
                int declaredLen = Integer.parseInt(lenStr);
                int actualLen = line.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                assertEquals("Line length prefix doesn't match actual length", 
                            declaredLen, actualLen);
            }
        }
        
        // Verify interactions
        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
    }


}
