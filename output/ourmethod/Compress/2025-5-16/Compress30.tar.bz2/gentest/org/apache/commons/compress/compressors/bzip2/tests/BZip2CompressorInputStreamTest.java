package gentest.org.apache.commons.compress.compressors.bzip2.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.compressors.bzip2.*;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.compress.compressors.CompressorInputStream;
 
public class BZip2CompressorInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                                      public void testRead_ZeroLength_ReturnsZero() throws IOException {
                                                                                                                                                                                                                                                                                                                                                          byte[] inputData = {1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(inputData));
                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 0);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, result);
                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                      public void testRead_EmptyStream_ReturnsMinusOne() throws IOException {
                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(-1, result);
                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                      public void testRead_NormalCase_ReturnsBytesRead() throws IOException {
                                                                                                                                                                                                                                                                                                                                                          byte[] inputData = {1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(inputData));
                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 2, 3);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(3, result);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[0]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[1]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(1, dest[2]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(2, dest[3]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(3, dest[4]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[5]);
                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                      public void testRead_PartialRead_ReturnsBytesActuallyRead() throws IOException {
                                                                                                                                                                                                                                                                                                                                                          InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                          when(mockIn.read()).thenReturn(1, 2, -1);
                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(2, result);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(1, dest[0]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(2, dest[1]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[2]);
                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                      public void testRead_WithOffset_PutsDataInCorrectPosition() throws IOException {
                                                                                                                                                                                                                                                                                                                                                          byte[] inputData = {10, 20, 30, 40, 50};
                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(inputData));
                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 3, 2);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(2, result);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[0]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[1]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[2]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(10, dest[3]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(20, dest[4]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[5]);
                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                      public void testRead_MultipleCalls_ContinuesReading() throws IOException {
                                                                                                                                                                                                                                                                                                                                                          byte[] inputData = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(inputData));
                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                          int firstRead = stream.read(dest, 0, 3);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(3, firstRead);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(1, dest[0]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(2, dest[1]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(3, dest[2]);
                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                          int secondRead = stream.read(dest, 3, 4);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(4, secondRead);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(4, dest[3]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(5, dest[4]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(6, dest[5]);
                                                                                                                                                                                                                                                                                                                                                          assertEquals(7, dest[6]);
                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                              public void testRead_WhenStreamOpenAndRead0ReturnsPositive() throws Exception {
                                                                                                                                                                                                                                                                                                                                                  // Arrange
                                                                                                                                                                                                                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                  // Use reflection to mock the private read0() method
                                                                                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                                                                                                                                                                                                                                                                  Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                                                                                                                                  read0Method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                  when(read0Method.invoke(spyBzIn)).thenReturn(42);
                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                  // Act
                                                                                                                                                                                                                                                                                                                                                  int result = spyBzIn.read();
                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                  // Assert
                                                                                                                                                                                                                                                                                                                                                  assertEquals(42, result);
                                                                                                                                                                                                                                                                                                                                                  // Can't verify protected count() method directly
                                                                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                                                                              public void testRead_WhenStreamNeverInitialized_ThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                                                                                                  // Arrange
                                                                                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                  // Expect exception
                                                                                                                                                                                                                                                                                                                                                  ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                                                                                  exception.expect(IOException.class);
                                                                                                                                                                                                                                                                                                                                                  exception.expectMessage("stream closed");
                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                  // Act
                                                                                                                                                                                                                                                                                                                                                  bzIn.read();
                                                                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                                                                              public void testRead_StreamClosed_ThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                                                                                                  InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                                                                                                                                  stream.close();
                                                                                                                                                                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                                                                                                      stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                                                                      fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                                                                                                                                  } catch (IOException e) {
                                                                                                                                                                                                                                                                                                                                                      assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                                                                          public void testRead_WhenStreamOpenAndRead0ReturnsNegative() throws Exception {
                                                                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                              when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                                                                              int result = bzIn.read();
                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                                                                              assertEquals(-1, result);
                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                              // Clean up
                                                                                                                                                                                                                                                                                                                                              bzIn.close();
                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                          public void testRead_NegativeOffset_ThrowsIndexOutOfBounds() throws IOException {
                                                                                                                                                                                                                                                                                                                                              BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(new byte[10]));
                                                                                                                                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                                                                                  stream.read(dest, -1, 5);
                                                                                                                                                                                                                                                                                                                                                  fail("Expected IndexOutOfBoundsException");
                                                                                                                                                                                                                                                                                                                                              } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                                                                                                  assertEquals("offs(-1) < 0.", e.getMessage());
                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                          public void testRead_NegativeLength_ThrowsIndexOutOfBounds() throws IOException {
                                                                                                                                                                                                                                                                                                                                              byte[] input = new byte[10];
                                                                                                                                                                                                                                                                                                                                              ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(input);
                                                                                                                                                                                                                                                                                                                                              BZip2CompressorInputStream stream = new BZip2CompressorInputStream(byteArrayInputStream);
                                                                                                                                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                                                                                                      stream.read(dest, 0, -1);
                                                                                                                                                                                                                                                                                                                                                      fail("Expected IndexOutOfBoundsException to be thrown");
                                                                                                                                                                                                                                                                                                                                                  } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                                                                                                      assertEquals("len(-1) < 0.", e.getMessage());
                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                              } finally {
                                                                                                                                                                                                                                                                                                                                                  stream.close();
                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                          public void testRead_OffsetPlusLengthExceedsDestLength_ThrowsIndexOutOfBounds() throws IOException {
                                                                                                                                                                                                                                                                                                                                              BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(new byte[10]));
                                                                                                                                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                                                                                                  stream.read(dest, 5, 6);
                                                                                                                                                                                                                                                                                                                                                  fail("Expected IndexOutOfBoundsException to be thrown");
                                                                                                                                                                                                                                                                                                                                              } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                                                                                                  assertEquals("offs(5) + len(6) > dest.length(10).", e.getMessage());
                                                                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                                      public void testRead_WhenRead0ThrowsIOException_PropagatesException() throws Exception {
                                                                                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Get private read0 method via reflection
                                                                                                                                                                                                                                                                                                                                          Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                                                                                                                          read0Method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Create a spy
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Mock the read0 method to throw IOException
                                                                                                                                                                                                                                                                                                                                          doThrow(new IOException("read error")).when(read0Method.invoke(spyBzIn));
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Act & Assert
                                                                                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                                                                                              spyBzIn.read();
                                                                                                                                                                                                                                                                                                                                              fail("Expected IOException");
                                                                                                                                                                                                                                                                                                                                          } catch (IOException e) {
                                                                                                                                                                                                                                                                                                                                              assertEquals("read error", e.getMessage());
                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                          public void testRead_WhenCountThrowsRuntimeException_PropagatesException() throws Exception {
                                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Create a spy that will allow us to override protected method behavior
                                                                                                                                                                                                                                                                                                              BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Mock read0() via reflection
                                                                                                                                                                                                                                                                                                              Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                                                                                              read0Method.setAccessible(true);
                                                                                                                                                                                                                                                                                                              when(read0Method.invoke(spyBzIn)).thenReturn(10);
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Override count() behavior using doThrow on the spy
                                                                                                                                                                                                                                                                                                              // Using doThrow().when() syntax for protected method
                                                                                                                                                                                                                                                                                                              doThrow(new RuntimeException("count error"));
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Set up expected exception
                                                                                                                                                                                                                                                                                                              ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                                              exception.expect(RuntimeException.class);
                                                                                                                                                                                                                                                                                                              exception.expectMessage("count error");
                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                                              spyBzIn.read();
                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                              public void testRead_WhenStreamClosed_ThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                  // Arrange
                                                                                                                                                                                                                                                                  org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                                  InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                  org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream bzIn = 
                                                                                                                                                                                                                                                                      new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Close the stream
                                                                                                                                                                                                                                                                  bzIn.close();
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Expect exception
                                                                                                                                                                                                                                                                  expectedException.expect(IOException.class);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Act
                                                                                                                                                                                                                                                                  bzIn.read();
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                          public void testReadWithZeroLength() throws IOException {
                                                                                                                                                                                                                                                              // Setup - create a mock input stream that will return some data
                                                                                                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                              when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(1);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create the test object with our mock stream
                                                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test case 1: len = -1 (should be treated as invalid)
                                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                  bzIn.read(dest, 0, -1);
                                                                                                                                                                                                                                                                  fail("Should have thrown IOException for negative length");
                                                                                                                                                                                                                                                              } catch (IOException e) {
                                                                                                                                                                                                                                                                  // Expected behavior
                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test case 2: len = 0 (should be treated as valid in original, invalid in mutant)
                                                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                                                              int result = bzIn.read(dest, 0, 0);
                                                                                                                                                                                                                                                              // Original would allow this and return 0 (or whatever read0 returns)
                                                                                                                                                                                                                                                              // Mutant would throw exception
                                                                                                                                                                                                                                                              // Assert that we get a valid response (not exception) for len=0
                                                                                                                                                                                                                                                              assertTrue("Should handle zero-length read properly", result >= -1);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test case 3: len = 1 (normal case)
                                                                                                                                                                                                                                                              result = bzIn.read(dest, 0, 1);
                                                                                                                                                                                                                                                              assertEquals("Should read one byte", 1, result);
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testReadWithZeroLengthShouldReturnZero() throws IOException {
                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                                                              int offs = 0;
                                                                                                                                                                                                                                                              int len = 0;  // This is the critical value that will expose the mutant
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                              int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                              assertEquals("Method should return 0 when len=0", 0, result);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify no interaction with the stream should occur for len=0
                                                                                                                                                                                                                                                              verify(mockInputStream, never()).read();
                                                                                                                                                                                                                                                          }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                         public void testReadWithBufferOverflow() throws IOException {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                                                                                                                                             int offs = 0;
                                                                                                                                                                                                                                                             int len = 11;  // Exceeds dest.length
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Test - should throw for offs+len > dest.length
                                                                                                                                                                                                                                                             bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testReadWithExactBufferBoundary() throws IOException {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             byte[] dest = new byte[10];  // buffer of size 10
                                                                                                                                                                                                                                                             int offs = 0;
                                                                                                                                                                                                                                                             int len = 10;  // exactly equals buffer length
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Mock the input stream to return some data
                                                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                             when(mockInputStream.read()).thenReturn(65, 66, 67, -1); // return 3 bytes then EOF
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create test instance with our mock stream
                                                                                                                                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Test - should not throw exception and should read successfully
                                                                                                                                                                                                                                                             int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             assertEquals(3, bytesRead);  // should read 3 bytes
                                                                                                                                                                                                                                                             assertEquals(65, dest[0]);   // first byte
                                                                                                                                                                                                                                                             assertEquals(66, dest[1]);   // second byte
                                                                                                                                                                                                                                                             assertEquals(67, dest[2]);   // third byte
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Clean up
                                                                                                                                                                                                                                                             bzIn.close();
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                        public void testReadWithExactBufferSize() throws IOException {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                                                                                                                                            int offs = 0;
                                                                                                                                                                                                                                                            int len = 10;  // Exactly equals dest.length
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Mock the InputStream to return some data
                                                                                                                                                                                                                                                            InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                                            when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(len);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Test - should successfully read when offs+len == dest.length
                                                                                                                                                                                                                                                            int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                            assertEquals(len, result);  // This will fail in the mutant version
                                                                                                                                                                                                                                                            verify(mockIn).read(dest, offs, len);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testReadWithPartialBuffer() throws IOException {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                                                                                                                                            int offs = 0;
                                                                                                                                                                                                                                                            int len = 5;  // Less than dest.length
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                                            when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(len);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Test - should successfully read when offs+len < dest.length
                                                                                                                                                                                                                                                            int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                            assertEquals(len, result);
                                                                                                                                                                                                                                                            verify(mockIn).read(dest, offs, len);
                                                                                                                                                                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                   public void testReadWhenStreamIsNullShouldThrowException() throws IOException {
                                                                                                                                                                                                                                                       // Arrange - create stream with null input
                                                                                                                                                                                                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Act - should throw IOException
                                                                                                                                                                                                                                                       bzip2Stream.read();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Assert - exception expected (handled by @Test annotation)
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testReadWhenStreamIsNotNullShouldNotThrowException() throws IOException {
                                                                                                                                                                                                                                                       // Arrange - create stream with mock input
                                                                                                                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                       when(mockInputStream.read()).thenReturn(42); // mock read() to return some value
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                                                       int result = bzip2Stream.read();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Assert - should return the mocked value
                                                                                                                                                                                                                                                       assertEquals(42, result);
                                                                                                                                                                                                                                                   }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                   public void testReadWithNullStreamShouldThrowIOException() throws IOException {
                                                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                                                                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Act - should throw IOException when in is null
                                                                                                                                                                                                                                                       bzip2Stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Assert - exception expected (handled by @Test annotation)
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testReadWithValidStreamShouldNotThrowException() throws IOException {
                                                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                                                                                                                       when(mockInputStream.read()).thenReturn(-1); // Simulate EOF
                                                                                                                                                                                                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                                                       int result = bzip2Stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                                                       assertEquals(-1, result); // Verify EOF handling
                                                                                                                                                                                                                                                       verify(mockInputStream).read(); // Verify stream was accessed
                                                                                                                                                                                                                                                   }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                                                                                                               public void testReadWithNegativeLengthShouldThrowException() throws IOException {
                                                                                                                                                                                                                                                   // Arrange
                                                                                                                                                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                   byte[] dest = new byte[10];
                                                                                                                                                                                                                                                   int offs = 0;
                                                                                                                                                                                                                                                   int len = -1;  // Negative length
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Act
                                                                                                                                                                                                                                                   bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Assert - expecting IndexOutOfBoundsException
                                                                                                                                                                                                                                                   // If mutation exists (len <= 0), it would return 0 instead of throwing
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                              public void testReadWithZeroLengthShouldNotProcessNegativeLengthSameAsZero() throws IOException {
                                                                                                                                                                                                                                                  // Setup mock to return -1 when read0() is called with negative length
                                                                                                                                                                                                                                                  // and 0 when read0() is called with zero length
                                                                                                                                                                                                                                                  // This is implementation-specific and might need adjustment based on actual read0() behavior
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // The key is that with the mutation, both cases would be treated the same,
                                                                                                                                                                                                                                                  // while the original code would treat them differently
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // First test with zero length
                                                                                                                                                                                                                                                  when(mockInputStream.read(any(byte[].class), eq(0), eq(0))).thenReturn(0);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Then test with negative length
                                                                                                                                                                                                                                                  when(mockInputStream.read(any(byte[].class), eq(0), eq(-1))).thenThrow(new IOException("Invalid length"));
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                      byte[] buffer = new byte[10];
                                                                                                                                                                                                                                                      // Test zero length read
                                                                                                                                                                                                                                                      int result1 = bzip2Stream.read(buffer, 0, 0);
                                                                                                                                                                                                                                                      assertEquals(0, result1);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Test negative length read - should throw exception
                                                                                                                                                                                                                                                      bzip2Stream.read(buffer, 0, -1);
                                                                                                                                                                                                                                                      fail("Expected IOException for negative length");
                                                                                                                                                                                                                                                  } catch (IOException e) {
                                                                                                                                                                                                                                                      // Expected for original code
                                                                                                                                                                                                                                                      assertTrue(e.getMessage().contains("Invalid length"));
                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // The mutation would treat both cases the same (as zero length),
                                                                                                                                                                                                                                                  // so this test would fail for the mutated code
                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                          public void testReadAtBoundaryCondition() throws IOException {
                                                                                                                                                                                                                                              // Create a mock input stream that returns specific values
                                                                                                                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                              when(mockIn.read()).thenReturn(1, 2, 3, -1); // Will return 1, 2, 3 then EOF
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Create the compressor stream with our mock
                                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Test reading exactly at boundary
                                                                                                                                                                                                                                              byte[] dest = new byte[3];
                                                                                                                                                                                                                                              int bytesRead = bzIn.read(dest, 0, 3); // Read exactly 3 bytes
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Verify correct behavior
                                                                                                                                                                                                                                              assertEquals(3, bytesRead); // Should read exactly 3 bytes
                                                                                                                                                                                                                                              assertEquals(1, dest[0]);
                                                                                                                                                                                                                                              assertEquals(2, dest[1]);
                                                                                                                                                                                                                                              assertEquals(3, dest[2]);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Verify the mutant would try to read one more byte
                                                                                                                                                                                                                                              // The original code would stop at 3 bytes, mutant would try to read 4th
                                                                                                                                                                                                                                              verify(mockIn, times(3)).read(); // Original should call read() exactly 3 times
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // If mutant was present, it would call read() 4 times (due to <= instead of <)
                                                                                                                                                                                                                                              // This assertion would fail for the mutant
                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                          public void testReadWithExactBufferSizeShouldNotOverflow() throws IOException {
                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                                              int offs = 0;
                                                                                                                                                                                                                                              int len = 10;
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Mock input stream that returns exactly 10 bytes then EOF
                                                                                                                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                              when(mockIn.read()).thenReturn(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Test
                                                                                                                                                                                                                                              int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                              assertEquals("Should return exactly len bytes", len, result);
                                                                                                                                                                                                                                              assertEquals("Last byte should be 10", 10, dest[9]);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Verify no write beyond buffer bounds would occur
                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                  byte b = dest[10]; // This should be out of bounds
                                                                                                                                                                                                                                                  fail("Should not be able to read beyond buffer bounds");
                                                                                                                                                                                                                                              } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                  // Expected
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Verify exactly len bytes were requested from stream
                                                                                                                                                                                                                                              verify(mockIn, times(len + 1)).read(); // len successful reads + 1 EOF check
                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                         public void testReadWithMultipleBytesDetectsPostIncrementMutant() throws IOException {
                                                                                                                                                                                                                                             // Setup mock input stream that returns 3 bytes then EOF
                                                                                                                                                                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                             when(mockIn.read()).thenReturn(65, 66, 67, -1);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create test subject with our mock stream
                                                                                                                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Prepare destination array
                                                                                                                                                                                                                                             byte[] dest = new byte[5];
                                                                                                                                                                                                                                             int offs = 1;
                                                                                                                                                                                                                                             int len = 3;
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Execute read
                                                                                                                                                                                                                                             int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify results
                                                                                                                                                                                                                                             assertEquals(3, result); // Should read 3 bytes
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify correct positions were written (original behavior)
                                                                                                                                                                                                                                             assertEquals(0, dest[0]); // Should remain unchanged
                                                                                                                                                                                                                                             assertEquals(65, dest[1]); // First byte at offs
                                                                                                                                                                                                                                             assertEquals(66, dest[2]); // Second byte at offs+1
                                                                                                                                                                                                                                             assertEquals(67, dest[3]); // Third byte at offs+2
                                                                                                                                                                                                                                             assertEquals(0, dest[4]); // Should remain unchanged
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify mock interactions
                                                                                                                                                                                                                                             verify(mockIn, times(4)).read(); // 3 bytes + EOF check
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                        public void testReadArrayWithOffsetDetectsMutant() throws IOException {
                                                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                                                            byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                                                                                                                            int initialOffset = 2;
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Mock the input stream to return test data
                                                                                                                                                                                                                                            InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                            when(mockIn.read()).thenReturn(
                                                                                                                                                                                                                                                (int) testData[0], 
                                                                                                                                                                                                                                                (int) testData[1], 
                                                                                                                                                                                                                                                (int) testData[2],
                                                                                                                                                                                                                                                -1); // EOF
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Create the compressor stream with our mock
                                                                                                                                                                                                                                            BZip2CompressorInputStream compressor = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // First read - should write to dest[2] and increment offset
                                                                                                                                                                                                                                            int bytesRead1 = compressor.read(dest, initialOffset, 1);
                                                                                                                                                                                                                                            assertEquals(1, bytesRead1);
                                                                                                                                                                                                                                            assertEquals(testData[0], dest[initialOffset]);
                                                                                                                                                                                                                                            assertEquals(0, dest[initialOffset + 1]); // Next position should be untouched
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Second read - should write to dest[3] if post-increment works correctly
                                                                                                                                                                                                                                            int bytesRead2 = compressor.read(dest, initialOffset + bytesRead1, 1);
                                                                                                                                                                                                                                            assertEquals(1, bytesRead2);
                                                                                                                                                                                                                                            assertEquals(testData[1], dest[initialOffset + bytesRead1]);
                                                                                                                                                                                                                                            assertEquals(0, dest[initialOffset + bytesRead1 + 1]); // Next position should be untouched
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Third read with larger length to test multiple writes
                                                                                                                                                                                                                                            int bytesRead3 = compressor.read(dest, initialOffset + bytesRead1 + bytesRead2, 3);
                                                                                                                                                                                                                                            assertEquals(1, bytesRead3); // Only one byte available from our mock
                                                                                                                                                                                                                                            assertEquals(testData[2], dest[initialOffset + bytesRead1 + bytesRead2]);
                                                                                                                                                                                                                                            assertEquals(0, dest[initialOffset + bytesRead1 + bytesRead2 + 1]); // Next position should be untouched
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify the mutation would fail this test - with the mutant, all writes would go to initialOffset
                                                                                                                                                                                                                                            // and the offset would only increment afterwards, causing overwrites
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testReadByteArrayWithDestOffsLessThanOffs() throws IOException {
                                                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                                                            byte[] inputData = "test data".getBytes();
                                                                                                                                                                                                                                            ByteArrayInputStream inputStream = new ByteArrayInputStream(inputData);
                                                                                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(inputStream);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Create destination array and parameters where destOffs < offs
                                                                                                                                                                                                                                            byte[] dest = new byte[100];
                                                                                                                                                                                                                                            int offs = 5;
                                                                                                                                                                                                                                            int len = 10;
                                                                                                                                                                                                                                            int destOffs = 3; // destOffs < offs
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // The original code should return (destOffs - offs) = -2
                                                                                                                                                                                                                                            // The mutated code would return -1
                                                                                                                                                                                                                                            int expected = destOffs - offs; // Should be -2
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Call the method
                                                                                                                                                                                                                                            int result = bzIn.read(dest, destOffs, len);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify the result
                                                                                                                                                                                                                                            assertEquals("Should return the correct offset difference when destOffs < offs", 
                                                                                                                                                                                                                                                        expected, result);
                                                                                                                                                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                        public void testReadWhenStreamClosed() throws IOException {
                                                                                                                                                                                                                                            // Create stream with null input to simulate closed stream
                                                                                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // This should throw IOException
                                                                                                                                                                                                                                            bzIn.read();
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testReadNormalCase() throws IOException {
                                                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                                                            byte[] inputData = "test data".getBytes();
                                                                                                                                                                                                                                            ByteArrayInputStream inputStream = new ByteArrayInputStream(inputData);
                                                                                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(inputStream);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Call the simple read method
                                                                                                                                                                                                                                            int result = bzIn.read();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify we got the first byte
                                                                                                                                                                                                                                            assertTrue("Should return a valid byte value", result >= 0);
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                    public void testReadDetectsDestOffsetMutation() throws IOException {
                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                        byte[] dest = new byte[10];
                                                                                                                                                                                                                                        int offs = 0;
                                                                                                                                                                                                                                        int len = 1;
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Mock the input stream to return one byte then EOF
                                                                                                                                                                                                                                        InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                        when(mockIn.read()).thenReturn(65, -1);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Execute
                                                                                                                                                                                                                                        int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                        assertEquals("Should return 1 when one byte is read", 1, bytesRead);
                                                                                                                                                                                                                                        assertEquals("First byte should be read into destination", 65, dest[0]);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Cleanup
                                                                                                                                                                                                                                        bzIn.close();
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                   public void testReadWithInUseMutation() throws Exception {
                                                                                                                                                                                                                                       // Setup mock input stream with test data
                                                                                                                                                                                                                                       byte[] testData = {1, 2, 3, 4, 5, 6, 7, 8};
                                                                                                                                                                                                                                       InputStream mockIn = new ByteArrayInputStream(testData);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Create compressor stream with mock input
                                                                                                                                                                                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Use reflection to access private inUse array and modify it
                                                                                                                                                                                                                                       // This simulates the mutation where inUse flags are incorrectly set
                                                                                                                                                                                                                                       Field inUseField = BZip2CompressorInputStream.class.getDeclaredField("inUse");
                                                                                                                                                                                                                                       inUseField.setAccessible(true);
                                                                                                                                                                                                                                       boolean[] inUse = (boolean[]) inUseField.get(bzIn);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Set alternating inUse flags to test the mutation
                                                                                                                                                                                                                                       for (int i = 0; i < inUse.length; i++) {
                                                                                                                                                                                                                                           inUse[i] = (i % 2 == 0); // Every even index is inUse
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Destination buffer
                                                                                                                                                                                                                                       byte[] dest = new byte[8];
                                                                                                                                                                                                                                       int offs = 0;
                                                                                                                                                                                                                                       int len = 8;
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Call read method
                                                                                                                                                                                                                                       int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify results
                                                                                                                                                                                                                                       if (bytesRead > 0) {
                                                                                                                                                                                                                                           // Check that only bytes at even positions were read (original behavior)
                                                                                                                                                                                                                                           // The mutation would read odd positions instead
                                                                                                                                                                                                                                           for (int i = 0; i < bytesRead; i++) {
                                                                                                                                                                                                                                               if (i % 2 == 0) {
                                                                                                                                                                                                                                                   assertNotEquals(0, dest[i]); // Should have data for even positions
                                                                                                                                                                                                                                               } else {
                                                                                                                                                                                                                                                   assertEquals(0, dest[i]); // Should be 0 for odd positions
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify correct number of bytes read
                                                                                                                                                                                                                                       assertTrue(bytesRead > 0 || bytesRead == -1);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Clean up
                                                                                                                                                                                                                                       bzIn.close();
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                              public void testReadWithInUseCharacters() throws IOException {
                                                                                                                                                                                                                                  // Create a mock input stream with specific test data
                                                                                                                                                                                                                                  // This is a simple BZip2 compressed version of "test" string
                                                                                                                                                                                                                                  byte[] testData = new byte[] {
                                                                                                                                                                                                                                      0x42, 0x5A, 0x68, 0x39, 0x31, 0x41, 0x59, 0x26, 
                                                                                                                                                                                                                                      0x53, 0x59, (byte)0xE5, (byte)0x99, 0x00, 0x00, 0x00, 0x10,
                                                                                                                                                                                                                                      0x40, 0x00, 0x20, 0x00, 0x30, (byte)0xCD, 0x34, 0x19,
                                                                                                                                                                                                                                      (byte)0xA6, (byte)0xD3, (byte)0x8B, (byte)0x9E, 0x00, 0x00, 0x00, 0x00
                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                  InputStream mockIn = new ByteArrayInputStream(testData);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create the compressor input stream with our test data
                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Read some data that would be affected by the inUse condition
                                                                                                                                                                                                                                  int firstByte = bzIn.read();
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify the read data matches expected decompressed output
                                                                                                                                                                                                                                  // For our test data "test", first byte is 't' (116)
                                                                                                                                                                                                                                  assertEquals(116, firstByte);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Read more data to ensure proper decompression
                                                                                                                                                                                                                                  byte[] buffer = new byte[100];
                                                                                                                                                                                                                                  int bytesRead = bzIn.read(buffer, 0, 100);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify the correct number of bytes were read
                                                                                                                                                                                                                                  assertTrue(bytesRead > 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify specific content that would be affected by the inUse condition
                                                                                                                                                                                                                                  // For our test data "test", remaining bytes are 'e' (101), 's' (115), 't' (116)
                                                                                                                                                                                                                                  assertEquals(101, buffer[0]);
                                                                                                                                                                                                                                  assertEquals(115, buffer[1]);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  bzIn.close();
                                                                                                                                                                                                                              }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                              public void testReadWhenStreamClosed1() throws IOException {
                                                                                                                                                                                                                                  // Create stream with null input to simulate closed stream
                                                                                                                                                                                                                                  BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                  closedStream.read(); // Should throw IOException
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                          public void testReadWithMultipleBytesDetectsSeqToUnseqMutation() throws Exception {
                                                                                                                                                                                                                              // Setup mock input stream that returns multiple bytes
                                                                                                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                              when(mockIn.read()).thenReturn(65, 66, 67, -1); // Return 3 bytes then EOF
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Create test instance
                                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to access private seqToUnseq array for verification
                                                                                                                                                                                                                              Field seqToUnseqField = BZip2CompressorInputStream.class.getDeclaredField("seqToUnseq");
                                                                                                                                                                                                                              seqToUnseqField.setAccessible(true);
                                                                                                                                                                                                                              byte[] seqToUnseq = (byte[]) seqToUnseqField.get(bzIn);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Create destination buffer
                                                                                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                                                                                              int bytesRead = bzIn.read(dest, 0, 3);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify correct number of bytes read
                                                                                                                                                                                                                              assertEquals(3, bytesRead);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify seqToUnseq was populated correctly
                                                                                                                                                                                                                              // The mutation would cause incorrect indexing if not caught
                                                                                                                                                                                                                              assertEquals(65, seqToUnseq[0]); // First byte should be at index 0
                                                                                                                                                                                                                              assertEquals(66, seqToUnseq[1]); // Second byte at index 1
                                                                                                                                                                                                                              assertEquals(67, seqToUnseq[2]); // Third byte at index 2
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify destination buffer was filled correctly
                                                                                                                                                                                                                              assertEquals(65, dest[0]);
                                                                                                                                                                                                                              assertEquals(66, dest[1]);
                                                                                                                                                                                                                              assertEquals(67, dest[2]);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify nInUseShadow was incremented properly (would fail with mutation)
                                                                                                                                                                                                                              Field nInUseShadowField = BZip2CompressorInputStream.class.getDeclaredField("nInUseShadow");
                                                                                                                                                                                                                              nInUseShadowField.setAccessible(true);
                                                                                                                                                                                                                              int nInUseShadow = nInUseShadowField.getInt(bzIn);
                                                                                                                                                                                                                              assertTrue(nInUseShadow >= 3); // Should be at least 3 after reading 3 bytes
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                         public void testReadSequenceWithMultipleBytes() throws IOException {
                                                                                                                                                                                                                             // Setup mock to return a sequence of bytes
                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                             when(mockInputStream.read()).thenReturn(65, 66, 67, -1);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create BZip2 stream with mock input
                                                                                                                                                                                                                             BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                             // First read
                                                                                                                                                                                                                             int firstByte = bzip2Stream.read();
                                                                                                                                                                                                                             assertEquals(65, firstByte);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                             // Second read - this would expose the mutation if nInUseShadow is not properly incremented
                                                                                                                                                                                                                             int secondByte = bzip2Stream.read();
                                                                                                                                                                                                                             assertEquals(66, secondByte);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                             // Third read
                                                                                                                                                                                                                             int thirdByte = bzip2Stream.read();
                                                                                                                                                                                                                             assertEquals(67, thirdByte);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                             // EOF
                                                                                                                                                                                                                             int eof = bzip2Stream.read();
                                                                                                                                                                                                                             assertEquals(-1, eof);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                             // Verify the internal state through reflection if needed
                                                                                                                                                                                                                             // This would catch if nInUseShadow was incremented at wrong time
                                                                                                                                                                                                                             // Note: In a real test, we might need reflection to check internal counters
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                         public void testReadWithNegativeValueFromRead() throws IOException {
                                                                                                                                                                                                                             // Create mock InputStream
                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                             // Simulate read() returning negative value (EOF)
                                                                                                                                                                                                                             when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create BZip2CompressorInputStream with mock
                                                                                                                                                                                                                             BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             int result = bzip2Stream.read();
                                                                                                                                                                                                                             assertEquals(-1, result);
                                                                                                                                                                                                                             // Verify count was properly updated (would be -1 for EOF)
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                     public void testReadReturnsNegativeOneOnEOF() throws Exception {
                                                                                                                                                                                                                         // Create a mock InputStream that returns -1 (EOF) when read is called
                                                                                                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                         when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Create the compressor stream with our mock input
                                                                                                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Call read() and verify it returns -1 for EOF
                                                                                                                                                                                                                         int result = bzIn.read();
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Assert that we get -1 (not 0) for EOF condition
                                                                                                                                                                                                                         assertEquals("Should return -1 for EOF condition", -1, result);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify the mock was called
                                                                                                                                                                                                                         verify(mockInputStream).read();
                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                public void testReadReturnsNegativeOneOnEOF1() throws Exception {
                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                    byte[] dest = new byte[10];
                                                                                                                                                                                                                    int offs = 0;
                                                                                                                                                                                                                    int len = 5;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create a real stream with a mock input stream that returns EOF
                                                                                                                                                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                    when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                    when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                    BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to set the private 'in' field
                                                                                                                                                                                                                    Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                                                                    inField.setAccessible(true);
                                                                                                                                                                                                                    inField.set(stream, mockInputStream);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                    int result = stream.read(dest, offs, len);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                    assertEquals("Should return -1 when no bytes are read", -1, result);
                                                                                                                                                                                                                }

    @Test(expected = IOException.class)
                                                                                                                                                                                                            public void testReadWhenStreamClosedThrowsException() throws IOException {
                                                                                                                                                                                                                // Arrange - create stream with null input to simulate closed stream
                                                                                                                                                                                                                BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    // Act - should throw
                                                                                                                                                                                                                    stream.read();
                                                                                                                                                                                                                } catch (IOException e) {
                                                                                                                                                                                                                    // Assert - verify exception message
                                                                                                                                                                                                                    assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                    throw e; // rethrow for @Test verification
                                                                                                                                                                                                                }
                                                                                                                                                                                                                
                                                                                                                                                                                                                // If we get here, the method returned instead of throwing
                                                                                                                                                                                                                fail("Expected IOException but method returned normally");
                                                                                                                                                                                                            }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                public void testReadWhenStreamClosed2() throws IOException {
                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                    byte[] dest = new byte[10];
                                                                                                                                                                                                                    int offs = 0;
                                                                                                                                                                                                                    int len = 5;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create instance with null input stream (simulating closed stream)
                                                                                                                                                                                                                    BZip2CompressorInputStream stream = new BZip2CompressorInputStream((InputStream) null);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Act & Assert
                                                                                                                                                                                                                    // Should throw IllegalStateException, but mutant would return -1
                                                                                                                                                                                                                    stream.read(dest, offs, len);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                           public void testReadWhenStreamClosed_VerifyExceptionMessage() {
                                                                                                                                                                                                               // Arrange
                                                                                                                                                                                                               byte[] dest = new byte[10];
                                                                                                                                                                                                               int offs = 0;
                                                                                                                                                                                                               int len = 5;
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create instance with null input stream (simulating closed stream)
                                                                                                                                                                                                               BZip2CompressorInputStream stream = null;
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   stream = new BZip2CompressorInputStream((InputStream) null);
                                                                                                                                                                                                               } catch (IOException e) {
                                                                                                                                                                                                                   fail("Unexpected IOException during stream creation");
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   // Act
                                                                                                                                                                                                                   stream.read(dest, offs, len);
                                                                                                                                                                                                                   fail("Expected IllegalStateException");
                                                                                                                                                                                                               } catch (IOException e) {
                                                                                                                                                                                                                   // Assert
                                                                                                                                                                                                                   assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }

    @Test(expected = IOException.class)
                                                                                                                                                                                                      public void testReadWhenStreamIsNull() throws IOException {
                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                          BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Act & Assert
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              bzip2Stream.read();
                                                                                                                                                                                                          } finally {
                                                                                                                                                                                                              bzip2Stream.close();
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testReadWhenStreamIsNotNull() throws IOException {
                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                          when(mockInputStream.read()).thenReturn(42); // Mock read() to return test value
                                                                                                                                                                                                          BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Act
                                                                                                                                                                                                          int result = bzip2Stream.read();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Assert
                                                                                                                                                                                                          assertEquals(42, result);
                                                                                                                                                                                                          // Original: should read successfully
                                                                                                                                                                                                          // Mutant: would throw IOException when stream is not null
                                                                                                                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                                                                                                                      public void testReadThrowsIOExceptionWhenStreamClosed() throws IOException {
                                                                                                                                                                                                          // Create a stream with null input (simulating closed stream)
                                                                                                                                                                                                          BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Prepare test data
                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                          int offs = 0;
                                                                                                                                                                                                          int len = 5;
                                                                                                                                                                                                          
                                                                                                                                                                                                          // This should throw IOException with "stream closed" message
                                                                                                                                                                                                          bzip2Stream.read(dest, offs, len);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // The mutant would not throw the exception here, so this test would fail
                                                                                                                                                                                                          // for the mutated version, thus detecting the mutant
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                              public void testReadDoesNotThrowExceptionWhenStreamOpen() throws Exception {
                                                                                                                                                                                                  // Create mock input stream
                                                                                                                                                                                                  InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create a stream with valid input
                                                                                                                                                                                                  BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Prepare test data
                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                  int offs = 0;
                                                                                                                                                                                                  int len = 5;
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to access the private read0() method
                                                                                                                                                                                                  Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                  read0Method.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create a spy to intercept calls
                                                                                                                                                                                                  BZip2CompressorInputStream spyStream = spy(bzip2Stream);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Mock the read0() method behavior using reflection
                                                                                                                                                                                                  doAnswer(invocation -> {
                                                                                                                                                                                                      // Return -1 when read0() is called
                                                                                                                                                                                                      return -1;
                                                                                                                                                                                                  }).when(spyStream).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                  
                                                                                                                                                                                                  // This should not throw exception
                                                                                                                                                                                                  int result = spyStream.read(dest, offs, len);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify the result is -1 (no bytes read)
                                                                                                                                                                                                  assertEquals(-1, result);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // The mutant would throw exception here, so this test would fail
                                                                                                                                                                                                  // for the mutated version, thus detecting the mutant from the other side
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                         public void testReadDetectsMutantWhenMagic0IsNotMinus1AndIsNotFirstStream() throws IOException {
                                                                                                                                                                                             // Setup scenario where magic0 != -1 && isFirstStream == false
                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                             BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream, false);
                                                                                                                                                                                             
                                                                                                                                                                                             // We can't mock read0() directly as it's private, so we'll test the public read() behavior
                                                                                                                                                                                             // The test will verify the basic read functionality when stream is properly initialized
                                                                                                                                                                                             when(mockInputStream.read()).thenReturn(20);
                                                                                                                                                                                             
                                                                                                                                                                                             int result = bzip2Stream.read();
                                                                                                                                                                                             assertEquals(20, result);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the underlying InputStream was called
                                                                                                                                                                                             verify(mockInputStream).read();
                                                                                                                                                                                         }

    @Test(expected = IOException.class)
                                                                                                                                                                                         public void testReadThrowsWhenStreamClosed() throws IOException {
                                                                                                                                                                                             // Test the else branch where stream is closed
                                                                                                                                                                                             BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                             bzip2Stream.read();
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                     public void testReadDetectsMutantWhenMagic0IsMinus1AndIsFirstStream() throws Exception {
                                                                                                                                                                                         // Setup scenario where magic0 == -1 && isFirstStream == true
                                                                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                         BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream, true);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set magic0 to -1 to simulate the condition
                                                                                                                                                                                         Field magic0Field = BZip2CompressorInputStream.class.getDeclaredField("magic0");
                                                                                                                                                                                         magic0Field.setAccessible(true);
                                                                                                                                                                                         magic0Field.set(bzip2Stream, -1);
                                                                                                                                                                                         
                                                                                                                                                                                         // Mock the underlying InputStream to return test data
                                                                                                                                                                                         when(mockInputStream.read()).thenReturn(10);
                                                                                                                                                                                         
                                                                                                                                                                                         // Test the read method
                                                                                                                                                                                         int result = bzip2Stream.read();
                                                                                                                                                                                         assertEquals(10, result);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify the underlying InputStream was called
                                                                                                                                                                                         verify(mockInputStream).read();
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                     public void testReadDetectsMutatedInitCondition() throws Exception {
                                                                                                                                                                                         // Create a mock InputStream
                                                                                                                                                                                         InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                         
                                                                                                                                                                                         // Case 1: magic0 is -1 and isFirstStream is true
                                                                                                                                                                                         // Original would allow, mutant should throw
                                                                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn) {
                                                                                                                                                                                             // We can't override private init() method, so we'll test behavior through read()
                                                                                                                                                                                         };
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to force the init to fail
                                                                                                                                                                                         Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                                         inField.setAccessible(true);
                                                                                                                                                                                         inField.set(bzIn, mockIn);
                                                                                                                                                                                         
                                                                                                                                                                                         Field magic0Field = BZip2CompressorInputStream.class.getDeclaredField("magic0");
                                                                                                                                                                                         magic0Field.setAccessible(true);
                                                                                                                                                                                         magic0Field.set(bzIn, -1);
                                                                                                                                                                                         
                                                                                                                                                                                         byte[] dest = new byte[10];
                                                                                                                                                                                         try {
                                                                                                                                                                                             bzIn.read(dest, 0, 10);
                                                                                                                                                                                             fail("Should have thrown IOException for invalid magic number with first stream");
                                                                                                                                                                                         } catch (IOException e) {
                                                                                                                                                                                             // Expected for mutant
                                                                                                                                                                                         }
                                                                                                                                                                                         
                                                                                                                                                                                         // Case 2: magic0 is not -1 and isFirstStream is false (concatenated stream)
                                                                                                                                                                                         // Original would allow, mutant should throw
                                                                                                                                                                                         BZip2CompressorInputStream bzIn2 = new BZip2CompressorInputStream(mockIn, true);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set magic0 to valid value but isFirstStream to false
                                                                                                                                                                                         magic0Field.set(bzIn2, 'B'); // Valid magic number
                                                                                                                                                                                         Field decompressConcatenatedField = BZip2CompressorInputStream.class.getDeclaredField("decompressConcatenated");
                                                                                                                                                                                         decompressConcatenatedField.setAccessible(true);
                                                                                                                                                                                         decompressConcatenatedField.set(bzIn2, false);
                                                                                                                                                                                         
                                                                                                                                                                                         try {
                                                                                                                                                                                             bzIn2.read(dest, 0, 10);
                                                                                                                                                                                             fail("Should have thrown IOException for concatenated stream even with valid magic");
                                                                                                                                                                                         } catch (IOException e) {
                                                                                                                                                                                             // Expected for mutant
                                                                                                                                                                                         }
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                 public void testBlockSizeCalculation() throws Exception {
                                                                                                                                                                                     // Create a mock input stream
                                                                                                                                                                                     InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                     
                                                                                                                                                                                     // Create BZip2CompressorInputStream with block size '1' (ASCII 49)
                                                                                                                                                                                     // Original behavior: blockSize100k = 49 - 48 = 1
                                                                                                                                                                                     // Mutated behavior: blockSize100k = 49 + 48 = 97
                                                                                                                                                                                     BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockStream);
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to access private field blockSize100k
                                                                                                                                                                                     Field blockSizeField = BZip2CompressorInputStream.class.getDeclaredField("blockSize100k");
                                                                                                                                                                                     blockSizeField.setAccessible(true);
                                                                                                                                                                                     int actualBlockSize = blockSizeField.getInt(bzIn);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify the block size is calculated correctly (should be 1)
                                                                                                                                                                                     assertEquals("Block size calculation is incorrect", 1, actualBlockSize);
                                                                                                                                                                                     
                                                                                                                                                                                     // Additional test with different block size to be thorough
                                                                                                                                                                                     // Using block size '2' (ASCII 50)
                                                                                                                                                                                     // Original: 50 - 48 = 2
                                                                                                                                                                                     // Mutated: 50 + 48 = 98
                                                                                                                                                                                     bzIn = new BZip2CompressorInputStream(mockStream);
                                                                                                                                                                                     actualBlockSize = blockSizeField.getInt(bzIn);
                                                                                                                                                                                     assertEquals("Block size calculation is incorrect", 1, actualBlockSize);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                public void testBlockSizeCalculation1() throws IOException {
                                                                                                                                                                                    // Create a mock input stream with block size character '1' (ASCII 49)
                                                                                                                                                                                    byte[] mockData = {'B', 'Z', 'h', '1'}; // BZh1 is the BZip2 header format
                                                                                                                                                                                    ByteArrayInputStream bais = new ByteArrayInputStream(mockData);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create the compressor stream which should parse the block size
                                                                                                                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(bais);
                                                                                                                                                                                    
                                                                                                                                                                                    try {
                                                                                                                                                                                        // Use reflection to access the private blockSize100k field
                                                                                                                                                                                        Field blockSizeField = BZip2CompressorInputStream.class.getDeclaredField("blockSize100k");
                                                                                                                                                                                        blockSizeField.setAccessible(true);
                                                                                                                                                                                        int blockSize = blockSizeField.getInt(bzIn);
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify blockSize100k was calculated correctly
                                                                                                                                                                                        // Original: blockSize100k = '1' - '0' = 49 - 48 = 1
                                                                                                                                                                                        // Mutant: blockSize100k = '1' + '0' = 49 + 48 = 97
                                                                                                                                                                                        assertEquals("Block size should be 1 (original calculation)", 1, blockSize);
                                                                                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                        fail("Failed to access private field blockSize100k: " + e.getMessage());
                                                                                                                                                                                    } finally {
                                                                                                                                                                                        bzIn.close();
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test(expected = IOException.class)
                                                                                                                                                                                public void testReadThrowsExceptionWhenStreamClosed() throws IOException {
                                                                                                                                                                                    BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                    closedStream.read();
                                                                                                                                                                                }

    @Test
                                                                                                                                                                            public void testBlockRandomisedFlag() throws Exception {
                                                                                                                                                                                // Create a mock input stream
                                                                                                                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                when(mockIn.read()).thenReturn(1); // Return some dummy data
                                                                                                                                                                                
                                                                                                                                                                                // Create the compressor stream with decompressConcatenated=true to ensure init is called
                                                                                                                                                                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn, true);
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to access private bsR method for testing
                                                                                                                                                                                Method bsRMethod = BZip2CompressorInputStream.class.getDeclaredMethod("bsR", int.class);
                                                                                                                                                                                bsRMethod.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Test case 1: When bsR(1) returns 1
                                                                                                                                                                                // Original code would set blockRandomised=true, mutant would set false
                                                                                                                                                                                Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
                                                                                                                                                                                blockRandomisedField.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Call bsR(1) directly and verify blockRandomised
                                                                                                                                                                                int result = (int) bsRMethod.invoke(bzIn, 1);
                                                                                                                                                                                boolean isRandomised = blockRandomisedField.getBoolean(bzIn);
                                                                                                                                                                                
                                                                                                                                                                                // Assert original behavior (true when bsR(1)==1)
                                                                                                                                                                                // This will fail if mutant is present (which would set false)
                                                                                                                                                                                assertEquals("blockRandomised should be true when bsR(1) returns 1", 
                                                                                                                                                                                             result == 1, isRandomised);
                                                                                                                                                                                
                                                                                                                                                                                // Test case 2: When bsR(1) returns 0
                                                                                                                                                                                // Need to reset the stream for clean test
                                                                                                                                                                                bzIn = new BZip2CompressorInputStream(mockIn, true);
                                                                                                                                                                                // Mock bsR to return 0 - in real code this depends on internal state
                                                                                                                                                                                // Since we can't directly mock bsR, we'll test the actual behavior
                                                                                                                                                                                // and verify the inverse relationship holds
                                                                                                                                                                                result = (int) bsRMethod.invoke(bzIn, 1);
                                                                                                                                                                                isRandomised = blockRandomisedField.getBoolean(bzIn);
                                                                                                                                                                                
                                                                                                                                                                                // Assert original behavior (false when bsR(1)==0)
                                                                                                                                                                                // This will fail if mutant is present (which would set true)
                                                                                                                                                                                assertEquals("blockRandomised should be false when bsR(1) returns 0", 
                                                                                                                                                                                             result == 1, isRandomised);
                                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testReadSetsCorrectBlockRandomisedState() throws Exception {
                                                                                                                                                           // Create input stream with test data
                                                                                                                                                           byte[] testData = new byte[100]; // Enough data to avoid EOF
                                                                                                                                                           InputStream in = new ByteArrayInputStream(testData);
                                                                                                                                                           BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(in);
                                                                                                                                                           
                                                                                                                                                           // Get private methods and field via reflection
                                                                                                                                                           Method bsRMethod = BZip2CompressorInputStream.class.getDeclaredMethod("bsR", int.class);
                                                                                                                                                           bsRMethod.setAccessible(true);
                                                                                                                                                           Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
                                                                                                                                                           blockRandomisedField.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Get START_BLOCK_STATE via reflection
                                                                                                                                                           Field startBlockStateField = BZip2CompressorInputStream.class.getDeclaredField("START_BLOCK_STATE");
                                                                                                                                                           startBlockStateField.setAccessible(true);
                                                                                                                                                           int START_BLOCK_STATE = startBlockStateField.getInt(null);
                                                                                                                                                           
                                                                                                                                                           // First test case: simulate bsR(1) returning 1 (should set blockRandomised to true)
                                                                                                                                                           Field currentStateField = BZip2CompressorInputStream.class.getDeclaredField("currentState");
                                                                                                                                                           currentStateField.setAccessible(true);
                                                                                                                                                           currentStateField.set(bzIn, START_BLOCK_STATE);
                                                                                                                                                           
                                                                                                                                                           // Create a mock that will return 1 when bsR(1) is called
                                                                                                                                                           BZip2CompressorInputStream testStream = new BZip2CompressorInputStream(new ByteArrayInputStream(testData));
                                                                                                                                                           currentStateField.set(testStream, START_BLOCK_STATE);
                                                                                                                                                           
                                                                                                                                                           // Mock bsR to return 1 when called with argument 1
                                                                                                                                                           Method mockedBsR = BZip2CompressorInputStream.class.getDeclaredMethod("bsR", int.class);
                                                                                                                                                           mockedBsR.setAccessible(true);
                                                                                                                                                           when(mockedBsR.invoke(testStream, eq(1))).thenReturn(1);
                                                                                                                                                           
                                                                                                                                                           // Call read which should trigger the blockRandomised assignment
                                                                                                                                                           testStream.read();
                                                                                                                                                           
                                                                                                                                                           // Verify blockRandomised is set correctly (should be true for bsR(1) == 1)
                                                                                                                                                           assertTrue(blockRandomisedField.getBoolean(testStream));
                                                                                                                                                           
                                                                                                                                                           // Second test case: simulate bsR(1) returning 0 (should set blockRandomised to false)
                                                                                                                                                           BZip2CompressorInputStream testStream2 = new BZip2CompressorInputStream(new ByteArrayInputStream(testData));
                                                                                                                                                           currentStateField.set(testStream2, START_BLOCK_STATE);
                                                                                                                                                           
                                                                                                                                                           // Mock bsR to return 0 when called with argument 1
                                                                                                                                                           when(mockedBsR.invoke(testStream2, eq(1))).thenReturn(0);
                                                                                                                                                           
                                                                                                                                                           testStream2.read();
                                                                                                                                                           // Should be false for original condition (bsR(1) == 0)
                                                                                                                                                           assertFalse(blockRandomisedField.getBoolean(testStream2));
                                                                                                                                                       }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                  public void testReadWithNegativeOffset() throws IOException {
                                                                                                                                                      InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                      byte[] dest = new byte[10];
                                                                                                                                                      bzip2Stream.read(dest, -1, 5);
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testReadWithZeroOffset() throws IOException {
                                                                                                                                                      // Create a mock input stream that returns test data
                                                                                                                                                      byte[] testData = new byte[]{65}; // 'A' character
                                                                                                                                                      InputStream mockInput = new ByteArrayInputStream(testData);
                                                                                                                                                      
                                                                                                                                                      // Initialize the BZip2 stream with our mock input
                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                      
                                                                                                                                                      byte[] dest = new byte[10];
                                                                                                                                                      // This test will pass with original code but fail with mutant
                                                                                                                                                      // since mutant would throw exception for offset=0
                                                                                                                                                      int result = bzip2Stream.read(dest, 0, 5);
                                                                                                                                                      assertEquals(1, result); // assuming read0() returns 1
                                                                                                                                                      assertEquals(65, dest[0]); // verify data was written
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testReadWithPositiveOffset() throws IOException {
                                                                                                                                                      // Create test data - single byte 'A' (ASCII 65) compressed with BZip2
                                                                                                                                                      byte[] testData = new byte[] {'B', 'Z', 'h', '9', '1', 'A', 'Y', '&', 'S', 'Y'};
                                                                                                                                                      InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(inputStream);
                                                                                                                                                      
                                                                                                                                                      byte[] dest = new byte[10];
                                                                                                                                                      int result = bzip2Stream.read(dest, 1, 5);
                                                                                                                                                      assertEquals(1, result); // assuming read0() returns 1
                                                                                                                                                      assertEquals(65, dest[1]); // verify data was written at offset 1
                                                                                                                                                      
                                                                                                                                                      bzip2Stream.close();
                                                                                                                                                  }

    @Test
                                                                                                                                                  public void testReadWithZeroOffsetShouldNotThrowException() throws IOException {
                                                                                                                                                      // Arrange
                                                                                                                                                      InputStream mockInput = new ByteArrayInputStream("TestData".getBytes());
                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                      byte[] dest = new byte[10];
                                                                                                                                                      int offs = 0;  // This is the critical value that would be affected by the mutation
                                                                                                                                                      int len = 5;
                                                                                                                                                  
                                                                                                                                                      // Act
                                                                                                                                                      int result = bzip2Stream.read(dest, offs, len);
                                                                                                                                                  
                                                                                                                                                      // Assert
                                                                                                                                                      assertTrue("Should not throw exception for offs=0", result >= -1);
                                                                                                                                                      // Additional verification that bytes were actually read
                                                                                                                                                      if (result > 0) {
                                                                                                                                                          assertEquals('T', dest[0]);  // Verify first byte was written (changed from 'A' to 'T' to match test data)
                                                                                                                                                      }
                                                                                                                                                      bzip2Stream.close();
                                                                                                                                                  }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                  public void testReadWithNegativeOffsetShouldThrowException() throws IOException {
                                                                                                                                                      // Arrange
                                                                                                                                                      byte[] dest = new byte[10];
                                                                                                                                                      int offs = -1;  // Clearly negative
                                                                                                                                                      int len = 5;
                                                                                                                                                      InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                  
                                                                                                                                                      // Act & Assert (expect exception)
                                                                                                                                                      bzip2Stream.read(dest, offs, len);
                                                                                                                                                  }

    @Test
                                                                                                                                              public void testReadWithZeroLengthShouldReturnZeroWithoutException() throws IOException {
                                                                                                                                                  // Arrange
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                  int offs = 0;
                                                                                                                                                  int len = 0;  // This is the critical value that will expose the mutation
                                                                                                                                                  
                                                                                                                                                  // Act
                                                                                                                                                  int result = bzIn.read(dest, offs, len);
                                                                                                                                                  
                                                                                                                                                  // Assert
                                                                                                                                                  assertEquals("Method should return 0 for zero-length read", 0, result);
                                                                                                                                                  
                                                                                                                                                  // Verify no interaction with the stream for zero-length read
                                                                                                                                                  verify(mockInputStream, never()).read();
                                                                                                                                                  verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                              }

    @Test
                                                                                                                                             public void testReadWithDifferentReturnValues() throws IOException {
                                                                                                                                                 // Create mock objects
                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                 BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                 
                                                                                                                                                 // We can't mock private read0() directly, so we'll test through public read()
                                                                                                                                                 // Test case 1: read returns positive value
                                                                                                                                                 when(mockInputStream.read()).thenReturn(42);
                                                                                                                                                 assertEquals(42, bzStream.read());
                                                                                                                                                 
                                                                                                                                                 // Test case 2: read returns 0
                                                                                                                                                 when(mockInputStream.read()).thenReturn(0);
                                                                                                                                                 assertEquals(0, bzStream.read());
                                                                                                                                                 
                                                                                                                                                 // Test case 3: read returns negative value (EOF)
                                                                                                                                                 when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                 assertEquals(-1, bzStream.read());
                                                                                                                                                 
                                                                                                                                                 // Test case 4: stream is closed
                                                                                                                                                 BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                                                                                 try {
                                                                                                                                                     closedStream.read();
                                                                                                                                                     fail("Expected IOException");
                                                                                                                                                 } catch (IOException e) {
                                                                                                                                                     assertEquals("stream closed", e.getMessage());
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                         public void testReadWithExactBufferSize1() throws IOException {
                                                                                                                                             // Setup
                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                             int offs = 0;
                                                                                                                                             int len = 10;  // Exactly equals dest.length
                                                                                                                                             
                                                                                                                                             // Mock the input stream to return some data
                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                             when(mockInputStream.read(any(), eq(offs), eq(len))).thenReturn(len);
                                                                                                                                             
                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                             
                                                                                                                                             // Test - should not throw exception for original, but mutant would throw
                                                                                                                                             int result = bzIn.read(dest, offs, len);
                                                                                                                                             
                                                                                                                                             // Verify
                                                                                                                                             assertEquals(len, result);
                                                                                                                                             verify(mockInputStream).read(dest, offs, len);
                                                                                                                                         }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                                                         public void testReadWithBufferOverflow1() throws IOException {
                                                                                                                                             // Setup
                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                             int offs = 0;
                                                                                                                                             int len = 11;  // Exceeds dest.length
                                                                                                                                             
                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                             
                                                                                                                                             // Test - should throw exception in both original and mutant
                                                                                                                                             bzIn.read(dest, offs, len);
                                                                                                                                         }

    @Test
                                                                                                                                         public void testReadWithPartialBuffer1() throws IOException {
                                                                                                                                             // Setup
                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                             int offs = 0;
                                                                                                                                             int len = 5;  // Less than dest.length
                                                                                                                                             
                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                             when(mockInputStream.read(any(), eq(offs), eq(len))).thenReturn(len);
                                                                                                                                             
                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                             
                                                                                                                                             // Test - should work in both original and mutant
                                                                                                                                             int result = bzIn.read(dest, offs, len);
                                                                                                                                             
                                                                                                                                             // Verify
                                                                                                                                             assertEquals(len, result);
                                                                                                                                             verify(mockInputStream).read(dest, offs, len);
                                                                                                                                         }

    @Test
                                                                                                                                         public void testReadWithOffsetAndLengthEqualToBufferLength() throws IOException {
                                                                                                                                             // Setup
                                                                                                                                             byte[] dest = new byte[10];  // buffer of size 10
                                                                                                                                             int offs = 5;
                                                                                                                                             int len = 5;  // offs + len = 10, which equals dest.length
                                                                                                                                             
                                                                                                                                             // Mock the input stream to return some data
                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                             when(mockInputStream.read()).thenReturn(65);  // return 'A'
                                                                                                                                             
                                                                                                                                             // Create test instance with our mock stream
                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                             
                                                                                                                                             // Test - should NOT throw exception with original code
                                                                                                                                             // If mutant is present, this would throw IndexOutOfBoundsException
                                                                                                                                             int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                             
                                                                                                                                             // Verify
                                                                                                                                             assertTrue("Should read at least some bytes", bytesRead > 0);
                                                                                                                                             assertEquals("Should read exactly len bytes", len, bytesRead);
                                                                                                                                             assertEquals('A', dest[offs]);  // verify data was written
                                                                                                                                         }

    @Test(expected = IOException.class)
                                                                                                                                        public void testReadWithNullInputStreamThrowsException() throws IOException {
                                                                                                                                            // Arrange
                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                            int offs = 0;
                                                                                                                                            int len = 5;
                                                                                                                                            
                                                                                                                                            // Create instance with null input stream
                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                            
                                                                                                                                            // Act & Assert (expecting IOException)
                                                                                                                                            bzIn.read(dest, offs, len);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testReadWithValidInputStreamDoesNotThrowException() throws IOException {
                                                                                                                                            // Arrange
                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                            int offs = 0;
                                                                                                                                            int len = 5;
                                                                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                            when(mockInputStream.read()).thenReturn(-1); // Simulate EOF
                                                                                                                                            
                                                                                                                                            // Create instance with valid input stream
                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                            
                                                                                                                                            // Act
                                                                                                                                            int result = bzIn.read(dest, offs, len);
                                                                                                                                            
                                                                                                                                            // Assert
                                                                                                                                            assertEquals(-1, result); // Should return -1 for EOF
                                                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                                                       public void testReadWhenStreamIsNullShouldThrowException1() throws IOException {
                                                                                                                                           // Arrange
                                                                                                                                           BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                           
                                                                                                                                           // Act & Assert
                                                                                                                                           bzip2Stream.read();
                                                                                                                                       }

    @Test
                                                                                                                                       public void testReadWhenStreamIsNotNullShouldNotThrowException1() throws IOException {
                                                                                                                                           // Arrange
                                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                           when(mockInputStream.read()).thenReturn(42); // return some dummy value
                                                                                                                                           BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                           
                                                                                                                                           // Act
                                                                                                                                           int result = bzip2Stream.read();
                                                                                                                                           
                                                                                                                                           // Assert
                                                                                                                                           // If we get here without exception, the test passes
                                                                                                                                           // The mutation would have thrown an exception instead
                                                                                                                                           // We can optionally verify the read was called
                                                                                                                                           verify(mockInputStream).read();
                                                                                                                                       }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                   public void testReadWithNegativeLengthShouldThrowException1() throws IOException {
                                                                                                                                       // Arrange
                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                       int offs = 0;
                                                                                                                                       int len = -1;  // Negative length that should trigger exception
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       bzIn.read(dest, offs, len);
                                                                                                                                       
                                                                                                                                       // Assert - exception expected
                                                                                                                                   }

    @Test
                                                                                                                                  public void testReadWithNegativeLength() throws IOException {
                                                                                                                                      // Create mock input stream
                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                      
                                                                                                                                      // Create BZip2CompressorInputStream with mock input
                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                      
                                                                                                                                      // Use reflection to access private read0() method for mocking
                                                                                                                                      try {
                                                                                                                                          Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                          read0Method.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Mock read0() to return -1
                                                                                                                                          when(read0Method.invoke(bzip2Stream)).thenReturn(-1);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to setup mock for read0()");
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Test with negative length
                                                                                                                                      byte[] dest = new byte[10];
                                                                                                                                      int result = bzip2Stream.read(dest, 0, -1);
                                                                                                                                      
                                                                                                                                      // Verify behavior with negative length
                                                                                                                                      // Should either return something other than 0, or if it returns 0,
                                                                                                                                      // then reading with length 0 should also return 0
                                                                                                                                      assertTrue("Negative length should be treated differently from zero", 
                                                                                                                                                result != 0 || bzip2Stream.read(dest, 0, 0) == 0);
                                                                                                                                  }

    @Test
                                                                                                                              public void testReadWithZeroLength1() throws IOException {
                                                                                                                                  // Create mock InputStream
                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                  // Create BZip2CompressorInputStream with mock input
                                                                                                                                  BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                  
                                                                                                                                  // Test with zero length - shouldn't need to mock read0() since zero-length read shouldn't call it
                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                  int result = bzip2Stream.read(dest, 0, 0);
                                                                                                                                  
                                                                                                                                  // Verify behavior for zero length
                                                                                                                                  assertEquals(0, result);
                                                                                                                              }

    @Test
                                                                                                                              public void testReadArrayBoundaryCondition() throws IOException {
                                                                                                                                  // Setup test data - create input that would fill exactly 'hi' bytes
                                                                                                                                  byte[] testData = new byte[100];
                                                                                                                                  for (int i = 0; i < testData.length; i++) {
                                                                                                                                      testData[i] = (byte)(i % 256);
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Create real input stream with test data
                                                                                                                                  ByteArrayInputStream bais = new ByteArrayInputStream(testData);
                                                                                                                                  
                                                                                                                                  // Create BZip2CompressorInputStream with our test data
                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(bais);
                                                                                                                                  
                                                                                                                                  // Create destination array with exactly the size we want to read
                                                                                                                                  byte[] dest = new byte[100];
                                                                                                                                  int offs = 0;
                                                                                                                                  int len = dest.length;
                                                                                                                                  
                                                                                                                                  // Test the boundary condition - read exactly to the array boundary
                                                                                                                                  int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                  
                                                                                                                                  // Verify we read exactly the expected amount (not more)
                                                                                                                                  assertEquals("Should read exactly len bytes", len, bytesRead);
                                                                                                                                  
                                                                                                                                  // Verify no ArrayIndexOutOfBoundsException was thrown
                                                                                                                                  // (the mutant would try to read one more byte when destOffs == hi)
                                                                                                                                  
                                                                                                                                  // Verify the content matches
                                                                                                                                  assertArrayEquals("Read data should match input", testData, dest);
                                                                                                                                  
                                                                                                                                  // Try to read again - should return -1 for EOF
                                                                                                                                  assertEquals("Subsequent read should return EOF", -1, bzIn.read(dest, offs, len));
                                                                                                                              }

    @Test
                                                                                                                          public void testReadBoundaryConditionToDetectMutant() throws IOException {
                                                                                                                              // Setup
                                                                                                                              byte[] dest = new byte[10];
                                                                                                                              int offs = 0;
                                                                                                                              int len = 10;
                                                                                                                              
                                                                                                                              // Mock the input stream to return exactly 'len' bytes before EOF
                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                              when(mockInputStream.read()).thenReturn(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1);
                                                                                                                              
                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                              
                                                                                                                              // Test
                                                                                                                              int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                              
                                                                                                                              // Verify
                                                                                                                              assertEquals("Should read exactly len bytes", len, bytesRead);
                                                                                                                              
                                                                                                                              // Verify no ArrayIndexOutOfBoundsException occurred (would fail if mutant was present)
                                                                                                                              byte[] expected = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                                                                                                              assertArrayEquals("Destination buffer should contain exactly len bytes", 
                                                                                                                                              expected, dest);
                                                                                                                              
                                                                                                                              // Verify the stream position (would be different with mutant)
                                                                                                                              verify(mockInputStream, times(len)).read(); // Exactly len reads
                                                                                                                          }

    @Test
                                                                                                                         public void testReadByteArrayDetectsOffsetMutation() throws IOException {
                                                                                                                             // Setup test data - we'll read 3 bytes
                                                                                                                             byte[] testData = new byte[]{(byte) 0x01, (byte) 0x02, (byte) 0x03};
                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                             when(mockInputStream.read()).thenReturn(
                                                                                                                                 (int) testData[0], 
                                                                                                                                 (int) testData[1], 
                                                                                                                                 (int) testData[2], 
                                                                                                                                 -1); // EOF
                                                                                                                             
                                                                                                                             // Create instance with our mock stream
                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                             
                                                                                                                             // Destination array with extra space to detect overwrites
                                                                                                                             byte[] dest = new byte[5];
                                                                                                                             int offs = 1; // Start writing at position 1
                                                                                                                             
                                                                                                                             // First read - 2 bytes
                                                                                                                             int read1 = bzIn.read(dest, offs, 2);
                                                                                                                             assertEquals(2, read1);
                                                                                                                             assertEquals(testData[0], dest[1]); // Should be at position 1
                                                                                                                             assertEquals(testData[1], dest[2]); // Should be at position 2
                                                                                                                             assertEquals(0, dest[0]); // Should not have written before offset
                                                                                                                             assertEquals(0, dest[3]); // Should not have written beyond
                                                                                                                             
                                                                                                                             // Second read - 1 byte (remaining in our test data)
                                                                                                                             int read2 = bzIn.read(dest, offs + read1, 1);
                                                                                                                             assertEquals(1, read2);
                                                                                                                             assertEquals(testData[2], dest[3]); // Should be at position 3
                                                                                                                             assertEquals(0, dest[4]); // Should not have written beyond
                                                                                                                             
                                                                                                                             // Verify the mutant would fail:
                                                                                                                             // If the offset wasn't incremented properly between writes,
                                                                                                                             // we would see the last write at position 1 instead of 3
                                                                                                                             assertNotEquals(testData[2], dest[1]);
                                                                                                                         }

    @Test
                                                                                                                         public void testReadWithMultipleBytesDetectsPostIncrementMutation() throws IOException {
                                                                                                                             // Setup mock input stream that returns 3 bytes then EOF
                                                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                                                             when(mockIn.read()).thenReturn(65, 66, 67, -1);
                                                                                                                             
                                                                                                                             // Create test subject with our mock input
                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                             
                                                                                                                             // Prepare destination buffer
                                                                                                                             byte[] dest = new byte[10];
                                                                                                                             int offs = 2;
                                                                                                                             int len = 5;
                                                                                                                             
                                                                                                                             // Call the method under test
                                                                                                                             int result = bzIn.read(dest, offs, len);
                                                                                                                             
                                                                                                                             // Verify results
                                                                                                                             assertEquals(3, result); // Should read 3 bytes
                                                                                                                             
                                                                                                                             // Verify array contents - this will catch the mutation
                                                                                                                             // Original code would have:
                                                                                                                             // dest[2] = 65, dest[3] = 66, dest[4] = 67
                                                                                                                             // Mutated code would have:
                                                                                                                             // dest[2] = 65, dest[2] = 66, dest[2] = 67 (overwriting same position)
                                                                                                                             assertEquals(65, dest[offs]);
                                                                                                                             assertEquals(66, dest[offs+1]);
                                                                                                                             assertEquals(67, dest[offs+2]);
                                                                                                                             
                                                                                                                             // Verify positions after offsets+2 are untouched
                                                                                                                             assertEquals(0, dest[offs+3]);
                                                                                                                             assertEquals(0, dest[offs+4]);
                                                                                                                             
                                                                                                                             // Verify positions before offset are untouched
                                                                                                                             assertEquals(0, dest[0]);
                                                                                                                             assertEquals(0, dest[1]);
                                                                                                                         }

    @Test
                                                                                                                            public void testReadWithDifferentOffsets() throws IOException {
                                                                                                                                // Setup mock input stream
                                                                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                                                                when(mockIn.read()).thenReturn(65); // Return 'A' when read
                                                                                                                                
                                                                                                                                // Create test object
                                                                                                                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                
                                                                                                                                // Test case 1: destOffs == offs (should return -1 in both original and mutant)
                                                                                                                                byte[] dest1 = new byte[10];
                                                                                                                                int result1 = bzIn.read(dest1, 5, 5);
                                                                                                                                assertEquals("Should return -1 when offsets are equal", -1, result1);
                                                                                                                                
                                                                                                                                // Test case 2: destOffs < offs (original returns difference, mutant returns -1)
                                                                                                                                byte[] dest2 = new byte[10];
                                                                                                                                int result2 = bzIn.read(dest2, 3, 5);
                                                                                                                                // Original should return (3-5) = -2, mutant would return -1
                                                                                                                                assertNotEquals("Should not return -1 when destOffs < offs", -1, result2);
                                                                                                                                assertEquals("Should return difference when destOffs < offs", -2, result2);
                                                                                                                                
                                                                                                                                // Test case 3: destOffs > offs (should return positive difference)
                                                                                                                                byte[] dest3 = new byte[10];
                                                                                                                                int result3 = bzIn.read(dest3, 7, 5);
                                                                                                                                assertEquals("Should return difference when destOffs > offs", 2, result3);
                                                                                                                            }

    @Test(expected = IOException.class)
                                                                                                                            public void testReadWhenStreamClosed3() throws IOException {
                                                                                                                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                bzIn.read(); // Should throw IOException
                                                                                                                            }

    @Test
                                                                                                                        public void testReadDetectsDestOffsetMutation1() throws IOException {
                                                                                                                            // Setup
                                                                                                                            byte[] dest = new byte[10];
                                                                                                                            int offs = 5;
                                                                                                                            int len = 3;
                                                                                                                            
                                                                                                                            // Mock the input stream to return some bytes
                                                                                                                            InputStream mockIn = mock(InputStream.class);
                                                                                                                            when(mockIn.read()).thenReturn(65, 66, -1); // Return two bytes then EOF
                                                                                                                            
                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                            
                                                                                                                            // Test - read with offset where we expect to read some bytes
                                                                                                                            int result = bzIn.read(dest, offs, len);
                                                                                                                            
                                                                                                                            // Verify - original would return 2 (bytes read), mutant would return -1
                                                                                                                            assertEquals("Should return number of bytes read", 2, result);
                                                                                                                            
                                                                                                                            // Additional verification that bytes were actually written
                                                                                                                            assertEquals((byte)65, dest[offs]);
                                                                                                                            assertEquals((byte)66, dest[offs+1]);
                                                                                                                            
                                                                                                                            // Test case where no bytes are read (destOffs == offs)
                                                                                                                            when(mockIn.read()).thenReturn(-1); // EOF immediately
                                                                                                                            result = bzIn.read(dest, offs, len);
                                                                                                                            assertEquals("Should return -1 when no bytes read", -1, result);
                                                                                                                        }

    @Test
                                                                                                                       public void testReadDetectsInUseMutation() throws IOException {
                                                                                                                           // Setup mock input stream with known data
                                                                                                                           InputStream mockIn = mock(InputStream.class);
                                                                                                                           when(mockIn.read()).thenReturn(65, 66, -1); // 'A', 'B', EOF
                                                                                                                           
                                                                                                                           // Create instance with mock stream
                                                                                                                           BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                           
                                                                                                                           // Force specific inUse state (assuming makeMaps sets this up)
                                                                                                                           // We'll use reflection to manipulate private fields since we need to test the mutation
                                                                                                                           try {
                                                                                                                               Field inUseField = BZip2CompressorInputStream.class.getDeclaredField("inUse");
                                                                                                                               inUseField.setAccessible(true);
                                                                                                                               boolean[] inUse = new boolean[256];
                                                                                                                               inUse[65] = true;  // Only 'A' is marked as in use
                                                                                                                               inUseField.set(bzIn, inUse);
                                                                                                                               
                                                                                                                               Field nInUseField = BZip2CompressorInputStream.class.getDeclaredField("nInUse");
                                                                                                                               nInUseField.setAccessible(true);
                                                                                                                               nInUseField.set(bzIn, 1); // Only 1 character in use
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Failed to setup test via reflection: " + e.getMessage());
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Test reading - should only process 'A' (65)
                                                                                                                           int firstByte = bzIn.read();
                                                                                                                           assertEquals(65, firstByte); // Should read 'A'
                                                                                                                           
                                                                                                                           // Next read should skip 'B' (since it's not in use) and return EOF
                                                                                                                           int secondByte = bzIn.read();
                                                                                                                           assertEquals(-1, secondByte); // Should return EOF
                                                                                                                           
                                                                                                                           // Verify count (should only count 'A')
                                                                                                                           Field suCountField;
                                                                                                                           try {
                                                                                                                               suCountField = BZip2CompressorInputStream.class.getDeclaredField("su_count");
                                                                                                                               suCountField.setAccessible(true);
                                                                                                                               int count = suCountField.getInt(bzIn);
                                                                                                                               assertEquals(1, count); // Only counted 1 valid byte
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Failed to verify count: " + e.getMessage());
                                                                                                                           }
                                                                                                                           
                                                                                                                           // With the mutation (!inUse), it would:
                                                                                                                           // 1. Skip 'A' (because inUse is negated)
                                                                                                                           // 2. Process 'B' (because it's not in use but condition is negated)
                                                                                                                           // 3. Count would be wrong (either 0 or 2 depending on implementation)
                                                                                                                       }

    @Test
                                                                                                                       public void testReadDetectsInUseMutation1() throws IOException {
                                                                                                                           // Create a simple compressed stream that would be affected by inUse mutation
                                                                                                                           byte[] compressedData = new byte[] {
                                                                                                                               // BZip2 header
                                                                                                                               'B', 'Z', 'h', '1',
                                                                                                                               // Block with some simple data
                                                                                                                               0x31, 0x41, 0x59, 0x26, 0x53, 0x59, 0x00, 0x00, 0x00, 0x00,
                                                                                                                               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
                                                                                                                           };
                                                                                                                           
                                                                                                                           InputStream inputStream = new ByteArrayInputStream(compressedData);
                                                                                                                           BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(inputStream);
                                                                                                                           
                                                                                                                           // Buffer for reading
                                                                                                                           byte[] dest = new byte[100];
                                                                                                                           
                                                                                                                           // Read the data - with mutation this would produce different output
                                                                                                                           int bytesRead = bzIn.read(dest, 0, dest.length);
                                                                                                                           
                                                                                                                           // Verify we read some data (exact value depends on compression)
                                                                                                                           assertTrue("Should read some bytes", bytesRead > 0);
                                                                                                                           
                                                                                                                           // Verify specific expected output that would change with the mutation
                                                                                                                           // This assumes knowledge of what the correct decompressed output should be
                                                                                                                           byte[] expectedStart = "expected decompressed data".getBytes();
                                                                                                                           for (int i = 0; i < expectedStart.length && i < bytesRead; i++) {
                                                                                                                               assertEquals("Byte at position " + i + " differs", 
                                                                                                                                           expectedStart[i], dest[i]);
                                                                                                                           }
                                                                                                                           
                                                                                                                           bzIn.close();
                                                                                                                       }

    @Test
                                                                                                                      public void testReadWithSequenceMapping() throws Exception {
                                                                                                                          // Setup
                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                          when(mockInputStream.read()).thenReturn(65); // 'A'
                                                                                                                          
                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                          
                                                                                                                          // Use reflection to access private fields for verification
                                                                                                                          Field seqToUnseqField = BZip2CompressorInputStream.class.getDeclaredField("seqToUnseq");
                                                                                                                          seqToUnseqField.setAccessible(true);
                                                                                                                          byte[] seqToUnseq = (byte[]) seqToUnseqField.get(bzIn);
                                                                                                                          
                                                                                                                          Field nInUseShadowField = BZip2CompressorInputStream.class.getDeclaredField("nInUseShadow");
                                                                                                                          nInUseShadowField.setAccessible(true);
                                                                                                                          int initialNInUseShadow = nInUseShadowField.getInt(bzIn);
                                                                                                                          
                                                                                                                          // Action - trigger sequence mapping
                                                                                                                          int result = bzIn.read();
                                                                                                                          
                                                                                                                          // Verification
                                                                                                                          assertEquals(65, result); // Verify read value
                                                                                                                          
                                                                                                                          // Verify sequence mapping was done correctly
                                                                                                                          byte[] updatedSeqToUnseq = (byte[]) seqToUnseqField.get(bzIn);
                                                                                                                          int updatedNInUseShadow = nInUseShadowField.getInt(bzIn);
                                                                                                                          
                                                                                                                          // In original code, nInUseShadow would be incremented after assignment
                                                                                                                          // In mutant, it would be incremented separately
                                                                                                                          // Verify both the array content and counter
                                                                                                                          assertNotEquals(initialNInUseShadow, updatedNInUseShadow);
                                                                                                                          assertEquals((byte)65, updatedSeqToUnseq[initialNInUseShadow]);
                                                                                                                          
                                                                                                                          // Clean up
                                                                                                                          bzIn.close();
                                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                                      public void testReadWhenStreamClosed4() throws Exception {
                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                          bzIn.read(); // Should throw IOException
                                                                                                                      }

    @Test
                                                                                                                     public void testReadDetectsArrayIndexMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                         // Setup test data
                                                                                                                         byte[] dest = new byte[10];
                                                                                                                         int offs = 0;
                                                                                                                         int len = 5;
                                                                                                                         
                                                                                                                         // Create a mock input stream that returns specific bytes
                                                                                                                         InputStream mockIn = mock(InputStream.class);
                                                                                                                         when(mockIn.read()).thenReturn(65, 66, 67, 68, 69, -1); // Return A,B,C,D,E then EOF
                                                                                                                         
                                                                                                                         // Create the compressor stream with our mock input
                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                         
                                                                                                                         // Use reflection to access private nInUseShadow field for verification
                                                                                                                         Field nInUseShadowField = BZip2CompressorInputStream.class.getDeclaredField("nInUseShadow");
                                                                                                                         nInUseShadowField.setAccessible(true);
                                                                                                                         
                                                                                                                         // Get initial value
                                                                                                                         int initialNInUseShadow = nInUseShadowField.getInt(bzIn);
                                                                                                                         
                                                                                                                         // Perform the read operation
                                                                                                                         int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                         
                                                                                                                         // Verify results
                                                                                                                         assertEquals(5, bytesRead); // Should read 5 bytes
                                                                                                                         assertEquals('A', dest[0]); // Verify array was populated correctly
                                                                                                                         assertEquals('B', dest[1]);
                                                                                                                         assertEquals('C', dest[2]);
                                                                                                                         assertEquals('D', dest[3]);
                                                                                                                         assertEquals('E', dest[4]);
                                                                                                                         
                                                                                                                         // Verify nInUseShadow was incremented properly
                                                                                                                         int finalNInUseShadow = nInUseShadowField.getInt(bzIn);
                                                                                                                         assertEquals(initialNInUseShadow + bytesRead, finalNInUseShadow);
                                                                                                                         
                                                                                                                         // Verify the sequence of operations was correct by checking mock interactions
                                                                                                                         verify(mockIn, times(6)).read(); // 5 successful reads + 1 EOF check
                                                                                                                     }

    @Test
                                                                                                                 public void testReadReturnsNegativeOneWhenNoBytesRead() throws Exception {
                                                                                                                     // Arrange
                                                                                                                     byte[] dest = new byte[10];
                                                                                                                     int offs = 0;
                                                                                                                     int len = 5;
                                                                                                                     
                                                                                                                     // Mock the InputStream and set up EOF condition
                                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                                     BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                     
                                                                                                                     // Use reflection to mock read0() to return -1 (EOF)
                                                                                                                     Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                     inField.setAccessible(true);
                                                                                                                     inField.set(bzIn, mockInputStream);
                                                                                                                     
                                                                                                                     // Mock read0() to return -1 immediately
                                                                                                                     Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                     read0Method.setAccessible(true);
                                                                                                                     when(read0Method.invoke(bzIn)).thenReturn(-1);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     int result = bzIn.read(dest, offs, len);
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertEquals("Should return -1 when no bytes are read", -1, result);
                                                                                                                 }

    @Test
                                                                                                        public void testReadReturnsNegativeOneOnEOF2() throws Exception {
                                                                                                            // Arrange
                                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                            
                                                                                                            // Use reflection to access private read0 method
                                                                                                            Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                            read0Method.setAccessible(true);
                                                                                                            
                                                                                                            // Create a spy and use reflection to force read0() to return -1
                                                                                                            BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                            doAnswer(invocation -> {
                                                                                                                // When read0 is called through normal invocation, return -1
                                                                                                                return -1;
                                                                                                            }).when(spyBzIn).read();
                                                                                                            
                                                                                                            // Use reflection to access protected count field
                                                                                                            Field countField = CompressorInputStream.class.getDeclaredField("count");
                                                                                                            countField.setAccessible(true);
                                                                                                            long initialCount = (long) countField.get(spyBzIn);
                                                                                                            
                                                                                                            // Act
                                                                                                            int result = spyBzIn.read();
                                                                                                            
                                                                                                            // Assert
                                                                                                            assertEquals("Should return -1 on EOF", -1, result);
                                                                                                            
                                                                                                            // Verify count was updated (indirect test through side effects)
                                                                                                            long newCount = (long) countField.get(spyBzIn);
                                                                                                            assertEquals("Count should be incremented by -1", initialCount - 1, newCount);
                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                        public void testReadWhenStreamClosed5() throws IOException {
                                                                                                            // Create an instance with null input stream to simulate closed stream
                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream((InputStream) null);
                                                                                                            
                                                                                                            // This should throw IOException with message "stream closed"
                                                                                                            bzIn.read();
                                                                                                            
                                                                                                            // If the mutant is present, it will return -1 instead of throwing
                                                                                                            // The @Test(expected) will fail if no exception is thrown
                                                                                                        }

    @Test(expected = IllegalStateException.class)
                                                                                                    public void testReadWhenStreamClosedShouldThrowException() throws IOException {
                                                                                                        // Arrange
                                                                                                        byte[] dest = new byte[10];
                                                                                                        int offs = 0;
                                                                                                        int len = 5;
                                                                                                        
                                                                                                        // Create stream with null input to simulate closed stream
                                                                                                        BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        // Should throw IllegalStateException for original code
                                                                                                        // Will return -1 for mutated code and fail the test
                                                                                                        stream.read(dest, offs, len);
                                                                                                    }

    @Test
                                                                                                   public void testReadWhenStreamClosedVerifyExceptionMessage() throws IOException {
                                                                                                       // Create an instance with null input stream to simulate closed stream
                                                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream((InputStream) null);
                                                                                                       
                                                                                                       try {
                                                                                                           bzIn.read();
                                                                                                           fail("Expected IOException to be thrown");
                                                                                                       } catch (IOException e) {
                                                                                                           // Verify the exception message matches exactly
                                                                                                           assertEquals("stream closed", e.getMessage());
                                                                                                       }
                                                                                                   }

    @Test
                                                                                              public void testReadDetectsMutantWhenMagic0IsMinusOneAndIsFirstStream() throws Exception {
                                                                                                  // Setup mock input stream
                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                  when(mockInputStream.read()).thenReturn(-1);
                                                                                                  
                                                                                                  // Create the stream under test with decompressConcatenated=true to ensure isFirstStream can be set
                                                                                                  BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream, true);
                                                                                                  
                                                                                                  // Use reflection to access private fields for testing
                                                                                                  try {
                                                                                                      // Set magic0 to -1
                                                                                                      Field magic0Field = BZip2CompressorInputStream.class.getDeclaredField("magic0");
                                                                                                      magic0Field.setAccessible(true);
                                                                                                      magic0Field.set(bzip2Stream, -1);
                                                                                                      
                                                                                                      // Set isFirstStream to true
                                                                                                      Field isFirstStreamField = BZip2CompressorInputStream.class.getDeclaredField("isFirstStream");
                                                                                                      isFirstStreamField.setAccessible(true);
                                                                                                      isFirstStreamField.set(bzip2Stream, true);
                                                                                                  } catch (NoSuchFieldException e) {
                                                                                                      fail("Required field not found in BZip2CompressorInputStream: " + e.getMessage());
                                                                                                  }
                                                                                                  
                                                                                                  // The original code would return -1 in this case
                                                                                                  // The mutant might behave differently (throw exception or return different value)
                                                                                                  int result = bzip2Stream.read();
                                                                                                  
                                                                                                  // Verify the expected behavior
                                                                                                  assertEquals(-1, result);
                                                                                              }

    @Test
                                                                                              public void testReadDetectsMutantWhenMagic0IsNotMinusOneAndIsNotFirstStream() throws Exception {
                                                                                                  // Setup mock input stream
                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                  when(mockInputStream.read()).thenReturn(42);
                                                                                                  
                                                                                                  // Create BZip2 stream with mock input
                                                                                                  BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream, true);
                                                                                                  
                                                                                                  // Set magic0 to 0 (not -1)
                                                                                                  Field magic0Field = BZip2CompressorInputStream.class.getDeclaredField("magic0");
                                                                                                  magic0Field.setAccessible(true);
                                                                                                  magic0Field.setInt(bzip2Stream, 0);  // Use setInt for primitive int
                                                                                                  
                                                                                                  // Set isFirstStream to false
                                                                                                  Field isFirstStreamField = BZip2CompressorInputStream.class.getDeclaredField("isFirstStream");
                                                                                                  isFirstStreamField.setAccessible(true);
                                                                                                  isFirstStreamField.setBoolean(bzip2Stream, false);  // Use setBoolean for primitive boolean
                                                                                                  
                                                                                                  // The original code would not enter the if block in this case
                                                                                                  // The mutated code would enter the if block
                                                                                                  int result = bzip2Stream.read();
                                                                                                  
                                                                                                  // Original would return the read value (42)
                                                                                                  // Mutant might do something different
                                                                                                  assertEquals(42, result);
                                                                                              }

    @Test
                                                                                              public void testInitWithMagicNumberAndStreamState() throws Exception {
                                                                                                  // Create test input stream with mock data
                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                  
                                                                                                  // Case 1: magic0 is -1 and isFirstStream is true
                                                                                                  // Original should pass, mutant should throw exception
                                                                                                  when(mockInput.read()).thenReturn(66 /* 'B' */, 90 /* 'Z' */, 104 /* 'h' */, 48 /* '0' */, -1 /* magic0 */);
                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInput);
                                                                                                  assertNotNull(bzIn); // Original passes
                                                                                                  
                                                                                                  // Case 2: magic0 is not -1 and isFirstStream is false
                                                                                                  // Original should pass, mutant should throw exception
                                                                                                  reset(mockInput);
                                                                                                  when(mockInput.read()).thenReturn(66 /* 'B' */, 90 /* 'Z' */, 104 /* 'h' */, 48 /* '0' */, 0 /* magic0 */);
                                                                                                  bzIn = new BZip2CompressorInputStream(mockInput, false);
                                                                                                  assertNotNull(bzIn); // Original passes
                                                                                                  
                                                                                                  // Case 3: magic0 is -1 and isFirstStream is false
                                                                                                  // Both should throw exception
                                                                                                  reset(mockInput);
                                                                                                  when(mockInput.read()).thenReturn(66 /* 'B' */, 90 /* 'Z' */, 104 /* 'h' */, 48 /* '0' */, -1 /* magic0 */);
                                                                                                  try {
                                                                                                      bzIn = new BZip2CompressorInputStream(mockInput, false);
                                                                                                      fail("Expected IOException");
                                                                                                  } catch (IOException e) {
                                                                                                      // Expected for both original and mutant
                                                                                                  }
                                                                                                  
                                                                                                  // Case 4: magic0 is not -1 and isFirstStream is true
                                                                                                  // Both should pass
                                                                                                  reset(mockInput);
                                                                                                  when(mockInput.read()).thenReturn(66 /* 'B' */, 90 /* 'Z' */, 104 /* 'h' */, 48 /* '0' */, 0 /* magic0 */);
                                                                                                  bzIn = new BZip2CompressorInputStream(mockInput, true);
                                                                                                  assertNotNull(bzIn);
                                                                                              }

    @Test(expected = IOException.class)
                                                                                              public void testReadWithPartialMagicBytesShouldFail() throws IOException {
                                                                                                  // Create a mock input stream that returns partial correct magic bytes
                                                                                                  InputStream mockIn = mock(InputStream.class);
                                                                                                  when(mockIn.read()).thenReturn(
                                                                                                      (int) 'B',  // magic0 correct
                                                                                                      (int) 'X',  // magic1 wrong
                                                                                                      (int) 'h',  // magic2 correct
                                                                                                      -1          // EOF
                                                                                                  );
                                                                                          
                                                                                                  // Create the compressor stream with our mock input
                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockIn);
                                                                                                  
                                                                                                  // Prepare destination buffer
                                                                                                  byte[] dest = new byte[10];
                                                                                                  
                                                                                                  try {
                                                                                                      // This should throw IOException in original implementation
                                                                                                      // but would pass in mutated version
                                                                                                      stream.read(dest, 0, 10);
                                                                                                  } finally {
                                                                                                      stream.close();
                                                                                                  }
                                                                                              }

    @Test
                                                                                              public void testReadWithCorrectMagicBytesShouldPass() throws IOException {
                                                                                                  // Create a mock input stream that returns correct magic bytes
                                                                                                  InputStream mockIn = mock(InputStream.class);
                                                                                                  when(mockIn.read()).thenReturn(
                                                                                                      (int) 'B',  // magic0 correct
                                                                                                      (int) 'Z',  // magic1 correct
                                                                                                      (int) 'h',  // magic2 correct
                                                                                                      -1          // EOF
                                                                                                  );
                                                                                          
                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockIn);
                                                                                                  byte[] dest = new byte[10];
                                                                                                  
                                                                                                  try {
                                                                                                      int result = stream.read(dest, 0, 10);
                                                                                                      assertEquals(-1, result); // Should read no data after magic bytes
                                                                                                  } finally {
                                                                                                      stream.close();
                                                                                                  }
                                                                                              }

    @Test(expected = IOException.class)
                                                                                              public void testReadWithAllWrongMagicBytesShouldFail() throws IOException {
                                                                                                  // Create a mock input stream that returns all wrong magic bytes
                                                                                                  InputStream mockIn = mock(InputStream.class);
                                                                                                  when(mockIn.read()).thenReturn(
                                                                                                      (int) 'X',  // magic0 wrong
                                                                                                      (int) 'Y',  // magic1 wrong
                                                                                                      (int) 'Z',  // magic2 wrong
                                                                                                      -1          // EOF
                                                                                                  );
                                                                                          
                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockIn);
                                                                                                  byte[] dest = new byte[10];
                                                                                                  
                                                                                                  try {
                                                                                                      stream.read(dest, 0, 10);
                                                                                                  } finally {
                                                                                                      stream.close();
                                                                                                  }
                                                                                              }

    @Test(expected = IOException.class)
                                                                                         public void testReadWithInvalidFirstMagicByte() throws Exception {
                                                                                             // Create mock InputStream
                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                             
                                                                                             // Setup mock to return invalid first magic byte but others correct
                                                                                             when(mockIn.read()).thenReturn(
                                                                                                 (int) 'X',  // Not 'B' - first magic byte wrong
                                                                                                 (int) 'Z',  // Correct second magic byte
                                                                                                 (int) 'h',   // Correct third magic byte
                                                                                                 -1           // EOF
                                                                                             );
                                                                                             
                                                                                             // Create BZip2CompressorInputStream with mock
                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                             
                                                                                             // This should throw IOException because first magic byte is wrong
                                                                                             bzIn.read();
                                                                                         }

    @Test(expected = IOException.class)
                                                                                         public void testReadWithInvalidSecondMagicByte() throws Exception {
                                                                                             // Create mock InputStream
                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                             
                                                                                             // Setup mock to return invalid second magic byte but others correct
                                                                                             when(mockIn.read()).thenReturn(
                                                                                                 (int) 'B',  // Correct first magic byte
                                                                                                 (int) 'X',  // Not 'Z' - second magic byte wrong
                                                                                                 (int) 'h',  // Correct third magic byte
                                                                                                 -1          // EOF
                                                                                             );
                                                                                             
                                                                                             // Create BZip2CompressorInputStream with mock
                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                             
                                                                                             // This should throw IOException due to invalid magic bytes
                                                                                             bzIn.read();
                                                                                         }

    @Test(expected = IOException.class)
                                                                                         public void testReadWithInvalidThirdMagicByte() throws Exception {
                                                                                             // Create mock InputStream
                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                             
                                                                                             // Setup mock to return invalid third magic byte but others correct
                                                                                             when(mockIn.read()).thenReturn(
                                                                                                 (int) 'B',  // Correct first magic byte
                                                                                                 (int) 'Z',  // Correct second magic byte
                                                                                                 (int) 'X',  // Not 'h' - third magic byte wrong
                                                                                                 -1         // EOF
                                                                                             );
                                                                                             
                                                                                             // Create BZip2CompressorInputStream with mock
                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                             
                                                                                             // Attempt to read - should throw IOException due to invalid magic bytes
                                                                                             bzIn.read();
                                                                                         }

    @Test(expected = IOException.class)
                                                                                         public void testReadWithClosedStream() throws Exception {
                                                                                             BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(null);
                                                                                             bzStream.read(); // Should throw IOException
                                                                                         }

    @Test
                                                                                         public void testReadWithValidStream() throws Exception {
                                                                                             InputStream mockStream = mock(InputStream.class);
                                                                                             when(mockStream.read()).thenReturn((int)'1', 123, -1); // Block size, data, EOF
                                                                                             
                                                                                             BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockStream);
                                                                                             
                                                                                             // First read should process block size
                                                                                             // Subsequent reads should return actual data
                                                                                             assertEquals(123, bzStream.read());
                                                                                             assertEquals(-1, bzStream.read()); // EOF
                                                                                         }

    @Test
                                                                                    public void testBlockSizeCalculation2() throws Exception {
                                                                                        // Create a mock input stream with known block size character '1' (ASCII 49)
                                                                                        InputStream mockStream = mock(InputStream.class);
                                                                                        when(mockStream.read()).thenReturn((int)'1'); // Simulate reading block size
                                                                                        
                                                                                        // Create the compressor stream
                                                                                        BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockStream);
                                                                                        
                                                                                        // Use reflection to access private field blockSize100k
                                                                                        Field blockSizeField = BZip2CompressorInputStream.class.getDeclaredField("blockSize100k");
                                                                                        blockSizeField.setAccessible(true);
                                                                                        int blockSize = blockSizeField.getInt(bzStream);
                                                                                        
                                                                                        // Verify block size calculation
                                                                                        // Original: 49 - 48 = 1
                                                                                        // Mutant: 49 + 48 = 97
                                                                                        // We test that it's not the mutant value
                                                                                        assertNotEquals("Block size calculation should not use addition", 
                                                                                                        97, blockSize);
                                                                                        
                                                                                        // Verify correct calculation
                                                                                        assertEquals("Block size should be calculated by subtraction", 
                                                                                                    1, blockSize);
                                                                                        
                                                                                        // Additional test with different block size character '5' (ASCII 53)
                                                                                        InputStream mockStream2 = mock(InputStream.class);
                                                                                        when(mockStream2.read()).thenReturn((int)'5');
                                                                                        
                                                                                        BZip2CompressorInputStream bzStream2 = new BZip2CompressorInputStream(mockStream2);
                                                                                        int blockSize2 = blockSizeField.getInt(bzStream2);
                                                                                        assertNotEquals("Block size calculation should not use addition", 
                                                                                                       53 + 48, blockSize2);
                                                                                        assertEquals("Block size should be calculated by subtraction", 
                                                                                                    5, blockSize2);
                                                                                    }

    @Test
                                                                                    public void testBlockSizeCalculation3() throws Exception {
                                                                                        // Create a mock input stream with block size header '1' (ASCII 49)
                                                                                        InputStream mockIn = mock(InputStream.class);
                                                                                        when(mockIn.read()).thenReturn(
                                                                                            (int) 'B', (int) 'Z', (int) 'h', // Magic bytes as integers
                                                                                            (int) '1',                       // Block size character '1' (should become 1)
                                                                                            0, 0, 0, 0, 0, 0, 0, 0, 0        // Rest of header
                                                                                        );
                                                                                        
                                                                                        // Create the compressor stream which will parse the header
                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                        
                                                                                        // Use reflection to access private blockSize100k field
                                                                                        Field blockSizeField = BZip2CompressorInputStream.class.getDeclaredField("blockSize100k");
                                                                                        blockSizeField.setAccessible(true);
                                                                                        int blockSize = blockSizeField.getInt(bzIn);
                                                                                        
                                                                                        // Verify blockSize100k was calculated correctly
                                                                                        // Original: 49 - 48 = 1
                                                                                        // Mutant: 49 + 48 = 97 (would fail this test)
                                                                                        assertEquals(1, blockSize);
                                                                                        
                                                                                        bzIn.close();
                                                                                    }

    @Test
                                                                                public void testReadWithPartialMagicNumbersShouldFail() throws Exception {
                                                                                    // Create a mock input stream that returns partial correct magic numbers
                                                                                    InputStream mockStream = mock(InputStream.class);
                                                                                    
                                                                                    // Setup mock to return partial correct magic numbers (only first byte matches)
                                                                                    when(mockStream.read()).thenReturn(
                                                                                        0x17,  // magic0 - correct
                                                                                        0x00,   // magic1 - wrong (should be 0x72)
                                                                                        0x00,   // magic2 - wrong (should be 0x45)
                                                                                        -1      // EOF
                                                                                    );
                                                                                    
                                                                                    // Create the compressor stream
                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockStream);
                                                                                    
                                                                                    // This should throw IOException because header validation should fail
                                                                                    // The original code would fail because not all magic numbers match
                                                                                    // The mutant would pass because at least one magic number matches
                                                                                    try {
                                                                                        int result = bzIn.read();
                                                                                        fail("Should have thrown IOException for invalid header");
                                                                                    } catch (IOException e) {
                                                                                        // Expected behavior for original code
                                                                                        assertTrue(e.getMessage().contains("Not a BZIP2"));
                                                                                    }
                                                                                }

    @Test
                                                                                public void testReadWithAllWrongMagicNumbersShouldFail() throws Exception {
                                                                                    // Create a mock input stream that returns all wrong magic numbers
                                                                                    InputStream mockStream = mock(InputStream.class);
                                                                                    
                                                                                    // Setup mock to return all wrong magic numbers
                                                                                    when(mockStream.read()).thenReturn(
                                                                                        0x00,   // magic0 - wrong
                                                                                        0x00,   // magic1 - wrong
                                                                                        0x00,   // magic2 - wrong
                                                                                        -1      // EOF
                                                                                    );
                                                                                    
                                                                                    // Create the compressor stream
                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockStream);
                                                                                    
                                                                                    try {
                                                                                        int result = bzIn.read();
                                                                                        fail("Should have thrown IOException for invalid header");
                                                                                    } catch (IOException e) {
                                                                                        // Both original and mutant should fail here
                                                                                        assertTrue(e.getMessage().contains("Not a BZIP2"));
                                                                                    }
                                                                                }

    @Test
                                                                                public void testReadWithCorrectMagicNumbersShouldPass() throws Exception {
                                                                                    // Create a mock input stream that returns correct magic numbers
                                                                                    InputStream mockStream = mock(InputStream.class);
                                                                                    
                                                                                    // Setup mock to return correct BZip2 header
                                                                                    when(mockStream.read()).thenReturn(
                                                                                        0x17,   // magic0 - correct
                                                                                        0x72,   // magic1 - correct
                                                                                        0x45,   // magic2 - correct
                                                                                        -1      // EOF
                                                                                    );
                                                                                    
                                                                                    // Create the compressor stream
                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockStream);
                                                                                    
                                                                                    // Both original and mutant should pass this case
                                                                                    int result = bzIn.read();
                                                                                    assertEquals(-1, result); // Expecting EOF
                                                                                }

    @Test
                                                                                    public void testMagicNumberValidation() throws IOException {
                                                                                        // Test with all correct magic numbers (should pass)
                                                                                        byte[] correctMagic = {0x17, 0x72, 0x45, 0x00, 0x00}; // Correct header
                                                                                        InputStream correctStream = new ByteArrayInputStream(correctMagic);
                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(correctStream);
                                                                                        // Should not throw exception
                                                                                        
                                                                                        // Test with one incorrect magic number (should fail)
                                                                                        byte[] wrongMagic1 = {0x18, 0x72, 0x45, 0x00, 0x00}; // First byte wrong
                                                                                        InputStream wrongStream1 = new ByteArrayInputStream(wrongMagic1);
                                                                                        try {
                                                                                            new BZip2CompressorInputStream(wrongStream1);
                                                                                            // If we get here, the test should fail because the mutant would accept this
                                                                                            throw new AssertionError("Should have thrown IOException for invalid magic numbers");
                                                                                        } catch (IOException e) {
                                                                                            // Expected behavior
                                                                                        }
                                                                                
                                                                                        // Test with two incorrect magic numbers (should fail)
                                                                                        byte[] wrongMagic2 = {0x17, 0x73, 0x46, 0x00, 0x00}; // Last two bytes wrong
                                                                                        InputStream wrongStream2 = new ByteArrayInputStream(wrongMagic2);
                                                                                        try {
                                                                                            new BZip2CompressorInputStream(wrongStream2);
                                                                                            // If we get here, the test should fail because the mutant would accept this
                                                                                            throw new AssertionError("Should have thrown IOException for invalid magic numbers");
                                                                                        } catch (IOException e) {
                                                                                            // Expected behavior
                                                                                        }
                                                                                
                                                                                        // Test with all incorrect magic numbers (should fail)
                                                                                        byte[] wrongMagic3 = {0x10, 0x70, 0x40, 0x00, 0x00}; // All bytes wrong
                                                                                        InputStream wrongStream3 = new ByteArrayInputStream(wrongMagic3);
                                                                                        try {
                                                                                            new BZip2CompressorInputStream(wrongStream3);
                                                                                            // If we get here, the test should fail because the mutant would accept this
                                                                                            throw new AssertionError("Should have thrown IOException for invalid magic numbers");
                                                                                        } catch (IOException e) {
                                                                                            // Expected behavior
                                                                                        }
                                                                                    }

    @Test
                                                                               public void testBlockRandomisedSetting() throws Exception {
                                                                                   // Create a mock input stream
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   
                                                                                   // Create the test object with the mock stream
                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                   
                                                                                   // Use reflection to access private bsR method for mocking
                                                                                   Method bsRMethod = BZip2CompressorInputStream.class.getDeclaredMethod("bsR", int.class);
                                                                                   bsRMethod.setAccessible(true);
                                                                                   
                                                                                   // Mock bsR(1) to return 1
                                                                                   when(bsRMethod.invoke(bzIn, 1)).thenReturn(1);
                                                                                   
                                                                                   // Call a method that would trigger blockRandomised setting
                                                                                   // We'll use initBlock() since it's called during initialization
                                                                                   Method initBlockMethod = BZip2CompressorInputStream.class.getDeclaredMethod("initBlock");
                                                                                   initBlockMethod.setAccessible(true);
                                                                                   initBlockMethod.invoke(bzIn);
                                                                                   
                                                                                   // Verify blockRandomised is set correctly (should be true for original, false for mutant)
                                                                                   Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
                                                                                   blockRandomisedField.setAccessible(true);
                                                                                   boolean blockRandomised = blockRandomisedField.getBoolean(bzIn);
                                                                                   
                                                                                   assertTrue("blockRandomised should be true when bsR(1) returns 1", blockRandomised);
                                                                                   
                                                                                   // Now test with bsR(1) returning 0
                                                                                   when(bsRMethod.invoke(bzIn, 1)).thenReturn(0);
                                                                                   initBlockMethod.invoke(bzIn);
                                                                                   blockRandomised = blockRandomisedField.getBoolean(bzIn);
                                                                                   
                                                                                   assertFalse("blockRandomised should be false when bsR(1) returns 0", blockRandomised);
                                                                               }

    @Test
                                                                               public void testBlockRandomisedFlag1() throws Exception {
                                                                                   // Create a mock input stream with test data
                                                                                   byte[] testData = {0x42, 0x5A, 0x68, 0x31}; // Minimal BZ2 header
                                                                                   InputStream mockIn = new ByteArrayInputStream(testData);
                                                                                   
                                                                                   // Create the compressor stream with our mock
                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                   
                                                                                   // Use reflection to access private field for verification
                                                                                   Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
                                                                                   blockRandomisedField.setAccessible(true);
                                                                                   
                                                                                   // Mock the bsR method to return 1
                                                                                   // In original code: bsR(1) == 1 would set blockRandomised to true
                                                                                   // In mutant: bsR(1) != 1 would set it to false for same input
                                                                                   Field bsBuffField = BZip2CompressorInputStream.class.getDeclaredField("bsBuff");
                                                                                   bsBuffField.setAccessible(true);
                                                                                   bsBuffField.set(bzIn, 1); // Set bsBuff to 1 so bsR(1) returns 1
                                                                                   
                                                                                   // Trigger block initialization which sets blockRandomised
                                                                                   Method initBlockMethod = BZip2CompressorInputStream.class.getDeclaredMethod("initBlock");
                                                                                   initBlockMethod.setAccessible(true);
                                                                                   initBlockMethod.invoke(bzIn);
                                                                                   
                                                                                   // Verify blockRandomised is true (would fail for mutant)
                                                                                   assertTrue("blockRandomised should be true when bsR(1) returns 1", 
                                                                                             (boolean)blockRandomisedField.get(bzIn));
                                                                                   
                                                                                   // Now test with bsR(1) returning 0
                                                                                   bsBuffField.set(bzIn, 0);
                                                                                   initBlockMethod.invoke(bzIn);
                                                                                   
                                                                                   // Verify blockRandomised is false (would fail for mutant)
                                                                                   assertFalse("blockRandomised should be false when bsR(1) returns 0",
                                                                                              (boolean)blockRandomisedField.get(bzIn));
                                                                                   
                                                                                   // Clean up
                                                                                   bzIn.close();
                                                                               }

    @Test(expected = IOException.class)
                                                                                  public void testReadWhenStreamClosedThrowsException1() throws IOException {
                                                                                      // Create a stream with null input
                                                                                      BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                      closedStream.read();
                                                                                  }

    @Test
                                                                              public void testReadWithZeroLengthShouldReturnZeroWithoutException1() throws IOException {
                                                                                  // Arrange
                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                  byte[] dest = new byte[10];
                                                                                  int offs = 0;
                                                                                  int len = 0;  // This is the critical value that will expose the mutation
                                                                                  
                                                                                  // Act and Assert
                                                                                  // Original method should return 0 for len=0
                                                                                  // Mutated method would throw IndexOutOfBoundsException
                                                                                  int result = bzIn.read(dest, offs, len);
                                                                                  assertEquals(0, result);
                                                                                  
                                                                                  // Verify no interaction with the stream should occur for len=0
                                                                                  verify(mockInputStream, never()).read();
                                                                              }

    @Test
                                                                             public void testReadWithZeroReturnShouldCountAsOne() throws Exception {
                                                                                 // Create a mock input stream
                                                                                 InputStream mockIn = mock(InputStream.class);
                                                                                 when(mockIn.read()).thenReturn(0);
                                                                                 
                                                                                 // Create real BZip2 stream with mock input
                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockIn);
                                                                                 
                                                                                 // Use reflection to access private read0 method
                                                                                 Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                 read0Method.setAccessible(true);
                                                                                 
                                                                                 // Spy on the real stream to verify count
                                                                                 BZip2CompressorInputStream spyStream = spy(bzip2Stream);
                                                                                 when(read0Method.invoke(spyStream)).thenReturn(0);
                                                                                 
                                                                                 // Call the read method
                                                                                 int result = spyStream.read();
                                                                                 
                                                                                 // Verify the count was called with 1 (not 0 or -1)
                                                                                 // Using reflection to verify the protected count field
                                                                                 Field countField = BZip2CompressorInputStream.class.getSuperclass().getDeclaredField("count");
                                                                                 countField.setAccessible(true);
                                                                                 long countValue = (long) countField.get(spyStream);
                                                                                 assertEquals(1, countValue);
                                                                                 assertEquals(0, result);
                                                                             }

    @Test
                                                                             public void testReadWithNegativeReturnShouldCountAsNegativeOne() throws Exception {
                                                                                 // Create a mock input stream that returns EOF immediately
                                                                                 InputStream mockIn = mock(InputStream.class);
                                                                                 when(mockIn.read()).thenReturn(-1);
                                                                                 
                                                                                 // Create real BZip2 stream with our mock input
                                                                                 BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockIn);
                                                                                 
                                                                                 // Call the read method
                                                                                 int result = stream.read();
                                                                                 
                                                                                 // Verify we got EOF
                                                                                 assertEquals(-1, result);
                                                                                 
                                                                                 // Verify count was called with -1 through reflection
                                                                                 Field countField = CompressorInputStream.class.getDeclaredField("bytesRead");
                                                                                 countField.setAccessible(true);
                                                                                 long bytesRead = countField.getLong(stream);
                                                                                 
                                                                                 // Since we hit EOF immediately, bytesRead should be 0 (not incremented)
                                                                                 assertEquals(0, bytesRead);
                                                                             }

    @Test
                                                                         public void testReadWithPositiveReturnShouldCountAsOne() throws Exception {
                                                                             // Create a real stream with mock input
                                                                             InputStream mockInput = mock(InputStream.class);
                                                                             BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                             
                                                                             // Use reflection to access and modify the private read0() method
                                                                             Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                             read0Method.setAccessible(true);
                                                                             
                                                                             // Create a spy that will return 42 for read0()
                                                                             BZip2CompressorInputStream spyStream = spy(stream);
                                                                             when(read0Method.invoke(spyStream)).thenReturn(42);
                                                                             
                                                                             // Call the read method
                                                                             int result = spyStream.read();
                                                                             
                                                                             // Use reflection to verify count was called with 1
                                                                             Method countMethod = BZip2CompressorInputStream.class.getSuperclass()
                                                                                     .getDeclaredMethod("count", long.class);
                                                                             countMethod.setAccessible(true);
                                                                             
                                                                             // Verify the result and that count was updated
                                                                             assertEquals(42, result);
                                                                             
                                                                             // Reset accessibility
                                                                             read0Method.setAccessible(false);
                                                                             countMethod.setAccessible(false);
                                                                         }

    @Test
                                                                     public void testReadWithExactBufferBoundary1() throws IOException {
                                                                         // Setup
                                                                         byte[] dest = new byte[10];
                                                                         int offs = 0;
                                                                         int len = 10;  // Exactly equals dest.length
                                                                         
                                                                         // Mock the input stream to return some data
                                                                         InputStream mockIn = mock(InputStream.class);
                                                                         when(mockIn.read()).thenReturn(65); // 'A'
                                                                         
                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                         
                                                                         try {
                                                                             // This should work in original, throw in mutant
                                                                             int result = bzIn.read(dest, offs, len);
                                                                             
                                                                             // Verify original behavior (no exception)
                                                                             assertEquals(1, result); // Assuming read0 returns 65 and count increments by 1
                                                                             assertEquals(65, dest[0]);
                                                                         } catch (ArrayIndexOutOfBoundsException e) {
                                                                             // This indicates the mutant was caught
                                                                             fail("Mutant detected: threw exception when offs+len equals dest.length");
                                                                         }
                                                                     }

    @Test
                                                                     public void testReadWithBufferBoundaryPlusOne() throws IOException {
                                                                         // Setup
                                                                         byte[] dest = new byte[10];
                                                                         int offs = 0;
                                                                         int len = 11;  // Exceeds dest.length
                                                                         
                                                                         InputStream mockIn = mock(InputStream.class);
                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                         
                                                                         try {
                                                                             bzIn.read(dest, offs, len);
                                                                             fail("Should throw ArrayIndexOutOfBoundsException when offs+len > dest.length");
                                                                         } catch (ArrayIndexOutOfBoundsException e) {
                                                                             // Expected behavior for both original and mutant
                                                                         }
                                                                     }

    @Test
                                                                     public void testReadWithBufferBoundaryMinusOne() throws IOException {
                                                                         // Setup
                                                                         byte[] dest = new byte[10];
                                                                         int offs = 0;
                                                                         int len = 9;  // One less than dest.length
                                                                         
                                                                         InputStream mockIn = mock(InputStream.class);
                                                                         when(mockIn.read()).thenReturn(65); // 'A'
                                                                         
                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                         
                                                                         try {
                                                                             int result = bzIn.read(dest, offs, len);
                                                                             assertEquals(1, result); // Should work in both original and mutant
                                                                             assertEquals(65, dest[0]);
                                                                         } catch (ArrayIndexOutOfBoundsException e) {
                                                                             fail("Should not throw exception when offs+len < dest.length");
                                                                         }
                                                                     }

    @Test
                                                                     public void testReadWithExactBufferSizeShouldNotThrowException() throws IOException {
                                                                         // Setup
                                                                         byte[] dest = new byte[10];
                                                                         int offs = 0;
                                                                         int len = dest.length; // offs + len == dest.length
                                                                         
                                                                         // Mock the input stream to return some data
                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                         when(mockInputStream.read()).thenReturn(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1);
                                                                         
                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                         
                                                                         // Test - should not throw exception with original code
                                                                         // Would throw IndexOutOfBoundsException with mutated code
                                                                         int bytesRead = bzIn.read(dest, offs, len);
                                                                         
                                                                         // Verify
                                                                         assertEquals(10, bytesRead);
                                                                         for (int i = 0; i < 10; i++) {
                                                                             assertEquals((byte)(i+1), dest[i]);
                                                                         }
                                                                         
                                                                         // Cleanup
                                                                         bzIn.close();
                                                                     }

    @Test(expected = IOException.class)
                                                                    public void testReadThrowsIOExceptionWhenStreamClosed1() throws IOException {
                                                                        // Arrange
                                                                        byte[] dest = new byte[10];
                                                                        int offs = 0;
                                                                        int len = 5;
                                                                        
                                                                        // Create instance with null input stream to simulate closed stream
                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                        
                                                                        // Use reflection to force in to be null since constructor would throw if given null
                                                                        try {
                                                                            Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                            inField.setAccessible(true);
                                                                            inField.set(bzIn, null);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set in field to null via reflection");
                                                                        }
                                                                        
                                                                        // Act & Assert (should throw IOException)
                                                                        bzIn.read(dest, offs, len);
                                                                    }

    @Test
                                                                    public void testReadProceedsNormallyWhenStreamOpen() throws IOException {
                                                                        // Arrange
                                                                        byte[] dest = new byte[10];
                                                                        int offs = 0;
                                                                        int len = 5;
                                                                        InputStream mockStream = mock(InputStream.class);
                                                                        when(mockStream.read()).thenReturn(65); // return 'A'
                                                                        
                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockStream);
                                                                        
                                                                        // Act
                                                                        int result = bzIn.read(dest, offs, len);
                                                                        
                                                                        // Assert
                                                                        assertEquals(1, result); // should read one byte
                                                                        assertEquals((byte)'A', dest[0]);
                                                                        verify(mockStream, times(1)).read();
                                                                    }

    @Test(expected = IOException.class)
                                                                   public void testReadWhenStreamIsNullShouldThrowException2() throws IOException {
                                                                       // Create stream with null input (closed stream case)
                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                       // This should throw IOException
                                                                       bzip2Stream.read();
                                                                   }

    @Test
                                                                   public void testReadWhenStreamIsNotNullShouldRead() throws IOException {
                                                                       // Setup mock to return test value
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       when(mockInputStream.read()).thenReturn(42);
                                                                       
                                                                       // Create stream with valid input
                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                       
                                                                       // This should read successfully in original, but will throw exception in mutated version
                                                                       int result = bzip2Stream.read();
                                                                       
                                                                       // Verify the read operation
                                                                       assertEquals(42, result);
                                                                       verify(mockInputStream).read();
                                                                   }

    @Test(expected = IndexOutOfBoundsException.class)
                                                               public void testReadWithNegativeLengthShouldThrowException2() throws IOException {
                                                                   // Arrange
                                                                   byte[] dest = new byte[10];
                                                                   int offs = 0;
                                                                   int len = -1;  // Negative length
                                                                   
                                                                   // Mock input stream to ensure it's not null
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                   
                                                                   // Act - should throw IndexOutOfBoundsException for negative length
                                                                   bzIn.read(dest, offs, len);
                                                                   
                                                                   // Assert - handled by @Test(expected)
                                                                   // If mutant is present (len <= 0), it would return 0 instead of throwing exception
                                                                   // and this test would fail
                                                               }

    @Test
                                                               public void testReadWithZeroLengthShouldReturnZero1() throws IOException {
                                                                   // Arrange
                                                                   byte[] dest = new byte[10];
                                                                   int offs = 0;
                                                                   int len = 0;  // Zero length
                                                                   
                                                                   // Mock input stream to ensure it's not null
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                   
                                                                   // Act
                                                                   int result = bzIn.read(dest, offs, len);
                                                                   
                                                                   // Assert
                                                                   assertEquals("Zero length read should return 0", 0, result);
                                                               }

    @Test
                                                          public void testReadWithDifferentLengthValues() throws IOException {
                                                              // Create mock InputStream
                                                              InputStream mockInputStream = mock(InputStream.class);
                                                              BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                              
                                                              // Test with len = 0
                                                              when(mockInputStream.read(any(byte[].class), eq(0), eq(0))).thenReturn(0);
                                                              assertEquals(0, bzip2Stream.read(new byte[10], 0, 0));
                                                              
                                                              // Test with len > 0 (normal case)
                                                              when(mockInputStream.read(any(byte[].class), eq(0), eq(5))).thenReturn(5);
                                                              assertEquals(5, bzip2Stream.read(new byte[10], 0, 5));
                                                              
                                                              // Test with len < 0 (should throw IllegalArgumentException in original code)
                                                              try {
                                                                  bzip2Stream.read(new byte[10], 0, -1);
                                                                  fail("Expected IllegalArgumentException for negative length");
                                                              } catch (IllegalArgumentException e) {
                                                                  // Expected behavior for original code
                                                              }
                                                          }

    @Test(expected = IOException.class)
                                                      public void testReadWhenStreamClosed6() throws IOException {
                                                          InputStream nullStream = null;
                                                          BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(nullStream);
                                                          bzip2Stream.read(new byte[10], 0, 5);
                                                      }

    @Test
                                                  public void testReadBoundaryCondition() throws IOException {
                                                      // Create a mock InputStream that returns EOF (-1) after 5 bytes
                                                      InputStream mockStream = mock(InputStream.class);
                                                      when(mockStream.read()).thenReturn(1, 2, 3, 4, 5, -1);
                                                      
                                                      // Create BZip2CompressorInputStream with our mock stream
                                                      BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockStream);
                                                      
                                                      // Create a buffer with exactly 5 bytes capacity (hi = 5)
                                                      byte[] dest = new byte[5];
                                                      
                                                      // Read into the buffer - should read exactly 5 bytes
                                                      int bytesRead = bzStream.read(dest, 0, 5);
                                                      
                                                      // Verify correct behavior:
                                                      // 1. Should read exactly 5 bytes
                                                      assertEquals(5, bytesRead);
                                                      
                                                      // 2. Verify read0() was called exactly 5 times (not 6)
                                                      // This is the key assertion that will catch the mutant
                                                      // The original code stops at destOffs == hi (5)
                                                      // The mutant would try to read one more time (destOffs <= hi)
                                                      verify(mockStream, times(5)).read();
                                                      
                                                      // 3. Verify the buffer contains the expected values
                                                      assertArrayEquals(new byte[]{1, 2, 3, 4, 5}, dest);
                                                      
                                                      // 4. Verify no more interactions with the stream
                                                      verifyNoMoreInteractions(mockStream);
                                                  }

    @Test
                                             public void testReadExactBufferSizeWithoutOverflow() throws IOException {
                                                 // Setup
                                                 InputStream mockInputStream = mock(InputStream.class);
                                                 // Mock InputStream.read() to return exactly 3 bytes then EOF
                                                 when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                     .thenAnswer(invocation -> {
                                                         byte[] buf = (byte[]) invocation.getArguments()[0];
                                                         int off = (Integer) invocation.getArguments()[1];
                                                         buf[off] = 65;   // 'A'
                                                         buf[off+1] = 66; // 'B'
                                                         buf[off+2] = 67; // 'C'
                                                         return 3;
                                                     })
                                                     .thenReturn(-1); // EOF
                                                 
                                                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                 
                                                 byte[] dest = new byte[3];
                                                 int offs = 0;
                                                 int len = 3;
                                                 
                                                 // Execute
                                                 int bytesRead = bzIn.read(dest, offs, len);
                                                 
                                                 // Verify
                                                 assertEquals(3, bytesRead);
                                                 assertEquals(65, dest[0]);
                                                 assertEquals(66, dest[1]);
                                                 assertEquals(67, dest[2]);
                                                 
                                                 // This test would fail with the mutant because:
                                                 // 1. Original: stops after 3 iterations (destOffs < hi)
                                                 // 2. Mutant: would attempt 4th iteration (destOffs <= hi)
                                                 //    potentially causing ArrayIndexOutOfBoundsException
                                                 //    or incorrect byte count if the bounds check fails
                                             }

    @Test
                                         public void testReadIntoArrayIncrementsOffsetCorrectly() throws IOException {
                                             // Setup
                                             byte[] dest = new byte[10];
                                             int initialOffset = 3;
                                             int expectedOffset = initialOffset + 1;
                                             byte testByte = 0x42;
                                             
                                             // Mock the InputStream to return our test byte
                                             InputStream mockIn = mock(InputStream.class);
                                             when(mockIn.read()).thenReturn((int)testByte);
                                             
                                             // Create instance with our mock stream
                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                             
                                             // Test
                                             int bytesRead = bzIn.read(dest, initialOffset, 1);
                                             
                                             // Verify
                                             assertEquals("Should read exactly one byte", 1, bytesRead);
                                             assertEquals("Byte should be written at correct position", 
                                                         testByte, dest[initialOffset]);
                                             assertEquals("Next position should be properly incremented", 
                                                         testByte, dest[initialOffset]); // Would fail with mutant if array was corrupted
                                             // Additional verification that offset was incremented
                                             // (though we can't directly check destOffs as it's local)
                                             
                                             // Test with multiple bytes to ensure offset progression
                                             bytesRead = bzIn.read(dest, expectedOffset, 1);
                                             assertEquals("Second byte should be written at next position", 
                                                         testByte, dest[expectedOffset]);
                                         }

    @Test
                                         public void testReadIntoArrayHandlesOffsetCorrectlyWithMultipleBytes() throws IOException {
                                             // Setup
                                             byte[] dest = new byte[10];
                                             int initialOffset = 2;
                                             byte[] testBytes = {0x42, 0x43, 0x44};
                                             
                                             // Mock the InputStream to return our test bytes
                                             InputStream mockIn = mock(InputStream.class);
                                             when(mockIn.read())
                                                 .thenReturn((int)testBytes[0])
                                                 .thenReturn((int)testBytes[1])
                                                 .thenReturn((int)testBytes[2]);
                                             
                                             // Create instance with our mock stream
                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                             
                                             // Test
                                             int bytesRead = bzIn.read(dest, initialOffset, testBytes.length);
                                             
                                             // Verify
                                             assertEquals("Should read all requested bytes", testBytes.length, bytesRead);
                                             for (int i = 0; i < testBytes.length; i++) {
                                                 assertEquals("Byte " + i + " should be in correct position",
                                                             testBytes[i], dest[initialOffset + i]);
                                             }
                                         }

    @Test
                                         public void testReadMultipleBytesDetectsPostIncrementMutation() throws IOException {
                                             // Setup mock input stream that returns multiple bytes
                                             InputStream mockIn = mock(InputStream.class);
                                             when(mockIn.read()).thenReturn(65, 66, 67, -1); // Return A, B, C then EOF
                                             
                                             // Create test subject with our mock input
                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                             
                                             // Destination array with extra space to detect overwrites
                                             byte[] dest = new byte[5];
                                             int offs = 1;
                                             int len = 3;
                                             
                                             // Call the method under test
                                             int bytesRead = bzIn.read(dest, offs, len);
                                             
                                             // Verify correct number of bytes read
                                             assertEquals(3, bytesRead);
                                             
                                             // Verify bytes were placed in correct positions
                                             assertEquals(0, dest[0]); // Should remain unchanged
                                             assertEquals(65, dest[1]); // First byte at offset 1
                                             assertEquals(66, dest[2]); // Second byte at offset 2
                                             assertEquals(67, dest[3]); // Third byte at offset 3
                                             assertEquals(0, dest[4]); // Should remain unchanged
                                             
                                             // Verify mock interactions
                                             verify(mockIn, times(4)).read(); // 3 bytes + EOF check
                                         }

    @Test
                                        public void testReadWithDifferentOffsets1() throws IOException {
                                            // Setup - create a mock input stream that will return test data
                                            InputStream mockInputStream = mock(InputStream.class);
                                            when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                .thenAnswer(invocation -> {
                                                    Object[] args = invocation.getArguments();
                                                    byte[] dest = (byte[])args[0];
                                                    int destOffs = (int)args[1];
                                                    int offs = (int)args[2];
                                                    
                                                    // Original behavior would be:
                                                    // int c = (destOffs == offs) ? -1 : (destOffs - offs);
                                                    // Mutated behavior is:
                                                    // int c = (destOffs <= offs) ? -1 : (destOffs - offs);
                                                    
                                                    // So we need to test cases where destOffs < offs to detect the difference
                                                    return destOffs - offs;
                                                });
                                        
                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                            byte[] buffer = new byte[100];
                                            
                                            // Test case 1: destOffs == offs (both versions return -1)
                                            int result1 = bzIn.read(buffer, 10, 10);
                                            assertEquals(-1, result1);
                                            
                                            // Test case 2: destOffs < offs (original returns negative, mutant returns -1)
                                            int result2 = bzIn.read(buffer, 5, 10);
                                            // This assertion will fail for the mutant but pass for original
                                            assertEquals(-5, result2);
                                            
                                            // Test case 3: destOffs > offs (both return positive difference)
                                            int result3 = bzIn.read(buffer, 15, 10);
                                            assertEquals(5, result3);
                                        }

    @Test
                                        public void testReadWithPartialDataLessThanOffset() throws IOException {
                                            // Setup
                                            byte[] dest = new byte[10];
                                            int offs = 5;
                                            int len = 3;
                                            
                                            // Mock the input stream to return only 2 bytes (less than offset)
                                            InputStream mockIn = mock(InputStream.class);
                                            when(mockIn.read()).thenReturn(65, 66, -1);
                                            
                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                            
                                            // Test
                                            int result = bzIn.read(dest, offs, len);
                                            
                                            // Verify
                                            // Original should return number of bytes read (2)
                                            // Mutant would return -1 because destOffs (7) > offs (5) is false in mutant condition
                                            assertEquals("Should return number of bytes read when some data is read", 2, result);
                                            
                                            // Verify the bytes were actually written to the destination
                                            assertEquals((byte)65, dest[offs]);
                                            assertEquals((byte)66, dest[offs+1]);
                                            
                                            // Clean up
                                            bzIn.close();
                                        }

    @Test
                                           public void testReadDetectsInUseMutation2() throws IOException {
                                               // Setup mock input stream that returns specific data
                                               InputStream mockIn = mock(InputStream.class);
                                               when(mockIn.read()).thenReturn(65, 66, -1); // Returns 'A', 'B', then EOF
                                               
                                               // Create instance with mock input
                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                               
                                               // First read should return 'A' (65)
                                               int firstChar = bzIn.read();
                                               assertEquals(65, firstChar);
                                               
                                               // Second read should return 'B' (66)
                                               int secondChar = bzIn.read();
                                               assertEquals(66, secondChar);
                                               
                                               // Third read should return -1 (EOF)
                                               int eof = bzIn.read();
                                               assertEquals(-1, eof);
                                               
                                               // Verify the count was updated properly (2 reads, 1 EOF)
                                               // This would fail if the inUse mutation affected counting
                                               verify(mockIn, times(3)).read();
                                           }

    @Test(expected = IOException.class)
                                           public void testReadThrowsWhenStreamClosed1() throws IOException {
                                               // Create instance with null input stream
                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                               
                                               // Should throw IOException
                                               bzIn.read();
                                           }

    @Test
                                      public void testReadDetectsInUseMutation3() throws IOException {
                                          // Create a simple BZip2 compressed stream (hex representation of "test")
                                          byte[] compressedData = new byte[] {
                                              0x42, 0x5A, 0x68, 0x39, 0x31, 0x41, 0x59, 0x26, 
                                              0x53, 0x59, (byte)0x8D, (byte)0xC7, (byte)0xE0, 0x00, 0x00, 0x00
                                          };
                                          InputStream inputStream = new ByteArrayInputStream(compressedData);
                                          
                                          // Create compressor stream with test data
                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(inputStream);
                                          
                                          // Read decompressed data
                                          byte[] dest = new byte[4];
                                          int bytesRead = bzIn.read(dest, 0, 4);
                                          
                                          // Verify correct decompression
                                          assertEquals(4, bytesRead);
                                          assertEquals("test", new String(dest, "US-ASCII"));
                                          
                                          // The mutation would cause either:
                                          // 1. Different number of bytes read
                                          // 2. Different content in dest
                                          // 3. Possible exception if invalid characters are processed
                                          
                                          bzIn.close();
                                      }

    @Test
                                  public void testMakeMapsIncrementsCorrectly() throws Exception {
                                      // Setup
                                      BZip2CompressorInputStream stream = new BZip2CompressorInputStream(new ByteArrayInputStream(new byte[0]));
                                      
                                      // Use reflection to access private fields for testing
                                      Field nInUseField = BZip2CompressorInputStream.class.getDeclaredField("nInUse");
                                      nInUseField.setAccessible(true);
                                      Field seqToUnseqField = BZip2CompressorInputStream.class.getDeclaredField("seqToUnseq");
                                      seqToUnseqField.setAccessible(true);
                                      
                                      // Set initial state
                                      nInUseField.set(stream, 0);
                                      byte[] seqToUnseq = new byte[256];
                                      seqToUnseqField.set(stream, seqToUnseq);
                                      
                                      // Call makeMaps (private method, need to make accessible)
                                      Method makeMaps = BZip2CompressorInputStream.class.getDeclaredMethod("makeMaps");
                                      makeMaps.setAccessible(true);
                                      makeMaps.invoke(stream);
                                      
                                      // Verify post-increment behavior
                                      byte[] updatedSeqToUnseq = (byte[]) seqToUnseqField.get(stream);
                                      int updatedNInUse = (int) nInUseField.get(stream);
                                      
                                      // The mutation would fail this test because:
                                      // Original: nInUse is incremented after assignment in each iteration
                                      // Mutant: nInUse is incremented after all assignments
                                      // So we expect the array to have values at correct positions
                                      for (int i = 0; i < updatedNInUse; i++) {
                                          assertEquals("Array value at position " + i + " should match", (byte)i, updatedSeqToUnseq[i]);
                                      }
                                      assertEquals("nInUse should equal array length", updatedNInUse, updatedSeqToUnseq.length);
                                  }

    @Test
                                 public void testReadWithSequenceMapping1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                     // Setup mock input stream that will return test data
                                     InputStream mockInputStream = mock(InputStream.class);
                                     when(mockInputStream.read()).thenReturn(1, 2, 3, -1); // Return three values then EOF
                                     
                                     // Create compressor stream with mock input
                                     BZip2CompressorInputStream compressor = new BZip2CompressorInputStream(mockInputStream);
                                     
                                     // First read - should map to position 0
                                     int firstRead = compressor.read();
                                     assertEquals(1, firstRead);
                                     
                                     // Verify internal state after first read
                                     Field seqToUnseqField = BZip2CompressorInputStream.class.getDeclaredField("seqToUnseq");
                                     seqToUnseqField.setAccessible(true);
                                     byte[] seqToUnseq = (byte[]) seqToUnseqField.get(compressor);
                                     assertEquals(1, seqToUnseq[0]); // Should be mapped to first position
                                     
                                     Field nInUseShadowField = BZip2CompressorInputStream.class.getDeclaredField("nInUseShadow");
                                     nInUseShadowField.setAccessible(true);
                                     int nInUseShadow = nInUseShadowField.getInt(compressor);
                                     assertEquals(1, nInUseShadow); // Counter should have incremented
                                     
                                     // Second read - should map to position 1
                                     int secondRead = compressor.read();
                                     assertEquals(2, secondRead);
                                     assertEquals(2, seqToUnseq[1]); // Should be mapped to second position
                                     assertEquals(2, nInUseShadowField.getInt(compressor)); // Counter should be 2
                                     
                                     // Third read - should map to position 2
                                     int thirdRead = compressor.read();
                                     assertEquals(3, thirdRead);
                                     assertEquals(3, seqToUnseq[2]); // Should be mapped to third position
                                     assertEquals(3, nInUseShadowField.getInt(compressor)); // Counter should be 3
                                     
                                     // EOF read
                                     int eofRead = compressor.read();
                                     assertEquals(-1, eofRead);
                                     
                                     // Verify the mutation would fail here - with the mutation, the counter might not increment properly
                                     // between assignments, causing subsequent reads to overwrite previous positions
                                 }

    @Test
                             public void testReadReturnsNegativeOneWhenNoBytesRead1() throws Exception {
                                 // Arrange
                                 byte[] dest = new byte[10];
                                 int offs = 0;
                                 int len = 5;
                                 
                                 // Mock the input stream to return EOF immediately
                                 InputStream mockInputStream = mock(InputStream.class);
                                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                 
                                 // Use reflection to inject our mock read0() behavior that returns -1 (EOF)
                                 Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                 inField.setAccessible(true);
                                 inField.set(bzIn, mockInputStream);
                                 
                                 // Mock read0() to return -1 (EOF) immediately
                                 when(mockInputStream.read()).thenReturn(-1);
                                 
                                 // Act
                                 int result = bzIn.read(dest, offs, len);
                                 
                                 // Assert
                                 assertEquals("Should return -1 when no bytes are read", -1, result);
                             }

    @Test
                            public void testReadReturnsNegativeOneOnEOF3() throws Exception {
                                // Create a mock InputStream that returns -1 on read (EOF)
                                InputStream mockInputStream = mock(InputStream.class);
                                when(mockInputStream.read()).thenReturn(-1);
                                
                                // Create the test object with the mock stream
                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                
                                // Call read() and verify it returns -1 (EOF)
                                int result = bzIn.read();
                                
                                // Verify the correct EOF indicator is returned
                                assertEquals("Should return -1 on EOF", -1, result);
                                
                                // Verify count was updated properly (should be -1)
                                // Note: If count() is a method that needs verification, we would need to:
                                // 1. Make it accessible via reflection if it's private
                                // 2. Verify its value
                                // But since the implementation isn't shown, we'll skip this part
                            }

    @Test(expected = IllegalStateException.class)
                        public void testReadWhenStreamClosedThrowsException2() throws IOException {
                            // Arrange
                            byte[] dest = new byte[10];
                            int offs = 0;
                            int len = 5;
                            
                            // Create stream with null input to simulate closed stream
                            BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                            
                            // Act & Assert
                            // Should throw IllegalStateException for original behavior
                            // Will return -1 for mutant behavior (which would make test fail)
                            stream.read(dest, offs, len);
                        }

    @Test(expected = IOException.class)
                       public void testReadThrowsExceptionWhenStreamClosed1() throws IOException {
                           // Create a BZip2CompressorInputStream with null input to trigger the exception
                           InputStream nullInput = null;
                           BZip2CompressorInputStream streamWithNullInput = new BZip2CompressorInputStream(nullInput);
                           
                           // This should throw IOException with message "stream closed"
                           streamWithNullInput.read();
                       }

    @Test
                   public void testReadThrowsCorrectExceptionMessageWhenStreamClosed() throws IOException {
                       BZip2CompressorInputStream streamWithNullInput = new BZip2CompressorInputStream(null);
                       try {
                           streamWithNullInput.read();
                           fail("Expected IOException to be thrown");
                       } catch (IOException e) {
                           assertEquals("stream closed", e.getMessage());
                       }
                   }

    @Test
                   public void testMagicNumberValidation1() throws IOException {
                       // Test case where one magic byte is wrong (should fail)
                       InputStream mockStream1 = mock(InputStream.class);
                       when(mockStream1.read()).thenReturn((int)'B', (int)'X', (int)'h'); // Second byte wrong
                       
                       try {
                           new BZip2CompressorInputStream(mockStream1);
                           fail("Should throw IOException for invalid magic bytes");
                       } catch (IOException e) {
                           assertTrue(e.getMessage().contains("Not a BZIP2 stream"));
                       }
               
                       // Test case where two magic bytes are wrong (should fail)
                       InputStream mockStream2 = mock(InputStream.class);
                       when(mockStream2.read()).thenReturn((int)'X', (int)'Y', (int)'h'); // First two bytes wrong
                       
                       try {
                           new BZip2CompressorInputStream(mockStream2);
                           fail("Should throw IOException for invalid magic bytes");
                       } catch (IOException e) {
                           assertTrue(e.getMessage().contains("Not a BZIP2 stream"));
                       }
               
                       // Test case where all magic bytes are correct (should pass)
                       InputStream mockStream3 = mock(InputStream.class);
                       when(mockStream3.read()).thenReturn((int)'B', (int)'Z', (int)'h'); // All correct
                       
                       // Should not throw exception
                       new BZip2CompressorInputStream(mockStream3);
               
                       // Test case where all magic bytes are wrong (should fail)
                       InputStream mockStream4 = mock(InputStream.class);
                       when(mockStream4.read()).thenReturn((int)'X', (int)'Y', (int)'Z'); // All wrong
                       
                       try {
                           new BZip2CompressorInputStream(mockStream4);
                           fail("Should throw IOException for invalid magic bytes");
                       } catch (IOException e) {
                           assertTrue(e.getMessage().contains("Not a BZIP2 stream"));
                       }
                   }

    @Test(expected = IOException.class)
              public void testReadWithInvalidHeaderSomeCorrectBytes() throws Exception {
                  // Setup mock InputStream
                  InputStream mockIn = mock(InputStream.class);
                  
                  // Setup mock to return some correct magic bytes
                  when(mockIn.read()).thenReturn(
                      (int)'X',  // First byte wrong (should be 'B')
                      (int)'Z',  // Second byte correct
                      (int)'h',  // Third byte correct
                      -1         // EOF
                  );
                  
                  // Create BZip2 stream which should detect invalid header
                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                  
                  // This should throw IOException because some magic bytes are wrong
                  bzIn.read();
              }

    @Test(expected = IOException.class)
              public void testReadWithInvalidHeaderAllWrongBytes() throws Exception {
                  // Setup mock InputStream
                  InputStream mockIn = mock(InputStream.class);
                  
                  // Setup mock to return all wrong magic bytes
                  when(mockIn.read()).thenReturn(
                      (int)'X',  // First byte wrong
                      (int)'Y',  // Second byte wrong
                      (int)'Z',  // Third byte wrong
                      -1         // EOF
                  );
                  
                  // Create BZip2 stream which should fail due to invalid header
                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                  
                  // This should throw IOException due to invalid header
                  bzIn.read();
              }

    @Test
              public void testReadWithValidHeader() throws Exception {
                  // Setup mock InputStream
                  InputStream mockIn = mock(InputStream.class);
                  
                  // Setup mock to return correct magic bytes
                  when(mockIn.read()).thenReturn(
                      (int)'B',  // First byte correct
                      (int)'Z',  // Second byte correct
                      (int)'h',  // Third byte correct
                      -1         // EOF
                  );
                  
                  // Create BZip2 stream with mock input
                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                  
                  // This should pass (both original and mutant would pass)
                  int result = bzIn.read();
                  assertEquals(-1, result); // Expecting EOF
              }

    @Test
              public void testBlockSizeInitialization() throws Exception {
                  // Prepare test data with different block sizes
                  char[] testBlockSizes = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
                  
                  for (char blockSize : testBlockSizes) {
                      // Create mock input stream with block size marker
                      InputStream mockStream = mock(InputStream.class);
                      
                      // Create instance with the mock stream
                      BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockStream);
                      
                      // Use reflection to access private field for verification
                      Field blockSizeField = BZip2CompressorInputStream.class.getDeclaredField("blockSize100k");
                      blockSizeField.setAccessible(true);
                      int actualBlockSize = blockSizeField.getInt(bzStream);
                      
                      // Calculate expected value (original behavior: blockSize - '0')
                      int expectedBlockSize = blockSize - '0';
                      
                      // Verify the block size was set correctly
                      assertEquals("Block size initialization failed for input " + blockSize, 
                                  expectedBlockSize, actualBlockSize);
                  }
              }

    @Test
         public void testBlockSizeInitialization1() throws Exception {
             // Create a mock input stream with a test block size (ASCII '1' = 49)
             InputStream mockStream = mock(InputStream.class);
             when(mockStream.read()).thenReturn((int)'1'); // Simulate reading block size '1'
             
             // Create the compressor with our mock stream
             BZip2CompressorInputStream compressor = new BZip2CompressorInputStream(mockStream);
             
             // Use reflection to access private fields
             Field blockSizeField = BZip2CompressorInputStream.class.getDeclaredField("blockSize100k");
             blockSizeField.setAccessible(true);
             int blockSize = blockSizeField.getInt(compressor);
             
             Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
             inField.setAccessible(true);
             InputStream in = (InputStream) inField.get(compressor);
             
             Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
             blockRandomisedField.setAccessible(true);
             boolean blockRandomised = blockRandomisedField.getBoolean(compressor);
             
             // Verify the block size calculation
             assertEquals("Block size should be correctly calculated", 1, blockSize);
             
             // Additional verification that the stream is properly initialized
             assertNotNull("Input stream should be set", in);
             assertFalse("Block should not be randomized initially", blockRandomised);
         }

    @Test
     public void testBlockRandomisedFlag2() throws Exception {
         // Create a mock input stream
         InputStream mockIn = mock(InputStream.class);
         
         // Create the compressor stream with decompressConcatenated=true
         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn, true);
         
         try {
             // Use reflection to access private bsR method for mocking
             Method bsRMethod = BZip2CompressorInputStream.class.getDeclaredMethod("bsR", int.class);
             bsRMethod.setAccessible(true);
             
             // Test case 1: bsR returns 1
             when(bsRMethod.invoke(bzIn, 1)).thenReturn(1);
             Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
             blockRandomisedField.setAccessible(true);
             
             // Trigger initialization that sets blockRandomised
             Method initMethod = BZip2CompressorInputStream.class.getDeclaredMethod("init", boolean.class);
             initMethod.setAccessible(true);
             initMethod.invoke(bzIn, true);
             
             // Verify blockRandomised is true (original) or false (mutant)
             assertTrue("blockRandomised should be true when bsR returns 1", 
                       blockRandomisedField.getBoolean(bzIn));
             
             // Test case 2: bsR returns 0
             when(bsRMethod.invoke(bzIn, 1)).thenReturn(0);
             initMethod.invoke(bzIn, true);
             assertFalse("blockRandomised should be false when bsR returns 0", 
                        blockRandomisedField.getBoolean(bzIn));
         } finally {
             bzIn.close();
         }
     }

    @Test
    public void testBlockRandomisedInitialization() throws Exception {
        // Create mock input stream
        InputStream mockInputStream = mock(InputStream.class);
        
        // Create the compressor stream with mocked dependencies
        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
        
        // Use reflection to access private bsR method for mocking
        Method bsRMethod = BZip2CompressorInputStream.class.getDeclaredMethod("bsR", int.class);
        bsRMethod.setAccessible(true);
        
        // Use reflection to access private init method
        Method initMethod = BZip2CompressorInputStream.class.getDeclaredMethod("init", boolean.class);
        initMethod.setAccessible(true);
        
        // Helper method to get private field
        Field blockRandomisedField = BZip2CompressorInputStream.class.getDeclaredField("blockRandomised");
        blockRandomisedField.setAccessible(true);
        
        // Test case 1: When bsR(1) returns 1
        when(bsRMethod.invoke(bzIn, 1)).thenReturn(1);
        initMethod.invoke(bzIn, true);
        assertTrue("blockRandomised should be true when bsR(1) returns 1", 
            (boolean) blockRandomisedField.get(bzIn));
        
        // Test case 2: When bsR(1) returns 0
        when(bsRMethod.invoke(bzIn, 1)).thenReturn(0);
        initMethod.invoke(bzIn, true);
        assertFalse("blockRandomised should be false when bsR(1) returns 0", 
            (boolean) blockRandomisedField.get(bzIn));
    }


}
