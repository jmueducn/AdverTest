package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                     public void testParseOctal_ValidInput() {
                                                         byte[] buffer = {' ', '1', '2', '3', ' ', '4', '5', ' ', ' '};
                                                         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                         assertEquals(83L, result); // 123 in octal is 83 in decimal
                                                     }

 @Test
                                                     public void testParseOctal_LeadingZeroReturnsZero() {
                                                         byte[] buffer = {'0', '1', '2', '3'};
                                                         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                         assertEquals(0L, result);
                                                     }

 @Test
                                                     public void testParseOctal_LeadingAndTrailingSpaces() {
                                                         byte[] buffer = {' ', ' ', '7', '5', ' ', ' ', ' '};
                                                         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                         assertEquals(61L, result); // 75 in octal is 61 in decimal
                                                     }

 @Test
                                                     public void testParseOctal_TrailingNulls() {
                                                         byte[] buffer = {'1', '2', '3', 0, 0, 0};
                                                         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                         assertEquals(83L, result); // 123 in octal is 83 in decimal
                                                     }

 @Test
                                                     public void testParseOctal_MaxValidOctalDigits() {
                                                         byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                         assertEquals(8589934591L, result); // 77777777777 in octal
                                                     }

 @Test
                                                     public void testParseOctal_OffsetAndLength() {
                                                         byte[] buffer = {'0', '0', '1', '2', '3', '4', '0', '0'};
                                                         long result = TarUtils.parseOctal(buffer, 2, 4);
                                                         assertEquals(668L, result); // 1234 in octal is 668 in decimal
                                                     }

 @Test
                                                     public void testParseOctal_EmptyAfterTrimming() {
                                                         byte[] buffer = {' ', ' ', ' '};
                                                         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                                         assertEquals(0L, result);
                                                     }

 @Test
                                                     public void testParseOctal_InvalidDigitThrowsException() {
                                                         byte[] buffer = {'1', '2', '8', '4'}; // '8' is invalid in octal
                                                         thrown.expect(IllegalArgumentException.class);
                                                         TarUtils.parseOctal(buffer, 0, buffer.length);
                                                     }

 @Test
                                                     public void testParseOctal_LengthLessThanTwoThrowsException() {
                                                         byte[] buffer = {'1'};
                                                         thrown.expect(IllegalArgumentException.class);
                                                         thrown.expectMessage("Length 1 must be at least 2");
                                                         TarUtils.parseOctal(buffer, 0, buffer.length);
                                                     }

 @Test
                                                     public void testParseOctal_NullBufferThrowsException() {
                                                         thrown.expect(NullPointerException.class);
                                                         TarUtils.parseOctal(null, 0, 2);
                                                     }

 @Test
                                                     public void testParseOctal_InvalidOffsetThrowsException() {
                                                         byte[] buffer = {'1', '2', '3'};
                                                         thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                         TarUtils.parseOctal(buffer, -1, 2);
                                                     }

 @Test
                                                     public void testParseOctal_InvalidLengthThrowsException() {
                                                         byte[] buffer = {'1', '2', '3'};
                                                         thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                         TarUtils.parseOctal(buffer, 0, 4); // length exceeds buffer size
                                                     }

 @Test
         public void testParseOctalWithBoundaryDigits() {
             // Test with '0' which should be valid but mutant would reject
             byte[] input1 = {' ', '0', '1', ' '};
             long result1 = TarUtils.parseOctal(input1, 0, 4);
             assertEquals(1L, result1);  // '01' in octal is 1
             
             // Test with '7' which should be valid but mutant would reject
             byte[] input2 = {'7', '0', ' '};
             long result2 = TarUtils.parseOctal(input2, 0, 3);
             assertEquals(7L, result2);  // '70' in octal is 56, but trimmed to '7' which is 7
             
             // Test with invalid digit '8' which both should reject
             byte[] input3 = {'1', '8', ' '};
             try {
                 TarUtils.parseOctal(input3, 0, 3);
                 fail("Should throw IllegalArgumentException for invalid digit '8'");
             } catch (IllegalArgumentException e) {
                 // expected
             }
             
             // Test with invalid byte '/' (ASCII 47) which both should reject
             byte[] input4 = {'/', '1', ' '};
             try {
                 TarUtils.parseOctal(input4, 0, 3);
                 fail("Should throw IllegalArgumentException for invalid byte '/'");
             } catch (IllegalArgumentException e) {
                 // expected
             }
         }

 @Test
        public void testParseOctalThrowsIllegalArgumentExceptionForInvalidDigits() {
            // Prepare test data with invalid octal digit (byte value '8' which is > '7')
            byte[] buffer = {' ', '1', '2', '8', ' '}; // Contains invalid digit '8'
            int offset = 0;
            int length = buffer.length;
    
            // Expect IllegalArgumentException to be thrown
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("Invalid byte 8 at offset 3");
    
            // Call the method that should throw
            TarUtils.parseOctal(buffer, offset, length);
        }

 @Test
        public void testParseOctalThrowsIllegalArgumentExceptionForDigitBelowZero() {
            // Prepare test data with invalid octal digit (byte value '/' which is < '0')
            byte[] buffer = {' ', '1', '2', '/', ' '}; // Contains invalid digit '/'
            int offset = 0;
            int length = buffer.length;
    
            // Expect IllegalArgumentException to be thrown
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("Invalid byte 47 at offset 3"); // 47 is ASCII for '/'
    
            // Call the method that should throw
            TarUtils.parseOctal(buffer, offset, length);
        }

 @Test(expected = IllegalArgumentException.class)
   public void testParseOctal_InvalidDigits_ThrowsIllegalArgumentException() {
       // Arrange
       byte[] buffer = {
           ' ', ' ', '1', '2', '8', ' '  // '8' is invalid in octal
       };
       int offset = 0;
       int length = buffer.length;
       
       // Act & Assert
       TarUtils.parseOctal(buffer, offset, length);
       
       // The test will pass if IllegalArgumentException is thrown
       // The mutant would throw NullPointerException instead, causing test failure
   }

 @Test
  public void testParseOctalWithLeadingZeroReturnsZero() {
      // Arrange
      byte[] buffer = {0, '1', '2', '3'}; // First byte is 0
      int offset = 0;
      int length = 4; // Length >= 2
      
      // Act
      long result = TarUtils.parseOctal(buffer, offset, length);
      
      // Assert
      assertEquals("Method should return 0 when first byte is 0", 0L, result);
  }

 @Test
 public void testParseOctalWithLeadingZero() {
     // Arrange
     byte[] buffer = {0, '1', '2', '3'}; // Buffer starts with 0
     int offset = 0;
     int length = 4;
     
     // Act
     long result = TarUtils.parseOctal(buffer, offset, length);
     
     // Assert
     assertEquals("Method should return 0 when buffer starts with 0", 0L, result);
 }

}
