package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.archivers.zip.ZipConstants.DATA_DESCRIPTOR_MIN_VERSION;
import org.apache.commons.compress.archivers.zip.ZipConstants.DEFLATE_MIN_VERSION;
import org.apache.commons.compress.archivers.zip.ZipConstants.DWORD;
import org.apache.commons.compress.archivers.zip.ZipConstants.INITIAL_VERSION;
import org.apache.commons.compress.archivers.zip.ZipConstants.SHORT;
import org.apache.commons.compress.archivers.zip.ZipConstants.WORD;
import org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MAGIC;
import org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MAGIC_SHORT;
import org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MIN_VERSION;
import org.apache.commons.compress.archivers.zip.ZipLong.putLong;
import org.apache.commons.compress.archivers.zip.ZipShort.putShort;
 
public class ZipArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                     public void testWriteLocalFileHeader_PhasedEntry() throws Exception {
                                                                         // Setup
                                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                         ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                         
                                                                         // Need to use reflection to test private method
                                                                         Method writeLocalFileHeader = ZipArchiveOutputStream.class
                                                                             .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                         writeLocalFileHeader.setAccessible(true);
                                                                         
                                                                         // Execute phased write
                                                                         writeLocalFileHeader.invoke(zos, entry, true);
                                                                         
                                                                         // Verify
                                                                         // Need reflection to access private metaData field
                                                                         Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                                                         metaDataField.setAccessible(true);
                                                                         @SuppressWarnings("unchecked")
                                                                         Map<ZipArchiveEntry, ?> metaData = (Map<ZipArchiveEntry, ?>) metaDataField.get(zos);
                                                                         Object metaDataValue = metaData.get(entry);
                                                                         assertNotNull(metaDataValue);
                                                                         
                                                                         // Need reflection to check usesDataDescriptor
                                                                         Method usesDataDescriptor = metaDataValue.getClass().getDeclaredMethod("usesDataDescriptor");
                                                                         usesDataDescriptor.setAccessible(true);
                                                                         boolean result = (boolean) usesDataDescriptor.invoke(metaDataValue);
                                                                         assertTrue(result);
                                                                     }

    @Test
                                                                     public void testCreateLocalFileHeader_PhasedEntry() throws Exception {
                                                                         // Setup
                                                                         ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                         ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                         ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                         
                                                                         when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                         // Use reflection to set alignment since getAlignment() is protected
                                                                         Method setAlignment = ZipArchiveEntry.class.getDeclaredMethod("setAlignment", int.class);
                                                                         setAlignment.setAccessible(true);
                                                                         setAlignment.invoke(entry, 0);
                                                                         
                                                                         when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                         when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                         when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                         when(entry.getCrc()).thenReturn(12345L);
                                                                         when(entry.getCompressedSize()).thenReturn(100L);
                                                                         when(entry.getSize()).thenReturn(200L);
                                                                         
                                                                         // Use reflection to call private createLocalFileHeader method
                                                                         Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                             "createLocalFileHeader", 
                                                                             ZipArchiveEntry.class, 
                                                                             ByteBuffer.class, 
                                                                             boolean.class, 
                                                                             boolean.class, 
                                                                             long.class
                                                                         );
                                                                         createLocalFileHeader.setAccessible(true);
                                                                         byte[] result = (byte[]) createLocalFileHeader.invoke(zos, entry, name, true, true, 0L);
                                                                         
                                                                         // Verify
                                                                         assertNotNull(result);
                                                                         // Get private LFH_CRC_OFFSET field via reflection
                                                                         Field crcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                         crcOffsetField.setAccessible(true);
                                                                         int crcOffset = crcOffsetField.getInt(zos);
                                                                         
                                                                         // Verify CRC is written (not zeroed out)
                                                                         assertNotEquals(0, result[crcOffset]);
                                                                         assertNotEquals(0, result[crcOffset + 1]);
                                                                         assertNotEquals(0, result[crcOffset + 2]);
                                                                         assertNotEquals(0, result[crcOffset + 3]);
                                                                     }

    @Test
                                                                 public void testCreateLocalFileHeader_WithNonEncodableName() throws Exception {
                                                                     // Setup
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                     ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                     
                                                                     // Mock entry methods
                                                                     when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                     
                                                                     // Use reflection to set alignment since it's protected
                                                                     Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                                     getAlignmentMethod.setAccessible(true);
                                                                     when(getAlignmentMethod.invoke(entry)).thenReturn(0);
                                                                     
                                                                     when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                     when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                     when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                     when(entry.getCrc()).thenReturn(12345L);
                                                                     when(entry.getCompressedSize()).thenReturn(100L);
                                                                     when(entry.getSize()).thenReturn(100L);
                                                                     
                                                                     // Use reflection to access private createLocalFileHeader method
                                                                     Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "createLocalFileHeader", 
                                                                         ZipArchiveEntry.class, 
                                                                         ByteBuffer.class, 
                                                                         boolean.class, 
                                                                         boolean.class, 
                                                                         long.class);
                                                                     createLocalFileHeaderMethod.setAccessible(true);
                                                                     
                                                                     // Execute with encodable=false
                                                                     byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                         zos, 
                                                                         entry, 
                                                                         name, 
                                                                         false, 
                                                                         false, 
                                                                         0L);
                                                                     
                                                                     // Verify
                                                                     assertNotNull(result);
                                                                     
                                                                     // Use reflection to access private LFH_GPB_OFFSET constant
                                                                     Field lfhGpbOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_GPB_OFFSET");
                                                                     lfhGpbOffsetField.setAccessible(true);
                                                                     int lfhGpbOffset = lfhGpbOffsetField.getInt(zos);
                                                                     
                                                                     // Verify general purpose bit is set for UTF-8
                                                                     int gpb = (result[lfhGpbOffset] & 0xff) + 
                                                                              ((result[lfhGpbOffset + 1] & 0xff) << 8);
                                                                     assertTrue((gpb & GeneralPurposeBit.UFT8_NAMES_FLAG) != 0);
                                                                 }

    @Test
                                                                 public void testCreateLocalFileHeader_WithChannelAndDeflated() throws Exception {
                                                                     // Setup
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(SeekableByteChannel.class));
                                                                     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                     ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                     
                                                                     when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                     when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                     when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                     when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                     when(entry.getCrc()).thenReturn(0L); // Should be zeroed out
                                                                     when(entry.getCompressedSize()).thenReturn(0L); // Should be zeroed out
                                                                     when(entry.getSize()).thenReturn(0L); // Should be zeroed out
                                                                     
                                                                     // Mock protected getAlignment() method
                                                                     Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                                     getAlignmentMethod.setAccessible(true);
                                                                     when(getAlignmentMethod.invoke(entry)).thenReturn(0);
                                                                     
                                                                     // Get private createLocalFileHeader method via reflection
                                                                     Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "createLocalFileHeader", 
                                                                         ZipArchiveEntry.class, 
                                                                         ByteBuffer.class, 
                                                                         boolean.class, 
                                                                         boolean.class, 
                                                                         long.class
                                                                     );
                                                                     createLocalFileHeaderMethod.setAccessible(true);
                                                                     
                                                                     // Execute
                                                                     byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                         zos, 
                                                                         entry, 
                                                                         name, 
                                                                         true, 
                                                                         false, 
                                                                         0L
                                                                     );
                                                                     
                                                                     // Verify
                                                                     assertNotNull(result);
                                                                     
                                                                     // Get private offset constants via reflection
                                                                     Field crcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                     crcOffsetField.setAccessible(true);
                                                                     int crcOffset = crcOffsetField.getInt(zos);
                                                                     
                                                                     Field sizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                     sizeOffsetField.setAccessible(true);
                                                                     int sizeOffset = sizeOffsetField.getInt(zos);
                                                                     
                                                                     // Verify CRC is zeroed out
                                                                     for (int i = 0; i < 4; i++) {
                                                                         assertEquals(0, result[crcOffset + i]);
                                                                     }
                                                                     
                                                                     // Verify sizes are zeroed out
                                                                     for (int i = 0; i < 4; i++) {
                                                                         assertEquals(0, result[sizeOffset + i]);
                                                                     }
                                                                 }

    @Test
                                                                 public void testWriteDataDescriptor_NoDataDescriptorNeeded() throws Exception {
                                                                     // Setup
                                                                     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                     when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                     
                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                     
                                                                     // Get the protected method via reflection
                                                                     Method writeDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "writeDataDescriptor", ZipArchiveEntry.class);
                                                                     writeDataDescriptorMethod.setAccessible(true);
                                                                     
                                                                     // Action
                                                                     writeDataDescriptorMethod.invoke(zos, entry);
                                                                     
                                                                     // Verify nothing was written
                                                                     assertEquals(0, baos.size());
                                                                 }

    @Test
                                                                 public void testWriteDataDescriptor_RegularSize() throws Exception {
                                                                     // Setup
                                                                     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                     when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                     when(entry.getCrc()).thenReturn(0x12345678L);
                                                                     when(entry.getCompressedSize()).thenReturn(1000L);
                                                                     when(entry.getSize()).thenReturn(2000L);
                                                                     when(entry.getExtraFields()).thenReturn(new ZipExtraField[0]);
                                                                     
                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "writeDataDescriptor", ZipArchiveEntry.class);
                                                                     writeDataDescriptor.setAccessible(true);
                                                                     
                                                                     // Action
                                                                     writeDataDescriptor.invoke(zos, entry);
                                                                     
                                                                     // Verify
                                                                     byte[] result = baos.toByteArray();
                                                                     assertEquals(16, result.length); // 4 (signature) + 4 (CRC) + 4 (compressed) + 4 (size)
                                                                     
                                                                     // Verify signature
                                                                     assertEquals(0x50, result[0] & 0xFF);
                                                                     assertEquals(0x4b, result[1] & 0xFF);
                                                                     assertEquals(0x07, result[2] & 0xFF);
                                                                     assertEquals(0x08, result[3] & 0xFF);
                                                                     
                                                                     // Verify CRC (little endian)
                                                                     assertEquals(0x78, result[4] & 0xFF);
                                                                     assertEquals(0x56, result[5] & 0xFF);
                                                                     assertEquals(0x34, result[6] & 0xFF);
                                                                     assertEquals(0x12, result[7] & 0xFF);
                                                                     
                                                                     // Verify compressed size
                                                                     assertEquals(0xE8, result[8] & 0xFF);
                                                                     assertEquals(0x03, result[9] & 0xFF);
                                                                     assertEquals(0x00, result[10] & 0xFF);
                                                                     assertEquals(0x00, result[11] & 0xFF);
                                                                     
                                                                     // Verify size
                                                                     assertEquals(0xD0, result[12] & 0xFF);
                                                                     assertEquals(0x07, result[13] & 0xFF);
                                                                     assertEquals(0x00, result[14] & 0xFF);
                                                                     assertEquals(0x00, result[15] & 0xFF);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtract_WhenUsedDataDescriptorIsTrue_ReturnsDataDescriptorMinVersion() throws Exception {
                                                                     // Arrange
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                     int zipMethod = ZipArchiveOutputStream.DEFLATED; // arbitrary method
                                                                     boolean zip64 = false;
                                                                     boolean usedDataDescriptor = true;
                                                                     
                                                                     // Get the private method using reflection
                                                                     Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                     versionNeededToExtractMethod.setAccessible(true);
                                                                     
                                                                     // Act
                                                                     int result = (int) versionNeededToExtractMethod.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                     
                                                                     // Assert
                                                                     Field dataDescriptorMinVersionField = ZipArchiveOutputStream.class.getDeclaredField("DATA_DESCRIPTOR_MIN_VERSION");
                                                                     dataDescriptorMinVersionField.setAccessible(true);
                                                                     int expectedVersion = (int) dataDescriptorMinVersionField.get(null);
                                                                     
                                                                     assertEquals(expectedVersion, result);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtract_WhenZip64AndDataDescriptorBothTrue_PrioritizesZip() throws Exception {
                                                                     // Arrange
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                     int zipMethod = ZipArchiveOutputStream.DEFLATED; // arbitrary method
                                                                     boolean zip64 = true;
                                                                     boolean usedDataDescriptor = true;
                                                                     
                                                                     // Get private method via reflection
                                                                     Method versionNeededMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                     versionNeededMethod.setAccessible(true);
                                                                     
                                                                     // Get ZIP64_MIN_VERSION constant via reflection
                                                                     Field zip64MinVersionField = ZipArchiveOutputStream.class.getDeclaredField("ZIP64_MIN_VERSION");
                                                                     zip64MinVersionField.setAccessible(true);
                                                                     int expectedVersion = zip64MinVersionField.getInt(zos);
                                                                     
                                                                     // Act
                                                                     int result = (int) versionNeededMethod.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                     
                                                                     // Assert
                                                                     assertEquals(expectedVersion, result);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtract_WithDefaultCompression_ReturnsCorrectVersion() throws Exception {
                                                                     // Arrange
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                     int zipMethod = ZipArchiveOutputStream.DEFLATED;
                                                                     boolean zip64 = false;
                                                                     boolean usedDataDescriptor = false;
                                                                     
                                                                     // Get the private method using reflection
                                                                     Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                     versionMethod.setAccessible(true);
                                                                     
                                                                     // Act
                                                                     int result = (int) versionMethod.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                     
                                                                     // Assert
                                                                     // For DEFLATED compression, the expected version should be 20
                                                                     assertEquals(20, result);
                                                                 }

    @Test
                                                                 public void testUsesDataDescriptor_AllConditionsTrue() throws Exception {
                                                                     // Create mock OutputStream
                                                                     OutputStream mockOutputStream = new ByteArrayOutputStream();
                                                                     
                                                                     // Create instance with OutputStream (channel will be null)
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                     
                                                                     // Set method to DEFLATED (using reflection since method is private)
                                                                     java.lang.reflect.Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                     methodField.setAccessible(true);
                                                                     methodField.set(zos, ZipArchiveOutputStream.DEFLATED);
                                                                     
                                                                     // Call the method with phased = false
                                                                     java.lang.reflect.Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                     usesDataDescriptor.setAccessible(true);
                                                                     boolean result = (boolean) usesDataDescriptor.invoke(zos, ZipArchiveOutputStream.DEFLATED, false);
                                                                     
                                                                     assertTrue(result);
                                                                 }

    @Test
                                                                 public void testUsesDataDescriptor_PhasedTrue() throws Exception {
                                                                     // Create mock output stream
                                                                     OutputStream mockOutputStream = new ByteArrayOutputStream();
                                                                     
                                                                     // Initialize ZipArchiveOutputStream
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                     
                                                                     // Set method field to DEFLATED using reflection
                                                                     java.lang.reflect.Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                     methodField.setAccessible(true);
                                                                     methodField.set(zos, ZipArchiveOutputStream.DEFLATED);
                                                                     
                                                                     // Get and invoke usesDataDescriptor method
                                                                     java.lang.reflect.Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                     usesDataDescriptor.setAccessible(true);
                                                                     boolean result = (boolean) usesDataDescriptor.invoke(zos, ZipArchiveOutputStream.DEFLATED, true);
                                                                     
                                                                     // Assert the result
                                                                     assertFalse(result);
                                                                 }

    @Test
                                                                 public void testUsesDataDescriptor_MethodNotDeflated() throws Exception {
                                                                     OutputStream mockOutputStream = new ByteArrayOutputStream();
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                     
                                                                     try {
                                                                         java.lang.reflect.Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                         methodField.setAccessible(true);
                                                                         methodField.set(zos, ZipArchiveOutputStream.STORED);
                                                                         
                                                                         java.lang.reflect.Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                             "usesDataDescriptor", int.class, boolean.class);
                                                                         usesDataDescriptor.setAccessible(true);
                                                                         boolean result = (boolean) usesDataDescriptor.invoke(
                                                                             zos, ZipArchiveOutputStream.STORED, false);
                                                                         
                                                                         assertFalse(result);
                                                                     } finally {
                                                                         zos.close();
                                                                     }
                                                                 }

    @Test
                                                                 public void testUsesDataDescriptor_ChannelNotNull() throws Exception {
                                                                     // Create mock SeekableByteChannel
                                                                     SeekableByteChannel mockChannel = mock(SeekableByteChannel.class);
                                                                     
                                                                     // Create instance with SeekableByteChannel (channel will not be null)
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockChannel);
                                                                     
                                                                     // Set method field to DEFLATED using reflection
                                                                     java.lang.reflect.Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                     methodField.setAccessible(true);
                                                                     methodField.set(zos, ZipArchiveOutputStream.DEFLATED);
                                                                     
                                                                     // Get and invoke usesDataDescriptor method
                                                                     java.lang.reflect.Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "usesDataDescriptor", int.class, boolean.class);
                                                                     usesDataDescriptor.setAccessible(true);
                                                                     boolean result = (boolean) usesDataDescriptor.invoke(zos, ZipArchiveOutputStream.DEFLATED, false);
                                                                     
                                                                     // Assert that result is false since channel is not null
                                                                     assertFalse(result);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtractMethod_Deflated() throws Exception {
                                                                     // Create an instance of ZipArchiveOutputStream
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                     
                                                                     // Get private method via reflection
                                                                     Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtractMethod", int.class);
                                                                     method.setAccessible(true);
                                                                     
                                                                     // Get DEFLATE_MIN_VERSION field via reflection
                                                                     Field deflateMinVersionField = ZipArchiveOutputStream.class.getDeclaredField("DEFLATE_MIN_VERSION");
                                                                     deflateMinVersionField.setAccessible(true);
                                                                     int deflateMinVersion = deflateMinVersionField.getInt(zos);
                                                                     
                                                                     // Test with DEFLATED compression method
                                                                     int result = (int) method.invoke(zos, ZipArchiveOutputStream.DEFLATED);
                                                                     
                                                                     assertEquals("DEFLATED should require DEFLATE_MIN_VERSION", 
                                                                                  deflateMinVersion, result);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtractMethod_Stored() throws Exception {
                                                                     // Create an instance of ZipArchiveOutputStream
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                     
                                                                     // Define constants since we can't access them directly
                                                                     final int STORED = 0;
                                                                     final int INITIAL_VERSION = 10; // Default initial version
                                                                     
                                                                     // Use reflection to access private method
                                                                     Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtractMethod", int.class);
                                                                     method.setAccessible(true);
                                                                     
                                                                     // Test with STORED compression method
                                                                     int result = (int) method.invoke(zos, STORED);
                                                                     assertEquals("STORED should require INITIAL_VERSION", 
                                                                                 INITIAL_VERSION, result);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtractMethod_DefaultCompression() throws Exception {
                                                                     // Create an instance of ZipArchiveOutputStream
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                     
                                                                     // Get the private method using reflection
                                                                     Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtractMethod", int.class);
                                                                     method.setAccessible(true);
                                                                     
                                                                     // Test with DEFAULT_COMPRESSION (should behave like DEFLATED)
                                                                     int defaultCompression = 0; // DEFAULT_COMPRESSION is typically 0
                                                                     int result = (int) method.invoke(zos, defaultCompression);
                                                                     
                                                                     // DEFLATE_MIN_VERSION is typically 20
                                                                     int deflateMinVersion = 20;
                                                                     assertEquals("DEFAULT_COMPRESSION should require DEFLATE_MIN_VERSION", 
                                                                                 deflateMinVersion, result);
                                                                 }

    @Test
                                                                 public void testVersionNeededToExtractMethod_MethodBoundaryValues() throws Exception {
                                                                     // Define constants locally
                                                                     final int STORED = 0;
                                                                     final int DEFLATED = 8;
                                                                     final int INITIAL_VERSION = 10;
                                                                     final int DEFLATE_MIN_VERSION = 20;
                                                                     
                                                                     // Create an instance of ZipArchiveOutputStream
                                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                     
                                                                     // Get private method via reflection
                                                                     Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "versionNeededToExtractMethod", int.class);
                                                                     versionMethod.setAccessible(true);
                                                                     
                                                                     // Test boundary values around the known methods
                                                                     assertEquals(INITIAL_VERSION, 
                                                                                 versionMethod.invoke(zos, STORED - 1));
                                                                     assertEquals(INITIAL_VERSION, 
                                                                                 versionMethod.invoke(zos, STORED));
                                                                     assertEquals(INITIAL_VERSION, 
                                                                                 versionMethod.invoke(zos, STORED + 1));
                                                                     
                                                                     assertEquals(DEFLATE_MIN_VERSION, 
                                                                                 versionMethod.invoke(zos, DEFLATED - 1));
                                                                     assertEquals(DEFLATE_MIN_VERSION, 
                                                                                 versionMethod.invoke(zos, DEFLATED));
                                                                     assertEquals(DEFLATE_MIN_VERSION, 
                                                                                 versionMethod.invoke(zos, DEFLATED + 1));
                                                                 }

    @Test
                                                             public void testCreateLocalFileHeader_WithoutAlignment() throws Exception {
                                                                 // Setup
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                 ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                 ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                 
                                                                 // Mock entry methods
                                                                 when(entry.getExtraField(any())).thenReturn(null);
                                                                 when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                 when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                 when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                 when(entry.getCrc()).thenReturn(12345L);
                                                                 when(entry.getCompressedSize()).thenReturn(100L);
                                                                 when(entry.getSize()).thenReturn(100L);
                                                                 
                                                                 // Use reflection to set alignment since it's protected
                                                                 Method setAlignment = ZipArchiveEntry.class.getDeclaredMethod("setAlignment", int.class);
                                                                 setAlignment.setAccessible(true);
                                                                 setAlignment.invoke(entry, 0);
                                                                 
                                                                 // Get private createLocalFileHeader method via reflection
                                                                 Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "createLocalFileHeader", 
                                                                     ZipArchiveEntry.class, 
                                                                     ByteBuffer.class, 
                                                                     boolean.class, 
                                                                     boolean.class, 
                                                                     long.class
                                                                 );
                                                                 createLocalFileHeader.setAccessible(true);
                                                                 
                                                                 // Execute
                                                                 byte[] result = (byte[]) createLocalFileHeader.invoke(zos, entry, name, true, false, 0L);
                                                                 
                                                                 // Get private constants via reflection
                                                                 Field lfhSigField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG");
                                                                 lfhSigField.setAccessible(true);
                                                                 byte[] LFH_SIG = (byte[]) lfhSigField.get(zos);
                                                                 
                                                                 Field methodOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_METHOD_OFFSET");
                                                                 methodOffsetField.setAccessible(true);
                                                                 int LFH_METHOD_OFFSET = methodOffsetField.getInt(zos);
                                                                 
                                                                 // Verify
                                                                 assertNotNull(result);
                                                                 assertEquals(LFH_SIG[0], result[0]);
                                                                 assertEquals(LFH_SIG[1], result[1]);
                                                                 assertEquals(LFH_SIG[2], result[2]);
                                                                 assertEquals(LFH_SIG[3], result[3]);
                                                                 
                                                                 // Verify method is STORED
                                                                 int method = (result[LFH_METHOD_OFFSET] & 0xff) + 
                                                                             ((result[LFH_METHOD_OFFSET + 1] & 0xff) << 8);
                                                                 assertEquals(ZipArchiveOutputStream.STORED, method);
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_WithExtraFields() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("extra.txt");
                                                                 entry.setSize(300);
                                                                 entry.setExtra(new byte[] {1, 2, 3, 4, 5, 6, 7, 8});
                                                                 
                                                                 // Get private method via reflection
                                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class
                                                                     .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                 writeLocalFileHeader.setAccessible(true);
                                                                 
                                                                 // Execute
                                                                 writeLocalFileHeader.invoke(zos, entry, false);
                                                                 
                                                                 // Verify
                                                                 byte[] header = baos.toByteArray();
                                                                 
                                                                 // Check extra field length (should be 8)
                                                                 assertEquals(8, 
                                                                             (header[28] & 0xff) | ((header[29] & 0xff) << 8));
                                                                 
                                                                 // Check extra field content
                                                                 assertArrayEquals(new byte[] {1, 2, 3, 4, 5, 6, 7, 8}, 
                                                                                  new byte[] {header[30], header[31], header[32], header[33],
                                                                                             header[34], header[35], header[36], header[37]});
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_NullEntry() throws Exception {
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                 
                                                                 // Get the private method using reflection
                                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                 writeLocalFileHeader.setAccessible(true);
                                                                 
                                                                 try {
                                                                     writeLocalFileHeader.invoke(zos, null, false);
                                                                     fail("Expected NullPointerException");
                                                                 } catch (InvocationTargetException e) {
                                                                     Throwable cause = e.getCause();
                                                                     assertTrue(cause instanceof NullPointerException);
                                                                     assertEquals("archive entry", cause.getMessage());
                                                                 } finally {
                                                                     writeLocalFileHeader.setAccessible(false);
                                                                 }
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_AfterFinish() throws Exception {
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                 
                                                                 zos.finish();
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("afterFinish.txt");
                                                                 
                                                                 try {
                                                                     // Use reflection to access private method
                                                                     Method writeLocalFileHeader = ZipArchiveOutputStream.class
                                                                         .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                     writeLocalFileHeader.setAccessible(true);
                                                                     writeLocalFileHeader.invoke(zos, entry, false);
                                                                     fail("Expected IOException");
                                                                 } catch (InvocationTargetException e) {
                                                                     Throwable cause = e.getCause();
                                                                     assertTrue(cause instanceof IOException);
                                                                     assertEquals("Stream has already been finished", cause.getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_WithZip() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("large.txt");
                                                                 entry.setSize(0xFFFFFFFFL + 100); // Exceeds ZIP32 limit
                                                                 entry.setCompressedSize(0xFFFFFFFFL + 80);
                                                                 entry.setCrc(0x12345678L);
                                                                 
                                                                 // Enable ZIP64 mode
                                                                 zos.setUseZip64(Zip64Mode.AsNeeded);
                                                                 
                                                                 // Execute - use putArchiveEntry instead of direct private method call
                                                                 zos.putArchiveEntry(entry);
                                                                 
                                                                 // Verify
                                                                 byte[] header = baos.toByteArray();
                                                                 
                                                                 // Check that sizes are set to 0xFFFFFFFF (ZIP32 max)
                                                                 assertEquals(0xFFFFFFFFL, 
                                                                             (header[18] & 0xffL) | ((header[19] & 0xffL) << 8) | 
                                                                             ((header[20] & 0xffL) << 16) | ((header[21] & 0xffL) << 24));
                                                                 
                                                                 assertEquals(0xFFFFFFFFL, 
                                                                             (header[22] & 0xffL) | ((header[23] & 0xffL) << 8) | 
                                                                             ((header[24] & 0xffL) << 16) | ((header[25] & 0xffL) << 24));
                                                                 
                                                                 // Check that ZIP64 extra field is present
                                                                 assertTrue(header.length > 30 + 8 + 20); // Basic header + filename + ZIP64 extra field
                                                                 
                                                                 // Clean up
                                                                 zos.closeArchiveEntry();
                                                                 zos.close();
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_StandardEntry() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                 entry.setSize(100);
                                                                 
                                                                 // Get total bytes written through reflection
                                                                 Field streamCompressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                 streamCompressorField.setAccessible(true);
                                                                 Object streamCompressor = streamCompressorField.get(zos);
                                                                 Method getTotalBytesWritten = streamCompressor.getClass().getDeclaredMethod("getTotalBytesWritten");
                                                                 getTotalBytesWritten.setAccessible(true);
                                                                 long initialBytes = (long) getTotalBytesWritten.invoke(streamCompressor);
                                                                 
                                                                 // Execute
                                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                 writeLocalFileHeader.setAccessible(true);
                                                                 writeLocalFileHeader.invoke(zos, entry);
                                                                 
                                                                 // Verify metadata
                                                                 Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                                                 metaDataField.setAccessible(true);
                                                                 Map<ZipArchiveEntry, Object> metaDataMap = (Map<ZipArchiveEntry, Object>) metaDataField.get(zos);
                                                                 
                                                                 Object metaData = metaDataMap.get(entry);
                                                                 assertNotNull(metaData);
                                                                 
                                                                 Method getLocalHeaderOffset = metaData.getClass().getDeclaredMethod("getLocalHeaderOffset");
                                                                 getLocalHeaderOffset.setAccessible(true);
                                                                 assertEquals(initialBytes, getLocalHeaderOffset.invoke(metaData));
                                                                 
                                                                 // Check data positions
                                                                 Field entryField = ZipArchiveOutputStream.class.getDeclaredField("entry");
                                                                 entryField.setAccessible(true);
                                                                 Object currentEntry = entryField.get(zos);
                                                                 
                                                                 Field localDataStartField = currentEntry.getClass().getDeclaredField("localDataStart");
                                                                 localDataStartField.setAccessible(true);
                                                                 long localDataStart = (long) localDataStartField.get(currentEntry);
                                                                 
                                                                 Field dataStartField = currentEntry.getClass().getDeclaredField("dataStart");
                                                                 dataStartField.setAccessible(true);
                                                                 long dataStart = (long) dataStartField.get(currentEntry);
                                                                 
                                                                 assertTrue(localDataStart > initialBytes);
                                                                 assertTrue(dataStart > localDataStart);
                                                                 
                                                                 // Verify header was written
                                                                 assertTrue(outputStream.size() > 0);
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_NonEncodableName() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                                 
                                                                 ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                 when(mockEncoding.canEncode(anyString())).thenReturn(false);
                                                                 
                                                                 // Use reflection to set private zipEncoding field
                                                                 Field zipEncodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                 zipEncodingField.setAccessible(true);
                                                                 zipEncodingField.set(zos, mockEncoding);
                                                                 
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                 
                                                                 // Use reflection to access protected writeLocalFileHeader method
                                                                 Method writeLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                 writeLocalFileHeaderMethod.setAccessible(true);
                                                                 
                                                                 // Execute
                                                                 writeLocalFileHeaderMethod.invoke(zos, entry);
                                                                 
                                                                 // Verify
                                                                 // Should still write header but with UTF-8 flag set
                                                                 assertTrue(outputStream.size() > 0);
                                                                 
                                                                 // Verify UTF-8 flag is set in GPB
                                                                 byte[] output = outputStream.toByteArray();
                                                                 
                                                                 // Use reflection to get private LFH_GPB_OFFSET constant
                                                                 Field gpbOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_GPB_OFFSET");
                                                                 gpbOffsetField.setAccessible(true);
                                                                 int gpbOffset = gpbOffsetField.getInt(null);
                                                                 
                                                                 // Use reflection to get private EFS_FLAG constant
                                                                 Field efsFlagField = ZipArchiveOutputStream.class.getDeclaredField("EFS_FLAG");
                                                                 efsFlagField.setAccessible(true);
                                                                 byte efsFlag = efsFlagField.getByte(null);
                                                                 
                                                                 assertTrue((output[gpbOffset] & efsFlag) != 0);
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_EmptyName() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                                 ZipArchiveEntry emptyNameEntry = new ZipArchiveEntry("");
                                                                 
                                                                 // Execute
                                                                 // Use reflection to access protected method
                                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                 writeLocalFileHeader.setAccessible(true);
                                                                 writeLocalFileHeader.invoke(zos, emptyNameEntry);
                                                                 
                                                                 // Verify
                                                                 // Access metaData field via reflection since it's likely private
                                                                 Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                                                 metaDataField.setAccessible(true);
                                                                 Map<ZipArchiveEntry, ?> metaData = (Map<ZipArchiveEntry, ?>) metaDataField.get(zos);
                                                                 
                                                                 Object metaDataValue = metaData.get(emptyNameEntry);
                                                                 assertNotNull(metaDataValue);
                                                                 // Should still create valid header
                                                                 assertTrue(outputStream.size() > 0);
                                                             }

    @Test(expected = NullPointerException.class)
                                                             public void testWriteLocalFileHeader_NullEntry1() throws Exception {
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                 try {
                                                                     // Use reflection to access protected method
                                                                     Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                         "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                     method.setAccessible(true);
                                                                     method.invoke(zos, (ZipArchiveEntry)null);
                                                                 } finally {
                                                                     zos.close();
                                                                 }
                                                             }

    @Test
                                                             public void testCreateLocalFileHeader_WithZip64Extra() throws Exception {
                                                                 // Setup
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                 ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                 ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                 
                                                                 // Mock entry behavior
                                                                 when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                 when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                 when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                 when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                 when(entry.getCrc()).thenReturn(12345L);
                                                                 when(entry.getCompressedSize()).thenReturn(0xFFFFFFFFL);
                                                                 when(entry.getSize()).thenReturn(0xFFFFFFFFL);
                                                                 
                                                                 // Set ZIP64 mode to ensure the extra field will be written
                                                                 zos.setUseZip64(Zip64Mode.Always);
                                                                 
                                                                 // Use reflection to access private createLocalFileHeader method
                                                                 Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "createLocalFileHeader", 
                                                                     ZipArchiveEntry.class, ByteBuffer.class, boolean.class, boolean.class, long.class);
                                                                 createLocalFileHeaderMethod.setAccessible(true);
                                                                 
                                                                 // Execute
                                                                 byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                     zos, entry, name, true, false, 0L);
                                                                 
                                                                 // Verify
                                                                 assertNotNull(result);
                                                                 
                                                                 // Verify ZIP64 magic numbers are written for sizes (0xFFFFFFFF)
                                                                 assertEquals((byte) 0xFF, result[30]); // LFH_COMPRESSED_SIZE_OFFSET
                                                                 assertEquals((byte) 0xFF, result[31]);
                                                                 assertEquals((byte) 0xFF, result[32]);
                                                                 assertEquals((byte) 0xFF, result[33]);
                                                                 
                                                                 assertEquals((byte) 0xFF, result[34]); // LFH_ORIGINAL_SIZE_OFFSET
                                                                 assertEquals((byte) 0xFF, result[35]);
                                                                 assertEquals((byte) 0xFF, result[36]);
                                                                 assertEquals((byte) 0xFF, result[37]);
                                                             }

    @Test
                                                             public void testWriteLocalFileHeader_StandardEntry1() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                 
                                                                 // Get initial bytes written using reflection since streamCompressor is private
                                                                 Field streamCompressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                 streamCompressorField.setAccessible(true);
                                                                 StreamCompressor streamCompressor = (StreamCompressor) streamCompressorField.get(zos);
                                                                 long initialBytes = streamCompressor.getTotalBytesWritten();
                                                                 
                                                                 // Execute - call protected method via reflection
                                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                 writeLocalFileHeader.setAccessible(true);
                                                                 writeLocalFileHeader.invoke(zos, entry);
                                                                 
                                                                 // Verify
                                                                 // Check metadata was updated correctly
                                                                 Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                                                 metaDataField.setAccessible(true);
                                                                 @SuppressWarnings("unchecked")
                                                                 Map<ZipArchiveEntry, Object> metaData = 
                                                                     (Map<ZipArchiveEntry, Object>) metaDataField.get(zos);
                                                                 Object metaDataEntry = metaData.get(entry);
                                                                 assertNotNull(metaDataEntry);
                                                                 
                                                                 // Get localHeaderOffset via reflection since EntryMetaData is not accessible
                                                                 Method getLocalHeaderOffset = metaDataEntry.getClass().getMethod("getLocalHeaderOffset");
                                                                 assertEquals(initialBytes, getLocalHeaderOffset.invoke(metaDataEntry));
                                                                 
                                                                 // Check data positions were set correctly
                                                                 Field entryField = ZipArchiveOutputStream.class.getDeclaredField("entry");
                                                                 entryField.setAccessible(true);
                                                                 Object currentEntry = entryField.get(zos);
                                                                 
                                                                 Field localDataStartField = currentEntry.getClass().getDeclaredField("localDataStart");
                                                                 localDataStartField.setAccessible(true);
                                                                 long localDataStart = localDataStartField.getLong(currentEntry);
                                                                 assertTrue(localDataStart > initialBytes);
                                                                 
                                                                 Field dataStartField = currentEntry.getClass().getDeclaredField("dataStart");
                                                                 dataStartField.setAccessible(true);
                                                                 long dataStart = dataStartField.getLong(currentEntry);
                                                                 assertTrue(dataStart > localDataStart);
                                                                 
                                                                 // Verify header was written to stream
                                                                 assertTrue(outputStream.size() > 0);
                                                             }

    @Test
                                                             public void testWriteDataDescriptor_Zip64Size() throws Exception {
                                                                 // Setup
                                                                 ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                 when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                 when(entry.getCrc()).thenReturn(0x12345678L);
                                                                 when(entry.getCompressedSize()).thenReturn(0x100000000L); // > 4GB
                                                                 when(entry.getSize()).thenReturn(0x200000000L); // > 4GB
                                                                 
                                                                 // Create real output stream with mocked output
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                 
                                                                 // Use reflection to set hasZip64Extra to return true
                                                                 Method hasZip64Extra = ZipArchiveOutputStream.class.getDeclaredMethod("hasZip64Extra", ZipArchiveEntry.class);
                                                                 hasZip64Extra.setAccessible(true);
                                                                 
                                                                 // Create entry metadata field
                                                                 Field entryMetaData = ZipArchiveOutputStream.class.getDeclaredField("entryMetaData");
                                                                 entryMetaData.setAccessible(true);
                                                                 
                                                                 // Create mock metadata object
                                                                 Object mockMetaData = new Object();
                                                                 entryMetaData.set(zos, mockMetaData);
                                                                 
                                                                 // Mock the writeOut method to capture output
                                                                 Field outField = ZipArchiveOutputStream.class.getDeclaredField("out");
                                                                 outField.setAccessible(true);
                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                 doAnswer(invocation -> {
                                                                     byte[] data = (byte[]) invocation.getArguments()[0];
                                                                     int offset = (int) invocation.getArguments()[1];
                                                                     int length = (int) invocation.getArguments()[2];
                                                                     baos.write(data, offset, length);
                                                                     return null;
                                                                 }).when(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                 outField.set(zos, mockOut);
                                                                 
                                                                 // Action - call writeDataDescriptor via reflection
                                                                 Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod("writeDataDescriptor", ZipArchiveEntry.class);
                                                                 writeDataDescriptor.setAccessible(true);
                                                                 writeDataDescriptor.invoke(zos, entry);
                                                                 
                                                                 // Verify
                                                                 byte[] result = baos.toByteArray();
                                                                 assertEquals(24, result.length); // 4 (signature) + 4 (CRC) + 8 (compressed) + 8 (size)
                                                                 
                                                                 // Verify signature
                                                                 assertEquals(0x50, result[0] & 0xFF);
                                                                 assertEquals(0x4b, result[1] & 0xFF);
                                                                 assertEquals(0x07, result[2] & 0xFF);
                                                                 assertEquals(0x08, result[3] & 0xFF);
                                                                 
                                                                 // Verify CRC (same as regular)
                                                                 assertEquals(0x78, result[4] & 0xFF);
                                                                 assertEquals(0x56, result[5] & 0xFF);
                                                                 assertEquals(0x34, result[6] & 0xFF);
                                                                 assertEquals(0x12, result[7] & 0xFF);
                                                                 
                                                                 // Verify compressed size (8 bytes, little endian)
                                                                 assertEquals(0x00, result[8] & 0xFF);
                                                                 assertEquals(0x00, result[9] & 0xFF);
                                                                 assertEquals(0x00, result[10] & 0xFF);
                                                                 assertEquals(0x00, result[11] & 0xFF);
                                                                 assertEquals(0x01, result[12] & 0xFF);
                                                                 assertEquals(0x00, result[13] & 0xFF);
                                                                 assertEquals(0x00, result[14] & 0xFF);
                                                                 assertEquals(0x00, result[15] & 0xFF);
                                                                 
                                                                 // Verify size (8 bytes)
                                                                 assertEquals(0x00, result[16] & 0xFF);
                                                                 assertEquals(0x00, result[17] & 0xFF);
                                                                 assertEquals(0x00, result[18] & 0xFF);
                                                                 assertEquals(0x00, result[19] & 0xFF);
                                                                 assertEquals(0x02, result[20] & 0xFF);
                                                                 assertEquals(0x00, result[21] & 0xFF);
                                                                 assertEquals(0x00, result[22] & 0xFF);
                                                                 assertEquals(0x00, result[23] & 0xFF);
                                                             }

    @Test
                                                             public void testWriteDataDescriptor_IOException() throws Exception {
                                                                 // Setup
                                                                 ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                 when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                 when(entry.getCrc()).thenReturn(0x12345678L);
                                                                 when(entry.getCompressedSize()).thenReturn(1000L);
                                                                 when(entry.getSize()).thenReturn(2000L);
                                                                 
                                                                 // Create real output stream that will throw IOException
                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos) {
                                                                     @Override
                                                                     protected void writeDataDescriptor(ZipArchiveEntry ze) throws IOException {
                                                                         throw new IOException("Test exception");
                                                                     }
                                                                 };
                                                                 
                                                                 // Use reflection to access protected method
                                                                 Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "writeDataDescriptor", ZipArchiveEntry.class);
                                                                 method.setAccessible(true);
                                                                 
                                                                 // Verify exception
                                                                 try {
                                                                     method.invoke(zos, entry);
                                                                     fail("Expected IOException");
                                                                 } catch (InvocationTargetException e) {
                                                                     assertTrue(e.getCause() instanceof IOException);
                                                                     assertEquals("Test exception", e.getCause().getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testVersionNeededToExtract_WhenNeitherZip64NorDataDescriptor_ReturnsMethodSpecificVersion() throws Exception {
                                                                 // Arrange
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                 int zipMethod = ZipArchiveOutputStream.DEFLATED;
                                                                 boolean zip64 = false;
                                                                 boolean usedDataDescriptor = false;
                                                                 
                                                                 // Get private methods via reflection
                                                                 Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "versionNeededToExtractMethod", int.class);
                                                                 versionNeededToExtractMethod.setAccessible(true);
                                                                 
                                                                 Method versionNeededToExtract = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                 versionNeededToExtract.setAccessible(true);
                                                                 
                                                                 // Get expected version by calling the private method directly via reflection
                                                                 int expectedVersion = (int) versionNeededToExtractMethod.invoke(zos, zipMethod);
                                                                 
                                                                 // Act
                                                                 int result = (int) versionNeededToExtract.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                 
                                                                 // Assert
                                                                 assertEquals(expectedVersion, result);
                                                             }

    @Test
                                                             public void testVersionNeededToExtract_WithStoredMethod_ReturnsCorrectVersion() throws Exception {
                                                                 // Arrange
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                 int zipMethod = ZipArchiveOutputStream.STORED;
                                                                 boolean zip64 = false;
                                                                 boolean usedDataDescriptor = false;
                                                                 int expectedVersion = 10; // example version for STORED method
                                                                 
                                                                 // Get private method via reflection
                                                                 Method versionNeededToExtract = ZipArchiveOutputStream.class
                                                                     .getDeclaredMethod("versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                 versionNeededToExtract.setAccessible(true);
                                                                 
                                                                 // Act
                                                                 int result = (int) versionNeededToExtract.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                 
                                                                 // Assert
                                                                 assertEquals(expectedVersion, result);
                                                             }

    @Test
                                                             public void testUsesDataDescriptor_AllConditionsFalse() throws Exception {
                                                                 // Create mock channel
                                                                 SeekableByteChannel mockChannel = mock(SeekableByteChannel.class);
                                                                 
                                                                 // Initialize output stream
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockChannel);
                                                                 
                                                                 // Get STORED constant value via reflection
                                                                 java.lang.reflect.Field storedField = ZipArchiveOutputStream.class.getDeclaredField("STORED");
                                                                 storedField.setAccessible(true);
                                                                 int STORED = (int) storedField.get(null);
                                                                 
                                                                 // Set method field to STORED via reflection
                                                                 java.lang.reflect.Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                 methodField.setAccessible(true);
                                                                 methodField.set(zos, STORED);
                                                                 
                                                                 // Get and invoke usesDataDescriptor method
                                                                 java.lang.reflect.Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "usesDataDescriptor", int.class, boolean.class);
                                                                 usesDataDescriptor.setAccessible(true);
                                                                 boolean result = (boolean) usesDataDescriptor.invoke(zos, STORED, true);
                                                                 
                                                                 // Verify result
                                                                 assertFalse(result);
                                                             }

    @Test
                                                             public void testVersionNeededToExtractMethod_UnknownMethod() throws Exception {
                                                                 // Create an instance of ZipArchiveOutputStream
                                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                 
                                                                 // Get the private method using reflection
                                                                 Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                     "versionNeededToExtractMethod", int.class);
                                                                 method.setAccessible(true);
                                                                 
                                                                 // Test with an unknown compression method (should default to INITIAL_VERSION)
                                                                 int unknownMethod = 99;
                                                                 int result = (int) method.invoke(zos, unknownMethod);
                                                                 
                                                                 // Standard ZIP INITIAL_VERSION is 10 (1.0)
                                                                 assertEquals("Unknown method should default to INITIAL_VERSION", 
                                                                              10, result);
                                                             }

    @Test
                                                         public void testWriteLocalFileHeader_WithPhasedWrite() throws Exception {
                                                             // Setup
                                                             ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                             ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                             try {
                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("phased.txt");
                                                                 entry.setMethod(ZipArchiveEntry.DEFLATED);
                                                                 entry.setSize(500);
                                                                 
                                                                 // Get private method via reflection
                                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class
                                                                     .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                 writeLocalFileHeader.setAccessible(true);
                                                                 
                                                                 // Execute phased write
                                                                 writeLocalFileHeader.invoke(zos, entry, true);
                                                                 
                                                                 // Verify
                                                                 byte[] header = baos.toByteArray();
                                                                 
                                                                 // Check general purpose bit flag (bit 3 should be set for phased write)
                                                                 assertEquals(1 << 3, 
                                                                             (header[6] & 0xff) | ((header[7] & 0xff) << 8));
                                                                 
                                                                 // Compressed size and CRC should be 0 for phased write
                                                                 assertEquals(0L, 
                                                                             (header[18] & 0xffL) | ((header[19] & 0xffL) << 8) | 
                                                                             ((header[20] & 0xffL) << 16) | ((header[21] & 0xffL) << 24));
                                                                 
                                                                 assertEquals(0L, 
                                                                             (header[14] & 0xffL) | ((header[15] & 0xffL) << 8) | 
                                                                             ((header[16] & 0xffL) << 16) | ((header[17] & 0xffL) << 24));
                                                             } finally {
                                                                 zos.close();
                                                             }
                                                         }

    @Test
                                                         public void testVersionNeededToExtract_WhenZip64IsTrue_ReturnsZip64MinVersion() throws Exception {
                                                             // Arrange
                                                             OutputStream mockOutputStream = mock(OutputStream.class);
                                                             ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                             int zipMethod = ZipArchiveOutputStream.DEFLATED; // arbitrary method
                                                             boolean zip64 = true;
                                                             boolean usedDataDescriptor = false;
                                                             
                                                             // Use reflection to access private method
                                                             Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                 "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                             method.setAccessible(true);
                                                             
                                                             // Act
                                                             int result = (int) method.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                             
                                                             // Assert
                                                             assertEquals(45, result); // ZIP64 requires version 4.5 (decimal 45)
                                                         }

    @Test
                                                     public void testWriteLocalFileHeader_DeflatedEntry() throws Exception {
                                                         // Setup
                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                         try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos)) {
                                                             ZipArchiveEntry entry = new ZipArchiveEntry("compressed.txt");
                                                             entry.setMethod(ZipArchiveEntry.DEFLATED);
                                                             entry.setSize(200);
                                                             entry.setCompressedSize(150);
                                                             entry.setCrc(987654321L);
                                                             
                                                             // Use reflection to access private method
                                                             Method writeLocalFileHeader = ZipArchiveOutputStream.class
                                                                 .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                             writeLocalFileHeader.setAccessible(true);
                                                             
                                                             // Execute
                                                             writeLocalFileHeader.invoke(zos, entry, false);
                                                             
                                                             // Verify
                                                             byte[] header = baos.toByteArray();
                                                             
                                                             // Check compression method (DEFLATED = 8)
                                                             assertEquals(8, 
                                                                        (header[8] & 0xff) | ((header[9] & 0xff) << 8));
                                                             
                                                             // Check version needed to extract (should be 20 for DEFLATED)
                                                             assertEquals(20, 
                                                                        (header[4] & 0xff) | ((header[5] & 0xff) << 8));
                                                         }
                                                     }

    @Test
                                                 public void testWriteLocalFileHeader_WithUnicodeFilename() throws Exception {
                                                     // Setup
                                                     java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                                                     org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zos = 
                                                         new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream(baos);
                                                     org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
                                                         new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("测试.txt"); // Chinese characters
                                                     entry.setMethod(java.util.zip.ZipEntry.STORED);
                                                     entry.setSize(50);
                                                     entry.setCrc(12345678L); // Need to set CRC for STORED method
                                                     
                                                     // Enable UTF-8 flag
                                                     zos.setEncoding("UTF-8");
                                                     zos.setUseLanguageEncodingFlag(true);
                                                     
                                                     // Use reflection to access private method
                                                     java.lang.reflect.Method writeLocalFileHeader = 
                                                         org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.class.getDeclaredMethod(
                                                             "writeLocalFileHeader", 
                                                             org.apache.commons.compress.archivers.zip.ZipArchiveEntry.class, 
                                                             boolean.class);
                                                     writeLocalFileHeader.setAccessible(true);
                                                     
                                                     // Execute
                                                     writeLocalFileHeader.invoke(zos, entry, false);
                                                     
                                                     // Verify
                                                     byte[] header = baos.toByteArray();
                                                     
                                                     // Check general purpose bit flag (bit 11 should be set for UTF-8)
                                                     assertEquals(1 << 11, 
                                                                 (header[6] & 0xff) | ((header[7] & 0xff) << 8));
                                                     
                                                     // Check filename length (9 bytes for "测试.txt" in UTF-8)
                                                     assertEquals(9, 
                                                                 (header[26] & 0xff) | ((header[27] & 0xff) << 8));
                                                 }

    @Test
                                                 public void testCreateLocalFileHeader_WithAlignmentAndMethodChangeAllowed() throws Exception {
                                                     // Setup
                                                     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                     ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                     
                                                     ResourceAlignmentExtraField alignmentEx = mock(ResourceAlignmentExtraField.class);
                                                     when(alignmentEx.getAlignment()).thenReturn((short)4); // Changed to return short
                                                     when(alignmentEx.allowMethodChange()).thenReturn(true);
                                                     when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(alignmentEx);
                                                     
                                                     // Create a real ZipArchiveEntry to access protected getAlignment()
                                                     ZipArchiveEntry realEntry = new ZipArchiveEntry("test.txt");
                                                     Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                     getAlignmentMethod.setAccessible(true);
                                                     int alignment = (int) getAlignmentMethod.invoke(realEntry);
                                                     
                                                     // Mock entry methods
                                                     when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                     when(entry.getMethod()).thenReturn(ZipMethod.DEFLATED.getCode());
                                                     when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                     when(entry.getCrc()).thenReturn(12345L);
                                                     when(entry.getCompressedSize()).thenReturn(100L);
                                                     when(entry.getSize()).thenReturn(200L);
                                                     
                                                     // Access private createLocalFileHeader method via reflection
                                                     Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                         "createLocalFileHeader", 
                                                         ZipArchiveEntry.class, 
                                                         ByteBuffer.class, 
                                                         boolean.class, 
                                                         boolean.class, 
                                                         long.class
                                                     );
                                                     createLocalFileHeaderMethod.setAccessible(true);
                                                     
                                                     // Execute
                                                     byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                         zos, 
                                                         entry, 
                                                         name, 
                                                         true, 
                                                         false, 
                                                         0L
                                                     );
                                                     
                                                     // Verify
                                                     assertNotNull(result);
                                                     assertTrue(result.length > 0);
                                                     
                                                     // Access private LFH_SIG field via reflection
                                                     Field lfhSigField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG");
                                                     lfhSigField.setAccessible(true);
                                                     byte[] lfhSig = (byte[]) lfhSigField.get(zos);
                                                     
                                                     // Verify signature
                                                     assertEquals(lfhSig[0], result[0]);
                                                     assertEquals(lfhSig[1], result[1]);
                                                     assertEquals(lfhSig[2], result[2]);
                                                     assertEquals(lfhSig[3], result[3]);
                                                 }

    @Test
                                             public void testWriteLocalFileHeader_StoredMethod() throws Exception {
                                                 // Setup
                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                 ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                 ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                 
                                                 entry.setMethod(ZipArchiveEntry.STORED);
                                                 entry.setSize(100);
                                                 entry.setCompressedSize(100);
                                                 entry.setCrc(12345678L);
                                                 
                                                 // Execute
                                                 // Access protected method via reflection
                                                 Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                     "writeLocalFileHeader", ZipArchiveEntry.class);
                                                 writeLocalFileHeader.setAccessible(true);
                                                 writeLocalFileHeader.invoke(zos, entry);
                                                 
                                                 // Verify
                                                 // Access private metaData field using reflection
                                                 Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                                 metaDataField.setAccessible(true);
                                                 @SuppressWarnings("unchecked")
                                                 Map<ZipArchiveEntry, ?> metaDataMap = (Map<ZipArchiveEntry, ?>) metaDataField.get(zos);
                                                 
                                                 Object metaData = metaDataMap.get(entry);
                                                 assertNotNull(metaData);
                                                 
                                                 // Access usesDataDescriptor field in EntryMetaData
                                                 Class<?> metaDataClass = metaData.getClass();
                                                 Field usesDataDescriptorField = metaDataClass.getDeclaredField("usesDataDescriptor");
                                                 usesDataDescriptorField.setAccessible(true);
                                                 boolean usesDataDescriptor = usesDataDescriptorField.getBoolean(metaData);
                                                 
                                                 assertFalse(usesDataDescriptor);
                                                 
                                                 // Cleanup
                                                 zos.close();
                                             }

    @Test
                                     public void testWriteLocalFileHeader_UnicodeNameWithAlwaysPolicy() throws Exception {
                                         // Setup
                                         ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                                         ZipArchiveOutputStream zos = new ZipArchiveOutputStream(outputStream);
                                         zos.setCreateUnicodeExtraFields(org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy.ALWAYS);
                                         ZipArchiveEntry unicodeEntry = new ZipArchiveEntry("测试.txt");
                                         unicodeEntry.setSize(0);
                                         unicodeEntry.setCompressedSize(0);
                                         unicodeEntry.setCrc(0);
                                         
                                         // Execute
                                         try {
                                             // Use reflection to access protected method
                                             Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                 "writeLocalFileHeader", ZipArchiveEntry.class);
                                             writeLocalFileHeader.setAccessible(true);
                                             writeLocalFileHeader.invoke(zos, unicodeEntry);
                                         } catch (Exception e) {
                                             fail("Reflection failed: " + e.getMessage());
                                         }
                                         
                                         // Verify
                                         try {
                                             // Use reflection to access private metaData field
                                             Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                             metaDataField.setAccessible(true);
                                             @SuppressWarnings("unchecked")
                                             Map<ZipArchiveEntry, ?> metaData = (Map<ZipArchiveEntry, ?>) metaDataField.get(zos);
                                             
                                             Object metaDataValue = metaData.get(unicodeEntry);
                                             assertNotNull(metaDataValue);
                                             // Should have written more bytes due to unicode extra field
                                             assertTrue(outputStream.size() > 30); // Minimum header size
                                         } catch (Exception e) {
                                             fail("Reflection failed: " + e.getMessage());
                                         }
                                     }

    @Test
    public void testWriteOut_VerifiesExactZeroCopyLength() throws Exception {
        // Setup
        byte[] testData = new byte[100];
        java.util.Arrays.fill(testData, (byte)1); // Fill with non-zero values
        byte[] buffer = new byte[testData.length + 100]; // Extra space to detect overflow
        
        // Create a mock streamCompressor that captures the buffer state
        StreamCompressor mockCompressor = org.mockito.mock(StreamCompressor.class);
        org.mockito.doAnswer(invocation -> {
            byte[] data = (byte[]) invocation.getArgument(0);
            int offset = (int) invocation.getArgument(1);
            int length = (int) invocation.getArgument(2);
            System.arraycopy(data, offset, buffer, 0, length);
            return null;
        }).when(mockCompressor).write(
            org.mockito.ArgumentMatchers.any(byte[].class),
            org.mockito.ArgumentMatchers.anyInt(),
            org.mockito.ArgumentMatchers.anyInt());
        
        // Create test instance and inject mock
        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new java.io.ByteArrayOutputStream());
        java.lang.reflect.Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
        compressorField.setAccessible(true);
        compressorField.set(zos, mockCompressor);
        
        // Set up WORD value (assuming WORD is 4 bytes as typical for ZIP format)
        final int WORD = 4;
        
        // Get LFH_COMPRESSED_SIZE_OFFSET via reflection or use default
        int LFH_COMPRESSED_SIZE_OFFSET = 14; // Default ZIP local file header compressed size offset
        try {
            java.lang.reflect.Field lfhCompressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
            lfhCompressedSizeOffsetField.setAccessible(true);
            LFH_COMPRESSED_SIZE_OFFSET = lfhCompressedSizeOffsetField.getInt(null); // Static field
        } catch (NoSuchFieldException e) {
            // Use default value if field not found
        }
        
        // Execute
        java.lang.reflect.Method writeOut = ZipArchiveOutputStream.class.getDeclaredMethod("writeOut", byte[].class, int.class, int.class);
        writeOut.setAccessible(true);
        writeOut.invoke(zos, testData, 0, testData.length);
        
        // Verify
        // Check that exactly WORD bytes were zeroed at LFH_COMPRESSED_SIZE_OFFSET
        for (int i = 0; i < WORD; i++) {
            org.junit.Assert.assertEquals(0, buffer[LFH_COMPRESSED_SIZE_OFFSET + i]);
        }
        // Verify no extra byte was written (WORD+1 would write to this position)
        if (LFH_COMPRESSED_SIZE_OFFSET + WORD < buffer.length) {
            org.junit.Assert.assertNotEquals(0, buffer[LFH_COMPRESSED_SIZE_OFFSET + WORD]);
        }
        
        // Verify the original data was preserved where it shouldn't be modified
        for (int i = 0; i < testData.length; i++) {
            if (i < LFH_COMPRESSED_SIZE_OFFSET || 
                i >= LFH_COMPRESSED_SIZE_OFFSET + WORD) {
                org.junit.Assert.assertEquals(testData[i], buffer[i]);
            }
        }
    }

    @Test
    public void testWriteOutDetectsArrayCopyMutation() throws Exception {
        // Setup
        byte[] testData = new byte[100];
        int offset = 0;
        int length = 50;
        
        // Define constants from ZipConstants
        final int LFH_COMPRESSED_SIZE_OFFSET = 18;
        final int WORD = 4; // Assuming WORD is 4 bytes based on typical ZIP format
        byte[] buf = new byte[LFH_COMPRESSED_SIZE_OFFSET + WORD];
        
        // Create a test implementation of StreamCompressor that captures the buffer
        class TestStreamCompressor extends StreamCompressor {
            TestStreamCompressor() throws IOException {
                super(StreamCompressor.create(new ByteArrayOutputStream(), new Deflater()));
            }
            
            @Override
            protected void writeOut(byte[] data, int offset, int length) {
                System.arraycopy(data, 0, buf, 0, Math.min(data.length, buf.length));
            }
        }
        
        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
        
        // Use reflection to inject our test compressor
        Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
        compressorField.setAccessible(true);
        compressorField.set(zos, new TestStreamCompressor());
        
        Field bufField = ZipArchiveOutputStream.class.getDeclaredField("LZERO");
        bufField.setAccessible(true);
        byte[] LZERO = (byte[]) bufField.get(zos);
        
        // Use reflection to call protected writeOut method
        Method writeOutMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
            "writeOut", byte[].class, int.class, int.class);
        writeOutMethod.setAccessible(true);
        writeOutMethod.invoke(zos, testData, offset, length);
        
        // Verify - check that only WORD bytes were copied at the offset
        // The mutant would try to copy WORD+1 bytes
        for (int i = LFH_COMPRESSED_SIZE_OFFSET + WORD; i < buf.length; i++) {
            assertEquals(0, buf[i]); // These should be untouched (0 is default byte value)
        }
    }


}
