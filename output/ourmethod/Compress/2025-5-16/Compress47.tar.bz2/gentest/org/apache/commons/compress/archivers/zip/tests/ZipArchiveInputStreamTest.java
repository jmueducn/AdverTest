package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.deflate64.Deflate64CompressorInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                          public void testCanReadEntryData_WithNullEntry_ReturnsFalse() {
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                              assertFalse(zais.canReadEntryData(null));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testCanReadEntryData_WithNonZipArchiveEntry_ReturnsFalse() {
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                              ArchiveEntry nonZipEntry = mock(ArchiveEntry.class);
                                                                                                                                                                              assertFalse(zais.canReadEntryData(nonZipEntry));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testCanReadEntryData_WithRealZipEntry_AllConditionsMet_ReturnsTrue() {
                                                                                                                                                                              // Create a real ZipArchiveEntry that should pass all conditions
                                                                                                                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                                              entry.setMethod(ZipArchiveEntry.STORED);
                                                                                                                                                                              entry.setSize(100);
                                                                                                                                                                              entry.setCompressedSize(100);
                                                                                                                                                                              
                                                                                                                                                                              // Create input stream with a real (but empty) input stream
                                                                                                                                                                              InputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(input);
                                                                                                                                                                              
                                                                                                                                                                              // This test assumes the default configuration supports this entry
                                                                                                                                                                              assertTrue(zais.canReadEntryData(entry));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_WithEmptyBuffer() throws IOException {
                                                                                                                                                                              // Arrange
                                                                                                                                                                              byte[] testData = "test data".getBytes();
                                                                                                                                                                              InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                                              byte[] emptyBuffer = new byte[0];
                                                                                                                                                                      
                                                                                                                                                                              // Act
                                                                                                                                                                              int bytesRead = zis.read(emptyBuffer);
                                                                                                                                                                      
                                                                                                                                                                              // Assert
                                                                                                                                                                              assertEquals(0, bytesRead);
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_NormalOperation() throws IOException {
                                                                                                                                                                              // Arrange
                                                                                                                                                                              byte[] testData = "test data".getBytes();
                                                                                                                                                                              InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                                              byte[] buffer = new byte[testData.length];
                                                                                                                                                                      
                                                                                                                                                                              // Act
                                                                                                                                                                              int bytesRead = zis.read(buffer);
                                                                                                                                                                      
                                                                                                                                                                              // Assert
                                                                                                                                                                              assertEquals(testData.length, bytesRead);
                                                                                                                                                                              assertArrayEquals(testData, buffer);
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_PartialRead() throws IOException {
                                                                                                                                                                              // Arrange
                                                                                                                                                                              byte[] testData = "test data".getBytes();
                                                                                                                                                                              InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                                              byte[] buffer = new byte[4]; // Smaller than test data
                                                                                                                                                                      
                                                                                                                                                                              // Act
                                                                                                                                                                              int bytesRead = zis.read(buffer);
                                                                                                                                                                      
                                                                                                                                                                              // Assert
                                                                                                                                                                              assertEquals(4, bytesRead);
                                                                                                                                                                              byte[] expected = new byte[4];
                                                                                                                                                                              System.arraycopy(testData, 0, expected, 0, 4);
                                                                                                                                                                              assertArrayEquals(expected, buffer);
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_EndOfStream() throws IOException {
                                                                                                                                                                              // Arrange
                                                                                                                                                                              byte[] testData = new byte[0];
                                                                                                                                                                              InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                                      
                                                                                                                                                                              // Act
                                                                                                                                                                              int bytesRead = zis.read(buffer);
                                                                                                                                                                      
                                                                                                                                                                              // Assert
                                                                                                                                                                              assertEquals(-1, bytesRead);
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_MultipleReads() throws IOException {
                                                                                                                                                                              // Arrange
                                                                                                                                                                              byte[] testData = "test data".getBytes();
                                                                                                                                                                              InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                                              byte[] buffer1 = new byte[4];
                                                                                                                                                                              byte[] buffer2 = new byte[5];
                                                                                                                                                                      
                                                                                                                                                                              // Act
                                                                                                                                                                              int bytesRead1 = zis.read(buffer1);
                                                                                                                                                                              int bytesRead2 = zis.read(buffer2);
                                                                                                                                                                      
                                                                                                                                                                              // Assert
                                                                                                                                                                              assertEquals(4, bytesRead1);
                                                                                                                                                                              assertEquals(5, bytesRead2);
                                                                                                                                                                              byte[] expected1 = new byte[4];
                                                                                                                                                                              byte[] expected2 = new byte[5];
                                                                                                                                                                              System.arraycopy(testData, 0, expected1, 0, 4);
                                                                                                                                                                              System.arraycopy(testData, 4, expected2, 0, 5);
                                                                                                                                                                              assertArrayEquals(expected1, buffer1);
                                                                                                                                                                              assertArrayEquals(expected2, buffer2);
                                                                                                                                                                          }

 @Test
                                                                                                                                                              public void testCanReadEntryData_WithZipEntry_AllConditionsTrue_ReturnsTrue() throws Exception {
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                  ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set private fields that would make the private methods return true
                                                                                                                                                                  Field allowStoredEntriesWithDataDescriptorField = ZipArchiveInputStream.class
                                                                                                                                                                      .getDeclaredField("allowStoredEntriesWithDataDescriptor");
                                                                                                                                                                  allowStoredEntriesWithDataDescriptorField.setAccessible(true);
                                                                                                                                                                  allowStoredEntriesWithDataDescriptorField.set(zais, true);
                                                                                                                                                                  
                                                                                                                                                                  // Set up the entry to have a known compressed size
                                                                                                                                                                  when(zipEntry.getCompressedSize()).thenReturn(100L);
                                                                                                                                                                  
                                                                                                                                                                  // The actual test
                                                                                                                                                                  assertTrue(zais.canReadEntryData(zipEntry));
                                                                                                                                                              }

 @Test
                                                                                                                                                              public void testCanReadEntryData_WithZipEntry_CannotHandleData_ReturnsFalse() {
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                                                                                                  ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                                  
                                                                                                                                                                  // Mock the other conditions to return true so we isolate testing the ZipUtil condition
                                                                                                                                                                  when(zipEntry.getMethod()).thenReturn(ZipEntry.STORED); // Ensure supportsDataDescriptorFor returns true
                                                                                                                                                                  when(zipEntry.getCompressedSize()).thenReturn(100L); // Ensure supportsCompressedSizeFor returns true
                                                                                                                                                                  
                                                                                                                                                                  // The method should return false because ZipUtil.canHandleEntryData() will return false
                                                                                                                                                                  assertFalse(zais.canReadEntryData(zipEntry));
                                                                                                                                                              }

 @Test
                                                                                                                                                              public void testCanReadEntryData_WithZipEntry_NoDataDescriptorSupport_ReturnsFalse() throws Exception {
                                                                                                                                                                  // Create a real input stream (we'll use a dummy one)
                                                                                                                                                                  InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(inputStream);
                                                                                                                                                                  
                                                                                                                                                                  // Create a real zip entry that would make canHandleEntryData return true
                                                                                                                                                                  // (e.g., a stored entry with known size)
                                                                                                                                                                  ZipArchiveEntry zipEntry = new ZipArchiveEntry("test");
                                                                                                                                                                  zipEntry.setMethod(ZipEntry.STORED);
                                                                                                                                                                  zipEntry.setSize(10);
                                                                                                                                                                  zipEntry.setCompressedSize(10);
                                                                                                                                                                  zipEntry.setCrc(12345L);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set supportsDataDescriptor to false
                                                                                                                                                                  Field allowStoredEntriesWithDataDescriptorField = 
                                                                                                                                                                      ZipArchiveInputStream.class.getDeclaredField("allowStoredEntriesWithDataDescriptor");
                                                                                                                                                                  allowStoredEntriesWithDataDescriptorField.setAccessible(true);
                                                                                                                                                                  allowStoredEntriesWithDataDescriptorField.set(zais, false);
                                                                                                                                                                  
                                                                                                                                                                  assertFalse(zais.canReadEntryData(zipEntry));
                                                                                                                                                              }

 @Test
                                                                                                                                                              public void testRead_WhenStreamClosed_ThrowsIOException() throws Exception {
                                                                                                                                                                  // Create a mock input stream
                                                                                                                                                                  InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                  // Create the ZipArchiveInputStream to test
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                                                  
                                                                                                                                                                  // Set up expected exception
                                                                                                                                                                  ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                  expectedException.expect(IOException.class);
                                                                                                                                                                  expectedException.expectMessage("The stream is closed");
                                                                                                                                                                  
                                                                                                                                                                  // Close the stream before reading
                                                                                                                                                                  zais.close();
                                                                                                                                                                  
                                                                                                                                                                  // Attempt to read from closed stream
                                                                                                                                                                  byte[] buffer = new byte[10];
                                                                                                                                                                  zais.read(buffer, 0, 10);
                                                                                                                                                              }

 @Test
                                                                                                                                                              public void testRead_WhenCurrentEntryIsNull_ReturnsMinusOne() throws Exception {
                                                                                                                                                                  // Create a mock InputStream
                                                                                                                                                                  InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                  // Create ZipArchiveInputStream with mock input
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                                                  byte[] buffer = new byte[10];
                                                                                                                                                                  assertEquals(-1, zais.read(buffer, 0, 10));
                                                                                                                                                              }

 @Test
                                                                                                                                                              public void testRead_WithOtherSupportedMethods_CallsInputStreamRead() throws Exception {
                                                                                                                                                                  // Create mock objects
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                  Object mockCurrentEntry = mock(Object.class);
                                                                                                                                                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                  CRC32 mockCrc = mock(CRC32.class);
                                                                                                                                                                  
                                                                                                                                                                  // Helper method to set private field
                                                                                                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                                  currentField.setAccessible(true);
                                                                                                                                                                  currentField.set(zais, mockCurrentEntry);
                                                                                                                                                                  
                                                                                                                                                                  // Set up mock behaviors
                                                                                                                                                                  when(mockCurrentEntry.getClass().getMethod("getEntry").invoke(mockCurrentEntry))
                                                                                                                                                                      .thenReturn(mockEntry);
                                                                                                                                                                  when(mockCurrentEntry.getClass().getMethod("getIn").invoke(mockCurrentEntry))
                                                                                                                                                                      .thenReturn(mockInputStream);
                                                                                                                                                                  when(mockCurrentEntry.getClass().getMethod("getCrc").invoke(mockCurrentEntry))
                                                                                                                                                                      .thenReturn(mockCrc);
                                                                                                                                                                  
                                                                                                                                                                  // Test with UNSHRINKING method
                                                                                                                                                                  when(mockEntry.getMethod()).thenReturn(ZipMethod.UNSHRINKING.getCode());
                                                                                                                                                                  when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                                  
                                                                                                                                                                  byte[] buffer = new byte[10];
                                                                                                                                                                  assertEquals(5, zais.read(buffer, 0, 10));
                                                                                                                                                                  
                                                                                                                                                                  verify(mockInputStream).read(buffer, 0, 10);
                                                                                                                                                                  verify(mockCrc).update(buffer, 0, 5);
                                                                                                                                                              }

 @Test
                                                                                                                                                          public void testSupportsCompressedSizeFor_WhenNullEntry() {
                                                                                                                                                              try {
                                                                                                                                                                  // Create a mock InputStream
                                                                                                                                                                  InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                  // Create ZipArchiveInputStream with default settings
                                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to access private method if needed
                                                                                                                                                                  Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                      "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                  method.invoke(zais, (ZipArchiveEntry)null);
                                                                                                                                                                  
                                                                                                                                                                  fail("Expected NullPointerException");
                                                                                                                                                              } catch (NullPointerException e) {
                                                                                                                                                                  // Expected
                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                  fail("Unexpected exception: " + e.getClass().getName());
                                                                                                                                                              }
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenMaxReached_ReturnsNegativeOne() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set private fields since they're final
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.set(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.set(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read();
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(-1, result);
                                                                                                                                                              verify(mockInputStream, never()).read();
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_NormalOperation_ReturnsByteAndUpdatesCounters() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              when(mockInputStream.read()).thenReturn(65); // 'A' in ASCII
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.set(zais, -1L); // No max limit
                                                                                                                                                              
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.set(zais, 0L);
                                                                                                                                                              
                                                                                                                                                              // Create mock current entry
                                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                              currentField.setAccessible(true);
                                                                                                                                                              currentField.set(zais, mockEntry);
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read();
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(65, result);
                                                                                                                                                              assertEquals(1L, posField.get(zais));
                                                                                                                                                              
                                                                                                                                                              // Verify bytesReadFromStream was updated
                                                                                                                                                              Field bytesReadField = ZipArchiveEntry.class.getDeclaredField("bytesReadFromStream");
                                                                                                                                                              bytesReadField.setAccessible(true);
                                                                                                                                                              assertEquals(1L, bytesReadField.get(mockEntry));
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenInputStreamReturnsNegativeOne_ReturnsNegativeOne() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              when(mockInputStream.read()).thenReturn(-1); // EOF
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.setLong(zais, -1L);
                                                                                                                                                              
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.setLong(zais, 0L);
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read();
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(-1, result);
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenIOExceptionOccurs_ThrowsIOException() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              when(mockInputStream.read()).thenThrow(new IOException("Test exception"));
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              // Set private fields using reflection
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.set(zais, -1L);
                                                                                                                                                              
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.set(zais, 0L);
                                                                                                                                                              
                                                                                                                                                              try {
                                                                                                                                                                  // Act
                                                                                                                                                                  zais.read();
                                                                                                                                                                  fail("Expected IOException to be thrown");
                                                                                                                                                              } catch (IOException e) {
                                                                                                                                                                  // Assert
                                                                                                                                                                  assertEquals("Test exception", e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenMaxNotReached_ReadsFromStream() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              when(mockInputStream.read()).thenReturn(42);
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              // Set private field 'max' using reflection
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.setLong(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              // Set private field 'pos' using reflection
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.setLong(zais, 5L); // pos < max
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read();
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(42, result);
                                                                                                                                                              verify(mockInputStream).read();
                                                                                                                                                              assertEquals(6L, posField.getLong(zais));
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_AfterClose() throws IOException {
                                                                                                                                                              // Arrange
                                                                                                                                                              byte[] testData = "test data".getBytes();
                                                                                                                                                              InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              zis.close();
                                                                                                                                                              
                                                                                                                                                              // Set up exception expectation
                                                                                                                                                              ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                              expectedException.expect(IOException.class);
                                                                                                                                                              expectedException.expectMessage("Stream closed");
                                                                                                                                                              
                                                                                                                                                              // Act & Assert
                                                                                                                                                              zis.read(buffer);
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenMaxReached_ReturnsMinusOne() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                                                              
                                                                                                                                                              // Set private field 'pos' to 10
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.setLong(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              // Set private field 'max' to 10
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.setLong(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read(buffer, 0, 10);
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(-1, result);
                                                                                                                                                              verify(mockIn, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenInputStreamReturnsMinusOne_ReturnsMinusOne() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                                              when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                              
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                                                              
                                                                                                                                                              // Set private field 'pos' using reflection
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.set(zais, 0L);
                                                                                                                                                              
                                                                                                                                                              // Set private field 'max' using reflection
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.set(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read(buffer, 0, 10);
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(-1, result);
                                                                                                                                                              assertEquals(0L, posField.get(zais));
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenPartialMaxRemaining_ReadsPartial() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                                              when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(3);
                                                                                                                                                              
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                                                              
                                                                                                                                                              // Set private fields using reflection
                                                                                                                                                              Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                              posField.setAccessible(true);
                                                                                                                                                              posField.setLong(zais, 7L);
                                                                                                                                                              
                                                                                                                                                              Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                              maxField.setLong(zais, 10L);
                                                                                                                                                              
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              int result = zais.read(buffer, 0, 10);
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertEquals(3, result);
                                                                                                                                                              assertEquals(10L, posField.getLong(zais));
                                                                                                                                                              verify(mockIn).read(buffer, 0, 3); // maxRead should be 3 (10-7)
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_IOExceptionFromUnderlyingStream() throws IOException {
                                                                                                                                                              // Arrange
                                                                                                                                                              InputStream inputStream = mock(InputStream.class);
                                                                                                                                                              when(inputStream.read(any(byte[].class), anyInt(), anyInt())).thenThrow(new IOException("Test exception"));
                                                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              
                                                                                                                                                              // Expected exception setup
                                                                                                                                                              ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                              expectedException.expect(IOException.class);
                                                                                                                                                              expectedException.expectMessage("Test exception");
                                                                                                                                                              
                                                                                                                                                              // Act & Assert
                                                                                                                                                              zis.read(buffer);
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WithInvalidOffsetOrLength_ThrowsArrayIndexOutOfBoundsException() throws Exception {
                                                                                                                                                              // Create input stream with dummy input
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                              
                                                                                                                                                              // Get the CurrentEntry class through reflection
                                                                                                                                                              Class<?> currentEntryClass = null;
                                                                                                                                                              for (Class<?> clazz : ZipArchiveInputStream.class.getDeclaredClasses()) {
                                                                                                                                                                  if (clazz.getSimpleName().equals("CurrentEntry")) {
                                                                                                                                                                      currentEntryClass = clazz;
                                                                                                                                                                      break;
                                                                                                                                                                  }
                                                                                                                                                              }
                                                                                                                                                              
                                                                                                                                                              // Create mock objects
                                                                                                                                                              Object mockCurrentEntry = mock(currentEntryClass);
                                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                              
                                                                                                                                                              // Set up mocks
                                                                                                                                                              when(currentEntryClass.getMethod("getEntry").invoke(mockCurrentEntry)).thenReturn(mockEntry);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set private field 'current'
                                                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                              currentField.setAccessible(true);
                                                                                                                                                              currentField.set(zais, mockCurrentEntry);
                                                                                                                                                              
                                                                                                                                                              // Set up exception rule
                                                                                                                                                              ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                              
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              
                                                                                                                                                              // Test various invalid offset/length combinations
                                                                                                                                                              expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                              zais.read(buffer, -1, 5); // negative offset
                                                                                                                                                              
                                                                                                                                                              expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                              zais.read(buffer, 11, 5); // offset > buffer length
                                                                                                                                                              
                                                                                                                                                              expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                              zais.read(buffer, 5, -1); // negative length
                                                                                                                                                              
                                                                                                                                                              expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                              zais.read(buffer, 5, 10); // length > available space
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WithStoredMethod_CallsReadStored() throws Exception {
                                                                                                                                                              // Create mock objects
                                                                                                                                                              ZipArchiveInputStream zais = mock(ZipArchiveInputStream.class);
                                                                                                                                                              Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                                                                                                                                              Object mockCurrentEntry = mock(currentEntryClass);
                                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              CRC32 mockCrc = mock(CRC32.class);
                                                                                                                                                              
                                                                                                                                                              // Set up reflection to set private field
                                                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                              currentField.setAccessible(true);
                                                                                                                                                              currentField.set(zais, mockCurrentEntry);
                                                                                                                                                              
                                                                                                                                                              // Set up mock behavior using reflection
                                                                                                                                                              Field entryField = currentEntryClass.getDeclaredField("entry");
                                                                                                                                                              entryField.setAccessible(true);
                                                                                                                                                              entryField.set(mockCurrentEntry, mockEntry);
                                                                                                                                                              
                                                                                                                                                              Field inField = currentEntryClass.getDeclaredField("in");
                                                                                                                                                              inField.setAccessible(true);
                                                                                                                                                              inField.set(mockCurrentEntry, mockInputStream);
                                                                                                                                                              
                                                                                                                                                              Field crcField = currentEntryClass.getDeclaredField("crc");
                                                                                                                                                              crcField.setAccessible(true);
                                                                                                                                                              crcField.set(mockCurrentEntry, mockCrc);
                                                                                                                                                              
                                                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                              
                                                                                                                                                              // Mock the actual read operation using reflection
                                                                                                                                                              Method readStoredMethod = ZipArchiveInputStream.class.getDeclaredMethod("readStored", byte[].class, int.class, int.class);
                                                                                                                                                              readStoredMethod.setAccessible(true);
                                                                                                                                                              when(zais.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                                                                                                  Object[] args = invocation.getArguments();
                                                                                                                                                                  return readStoredMethod.invoke(zais, args[0], args[1], args[2]);
                                                                                                                                                              });
                                                                                                                                                              when(readStoredMethod.invoke(zais, any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                              
                                                                                                                                                              // Call the method under test
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              assertEquals(5, zais.read(buffer, 0, 10));
                                                                                                                                                              
                                                                                                                                                              // Verify interactions
                                                                                                                                                              verify(mockCrc).update(buffer, 0, 5);
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WhenReadReturnsNegative_DoesNotUpdateCRC() throws Exception {
                                                                                                                                                              // Create mock objects
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              CRC32 mockCRC = mock(CRC32.class);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                              Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                              currentEntryField.setAccessible(true);
                                                                                                                                                              Object currentEntry = currentEntryField.get(zais);
                                                                                                                                                              
                                                                                                                                                              Field entryField = currentEntry.getClass().getDeclaredField("entry");
                                                                                                                                                              entryField.setAccessible(true);
                                                                                                                                                              entryField.set(currentEntry, mockEntry);
                                                                                                                                                              
                                                                                                                                                              Field inField = currentEntry.getClass().getDeclaredField("in");
                                                                                                                                                              inField.setAccessible(true);
                                                                                                                                                              inField.set(currentEntry, mockInputStream);
                                                                                                                                                              
                                                                                                                                                              Field crcField = currentEntry.getClass().getDeclaredField("crc");
                                                                                                                                                              crcField.setAccessible(true);
                                                                                                                                                              crcField.set(currentEntry, mockCRC);
                                                                                                                                                              
                                                                                                                                                              // Set up mock behavior
                                                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipMethod.UNSHRINKING.getCode());
                                                                                                                                                              when(mockInputStream.read(any(), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                              
                                                                                                                                                              // Test
                                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                                              assertEquals(-1, zais.read(buffer, 0, 10));
                                                                                                                                                              
                                                                                                                                                              // Verify
                                                                                                                                                              verify(mockCRC, never()).update(any(), anyInt(), anyInt());
                                                                                                                                                          }

 @Test(expected = NullPointerException.class)
                                                                                                                                                      public void testRead_WithNullBuffer() throws IOException {
                                                                                                                                                          // Arrange
                                                                                                                                                          InputStream inputStream = mock(InputStream.class);
                                                                                                                                                          ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                                          
                                                                                                                                                          // Act & Assert
                                                                                                                                                          zis.read(null);
                                                                                                                                                      }

 @Test
                                                                                                                                                  public void testSupportsCompressedSizeFor_WhenCompressedSizeKnown() throws Exception {
                                                                                                                                                      // Create mock entry
                                                                                                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                      // Create real input stream (content doesn't matter for this test)
                                                                                                                                                      ByteArrayInputStream bais = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                      // Create ZipArchiveInputStream with default settings
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(bais);
                                                                                                                                                      
                                                                                                                                                      // Set up test conditions
                                                                                                                                                      when(entry.getCompressedSize()).thenReturn(100L);
                                                                                                                                                      
                                                                                                                                                      // Get the private method using reflection
                                                                                                                                                      Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                          "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                      
                                                                                                                                                      // Test the method
                                                                                                                                                      boolean result = (boolean) method.invoke(zais, entry);
                                                                                                                                                      assertTrue(result);
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testSupportsCompressedSizeFor_WhenDeflated() throws Exception {
                                                                                                                                                      // Create mock ZipArchiveEntry
                                                                                                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                      // Create real ZipArchiveInputStream with default parameters
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                      
                                                                                                                                                      // Setup mock behavior
                                                                                                                                                      when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                                                                                                                                      when(entry.getMethod()).thenReturn(ZipEntry.DEFLATED);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                      Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                          "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                      boolean result = (boolean) method.invoke(zais, entry);
                                                                                                                                                      
                                                                                                                                                      // Test the method
                                                                                                                                                      assertTrue(result);
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testSupportsCompressedSizeFor_WhenStoredWithDataDescriptorAndAllowed() throws Exception {
                                                                                                                                                      // Create mock objects
                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                      GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                                                                                      
                                                                                                                                                      // Create the test object with data descriptor allowed
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, "UTF-8", true, true);
                                                                                                                                                      
                                                                                                                                                      // Setup mock behavior
                                                                                                                                                      when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                                                                                                                                      when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                                                                                      when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                                                                                      when(gpb.usesDataDescriptor()).thenReturn(true);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                      Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                          "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                      boolean result = (boolean) method.invoke(zais, entry);
                                                                                                                                                      
                                                                                                                                                      // Verify the expected behavior
                                                                                                                                                      assertTrue(result);
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testSupportsCompressedSizeFor_WhenStoredWithDataDescriptorButNotAllowed() throws Exception {
                                                                                                                                                      // Create mock objects
                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                      GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                                                                                      
                                                                                                                                                      // Create ZipArchiveInputStream with allowStoredEntriesWithDataDescriptor=false
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, "UTF-8", true, false);
                                                                                                                                                      
                                                                                                                                                      // Setup mock behavior
                                                                                                                                                      when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                                                                                                                                      when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                                                                                      when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                                                                                      when(gpb.usesDataDescriptor()).thenReturn(true);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                      Method supportsCompressedSizeFor = ZipArchiveInputStream.class
                                                                                                                                                          .getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                      supportsCompressedSizeFor.setAccessible(true);
                                                                                                                                                      
                                                                                                                                                      // Verify the expected result
                                                                                                                                                      assertFalse((Boolean)supportsCompressedSizeFor.invoke(zais, entry));
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testSupportsCompressedSizeFor_WhenStoredWithoutDataDescriptor() throws Exception {
                                                                                                                                                      // Create mock objects
                                                                                                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                      GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                                                                                      
                                                                                                                                                      // Initialize ZipArchiveInputStream with allowStoredEntriesWithDataDescriptor=false
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(
                                                                                                                                                          new ByteArrayInputStream(new byte[0]), 
                                                                                                                                                          "UTF-8", 
                                                                                                                                                          false, 
                                                                                                                                                          false
                                                                                                                                                      );
                                                                                                                                                      
                                                                                                                                                      // Set up mock behaviors
                                                                                                                                                      when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                                                                                                                                      when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                                                                                                                                      when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                                                                                      when(gpb.usesDataDescriptor()).thenReturn(false);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                      Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                          "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                      boolean result = (boolean) method.invoke(zais, entry);
                                                                                                                                                      
                                                                                                                                                      // Perform test
                                                                                                                                                      assertFalse(result);
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testSupportsCompressedSizeFor_WhenUnknownMethod() throws Exception {
                                                                                                                                                      // Create mock objects
                                                                                                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                      GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                                                                                                                                      
                                                                                                                                                      // Setup mock behavior
                                                                                                                                                      when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                                                                                                                                      when(entry.getMethod()).thenReturn(999); // Unknown method
                                                                                                                                                      when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                                                                                                                                      when(gpb.usesDataDescriptor()).thenReturn(false);
                                                                                                                                                      
                                                                                                                                                      // Create real object under test
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                      Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                          "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                      boolean result = (boolean) method.invoke(zais, entry);
                                                                                                                                                      
                                                                                                                                                      // Test and verify
                                                                                                                                                      assertFalse(result);
                                                                                                                                                  }

 @Test
                                                                                                                                                  public void testRead_WhenMaxNotReached_ReturnsBytesRead() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                      // Arrange
                                                                                                                                                      InputStream mockIn = mock(InputStream.class);
                                                                                                                                                      when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                      
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                                                      
                                                                                                                                                      // Set pos field via reflection
                                                                                                                                                      Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                      posField.setAccessible(true);
                                                                                                                                                      posField.set(zais, 0L);
                                                                                                                                                      
                                                                                                                                                      // Set max field via reflection
                                                                                                                                                      Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                      maxField.setAccessible(true);
                                                                                                                                                      maxField.set(zais, 10L);
                                                                                                                                                      
                                                                                                                                                      byte[] buffer = new byte[10];
                                                                                                                                                      
                                                                                                                                                      // Act
                                                                                                                                                      int result = zais.read(buffer, 0, 10);
                                                                                                                                                      
                                                                                                                                                      // Assert
                                                                                                                                                      assertEquals(5, result);
                                                                                                                                                      assertEquals(5L, posField.getLong(zais));
                                                                                                                                                      verify(mockIn).read(buffer, 0, 5); // maxRead should be 5 (10-0)
                                                                                                                                                  }

 @Test(expected = IOException.class)
                                                                                                                                                  public void testRead_WhenIOExceptionOccurs_ThrowsIOException1() throws Exception {
                                                                                                                                                      // Arrange
                                                                                                                                                      InputStream mockIn = mock(InputStream.class);
                                                                                                                                                      when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenThrow(new IOException());
                                                                                                                                                      
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                                                      
                                                                                                                                                      // Try to set private fields if they exist
                                                                                                                                                      try {
                                                                                                                                                          Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                                                                                                                                          posField.setAccessible(true);
                                                                                                                                                          posField.setLong(zais, 0L);
                                                                                                                                                          
                                                                                                                                                          Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                                                                                                                                          maxField.setAccessible(true);
                                                                                                                                                          maxField.setLong(zais, 10L);
                                                                                                                                                      } catch (NoSuchFieldException e) {
                                                                                                                                                          // Fields don't exist in this version, proceed without them
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      byte[] buffer = new byte[10];
                                                                                                                                                      
                                                                                                                                                      // Act
                                                                                                                                                      zais.read(buffer, 0, 10);
                                                                                                                                                  }

 @Test(expected) annotation
                                                                                                                                                  }
  
                                                                                                                                                  public void testRead_WithUnsupportedMethod_ThrowsUnsupportedZipFeatureException() throws Exception {
                                                                                                                                                      // Setup test objects
                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                      ZipArchiveEntry mockCurrentEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                      ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set private field
                                                                                                                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                      currentField.setAccessible(true);
                                                                                                                                                      currentField.set(zais, mockCurrentEntry);
                                                                                                                                                      
                                                                                                                                                      // Setup mock behavior
                                                                                                                                                      when(mockCurrentEntry.getMethod()).thenReturn(999);
                                                                                                                                                      
                                                                                                                                                      // Use an unsupported method code
                                                                                                                                                      when(mockEntry.getMethod()).thenReturn(999);
                                                                                                                                                      
                                                                                                                                                      byte[] buffer = new byte[10];
                                                                                                                                                      
                                                                                                                                                      // This should throw UnsupportedZipFeatureException
                                                                                                                                                      zais.read(buffer, 0, 10);
                                                                                                                                                  }

 @Test
                                                                                                                          public void testRead_WithUnsupportedDataDescriptor_ThrowsUnsupportedZipFeatureException() throws Exception {
                                                                                                                              // Setup
                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                              
                                                                                                                              // Set current entry fields using reflection
                                                                                  {
                                                                                  }{
                                                                                                                              }
                                                                                                                          }

 @Test
                                                                                                                          public void testRead_WithDeflatedMethod_CallsReadDeflated() throws Exception {
                                                                                                                              // Create mock objects
                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                              
                                                                                                                              // Use reflection to set private field
                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                              // Mock the input stream to return test data
                                                                                                                              byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                  {
                                                                                  }
                                                                                                                              
                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                          }

 @Test
                                                                                  public void testRead_WhenNoMaxLimit_ReadsFullLength() throws Exception {
                                                                                      // Arrange
                                                                                      byte[] testData = "testdata".getBytes();
                                                                                      InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(inputStream);
                                                                                      
                                                                                      // Use reflection to access private bytesRead field
                                                                                      Field bytesReadField = ZipArchiveInputStream.class.getDeclaredField("bytesRead");
                                                                                      bytesReadField.setAccessible(true);
                                                                                      
                                                                                      // Create buffer for reading
                                                                                      byte[] buffer = new byte[testData.length];
                                                                                      
                                                                                      // Act
                                                                                      int bytesRead = zais.read(buffer, 0, buffer.length);
                                                                                      
                                                                                      // Assert
                                                                                      assertEquals(testData.length, bytesRead);
                                                                                      assertEquals(testData.length, bytesReadField.getLong(zais));
                                                                                  }

 @Test
                                          public void testRead_WhenBufferTooSmall_ThrowsIndexOutOfBounds() throws IOException {
                                              // Arrange
                                              InputStream mockIn = mock(InputStream.class);
                                              when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                              byte[] buffer = new byte[10];
                                              
                                              try {
                                                  // Act
                                                  zais.read(buffer, 5, 10); // offset + length > buffer.length
                                                  fail("Expected IndexOutOfBoundsException");
                                              } catch (IndexOutOfBoundsException e) {
                                                  // Expected exception
                                              }
                                          }

 @Test
                                          public void testRead_WithUnsupportedCompressedSize_ThrowsUnsupportedZipFeatureException() throws Exception {
                                              // Create mock objects
                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                              
                                              // Set up expected exception rule
                                              ExpectedException expectedException = ExpectedException.none();
                                              expectedException.expect(UnsupportedZipFeatureException.class);
                                              expectedException.expectMessage("UNKNOWN_COMPRESSED_SIZE");
                                              
                                              // Set up reflection to access and set private fields
                                              Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                              Constructor<?> currentEntryConstructor = currentEntryClass.getDeclaredConstructor(ZipArchiveInputStream.class);
                                              currentEntryConstructor.setAccessible(true);
                                              Object mockCurrentEntry = currentEntryConstructor.newInstance(zais);
                                              
                                              Field entryField = currentEntryClass.getDeclaredField("entry");
                                              entryField.setAccessible(true);
                                              entryField.set(mockCurrentEntry, mockEntry);
                                              
                                              Field inField = currentEntryClass.getDeclaredField("in");
                                              inField.setAccessible(true);
                                              inField.set(mockCurrentEntry, mock(InputStream.class));
                                              
                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                              currentField.setAccessible(true);
                                              currentField.set(zais, mockCurrentEntry);
                                              
                                              // Mock behavior using reflection for private method
                                              ZipArchiveInputStream spyZais = spy(zais);
                                              Method supportsMethod = ZipArchiveInputStream.class.getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                              supportsMethod.setAccessible(true);
                                              when(supportsMethod.invoke(spyZais, mockEntry)).thenReturn(false);
                                              
                                              byte[] buffer = new byte[10];
                                              spyZais.read(buffer, 0, 10);
                                          }

 @Test
                                          public void testSupportsCompressedSizeFor_WhenEnhancedDeflated() throws Exception {
                                              // Create mock entry
                                              ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                              entry.setMethod(ZipMethod.ENHANCED_DEFLATED.getCode());
                                              
                                              // Create real input stream (using empty input stream)
                                              InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(inputStream);
                                              
                                              // Get private method via reflection
                                              Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                                  "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                              method.setAccessible(true);
                                              
                                              // Invoke and assert
                                              boolean result = (boolean) method.invoke(zais, entry);
                                              assertTrue("Should support compressed size for enhanced deflated", result);
                                          }

 @Test(expected = IndexOutOfBoundsException.class)
                                          public void testRead_WhenNegativeLength_ThrowsIndexOutOfBounds() throws IOException {
                                              // Arrange
                                              InputStream mockIn = new ByteArrayInputStream(new byte[0]);
                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                              byte[] buffer = new byte[10];
                                              
                                              // Act
                                              zais.read(buffer, 0, -1);
                                          }

 @Test
                                          public void testCanReadEntryData_WithZipEntry_NoCompressedSizeSupport_ReturnsFalse() throws Exception {
                                              // Create mock input stream
                                              InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                              
                                              // Create zip entry
                                              ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                              entry.setMethod(ZipEntry.STORED);
                                              
                                              // Create zip input stream
                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                              
                                              // Get the private methods via reflection
                                              Method supportsDataDescriptorFor = ZipArchiveInputStream.class
                                                  .getDeclaredMethod("supportsDataDescriptorFor", ZipArchiveEntry.class);
                                              supportsDataDescriptorFor.setAccessible(true);
                                              
                                              Method supportsCompressedSizeFor = ZipArchiveInputStream.class
                                                  .getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                              supportsCompressedSizeFor.setAccessible(true);
                                              
                                              // Create a spy to intercept method calls
                                              ZipArchiveInputStream zaisSpy = spy(zais);
                                              
                                              // Mock the private method behaviors
                                              when(supportsDataDescriptorFor.invoke(zaisSpy, entry)).thenReturn(false);
                                              when(supportsCompressedSizeFor.invoke(zaisSpy, entry)).thenReturn(false);
                                              
                                              // Test the method
                                              boolean result = zaisSpy.canReadEntryData(entry);
                                              
                                              // Verify the result
                                              assertFalse(result);
                                          }

 @Test
  public void testSupportsDataDescriptorFor_DeflatedEntry_ShouldReturnTrue() throws Exception {
      // Setup
      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
      GeneralPurposeBit bit = mock(GeneralPurposeBit.class);
      
      // Configure mocks to create the scenario where:
      // - uses data descriptor (first condition false)
      // - not stored (second condition irrelevant)
      // - not enhanced deflated (fourth condition false)
      // Only way to return true is via DEFLATED check (third condition)
      when(entry.getGeneralPurposeBit()).thenReturn(bit);
      when(bit.usesDataDescriptor()).thenReturn(true);
      when(entry.getMethod()).thenReturn(ZipEntry.DEFLATED);
      
      // Create instance with allowStoredEntriesWithDataDescriptor=false to make second condition false
      ZipArchiveInputStream zais = new ZipArchiveInputStream(
          new ByteArrayInputStream(new byte[0]), 
          "UTF-8", 
          true, 
          false
      );
      
      // Test - original should return true, mutant will return false
      assertTrue(zais.supportsDataDescriptorFor(entry));
      
      // Verify mock interactions
      verify(entry).getGeneralPurposeBit();
      verify(bit).usesDataDescriptor();
      verify(entry, atLeastOnce()).getMethod();
  }

 @Test
 public void testSupportsDataDescriptorFor_NonDeflatedEntry_ShouldReturnFalse() throws Exception {
     // Arrange
     ZipArchiveInputStream zais = new ZipArchiveInputStream(
         new ByteArrayInputStream(new byte[0]), "UTF-8", true, false);
     
     // Create a mock entry that:
     // - Uses data descriptor (so first condition false)
     // - Not STORED type (so second condition false)
     // - Not DEFLATED or ENHANCED_DEFLATED (so original would return false)
     ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
     GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
     when(gpb.usesDataDescriptor()).thenReturn(true);
     when(entry.getGeneralPurposeBit()).thenReturn(gpb);
     when(entry.getMethod()).thenReturn(99); // Some non-supported method
     
     // Act
     boolean result = zais.supportsDataDescriptorFor(entry);
     
     // Assert
     assertFalse("Should return false for non-DEFLATED entry when other conditions are false", 
                result);
 }

}
