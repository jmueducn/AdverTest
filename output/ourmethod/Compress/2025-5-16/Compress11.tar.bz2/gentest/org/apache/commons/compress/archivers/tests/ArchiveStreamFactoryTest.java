package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_ZipFormat() throws Exception {
                                                                                                                                                                                                                                                                                                     // ZIP signature: 50 4B 03 04
                                                                                                                                                                                                                                                                                                     byte[] zipSignature = {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                                                                                     InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_JarFormat() throws Exception {
                                                                                                                                                                                                                                                                                                     // JAR signature is same as ZIP
                                                                                                                                                                                                                                                                                                     byte[] jarSignature = {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                                                                                     InputStream input = new ByteArrayInputStream(jarSignature);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Mock the matches method to return true for JAR
                                                                                                                                                                                                                                                                                                     InputStream spyInput = spy(input);
                                                                                                                                                                                                                                                                                                     when(JarArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(spyInput);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_ArFormat() throws Exception {
                                                                                                                                                                                                                                                                                                     // AR signature: "!<arch>"
                                                                                                                                                                                                                                                                                                     byte[] arSignature = "!<arch>".getBytes();
                                                                                                                                                                                                                                                                                                     InputStream input = new ByteArrayInputStream(arSignature);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Mock the matches method to return true for AR
                                                                                                                                                                                                                                                                                                     InputStream spyInput = spy(input);
                                                                                                                                                                                                                                                                                                     when(ArArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(spyInput);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_CpioFormat() throws Exception {
                                                                                                                                                                                                                                                                                                     // CPIO signature varies by format, but we'll mock the matches method
                                                                                                                                                                                                                                                                                                     byte[] cpioSignature = new byte[12];
                                                                                                                                                                                                                                                                                                     InputStream input = new ByteArrayInputStream(cpioSignature);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Mock the matches method to return true for CPIO
                                                                                                                                                                                                                                                                                                     InputStream spyInput = spy(input);
                                                                                                                                                                                                                                                                                                     when(CpioArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(spyInput);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_DumpFormat() throws Exception {
                                                                                                                                                                                                                                                                                                     // Dump signature: "DUMP"
                                                                                                                                                                                                                                                                                                     byte[] dumpSignature = new byte[32];
                                                                                                                                                                                                                                                                                                     System.arraycopy("DUMP".getBytes(), 0, dumpSignature, 0, 4);
                                                                                                                                                                                                                                                                                                     InputStream input = new ByteArrayInputStream(dumpSignature);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Mock the matches method to return true for DUMP
                                                                                                                                                                                                                                                                                                     InputStream spyInput = spy(input);
                                                                                                                                                                                                                                                                                                     when(DumpArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(spyInput);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_TarFormat() throws Exception {
                                                                                                                                                                                                                                                                                                     // Tar signature is complex, but we'll mock the matches method
                                                                                                                                                                                                                                                                                                     byte[] tarSignature = new byte[512];
                                                                                                                                                                                                                                                                                                     InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Mock the matches method to return true for TAR
                                                                                                                                                                                                                                                                                                     InputStream spyInput = spy(input);
                                                                                                                                                                                                                                                                                                     when(TarArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(spyInput);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_UnknownArchiver() throws Exception {
                                                                                                                                                                                                                                                                                             // Setup expected exception rule
                                                                                                                                                                                                                                                                                             ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Create mock input stream
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Create factory instance
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Set expectations
                                                                                                                                                                                                                                                                                             thrown.expect(ArchiveException.class);
                                                                                                                                                                                                                                                                                             thrown.expectMessage("Archiver: UNKNOWN not found.");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                                                                             factory.createArchiveInputStream("UNKNOWN", mockInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_AR() throws Exception {
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                             assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_ZIP() throws Exception {
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                             assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_TAR() throws Exception {
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                             assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_JAR() throws Exception {
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInputStream);
                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                             assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_CPIO() throws Exception {
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                             assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_DUMP() throws Exception {
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInputStream);
                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                             assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_CaseInsensitive() throws Exception {
                                                                                                                                                                                                                                                                                             // Initialize required objects
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Test AR case insensitive
                                                                                                                                                                                                                                                                                             ArchiveInputStream result1 = factory.createArchiveInputStream("ar", mockInputStream);
                                                                                                                                                                                                                                                                                             assertTrue(result1 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Test ZIP case insensitive
                                                                                                                                                                                                                                                                                             ArchiveInputStream result2 = factory.createArchiveInputStream("ZiP", mockInputStream);
                                                                                                                                                                                                                                                                                             assertTrue(result2 instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Test TAR case insensitive
                                                                                                                                                                                                                                                                                             ArchiveInputStream result3 = factory.createArchiveInputStream("tAr", mockInputStream);
                                                                                                                                                                                                                                                                                             assertTrue(result3 instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testCreateArchiveInputStream_UnknownFormat() {
                                                                                                                                                                                                                                                                                             byte[] unknownSignature = new byte[12];
                                                                                                                                                                                                                                                                                             InputStream input = new ByteArrayInputStream(unknownSignature);
                                                                                                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                                 factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                                                                                 fail("Expected ArchiveException");
                                                                                                                                                                                                                                                                                             } catch (ArchiveException e) {
                                                                                                                                                                                                                                                                                                 assertEquals("No Archiver found for the stream signature", e.getMessage());
                                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                                 fail("Unexpected exception: " + e.getClass().getName());
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                     public void testCreateArchiveInputStream_UnsupportedMark() throws Exception {
                                                                                                                                                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                         when(input.markSupported()).thenReturn(false);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                                             factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                                                                             fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                                                                                         } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                                                             assertEquals("Mark is not supported.", e.getMessage());
                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_NullArchiverName() {
                                                                                                                                                                                                                                                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                                         fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                         assertEquals("Archivername must not be null.", e.getMessage());
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                 public void testCreateArchiveInputStream_NullInputStream() {
                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                                         fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                         assertEquals("InputStream must not be null.", e.getMessage());
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                             public void testCreateArchiveInputStream_NullStream() throws Exception {
                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                     factory.createArchiveInputStream((InputStream) null);
                                                                                                                                                                                                                                                     fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                     assertEquals("Stream must not be null.", e.getMessage());
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                     public void testCreateArchiveInputStream_TarFormatWithPartialHeader() throws Exception {
                                                                                                                                                                                                                                         // Create a partial tar header (less than 512 bytes)
                                                                                                                                                                                                                                         byte[] tarSignature = new byte[300];
                                                                                                                                                                                                                                         InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Spy the input stream to verify behavior
                                                                                                                                                                                                                                         InputStream spyInput = spy(input);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                             factory.createArchiveInputStream(spyInput);
                                                                                                                                                                                                                                             fail("Expected ArchiveException");
                                                                                                                                                                                                                                         } catch (ArchiveException e) {
                                                                                                                                                                                                                                             assertEquals("No Archiver found for the stream signature", e.getMessage());
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                             public void testCreateArchiveInputStream_IOException() throws Exception {
                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                 org.apache.commons.compress.archivers.ArchiveStreamFactory factory = 
                                                                                                                                                                                                                     new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                                                                                                                                                 
                                                                                                                                                                                                         {
                                                                                                                                                                                                                     org.junit.Assert.fail("Expected ArchiveException to be thrown");
                                                                                                                                                                                                         }{
                                                                                                                                                                                                                 }
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                         public void testCreateArchiveInputStream_ShouldResetInputStream() throws Exception {
                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                             String archiverName = ArchiveStreamFactory.ZIP; // Using ZIP as example
                                                                                                                                                                                                             InputStream in = mock(InputStream.class);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Simulate that the stream has been partially read
                                                                                                                                                                                                             when(in.read()).thenReturn(1, 2, 3, -1);
                                                                                                                                                                                                             in.read(); // Read first byte to move position
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Act
                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                             factory.createArchiveInputStream(archiverName, in);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Assert - verify reset was called exactly once
                                                                                                                                                                                                             verify(in, times(1)).reset();
                                                                                                                                                                                                         }

    @Test(expected = ArchiveException.class)
                                                                                                                                                                                                         public void testCreateArchiveInputStream_DetectsMissingReset() throws Exception {
                                                                                                                                                                                                             // Create a mock InputStream that tracks mark/reset operations
                                                                                                                                                                                                             InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Setup mock behavior
                                                                                                                                                                                                             when(mockIn.markSupported()).thenReturn(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // When mark is called, remember the position
                                                                                                                                                                                                             doAnswer(invocation -> {
                                                                                                                                                                                                                 // Simulate mark behavior
                                                                                                                                                                                                                 return null;
                                                                                                                                                                                                             }).when(mockIn).mark(anyInt());
                                                                                                                                                                                                             
                                                                                                                                                                                                             // When read is called, simulate reading signature
                                                                                                                                                                                                             when(mockIn.read(any(byte[].class))).thenReturn(12);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // When reset is called, verify it happens at the right time
                                                                                                                                                                                                             // The mutant will fail here because it skips reset()
                                                                                                                                                                                                             doThrow(new IOException("Reset not called")).when(mockIn).reset();
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create the factory and test
                                                                                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                             factory.createArchiveInputStream(mockIn);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify the interactions - this will fail for the mutant
                                                                                                                                                                                                             verify(mockIn, atLeastOnce()).reset();
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                            public void testCreateArchiveInputStreamForZip() throws Exception {
                                                                                                                                                                                                                // Prepare test data
                                                                                                                                                                                                                String zipArchiverName = ArchiveStreamFactory.ZIP;
                                                                                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create instance of class under test
                                                                                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Execute method
                                                                                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(zipArchiverName, mockInputStream);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify results
                                                                                                                                                                                                                assertNotNull("Result should not be null for ZIP archiver", result);
                                                                                                                                                                                                                assertTrue("Should return ZipArchiveInputStream for ZIP archiver", 
                                                                                                                                                                                                                          result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify the input stream was passed through
                                                                                                                                                                                                                verify(mockInputStream, never()).close(); // Verify basic interaction
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                       public void testCreateArchiveInputStream_DetectsZipFormat() throws Exception {
                                                                                                                                                                                                           // Arrange
                                                                                                                                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // ZIP signature (first 4 bytes are 'PK' signature)
                                                                                                                                                                                                           byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Configure mock behavior
                                                                                                                                                                                                           when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                                                                                           when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                                                                                               byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                               System.arraycopy(zipSignature, 0, buffer, 0, Math.min(zipSignature.length, buffer.length));
                                                                                                                                                                                                               return zipSignature.length;
                                                                                                                                                                                                           });
                                                                                                                                                                                                           
                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Act
                                                                                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Assert
                                                                                                                                                                                                           assertTrue("Should return ZipArchiveInputStream for ZIP format", 
                                                                                                                                                                                                                     result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testCreateArchiveInputStreamForJar() throws Exception {
                                                                                                                                                                                                           // Arrange
                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                           String archiverName = ArchiveStreamFactory.JAR; // Use the constant from class
                                                                                                                                                                                                           InputStream mockedInputStream = mock(InputStream.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Act
                                                                                                                                                                                                           Object result = factory.createArchiveInputStream(archiverName, mockedInputStream);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Assert
                                                                                                                                                                                                           assertNotNull("Result should not be null", result);
                                                                                                                                                                                                           assertTrue("Should return JarArchiveInputStream for JAR type", 
                                                                                                                                                                                                                     result instanceof JarArchiveInputStream);
                                                                                                                                                                                                       }

    @Test(expected = ArchiveException.class)
                                                                                                                                                                                                       public void testMutatedCreateArchiveInputStreamForJar() throws Exception {
                                                                                                                                                                                                           // This test would pass with the mutated code but fail with original code
                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                           String archiverName = ArchiveStreamFactory.JAR;
                                                                                                                                                                                                           InputStream mockedInputStream = mock(InputStream.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // This should throw ArchiveException with the mutated code
                                                                                                                                                                                                           factory.createArchiveInputStream(archiverName, mockedInputStream);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // If we reach here, the test fails (original code behavior)
                                                                                                                                                                                                           fail("Expected ArchiveException for JAR type with mutated code");
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                      public void testCreateArchiveInputStream_DetectsJarFormat() throws Exception {
                                                                                                                                                                                          // Create mock InputStream that provides JAR signature
                                                                                                                                                                                          InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                          
                                                                                                                                                                                          // JAR file signature bytes (first 4 bytes are 0x50, 0x4B, 0x03, 0x04)
                                                                                                                                                                                          byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                          
                                                                                                                                                                                          // Configure mock behavior
                                                                                                                                                                                          when(mockIn.markSupported()).thenReturn(true);
                                                                                                                                                                                          when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                                                                                                                              byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                              int offset = (int) invocation.getArguments()[1];
                                                                                                                                                                                              int length = (int) invocation.getArguments()[2];
                                                                                                                                                                                              System.arraycopy(jarSignature, 0, buffer, offset, Math.min(jarSignature.length, length));
                                                                                                                                                                                              return Math.min(jarSignature.length, length);
                                                                                                                                                                                          });
                                                                                                                                                                                          
                                                                                                                                                                                          // Create instance and test
                                                                                                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify the result is a JarArchiveInputStream
                                                                                                                                                                                          assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify interactions with the mock
                                                                                                                                                                                          verify(mockIn).mark(12);
                                                                                                                                                                                          verify(mockIn).reset();
                                                                                                                                                                                          verify(mockIn, never()).mark(32); // Shouldn't check larger signatures for JAR
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testCreateDumpArchiveInputStream() throws Exception {
                                                                                                                                                                                     // Create a minimal valid dump archive header
                                                                                                                                                                                     byte[] dumpHeader = new byte[32];
                                                                                                                                                                                     // Set the magic number for dump archive (0x6d, 0x75, 0x73, 0x74, 0x61, 0x72, 0x74)
                                                                                                                                                                                     byte[] dumpMagic = new byte[] {0x6d, 0x75, 0x73, 0x74, 0x61, 0x72, 0x74};
                                                                                                                                                                                     System.arraycopy(dumpMagic, 0, dumpHeader, 0, dumpMagic.length);
                                                                                                                                                                                     InputStream in = new ByteArrayInputStream(dumpHeader);
                                                                                                                                                                                     
                                                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                     ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, in);
                                                                                                                                                                                     
                                                                                                                                                                                     assertNotNull("Should return a DumpArchiveInputStream", ais);
                                                                                                                                                                                     assertEquals("Should be a DumpArchiveInputStream", 
                                                                                                                                                                                                  DumpArchiveInputStream.class, ais.getClass());
                                                                                                                                                                                     
                                                                                                                                                                                     // Try to read the header - this would fail with buffer size 0
                                                                                                                                                                                     try {
                                                                                                                                                                                         ais.read();
                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                         fail("Should be able to read from valid dump archive");
                                                                                                                                                                                     }
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                             public void testCreateArchiveInputStream_DetectsDumpFormat() throws Exception {
                                                                                                                                                                                 // Prepare a mock input stream that contains DUMP signature
                                                                                                                                                                                 byte[] dumpSignature = new byte[32];
                                                                                                                                                                                 // Fill with valid DUMP signature (first 6 bytes should be "070707" in octal)
                                                                                                                                                                                 System.arraycopy(new byte[] {0x07, 0x07, 0x07, 0x00, 0x00, 0x00}, 0, dumpSignature, 0, 6);
                                                                                                                                                                                 
                                                                                                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                 when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                                                                 when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                                                                     byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                     System.arraycopy(dumpSignature, 0, buf, 0, Math.min(dumpSignature.length, buf.length));
                                                                                                                                                                                     return buf.length;
                                                                                                                                                                                 });
                                                                                                                                                                                 
                                                                                                                                                                                 // Test the method
                                                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify it created a DumpArchiveInputStream
                                                                                                                                                                                 assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify the interactions - should have tried to read 32 bytes for DUMP signature
                                                                                                                                                                                 verify(mockInput, times(1)).mark(32);
                                                                                                                                                                                 org.mockito.ArgumentCaptor<byte[]> argument = org.mockito.ArgumentCaptor.forClass(byte[].class);
                                                                                                                                                                                 verify(mockInput, times(1)).read(argument.capture());
                                                                                                                                                                                 assertEquals(32, argument.getValue().length);
                                                                                                                                                                             }

    @Test
                                                                                                                                                                             public void testCreateTarArchiveInputStreamWithValidData() throws Exception {
                                                                                                                                                                                 // Prepare tar file data (minimal valid tar header)
                                                                                                                                                                                 byte[] tarData = new byte[512];
                                                                                                                                                                                 // Set magic bytes for tar
                                                                                                                                                                                 System.arraycopy("ustar".getBytes(), 0, tarData, 257, 5);
                                                                                                                                                                                 InputStream in = new ByteArrayInputStream(tarData);
                                                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                 
                                                                                                                                                                                 // Test the creation and reading capability
                                                                                                                                                                                 TarArchiveInputStream tarIn = (TarArchiveInputStream)factory.createArchiveInputStream(
                                                                                                                                                                                     ArchiveStreamFactory.TAR, in);
                                                                                                                                                                                 assertNotNull(tarIn);
                                                                                                                                                                                 
                                                                                                                                                                                 // Try to read the header - this would fail with 0-byte buffer
                                                                                                                                                                                 try {
                                                                                                                                                                                     assertNotNull(tarIn.getNextEntry());
                                                                                                                                                                                 } catch (IOException e) {
                                                                                                                                                                                     fail("Should be able to read tar entry with valid data");
                                                                                                                                                                                 }
                                                                                                                                                                             }

    @Test
                                                                                                                                            public void testCreateArchiveInputStream_TarFormat_DetectsWith512ByteBuffer() throws Exception {
                                                                                                                                                // Create mock input stream that returns TAR signature
                                                                                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                                                                                
                                                                                                                                                // Setup mock behavior
                                                                                                                                                when(mockIn.markSupported()).thenReturn(true);
                                                                                                                                                
                                                                                                                                                // First signature check (12 bytes)
                                                                                                                                                byte[] emptySignature = new byte[12];
                                                                                                                                                when(mockIn.read(any(byte[].class)))
                                                                                                                                                    .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                        @Override
                                                                                                                                                        public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                            System.arraycopy(emptySignature, 0, buf, 0, 12);
                                                                                                                                                            return 12;
                                                                                                                                                        }
                                                                                                                                                    });
                                                                                                                                                
                                                                                                                                                // Dump signature check (32 bytes)
                                                                                                                                                byte[] emptyDumpSig = new byte[32];
                                                                                                                                                when(mockIn.read(any(byte[].class)))
                                                                                                                                                    .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                        @Override
                                                                                                                                                        public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                            System.arraycopy(emptyDumpSig, 0, buf, 0, 32);
                                                                                                                                                            return 32;
                                                                                                                                                        }
                                                                                                                                                    });
                                                                                                                                                
                                                                                                                                                // TAR signature check (512 bytes)
                                                                                                                                                byte[] tarSignature = new byte[512];
                                                                                                                                                // Set magic bytes for TAR format at appropriate offset
                                                                                                                                                System.arraycopy("ustar".getBytes(), 0, tarSignature, 257, 5);
                                                                                                                                                when(mockIn.read(any(byte[].class)))
                                                                                                                                                    .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                        @Override
                                                                                                                                                        public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                            System.arraycopy(tarSignature, 0, buf, 0, 512);
                                                                                                                                                            return 512;
                                                                                                                                                        }
                                                                                                                                                    });
                                                                                                                                                
                                                                                                                                                // Test the method
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                                                                
                                                                                                                                                // Verify - should return TarArchiveInputStream
                                                                                                                                                assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                
                                                                                                                                                // Verify mock interactions
                                                                                                                                                verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                                                                                verify(mockIn, atLeastOnce()).reset();
                                                                                                                                            }

    @Test
                                                                                                                                            public void testCreateArchiveInputStreamForTarShouldReturnTarArchiveInputStream() throws Exception {
                                                                                                                                                // Arrange
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                String tarArchiverName = ArchiveStreamFactory.TAR;
                                                                                                                                                
                                                                                                                                                // Act
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(tarArchiverName, mockInputStream);
                                                                                                                                                
                                                                                                                                                // Assert
                                                                                                                                                assertNotNull("Result should not be null for valid TAR archiver", result);
                                                                                                                                                assertTrue("Should return TarArchiveInputStream for TAR archiver", 
                                                                                                                                                          result instanceof TarArchiveInputStream);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testCreateArchiveInputStream_DetectsTarFormat() throws Exception {
                                                                                                                                                // Create mock InputStream that provides TAR signature
                                                                                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                                                                                
                                                                                                                                                // Setup mock behavior
                                                                                                                                                // First 12 bytes read (initial signature check)
                                                                                                                                                when(mockIn.markSupported()).thenReturn(true);
                                                                                                                                                byte[] fakeSignature = new byte[12];
                                                                                                                                                when(mockIn.read(any(byte[].class))).thenReturn(fakeSignature.length);
                                                                                                                                                
                                                                                                                                                // Setup for TAR header check (512 bytes)
                                                                                                                                                byte[] tarSignature = new byte[512];
                                                                                                                                                // Set first 257 bytes to match TAR signature (ustar)
                                                                                                                                                tarSignature[257] = 'u';
                                                                                                                                                tarSignature[258] = 's';
                                                                                                                                                tarSignature[259] = 't';
                                                                                                                                                tarSignature[260] = 'a';
                                                                                                                                                tarSignature[261] = 'r';
                                                                                                                                                
                                                                                                                                                // Mock the read operations
                                                                                                                                                when(mockIn.read(any(byte[].class)))
                                                                                                                                                    .thenReturn(fakeSignature.length)  // first read (12 bytes)
                                                                                                                                                    .thenReturn(tarSignature.length);  // second read (512 bytes)
                                                                                                                                                
                                                                                                                                                // Create instance and test
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                                                                
                                                                                                                                                // Verify the result is a TarArchiveInputStream
                                                                                                                                                assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                
                                                                                                                                                // Verify mark/reset operations were called
                                                                                                                                                verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                                                                                verify(mockIn, atLeastOnce()).reset();
                                                                                                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                           public void testCreateArchiveInputStream_NullArchiverName1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               factory.createArchiveInputStream(null, input);
                                                                                                                                           }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                           public void testCreateArchiveInputStream_NullInputStream1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_AR1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, input);
                                                                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_ZIP1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, input);
                                                                                                                                               assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_TAR1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                               assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_JAR1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                               assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_CPIO1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, input);
                                                                                                                                               assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_DUMP1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, input);
                                                                                                                                               assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_CaseInsensitive1() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream("ar", input);
                                                                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                           }

    @Test(expected = ArchiveException.class)
                                                                                                                                           public void testCreateArchiveInputStream_UnsupportedArchive() throws Exception {
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                               factory.createArchiveInputStream("UNSUPPORTED", input);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testCreateArchiveInputStream_TarExactly512Bytes() throws Exception {
                                                                                                                                               // Create a mock tar header of exactly 512 bytes
                                                                                                                                               byte[] tarHeader = new byte[512];
                                                                                                                                               // Make it look like a tar file (ustar magic number at offset 257)
                                                                                                                                               System.arraycopy("ustar".getBytes(), 0, tarHeader, 257, 5);
                                                                                                                                               
                                                                                                                                               // Mock InputStream that returns exactly 512 bytes when read
                                                                                                                                               InputStream in = new ByteArrayInputStream(tarHeader) {
                                                                                                                                                   private boolean firstRead = true;
                                                                                                                                                   
                                                                                                                                                   @Override
                                                                                                                                                   public int read(byte[] b) throws IOException {
                                                                                                                                                       if (firstRead) {
                                                                                                                                                           firstRead = false;
                                                                                                                                                           System.arraycopy(tarHeader, 0, b, 0, 512);
                                                                                                                                                           return 512; // Exactly 512 bytes read
                                                                                                                                                       }
                                                                                                                                                       return -1;
                                                                                                                                                   }
                                                                                                                                                   
                                                                                                                                                   @Override
                                                                                                                                                   public boolean markSupported() {
                                                                                                                                                       return true;
                                                                                                                                                   }
                                                                                                                                               };
                                                                                                                                       
                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                                                               
                                                                                                                                               // Verify the correct type is returned
                                                                                                                                               assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                           }

    @Test
                                                                                                                                      public void testCreateArchiveInputStreamResetsStream() throws Exception {
                                                                                                                                          // Create a mock InputStream that can verify reset() calls
                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                          
                                                                                                                                          // Create a spy to track method calls on the mock
                                                                                                                                          doNothing().when(mockInputStream).reset();
                                                                                                                                          
                                                                                                                                          // Call the method with a valid archiver name
                                                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                          factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                                                                                          
                                                                                                                                          // Verify reset() was called exactly once
                                                                                                                                          verify(mockInputStream, times(1)).reset();
                                                                                                                                          
                                                                                                                                          // For completeness, test with another archiver type
                                                                                                                                          factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                                                                          verify(mockInputStream, times(2)).reset();
                                                                                                                                      }

    @Test
                                                                                                                                 public void testCreateArchiveInputStream_VerifiesResetAfterSignatureRead() throws Exception {
                                                                                                                                     // Create a mock input stream that can verify reset operations
                                                                                                                                     InputStream in = mock(InputStream.class);
                                                                                                                                     
                                                                                                                                     // Setup mock behavior
                                                                                                                                     when(in.markSupported()).thenReturn(true);
                                                                                                                                     
                                                                                                                                     // First signature read (12 bytes)
                                                                                                                                     byte[] zipSignature = new byte[12];
                                                                                                                                     // Fill array with 0x50 (PK header for ZIP) without using Arrays.fill()
                                                                                                                                     for (int i = 0; i < zipSignature.length; i++) {
                                                                                                                                         zipSignature[i] = (byte) 0x50;
                                                                                                                                     }
                                                                                                                                     when(in.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                         byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                         System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                                                                         return zipSignature.length;
                                                                                                                                     });
                                                                                                                                     
                                                                                                                                     // Create the factory and test
                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                     ArchiveInputStream ais = factory.createArchiveInputStream(in);
                                                                                                                                     
                                                                                                                                     // Verify the interactions - critical reset() calls
                                                                                                                                     verify(in, atLeastOnce()).mark(anyInt()); // Should mark before reading
                                                                                                                                     verify(in, atLeast(2)).reset(); // Should reset after each signature read attempt
                                                                                                                                     
                                                                                                                                     // Additional verification that we got a ZIP stream
                                                                                                                                     assertTrue(ais instanceof ZipArchiveInputStream);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testCreateArchiveInputStreamForZip1() throws Exception {
                                                                                                                                     // Prepare test data
                                                                                                                                     String zipArchiverName = ArchiveStreamFactory.ZIP;
                                                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                     
                                                                                                                                     // Create factory instance
                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                     
                                                                                                                                     // Execute method
                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(zipArchiverName, mockInputStream);
                                                                                                                                     
                                                                                                                                     // Verify results
                                                                                                                                     assertNotNull("Result should not be null for ZIP format", result);
                                                                                                                                     assertTrue("Should return ZipArchiveInputStream for ZIP format", 
                                                                                                                                               result instanceof ZipArchiveInputStream);
                                                                                                                                     
                                                                                                                                     // Verify the input stream was properly passed to the ZipArchiveInputStream
                                                                                                                                     // This is implementation-specific, but generally we can verify the stream was used
                                                                                                                                     verify(mockInputStream, atLeastOnce()).read(any(byte[].class));
                                                                                                                                 }

    @Test
                                                                                                                            public void testCreateArchiveInputStream_DetectsZipFormat1() throws Exception {
                                                                                                                                // Arrange
                                                                                                                                InputStream mockInput = mock(InputStream.class);
                                                                                                                                
                                                                                                                                // Mock behavior for markSupported
                                                                                                                                when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                
                                                                                                                                // Mock ZIP signature bytes (first 4 bytes are 'PK' header)
                                                                                                                                byte[] zipSignature = new byte[]{0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                    byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                                                    System.arraycopy(zipSignature, 0, buffer, 0, Math.min(zipSignature.length, buffer.length));
                                                                                                                                    return zipSignature.length;
                                                                                                                                });
                                                                                                                                
                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                
                                                                                                                                // Act
                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                                                
                                                                                                                                // Assert
                                                                                                                                assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                            }

    @Test
                                                                                                                            public void testCreateArchiveInputStreamForJar1() throws Exception {
                                                                                                                                // Prepare test data
                                                                                                                                String archiverName = ArchiveStreamFactory.JAR;
                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                
                                                                                                                                // Create instance of class under test
                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                
                                                                                                                                // Execute method
                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(archiverName, mockInputStream);
                                                                                                                                
                                                                                                                                // Verify results
                                                                                                                                assertNotNull("Result should not be null", result);
                                                                                                                                assertTrue("Should return JarArchiveInputStream", 
                                                                                                                                          result instanceof JarArchiveInputStream);
                                                                                                                                
                                                                                                                                // Verify the input stream was passed through
                                                                                                                                verify(mockInputStream, never()).close(); // Verify stream wasn't closed
                                                                                                                            }

    @Test
                                                                                                                       public void testMutatedCodeFailsToDetectJarFormat() throws Exception {
                                                                                                                           // This test would pass with the mutated code (where JAR detection is disabled)
                                                                                                                           // but we expect it to fail with the original code
                                                                                                                           
                                                                                                                           // Create a mock InputStream that returns JAR signature
                                                                                                                           InputStream mockIn = mock(InputStream.class);
                                                                                                                           
                                                                                                                           // JAR signature bytes
                                                                                                                           byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                           
                                                                                                                           // Configure mock behavior
                                                                                                                           when(mockIn.markSupported()).thenReturn(true);
                                                                                                                           when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                               byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                                               System.arraycopy(jarSignature, 0, buffer, 0, Math.min(jarSignature.length, buffer.length));
                                                                                                                               return jarSignature.length;
                                                                                                                           });
                                                                                                                           
                                                                                                                           // Create factory and test
                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                           
                                                                                                                           // With the mutated code, this should throw ArchiveException
                                                                                                                           // because JAR detection is disabled and no other format matches
                                                                                                                           factory.createArchiveInputStream(mockIn);
                                                                                                                       }

    @Test
                                                                                                           public void testCreateArchiveInputStreamDetectsJarFormat() throws Exception {
                                                                                                               // Create a mock InputStream that returns JAR signature
                                                                                                               InputStream mockIn = mock(InputStream.class);
                                                                                                               
                                                                                                               // JAR signature bytes (first 4 bytes are 'PK' magic number + 0x03 0x04)
                                                                                                               byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                               
                                                                                                               // Configure mock behavior
                                                                                                               when(mockIn.markSupported()).thenReturn(true);
                                                                                                               when(mockIn.read(any(byte[].class)))
                                                                                                                   .thenAnswer(invocation -> {
                                                                                                                       byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                                       System.arraycopy(jarSignature, 0, buffer, 0, Math.min(jarSignature.length, buffer.length));
                                                                                                                       return jarSignature.length;
                                                                                                                   });
                                                                                                               
                                                                                                               // Create factory and test
                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                               
                                                                                                               // Verify the result is a JarArchiveInputStream
                                                                                                               assertTrue(result instanceof JarArchiveInputStream);
                                                                                                               
                                                                                                               // Verify mark and read operations were called
                                                                                                               verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                                               verify(mockIn, atLeastOnce()).read(any(byte[].class));
                                                                                                               verify(mockIn, atLeastOnce()).reset();
                                                                                                           }

    @Test
                                                                                                      public void testCreateDumpArchiveInputStreamWithValidData() throws Exception {
                                                                                                          // Prepare test data
                                                                                                          String archiverName = "dump"; // Using string literal instead of constant
                                                                                                          byte[] testData = new byte[32]; // Minimum valid dump archive header
                                                                                                          java.util.Arrays.fill(testData, (byte) 1); // Fill with dummy data
                                                                                                          java.io.InputStream in = new java.io.ByteArrayInputStream(testData);
                                                                                                          
                                                                                                          // Create the stream
                                                                                                          org.apache.commons.compress.archivers.ArchiveStreamFactory factory = 
                                                                                                              new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                                          org.apache.commons.compress.archivers.ArchiveInputStream result = 
                                                                                                              factory.createArchiveInputStream(archiverName, in);
                                                                                                          
                                                                                                          // Verify it's a DumpArchiveInputStream
                                                                                                          assertTrue(result instanceof org.apache.commons.compress.archivers.dump.DumpArchiveInputStream);
                                                                                                          
                                                                                                          // Test the buffer size by trying to read the header
                                                                                                          try {
                                                                                                              // This will fail with ArrayIndexOutOfBoundsException if buffer size is 0
                                                                                                              result.getNextEntry();
                                                                                                              // If we get here, the buffer size is sufficient (original behavior)
                                                                                                          } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                              fail("Dump archive reading failed due to insufficient buffer size");
                                                                                                          }
                                                                                                      }

    @Test
                                                                                                      public void testCreateArchiveInputStream_DetectsDumpFormat1() throws Exception {
                                                                                                          // Create a mock input stream with dump signature
                                                                                                          InputStream mockIn = mock(InputStream.class);
                                                                                                          
                                                                                                          // Setup mock behavior
                                                                                                          when(mockIn.markSupported()).thenReturn(true);
                                                                                                          
                                                                                                          // Dump signature bytes (simplified for test)
                                                                                                          byte[] dumpSignature = new byte[32];
                                                                                                          // Fill with some dump signature pattern
                                                                                                          dumpSignature[0] = 0x1F;
                                                                                                          dumpSignature[1] = 0x45;
                                                                                                          
                                                                                                          // First read (for initial signature check)
                                                                                                          when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                              byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                              System.arraycopy(dumpSignature, 0, buf, 0, Math.min(buf.length, dumpSignature.length));
                                                                                                              return buf.length;
                                                                                                          });
                                                                                                          
                                                                                                          // Create factory and test
                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                          
                                                                                                          // Verify it created DumpArchiveInputStream
                                                                                                          assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                          
                                                                                                          // Verify mark was called with proper buffer sizes
                                                                                                          verify(mockIn).mark(12); // initial signature buffer
                                                                                                          verify(mockIn).mark(32); // dump signature buffer
                                                                                                          verify(mockIn, atLeastOnce()).reset();
                                                                                                      }

    @Test
                                                                                                      public void testCreateTarArchiveInputStreamWithValidHeader() throws Exception {
                                                                                                          // Prepare a minimal valid TAR header (512 bytes)
                                                                                                          byte[] tarData = new byte[512];
                                                                                                          // Set the magic number for TAR files
                                                                                                          System.arraycopy("ustar".getBytes(), 0, tarData, 257, 5);
                                                                                                          
                                                                                                          ByteArrayInputStream in = new ByteArrayInputStream(tarData);
                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                          
                                                                                                          // This will throw an exception if the internal buffer is size 0
                                                                                                          ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, in);
                                                                                                          assertTrue(ais instanceof TarArchiveInputStream);
                                                                                                          
                                                                                                          // Verify we can actually read the header
                                                                                                          try {
                                                                                                              ais.getNextEntry();
                                                                                                              // If we get here, the buffer was properly sized
                                                                                                          } catch (IOException e) {
                                                                                                              fail("Failed to read TAR header - likely due to incorrect buffer size");
                                                                                                          }
                                                                                                      }

    @Test
                                                                                                 public void testCreateArchiveInputStreamForTarWithValidHeader() throws Exception {
                                                                                                     // Create a mock InputStream that returns a valid TAR header
                                                                                                     byte[] tarSignature = new byte[512];
                                                                                                     // Fill with valid TAR header data (ustar magic number)
                                                                                                     System.arraycopy("ustar".getBytes(), 0, tarSignature, 257, 5);
                                                                                                     
                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                     when(mockInput.markSupported()).thenReturn(true);
                                                                                                     
                                                                                                     // Setup mock to return different responses based on read length
                                                                                                     when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                         byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                         if (buf.length >= 512) {
                                                                                                             System.arraycopy(tarSignature, 0, buf, 0, Math.min(tarSignature.length, buf.length));
                                                                                                             return buf.length;
                                                                                                         } else if (buf.length >= 32) {
                                                                                                             System.arraycopy(new byte[32], 0, buf, 0, Math.min(32, buf.length));
                                                                                                             return 32;
                                                                                                         } else {
                                                                                                             System.arraycopy(new byte[12], 0, buf, 0, Math.min(12, buf.length));
                                                                                                             return 12;
                                                                                                         }
                                                                                                     });
                                                                                                     
                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                     
                                                                                                     // Verify it created a TarArchiveInputStream
                                                                                                     assertTrue(result instanceof TarArchiveInputStream);
                                                                                                     
                                                                                                     // Verify the mock interactions
                                                                                                     verify(mockInput, atLeastOnce()).mark(anyInt());
                                                                                                     verify(mockInput, atLeastOnce()).reset();
                                                                                                 }

    @Test
                                                                                                 public void testCreateArchiveInputStreamForTarShouldReturnTarArchiveInputStream1() throws Exception {
                                                                                                     // Prepare test data
                                                                                                     String tarArchiverName = ArchiveStreamFactory.TAR;
                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                     
                                                                                                     // Create instance of class under test
                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                     
                                                                                                     // Execute method
                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(tarArchiverName, mockInputStream);
                                                                                                     
                                                                                                     // Verify results
                                                                                                     assertNotNull("Result should not be null", result);
                                                                                                     assertTrue("Should return TarArchiveInputStream", 
                                                                                                               result instanceof TarArchiveInputStream);
                                                                                                     
                                                                                                     // Verify the mutant by ensuring the correct stream type was created
                                                                                                     // The mutant would throw ArchiveException instead
                                                                                                     TarArchiveInputStream tarStream = (TarArchiveInputStream) result;
                                                                                                     // Additional verification that the stream was properly initialized
                                                                                                     // (implementation detail may vary based on actual TarArchiveInputStream)
                                                                                                 }

    @Test(expected = ArchiveException.class)
                                                                                                 public void testCreateArchiveInputStreamForInvalidTarShouldThrowException() throws Exception {
                                                                                                     // This test would pass for both original and mutant, showing the mutant is not caught
                                                                                                     // Included to show what wouldn't catch the mutant
                                                                                                     String invalidArchiverName = "INVALID_TAR";
                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                     
                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                     factory.createArchiveInputStream(invalidArchiverName, mockInputStream);
                                                                                                 }

    @Test
                                                                                            public void testCreateArchiveInputStreamDetectsTarFiles() throws Exception {
                                                                                                // Create a mock InputStream that provides TAR signature
                                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                                
                                                                                                // Setup mock behavior:
                                                                                                // - First mark/reset for 12-byte signature check
                                                                                                // - Then mark/reset for 32-byte dump signature check
                                                                                                // - Finally provide valid TAR header (512 bytes)
                                                                                                byte[] tarSignature = new byte[512];
                                                                                                // Set first bytes to match TAR signature (ustar)
                                                                                                tarSignature[257] = 'u';
                                                                                                tarSignature[258] = 's';
                                                                                                tarSignature[259] = 't';
                                                                                                tarSignature[260] = 'a';
                                                                                                tarSignature[261] = 'r';
                                                                                                
                                                                                                when(mockIn.markSupported()).thenReturn(true);
                                                                                                when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                    byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                    if (buf.length == 12 || buf.length == 32) {
                                                                                                        return -1; // Not matching other archive types
                                                                                                    } else if (buf.length == 512) {
                                                                                                        System.arraycopy(tarSignature, 0, buf, 0, 512);
                                                                                                        return 512;
                                                                                                    }
                                                                                                    return -1;
                                                                                                });
                                                                                                
                                                                                                // Create factory and test
                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                
                                                                                                // Verify we got a TarArchiveInputStream
                                                                                                assertTrue(result instanceof TarArchiveInputStream);
                                                                                                
                                                                                                // Verify proper stream interactions
                                                                                                verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                                verify(mockIn, atLeastOnce()).reset();
                                                                                            }

    @Test
                                                                                        public void testCreateTarArchiveInputStream() throws Exception {
                                                                                            // Arrange
                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                            InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                            
                                                                                            // Act
                                                                                            ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                            
                                                                                            // Assert
                                                                                            assertNotNull("Returned TarArchiveInputStream should not be null", result);
                                                                                            assertTrue("Returned stream should be TarArchiveInputStream", 
                                                                                                       result instanceof TarArchiveInputStream);
                                                                                        }

    @Test
                                                                                       public void testCreateArchiveInputStream_DetectsTarWhenInitialSignatureFails() throws Exception {
                                                                                           // Create a mock InputStream that returns:
                                                                                           // - First 12 bytes that don't match any known signature
                                                                                           // - Followed by valid TAR header data
                                                                                           InputStream mockIn = mock(InputStream.class);
                                                                                           
                                                                                           // First mark/reset cycle (12 byte signature check)
                                                                                           when(mockIn.markSupported()).thenReturn(true);
                                                                                           byte[] fakeSignature = new byte[12]; // Doesn't match any known format
                                                                                           when(mockIn.read(any(byte[].class))).thenAnswer(inv -> {
                                                                                               byte[] buf = (byte[]) inv.getArguments()[0];
                                                                                               System.arraycopy(fakeSignature, 0, buf, 0, Math.min(fakeSignature.length, buf.length));
                                                                                               return fakeSignature.length;
                                                                                           });
                                                                                           
                                                                                           // Second mark/reset cycle (32 byte dump signature check)
                                                                                           byte[] fakeDumpSig = new byte[32]; // Doesn't match dump format
                                                                                           when(mockIn.read(any(byte[].class))).thenAnswer(inv -> {
                                                                                               byte[] buf = (byte[]) inv.getArguments()[0];
                                                                                               System.arraycopy(fakeDumpSig, 0, buf, 0, Math.min(fakeDumpSig.length, buf.length));
                                                                                               return fakeDumpSig.length;
                                                                                           });
                                                                                           
                                                                                           // Third mark/reset cycle (512 byte tar header check)
                                                                                           byte[] validTarHeader = new byte[512];
                                                                                           // Set up a valid tar header (ustar magic number at offset 257)
                                                                                           System.arraycopy("ustar".getBytes(), 0, validTarHeader, 257, 5);
                                                                                           when(mockIn.read(any(byte[].class))).thenAnswer(inv -> {
                                                                                               byte[] buf = (byte[]) inv.getArguments()[0];
                                                                                               System.arraycopy(validTarHeader, 0, buf, 0, Math.min(validTarHeader.length, buf.length));
                                                                                               return validTarHeader.length;
                                                                                           });
                                                                                       
                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                           
                                                                                           // Verify that we got a TarArchiveInputStream
                                                                                           assertTrue(result instanceof TarArchiveInputStream);
                                                                                       }

    @Test
                                                                                       public void testCreateArchiveInputStreamForZip2() throws Exception {
                                                                                           // Prepare test data
                                                                                           String archiverName = ArchiveStreamFactory.ZIP; // Use the constant from class
                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                           
                                                                                           // Call the method under test
                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(archiverName, mockInputStream);
                                                                                           
                                                                                           // Verify the result
                                                                                           assertNotNull("Result should not be null for valid ZIP archiver", result);
                                                                                           assertTrue("Should return ZipArchiveInputStream for ZIP archiver", 
                                                                                                     result instanceof ZipArchiveInputStream);
                                                                                       }

    @Test
                                                                                  public void testCreateArchiveInputStream_DetectsZipFile() throws Exception {
                                                                                      // Arrange
                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                      
                                                                                      // Setup mock to support mark/reset
                                                                                      when(mockInput.markSupported()).thenReturn(true);
                                                                                      
                                                                                      // ZIP signature bytes (first 4 bytes are 0x50, 0x4B, 0x03, 0x04)
                                                                                      byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                      
                                                                                      // Mock the read behavior to return ZIP signature
                                                                                      when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                          byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                          System.arraycopy(zipSignature, 0, buffer, 0, Math.min(zipSignature.length, buffer.length));
                                                                                          return zipSignature.length;
                                                                                      });
                                                                                      
                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                      
                                                                                      // Act
                                                                                      ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                      
                                                                                      // Assert
                                                                                      assertTrue("Should return ZipArchiveInputStream for ZIP signature", 
                                                                                                result instanceof ZipArchiveInputStream);
                                                                                  }

    @Test
                                                                                  public void testCreateArchiveInputStreamForJar2() throws Exception {
                                                                                      // Setup
                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                      
                                                                                      // Test JAR archive type
                                                                                      try {
                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput);
                                                                                          // Original behavior: should return JarArchiveInputStream
                                                                                          assertTrue("Should return JarArchiveInputStream for JAR type", 
                                                                                                    result instanceof JarArchiveInputStream);
                                                                                      } catch (ArchiveException e) {
                                                                                          // Mutated behavior: throws exception
                                                                                          fail("Method failed to recognize JAR archive type - mutant detected");
                                                                                      }
                                                                                      
                                                                                      // Test other archive types to ensure they still work
                                                                                      try {
                                                                                          ArchiveInputStream zipResult = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                                                                          assertNotNull("ZIP archive type should work", zipResult);
                                                                                      } catch (ArchiveException e) {
                                                                                          fail("ZIP archive type failed unexpectedly");
                                                                                      }
                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                  public void testNullArchiverName() throws Exception {
                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                      factory.createArchiveInputStream(null, mock(InputStream.class));
                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                  public void testNullInputStream() throws Exception {
                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                      factory.createArchiveInputStream(ArchiveStreamFactory.JAR, null);
                                                                                  }

    @Test(expected = ArchiveException.class)
                                                                                  public void testUnknownArchiveType() throws Exception {
                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                      factory.createArchiveInputStream("UNKNOWN", mock(InputStream.class));
                                                                                  }

    @Test
                                                                                  public void testCreateArchiveInputStream_DetectsJarFile() throws Exception {
                                                                                      // Arrange
                                                                                      InputStream mockIn = mock(InputStream.class);
                                                                                      
                                                                                      // Mock the stream to support mark/reset
                                                                                      when(mockIn.markSupported()).thenReturn(true);
                                                                                      
                                                                                      // Mock signature reading - return JAR signature
                                                                                      byte[] jarSignature = new byte[12];
                                                                                      // Actual JAR signature would be filled here, but for test we just need to mock the match
                                                                                      when(mockIn.read(any(byte[].class))).thenReturn(12);
                                                                                      when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(12);
                                                                                      
                                                                                      // Mock the matches method behavior
                                                                                      // This is a bit tricky since matches is static, but we can assume it works as expected
                                                                                      // In real test, we might need PowerMock or other tools to mock static methods
                                                                                      
                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                      
                                                                                      // Act
                                                                                      ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                      
                                                                                      // Assert
                                                                                      assertTrue(result instanceof JarArchiveInputStream);
                                                                                      
                                                                                      // Verify stream operations
                                                                                      verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                      verify(mockIn, atLeastOnce()).reset();
                                                                                  }

    @Test
                                                                              public void testCreateArchiveInputStream_DetectsJarFileWithRealSignature() throws Exception {
                                                                                  // Create input stream with actual JAR signature
                                                                                  byte[] jarSignature = new byte[] {
                                                                                      // Actual JAR signature bytes would go here
                                                                                      // Typically starts with 'PK' (ZIP/JAR signature)
                                                                                      0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x08, 0x00, 0x08, 0x00, 0x00, 0x00
                                                                                  };
                                                                                  InputStream in = new ByteArrayInputStream(jarSignature);
                                                                                  
                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                  ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                  
                                                                                  assertTrue(result instanceof JarArchiveInputStream);
                                                                              }

    @Test
                                                                            public void testCreateDumpArchiveInputStreamWithValidData1() throws Exception {
                                                                                // Prepare test data with valid dump archive signature (first 32 bytes are important)
                                                                                byte[] dumpData = new byte[32];
                                                                                // Fill with valid dump signature (simplified for test)
                                                                                java.util.Arrays.fill(dumpData, (byte) 0x12); // Example signature bytes
                                                                                
                                                                                java.io.InputStream mockInput = new java.io.ByteArrayInputStream(dumpData);
                                                                                org.apache.commons.compress.archivers.ArchiveStreamFactory factory = 
                                                                                    new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                
                                                                                // This will fail with the mutant since DumpArchiveInputStream won't be able 
                                                                                // to read the signature with buffer size 0
                                                                                try (org.apache.commons.compress.archivers.ArchiveInputStream in = 
                                                                                        factory.createArchiveInputStream(
                                                                                            org.apache.commons.compress.archivers.ArchiveStreamFactory.DUMP, 
                                                                                            mockInput)) {
                                                                                    assertNotNull("Should return valid stream for DUMP format", in);
                                                                                    assertTrue("Should return DumpArchiveInputStream instance", 
                                                                                              in instanceof org.apache.commons.compress.archivers.dump.DumpArchiveInputStream);
                                                                                    
                                                                                    // Verify we can read from the stream (would fail with mutant)
                                                                                    assertNotNull("Should be able to read archive entry", in.getNextEntry());
                                                                                }
                                                                            }

    @Test
                                                                        public void testCreateArchiveInputStream_DetectsDumpArchive() throws Exception {
                                                                            // Create a mock input stream that returns a valid DUMP signature
                                                                            byte[] dumpSignature = new byte[32];
                                                                            // Fill with valid DUMP signature bytes (actual signature pattern would go here)
                                                                            System.arraycopy(new byte[] {0x1F, 0x7D, 0x48, 0x45, 0x41, 0x44, 0x45, 0x52}, 
                                                                                            0, dumpSignature, 0, 8); // Example DUMP signature
                                                                            
                                                                            InputStream mockInput = mock(InputStream.class);
                                                                            when(mockInput.markSupported()).thenReturn(true);
                                                                            when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                if (buf.length == 12) {
                                                                                    // Return non-matching signature for initial check
                                                                                    return 12;
                                                                                } else if (buf.length == 32) {
                                                                                    // Copy DUMP signature when 32-byte buffer is requested
                                                                                    System.arraycopy(dumpSignature, 0, buf, 0, Math.min(32, dumpSignature.length));
                                                                                    return 32;
                                                                                }
                                                                                return -1;
                                                                            });
                                                                            
                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                            ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                            
                                                                            // Verify the returned stream is a DumpArchiveInputStream
                                                                            assertTrue("Should return DumpArchiveInputStream for DUMP signature", 
                                                                                       result instanceof DumpArchiveInputStream);
                                                                            
                                                                            // Verify the mock interactions
                                                                            verify(mockInput, atLeastOnce()).mark(32); // Verify 32-byte buffer was used
                                                                            verify(mockInput, atLeastOnce()).read(any(byte[].class)); // Verify read was called
                                                                        }

    @Test
                                                                        public void testCreateTarArchiveInputStreamCanReadTarFormat() throws Exception {
                                                                            // Create a minimal valid tar file in memory (requires 512-byte headers)
                                                                            byte[] tarFile = new byte[1024]; // Need at least 2 blocks (header + content)
                                                                            // Set tar header magic
                                                                            System.arraycopy("ustar".getBytes(), 0, tarFile, 257, 5);
                                                                            
                                                                            // Create input stream from our test tar data
                                                                            ByteArrayInputStream in = new ByteArrayInputStream(tarFile);
                                                                            
                                                                            // Create the archive stream through factory
                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                            ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, in);
                                                                            
                                                                            assertTrue(ais instanceof TarArchiveInputStream);
                                                                            
                                                                            // Try to read the archive - this will fail if header buffer is 0 bytes
                                                                            try {
                                                                                ais.getNextEntry(); // This requires proper header reading
                                                                                // If we get here, the 512-byte buffer is working
                                                                            } catch (IOException e) {
                                                                                fail("Failed to read tar header - likely caused by incorrect buffer size");
                                                                            }
                                                                        }

    @Test
                               public void testCreateArchiveInputStreamForTarWithMutantDetection() throws Exception {
                                   // Import necessary classes
                                   java.io.InputStream in = mock(java.io.InputStream.class);
                                   org.apache.commons.compress.archivers.ArchiveStreamFactory factory = 
                                       new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                   org.apache.commons.compress.archivers.ArchiveInputStream ais;
                                   org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarIn;
                                   
                                   // Setup mock behavior:
                                   // 1. First markSupported() check
                                   when(in.markSupported()).thenReturn(true);
                                   
                                   // 2. First signature read (12 bytes) - not matching any format
                                   byte[] emptySig = new byte[12];
                                   when(in.read(any(byte[].class)))
                                       .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                           @Override
                                           public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                               System.arraycopy(emptySig, 0, buf, 0, Math.min(emptySig.length, buf.length));
                                               return emptySig.length;
                                           }
                                       });
                                   
                                   // 3. Dump signature read (32 bytes) - not matching
                                   byte[] emptyDumpSig = new byte[32];
                                   when(in.read(any(byte[].class)))
                                       .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                           @Override
                                           public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                               System.arraycopy(emptyDumpSig, 0, buf, 0, Math.min(emptyDumpSig.length, buf.length));
                                               return emptyDumpSig.length;
                                           }
                                       });
                                   
                                   // 4. TAR header read - this is where mutant would fail
                                   // Create a valid TAR header
                                   byte[] tarHeader = new byte[512];
                                   // Set magic bytes for TAR format
                                   System.arraycopy("ustar".getBytes(), 0, tarHeader, 257, 5);
                                   
                                   // The test will fail here for the mutant because:
                                   // - Mutant uses 0-byte buffer so read returns 0
                                   // - Original uses 512-byte buffer and reads full header
                                   when(in.read(any(byte[].class)))
                                       .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                           @Override
                                           public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                               if (buf.length == 0) { // This is the mutant case
                                                   return 0;
                                               }
                                               System.arraycopy(tarHeader, 0, buf, 0, Math.min(tarHeader.length, buf.length));
                                               return tarHeader.length;
                                           }
                                       });
                                   
                                   // Create factory and test
                                   try {
                                       ais = factory.createArchiveInputStream(in);
                                       assertTrue(ais instanceof org.apache.commons.compress.archivers.tar.TarArchiveInputStream);
                                   } catch (org.apache.commons.compress.archivers.ArchiveException ex) {
                                       fail("Should have detected TAR format but got: " + ex.getMessage());
                                   }
                               }

    @Test
                               public void testCreateTarArchiveInputStream1() throws Exception {
                                   // Prepare test data
                                   String archiverName = ArchiveStreamFactory.TAR;
                                   InputStream mockInputStream = mock(InputStream.class);
                                   
                                   // Create factory instance
                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                   
                                   // Execute method
                                   Object result = factory.createArchiveInputStream(archiverName, mockInputStream);
                                   
                                   // Verify result
                                   assertNotNull("Result should not be null", result);
                                   assertTrue("Should return TarArchiveInputStream", 
                                             result instanceof TarArchiveInputStream);
                               }

    @Test
                      public void testCreateArchiveInputStream_DetectsTarFormat1() throws Exception {
                          // Create a real input stream with tar signature
                          ByteArrayOutputStream baos = new ByteArrayOutputStream();
                          // Write tar signature (ustar)
                          byte[] header = new byte[512];
                          System.arraycopy(new byte[] {'u', 's', 't', 'a', 'r'}, 0, header, 257, 5);
                          baos.write(header);
                          
                          InputStream mockIn = new ByteArrayInputStream(baos.toByteArray()) {
                              @Override
                              public boolean markSupported() {
                                  return true;
                              }
                          };
                      
                          // Test
                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                          ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                          
                          // Verify
                          assertTrue("Should return TarArchiveInputStream for tar format", 
                                     result instanceof TarArchiveInputStream);
                      }

    @Test
                 public void testCreateArchiveInputStream_AR2() throws Exception {
                     // Create mock input stream
                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                     
                     // Initialize factory
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     
                     // Test with uppercase AR
                     ArchiveInputStream result = factory.createArchiveInputStream("AR", mockInputStream);
                     assertTrue(result instanceof ArArchiveInputStream);
                     
                     // Test case sensitivity with lowercase ar
                     result = factory.createArchiveInputStream("ar", mockInputStream);
                     assertTrue(result instanceof ArArchiveInputStream);
                 }

    @Test
                 public void testCreateArchiveInputStream_ZIP2() throws Exception {
                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     
                     ArchiveInputStream result = factory.createArchiveInputStream("ZIP", mockInputStream);
                     assertTrue(result instanceof ZipArchiveInputStream);
                     
                     // Test case sensitivity
                     result = factory.createArchiveInputStream("zip", mockInputStream);
                     assertTrue(result instanceof ZipArchiveInputStream);
                 }

    @Test
                 public void testCreateArchiveInputStream_TAR2() throws Exception {
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                     
                     ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                     assertTrue(result instanceof TarArchiveInputStream);
                     
                     // Test case sensitivity
                     result = factory.createArchiveInputStream("tar", mockInputStream);
                     assertTrue(result instanceof TarArchiveInputStream);
                 }

    @Test
                 public void testCreateArchiveInputStream_JAR2() throws Exception {
                     // Initialize required objects
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                     
                     // Test with constant
                     ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInputStream);
                     assertTrue(result instanceof JarArchiveInputStream);
                     
                     // Test case sensitivity
                     result = factory.createArchiveInputStream("jar", mockInputStream);
                     assertTrue(result instanceof JarArchiveInputStream);
                     
                     // Close the stream to avoid resource leaks
                     mockInputStream.close();
                 }

    @Test
                 public void testCreateArchiveInputStream_CPIO2() throws Exception {
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                     
                     ArchiveInputStream result = factory.createArchiveInputStream("CPIO", mockInputStream);
                     assertTrue(result instanceof CpioArchiveInputStream);
                     
                     // Test case sensitivity
                     result = factory.createArchiveInputStream("cpio", mockInputStream);
                     assertTrue(result instanceof CpioArchiveInputStream);
                 }

    @Test
                 public void testCreateArchiveInputStream_DUMP2() throws Exception {
                     // Initialize required objects
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                     
                     // Test with constant
                     ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInputStream);
                     assertTrue(result instanceof DumpArchiveInputStream);
                     
                     // Test case sensitivity
                     result = factory.createArchiveInputStream("dump", mockInputStream);
                     assertTrue(result instanceof DumpArchiveInputStream);
                 }

    @Test
                 public void testCreateArchiveInputStream_UnsupportedFormat() throws Exception {
                     // Setup
                     org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     java.io.InputStream mockInputStream = new java.io.ByteArrayInputStream(new byte[0]);
                     
                     // Test
                     String unsupportedFormat = "RAR";
                     thrown.expect(ArchiveException.class);
                     thrown.expectMessage("Archiver: " + unsupportedFormat + " not found.");
                     factory.createArchiveInputStream(unsupportedFormat, mockInputStream);
                 }

    @Test
             public void testCreateArchiveInputStream_TarExactly512Bytes1() throws Exception {
                 // Mock input stream that returns exactly 512 bytes
                 InputStream in = mock(InputStream.class);
                 when(in.markSupported()).thenReturn(true);
                 
                 // Create a valid TAR header (512 bytes)
                 byte[] tarHeader = new byte[512];
                 // Set magic bytes for TAR format
                 System.arraycopy("ustar".getBytes(), 0, tarHeader, 257, 5);
                 
                 // Mock behavior:
                 // First read (12 byte signature) - return non-matching signature
                 when(in.read(any(byte[].class), anyInt(), eq(12)))
                     .thenAnswer(invocation -> {
                         byte[] buf = (byte[]) invocation.getArguments()[0];
                         System.arraycopy(new byte[12], 0, buf, 0, 12);
                         return 12;
                     });
                 
                 // Second read (32 byte signature) - return non-matching signature
                 when(in.read(any(byte[].class), anyInt(), eq(32)))
                     .thenAnswer(invocation -> {
                         byte[] buf = (byte[]) invocation.getArguments()[0];
                         System.arraycopy(new byte[32], 0, buf, 0, 32);
                         return 32;
                     });
                 
                 // Third read (512 byte signature) - return valid TAR header
                 when(in.read(any(byte[].class), anyInt(), eq(512)))
                     .thenAnswer(invocation -> {
                         byte[] buf = (byte[]) invocation.getArguments()[0];
                         System.arraycopy(tarHeader, 0, buf, 0, 512);
                         return 512; // Exactly 512 bytes
                     });
                 
                 // Mock TarArchiveInputStream.matches to return true
                 when(TarArchiveInputStream.matches(tarHeader, 512)).thenReturn(true);
                 
                 // Test
                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                 ArchiveInputStream result = factory.createArchiveInputStream(in);
                 
                 // Verify
                 assertTrue(result instanceof TarArchiveInputStream);
             }

    @Test
         public void testCreateArchiveInputStream_NullArchiverName2() throws Exception {
             ArchiveStreamFactory factory = new ArchiveStreamFactory();
             InputStream mockInputStream = mock(InputStream.class);
             
             try {
                 factory.createArchiveInputStream(null, mockInputStream);
                 fail("Expected IllegalArgumentException to be thrown");
             } catch (IllegalArgumentException e) {
                 assertEquals("Archivername must not be null.", e.getMessage());
             }
         }

    @Test
         public void testCreateArchiveInputStream_NullInputStream2() throws Exception {
             ArchiveStreamFactory factory = new ArchiveStreamFactory();
             
             try {
                 factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                 fail("Expected IllegalArgumentException");
             } catch (IllegalArgumentException e) {
                 assertEquals("InputStream must not be null.", e.getMessage());
             }
         }

    @Test
     public void testCreateTarArchiveInputStreamNotNull() throws Exception {
         // Prepare test data
         InputStream inputStream = new ByteArrayInputStream(new byte[0]);
         ArchiveStreamFactory factory = new ArchiveStreamFactory();
         
         // Call the method under test
         ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
         
         // Verify the result
         assertNotNull("Returned TarArchiveInputStream should not be null", result);
         assertTrue("Should return TarArchiveInputStream instance", 
                    result instanceof TarArchiveInputStream);
     }

    @Test
    public void testCreateArchiveInputStream_TarWithImprovedDetection() throws Exception {
        // Create a minimal TAR header that would need COMPRESS-117 logic
        byte[] tarHeader = new byte[512];
        // Set up a mock input stream that returns this header
        InputStream in = mock(InputStream.class);
        when(in.markSupported()).thenReturn(true);
        when(in.read(any(byte[].class))).thenAnswer(invocation -> {
            byte[] buf = (byte[]) invocation.getArguments()[0];
            System.arraycopy(tarHeader, 0, buf, 0, Math.min(tarHeader.length, buf.length));
            return tarHeader.length;
        });
        
        // The original code would create a TarArchiveInputStream for validation
        // The mutant would skip this and throw ArchiveException
        ArchiveStreamFactory factory = new ArchiveStreamFactory();
        ArchiveInputStream result = factory.createArchiveInputStream(in);
        
        assertNotNull("Should return a stream for TAR archive", result);
        assertTrue("Should be a TarArchiveInputStream", 
                   result instanceof TarArchiveInputStream);
    }


}
