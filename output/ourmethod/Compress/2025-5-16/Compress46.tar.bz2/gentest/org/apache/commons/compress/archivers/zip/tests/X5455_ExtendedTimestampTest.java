package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.Serializable;
import java.util.Date;
import java.util.zip.ZipException;
 
public class X5455_ExtendedTimestampTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                      public void testUnixTimeToZipLong_ValidPositiveValue() throws Exception {
                                                          long input = 1234567890L;
                                                          // Use reflection to access the private method
                                                          Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          ZipLong result = (ZipLong) method.invoke(null, input);
                                                          assertNotNull(result);
                                                          assertEquals(input, result.getValue());
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_ValidNegativeValue() throws Exception {
                                                          long input = -1234567890L;
                                                          Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          unixTimeToZipLong.setAccessible(true);
                                                          ZipLong result = (ZipLong) unixTimeToZipLong.invoke(null, input);
                                                          assertNotNull(result);
                                                          assertEquals(input, result.getValue());
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_ZeroValue() throws Exception {
                                                          long input = 0L;
                                                          Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          unixTimeToZipLong.setAccessible(true);
                                                          ZipLong result = (ZipLong) unixTimeToZipLong.invoke(null, input);
                                                          assertNotNull(result);
                                                          assertEquals(input, result.getValue());
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_Max32BitValue() throws Exception {
                                                          long input = Integer.MAX_VALUE;
                                                          Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          ZipLong result = (ZipLong) method.invoke(null, input);
                                                          assertNotNull(result);
                                                          assertEquals(input, result.getValue());
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_Min32BitValue() throws Exception {
                                                          long input = Integer.MIN_VALUE;
                                                          Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          ZipLong result = (ZipLong) method.invoke(null, input);
                                                          assertNotNull(result);
                                                          assertEquals(input, result.getValue());
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_AboveMax32BitValue() throws Exception {
                                                          long input = Integer.MAX_VALUE + 1L;
                                                          thrown.expect(IllegalArgumentException.class);
                                                          thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                          
                                                          // Use reflection to access private static method
                                                          Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
                                                          Method method = clazz.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          method.invoke(null, input);
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_BelowMin32BitValue() throws Exception {
                                                          long input = Integer.MIN_VALUE - 1L;
                                                          thrown.expect(IllegalArgumentException.class);
                                                          thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                          
                                                          // Use reflection to access the private method
                                                          Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          method.invoke(null, input);
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_LargePositiveValue() throws Exception {
                                                          long input = Long.MAX_VALUE;
                                                          thrown.expect(IllegalArgumentException.class);
                                                          thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                          
                                                          // Use reflection to access the private static method
                                                          Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          method.invoke(null, input);
                                                      }

    @Test
                                                      public void testUnixTimeToZipLong_LargeNegativeValue() throws Exception {
                                                          long input = Long.MIN_VALUE;
                                                          thrown.expect(IllegalArgumentException.class);
                                                          thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                          
                                                          // Use reflection to access private method
                                                          Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
                                                          Method method = clazz.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                          method.setAccessible(true);
                                                          method.invoke(null, input);
                                                      }

    @Test
                                                 public void testDateToZipLongWithNullInput() throws Exception {
                                                     // Test that null input returns null
                                                     Date input = null;
                                                     Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                                     method.setAccessible(true);
                                                     ZipLong result = (ZipLong) method.invoke(null, input);
                                                     assertNull("Should return null for null input", result);
                                                 }

    @Test
                                                 public void testDateToZipLongWithValidDate() throws Exception {
                                                     // Test that non-null input gets processed (doesn't return null)
                                                     Date input = new Date(); // current time
                                                     
                                                     // Use reflection to access the private method
                                                     Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                                     dateToZipLongMethod.setAccessible(true);
                                                     ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, input);
                                                     
                                                     assertNotNull("Should not return null for valid date input", result);
                                                     
                                                     // Verify the conversion is correct (optional additional check)
                                                     long expectedSeconds = input.getTime() / 1000;
                                                     // Assuming unixTimeToZipLong is properly tested elsewhere
                                                 }

    @Test
                                            public void testDateToZipLongWithNullInput1() throws Exception {
                                                // Test that method returns null for null input (original behavior)
                                                // This will fail if the mutant is present (which returns ZipLong(0) instead)
                                                
                                                // Use reflection to access private static method
                                                Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
                                                Method method = clazz.getDeclaredMethod("dateToZipLong", Date.class);
                                                method.setAccessible(true);
                                                ZipLong result = (ZipLong) method.invoke(null, (Date) null);
                                                
                                                // Assert null is returned (original behavior)
                                                assertNull("Method should return null for null Date input", result);
                                                
                                                // Additional assertion to explicitly catch the mutant
                                                // If mutant is present, result will be a ZipLong(0) instead of null
                                                if (result != null) {
                                                    assertEquals("Mutant detected: Expected null but got ZipLong(0)", 
                                                                 0, result.getValue());
                                                    fail("Mutant detected: Method returned ZipLong(0) instead of null");
                                                }
                                            }

    @Test
                                       public void testDateToZipLongDetectsTimeUnitMutation() throws Exception {
                                           // Create a fixed date for testing (current time)
                                           Date testDate = new Date();
                                           long expectedUnixTime = testDate.getTime() / 1000;
                                           
                                           // Use reflection to access the private static method
                                           Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                               "dateToZipLong", Date.class);
                                           dateToZipLongMethod.setAccessible(true);
                                           ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                                           
                                           // Verify the time conversion is correct (seconds, not milliseconds)
                                           // Since we can't directly access unixTimeToZipLong's internals, we'll verify the behavior
                                           // by checking the ZipLong value is based on seconds, not milliseconds
                                           
                                           // Get the expected value range (accounting for possible rounding)
                                           long expectedValue = expectedUnixTime;
                                           long mutantValue = testDate.getTime();
                                           
                                           // Verify the result is closer to expected than mutant
                                           long resultValue = result.getValue(); // Assuming ZipLong has getValue()
                                           long diffToExpected = Math.abs(resultValue - expectedValue);
                                           long diffToMutant = Math.abs(resultValue - mutantValue);
                                           
                                           assertTrue("Result should be closer to expected (seconds) than mutant (milliseconds)", 
                                                      diffToExpected < diffToMutant);
                                           
                                           // Additional verification that the result is approximately expectedUnixTime
                                           // Allowing for small rounding differences
                                           assertEquals("Time conversion should be in seconds", 
                                                       expectedUnixTime, resultValue, 1);
                                       }

    @Test
                                  public void testDateToZipLong() throws Exception {
                                      // Create a specific date for testing (January 1, 2020 00:00:00 GMT)
                                      Date testDate = new Date(1577836800000L); // 1577836800000 milliseconds since epoch
                                      
                                      // Get the private methods using reflection
                                      Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                      dateToZipLongMethod.setAccessible(true);
                                      Method unixTimeToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                      unixTimeToZipLongMethod.setAccessible(true);
                                      
                                      // Calculate expected value (milliseconds to seconds)
                                      long expectedSeconds = 1577836800000L / 1000;
                                      ZipLong expected = (ZipLong) unixTimeToZipLongMethod.invoke(null, expectedSeconds);
                                      
                                      // Calculate what the mutant would return (milliseconds to deciseconds)
                                      long mutantSeconds = 1577836800000L / 100;
                                      ZipLong mutantValue = (ZipLong) unixTimeToZipLongMethod.invoke(null, mutantSeconds);
                                      
                                      // Test the actual method
                                      ZipLong actual = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                                      
                                      // Verify it returns the correct value (not the mutant value)
                                      assertEquals(expected, actual);
                                      assertNotEquals(mutantValue, actual); // This will fail if the mutant is present
                                      
                                      // Also test null input
                                      assertNull(dateToZipLongMethod.invoke(null, new Object[]{null}));
                                  }

    @Test
                             public void testDateToZipLong_ShouldNotAddExtraSecond() throws Exception {
                                 // Create a fixed date for testing (e.g., 2023-01-01 00:00:00 UTC)
                                 Date testDate = new Date(1672531200000L); // This is exactly 2023-01-01 00:00:00 UTC
                                 
                                 // Get the private method using reflection
                                 Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                 dateToZipLongMethod.setAccessible(true);
                                 
                                 // Expected value is the exact seconds since epoch (1672531200)
                                 ZipLong expected = new ZipLong(1672531200L);
                                 
                                 // Call the method via reflection
                                 ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                                 
                                 // Assert the result matches exactly (mutant would add 1 to the value)
                                 assertEquals("Converted time should match exactly without added seconds", 
                                             expected.getValue(), result.getValue());
                                 
                                 // Also test with a date that would show overflow if 1 was added
                                 Date edgeDate = new Date(Long.MAX_VALUE - 1000); // 1 second before overflow
                                 try {
                                     dateToZipLongMethod.invoke(null, edgeDate);
                                 } catch (InvocationTargetException e) {
                                     if (e.getCause() instanceof ArithmeticException) {
                                         fail("Original method should handle this date without overflow");
                                     }
                                     throw e;
                                 }
                                 
                                 // The mutant would cause overflow in this case
                             }

    @Test
                        public void testDateToZipLongWithLargeValue() {
                            // Create a date with time way beyond Integer.MAX_VALUE seconds
                            // Integer.MAX_VALUE seconds is about 68 years, so we use Long.MAX_VALUE
                            Date hugeDate = new Date(Long.MAX_VALUE);
                            
                            try {
                                // Use reflection to access the private method
                                Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                dateToZipLongMethod.setAccessible(true);
                                dateToZipLongMethod.invoke(null, hugeDate);
                                fail("Should have thrown IllegalArgumentException for too large value");
                            } catch (NoSuchMethodException | IllegalAccessException e) {
                                fail("Failed to access dateToZipLong method via reflection");
                            } catch (InvocationTargetException e) {
                                // Expected behavior - test passes if we get IllegalArgumentException
                                if (!(e.getCause() instanceof IllegalArgumentException)) {
                                    fail("Expected IllegalArgumentException but got " + e.getCause().getClass());
                                }
                            }
                        }

    @Test
                        public void testDateToZipLongWithSmallValue() throws Exception {
                            // Create a date with time way below Integer.MIN_VALUE seconds
                            Date smallDate = new Date(Long.MIN_VALUE);
                            
                            // Use reflection to access private method
                            Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
                            Method method = clazz.getDeclaredMethod("dateToZipLong", Date.class);
                            method.setAccessible(true);
                            
                            try {
                                method.invoke(null, smallDate);
                                fail("Should have thrown IllegalArgumentException for too small value");
                            } catch (InvocationTargetException e) {
                                // Expected behavior - test passes
                                assertTrue(e.getCause() instanceof IllegalArgumentException);
                            }
                        }

    @Test
                        public void testDateToZipLongWithValidValue() throws Exception {
                            // Create a date with time within Integer range
                            Date validDate = new Date(1000L * Integer.MAX_VALUE / 2);
                            
                            try {
                                // Use reflection to access the private method
                                Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                dateToZipLongMethod.setAccessible(true);
                                dateToZipLongMethod.invoke(null, validDate);
                                // No exception expected - test passes
                            } catch (IllegalArgumentException e) {
                                fail("Should not throw exception for valid value");
                            }
                        }

    @Test
                        public void testDateToZipLongWithNull() throws Exception {
                            Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                            dateToZipLongMethod.setAccessible(true);
                            assertNull(dateToZipLongMethod.invoke(null, (Date)null));
                        }

    @Test
                   public void testDateToZipLongWithExtremeDates() throws Exception {
                       // Get the private method via reflection
                       Method dateToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                       dateToZipLong.setAccessible(true);
                       
                       // Test with date that would exceed Integer.MAX_VALUE in seconds
                       Date farFuture = new Date(Long.MAX_VALUE);
                       try {
                           ZipLong result = (ZipLong) dateToZipLong.invoke(null, farFuture);
                           // If we get here, the mutant survived
                           fail("Expected exception for date exceeding Integer.MAX_VALUE in seconds");
                       } catch (InvocationTargetException e) {
                           Throwable cause = e.getCause();
                           if (!(cause instanceof ArithmeticException) && !(cause instanceof IllegalArgumentException)) {
                               fail("Expected ArithmeticException or IllegalArgumentException but got " + cause.getClass());
                           }
                           // Expected behavior for original code
                       }
                   
                       // Test with date that would be below Integer.MIN_VALUE in seconds
                       Date farPast = new Date(Long.MIN_VALUE);
                       try {
                           ZipLong result = (ZipLong) dateToZipLong.invoke(null, farPast);
                           // If we get here, the mutant survived
                           fail("Expected exception for date below Integer.MIN_VALUE in seconds");
                       } catch (InvocationTargetException e) {
                           Throwable cause = e.getCause();
                           if (!(cause instanceof ArithmeticException) && !(cause instanceof IllegalArgumentException)) {
                               fail("Expected ArithmeticException or IllegalArgumentException but got " + cause.getClass());
                           }
                           // Expected behavior for original code
                       }
                   }

    @Test
                   public void testDateToZipLongWithNullInput2() throws Exception {
                       // Test null input (should return null)
                       Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                       dateToZipLongMethod.setAccessible(true);
                       Object result = dateToZipLongMethod.invoke(null, (Date)null);
                       assertNull(result);
                   }

    @Test
                   public void testDateToZipLongWithNormalDate() throws Exception {
                       // Test with normal date within bounds
                       Date normalDate = new Date();
                       
                       // Use reflection to access the private method
                       Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                       dateToZipLongMethod.setAccessible(true);
                       ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, normalDate);
                       
                       assertNotNull(result);
                       // Additional assertions could be made about the converted value
                   }

    @Test
              public void testDateToZipLongWithNull1() throws Exception {
                  // Test null input returns null
                  Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                  dateToZipLongMethod.setAccessible(true);
                  ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, (Date) null);
                  assertNull(result);
              }

    @Test
              public void testDateToZipLongWithValidDate1() throws Exception {
                  // Test with current time (should be valid)
                  Date now = new Date();
                  
                  // Use reflection to access the private method
                  Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                  dateToZipLongMethod.setAccessible(true);
                  ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, now);
                  
                  assertNotNull(result);
              }

    @Test
              public void testDateToZipLongWithLargeTimestamp() throws Exception {
                  // Test with date that would exceed 32-bit signed integer range
                  thrown.expect(IllegalArgumentException.class);
                  thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer");
                  
                  // Create date far in the future (year 3000) that would exceed max 32-bit signed int
                  Date futureDate = new Date(32503680000000L); // approx year 3000
                  
                  // Use reflection to access private method
                  Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                      "dateToZipLong", Date.class);
                  dateToZipLongMethod.setAccessible(true);
                  dateToZipLongMethod.invoke(null, futureDate);
              }

    @Test
              public void testDateToZipLongWithSmallTimestamp() throws Exception {
                  // Test with date that would be below minimum 32-bit signed integer range
                  thrown.expect(IllegalArgumentException.class);
                  thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer");
                  
                  // Create date far in the past (year 1000) that would be below min 32-bit signed int
                  Date pastDate = new Date(-30610224000000L); // approx year 1000
                  
                  // Use reflection to access private method
                  Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
                  Method method = clazz.getDeclaredMethod("dateToZipLong", Date.class);
                  method.setAccessible(true);
                  method.invoke(null, pastDate);
              }

    @Test
         public void testDateToZipLongWithLargeTimestamp1() throws Exception {
             // Create a date with a timestamp that exceeds 32-bit signed integer range
             // 2^31 = 2147483648, so we use a value larger than this
             long largeTimestamp = 2147483648L * 1000L; // Convert to milliseconds
             
             // Create a date with this timestamp
             Date largeDate = new Date(largeTimestamp);
             
             // Get the private method using reflection
             Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
             dateToZipLongMethod.setAccessible(true);
             
             // Set up expected exception
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + (largeTimestamp/1000));
             
             // Call the method via reflection - should throw exception
             dateToZipLongMethod.invoke(null, largeDate);
         }

    @Test
         public void testDateToZipLongWithNullInput3() throws Exception {
             // Test null input case
             Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
             Method method = clazz.getDeclaredMethod("dateToZipLong", Date.class);
             method.setAccessible(true);
             ZipLong result = (ZipLong) method.invoke(null, (Date) null);
             assertNull(result);
         }

    @Test
         public void testDateToZipLongWithValidDate2() throws Exception {
             // Test with a valid date that fits in 32-bit signed integer
             Date validDate = new Date(1000000000000L); // 2001-09-09
             
             // Use reflection to access private static method
             Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
             Method method = clazz.getDeclaredMethod("dateToZipLong", Date.class);
             method.setAccessible(true);
             ZipLong result = (ZipLong) method.invoke(null, validDate);
             
             assertNotNull(result);
         }

    @Test
    public void testDateToZipLongWithLargeTimestamp2() throws Exception {
        // Create a date that would exceed 32-bit signed integer when converted to seconds
        // Integer.MAX_VALUE is 2^31-1 (2147483647) seconds
        // We need a time that's at least 2^31 * 1000 milliseconds
        long largeTime = ((long) Integer.MAX_VALUE + 1) * 1000L;
        Date largeDate = new Date(largeTime);
        
        // Get the private method using reflection
        Class<?> clazz = Class.forName("org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp");
        Method method = clazz.getDeclaredMethod("dateToZipLong", Date.class);
        method.setAccessible(true);
        
        try {
            // This should throw IllegalArgumentException in original code
            // If mutant is present, it would return ZipLong(0) instead
            method.invoke(null, largeDate);
            
            // If we reach here without exception, the test fails
            fail("Expected IllegalArgumentException for timestamp exceeding 32-bit signed integer");
        } catch (InvocationTargetException e) {
            // Check if the cause is IllegalArgumentException as expected
            if (!(e.getCause() instanceof IllegalArgumentException)) {
                fail("Expected IllegalArgumentException but got " + e.getCause().getClass().getName());
            }
        }
    }


}
