package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                         public void testFormatLongOctalOrBinaryBytes_PositiveWithinOctalRange() {
                                                             // Test positive value that can be stored as octal
                                                             byte[] buf = new byte[10];
                                                             int offset = 0;
                                                             int length = 8; // UIDLEN is typically 8
                                                             
                                                             // Value less than MAXID (for UIDLEN)
                                                             long value = TarConstants.MAXID - 1;
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals(0, buf[offset] & 0x80); // Should not have negative marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_NegativeValue() {
                                                             // Test negative value which should be stored in binary
                                                             byte[] buf = new byte[10];
                                                             int offset = 0;
                                                             int length = 8;
                                                             long value = -12345;
                                                             
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals((byte)0xff, buf[offset]); // Should have negative marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_PositiveExceedsOctalRange() {
                                                             // Test positive value that exceeds octal range
                                                             byte[] buf = new byte[10];
                                                             int offset = 0;
                                                             int length = 8;
                                                             long value = TarConstants.MAXID + 1;
                                                             
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals(0x80, buf[offset] & 0xff); // Should have binary marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_LengthLessThan() {
                                                             // Test with length < 9 which uses formatLongBinary
                                                             byte[] buf = new byte[10];
                                                             int offset = 1;
                                                             int length = 8;
                                                             long value = 12345678;
                                                             
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals(0x80, buf[offset] & 0xff); // Should have binary marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_Length9OrMore() {
                                                             // Test with length >= 9 which uses formatBigIntegerBinary
                                                             byte[] buf = new byte[20];
                                                             int offset = 2;
                                                             int length = 12;
                                                             long value = 123456789012L;
                                                             
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals(0x80, buf[offset] & 0xff); // Should have binary marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_ZeroValue() {
                                                             // Test with zero value
                                                             byte[] buf = new byte[10];
                                                             int offset = 0;
                                                             int length = 8;
                                                             long value = 0;
                                                             
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals(0, buf[offset] & 0x80); // Should not have negative marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_MaxOctalValue() {
                                                             // Test with maximum octal value
                                                             byte[] buf = new byte[10];
                                                             int offset = 0;
                                                             int length = 8;
                                                             long value = TarConstants.MAXID;
                                                             
                                                             int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                             
                                                             assertEquals(offset + length, result);
                                                             assertEquals(0, buf[offset] & 0x80); // Should not have negative marker
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_NullBuffer() {
                                                             // Test with null buffer
                                                             thrown.expect(NullPointerException.class);
                                                             TarUtils.formatLongOctalOrBinaryBytes(123, null, 0, 8);
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_InvalidOffset() {
                                                             // Test with invalid offset
                                                             byte[] buf = new byte[10];
                                                             thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                             TarUtils.formatLongOctalOrBinaryBytes(123, buf, -1, 8);
                                                         }

 @Test
                                                         public void testFormatLongOctalOrBinaryBytes_BufferTooSmall() {
                                                             // Test with buffer too small for the operation
                                                             byte[] buf = new byte[5];
                                                             thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                             TarUtils.formatLongOctalOrBinaryBytes(123, buf, 0, 8);
                                                         }

 @Test
         public void testFormatLongOctalOrBinaryBytes_DetectsBitwiseOperationMutant() {
             // Setup
             long testValue = 0xFFFFFFFF00000000L; // Value with high 32 bits set
             byte[] buffer = new byte[8];
             int offset = 0;
             int length = 8;
             
             // Execute
             int result = TarUtils.formatLongOctalOrBinaryBytes(testValue, buffer, offset, length);
             
             // Verify the binary formatting path was taken by checking the first byte
             // The original XOR would produce different bits than the mutated AND
             byte expectedFirstByte = (byte) 0x80; // Original XOR behavior would produce this
             assertEquals("First byte should match expected binary format", 
                          expectedFirstByte, buffer[offset]);
             
             // Additional verification that the full value was processed correctly
             // The mutated AND would lose the high bits, so we verify the full value
             long parsedValue = TarUtils.parseOctalOrBinary(buffer, offset, length);
             assertEquals("Parsed value should match original input", 
                          testValue, parsedValue);
             
             // Verify the return value (offset + length)
             assertEquals(offset + length, result);
         }

 @Test
        public void testFormatLongOctalOrBinaryBytes_BinaryFormattingDetectsValDecrementMutant() {
            // Setup
            byte[] buf = new byte[20];
            long testValue = 0x12345678L; // A value that will trigger binary formatting
            int offset = 0;
            int length = 8; // Less than 9 to trigger formatLongBinary
            
            // Expected binary representation (with proper incrementing)
            byte[] expected = new byte[] {
                (byte) 0x80, // Non-negative marker
                0x12, 0x34, 0x56, 0x78, 0, 0, 0 // Big-endian representation
            };
            
            // Execute
            int result = TarUtils.formatLongOctalOrBinaryBytes(testValue, buf, offset, length);
            
            // Verify
            assertEquals(offset + length, result);
            
            // Check the marker byte
            assertEquals(expected[0], buf[offset]);
            
            // Check the binary representation bytes
            // If val-- was used instead of val++, these bytes would be wrong
            for (int i = 1; i < length; i++) {
                assertEquals("Byte at position " + i + " doesn't match expected binary representation", 
                            expected[i], buf[offset + i]);
            }
            
            // Additional test with negative value to check negative marker
            long negativeValue = -0x12345678L;
            TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
            assertEquals((byte) 0xff, buf[offset]); // Negative marker
        }

 @Test
       public void testFormatLongOctalOrBinaryBytes_BinaryFormattingDetectsBitwiseMutation() {
           // Setup
           long testValue = 0x123456789ABCDEFL; // Value with diverse bit pattern
           byte[] buffer = new byte[16];
           int offset = 0;
           int length = 8; // Force binary formatting (length < 9)
           
           // Action
           int result = TarUtils.formatLongOctalOrBinaryBytes(testValue, buffer, offset, length);
           
           // Verification - check the binary representation
           // The mutation would cause incorrect bits due to AND instead of OR
           // Check specific bytes that would be affected by the mutation
           assertEquals((byte)0x12, buffer[offset]);
           assertEquals((byte)0x34, buffer[offset+1]);
           assertEquals((byte)0x56, buffer[offset+2]);
           assertEquals((byte)0x78, buffer[offset+3]);
           assertEquals((byte)0x9A, buffer[offset+4]);
           assertEquals((byte)0xBC, buffer[offset+5]);
           assertEquals((byte)0xDE, buffer[offset+6]);
           // Last byte would be different due to sign handling
           assertEquals((byte)(testValue & 0xFF), buffer[offset+7]);
           
           // Also test with a negative value to ensure sign handling is correct
           long negativeValue = -123456789L;
           TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buffer, offset, length);
           // Check that the sign marker was set correctly
           assertEquals((byte)0xff, buffer[offset]);
       }

 @Test
      public void testFormatLongOctalOrBinaryBytes_DetectsLoopDirectionMutant() {
          // Setup
          long value = 0x12345678L; // Large enough to force binary formatting
          byte[] buf = new byte[20];
          int offset = 5;
          int length = 8;
          
          // Action - this will call either formatLongBinary or formatBigIntegerBinary
          int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
          
          // Verification - check byte order is correct (original uses descending loop)
          // The most significant byte should be at the highest offset
          assertEquals((byte)0x12, buf[offset]);
          assertEquals((byte)0x34, buf[offset+1]);
          assertEquals((byte)0x56, buf[offset+2]);
          assertEquals((byte)0x78, buf[offset+3]);
          
          // Check return value
          assertEquals(offset + length, result);
          
          // Check the sign byte was set correctly (non-negative case)
          assertEquals((byte)0x80, buf[offset]);
      }

 @Test
     public void testFormatLongOctalOrBinaryBytes_NegativeValueWithBigInteger() {
         // Setup
         long negativeValue = -123456789L;
         byte[] buf = new byte[20];
         int offset = 0;
         int length = 9; // length >=9 triggers BigInteger path
         
         // Execute
         int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
         
         // Verify
         // Check that the first byte indicates negative (0xff)
         assertEquals((byte)0xff, buf[offset]);
         
         // Verify the position after the formatted value is correct
         assertEquals(offset + length, result);
         
         // Additional verification that the value was properly processed as negative
         // (This would depend on the exact formatBigIntegerBinary implementation)
         // For example, check that the remaining bytes contain the negative value
         // Note: This assumes formatBigIntegerBinary stores the value in two's complement
         boolean isNegativeRepresentation = (buf[offset + 1] & 0x80) != 0;
         assertTrue(isNegativeRepresentation);
     }

 @Test
    public void testFormatLongOctalOrBinaryBytes_BinaryBoundaryCase() {
        // Setup
        long value = 255; // Will be formatted as binary (since > max octal char)
        byte[] buf = new byte[10];
        int offset = 0;
        int length = 9; // Chosen to trigger the boundary condition
        
        // Execute
        int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
        
        // Verify
        assertEquals(offset + length, result);
        
        // For binary format with length 9, the first byte should be 0x80 (positive)
        // The mutation would incorrectly handle the boundary and potentially corrupt the buffer
        assertEquals((byte) 0x80, buf[offset]);
        
        // Verify remaining bytes contain the binary representation
        // The exact binary pattern depends on the implementation of formatBigIntegerBinary
        // but we know it shouldn't be all zeros or corrupted
        boolean hasNonZero = false;
        for (int i = offset + 1; i < offset + length; i++) {
            if (buf[i] != 0) {
                hasNonZero = true;
                break;
            }
        }
        assertTrue("Binary representation should have non-zero bytes", hasNonZero);
    }

 @Test
   public void testFormatLongOctalOrBinaryBytes_OffsetCalculation() {
       // Setup
       long value = 12345678L; // Value that will trigger binary formatting
       byte[] buf = new byte[20];
       int offset = 5;
       int length = 8;
       
       // Expected behavior - original writes at offset + length - len (which would be 5 + 8 - 8 = 5)
       // Mutant writes at offset + len (5 + 8 = 13)
       
       // Call method
       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
       
       // Verify the position where the special marker byte is written
       // Original would write at buf[5], mutant at buf[13]
       assertEquals("Marker byte should be at original offset", 
           (byte)0x80, buf[offset]);
       assertEquals("Marker byte should not be at mutant offset", 
           (byte)0, buf[offset + length]);
       
       // Verify return value
       assertEquals(offset + length, result);
       
       // Additional check for binary data position
       // Create a situation where len differs from length
       value = Long.MAX_VALUE; // Large value that will need full length
       byte[] buf2 = new byte[30];
       offset = 10;
       length = 16;
       
       result = TarUtils.formatLongOctalOrBinaryBytes(value, buf2, offset, length);
       
       // Original would write marker at offset (10), mutant at offset + len (26)
       assertEquals("Marker byte should be at original offset for large value", 
           (byte)0x80, buf2[offset]);
       assertEquals("Marker byte should not be at mutant offset for large value", 
           (byte)0, buf2[offset + length]);
   }

 @Test
  public void testFormatLongOctalOrBinaryBytes_MarkerByte() {
      // Test with negative value (should set 0xff in original, 0 in mutant)
      long negativeValue = -12345L;
      byte[] bufNegative = new byte[20];
      int offsetNegative = 5;
      int lengthNegative = 8;
      
      TarUtils.formatLongOctalOrBinaryBytes(negativeValue, bufNegative, offsetNegative, lengthNegative);
      // Original should set 0xff (which is -1 in byte) for negative values
      assertEquals("Marker byte for negative value should be 0xff", (byte) 0xff, bufNegative[offsetNegative]);
  
      // Test with positive value (should set 0 in original, 0xff in mutant)
      long positiveValue = 12345L;
      byte[] bufPositive = new byte[20];
      int offsetPositive = 5;
      int lengthPositive = 8;
      
      TarUtils.formatLongOctalOrBinaryBytes(positiveValue, bufPositive, offsetPositive, lengthPositive);
      // Original should set 0 for positive values
      assertEquals("Marker byte for positive value should be 0", (byte) 0, bufPositive[offsetPositive]);
  }

 @Test
 public void testFormatLongBinary_NegativeValue_DetectsBitwiseOperatorMutant() {
     // Setup
     long value = -12345L;  // A negative value to trigger the negative path
     byte[] buf = new byte[8];  // Large enough buffer
     int offset = 0;
     int length = 8;
     boolean negative = true;
     
     // Expected behavior (original)
     byte[] expectedBuf = new byte[8];
     // Manually calculate expected result
     long bits = (length - 1) * 8;
     long max = 1L << bits;
     long val = Math.abs(value);
     val ^= max - 1;
     val++;
     val |= 0xffL << bits;  // Original operation
     
     for (int i = offset + length - 1; i >= offset; i--) {
         expectedBuf[i] = (byte) val;
         val >>= 8;
     }
     
     // Test
     try {
         // Use reflection to access private method
         Method method = TarUtils.class.getDeclaredMethod(
             "formatLongBinary", long.class, byte[].class, int.class, int.class, boolean.class);
         method.setAccessible(true);
         method.invoke(null, value, buf, offset, length, negative);
         
         // Verify the buffer matches expected result
         assertArrayEquals("Negative value binary format incorrect - mutant not detected", 
                         expectedBuf, buf);
     } catch (Exception e) {
         fail("Test failed due to reflection error: " + e.getMessage());
     }
 }

}
