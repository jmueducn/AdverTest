package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                    public void testSetName_ThroughConstructor() {
                                        String nameWithBackslashes = "path\\to\\file";
                                        ZipArchiveEntry entry = new ZipArchiveEntry(nameWithBackslashes);
                                        // Default platform is FAT, should convert backslashes
                                        assertEquals("path/to/file", entry.getName());
                                    }

    @Test
                            public void testSetName_NullName() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, (Object)null);
                                assertNull(entry.getName());
                            }

    @Test
                            public void testSetName_EmptyName() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, "");
                                assertEquals("", entry.getName());
                            }

    @Test
                            public void testSetName_NonFatPlatform() throws Exception {
                                // Use public constructor with dummy name
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                
                                // Use reflection to access protected setPlatform method
                                Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatformMethod.setAccessible(true);
                                setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                
                                String nameWithBackslashes = "path\\\\to\\\\file";
                                
                                // Use reflection to access protected setName method
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, nameWithBackslashes);
                                
                                // Should not modify backslashes on UNIX platform
                                assertEquals(nameWithBackslashes, entry.getName());
                            }

    @Test
                            public void testSetName_FatPlatform_NoBackslashes() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                // Use reflection to set platform
                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatform.setAccessible(true);
                                setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                String simpleName = "filename";
                                // Use reflection to set name
                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setName.setAccessible(true);
                                setName.invoke(entry, simpleName);
                                
                                assertEquals(simpleName, entry.getName());
                            }

    @Test
                            public void testSetName_FatPlatform_WithBackslashes() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                
                                // Use reflection to set platform
                                Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatformMethod.setAccessible(true);
                                setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                String nameWithBackslashes = "path\\\\to\\\\file";
                                
                                // Use reflection to set name
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, nameWithBackslashes);
                                
                                // Should convert backslashes to forward slashes
                                assertEquals("path/to/file", entry.getName());
                            }

    @Test
                            public void testSetName_FatPlatform_WithMixedSlashes() throws Exception {
                                // Use reflection to access protected constructor
                                Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                constructor.setAccessible(true);
                                ZipArchiveEntry entry = constructor.newInstance();
                                
                                // Use reflection to access protected setPlatform method
                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatform.setAccessible(true);
                                setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                String mixedSlashes = "path\\\\to/file";
                                
                                // Use reflection to access protected setName method
                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setName.setAccessible(true);
                                setName.invoke(entry, mixedSlashes);
                                
                                // Should only convert backslashes, leave forward slashes
                                assertEquals("path/to/file", entry.getName());
                            }

    @Test
                            public void testSetName_FatPlatform_WithForwardSlashesOnly() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                
                                // Use reflection to set platform
                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatform.setAccessible(true);
                                setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                String forwardSlashes = "path/to/file";
                                
                                // Use reflection to set name
                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setName.setAccessible(true);
                                setName.invoke(entry, forwardSlashes);
                                
                                // Should leave forward slashes unchanged
                                assertEquals(forwardSlashes, entry.getName());
                            }

    @Test
                            public void testSetName_UnicodeCharacters() throws Exception {
                                // Create entry using public constructor
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                
                                // Set platform using reflection
                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatform.setAccessible(true);
                                setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                String unicodeName = "中文\\文件.txt";
                                
                                // Set name using reflection
                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setName.setAccessible(true);
                                setName.invoke(entry, unicodeName);
                                
                                assertEquals("中文/文件.txt", entry.getName());
                            }

    @Test
                            public void testSetName_LongPath() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                // Use reflection to set platform
                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatform.setAccessible(true);
                                setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                StringBuilder longPath = new StringBuilder();
                                for (int i = 0; i < 100; i++) {
                                    longPath.append("dir\\\\");
                                }
                                longPath.append("file.txt");
                                
                                String expected = longPath.toString().replace('\\', '/');
                                // Use reflection to set name
                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setName.setAccessible(true);
                                setName.invoke(entry, longPath.toString());
                                
                                assertEquals(expected, entry.getName());
                            }

    @Test
                            public void testSetNameWithRawName_NormalValues() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                String name = "testFile.txt";
                                byte[] rawName = name.getBytes("UTF-8");
                                
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, name, rawName);
                                
                                assertEquals("Name should be set correctly", name, entry.getName());
                                Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                byte[] actualRawName = (byte[]) getRawNameMethod.invoke(entry);
                                assertArrayEquals("Raw name should be set correctly", rawName, actualRawName);
                            }

    @Test
                            public void testSetNameWithRawName_EmptyName() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                String name = "";
                                byte[] rawName = name.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                
                                // Use reflection to access protected setName method
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                    "setName", String.class, byte[].class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, name, rawName);
                                
                                assertEquals("Empty name should be allowed", name, entry.getName());
                                assertArrayEquals("Raw name should match empty string", rawName, entry.getRawName());
                            }

    @Test
                            public void testSetNameWithRawName_NullRawName() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                String name = "testFile.txt";
                                
                                // Use reflection to access protected setName method
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                    "setName", String.class, byte[].class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, name, null);
                                
                                assertEquals("Name should still be set with null rawName", name, entry.getName());
                                assertNull("Raw name should be null", entry.getRawName());
                            }

    @Test
                            public void testSetNameWithRawName_AfterPreviousSet() throws Exception {
                                ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                String initialName = "initial.txt";
                                byte[] initialRawName = initialName.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                
                                Method setNameWithRaw = ZipArchiveEntry.class.getDeclaredMethod(
                                    "setName", String.class, byte[].class);
                                setNameWithRaw.setAccessible(true);
                                setNameWithRaw.invoke(entry, initialName, initialRawName);
                                
                                String newName = "new.txt";
                                byte[] newRawName = newName.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                setNameWithRaw.invoke(entry, newName, newRawName);
                                
                                assertEquals("New name should overwrite previous", newName, entry.getName());
                                assertArrayEquals("New raw name should overwrite previous", 
                                                 newRawName, entry.getRawName());
                            }

    @Test
                        public void testSetNameWithRawName_NullName() throws Exception {
                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                            byte[] rawName = "test".getBytes("UTF-8");
                            
                            thrown.expect(NullPointerException.class);
                            
                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                "setName", String.class, byte[].class);
                            setNameMethod.setAccessible(true);
                            setNameMethod.invoke(entry, null, rawName);
                        }

    @Test
                        public void testSetNameWithRawName_NonMatchingRawName() throws Exception {
                            org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
                                new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("initialName");
                            String name = "testFile.txt";
                            byte[] rawName = "different.txt".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                            
                            // Use reflection to access protected setName(String, byte[]) method
                            java.lang.reflect.Method setNameMethod = org.apache.commons.compress.archivers.zip.ZipArchiveEntry.class
                                .getDeclaredMethod("setName", String.class, byte[].class);
                            setNameMethod.setAccessible(true);
                            setNameMethod.invoke(entry, name, rawName);
                            
                            org.junit.Assert.assertEquals("Name should be set correctly", name, entry.getName());
                            // Use reflection to access protected getRawName() method if needed
                            java.lang.reflect.Method getRawNameMethod = org.apache.commons.compress.archivers.zip.ZipArchiveEntry.class
                                .getDeclaredMethod("getRawName");
                            getRawNameMethod.setAccessible(true);
                            byte[] actualRawName = (byte[]) getRawNameMethod.invoke(entry);
                            org.junit.Assert.assertArrayEquals("Raw name should be set as provided even if different", 
                                                 rawName, actualRawName);
                        }

    @Test
                        public void testSetNameWithRawName_LongName() throws Exception {
                            // Create test entry
                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                            
                            // Build long name (1000 characters)
                            StringBuilder longNameBuilder = new StringBuilder();
                            for (int i = 0; i < 1000; i++) {
                                longNameBuilder.append("a");
                            }
                            String name = longNameBuilder.toString();
                            byte[] rawName = name.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                            
                            // Use reflection to call protected setName(String, byte[]) method
                            java.lang.reflect.Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                "setName", String.class, byte[].class);
                            setNameMethod.setAccessible(true);
                            setNameMethod.invoke(entry, name, rawName);
                            
                            // Verify results
                            assertEquals("Long names should be handled", name, entry.getName());
                            assertArrayEquals("Raw name should handle long names", rawName, entry.getRawName());
                        }

    @Test
                        public void testSetNameWithRawName_PlatformSpecificEncoding() throws Exception {
                            ZipArchiveEntry entry = new ZipArchiveEntry("temp");
                            String name = "überFile.txt";
                            // Using ISO-8859-1 encoding which is common for FAT platform
                            byte[] rawName = name.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1);
                            
                            // Use reflection to access protected setName(String, byte[]) method
                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                "setName", String.class, byte[].class);
                            setNameMethod.setAccessible(true);
                            setNameMethod.invoke(entry, name, rawName);
                            
                            assertEquals("Name should be set correctly", name, entry.getName());
                            assertArrayEquals("Raw name should preserve platform-specific encoding", 
                                             rawName, entry.getRawName());
                        }

    @Test
                    public void testSetNameWithRawName_SpecialCharacters() throws Exception {
                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                        String name = "测试文件.txt";
                        byte[] rawName = name.getBytes("UTF-8");
                        
                        // Use reflection to access protected setName(String, byte[]) method
                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                            "setName", String.class, byte[].class);
                        setNameMethod.setAccessible(true);
                        setNameMethod.invoke(entry, name, rawName);
                        
                        assertEquals("Unicode names should be handled", name, entry.getName());
                        assertArrayEquals("Raw name should preserve Unicode bytes", rawName, entry.getRawName());
                    }

    @Test
               public void testIsDirectoryDetectsTrailingSlash() {
                   // Test case that will catch the mutant
                   
                   // Case 1: Path ends with "/" but doesn't start with "/" - should be directory
                   ZipArchiveEntry entry1 = new ZipArchiveEntry("folder/subfolder/");
                   assertTrue("Entry ending with / should be directory", entry1.isDirectory());
                   
                   // Case 2: Path starts with "/" but doesn't end with "/" - should NOT be directory
                   ZipArchiveEntry entry2 = new ZipArchiveEntry("/absolute/path");
                   assertFalse("Entry starting with / but not ending with / should not be directory", 
                               entry2.isDirectory());
                   
                   // Case 3: Path both starts and ends with "/" - should be directory
                   ZipArchiveEntry entry3 = new ZipArchiveEntry("/root/folder/");
                   assertTrue("Entry both starting and ending with / should be directory", 
                              entry3.isDirectory());
                   
                   // Case 4: Path neither starts nor ends with "/" - should NOT be directory
                   ZipArchiveEntry entry4 = new ZipArchiveEntry("regularfile.txt");
                   assertFalse("Regular file should not be directory", entry4.isDirectory());
               }

    @Test
               public void testIsDirectory() {
                   // Test case 1: Name ends with "/" - should be directory
                   ZipArchiveEntry entry1 = new ZipArchiveEntry("folder/");
                   assertTrue("Entry ending with / should be directory", entry1.isDirectory());
                   
                   // Test case 2: Name contains "/" in middle - should NOT be directory in original
                   ZipArchiveEntry entry2 = new ZipArchiveEntry("folder/subfolder");
                   assertFalse("Entry with / in middle should not be directory", entry2.isDirectory());
                   
                   // Test case 3: Name starts with "/" - should NOT be directory in original
                   ZipArchiveEntry entry3 = new ZipArchiveEntry("/folder");
                   assertFalse("Entry starting with / should not be directory", entry3.isDirectory());
                   
                   // Test case 4: Name without "/" - should NOT be directory
                   ZipArchiveEntry entry4 = new ZipArchiveEntry("file");
                   assertFalse("Entry without / should not be directory", entry4.isDirectory());
               }

    @Test
              public void testIsDirectoryDetectsForwardSlash() {
                  // Create entry with Unix-style directory path
                  ZipArchiveEntry entry = new ZipArchiveEntry("testdir/");
                  assertTrue("Entry with / should be recognized as directory", 
                            entry.isDirectory());
              }

    @Test
              public void testIsDirectoryRejectsBackslash() {
                  // Create entry with Windows-style path (should not be recognized as directory)
                  ZipArchiveEntry entry = new ZipArchiveEntry("testdir\\");
                  assertFalse("Entry with \\ should NOT be recognized as directory", 
                             entry.isDirectory());
              }

    @Test
              public void testIsDirectoryRejectsPlainFile() {
                  // Create regular file entry
                  ZipArchiveEntry entry = new ZipArchiveEntry("testfile.txt");
                  assertFalse("Regular file should NOT be recognized as directory", 
                             entry.isDirectory());
              }

    @Test
              public void testIsDirectoryWithMixedCase() {
                  // Test case sensitivity
                  ZipArchiveEntry entry1 = new ZipArchiveEntry("TESTDIR/");
                  ZipArchiveEntry entry2 = new ZipArchiveEntry("testdir/");
                  assertTrue("Upper case directory should be recognized", entry1.isDirectory());
                  assertTrue("Lower case directory should be recognized", entry2.isDirectory());
              }

    @Test
             public void testIsDirectory1() {
                 // Test directory case (should return true)
                 ZipArchiveEntry dirEntry = new ZipArchiveEntry("testdir/");
                 assertTrue("Entry ending with / should be recognized as directory", 
                           dirEntry.isDirectory());
                 
                 // Test file case (should return false)
                 ZipArchiveEntry fileEntry = new ZipArchiveEntry("testfile.txt");
                 assertFalse("Entry not ending with / should not be recognized as directory", 
                            fileEntry.isDirectory());
                 
                 // Test edge case - empty name (should return false)
                 ZipArchiveEntry emptyEntry = new ZipArchiveEntry("");
                 assertFalse("Empty name should not be recognized as directory", 
                            emptyEntry.isDirectory());
             }

    @Test
            public void testIsDirectory2() {
                // Test case 1: Non-empty name not ending with "/" (file)
                ZipArchiveEntry fileEntry = new ZipArchiveEntry("file.txt");
                assertFalse("Non-directory entry should return false", fileEntry.isDirectory());
                
                // Test case 2: Name ending with "/" (directory)
                ZipArchiveEntry dirEntry = new ZipArchiveEntry("folder/");
                assertTrue("Directory entry should return true", dirEntry.isDirectory());
                
                // Test case 3: Empty name
                ZipArchiveEntry emptyEntry = new ZipArchiveEntry("");
                assertFalse("Empty name entry should return false", emptyEntry.isDirectory());
                
                // Test case 4: Root directory case
                ZipArchiveEntry rootEntry = new ZipArchiveEntry("/");
                assertTrue("Root directory should return true", rootEntry.isDirectory());
            }

    @Test
           public void testIsDirectory3() {
               // Test case for non-directory entry (should return false)
               ZipArchiveEntry fileEntry = new ZipArchiveEntry("file.txt");
               assertFalse("Non-directory entry should return false", fileEntry.isDirectory());
               
               // Test case for directory entry (should return true)
               ZipArchiveEntry dirEntry = new ZipArchiveEntry("folder/");
               assertTrue("Directory entry should return true", dirEntry.isDirectory());
               
               // Additional edge case - empty name (should return false)
               ZipArchiveEntry emptyEntry = new ZipArchiveEntry("");
               assertFalse("Empty name should return false", emptyEntry.isDirectory());
               
               // Additional edge case - name with just a slash (should return true)
               ZipArchiveEntry slashEntry = new ZipArchiveEntry("/");
               assertTrue("Single slash should return true", slashEntry.isDirectory());
           }

    @Test
      public void testIsDirectory4() {
          // Test case for directory entry (should return true)
          ZipArchiveEntry directoryEntry = new ZipArchiveEntry("testdir/");
          assertTrue("Entry ending with / should be recognized as directory", 
                     directoryEntry.isDirectory());
          
          // Test case for non-directory entry (should return false)
          ZipArchiveEntry fileEntry = new ZipArchiveEntry("testfile.txt");
          assertFalse("Entry not ending with / should not be recognized as directory", 
                      fileEntry.isDirectory());
          
          // Edge case: empty name (should return false)
          ZipArchiveEntry emptyEntry = new ZipArchiveEntry("");
          assertFalse("Empty name should not be recognized as directory", 
                     emptyEntry.isDirectory());
          
          // Edge case: root directory (should return true)
          ZipArchiveEntry rootEntry = new ZipArchiveEntry("/");
          assertTrue("Root directory should be recognized as directory", 
                    rootEntry.isDirectory());
      }

    @Test
    public void testIsDirectoryDetectsMutant() {
        // Create entry with name that ends with "/" but has "/" elsewhere
        ZipArchiveEntry entry = new ZipArchiveEntry("path/to/directory/");
        
        // This should be false in original (because of indexOf check) 
        // but true in mutant (only checks endsWith)
        // So if this assertion fails, the mutant is detected
        assertFalse("Entry with '/' in middle should not be considered directory", 
                   entry.isDirectory());
        
        // Test normal directory case
        ZipArchiveEntry dirEntry = new ZipArchiveEntry("directory/");
        assertTrue("Simple directory name should be considered directory", 
                  dirEntry.isDirectory());
        
        // Test non-directory case
        ZipArchiveEntry fileEntry = new ZipArchiveEntry("file.txt");
        assertFalse("Regular file should not be considered directory", 
                   fileEntry.isDirectory());
    }


}
