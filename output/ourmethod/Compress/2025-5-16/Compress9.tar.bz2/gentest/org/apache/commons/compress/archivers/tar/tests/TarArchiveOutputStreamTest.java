package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                                          public void testGetCount_ZeroBytes() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(0, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_SmallPositiveValue() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              byte[] data = new byte[100];
                                                                                                                                                                                              
                                                                                                                                                                                              // Write some data
                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(100, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_LargeValue() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              byte[] data = new byte[Integer.MAX_VALUE];
                                                                                                                                                                                              
                                                                                                                                                                                              // Write large amount of data
                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(Integer.MAX_VALUE, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_AfterMultipleWrites() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              byte[] data1 = new byte[100];
                                                                                                                                                                                              byte[] data2 = new byte[200];
                                                                                                                                                                                              byte[] data3 = new byte[300];
                                                                                                                                                                                              
                                                                                                                                                                                              // Write multiple times
                                                                                                                                                                                              tarOut.write(data1, 0, data1.length);
                                                                                                                                                                                              tarOut.write(data2, 0, data2.length);
                                                                                                                                                                                              tarOut.write(data3, 0, data3.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(600, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_AfterClose() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              byte[] data = new byte[500];
                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Close the stream
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(500, tarOut.getCount());
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_AfterFinish() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              byte[] data = new byte[750];
                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Finish the stream
                                                                                                                                                                                              tarOut.finish();
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(750, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_WithEmptyWrites() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              byte[] data = new byte[0];
                                                                                                                                                                                              
                                                                                                                                                                                              // Write empty data
                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(0, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetCount_AfterArchiveEntryOperations() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                              ArchiveEntry entry = mock(ArchiveEntry.class);
                                                                                                                                                                                              
                                                                                                                                                                                              // Perform archive operations
                                                                                                                                                                                              tarOut.putArchiveEntry(entry);
                                                                                                                                                                                              byte[] data = new byte[400];
                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                              tarOut.closeArchiveEntry();
                                                                                                                                                                                              
                                                                                                                                                                                              // Test & Verify
                                                                                                                                                                                              assertEquals(400, tarOut.getCount());
                                                                                                                                                                                              
                                                                                                                                                                                              // Cleanup
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_NoDataWritten() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              OutputStream mockOs = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOs);
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(0, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_AfterWritingData() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              byte[] testData = "Test data".getBytes();
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(testData.length, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_MultipleWrites() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              byte[] data1 = "First".getBytes();
                                                                                                                                                                                              byte[] data2 = "Second".getBytes();
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.write(data1, 0, data1.length);
                                                                                                                                                                                              long firstWrite = tarOut.getBytesWritten();
                                                                                                                                                                                              tarOut.write(data2, 0, data2.length);
                                                                                                                                                                                              long secondWrite = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(data1.length, firstWrite);
                                                                                                                                                                                              assertEquals(data1.length + data2.length, secondWrite);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_AfterClose() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              byte[] testData = "Test data".getBytes();
                                                                                                                                                                                              tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(testData.length, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_WithLargeData() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              byte[] largeData = new byte[1024 * 1024]; // 1MB
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.write(largeData, 0, largeData.length);
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(largeData.length, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_AfterFinish() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              byte[] testData = "Test data".getBytes();
                                                                                                                                                                                              tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.finish();
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(testData.length, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_WithEmptyWrites() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.write(new byte[0], 0, 0);
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(0, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                          public void testGetBytesWritten_WithPartialWrites() throws Exception {
                                                                                                                                                                                              // Arrange
                                                                                                                                                                                              ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                              byte[] testData = "Partial".getBytes();
                                                                                                                                                                                              
                                                                                                                                                                                              // Act
                                                                                                                                                                                              tarOut.write(testData, 0, 3); // Write first 3 bytes
                                                                                                                                                                                              long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                              
                                                                                                                                                                                              // Assert
                                                                                                                                                                                              assertEquals(3, bytesWritten);
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                  public void testWrite_ThrowsWhenExceedingSize() throws Exception {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Set private fields using reflection
                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                      currSizeField.set(tarOut, 100L);
                                                                                                                                                                                      
                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                      currBytesField.set(tarOut, 90L);
                                                                                                                                                                                      
                                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                                      currNameField.set(tarOut, "test.txt");
                                                                                                                                                                                      
                                                                                                                                                                                      byte[] data = new byte[20];
                                                                                                                                                                                      
                                                                                                                                                                                      // Expect exception
                                                                                                                                                                                      ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                      exception.expect(IOException.class);
                                                                                                                                                                                      exception.expectMessage("request to write '20' bytes exceeds size in header of '100' bytes for entry 'test.txt'");
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 20);
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testWrite_EmptyWriteDoesNothing() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                      byte[] data = new byte[0];
                                                                                                                                                                                      
                                                                                                                                                                                      // Get private field assemLen using reflection
                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 0);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      verifyZeroInteractions(mockOut);
                                                                                                                                                                                      assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testWrite_CompletesPartialAssemblyBuffer() throws Exception {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                      currSizeField.set(tarOut, 1024L);
                                                                                                                                                                                      
                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                      assemLenField.set(tarOut, 500);
                                                                                                                                                                                      
                                                                                                                                                                                      byte[] data = new byte[600];
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 600);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      assertEquals(100, assemLenField.get(tarOut)); // 500 + 600 - 1024 = 100 remaining
                                                                                                                                                                                      verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(1024));
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testWrite_AddsToAssemblyBuffer() throws Exception {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                      currSizeField.set(tarOut, 1024L);
                                                                                                                                                                                      
                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                      assemLenField.set(tarOut, 500);
                                                                                                                                                                                      
                                                                                                                                                                                      byte[] data = new byte[100];
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 100);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      assertEquals(600, assemLenField.getInt(tarOut));
                                                                                                                                                                                      verifyZeroInteractions(mockOut);
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testWrite_WritesCompleteRecords() throws Exception {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Set private currSize field using reflection
                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                      currSizeField.set(tarOut, 2048L);
                                                                                                                                                                                      
                                                                                                                                                                                      byte[] data = new byte[1536]; // 1.5 records (assuming default 1024 record size)
                                                                                                                                                                                  
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 1536);
                                                                                                                                                                                  
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      // Get private assemLen field using reflection
                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                      int assemLen = (int) assemLenField.get(tarOut);
                                                                                                                                                                                      
                                                                                                                                                                                      assertEquals(512, assemLen); // remaining 512 bytes
                                                                                                                                                                                      verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(1024));
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testWrite_MultipleCompleteRecords() throws Exception {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut, 1024, 512);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to set private currSize field
                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                      currSizeField.set(tarOut, 2048);
                                                                                                                                                                                      
                                                                                                                                                                                      byte[] data = new byte[2048];
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 2048);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to get private assemLen field
                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                      int assemLen = (int) assemLenField.get(tarOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      assertEquals(0, assemLen); // no remaining bytes
                                                                                                                                                                                      verify(mockOut, times(4)).write(any(byte[].class), eq(0), eq(512));
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testWrite_UpdatesCurrentBytes() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to set private currSize field
                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                      currSizeField.set(tarOut, 2048L);
                                                                                                                                                                                      
                                                                                                                                                                                      byte[] data = new byte[1536]; // 1.5 records
                                                                                                                                                                                      
                                                                                                                                                                                      // Test
                                                                                                                                                                                      tarOut.write(data, 0, 1536);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to verify private currBytes field
                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                      long currBytes = currBytesField.getLong(tarOut);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify - only complete records count
                                                                                                                                                                                      assertEquals(1024, currBytes);
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                         public void testWriteWithZeroAssemLenShouldSkipAssemblyBufferLogic() throws Exception {
                                                                                                                                                                             // Setup
                                                                                                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                             
                                                                                                                                                                             // Set state where assemLen = 0
                                                                                                                                                                             byte[] testData = new byte[10]; // Small data that wouldn't fill a record
                                                                                                                                                                             int recordSize = tarOut.getRecordSize();
                                                                                                                                                                             
                                                                                                                                                                             // Set up test entry
                                                                                                                                                                             ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                             when(mockEntry.getSize()).thenReturn((long)recordSize * 2); // Enough space
                                                                                                                                                                             tarOut.putArchiveEntry(mockEntry);
                                                                                                                                                                             
                                                                                                                                                                             // Use reflection to access private fields
                                                                                                                                                                             Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                             assemLenField.setAccessible(true);
                                                                                                                                                                             Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                             assemBufField.setAccessible(true);
                                                                                                                                                                             
                                                                                                                                                                             // Verify initial state
                                                                                                                                                                             assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                             
                                                                                                                                                                             // Execute - write data with assemLen = 0
                                                                                                                                                                             tarOut.write(testData, 0, testData.length);
                                                                                                                                                                             
                                                                                                                                                                             // Verify behavior - should go straight to while loop, not assembly buffer logic
                                                                                                                                                                             // Check assemLen was updated correctly
                                                                                                                                                                             assertEquals(testData.length, assemLenField.getInt(tarOut));
                                                                                                                                                                             
                                                                                                                                                                             // Verify no records were written yet (since data < recordSize)
                                                                                                                                                                             verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                             
                                                                                                                                                                             // Verify data was copied to assemBuf
                                                                                                                                                                             byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                             byte[] copiedData = new byte[testData.length];
                                                                                                                                                                             System.arraycopy(assemBuf, 0, copiedData, 0, testData.length);
                                                                                                                                                                             assertArrayEquals(testData, copiedData);
                                                                                                                                                                             
                                                                                                                                                                             // Clean up
                                                                                                                                                                             tarOut.closeArchiveEntry();
                                                                                                                                                                         }

 @Test
                                                                                                                                                                public void testWrite_ExactBufferSizeShouldWriteRecord() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                    // Setup
                                                                                                                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                    
                                                                                                                                                                    // Get internal fields via reflection
                                                                                                                                                                    Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                    bufferField.setAccessible(true);
                                                                                                                                                                    Object buffer = bufferField.get(tarOut);
                                                                                                                                                                    
                                                                                                                                                                    Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                    recordBufField.setAccessible(true);
                                                                                                                                                                    byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                    int recordSize = recordBuf.length;
                                                                                                                                                                    
                                                                                                                                                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                    assemLenField.setAccessible(true);
                                                                                                                                                                    assemLenField.set(tarOut, recordSize - 10); // Leave 10 bytes remaining
                                                                                                                                                                    
                                                                                                                                                                    Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                    assemBufField.setAccessible(true);
                                                                                                                                                                    byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                    
                                                                                                                                                                    // Test data - exactly fills remaining buffer
                                                                                                                                                                    byte[] testData = new byte[10];
                                                                                                                                                                    java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    tarOut.write(testData, 0, 10);
                                                                                                                                                                    
                                                                                                                                                                    // Verify assembly buffer is reset
                                                                                                                                                                    assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                    
                                                                                                                                                                    // Verify data was written to the output stream
                                                                                                                                                                    verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                }

 @Test
                                                                                                                                                           public void testWriteWithPartialAssemblyDetectsOffsetMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                               // Setup
                                                                                                                                                               ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                               
                                                                                                                                                               // Initialize state to trigger the assembly path
                                                                                                                                                               int recordSize = tarOut.getRecordSize();
                                                                                                                                                               byte[] data = new byte[recordSize * 2]; // Enough to trigger assembly
                                                                                                                                                               
                                                                                                                                                               // Fill with test data
                                                                                                                                                               java.util.Arrays.fill(data, (byte)1);
                                                                                                                                                               
                                                                                                                                                               // Set up initial assembly state
                                                                                                                                                               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                               assemLenField.setAccessible(true);
                                                                                                                                                               assemLenField.set(tarOut, recordSize / 2); // Half a record already assembled
                                                                                                                                                               
                                                                                                                                                               Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                               assemBufField.setAccessible(true);
                                                                                                                                                               byte[] assemBuf = (byte[])assemBufField.get(tarOut);
                                                                                                                                                               java.util.Arrays.fill(assemBuf, 0, recordSize / 2, (byte)2);
                                                                                                                                                               
                                                                                                                                                               // Initial offset
                                                                                                                                                               int initialOffset = 10;
                                                                                                                                                               
                                                                                                                                                               // Test
                                                                                                                                                               tarOut.write(data, initialOffset, recordSize); // Should trigger assembly path
                                                                                                                                                               
                                                                                                                                                               // Verify offset moved forward correctly
                                                                                                                                                               Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                                                                                                                                               wOffsetField.setAccessible(true);
                                                                                                                                                               int finalOffset = (int)wOffsetField.get(tarOut);
                                                                                                                                                               
                                                                                                                                                               // Calculate expected offset movement
                                                                                                                                                               int aLen = recordSize - (recordSize / 2);
                                                                                                                                                               int expectedOffset = initialOffset + aLen;
                                                                                                                                                               
                                                                                                                                                               // Assert offset moved forward (would fail with mutant)
                                                                                                                                                               assertEquals("Write offset should increase by aLen", 
                                                                                                                                                                           expectedOffset, finalOffset);
                                                                                                                                                               
                                                                                                                                                               // Additional verification of written data if needed
                                                                                                                                                               tarOut.close();
                                                                                                                                                           }

 @Test
                                                                                                                                                      public void testWriteWithExactRecordSizeShouldNotLoopWhenZero() throws Exception {
                                                                                                                                                          // Setup
                                                                                                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                          
                                                                                                                                                          // Set up test data where numToWrite exactly matches record size
                                                                                                                                                          int recordSize = tarOut.getRecordSize();
                                                                                                                                                          byte[] testData = new byte[recordSize];
                                                                                                                                                          java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                          
                                                                                                                                                          // Set current entry parameters using reflection
                                                                                                                                                          tarOut.putArchiveEntry(new TarArchiveEntry("test"));
                                                                                                                                                          Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                          currSizeField.setAccessible(true);
                                                                                                                                                          currSizeField.set(tarOut, recordSize * 2); // Allow writing
                                                                                                                                                          
                                                                                                                                                          // Execute - write exactly one record's worth of data
                                                                                                                                                          tarOut.write(testData, 0, recordSize);
                                                                                                                                                          
                                                                                                                                                          // Verify
                                                                                                                                                          // Original code would complete, mutant would continue looping
                                                                                                                                                          assertEquals("Should have written exactly one record worth of bytes",
                                                                                                                                                                      recordSize, tarOut.getBytesWritten());
                                                                                                                                                          
                                                                                                                                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                          assemLenField.setAccessible(true);
                                                                                                                                                          assertEquals("Assembly buffer should be empty",
                                                                                                                                                                      0, assemLenField.get(tarOut));
                                                                                                                                                          
                                                                                                                                                          // Verify buffer was written exactly once
                                                                                                                                                          verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                                                                          
                                                                                                                                                          // Clean up
                                                                                                                                                          tarOut.closeArchiveEntry();
                                                                                                                                                      }

 @Test
                                                                                                                                                 public void testWriteWhenNumToWriteEqualsRecordSize() throws Exception {
                                                                                                                                                     // Setup
                                                                                                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                     int recordSize = 512; // Default record size
                                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos, recordSize);
                                                                                                                                                     
                                                                                                                                                     // Create test data exactly matching record size
                                                                                                                                                     byte[] testData = new byte[recordSize];
                                                                                                                                                     java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                     
                                                                                                                                                     // Get the buffer instance through reflection
                                                                                                                                                     Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                     bufferField.setAccessible(true);
                                                                                                                                                     Object buffer = bufferField.get(tarOut);
                                                                                                                                                     
                                                                                                                                                     // Get the recordBuf to verify writes
                                                                                                                                                     Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                     recordBufField.setAccessible(true);
                                                                                                                                                     byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                     
                                                                                                                                                     // Set initial state
                                                                                                                                                     Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                     assemLenField.setAccessible(true);
                                                                                                                                                     assemLenField.set(tarOut, 0);
                                                                                                                                                     
                                                                                                                                                     // Execute - write exactly one record's worth of data
                                                                                                                                                     tarOut.write(testData, 0, recordSize);
                                                                                                                                                     
                                                                                                                                                     // Verify
                                                                                                                                                     // Data should be written directly without buffering
                                                                                                                                                     assertEquals("Data should be written directly without buffering", 
                                                                                                                                                                 0, assemLenField.get(tarOut));
                                                                                                                                                     
                                                                                                                                                     // Verify the data was written to the buffer by checking the output
                                                                                                                                                     tarOut.flush();
                                                                                                                                                     byte[] output = baos.toByteArray();
                                                                                                                                                     assertTrue("Output should contain the test data", 
                                                                                                                                                               output.length >= recordSize);
                                                                                                                                                     
                                                                                                                                                     // Clean up
                                                                                                                                                     tarOut.close();
                                                                                                                                                 }

 @Test
                                                                                                                                            public void testWriteAccumulatesBytesCorrectly() throws IOException {
                                                                                                                                                // Helper method to count bytes with specific value
                                                                                                                                                java.util.function.ToIntFunction<byte[]> countBytes = (arr) -> {
                                                                                                                                                    int count = 0;
                                                                                                                                                    for (byte b : arr) {
                                                                                                                                                        if (b == (byte)1) {
                                                                                                                                                            count++;
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    return count;
                                                                                                                                                };
                                                                                                                                            
                                                                                                                                                // Setup
                                                                                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                
                                                                                                                                                // Set up a test entry
                                                                                                                                                ArchiveEntry entry = mock(ArchiveEntry.class);
                                                                                                                                                when(entry.getSize()).thenReturn(2048L); // Allow enough space for multiple writes
                                                                                                                                                tarOut.putArchiveEntry(entry);
                                                                                                                                                
                                                                                                                                                // Prepare test data - need enough to trigger multiple record writes
                                                                                                                                                byte[] data = new byte[1024]; // 2 full records (assuming default 512-byte records)
                                                                                                                                                java.util.Arrays.fill(data, (byte)1);
                                                                                                                                                
                                                                                                                                                // Action - write the data
                                                                                                                                                tarOut.write(data, 0, data.length);
                                                                                                                                                tarOut.closeArchiveEntry();
                                                                                                                                                
                                                                                                                                                // Verification
                                                                                                                                                // Original behavior: currBytes should be 1024 (accumulated)
                                                                                                                                                // Mutant behavior: currBytes would be 512 (last assigned value)
                                                                                                                                                assertEquals("Bytes written should accumulate properly", 
                                                                                                                                                            1024L, tarOut.getBytesWritten());
                                                                                                                                                
                                                                                                                                                // Additional verification that records were written correctly
                                                                                                                                                byte[] output = baos.toByteArray();
                                                                                                                                                assertEquals("Output should contain all written data", 
                                                                                                                                                            1024, countBytes.applyAsInt(output));
                                                                                                                                            }

 @Test
                                                                                                                                   public void testWriteMultipleRecordsUpdatesOffsetCorrectly() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                       // Setup
                                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                       
                                                                                                                                       // Get the record buffer to determine record size
                                                                                                                                       Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                       recordBufField.setAccessible(true);
                                                                                                                                       byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                       int recordSize = recordBuf.length;
                                                                                                                                       
                                                                                                                                       // Create test data that spans multiple records
                                                                                                                                       int totalBytes = recordSize * 2 + 10; // 2 full records + partial
                                                                                                                                       byte[] testData = new byte[totalBytes];
                                                                                                                                       java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                       
                                                                                                                                       // Test
                                                                                                                                       tarOut.write(testData, 0, totalBytes);
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       // Check final wOffset - should be equal to total bytes written (2 full records)
                                                                                                                                       Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                                                                                                                       wOffsetField.setAccessible(true);
                                                                                                                                       int finalOffset = (int) wOffsetField.get(tarOut);
                                                                                                                                       assertEquals("Write offset should equal total bytes written", 
                                                                                                                                                   recordSize * 2, finalOffset);
                                                                                                                                       
                                                                                                                                       // Verify remaining bytes were properly assembled
                                                                                                                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                       assemLenField.setAccessible(true);
                                                                                                                                       int assemLen = (int) assemLenField.get(tarOut);
                                                                                                                                       assertEquals("Remaining bytes should be in assembly buffer", 
                                                                                                                                                   10, assemLen);
                                                                                                                                   }

 @Test
                                                                                                                          public void testWriteWithZeroAssemLenShouldSkipAssemblyLogic() throws Exception {
                                                                                                                              // Setup
                                                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                                                              
                                                                                                                              // Create test instance with mocked output stream
                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                              
                                                                                                                              // Get the real buffer instance created by the constructor
                                                                                                                              Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                              bufferField.setAccessible(true);
                                                                                                                              Object realBuffer = bufferField.get(tarOut);
                                                                                                                              
                                                                                                                              // Mock the buffer's output stream to verify interactions
                                                                                                                              Field outField = realBuffer.getClass().getDeclaredField("out");
                                                                                                                              outField.setAccessible(true);
                                                                                                                              OutputStream bufferOut = mock(OutputStream.class);
                                                                                                                              outField.set(realBuffer, bufferOut);
                                                                                                                              
                                                                                                                              // Set initial conditions: assemLen = 0, recordBuf.length = 512
                                                                                                                              Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                              assemLenField.setAccessible(true);
                                                                                                                              assemLenField.set(tarOut, 0);
                                                                                                                              
                                                                                                                              Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                              recordBufField.setAccessible(true);
                                                                                                                              recordBufField.set(tarOut, new byte[512]);
                                                                                                                              
                                                                                                                              // Test data - small write that should go directly to assembly buffer
                                                                                                                              byte[] testData = new byte[100];
                                                                                                                              
                                                                                                                              // Execute
                                                                                                                              tarOut.write(testData, 0, testData.length);
                                                                                                                              
                                                                                                                              // Verify - should NOT interact with buffer when assemLen is 0
                                                                                                                              verify(bufferOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                              
                                                                                                                              // Verify data was copied to assembly buffer
                                                                                                                              Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                              assemBufField.setAccessible(true);
                                                                                                                              byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                              assertEquals(testData.length, assemLenField.get(tarOut));
                                                                                                                              assertArrayEquals(testData, java.util.Arrays.copyOf(assemBuf, testData.length));
                                                                                                                          }

 @Test
                                                                                                                     public void testWrite_AssemblyBufferBoundaryCase() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                         // Setup
                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                         
                                                                                                                         // Set up initial assembly buffer state
                                                                                                                         int recordSize = tarOut.getRecordSize();
                                                                                                                         int initialAssemLen = recordSize / 2;
                                                                                                                         byte[] testData = new byte[recordSize];
                                                                                                                         
                                                                                                                         // Use reflection to set private fields for testing
                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                         assemLenField.set(tarOut, initialAssemLen);
                                                                                                                         
                                                                                                                         Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                         assemBufField.setAccessible(true);
                                                                                                                         byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                         System.arraycopy(testData, 0, assemBuf, 0, initialAssemLen);
                                                                                                                         
                                                                                                                         // Test case where assemLen + numToWrite exactly equals record size
                                                                                                                         int numToWrite = recordSize - initialAssemLen;
                                                                                                                         
                                                                                                                         // Execute
                                                                                                                         tarOut.write(testData, 0, numToWrite);
                                                                                                                         
                                                                                                                         // Verify - should have written one complete record
                                                                                                                         verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                                         
                                                                                                                         // Verify assembly buffer was reset
                                                                                                                         assertEquals(0, assemLenField.get(tarOut));
                                                                                                                     }

 @Test
                                                                                                            public void testWriteWithPartialAssemblyBuffer() throws Exception {
                                                                                                                // Setup
                                                                                                                ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                int recordSize = 512; // Default tar record size
                                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                
                                                                                                                // Set up initial state with partial assembly buffer
                                                                                                                byte[] testData = new byte[600]; // More than one record
                                                                                                                java.util.Arrays.fill(testData, (byte)1);
                                                                                                                tarOut.putArchiveEntry(new TarArchiveEntry("test"));
                                                                                                                
                                                                                                                // Set up assembly buffer state using reflection
                                                                                                                java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                assemLenField.setAccessible(true);
                                                                                                                assemLenField.set(tarOut, 300); // Partially filled assembly buffer
                                                                                                                
                                                                                                                java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                assemBufField.setAccessible(true);
                                                                                                                byte[] assemBuf = (byte[])assemBufField.get(tarOut);
                                                                                                                java.util.Arrays.fill(assemBuf, 0, 300, (byte)2); // Fill with different pattern
                                                                                                                
                                                                                                                // Execute
                                                                                                                tarOut.write(testData, 0, 300); // Write enough to fill record
                                                                                                                
                                                                                                                // Verify by checking the output stream contents
                                                                                                                byte[] output = out.toByteArray();
                                                                                                                
                                                                                                                // Should have written at least one complete record (512 bytes)
                                                                                                                assertTrue(output.length >= recordSize);
                                                                                                                
                                                                                                                // First 300 bytes should be from assembly buffer (value 2)
                                                                                                                for (int i = 0; i < 300; i++) {
                                                                                                                    assertEquals((byte)2, output[i]);
                                                                                                                }
                                                                                                                // Next 212 bytes should be from write buffer (value 1)
                                                                                                                for (int i = 300; i < 512; i++) {
                                                                                                                    assertEquals((byte)1, output[i]);
                                                                                                                }
                                                                                                                
                                                                                                                // Verify offsets updated correctly
                                                                                                                assertEquals(0, assemLenField.get(tarOut)); // Should be 0 after write
                                                                                                                assertEquals(512, tarOut.getBytesWritten()); // Full record written
                                                                                                            }

 @Test
                                                                                                       public void testWriteWithAssemblyBufferFillingRecord() throws IOException {
                                                                                                           // Setup
                                                                                                           ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                           
                                                                                                           // Set up initial state with partial record in assembly buffer
                                                                                                           int recordSize = tarOut.getRecordSize();
                                                                                                           byte[] testData = new byte[recordSize * 2]; // Enough data for two records
                                                                                                           java.util.Arrays.fill(testData, (byte)1); // Fill with test pattern
                                                                                                           
                                                                                                           // First write - partial record to fill assembly buffer
                                                                                                           int firstWriteSize = recordSize / 2;
                                                                                                           tarOut.write(testData, 0, firstWriteSize);
                                                                                                           
                                                                                                           // Second write - enough to complete the record
                                                                                                           int secondWriteSize = recordSize;
                                                                                                           tarOut.write(testData, firstWriteSize, secondWriteSize);
                                                                                                           
                                                                                                           // Verify the wOffset was correctly updated by checking subsequent write
                                                                                                           // If mutant exists (wOffset -= aLen), this would write from wrong position
                                                                                                           int thirdWriteSize = recordSize / 4;
                                                                                                           tarOut.write(testData, firstWriteSize + secondWriteSize, thirdWriteSize);
                                                                                                           
                                                                                                           // Close to flush any remaining data
                                                                                                           tarOut.close();
                                                                                                           
                                                                                                           // Verify the written data
                                                                                                           byte[] writtenData = baos.toByteArray();
                                                                                                           // Should have written first full record (assembly + first part of second write)
                                                                                                           assertEquals(recordSize, writtenData.length);
                                                                                                           
                                                                                                           // Verify all bytes in record are 1 (our test pattern)
                                                                                                           for (byte b : writtenData) {
                                                                                                               assertEquals(1, b);
                                                                                                           }
                                                                                                           
                                                                                                           // If mutant exists, the third write would have tried to write from negative offset
                                                                                                           // and either thrown exception or written wrong data
                                                                                                       }

 @Test
                                                                                                  public void testWriteWithExactBlockSizeShouldTerminateProperly() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                      // Setup
                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                      
                                                                                                      // Set up test data where numToWrite exactly matches record size
                                                                                                      int recordSize = tarOut.getRecordSize();
                                                                                                      byte[] testData = new byte[recordSize];
                                                                                                      java.util.Arrays.fill(testData, (byte)1);  // Fill with some data
                                                                                                      
                                                                                                      // Set current entry details
                                                                                                      tarOut.putArchiveEntry(new TarArchiveEntry("test"));
                                                                                                      
                                                                                                      // Use reflection to set private currSize field
                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                      currSizeField.setAccessible(true);
                                                                                                      currSizeField.set(tarOut, recordSize * 2L);  // Allow writing
                                                                                                      
                                                                                                      // Test exact block size write
                                                                                                      tarOut.write(testData, 0, recordSize);
                                                                                                      
                                                                                                      // Verify
                                                                                                      // Original code would write exactly once and terminate
                                                                                                      // Mutant would continue looping with numToWrite=0
                                                                                                      verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                      
                                                                                                      // Additional verification that assembly buffer is empty
                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                      assemLenField.setAccessible(true);
                                                                                                      assertEquals(0, assemLenField.get(tarOut));
                                                                                                      
                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                      currBytesField.setAccessible(true);
                                                                                                      assertEquals(recordSize, currBytesField.get(tarOut));
                                                                                                  }

 @Test
                                                                                             public void testWriteWhenNumToWriteEqualsRecordSize1() throws Exception {
                                                                                                 // Setup
                                                                                                 ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                 int recordSize = 512; // Default record size
                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                 
                                                                                                 // Create a test entry
                                                                                                 ArchiveEntry entry = mock(ArchiveEntry.class);
                                                                                                 when(entry.getSize()).thenReturn(recordSize * 2L); // Allow writing at least 2 records
                                                                                                 tarOut.putArchiveEntry(entry);
                                                                                                 
                                                                                                 // Prepare test data exactly matching record size
                                                                                                 byte[] testData = new byte[recordSize];
                                                                                                 java.util.Arrays.fill(testData, (byte)1);
                                                                                                 
                                                                                                 // Execute - write exactly one record's worth of data
                                                                                                 tarOut.write(testData, 0, recordSize);
                                                                                                 
                                                                                                 // Verify - in original code, assemLen should remain 0 as it writes complete record
                                                                                                 // In mutant, assemLen would be recordSize (incorrect)
                                                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                 assemLenField.setAccessible(true);
                                                                                                 int assemLen = assemLenField.getInt(tarOut);
                                                                                                 assertEquals("Assembly buffer should be empty when writing exact record size", 
                                                                                                              0, assemLen);
                                                                                                 
                                                                                                 // Additional verification that data was written correctly
                                                                                                 tarOut.closeArchiveEntry();
                                                                                                 byte[] written = baos.toByteArray();
                                                                                                 assertTrue("Data should be written to output", written.length >= recordSize);
                                                                                                 
                                                                                                 // Verify first record matches our test data
                                                                                                 byte[] firstRecord = java.util.Arrays.copyOfRange(written, 0, recordSize);
                                                                                                 assertArrayEquals("First record should match written data", testData, firstRecord);
                                                                                             }

 @Test
                                                                                        public void testWriteMultipleRecordsAccumulatesBytesCorrectly() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                            // Setup
                                                                                            OutputStream mockOut = mock(OutputStream.class);
                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                            
                                                                                            // Use reflection to get buffer and set up test conditions
                                                                                            Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                            bufferField.setAccessible(true);
                                                                                            Object buffer = bufferField.get(tarOut);
                                                                                            
                                                                                            Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                            recordBufField.setAccessible(true);
                                                                                            byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                            int recordSize = recordBuf.length;
                                                                                            
                                                                                            // Set up test data - write enough data for 3 full records
                                                                                            byte[] testData = new byte[recordSize * 3];
                                                                                            java.util.Arrays.fill(testData, (byte)1);
                                                                                            
                                                                                            // Set current entry size large enough to accept all data
                                                                                            Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                            currSizeField.setAccessible(true);
                                                                                            currSizeField.set(tarOut, recordSize * 3L);
                                                                                            
                                                                                            // Act
                                                                                            tarOut.write(testData, 0, testData.length);
                                                                                            
                                                                                            // Verify currBytes was accumulated correctly (should be recordSize * 3)
                                                                                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                            currBytesField.setAccessible(true);
                                                                                            long actualBytes = (long) currBytesField.get(tarOut);
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals("currBytes should accumulate across multiple writes", 
                                                                                                       recordSize * 3L, actualBytes);
                                                                                            
                                                                                            // Verify buffer wrote 3 records by checking the output stream
                                                                                            verify(mockOut, times(3)).write(any(byte[].class), anyInt(), eq(recordSize));
                                                                                        }

 @Test
                                                                               public void testWriteWithMultipleRecordsDetectsOffsetMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                   // Setup
                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                   
                                                                                   // Set up test data - need enough to trigger multiple record writes
                                                                                   byte[] recordBuf = new byte[512]; // default record size
                                                                                   Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                   recordBufField.setAccessible(true);
                                                                                   recordBufField.set(tarOut, recordBuf);
                                                                                   
                                                                                   byte[] testData = new byte[1024]; // 2 full records
                                                                                   java.util.Arrays.fill(testData, (byte)1);
                                                                                   
                                                                                   // Act
                                                                                   tarOut.write(testData, 0, testData.length);
                                                                                   
                                                                                   // Assert - verify the output stream received the correct data
                                                                                   // Each record is 512 bytes, so we should have 2 full writes
                                                                                   verify(mockOut, times(2)).write(any(byte[].class), eq(0), eq(512));
                                                                                   
                                                                                   // Verify wOffset would be incorrect with mutation (would be 512 instead of 1024)
                                                                                   Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                                                                   wOffsetField.setAccessible(true);
                                                                                   int finalOffset = (int)wOffsetField.get(tarOut);
                                                                                   assertEquals("Final offset should be sum of all writes", 1024, finalOffset);
                                                                               }

 @Test
                                                                          public void testWriteWithZeroAssemLenShouldNotPerformAssembly() throws Exception {
                                                                              // Setup
                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                              
                                                                              // Set initial conditions where assemLen is 0
                                                                              Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                              assemLenField.setAccessible(true);
                                                                              assemLenField.set(tarOut, 0);
                                                                              
                                                                              Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                              assemBufField.setAccessible(true);
                                                                              byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                              
                                                                              // Create test data that would trigger assembly if condition was >= 0
                                                                              byte[] testData = new byte[100]; // Smaller than record size
                                                                              for (int i = 0; i < testData.length; i++) {
                                                                                  testData[i] = (byte)1;
                                                                              }
                                                                              
                                                                              // Act
                                                                              tarOut.write(testData, 0, testData.length);
                                                                              
                                                                              // Verify assembly buffer wasn't touched when assemLen was 0
                                                                              byte[] expectedAssemBuf = new byte[assemBuf.length]; // All zeros
                                                                              assertArrayEquals("Assembly buffer should not be modified when assemLen is 0", 
                                                                                               expectedAssemBuf, assemBuf);
                                                                              
                                                                              // Verify assemLen was updated correctly (only by the while loop part)
                                                                              assertEquals("assemLen should equal the written data size", 
                                                                                          testData.length, assemLenField.get(tarOut));
                                                                              
                                                                              // Verify no records were written to buffer (since data was small and should be buffered)
                                                                              verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                          }

 @Test
                                                             public void testWrite_AssembledBufferExactlyFillsRecord() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                 // Setup
                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                 
                                                                 // Get the real buffer instance and spy on it
                                                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                 bufferField.setAccessible(true);
                                                                 Object realBuffer = bufferField.get(tarOut);
                                                                 Object spyBuffer = spy(realBuffer);
                                                                 bufferField.set(tarOut, spyBuffer);
                                                                 
                                                                 Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                 recordBufField.setAccessible(true);
                                                                 byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                 int recordSize = recordBuf.length;
                                                                 
                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                 assemLenField.setAccessible(true);
                                                                 assemLenField.set(tarOut, 1); // Set some assembled data
                                                                 
                                                                 Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                 assemBufField.setAccessible(true);
                                                                 byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                 assemBuf[0] = (byte) 0xFF; // Set some dummy data
                                                                 
                                                                 // Test data where assemLen + numToWrite exactly equals record size
                                                                 byte[] testData = new byte[recordSize - 1];
                                                                 java.util.Arrays.fill(testData, (byte) 0xAA);
                                                                 
                                                                 // Execute
                                                                 tarOut.write(testData, 0, testData.length);
                                                                 
                                                                 // Verify - should write to output stream
                                                                 verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                 
                                                                 // Additional verification of state changes
                                                                 assertEquals(0, assemLenField.get(tarOut)); // Should be 0 after write
                                                             }

 @Test
                                            public void testWriteWithPartialAssemblyBuffer1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                // Setup
                                                ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                int recordSize = 512; // Default tar record size
                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                
                                                // Set up initial state with partial assembly buffer
                                                byte[] testData = new byte[600]; // More than one record
                                                java.util.Arrays.fill(testData, (byte)1);
                                                tarOut.write(testData, 0, 300); // Write partial record (fills assembly buffer)
                                                
                                                // Get internal fields
                                                Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                assemLenField.setAccessible(true);
                                                assemLenField.set(tarOut, 300); // Half-filled assembly buffer
                                                
                                                Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                assemBufField.setAccessible(true);
                                                byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                
                                                Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                recordBufField.setAccessible(true);
                                                byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                
                                                // Test data that will trigger the branch
                                                byte[] writeData = new byte[300]; // Will make total 600 (300+300)
                                                java.util.Arrays.fill(writeData, (byte)2);
                                                
                                                // Execute
                                                tarOut.write(writeData, 0, 300);
                                                
                                                // Verify
                                                // Check assembly buffer state
                                                int newAssemLen = (Integer)assemLenField.get(tarOut);
                                                assertEquals(88, newAssemLen); // 600 - 512 = 88 remaining
                                                
                                                // Verify correct bytes were written to output
                                                byte[] output = out.toByteArray();
                                                assertTrue(output.length >= 512); // At least one full record written
                                                
                                                // First 300 bytes should be from assembly buffer (1s)
                                                for (int i = 0; i < 300; i++) {
                                                    assertEquals((byte)1, output[i]);
                                                }
                                                // Next 212 bytes should be from new data (2s)
                                                for (int i = 300; i < 512; i++) {
                                                    assertEquals((byte)2, output[i]);
                                                }
                                            }

 @Test
                                       public void testWriteWithPartialAssemblyDetectsOffsetMutation1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                           // Setup
                                           ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                           
                                           // Initialize state to trigger the assembly path
                                           int recordSize = tarOut.getRecordSize();
                                           byte[] data = new byte[recordSize * 2]; // Enough data to require assembly
                                           
                                           // Set up initial assembly buffer state
                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                           assemLenField.setAccessible(true);
                                           assemLenField.set(tarOut, recordSize / 2); // Half a record already in assembly
                                           
                                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                           assemBufField.setAccessible(true);
                                           byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                           java.util.Arrays.fill(assemBuf, 0, recordSize / 2, (byte)1); // Fill with test data
                                           
                                           // Set up current entry
                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                           currSizeField.setAccessible(true);
                                           currSizeField.set(tarOut, recordSize * 3L); // Enough space
                                           
                                           // Write data that will trigger the assembly path
                                           int writeSize = recordSize; // Enough to complete a full record when combined with assembly
                                           tarOut.write(data, 0, writeSize);
                                           
                                           // Verify the offset was correctly updated
                                           Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                           wOffsetField.setAccessible(true);
                                           int actualOffset = (int) wOffsetField.get(tarOut);
                                           
                                           // Expected offset should be the amount written (recordSize - assemLen)
                                           int expectedOffset = recordSize - (recordSize / 2);
                                           assertEquals("Write offset was not correctly updated", expectedOffset, actualOffset);
                                           
                                           // Verify the remaining bytes to write were updated correctly
                                           Field numToWriteField = TarArchiveOutputStream.class.getDeclaredField("numToWrite");
                                           numToWriteField.setAccessible(true);
                                           int remainingBytes = (int) numToWriteField.get(tarOut);
                                           assertEquals("Remaining bytes calculation incorrect", writeSize - expectedOffset, remainingBytes);
                                           
                                           // Verify assembly buffer was cleared
                                           int currentAssemLen = (int) assemLenField.get(tarOut);
                                           assertEquals("Assembly buffer should be empty after writing full record", 0, currentAssemLen);
                                       }

 @Test
                                   public void testWriteWithZeroBytesShouldCompleteImmediately() throws IOException {
                                       // Setup
                                       OutputStream mockOut = mock(OutputStream.class);
                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                       
                                       // Set up entry
                                       ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                       when(mockEntry.getSize()).thenReturn(1024L);
                                       tarOut.putArchiveEntry(mockEntry);
                                       
                                       // Test writing 0 bytes
                                       byte[] emptyData = new byte[0];
                                       tarOut.write(emptyData, 0, 0);
                                       
                                       // Verify no writes occurred
                                       verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                       assertEquals(0, tarOut.getBytesWritten());
                                       assertEquals(0, tarOut.getCount());
                                   }

 @Test
                                  public void testWriteWithExactBufferSizeShouldComplete() throws IOException {
                                      // Setup
                                      OutputStream mockOut = mock(OutputStream.class);
                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                      
                                      // Set up entry
                                      ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                      when(mockEntry.getSize()).thenReturn(1024L); // Large enough to avoid size check
                                      tarOut.putArchiveEntry(mockEntry);
                                      
                                      // Prepare test data - exactly one record size
                                      int recordSize = tarOut.getRecordSize();
                                      byte[] testData = new byte[recordSize];
                                      java.util.Arrays.fill(testData, (byte)1);
                                      
                                      // Test the write
                                      tarOut.write(testData, 0, testData.length);
                                      
                                      // Verify behavior
                                      // Original: Should complete normally
                                      // Mutant: Would potentially hang or process extra empty record
                                      verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                      
                                      // Additional verification
                                      assertEquals(recordSize, tarOut.getBytesWritten());
                                      assertEquals(0, tarOut.getCount()); // assembly buffer should be empty
                                  }

 @Test
     public void testWriteWhenNumToWriteEqualsRecordSize2() throws Exception {
         // Setup
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         int recordSize = 512; // Default tar record size
         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
         
         // Set up test data - exactly one record's worth
         byte[] testData = new byte[recordSize];
         java.util.Arrays.fill(testData, (byte)1);
         
         // Use reflection to access and modify private fields
         Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
         bufferField.setAccessible(true);
         Object originalBuffer = bufferField.get(tarOut);
         
         // Instead of mocking TarBuffer, we'll verify the output
         // Set initial state using reflection
         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
         assemLenField.setAccessible(true);
         assemLenField.set(tarOut, 0);
         
         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
         currBytesField.setAccessible(true);
         currBytesField.set(tarOut, 0);
         
         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
         currSizeField.setAccessible(true);
         currSizeField.set(tarOut, recordSize * 2); // Enough space
         
         // Execute
         tarOut.write(testData, 0, recordSize);
         
         // Verify - check the output stream contains our data
         byte[] output = baos.toByteArray();
         assertTrue(output.length >= recordSize); // Should have at least one record
         
         // Verify state using reflection
         assertEquals(0, assemLenField.get(tarOut)); // Nothing should be in assembly buffer
         assertEquals(recordSize, currBytesField.get(tarOut)); // Bytes written should increment
         
         // Restore original buffer
         bufferField.set(tarOut, originalBuffer);
     }

 @Test
 public void testWriteAccumulatesBytesCorrectly1() throws IOException {
     // Setup
     OutputStream mockOut = mock(OutputStream.class);
     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
     
     // Set up a test entry
     ArchiveEntry mockEntry = mock(ArchiveEntry.class);
     when(mockEntry.getSize()).thenReturn(1024L); // Large enough to allow multiple writes
     when(mockEntry.getName()).thenReturn("test.txt");
     tarOut.putArchiveEntry(mockEntry);
     
     // Prepare test data - write multiple records
     int recordSize = tarOut.getRecordSize();
     byte[] data1 = new byte[recordSize]; // First full record
     byte[] data2 = new byte[recordSize]; // Second full record
     byte[] data3 = new byte[recordSize / 2]; // Partial record
     
     // Perform writes
     tarOut.write(data1, 0, data1.length);
     tarOut.write(data2, 0, data2.length);
     tarOut.write(data3, 0, data3.length);
     
     // Verify
     long expectedBytes = data1.length + data2.length + data3.length;
     assertEquals("currBytes should accumulate all written bytes", 
                 expectedBytes, 
                 tarOut.getBytesWritten());
     
     tarOut.closeArchiveEntry();
 }

}
