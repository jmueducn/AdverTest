package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                 public void testParseOctal_ValidInput() {
                                                     byte[] buffer = {' ', '1', '2', '3', ' ', '4', '5', ' ', 0};
                                                     long result = TarUtils.parseOctal(buffer, 0, 9);
                                                     assertEquals(012345L, result);
                                                 }

 @Test
                                                 public void testParseOctal_LeadingZeros() {
                                                     byte[] buffer = {'0', '0', '7', '5', ' ', 0};
                                                     long result = TarUtils.parseOctal(buffer, 0, 6);
                                                     assertEquals(075L, result);
                                                 }

 @Test
                                                 public void testParseOctal_AllZeros() {
                                                     byte[] buffer = {'0', '0', '0', '0', 0};
                                                     long result = TarUtils.parseOctal(buffer, 0, 5);
                                                     assertEquals(0L, result);
                                                 }

 @Test
                                                 public void testParseOctal_LeadingSpaces() {
                                                     byte[] buffer = {' ', ' ', '7', '5', ' ', 0};
                                                     long result = TarUtils.parseOctal(buffer, 0, 6);
                                                     assertEquals(075L, result);
                                                 }

 @Test
                                                 public void testParseOctal_TrailingSpacesAndNulls() {
                                                     byte[] buffer = {'1', '2', '3', ' ', ' ', 0, 0};
                                                     long result = TarUtils.parseOctal(buffer, 0, 7);
                                                     assertEquals(0123L, result);
                                                 }

 @Test
                                                 public void testParseOctal_MaxValidOctal() {
                                                     byte[] buffer = {'1', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                     long result = TarUtils.parseOctal(buffer, 0, 12);
                                                     assertEquals(Long.MAX_VALUE, result);
                                                 }

 @Test
                                                 public void testParseOctal_OffsetParameter() {
                                                     byte[] buffer = {'x', 'x', '1', '2', '3', '4', 'x', 'x'};
                                                     long result = TarUtils.parseOctal(buffer, 2, 4);
                                                     assertEquals(01234L, result);
                                                 }

 @Test
                                                 public void testParseOctal_LengthTooShort() {
                                                     byte[] buffer = {'1'};
                                                     thrown.expect(IllegalArgumentException.class);
                                                     thrown.expectMessage("Length 1 must be at least 2");
                                                     TarUtils.parseOctal(buffer, 0, 1);
                                                 }

 @Test
                                                 public void testParseOctal_InvalidOctalDigit() {
                                                     byte[] buffer = {'1', '2', '8', '4'}; // '8' is invalid in octal
                                                     thrown.expect(IllegalArgumentException.class);
                                                     TarUtils.parseOctal(buffer, 0, 4);
                                                 }

 @Test
                                                 public void testParseOctal_EmptyAfterTrimming() {
                                                     byte[] buffer = {' ', ' ', ' ', ' '};
                                                     thrown.expect(IllegalArgumentException.class);
                                                     TarUtils.parseOctal(buffer, 0, 4);
                                                 }

 @Test
                                                 public void testParseOctal_AllSpaces() {
                                                     byte[] buffer = {' ', ' ', ' ', ' ', ' '};
                                                     thrown.expect(IllegalArgumentException.class);
                                                     TarUtils.parseOctal(buffer, 0, 5);
                                                 }

 @Test
                                                 public void testParseOctal_NullByteOnly() {
                                                     byte[] buffer = {0, 0, 0};
                                                     thrown.expect(IllegalArgumentException.class);
                                                     TarUtils.parseOctal(buffer, 0, 3);
                                                 }

 @Test
                                                 public void testParseOctal_FirstByteZero() {
                                                     byte[] buffer = {0, '1', '2', '3'};
                                                     long result = TarUtils.parseOctal(buffer, 0, 4);
                                                     assertEquals(0L, result);
                                                 }

 @Test
 public void testParseOctalWithLength2ShouldNotThrowException() {
     // Arrange
     byte[] buffer = {' ', '1', '2'}; // valid octal "12" with length=2
     int offset = 1; // skip the leading space
     int length = 2;
     
     // Act & Assert
     try {
         long result = TarUtils.parseOctal(buffer, offset, length);
         assertEquals(10L, result); // "12" in octal is 10 in decimal
     } catch (IllegalArgumentException e) {
         fail("Should not throw exception for length=2 input");
     }
 }

}
