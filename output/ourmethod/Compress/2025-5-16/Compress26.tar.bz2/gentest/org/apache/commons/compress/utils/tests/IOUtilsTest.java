package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
 
public class IOUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                                                                             public void testSkip_ZeroBytes() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                                 InputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(input, 0);
                                                                                                                                                                                                                                                                                                                                                                                                 assertEquals(0, skipped);
                                                                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                             public void testSkip_ExactBytesAvailable() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                                 byte[] data = new byte[100];
                                                                                                                                                                                                                                                                                                                                                                                                 InputStream input = new ByteArrayInputStream(data);
                                                                                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(input, 100);
                                                                                                                                                                                                                                                                                                                                                                                                 assertEquals(100, skipped);
                                                                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                             public void testSkip_LessBytesAvailable() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                                 byte[] data = new byte[50];
                                                                                                                                                                                                                                                                                                                                                                                                 InputStream input = new ByteArrayInputStream(data);
                                                                                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(input, 100);
                                                                                                                                                                                                                                                                                                                                                                                                 assertEquals(50, skipped);
                                                                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                             public void testSkip_EmptyStream() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                                 InputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(input, 100);
                                                                                                                                                                                                                                                                                                                                                                                                 assertEquals(0, skipped);
                                                                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testSkip_WithPartialSkips() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                         // Define our own buffer size since we can't access the private SKIP_BUF_SIZE
                                                                                                                                                                                                                                                                                                                                                                                         final int SKIP_BUF_SIZE = 8192;
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(input.skip(anyLong()))
                                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(10L)  // first skip returns 10
                                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(0L);  // subsequent skips return 0
                                                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                                                         // Mock readFully behavior (since skip will fall back to reading)
                                                                                                                                                                                                                                                                                                                                                                                         byte[] buf = new byte[SKIP_BUF_SIZE];
                                                                                                                                                                                                                                                                                                                                                                                         when(input.read(eq(buf), eq(0), anyInt()))
                                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(20)  // first read returns 20
                                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(30)  // second read returns 30
                                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(-1);  // EOF
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         long skipped = IOUtils.skip(input, 100);
                                                                                                                                                                                                                                                                                                                                                                                         assertEquals(60, skipped); // 10 (skip) + 20 + 30
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testSkip_StreamThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(input.skip(anyLong())).thenThrow(new IOException("Test exception"));
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                                                                                                                                                                                                                                                                         exceptionRule.expect(IOException.class);
                                                                                                                                                                                                                                                                                                                                                                                         exceptionRule.expectMessage("Test exception");
                                                                                                                                                                                                                                                                                                                                                                                         IOUtils.skip(input, 100);
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testSkip_LargeAmountOfBytes() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                         // Define our own large buffer size for testing (2*8192 + 100 is common)
                                                                                                                                                                                                                                                                                                                                                                                         final int largeBufferSize = 8192 * 2 + 100;
                                                                                                                                                                                                                                                                                                                                                                                         byte[] data = new byte[largeBufferSize];
                                                                                                                                                                                                                                                                                                                                                                                         InputStream input = new ByteArrayInputStream(data);
                                                                                                                                                                                                                                                                                                                                                                                         long skipped = IOUtils.skip(input, largeBufferSize);
                                                                                                                                                                                                                                                                                                                                                                                         assertEquals(largeBufferSize, skipped);
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                             public void testSkipExactlyZeroBytes() throws IOException {
                                                                                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                                                                                 InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                 when(input.skip(0)).thenReturn(0L);
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Test skipping exactly 0 bytes
                                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(input, 0);
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                                                                                 assertEquals(0, skipped);
                                                                                                                                                                                                                                                                                                                                                 verify(input, never()).skip(anyLong());  // Shouldn't call skip when numToSkip is 0
                                                                                                                                                                                                                                                                                                                                                 verify(input, never()).read(any(byte[].class), anyInt(), anyInt());  // Shouldn't read either
                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                             public void testSkipWithPartialReads() throws IOException {
                                                                                                                                                                                                                                                                                                                                                 // Setup - stream that returns partial reads
                                                                                                                                                                                                                                                                                                                                                 InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                 when(input.skip(10)).thenReturn(5L);  // first skip only does 5
                                                                                                                                                                                                                                                                                                                                                 when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                                                                                     .thenReturn(3)  // first read returns 3
                                                                                                                                                                                                                                                                                                                                                     .thenReturn(2)   // second read returns 2
                                                                                                                                                                                                                                                                                                                                                     .thenReturn(0);  // then EOF
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Test skipping with partial reads
                                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                                                                                 assertEquals(10, skipped);  // 5 (skip) + 3 + 2 = 10
                                                                                                                                                                                                                                                                                                                                                 verify(input, times(1)).skip(10);
                                                                                                                                                                                                                                                                                                                                                 verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testSkipBoundaryCondition() throws IOException {
                                                                                                                                                                                                                                                                                                                                    // Setup - stream that returns exactly the requested bytes
                                                                                                                                                                                                                                                                                                                                    InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                    when(input.skip(10)).thenReturn(10L);
                                                                                                                                                                                                                                                                                                                                    when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                                                                        .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                                                                                                            public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                                                                                                                                                                                                                byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                                                                                                                                int off = (Integer) invocation.getArguments()[1];
                                                                                                                                                                                                                                                                                                                                                int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                                                                                                                                                                                return len;
                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                        });
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Test skipping where the exact amount is skipped
                                                                                                                                                                                                                                                                                                                                    long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                                                                                                    assertEquals(10, skipped);
                                                                                                                                                                                                                                                                                                                                    verify(input, times(1)).skip(10);
                                                                                                                                                                                                                                                                                                                                    verify(input, never()).read(any(byte[].class), anyInt(), anyInt());  // Shouldn't need to read
                                                                                                                                                                                                                                                                                                                                }

    @Test(timeout = 1000) // Add timeout to detect infinite loops
                                                                                                                                                                                                                                                                                                                            public void testSkip_DetectsInfiniteLoopMutant() throws IOException {
                                                                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                                                                InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                long requestedSkip = 100L;
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Mock behavior:
                                                                                                                                                                                                                                                                                                                                // First skip returns 50, then 0 (indicating no more can be skipped)
                                                                                                                                                                                                                                                                                                                                when(input.skip(requestedSkip)).thenReturn(50L, 0L);
                                                                                                                                                                                                                                                                                                                                // When falling back to readFully, return -1 (EOF)
                                                                                                                                                                                                                                                                                                                                when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                                                                                                long actualSkipped = IOUtils.skip(input, requestedSkip);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                                                                                                // Original would return 50 (only what was actually skipped)
                                                                                                                                                                                                                                                                                                                                // Mutant would hang in infinite loop (caught by timeout)
                                                                                                                                                                                                                                                                                                                                assertEquals(50L, actualSkipped);
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Verify interactions
                                                                                                                                                                                                                                                                                                                                verify(input, times(2)).skip(requestedSkip);
                                                                                                                                                                                                                                                                                                                                verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                                           public void testSkipExactAmount() throws IOException {
                                                                                                                                                                                                                                                                                                                               // Setup mock InputStream that returns exactly what was requested
                                                                                                                                                                                                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                               // Test case where we want to skip 10 bytes
                                                                                                                                                                                                                                                                                                                               long numToSkip = 10;
                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                               // Original behavior would call skip(10), mutant calls skip(11)
                                                                                                                                                                                                                                                                                                                               // Make mock return exactly 10 when skip(10) is called (original behavior)
                                                                                                                                                                                                                                                                                                                               when(input.skip(10)).thenReturn(10L);
                                                                                                                                                                                                                                                                                                                               // Make mock return something different when skip(11) is called (mutant behavior)
                                                                                                                                                                                                                                                                                                                               when(input.skip(11)).thenReturn(11L);
                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                               // Also mock readFully since it's called in the fallback path
                                                                                                                                                                                                                                                                                                                               // We shouldn't reach this in this test case
                                                                                                                                                                                                                                                                                                                               when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                               // Call the method
                                                                                                                                                                                                                                                                                                                               long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                               // Verify the exact amount was skipped
                                                                                                                                                                                                                                                                                                                               assertEquals(10L, skipped);
                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                               // Verify the mock interactions
                                                                                                                                                                                                                                                                                                                               verify(input).skip(10);  // This will fail if mutant is present (would expect skip(11))
                                                                                                                                                                                                                                                                                                                               verify(input, never()).skip(11);  // This will fail if mutant is present
                                                                                                                                                                                                                                                                                                                               verify(input, never()).read(any(byte[].class), anyInt(), anyInt());  // Shouldn't reach fallback
                                                                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                                                                          public void testSkip_ShouldCallInputSkipMethod() throws IOException {
                                                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                              long numToSkip = 1024;
                                                                                                                                                                                                                                                                                                                              long expectedSkip = 512;
                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                              // Setup mock behavior
                                                                                                                                                                                                                                                                                                                              when(mockInput.skip(numToSkip)).thenReturn(expectedSkip);
                                                                                                                                                                                                                                                                                                                              when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                                                              long result = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                                                              // Verify skip() was called on the input stream
                                                                                                                                                                                                                                                                                                                              verify(mockInput).skip(numToSkip);
                                                                                                                                                                                                                                                                                                                              // Verify the result accounts for the skipped bytes
                                                                                                                                                                                                                                                                                                                              assertEquals(expectedSkip, result);
                                                                                                                                                                                                                                                                                                                              // Verify no read operations were needed since skip() succeeded
                                                                                                                                                                                                                                                                                                                              verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testSkipWithNegativeSkippedValue() throws Exception {
                                                                                                                                                                                                                                                                                                                                 // Create a mock InputStream that returns -1 on skip
                                                                                                                                                                                                                                                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                 when(mockInput.skip(anyLong())).thenReturn(-1L);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // The original code would continue to the readFully path when skip returns -1
                                                                                                                                                                                                                                                                                                                                 // The mutated code would break the loop immediately when skip returns -1 (due to <= 0 condition)
                                                                                                                                                                                                                                                                                                                                 long numToSkip = 100;
                                                                                                                                                                                                                                                                                                                                 long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Verify the behavior difference:
                                                                                                                                                                                                                                                                                                                                 // Original: should continue to readFully path and return 100 (if readFully works)
                                                                                                                                                                                                                                                                                                                                 // Mutant: would return 0 since it breaks immediately
                                                                                                                                                                                                                                                                                                                                 // We can't know readFully's behavior, but we can verify the skip was called
                                                                                                                                                                                                                                                                                                                                 verify(mockInput).skip(numToSkip);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // For this test, we just want to ensure the skip path is tested with negative return
                                                                                                                                                                                                                                                                                                                                 // The assertion here depends on the expected behavior:
                                                                                                                                                                                                                                                                                                                                 // If we expect the method to handle negative skips by continuing to readFully:
                                                                                                                                                                                                                                                                                                                                 assertTrue("Method should handle negative skip values by continuing", skipped > 0);
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Or if we want to specifically test the original vs mutant behavior:
                                                                                                                                                                                                                                                                                                                                 // Original would continue to readFully, so skipped should be > 0
                                                                                                                                                                                                                                                                                                                                 // Mutant would break immediately, so skipped would be 0
                                                                                                                                                                                                                                                                                                                                 // This assertion would fail for the mutant but pass for original
                                                                                                                                                                                                                                                                                                                                 assertNotEquals("Should not return 0 when skip returns negative", 0, skipped);
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testSkip_ZeroBytes_ShouldNotEnterBufferReadingLoop() throws IOException {
                                                                                                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                                                                                                            InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                            long numToSkip = 0L;
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Mock behavior - skip() should return 0 when numToSkip is 0
                                                                                                                                                                                                                                                                                                                            when(mockInput.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                                                                                                                            long result = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                                                                                                                            assertEquals(0L, result);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Verify we never entered the buffer-reading path
                                                                                                                                                                                                                                                                                                                            verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Also verify we only called skip() once (original behavior)
                                                                                                                                                                                                                                                                                                                            verify(mockInput, times(1)).skip(anyLong());
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                       public void testSkip_ZeroBytesShouldNotCallReadFully() throws Exception {
                                                                                                                                                                                                                                                                                                                           // Arrange
                                                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                           long numToSkip = 0L;
                                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                                           // Mock behavior - skip() should return 0 since we're skipping 0 bytes
                                                                                                                                                                                                                                                                                                                           when(input.skip(numToSkip)).thenReturn(0L);
                                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                                           // Act
                                                                                                                                                                                                                                                                                                                           long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                                           // Assert
                                                                                                                                                                                                                                                                                                                           assertEquals(0L, result);
                                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                                           // Verify readFully() is never called (would only happen in mutated version)
                                                                                                                                                                                                                                                                                                                           verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                                           // Also verify skip was called exactly once with 0
                                                                                                                                                                                                                                                                                                                           verify(input, times(1)).skip(0L);
                                                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                                                     public void testSkipExactlyAllBytes() throws IOException {
                                                                                                                                                                                                                                                                                                                         // Setup mock input stream that will skip exactly the requested amount
                                                                                                                                                                                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                         long numToSkip = 10;
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         // First skip will skip all requested bytes
                                                                                                                                                                                                                                                                                                                         when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         // Method should not enter the second while loop (with readFully)
                                                                                                                                                                                                                                                                                                                         // since all bytes were skipped in first attempt
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         // Verify correct number of bytes skipped
                                                                                                                                                                                                                                                                                                                         assertEquals(numToSkip, skipped);
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         // Verify stream.skip() was called exactly once with correct parameter
                                                                                                                                                                                                                                                                                                                         verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         // Verify readFully was never called (since all bytes were skipped)
                                                                                                                                                                                                                                                                                                                         // Note: This requires access to the static readFully method, 
                                                                                                                                                                                                                                                                                                                         // in real test might need PowerMock or other techniques to verify
                                                                                                                                                                                                                                                                                                                         // Alternatively could mock a stream that would require readFully
                                                                                                                                                                                                                                                                                                                         // if the mutation caused extra reads
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         // Additional test case to catch the mutant:
                                                                                                                                                                                                                                                                                                                         // When numToSkip becomes 0, the mutated version would try one more read
                                                                                                                                                                                                                                                                                                                         // So we test with a stream that would return data if incorrectly queried
                                                                                                                                                                                                                                                                                                                         InputStream input2 = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                         when(input2.skip(numToSkip)).thenReturn(numToSkip - 1).thenReturn(1L);
                                                                                                                                                                                                                                                                                                                         // Define our own buffer size for testing purposes
                                                                                                                                                                                                                                                                                                                         final int testBufferSize = 8192; // typical buffer size
                                                                                                                                                                                                                                                                                                                         byte[] buf = new byte[testBufferSize];
                                                                                                                                                                                                                                                                                                                         when(input2.read(buf, 0, 1)).thenReturn(-1); // Should never be called in original
                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                         long skipped2 = IOUtils.skip(input2, numToSkip);
                                                                                                                                                                                                                                                                                                                         assertEquals(numToSkip, skipped2);
                                                                                                                                                                                                                                                                                                                         // If mutant exists, it would call read when numToSkip=0
                                                                                                                                                                                                                                                                                                                         verify(input2, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                        public void testSkip_DetectsInfiniteLoopMutant1() throws IOException {
                                                                                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                                                                                            InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                            long numToSkip = 1024;
                                                                                                                                                                                                                                                                                                            int skipBufSize = 512;
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Mock behavior:
                                                                                                                                                                                                                                                                                                            // First skip returns partial amount
                                                                                                                                                                                                                                                                                                            when(input.skip(numToSkip)).thenReturn(512L);
                                                                                                                                                                                                                                                                                                            // Subsequent reads return chunks until done
                                                                                                                                                                                                                                                                                                            when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                                                .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                                                                    public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                                                                                                                                                                                        int len = (Integer)invocation.getArguments()[2];
                                                                                                                                                                                                                                                                                                                        return len; // return full requested length
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                });
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                                                                                                            long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                                                                                                            assertEquals("Should have skipped exactly requested amount", 
                                                                                                                                                                                                                                                                                                                        numToSkip, skipped);
                                                                                                                                                                                                                                                                                                            verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                                                                                                                                            verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                               public void testSkipWithFallbackToReadFully_DetectsOffsetMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                                                                   // Arrange
                                                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                   when(input.skip(anyLong())).thenReturn(0L); // Force fallback to readFully path
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // Use reflection to get the private SKIP_BUF_SIZE
                                                                                                                                                                                                                                                                                                   Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                                                                                                                                                                                   field.setAccessible(true);
                                                                                                                                                                                                                                                                                                   int skipBufSize = field.getInt(null);
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // We'll use a small buffer to test the mutation
                                                                                                                                                                                                                                                                                                   int testSkipSize = skipBufSize + 1;
                                                                                                                                                                                                                                                                                                   byte[] expectedBuffer = new byte[skipBufSize];
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // Mock readFully to return full buffer except last byte
                                                                                                                                                                                                                                                                                                   doAnswer(invocation -> {
                                                                                                                                                                                                                                                                                                       byte[] buf = (byte[]) invocation.getArguments()[1];
                                                                                                                                                                                                                                                                                                       int off = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                                                                                                                                       int len = (Integer) invocation.getArguments()[3];
                                                                                                                                                                                                                                                                                                       if (len == skipBufSize) {
                                                                                                                                                                                                                                                                                                           System.arraycopy(new byte[skipBufSize], 0, buf, off, skipBufSize);
                                                                                                                                                                                                                                                                                                           return skipBufSize;
                                                                                                                                                                                                                                                                                                       } else {
                                                                                                                                                                                                                                                                                                           buf[off] = 0; // Write one byte
                                                                                                                                                                                                                                                                                                           return 1;
                                                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                                                   }).when(input).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // Act
                                                                                                                                                                                                                                                                                                   long skipped = IOUtils.skip(input, testSkipSize);
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // Assert
                                                                                                                                                                                                                                                                                                   // Verify we got exactly the requested amount
                                                                                                                                                                                                                                                                                                   assertEquals(testSkipSize, skipped);
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // Verify read was called with correct offset (0)
                                                                                                                                                                                                                                                                                                   verify(input, times(2)).read(any(byte[].class), eq(0), anyInt());
                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                   // The mutant would fail these assertions because:
                                                                                                                                                                                                                                                                                                   // 1. It would skip one less byte (testSkipSize-1)
                                                                                                                                                                                                                                                                                                   // 2. It would call read() with offset 1 instead of 0
                                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                                  public void testSkipWithNumToSkipLargerThanBufferSize() throws IOException {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      final int SKIP_BUF_SIZE = 8192; // Assuming this is the value from class
                                                                                                                                                                                                                                                                                      final long largeSkip = SKIP_BUF_SIZE + 100; // Larger than buffer size
                                                                                                                                                                                                                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Mock behavior
                                                                                                                                                                                                                                                                                      when(mockInput.skip(largeSkip)).thenReturn(0L); // Force fallback to buffer read
                                                                                                                                                                                                                                                                                      when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                          .thenAnswer(invocation -> {
                                                                                                                                                                                                                                                                                              Object[] args = invocation.getArguments();
                                                                                                                                                                                                                                                                                              byte[] buf = (byte[]) args[0];
                                                                                                                                                                                                                                                                                              int off = (Integer) args[1];
                                                                                                                                                                                                                                                                                              int len = (Integer) args[2];
                                                                                                                                                                                                                                                                                              return len; // Always read full requested length
                                                                                                                                                                                                                                                                                          });
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                                      long skipped = IOUtils.skip(mockInput, largeSkip);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      assertEquals(largeSkip, skipped);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify buffer size used in read calls
                                                                                                                                                                                                                                                                                      verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Additional verification to check buffer size constraints
                                                                                                                                                                                                                                                                                      verify(mockInput, atLeastOnce()).read(
                                                                                                                                                                                                                                                                                          any(byte[].class),
                                                                                                                                                                                                                                                                                          anyInt(),
                                                                                                                                                                                                                                                                                          eq(SKIP_BUF_SIZE)
                                                                                                                                                                                                                                                                                      );
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                         public void testSkipWithLargeNumToSkip() throws IOException {
                                                                                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                                                                                             final int SKIP_BUF_SIZE = 8192; // Define our own constant since IOUtils.SKIP_BUF_SIZE is private
                                                                                                                                                                                                                                                                             InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                             long largeSkip = SKIP_BUF_SIZE + 1; // Make sure it's larger than buffer
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Mock behavior:
                                                                                                                                                                                                                                                                             // First skip returns partial skip (less than requested)
                                                                                                                                                                                                                                                                             when(input.skip(anyLong())).thenReturn(SKIP_BUF_SIZE - 1L);
                                                                                                                                                                                                                                                                             // Then mock readFully behavior - this is where mutant would fail
                                                                                                                                                                                                                                                                             // We need to verify it calls readFully with proper buffer size
                                                                                                                                                                                                                                                                             // Mock to return 1 byte each time to test the loop
                                                                                                                                                                                                                                                                             doAnswer(invocation -> {
                                                                                                                                                                                                                                                                                 byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                                                                 int len = (int) invocation.getArguments()[2];
                                                                                                                                                                                                                                                                                 // Original would pass len <= SKIP_BUF_SIZE, mutant might pass larger
                                                                                                                                                                                                                                                                                 assertTrue("Should not try to read more than buffer size", 
                                                                                                                                                                                                                                                                                          len <= SKIP_BUF_SIZE);
                                                                                                                                                                                                                                                                                 return 1; // return 1 byte each time
                                                                                                                                                                                                                                                                             }).when(input).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Act
                                                                                                                                                                                                                                                                             long skipped = IOUtils.skip(input, largeSkip);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Assert
                                                                                                                                                                                                                                                                             // Should have skipped at least the initial partial skip
                                                                                                                                                                                                                                                                             assertTrue(skipped >= SKIP_BUF_SIZE - 1);
                                                                                                                                                                                                                                                                             // Verify interaction - should have tried to skip first
                                                                                                                                                                                                                                                                             verify(input).skip(largeSkip);
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                     public void testSkipWithZeroAndNegativeReads() throws Exception {
                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                         long numToSkip = 1024;
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // First make skip() not able to skip all bytes
                                                                                                                                                                                                                                                                         when(input.skip(numToSkip)).thenReturn(512L);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Then make readFully return 0 first (should break in original)
                                                                                                                                                                                                                                                                         // Then return -1 (should be treated differently by original vs mutant)
                                                                                                                                                                                                                                                                         when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                             .thenReturn(0)  // First read returns 0
                                                                                                                                                                                                                                                                             .thenReturn(-1); // Second read returns -1
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Test
                                                                                                                                                                                                                                                                         long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                                                         // Original would continue after read=0 and process read=-1 as another read
                                                                                                                                                                                                                                                                         // Mutant would break at read=0 and not process read=-1
                                                                                                                                                                                                                                                                         // So we verify it only processed one read operation after skip
                                                                                                                                                                                                                                                                         verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                         assertEquals(512L, skipped); // Only the initial skip should count
                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                   public void testSkipWithPartialReadsDetectsSubtractionMutant() throws IOException {
                                                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                       long numToSkip = 1024; // Request to skip 1KB
                                                                                                                                                                                                                                                       int bufSize = 256; // Buffer size (smaller than total to skip)
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock behavior:
                                                                                                                                                                                                                                                       // First skip returns partial skip
                                                                                                                                                                                                                                                       when(input.skip(numToSkip)).thenReturn(512L);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Then mock partial reads when buffer is used
                                                                                                                                                                                                                                                       // First read returns 256 bytes, second read returns 256 bytes
                                                                                                                                                                                                                                                       // (total 1024 skipped: 512 from skip + 256 + 256)
                                                                                                                                                                                                                                                       when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                           .thenAnswer(invocation -> {
                                                                                                                                                                                                                                                               return (Integer)invocation.getArguments()[2]; // return full read
                                                                                                                                                                                                                                                           })
                                                                                                                                                                                                                                                           .thenAnswer(invocation -> {
                                                                                                                                                                                                                                                               return (Integer)invocation.getArguments()[2]; // return full read
                                                                                                                                                                                                                                                           })
                                                                                                                                                                                                                                                           .thenReturn(-1); // EOF
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                                                       long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                                                       assertEquals("Should have skipped all requested bytes", numToSkip, skipped);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify interaction
                                                                                                                                                                                                                                                       verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                                                                                       verify(input, times(2)).read(any(byte[].class), eq(0), anyInt());
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                      public void testSkipWithMultipleReadsDetectsMutant() throws Exception {
                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                          // First skip() call will skip 5 bytes
                                                                                                                                                                                                                          when(mockInput.skip(anyLong())).thenReturn(5L);
                                                                                                                                                                                                                          // Subsequent reads will return 100 bytes each time until done
                                                                                                                                                                                                                          when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                              .thenAnswer(invocation -> {
                                                                                                                                                                                                                                  Object[] args = invocation.getArguments();
                                                                                                                                                                                                                                  return (Integer) args[2]; // return the requested length (3rd argument)
                                                                                                                                                                                                                              });
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          long numToSkip = 205; // Need multiple reads to skip all
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Act
                                                                                                                                                                                                                          long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Assert
                                                                                                                                                                                                                          // Original code should skip all 205 bytes
                                                                                                                                                                                                                          // Mutant would return less (probably 105) due to incorrect subtraction
                                                                                                                                                                                                                          assertEquals("Should skip all requested bytes", numToSkip, skipped);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify interaction
                                                                                                                                                                                                                          verify(mockInput, times(1)).skip(205L);
                                                                                                                                                                                                                          // Should do 2 reads: first for 200 (205-5), second for 5
                                                                                                                                                                                                                          verify(mockInput, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                  public void testSkipDetectsMutantWhenExactlyEnoughBytesAvailable() throws Exception {
                                                                                                                                                                                                                      // Arrange
                                                                                                                                                                                                                      InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                      long bytesToSkip = 1;
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Mock the input stream to report exactly the number of bytes skipped
                                                                                                                                                                                                                      when(input.skip(bytesToSkip)).thenReturn(bytesToSkip);
                                                                                                                                                                                                                      when(input.skip(bytesToSkip - 1)).thenReturn(bytesToSkip - 1);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Act - test the original behavior
                                                                                                                                                                                                                      long skipped = IOUtils.skip(input, bytesToSkip);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Assert - should skip exactly the requested amount
                                                                                                                                                                                                                      assertEquals("Should have skipped exactly the requested bytes", 
                                                                                                                                                                                                                                  bytesToSkip, skipped);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // The mutant version would return bytesToSkip-1 here
                                                                                                                                                                                                                      // because it calls input.skip(bytesToSkip-1) instead
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                 public void testSkipDetectsMutantWhenExactlyBufferSizeBytesAvailable() throws Exception {
                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                     InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                     // Define our own buffer size matching the expected IOUtils implementation
                                                                                                                                                                                                                     final long bytesToSkip = 8192; // Common buffer size
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock the input stream behavior
                                                                                                                                                                                                                     when(input.skip(bytesToSkip)).thenReturn(bytesToSkip);
                                                                                                                                                                                                                     when(input.skip(bytesToSkip - 1)).thenReturn(bytesToSkip - 1);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock the readFully behavior (though it shouldn't be called in this case)
                                                                                                                                                                                                                     when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                     long skipped = IOUtils.skip(input, bytesToSkip);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                     assertEquals("Should have skipped exactly SKIP_BUF_SIZE bytes", 
                                                                                                                                                                                                                                 bytesToSkip, skipped);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // The mutant would return bytesToSkip-1 here
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                            public void testSkipWithMultiByteReadsDetectsMutant() throws IOException {
                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                InputStream input = mock(InputStream.class);
                                                                                                                                                                                                when(input.skip(anyLong())).thenReturn(0L); // Force fallback to readFully
                                                                                                                                                                                                
                                                                                                                                                                                                // Mock read behavior to simulate partial reads
                                                                                                                                                                                                when(input.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                                                                                                                                    byte[] b = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                    int off = (int) invocation.getArguments()[1];
                                                                                                                                                                                                    int len = (int) invocation.getArguments()[2];
                                                                                                                                                                                                    return len >= 2 ? 2 : len;
                                                                                                                                                                                                });
                                                                                                                                                                                            
                                                                                                                                                                                                long numToSkip = 4; // Need to skip 4 bytes
                                                                                                                                                                                                long expectedSkipped = 4; // Should skip all 4 bytes
                                                                                                                                                                                                
                                                                                                                                                                                                // Act
                                                                                                                                                                                                long actualSkipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                
                                                                                                                                                                                                // Assert
                                                                                                                                                                                                assertEquals("Should have skipped all bytes", expectedSkipped, actualSkipped);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify read was called the correct number of times (2 times for original, more for mutant)
                                                                                                                                                                                                verify(input, times(2)).read(any(byte[].class), eq(0), anyInt());
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                       public void testSkipExactBoundaryCondition() throws IOException {
                                                                                                                                                                                           // Create a mock InputStream that will:
                                                                                                                                                                                           // 1. On first skip(), skip all requested bytes (10)
                                                                                                                                                                                           // 2. Subsequent operations should not be called in original version
                                                                                                                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                           when(mockInput.skip(anyLong())).thenAnswer(invocation -> {
                                                                                                                                                                                               Long requested = (Long)invocation.getArguments()[0];
                                                                                                                                                                                               return requested; // Skip all requested bytes
                                                                                                                                                                                           });
                                                                                                                                                                                           
                                                                                                                                                                                           // This test case is specifically designed to catch the >=0 vs >0 mutation
                                                                                                                                                                                           // We're skipping exactly 10 bytes which should be handled by the skip() call alone
                                                                                                                                                                                           long numToSkip = 10L;
                                                                                                                                                                                           long result = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify correct number of bytes skipped
                                                                                                                                                                                           assertEquals(10L, result);
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify the skip() was called exactly once with the right parameter
                                                                                                                                                                                           verify(mockInput, times(1)).skip(10L);
                                                                                                                                                                                           
                                                                                                                                                                                           // Critical assertion: verify readFully was NEVER called
                                                                                                                                                                                           // The mutant version would call readFully when numToSkip reaches 0
                                                                                                                                                                                           verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                           
                                                                                                                                                                                           // Alternative verification that would catch the mutant:
                                                                                                                                                                                           // The mutant would call skip() twice (once with 10, once with 0)
                                                                                                                                                                                           verify(mockInput, times(1)).skip(anyLong());
                                                                                                                                                                                       }

    @Test(timeout = 1000) // timeout prevents infinite loop from hanging tests
                                                                                                                                                                                   public void testSkipExactBytesShouldReturnImmediately() throws Exception {
                                                                                                                                                                                       // Arrange
                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                       long numToSkip = 10;
                                                                                                                                                                                       
                                                                                                                                                                                       // First skip() call will skip all requested bytes
                                                                                                                                                                                       when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                                       
                                                                                                                                                                                       // Act
                                                                                                                                                                                       long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                       
                                                                                                                                                                                       // Assert
                                                                                                                                                                                       assertEquals("Should have skipped all requested bytes", numToSkip, skipped);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify no additional reads were attempted
                                                                                                                                                                                       verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                       verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                  public void testSkip_ShouldDetectMutatedSkipAmount() throws IOException {
                                                                                                                                                                                      // Arrange
                                                                                                                                                                                      InputStream input = mock(InputStream.class);
                                                                                                                                                                                      long numToSkip = 10;
                                                                                                                                                                                      
                                                                                                                                                                                      // Mock the input stream behavior:
                                                                                                                                                                                      // First skip attempt should return exactly numToSkip (10) bytes
                                                                                                                                                                                      when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                                      // Mutated version would call skip(11) and return something different
                                                                                                                                                                                      
                                                                                                                                                                                      // Act
                                                                                                                                                                                      long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                      
                                                                                                                                                                                      // Assert
                                                                                                                                                                                      // Verify the exact number of bytes was skipped
                                                                                                                                                                                      assertEquals("Should have skipped exactly the requested amount", 
                                                                                                                                                                                                  numToSkip, skipped);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify the skip was called with exactly numToSkip (not numToSkip+1)
                                                                                                                                                                                      verify(input).skip(numToSkip);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify no fallback reading was needed
                                                                                                                                                                                      verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                 public void testSkip_ShouldUseInputStreamSkipMethod() throws IOException {
                                                                                                                                                                                     // Arrange
                                                                                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                     when(mockInput.skip(anyLong())).thenReturn(10L); // First skip returns 10 bytes
                                                                                                                                                                                     when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1); // Read returns EOF
                                                                                                                                                                                     
                                                                                                                                                                                     long numToSkip = 100;
                                                                                                                                                                                     
                                                                                                                                                                                     // Act
                                                                                                                                                                                     long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                     
                                                                                                                                                                                     // Assert
                                                                                                                                                                                     // Verify skip() was called and its result was used
                                                                                                                                                                                     verify(mockInput, atLeastOnce()).skip(anyLong());
                                                                                                                                                                                     assertEquals(10, skipped); // Should have skipped 10 bytes via skip() call
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify readFully wasn't called (since skip() succeeded partially)
                                                                                                                                                                                     // Note: This depends on readFully being mocked or not
                                                                                                                                                                                     // If we want to be thorough, we could mock readFully behavior and verify it wasn't called
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                               public void testSkipWithNegativeSkippedValue1() throws IOException {
                                                                                                                                                                                   // Create a mock InputStream that returns -1 on skip()
                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                   when(input.skip(anyLong())).thenReturn(-1L);
                                                                                                                                                                                   
                                                                                                                                                                                   // The original code should continue to the buffer reading phase since -1 != 0
                                                                                                                                                                                   // The mutated code would stop immediately since -1 <= 0
                                                                                                                                                                                   long numToSkip = 100;
                                                                                                                                                                                   long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the mock was called (original behavior would call skip)
                                                                                                                                                                                   verify(input).skip(numToSkip);
                                                                                                                                                                                   
                                                                                                                                                                                   // Original behavior would then try to read into buffer
                                                                                                                                                                                   // Since we didn't mock readFully, it would throw NPE, but we can verify skip was called
                                                                                                                                                                                   // A better assertion would be to check the return value matches expected behavior
                                                                                                                                                                                   // For this test, we mainly want to verify the skip() behavior before buffer reading
                                                                                                                                                                                   
                                                                                                                                                                                   // Alternative complete test with mocked readFully:
                                                                                                                                                                                   // Use a reasonable buffer size (1024 is common for I/O operations)
                                                                                                                                                                                   when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                   
                                                                                                                                                                                   long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                   assertEquals(0, result); // Should skip 0 bytes in either case, but path differs
                                                                                                                                                                                   
                                                                                                                                                                                   // Key point: mutated version would not proceed to buffer reading phase
                                                                                                                                                                                   // So we can verify interaction with mock
                                                                                                                                                                                   verify(input).skip(numToSkip);
                                                                                                                                                                                   // Original would also call read(), mutated wouldn't
                                                                                                                                                                                   // So this test would fail on mutant (detect it) because:
                                                                                                                                                                                   // - Mutant would only call skip() once and exit
                                                                                                                                                                                   // - Original would call skip() then proceed to read()
                                                                                                                                                                               }

    @Test
                                                                                                                                                                           public void testSkipWithZeroBytesShouldNotRead() throws IOException {
                                                                                                                                                                               // Arrange
                                                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                                                               long numToSkip = 0L;
                                                                                                                                                                               
                                                                                                                                                                               // Act
                                                                                                                                                                               long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                                               
                                                                                                                                                                               // Assert
                                                                                                                                                                               assertEquals(0L, result);
                                                                                                                                                                               verify(input, never()).skip(anyLong());
                                                                                                                                                                               verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                               
                                                                                                                                                                               // Additional verification that no buffer was actually used
                                                                                                                                                                               // Since SKIP_BUF_SIZE is private, we'll verify no read operations occurred
                                                                                                                                                                               verifyNoMoreInteractions(input);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                          public void testSkipWithZeroBytesShouldNotCallReadFully() throws Exception {
                                                                                                                                                                              // Arrange
                                                                                                                                                                              InputStream input = mock(InputStream.class);
                                                                                                                                                                              when(input.skip(anyLong())).thenReturn(0L); // Simulate that skip couldn't skip any bytes
                                                                                                                                                                              
                                                                                                                                                                              // Act
                                                                                                                                                                              long result = IOUtils.skip(input, 0);
                                                                                                                                                                              
                                                                                                                                                                              // Assert
                                                                                                                                                                              assertEquals(0, result);
                                                                                                                                                                              verify(input, times(1)).skip(0); // Verify skip was called with 0
                                                                                                                                                                              verifyNoMoreInteractions(input); // Ensure readFully wasn't called
                                                                                                                                                                          }

    @Test
                                                                                                                                                                    public void testSkipWithExactBufferSize() throws IOException {
                                                                                                                                                                        // Setup
                                                                                                                                                                        final int SKIP_BUF_SIZE = 8192; // Assuming this is the value, adjust if different
                                                                                                                                                                        final long initialSkip = 100;
                                                                                                                                                                        final long remainingSkip = SKIP_BUF_SIZE;
                                                                                                                                                                        final long totalToSkip = initialSkip + remainingSkip;
                                                                                                                                                                        
                                                                                                                                                                        InputStream input = mock(InputStream.class);
                                                                                                                                                                        
                                                                                                                                                                        // First skip returns partial skip
                                                                                                                                                                        when(input.skip(totalToSkip)).thenReturn(initialSkip);
                                                                                                                                                                        
                                                                                                                                                                        // Mock readFully to return exactly the requested amount
                                                                                                                                                                        doAnswer(invocation -> {
                                                                                                                                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                            int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                            // Verify buffer size is exactly SKIP_BUF_SIZE
                                                                                                                                                                            assertEquals(SKIP_BUF_SIZE, buf.length);
                                                                                                                                                                            return len;
                                                                                                                                                                        }).when(input).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        long skipped = IOUtils.skip(input, totalToSkip);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals(totalToSkip, skipped);
                                                                                                                                                                        // Verify read was called exactly once with the remaining bytes
                                                                                                                                                                        verify(input, times(1)).read(any(byte[].class), eq(0), eq(SKIP_BUF_SIZE));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testSkipExactlyAllBytes1() throws IOException {
                                                                                                                                                                    // Create a mock InputStream that will skip exactly the requested amount
                                                                                                                                                                    InputStream input = mock(InputStream.class);
                                                                                                                                                                    long numToSkip = 10;
                                                                                                                                                                    
                                                                                                                                                                    // First skip will skip all requested bytes
                                                                                                                                                                    when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                    
                                                                                                                                                                    // Method should not enter the second while loop
                                                                                                                                                                    long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                                    
                                                                                                                                                                    // Verify correct number of bytes skipped
                                                                                                                                                                    assertEquals(numToSkip, result);
                                                                                                                                                                    
                                                                                                                                                                    // Verify skip was called exactly once (mutant would call it multiple times)
                                                                                                                                                                    verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                    
                                                                                                                                                                    // Verify no read operations were performed (mutant might enter read loop)
                                                                                                                                                                    verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testSkipWithZeroBytes() throws IOException {
                                                                                                                                                                    // Create a mock InputStream that can't skip any bytes
                                                                                                                                                                    InputStream input = mock(InputStream.class);
                                                                                                                                                                    long numToSkip = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Method should immediately return without any operations
                                                                                                                                                                    long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                                    
                                                                                                                                                                    // Verify correct number of bytes skipped
                                                                                                                                                                    assertEquals(0, result);
                                                                                                                                                                    
                                                                                                                                                                    // Verify no operations were performed (mutant might enter loops)
                                                                                                                                                                    verify(input, never()).skip(anyLong());
                                                                                                                                                                    verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                }

    @Test
                                                                                                                                                                   public void testSkipWithEmptyStreamShouldNotLoopInfinitely() throws Exception {
                                                                                                                                                                       // Arrange
                                                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                       when(mockInput.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                       when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                       
                                                                                                                                                                       // Act & Assert
                                                                                                                                                                       // If the mutant is present, this will timeout due to infinite loop
                                                                                                                                                                       long skipped = IOUtils.skip(mockInput, 100);
                                                                                                                                                                       
                                                                                                                                                                       // Original behavior should return 0 (no bytes skipped)
                                                                                                                                                                       assertEquals(0, skipped);
                                                                                                                                                                       
                                                                                                                                                                       // Verify interactions
                                                                                                                                                                       verify(mockInput).skip(100);
                                                                                                                                                                       verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                   }

    @Test
                                                                                                                                                         public void testSkipWithFullBufferRead() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                             // Setup
                                                                                                                                                             // Get private SKIP_BUF_SIZE using reflection
                                                                                                                                                             Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                                             field.setAccessible(true);
                                                                                                                                                             final int SKIP_BUF_SIZE = field.getInt(null);
                                                                                                                                                             final int SKIP_SIZE = SKIP_BUF_SIZE; // Exactly one buffer's worth
                                                                                                                                                             
                                                                                                                                                             InputStream input = mock(InputStream.class);
                                                                                                                                                             
                                                                                                                                                             // Mock behavior - first skip returns 0 to force buffer read path
                                                                                                                                                             when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                             
                                                                                                                                                             // Mock readFully to return full buffer size when offset is 0 (original)
                                                                                                                                                             // This would fail if offset is 1 (mutant)
                                                                                                                                                             when(input.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                                                                                                 Object[] args = invocation.getArguments();
                                                                                                                                                                 byte[] buf = (byte[]) args[0];
                                                                                                                                                                 int offset = (int) args[1];
                                                                                                                                                                 int len = (int) args[2];
                                                                                                                                                                 
                                                                                                                                                                 // Original expects offset 0, so len should equal SKIP_BUF_SIZE
                                                                                                                                                                 // Mutant uses offset 1, so len would be SKIP_BUF_SIZE-1
                                                                                                                                                                 assertEquals(0, offset); // This will fail for the mutant
                                                                                                                                                                 assertEquals(SKIP_BUF_SIZE, len); // This will fail for the mutant
                                                                                                                                                                 
                                                                                                                                                                 // Fill the buffer section with dummy data
                                                                                                                                                                 java.util.Arrays.fill(buf, offset, offset + len, (byte)1);
                                                                                                                                                                 return len;
                                                                                                                                                             });
                                                                                                                                                             
                                                                                                                                                             // Test
                                                                                                                                                             long skipped = IOUtils.skip(input, SKIP_SIZE);
                                                                                                                                                             
                                                                                                                                                             // Verify
                                                                                                                                                             assertEquals(SKIP_SIZE, skipped);
                                                                                                                                                             
                                                                                                                                                             // Verify readFully was called with correct parameters
                                                                                                                                                             verify(input).read(any(byte[].class), eq(0), eq(SKIP_BUF_SIZE));
                                                                                                                                                         }

    @Test
                                                                                                                                                     public void testSkipWithSmallNumToSkipDetectsMathMinMutant() throws IOException {
                                                                                                                                                         // Setup
                                                                                                                                                         final int SKIP_BUF_SIZE = 8192; // Assuming this is the value based on common implementations
                                                                                                                                                         final long smallNumToSkip = 100; // Less than SKIP_BUF_SIZE
                                                                                                                                                         
                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                         // First skip attempt returns 0 to force the fallback path
                                                                                                                                                         when(input.skip(smallNumToSkip)).thenReturn(0L);
                                                                                                                                                         // Mock readFully behavior - we expect it to be called with smallNumToSkip (100)
                                                                                                                                                         // but mutant would try to read SKIP_BUF_SIZE (8192)
                                                                                                                                                         when(input.read(any(byte[].class), anyInt(), eq(100))).thenReturn(100);
                                                                                                                                                         
                                                                                                                                                         // Test
                                                                                                                                                         long skipped = IOUtils.skip(input, smallNumToSkip);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         assertEquals("Should have skipped all requested bytes", smallNumToSkip, skipped);
                                                                                                                                                         // Verify the buffer size used was correct (should be smallNumToSkip)
                                                                                                                                                         verify(input).read(any(byte[].class), anyInt(), eq(100));
                                                                                                                                                         
                                                                                                                                                         // This test would fail with the mutant because:
                                                                                                                                                         // 1. Mutant would try to read 8192 bytes instead of 100
                                                                                                                                                         // 2. The verify assertion would fail because it expects read length of 100
                                                                                                                                                     }

    @Test
                                                                                                                                   public void testSkipWithLargeNumToSkipUsesBufferSizeLimit() throws IOException {
                                                                                                                                       // Arrange
                                                                                                                                       final int SKIP_BUF_SIZE = 8192; // Assuming this is the value from class
                                                                                                                                       final long largeSkip = SKIP_BUF_SIZE * 2L; // Twice the buffer size
                                                                                                                                       
                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                       // First skip returns partial skip
                                                                                                                                       when(mockInput.skip(largeSkip)).thenReturn((long)SKIP_BUF_SIZE);
                                                                                                                                       // Then mock partial reads
                                                                                                                                       when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                           .thenAnswer(invocation -> {
                                                                                                                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                               int off = (Integer) invocation.getArguments()[1];
                                                                                                                                               int len = (Integer) invocation.getArguments()[2];
                                                                                                                                               return len; // Return full read length
                                                                                                                                           });
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       long skipped = IOUtils.skip(mockInput, largeSkip);
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertEquals(largeSkip, skipped);
                                                                                                                                       
                                                                                                                                       // Verify the readFully calls used buffer size <= SKIP_BUF_SIZE
                                                                                                                                       org.mockito.ArgumentCaptor<byte[]> bufferCaptor = org.mockito.ArgumentCaptor.forClass(byte[].class);
                                                                                                                                       org.mockito.ArgumentCaptor<Integer> offsetCaptor = org.mockito.ArgumentCaptor.forClass(Integer.class);
                                                                                                                                       org.mockito.ArgumentCaptor<Integer> lenCaptor = org.mockito.ArgumentCaptor.forClass(Integer.class);
                                                                                                                                       
                                                                                                                                       verify(mockInput, atLeastOnce()).read(bufferCaptor.capture(), offsetCaptor.capture(), lenCaptor.capture());
                                                                                                                                       
                                                                                                                                       // Check all read lengths were <= SKIP_BUF_SIZE
                                                                                                                                       for (int len : lenCaptor.getAllValues()) {
                                                                                                                                           assertTrue("Read length should be <= SKIP_BUF_SIZE", 
                                                                                                                                                     len <= SKIP_BUF_SIZE);
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Also verify the buffer sizes were <= SKIP_BUF_SIZE
                                                                                                                                       for (byte[] buffer : bufferCaptor.getAllValues()) {
                                                                                                                                           assertTrue("Buffer size should be <= SKIP_BUF_SIZE", 
                                                                                                                                                     buffer.length <= SKIP_BUF_SIZE);
                                                                                                                                       }
                                                                                                                                   }

    @Test
                                                                                                                              public void testSkip_ShouldContinueWhenReadFullyReturnsZero() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  InputStream input = mock(InputStream.class);
                                                                                                                                  long numToSkip = 1024;
                                                                                                                                  // Use a reasonable buffer size that matches typical implementations (8192 is common)
                                                                                                                                  byte[] skipBuf = new byte[8192];
                                                                                                                                  
                                                                                                                                  // First skip returns partial skip
                                                                                                                                  when(input.skip(numToSkip)).thenReturn(512L);
                                                                                                                                  
                                                                                                                                  // First readFully returns 0 (but stream isn't ended)
                                                                                                                                  // Second readFully returns some data
                                                                                                                                  when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                      .thenReturn(0)
                                                                                                                                      .thenReturn(256);
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  // Should be 512 (initial skip) + 256 (from readFully) = 768
                                                                                                                                  assertEquals(768L, skipped);
                                                                                                                                  
                                                                                                                                  // Verify behavior - should call readFully twice (once returning 0, once returning 256)
                                                                                                                                  verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                              }

    @Test
                                                                                                                     public void testSkipWithPartialReadsDetectsSubtractionMutant1() throws IOException {
                                                                                                                         // Arrange
                                                                                                                         InputStream mockInput = mock(InputStream.class);
                                                                                                                         
                                                                                                                         // First skip() call returns partial skip
                                                                                                                         when(mockInput.skip(anyLong())).thenReturn(5L, 0L);
                                                                                                                         
                                                                                                                         // readFully() calls return partial reads
                                                                                                                         when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                             .thenAnswer(invocation -> {
                                                                                                                                 byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                 int off = (Integer) invocation.getArguments()[1];
                                                                                                                                 int len = (Integer) invocation.getArguments()[2];
                                                                                                                                 return len > 3 ? 3 : -1; // return 3 bytes until last call
                                                                                                                             });
                                                                                                                         
                                                                                                                         long numToSkip = 10L; // We want to skip 10 bytes
                                                                                                                         
                                                                                                                         // Act
                                                                                                                         long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                         
                                                                                                                         // Assert
                                                                                                                         // Original should return 10 (5 from skip + 3 + 2 from reads)
                                                                                                                         // Mutant would either:
                                                                                                                         // - Return wrong value (if it completes)
                                                                                                                         // - Run indefinitely (test would timeout)
                                                                                                                         assertEquals("Should have skipped all requested bytes", numToSkip, skipped);
                                                                                                                         
                                                                                                                         // Verify interaction
                                                                                                                         verify(mockInput, times(2)).skip(anyLong());
                                                                                                                         verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                     }

    @Test
                                                                                                                public void testSkipWithMultipleReadsDetectsSubtractionMutant() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                    // Arrange
                                                                                                                    InputStream input = mock(InputStream.class);
                                                                                                                    when(input.skip(anyLong())).thenReturn(0L); // Force fallback to readFully
                                                                                                                    
                                                                                                                    // Get SKIP_BUF_SIZE via reflection
                                                                                                                    Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                    field.setAccessible(true);
                                                                                                                    int skipBufSize = field.getInt(null);
                                                                                                                    
                                                                                                                    // Setup read to return partial reads (2 reads needed to cover buffer size)
                                                                                                                    int firstRead = skipBufSize / 2;
                                                                                                                    int secondRead = skipBufSize / 2;
                                                                                                                    when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                        .thenReturn(firstRead)
                                                                                                                        .thenReturn(secondRead);
                                                                                                                    
                                                                                                                    long requestedSkip = skipBufSize; // Request to skip full buffer size
                                                                                                                    
                                                                                                                    // Act
                                                                                                                    long actualSkipped = IOUtils.skip(input, requestedSkip);
                                                                                                                    
                                                                                                                    // Assert
                                                                                                                    // Original would return requestedSkip since we read all requested bytes
                                                                                                                    // Mutant would return secondRead (4096) due to incorrect subtraction
                                                                                                                    assertEquals("Should return full requested skip amount", 
                                                                                                                                requestedSkip, actualSkipped);
                                                                                                                    
                                                                                                                    // Verify read was called twice (once for each partial read)
                                                                                                                    verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                }

    @Test
                                                                                                            public void testSkipShouldNotFallBackToBufferWhenSkipSucceeds() throws IOException {
                                                                                                                // Arrange
                                                                                                                InputStream input = mock(InputStream.class);
                                                                                                                long numToSkip = 10;
                                                                                                                
                                                                                                                // Mock behavior: skip succeeds completely on first try
                                                                                                                when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                
                                                                                                                // Act
                                                                                                                long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                
                                                                                                                // Assert
                                                                                                                assertEquals("Should have skipped all bytes", numToSkip, skipped);
                                                                                                                verify(input, times(1)).skip(numToSkip);
                                                                                                                verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                
                                                                                                                // The mutant would fail this test because:
                                                                                                                // 1. It would call skip(9) instead of skip(10)
                                                                                                                // 2. It would then fall back to buffer reading
                                                                                                                // 3. The verify(input, never()).read() assertion would fail
                                                                                                            }

    @Test
                                                                                                            public void testSkipShouldRequestExactNumberOfBytes() throws IOException {
                                                                                                                // Arrange
                                                                                                                InputStream input = mock(InputStream.class);
                                                                                                                long numToSkip = 5;
                                                                                                                
                                                                                                                // Mock behavior: skip succeeds completely on first try
                                                                                                                when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                
                                                                                                                // Act
                                                                                                                IOUtils.skip(input, numToSkip);
                                                                                                                
                                                                                                                // Assert
                                                                                                                verify(input).skip(numToSkip); // Would fail with mutant which calls skip(4)
                                                                                                                
                                                                                                                // This directly verifies the exact skip amount was requested
                                                                                                                // The mutant would fail this verification
                                                                                                            }

    @Test
                                                                                                          public void testSkipWithMultipleReadsDetectsMutant1() throws IOException {
                                                                                                              // Arrange
                                                                                                              InputStream input = mock(InputStream.class);
                                                                                                              // Use a reasonable buffer size since we can't access the private one
                                                                                                              int bufferSize = 8192; 
                                                                                                              byte[] skipBuf = new byte[bufferSize];
                                                                                                              
                                                                                                              // First skip will return 0 to force the fallback path
                                                                                                              when(input.skip(anyLong())).thenReturn(0L);
                                                                                                              
                                                                                                              // Set up read to return 10 bytes each time (more than 1)
                                                                                                              when(input.read(skipBuf, 0, Math.min(20, bufferSize)))
                                                                                                                  .thenReturn(10)
                                                                                                                  .thenReturn(10)
                                                                                                                  .thenReturn(-1); // End of stream
                                                                                                              
                                                                                                              // We want to skip 20 bytes total
                                                                                                              long numToSkip = 20;
                                                                                                              
                                                                                                              // Act
                                                                                                              long skipped = IOUtils.skip(input, numToSkip);
                                                                                                              
                                                                                                              // Assert
                                                                                                              // Original code would call read twice (20/10)
                                                                                                              // Mutant would call read 20 times (decrementing by 1 each time)
                                                                                                              verify(input, times(2)).read(skipBuf, 0, Math.min(20, bufferSize));
                                                                                                              assertEquals(20, skipped);
                                                                                                          }

    @Test
                                                                                                      public void testSkipWithZeroBytesShouldNotAttemptToSkipOrRead() throws IOException {
                                                                                                          // Arrange
                                                                                                          InputStream input = mock(InputStream.class);
                                                                                                          long numToSkip = 0L;
                                                                                                          
                                                                                                          // Act
                                                                                                          long skipped = IOUtils.skip(input, numToSkip);
                                                                                                          
                                                                                                          // Assert
                                                                                                          assertEquals("Should return 0 when skipping 0 bytes", 0L, skipped);
                                                                                                          verify(input, never()).skip(anyLong());
                                                                                                          verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                      }

    @Test
                                                                                                      public void testSkipShouldNotReadWhenExactlyAllBytesSkipped() throws IOException {
                                                                                                          // Arrange
                                                                                                          InputStream input = mock(InputStream.class);
                                                                                                          long numToSkip = 100L;
                                                                                                          when(input.skip(numToSkip)).thenReturn(100L);
                                                                                                          
                                                                                                          // Act
                                                                                                          long skipped = IOUtils.skip(input, numToSkip);
                                                                                                          
                                                                                                          // Assert
                                                                                                          assertEquals("Should return all skipped bytes", 100L, skipped);
                                                                                                          verify(input, times(1)).skip(numToSkip);
                                                                                                          verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                      }

    @Test
                                                                                                      public void testSkipShouldNotReadWhenSkipReturnsZero() throws IOException {
                                                                                                          // Arrange
                                                                                                          InputStream input = mock(InputStream.class);
                                                                                                          long numToSkip = 100L;
                                                                                                          when(input.skip(numToSkip)).thenReturn(0L);
                                                                                                          
                                                                                                          // Act
                                                                                                          long skipped = IOUtils.skip(input, numToSkip);
                                                                                                          
                                                                                                          // Assert
                                                                                                          assertEquals("Should return 0 when skip returns 0", 0L, skipped);
                                                                                                          verify(input, times(1)).skip(numToSkip);
                                                                                                          verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                      }

    @Test
                                                                                                public void testSkip_ShouldNotSkipMoreThanRequested() throws IOException {
                                                                                                    // Arrange
                                                                                                    InputStream input = mock(InputStream.class);
                                                                                                    long numToSkip = 100;
                                                                                                    
                                                                                                    // Mock behavior:
                                                                                                    // First skip returns 50 (half the requested amount)
                                                                                                    // Then readFully will return 25 bytes each time
                                                                                                    // After 2 reads (total 50+25+25=100), we should stop
                                                                                                    // But mutant would continue trying to read
                                                                                                    when(input.skip(numToSkip)).thenReturn(50L);
                                                                                                    when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                        .thenReturn(25); // always return 25 bytes
                                                                                                    
                                                                                                    // Act
                                                                                                    long skipped = IOUtils.skip(input, numToSkip);
                                                                                                    
                                                                                                    // Assert
                                                                                                    assertEquals("Should skip exactly the requested amount", numToSkip, skipped);
                                                                                                    
                                                                                                    // Verify interaction - should only call read twice (50 + 25 + 25)
                                                                                                    verify(input, times(1)).skip(numToSkip);
                                                                                                    verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                }

    @Test
                                                                                           public void testSkip_DetectsMutatedSkipAmount() throws IOException {
                                                                                               // Create a mock InputStream that records the skip amount
                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                               
                                                                                               // Setup the mock to return exactly what's requested when skipping
                                                                                               // This will help detect if the mutant asks for numToSkip+1
                                                                                               when(mockInput.skip(anyLong())).thenAnswer(invocation -> {
                                                                                                   Long requested = (Long) invocation.getArguments()[0];
                                                                                                   return requested; // Return exactly what was requested
                                                                                               });
                                                                                               
                                                                                               // Test skipping exactly 10 bytes
                                                                                               long numToSkip = 10;
                                                                                               long result = IOUtils.skip(mockInput, numToSkip);
                                                                                               
                                                                                               // Verify the result is correct
                                                                                               assertEquals(10, result);
                                                                                               
                                                                                               // Verify the skip was called with exactly 10 (not 11)
                                                                                               verify(mockInput).skip(10);
                                                                                               
                                                                                               // The mutant would call skip(11) here, which would make the test fail
                                                                                               // because we verify skip(10) was called
                                                                                           }

    @Test
                                                                                           public void testSkip_ShouldUseSkipMethodResult() throws Exception {
                                                                                               // Arrange
                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                               long numToSkip = 100;
                                                                                               long expectedSkipResult = 50;
                                                                                               
                                                                                               // Configure the mock to return some skipped bytes when skip() is called
                                                                                               when(mockInput.skip(numToSkip)).thenReturn(expectedSkipResult);
                                                                                               // Configure readFully to return 0 to simulate end of stream
                                                                                               when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                               
                                                                                               // Act
                                                                                               long actualSkipped = IOUtils.skip(mockInput, numToSkip);
                                                                                               
                                                                                               // Assert
                                                                                               // Verify skip() was called
                                                                                               verify(mockInput).skip(numToSkip);
                                                                                               // The method should return the bytes skipped by skip() method
                                                                                               assertEquals("Should return the bytes skipped by skip() method", 
                                                                                                           expectedSkipResult, actualSkipped);
                                                                                               
                                                                                               // With the mutant (skipped = 0), the method would return 0 instead of expectedSkipResult
                                                                                               // So this test would fail with the mutant, thus detecting it
                                                                                           }

    @Test
                                                                                           public void testSkip_ShouldFallBackToReadingWhenSkipFails() throws Exception {
                                                                                               // Arrange
                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                               long numToSkip = 100;
                                                                                               int bufSize = 8192; // Assuming SKIP_BUF_SIZE is 8192
                                                                                               
                                                                                               // Configure skip to return 0 (can't skip)
                                                                                               when(mockInput.skip(numToSkip)).thenReturn(0L);
                                                                                               // Configure read to return 50 bytes then 0 (end of stream)
                                                                                               when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                   .thenReturn(50)
                                                                                                   .thenReturn(0);
                                                                                               
                                                                                               // Act
                                                                                               long actualSkipped = IOUtils.skip(mockInput, numToSkip);
                                                                                               
                                                                                               // Assert
                                                                                               // Verify skip was attempted
                                                                                               verify(mockInput).skip(numToSkip);
                                                                                               // Verify read was called with buffer
                                                                                               verify(mockInput, atLeastOnce()).read(any(byte[].class), eq(0), 
                                                                                                                               eq((int)Math.min(numToSkip, bufSize)));
                                                                                               // Should return the bytes read (50)
                                                                                               assertEquals(50L, actualSkipped);
                                                                                           }

    @Test
                                                                                     public void testSkipWithNegativeSkippedValue2() throws Exception {
                                                                                         // Create a mock InputStream that returns -1 from skip()
                                                                                         InputStream input = mock(InputStream.class);
                                                                                         when(input.skip(anyLong())).thenReturn(-1L);
                                                                                         
                                                                                         // Test with the original implementation (should continue trying to skip)
                                                                                         long numToSkip = 100;
                                                                                         long skipped = IOUtils.skip(input, numToSkip);
                                                                                         
                                                                                         // Verify the behavior:
                                                                                         // 1. Original would continue trying (would call skip multiple times)
                                                                                         // 2. Mutated would stop after first negative return
                                                                                         verify(input, atLeast(2)).skip(anyLong());
                                                                                         
                                                                                         // Since our mock always returns -1, original would try to read via buffer
                                                                                         // We need to mock readFully behavior too
                                                                                         // Reset mock for the buffer reading part
                                                                                         reset(input);
                                                                                         // Use a reasonable buffer size (8192 is common for I/O operations)
                                                                                         byte[] buf = new byte[8192];
                                                                                         when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                         
                                                                                         skipped = IOUtils.skip(input, numToSkip);
                                                                                         
                                                                                         // Should return 0 since we couldn't skip anything
                                                                                         assertEquals(0, skipped);
                                                                                         
                                                                                         // Verify read was attempted (original behavior)
                                                                                         verify(input).read(any(byte[].class), anyInt(), anyInt());
                                                                                         
                                                                                         // For the mutated version, this test would fail because:
                                                                                         // 1. The first skip() returns -1
                                                                                         // 2. Mutated condition (<=0) would trigger the break
                                                                                         // 3. No buffer reading would occur
                                                                                         // 4. The test would fail on verify() checks
                                                                                     }

    @Test
                                                                                 public void testSkipWithZeroBytesShouldNotAttemptToSkip() throws IOException {
                                                                                     // Arrange
                                                                                     InputStream input = mock(InputStream.class);
                                                                                     long numToSkip = 0L;
                                                                                     
                                                                                     // Act
                                                                                     long result = IOUtils.skip(input, numToSkip);
                                                                                     
                                                                                     // Assert
                                                                                     assertEquals(0L, result);
                                                                                     verify(input, never()).skip(anyLong());
                                                                                     verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                 }

    @Test
                                                                                public void testSkipWithZeroBytesShouldNotCallReadFully1() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream input = mock(InputStream.class);
                                                                                    when(input.skip(anyLong())).thenReturn(0L);
                                                                                    
                                                                                    // Act
                                                                                    long skipped = IOUtils.skip(input, 0);
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(0, skipped);
                                                                                    verify(input, times(1)).skip(0);  // Should try skip once
                                                                                    verify(input, never()).read(any(byte[].class), anyInt(), anyInt());  // Should never call read
                                                                                    
                                                                                    // The mutant would fail this test because it would enter the second block
                                                                                    // and call readFully even when numToSkip is 0
                                                                                }

    @Test
                                                                                public void testSkipWithNegativeBytesShouldNotCallReadFully() throws Exception {
                                                                                    // Arrange
                                                                                    InputStream input = mock(InputStream.class);
                                                                                    when(input.skip(anyLong())).thenReturn(0L);
                                                                                    
                                                                                    // Act
                                                                                    long skipped = IOUtils.skip(input, -100);
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(0, skipped);
                                                                                    verify(input, times(1)).skip(-100);  // Should try skip once
                                                                                    verify(input, never()).read(any(byte[].class), anyInt(), anyInt());  // Should never call read
                                                                                    
                                                                                    // The mutant would fail this test because it would enter the second block
                                                                                    // and call readFully even when numToSkip is negative
                                                                                }

    @Test
                                                                              public void testSkip_ShouldUseCorrectBufferSize() throws IOException {
                                                                                  // Arrange
                                                                                  final int SKIP_BUF_SIZE = 8192; // Assuming this is the value from class
                                                                                  final long bytesToSkip = SKIP_BUF_SIZE * 2 + 1; // Need more than one buffer read
                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                  
                                                                                  // Make skip() fail to force buffer reading path
                                                                                  when(mockInput.skip(anyLong())).thenReturn(0L);
                                                                                  
                                                                                  // Track buffer sizes used in read operations
                                                                                  final List<Integer> bufferSizes = new ArrayList<>();
                                                                                  when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                      Object[] args = invocation.getArguments();
                                                                                      byte[] buf = (byte[]) args[0];
                                                                                      int len = (int) args[2];
                                                                                      bufferSizes.add(buf.length); // Record actual buffer size
                                                                                      return len; // Return full read each time
                                                                                  });
                                                                                  
                                                                                  // Act
                                                                                  long skipped = IOUtils.skip(mockInput, bytesToSkip);
                                                                                  
                                                                                  // Assert
                                                                                  assertEquals(bytesToSkip, skipped);
                                                                                  
                                                                                  // Verify buffer sizes used were exactly SKIP_BUF_SIZE
                                                                                  for (int size : bufferSizes) {
                                                                                      assertEquals("Buffer size should be exactly SKIP_BUF_SIZE", 
                                                                                                  SKIP_BUF_SIZE, size);
                                                                                  }
                                                                                  
                                                                                  // Verify we did multiple reads (proving buffer was used)
                                                                                  assertTrue("Should have used buffer reads", bufferSizes.size() > 0);
                                                                              }

    @Test
                                                                              public void testSkipZeroBytesShouldNotPerformAnyOperations() throws Exception {
                                                                                  // Arrange
                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                  long numToSkip = 0L;
                                                                                  
                                                                                  // Act
                                                                                  long result = IOUtils.skip(mockInput, numToSkip);
                                                                                  
                                                                                  // Assert
                                                                                  assertEquals("Should return 0 when skipping 0 bytes", 0, result);
                                                                                  verify(mockInput, never()).skip(anyLong());
                                                                                  verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                              }

    @Test(timeout = 1000) // Add timeout to detect infinite loops
                                                                         public void testSkipExactBytesDetectsInfiniteLoopMutant() throws IOException {
                                                                             // Arrange
                                                                             final long bytesToSkip = 1024;
                                                                             InputStream input = mock(InputStream.class);
                                                                             
                                                                             // Mock the input stream to:
                                                                             // 1. Return all bytes in first skip() call
                                                                             // 2. Never reach readFully() calls
                                                                             when(input.skip(bytesToSkip)).thenReturn(bytesToSkip);
                                                                             
                                                                             // Act
                                                                             long skipped = IOUtils.skip(input, bytesToSkip);
                                                                             
                                                                             // Assert
                                                                             assertEquals("Should skip exactly requested bytes", bytesToSkip, skipped);
                                                                             
                                                                             // Verify the interaction - should only call skip() once
                                                                             verify(input, times(1)).skip(bytesToSkip);
                                                                             verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                         }

    @Test
                                                                       public void testSkipWithPartialReadsDetectsOffsetMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                           // Setup
                                                                           InputStream input = mock(InputStream.class);
                                                                           when(input.skip(anyLong())).thenReturn(0L); // Force fallback to readFully
                                                                           
                                                                           // Get private SKIP_BUF_SIZE using reflection
                                                                           Field skipBufSizeField = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                           skipBufSizeField.setAccessible(true);
                                                                           int SKIP_BUF_SIZE = skipBufSizeField.getInt(null);
                                                                           
                                                                           // Create test data that would expose the offset mutation
                                                                           byte[] testData = new byte[SKIP_BUF_SIZE * 2];
                                                                           java.util.Arrays.fill(testData, (byte)1); // Fill with non-zero data
                                                                           
                                                                           // Mock readFully to return partial reads
                                                                           when(input.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                               int offset = (int) invocation.getArguments()[1];
                                                                               int len = (int) invocation.getArguments()[2];
                                                                               
                                                                               // Verify the offset is 0 (original behavior)
                                                                               // This will fail if mutant is present (offset would be 1)
                                                                               assertEquals(0, offset);
                                                                               
                                                                               // Fill the requested portion of buffer
                                                                               int bytesToRead = Math.min(len, testData.length / 2);
                                                                               System.arraycopy(testData, 0, buf, offset, bytesToRead);
                                                                               return bytesToRead;
                                                                           });
                                                                           
                                                                           long numToSkip = SKIP_BUF_SIZE + 10; // More than one buffer
                                                                           long skipped = IOUtils.skip(input, numToSkip);
                                                                           
                                                                           // Verify all bytes were skipped
                                                                           assertEquals(numToSkip, skipped);
                                                                           
                                                                           // Verify readFully was called with correct parameters
                                                                           verify(input, atLeastOnce()).read(any(byte[].class), eq(0), anyInt());
                                                                       }

    @Test
                                                          public void testSkipWithSmallNumToSkipShouldNotExceedRequestedBytes() throws IOException {
                                                              // Arrange
                                                              final int SKIP_BUF_SIZE = 8192; // Assuming this is the value from class
                                                              final long smallNumToSkip = 100; // Less than SKIP_BUF_SIZE
                                                              InputStream mockInput = mock(InputStream.class);
                                                              
                                                              // Mock behavior:
                                                              // First skip attempt returns 0 (forcing fallback to read)
                                                              when(mockInput.skip(smallNumToSkip)).thenReturn(0L);
                                                              // When reading, return exactly what was requested
                                                              when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                  .thenAnswer(invocation -> {
                                                                      Object[] args = invocation.getArguments();
                                                                      return (Integer) args[2]; // Return the length argument
                                                                  });
                                                              
                                                              // Act
                                                              long skipped = IOUtils.skip(mockInput, smallNumToSkip);
                                                              
                                                              // Assert
                                                              assertEquals("Should have skipped exactly requested bytes", smallNumToSkip, skipped);
                                                              
                                                              // Verify the read was called with the correct length (min, not max)
                                                              verify(mockInput).read(any(byte[].class), eq(0), eq((int)smallNumToSkip));
                                                              
                                                              // Additional verification that we didn't try to read SKIP_BUF_SIZE bytes
                                                              verify(mockInput, never()).read(any(byte[].class), anyInt(), eq(SKIP_BUF_SIZE));
                                                          }

    @Test
                                                 public void testSkipWithNumToSkipLargerThanBufferSize1() throws Exception {
                                                     // Arrange
                                                     InputStream input = mock(InputStream.class);
                                                     
                                                     // Get private SKIP_BUF_SIZE using reflection
                                                     Field skipBufSizeField = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                     skipBufSizeField.setAccessible(true);
                                                     int skipBufSize = skipBufSizeField.getInt(null);
                                                     
                                                     long numToSkip = skipBufSize + 1; // Make sure it's larger than buffer
                                                     
                                                     // Mock behavior:
                                                     // First skip returns partial skip (triggering fallback)
                                                     when(input.skip(numToSkip)).thenReturn((long)skipBufSize);
                                                     // Then mock the readFully behavior
                                                     // First read returns full buffer
                                                     // Second read returns 1 byte (remaining)
                                                     doAnswer(invocation -> {
                                                         byte[] buf = (byte[])invocation.getArguments()[0];
                                                         int off = (int)invocation.getArguments()[1];
                                                         int len = (int)invocation.getArguments()[2];
                                                         return len;
                                                     }).when(input).read(any(byte[].class), anyInt(), anyInt());
                                                     
                                                     // Act
                                                     long skipped = IOUtils.skip(input, numToSkip);
                                                     
                                                     // Assert
                                                     assertEquals(numToSkip, skipped);
                                                     
                                                     // Verify the fallback read was called with proper chunk sizes
                                                     verify(input).read(any(byte[].class), eq(0), eq(skipBufSize));
                                                     verify(input).read(any(byte[].class), eq(0), eq(1));
                                                 }

    @Test
                                            public void testSkip_ShouldContinueWhenReadReturnsZero() throws Exception {
                                                // Arrange
                                                InputStream input = mock(InputStream.class);
                                                long numToSkip = 1024; // Request to skip 1KB
                                                int skipBufSize = 512; // Buffer size for fallback reading
                                                
                                                // Mock behavior:
                                                // First skip attempt skips partial amount (512 bytes)
                                                when(input.skip(numToSkip)).thenReturn(512L);
                                                // Second skip attempt returns 0 (no more bytes skipped)
                                                when(input.skip(512L)).thenReturn(0L);
                                                
                                                // Mock readFully to return 0 (but not EOF)
                                                // We need to mock the static readFully method - this requires PowerMock or similar,
                                                // but since we can't use it, we'll test the behavior indirectly by checking
                                                // that the method keeps trying when read returns 0
                                                
                                                // For this test, we'll use a custom InputStream that implements this behavior
                                                InputStream testInput = new InputStream() {
                                                    private int skipCount = 0;
                                                    private int readCount = 0;
                                                    
                                                    @Override
                                                    public long skip(long n) {
                                                        if (skipCount++ == 0) {
                                                            return 512; // first skip returns 512
                                                        }
                                                        return 0; // subsequent skips return 0
                                                    }
                                                    
                                                    @Override
                                                    public int read(byte[] b, int off, int len) {
                                                        // Simulate readFully behavior
                                                        if (readCount++ < 3) {
                                                            return 0; // first 3 reads return 0
                                                        }
                                                        return -1; // then EOF
                                                    }
                                                    
                                                    @Override
                                                    public int read() {
                                                        return -1;
                                                    }
                                                };
                                                
                                                // Act
                                                long skipped = IOUtils.skip(testInput, numToSkip);
                                                
                                                // Assert
                                                // Original behavior should keep trying after read returns 0,
                                                // so it should eventually hit EOF and return 512 (from initial skip)
                                                assertEquals(512L, skipped);
                                                
                                                // The mutant would stop at first read returning 0 and return 512,
                                                // so this test would pass for mutant too. We need a stronger test.
                                                // Let's modify the test to verify multiple read attempts:
                                                
                                                // New test with verification of multiple read attempts
                                                final int[] readAttempts = new int[1];
                                                InputStream verifyingInput = new InputStream() {
                                                    private int skipCount = 0;
                                                    
                                                    @Override
                                                    public long skip(long n) {
                                                        if (skipCount++ == 0) {
                                                            return 512;
                                                        }
                                                        return 0;
                                                    }
                                                    
                                                    @Override
                                                    public int read(byte[] b, int off, int len) {
                                                        readAttempts[0]++;
                                                        return 0; // always return 0
                                                    }
                                                    
                                                    @Override
                                                    public int read() {
                                                        return -1;
                                                    }
                                                };
                                                
                                                long result = IOUtils.skip(verifyingInput, numToSkip);
                                                // Original should make multiple read attempts (until buffer filled)
                                                assertTrue(readAttempts[0] > 1);
                                                assertEquals(512L, result);
                                                
                                                // The mutant would stop after first read (<=0), so readAttempts would be 1
                                                // This difference would catch the mutant
                                            }

    @Test
                                   public void testSkipWithPartialSkipsAndReads() throws IOException {
                                       // Arrange
                                       InputStream input = mock(InputStream.class);
                                       when(input.skip(anyLong())).thenReturn(5L, 0L); // First skip returns 5, then 0
                                       when(input.read(any(byte[].class), anyInt(), anyInt()))
                                           .thenAnswer(invocation -> {
                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                               int off = (Integer) invocation.getArguments()[1];
                                               int len = (Integer) invocation.getArguments()[2];
                                               return len; // Always read full requested length
                                           });
                                       
                                       long numToSkip = 10;
                                       long expectedSkipped = 10; // Should skip all 10 bytes
                                       
                                       // Act
                                       long actualSkipped = IOUtils.skip(input, numToSkip);
                                       
                                       // Assert
                                       assertEquals("Should have skipped all requested bytes", 
                                                   expectedSkipped, actualSkipped);
                                       
                                       // Verify interaction
                                       verify(input, times(2)).skip(anyLong()); // Two skip attempts
                                       verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                   }

    @Test
                              public void testSkipWithExactBufferSizeDetectsMutant() throws Exception {
                                  // Arrange
                                  final int SKIP_BUF_SIZE = 8192; // Common buffer size, matches IOUtils implementation
                                  InputStream input = mock(InputStream.class);
                                  when(input.skip(anyLong())).thenReturn(0L); // Force the method to use readFully
                                  
                                  // Setup readFully to return exactly SKIP_BUF_SIZE bytes
                                  when(input.read(any(byte[].class), anyInt(), anyInt()))
                                      .thenReturn(SKIP_BUF_SIZE);
                                  
                                  // Act
                                  long skipped = IOUtils.skip(input, SKIP_BUF_SIZE + 10); // Try to skip more than buffer size
                                  
                                  // Assert
                                  // Original code should return SKIP_BUF_SIZE, mutant would return SKIP_BUF_SIZE (same in this case)
                                  // This test shows the mutant isn't caught in all cases
                                  assertEquals("Should have skipped buffer size bytes", SKIP_BUF_SIZE, skipped);
                                  
                                  // This test alone wouldn't catch the mutant, which is why we need the first test
                                  verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());
                              }

    @Test
              public void testSkipWithMultipleReadsDetectsMutant2() throws Exception {
                  // Arrange
                  InputStream input = mock(InputStream.class);
                  when(input.skip(anyLong())).thenReturn(0L); // Force the method to use readFully
                  
                  // Setup readFully to return partial reads (3 bytes then 2 bytes)
                  when(input.read(any(byte[].class), anyInt(), anyInt()))
                      .thenAnswer(invocation -> {
                          byte[] buf = (byte[]) invocation.getArguments()[0];
                          int off = (Integer) invocation.getArguments()[1];
                          int len = (Integer) invocation.getArguments()[2];
                          return len > 3 ? 3 : 2; // First read returns 3, second returns 2
                      });
                  
                  // Act
                  long skipped = IOUtils.skip(input, 5); // Try to skip 5 bytes
                  
                  // Assert
                  // Original code should return 5 (3+2), mutant would return 2 (last read value)
                  assertEquals("Should have skipped all 5 bytes", 5, skipped);
                  
                  // Verify the read operations
                  verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
              }

    @Test
          public void testSkipExactlyRequestedBytes() throws IOException {
              // Arrange
              InputStream input = mock(InputStream.class);
              long numToSkip = 10;
              
              // Mock the input stream to skip exactly the requested amount
              when(input.skip(numToSkip)).thenReturn(numToSkip);
              when(input.skip(numToSkip - 1)).thenReturn(numToSkip - 1);
              
              // Act
              long skipped = IOUtils.skip(input, numToSkip);
              
              // Assert
              assertEquals("Should have skipped exactly the requested bytes", 
                          numToSkip, skipped);
              verify(input).skip(numToSkip);  // Verify original behavior was used
              verify(input, never()).skip(numToSkip - 1);  // Would fail for mutant
          }

    @Test
    public void testSkipWithMultipleBufferReads() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Arrange
        InputStream input = mock(InputStream.class);
        // Get private SKIP_BUF_SIZE using reflection
        Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
        field.setAccessible(true);
        int skipBufferSize = field.getInt(null);
        int skipSize = skipBufferSize * 2 + 10; // Need more than one buffer read
        long initialSkip = 5;
        
        // Mock behavior:
        // First skip returns partial skip
        when(input.skip(anyLong())).thenReturn(initialSkip);
        
        // First readFully returns full buffer
        // Second readFully returns partial buffer
        when(input.read(any(byte[].class), anyInt(), anyInt()))
            .thenAnswer(invocation -> {
                byte[] buf = (byte[]) invocation.getArguments()[0];
                int off = (Integer) invocation.getArguments()[1];
                int len = (Integer) invocation.getArguments()[2];
                return len; // First read returns full buffer
            })
            .thenAnswer(invocation -> {
                return 10; // Second read returns 10 bytes
            })
            .thenReturn(-1); // EOF
        
        // Act
        long skipped = IOUtils.skip(input, skipSize);
        
        // Assert
        // Original would return initialSkip + SKIP_BUF_SIZE + 10
        // Mutant would return less because it only decrements by 1 per read
        long expected = initialSkip + skipBufferSize + 10;
        assertEquals("Should have skipped all requested bytes", expected, skipped);
        
        // Verify interaction
        verify(input, times(1)).skip(skipSize);
        verify(input, times(3)).read(any(byte[].class), anyInt(), anyInt());
    }


}
