package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.Serializable;
import java.util.Date;
import java.util.zip.ZipException;
 
public class X5455_ExtendedTimestampTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                      public void testUnixTimeToZipLong_ValidWithinIntegerRange() throws Exception {
                                          // Get the private method using reflection
                                          Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                          unixTimeToZipLong.setAccessible(true);
                                          
                                          // Test minimum valid 32-bit signed integer value
                                          ZipLong result1 = (ZipLong) unixTimeToZipLong.invoke(null, (long)Integer.MIN_VALUE);
                                          assertEquals(Integer.MIN_VALUE, result1.getValue());
                                          
                                          // Test maximum valid 32-bit signed integer value
                                          ZipLong result2 = (ZipLong) unixTimeToZipLong.invoke(null, (long)Integer.MAX_VALUE);
                                          assertEquals(Integer.MAX_VALUE, result2.getValue());
                                          
                                          // Test zero value
                                          ZipLong result3 = (ZipLong) unixTimeToZipLong.invoke(null, 0L);
                                          assertEquals(0, result3.getValue());
                                          
                                          // Test positive value within range
                                          ZipLong result4 = (ZipLong) unixTimeToZipLong.invoke(null, 1234567890L);
                                          assertEquals(1234567890L, result4.getValue());
                                          
                                          // Test negative value within range
                                          ZipLong result5 = (ZipLong) unixTimeToZipLong.invoke(null, -987654321L);
                                          assertEquals(-987654321L, result5.getValue());
                                      }

    @Test
                                      public void testUnixTimeToZipLong_InvalidBelowIntegerMinValue() throws Exception {
                                          // Setup expected exception
                                          org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                          expectedException.expect(IllegalArgumentException.class);
                                          expectedException.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + (Integer.MIN_VALUE - 1L));
                                          
                                          // Use reflection to access private method
                                          java.lang.reflect.Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                              "unixTimeToZipLong", long.class);
                                          method.setAccessible(true);
                                          method.invoke(null, Integer.MIN_VALUE - 1L);
                                      }

    @Test
                                      public void testUnixTimeToZipLong_ExtremePositiveValue() throws Exception {
                                          // Setup expected exception
                                          org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                          expectedException.expect(IllegalArgumentException.class);
                                          expectedException.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + Long.MAX_VALUE);
                                          
                                          // Use reflection to access private method
                                          java.lang.reflect.Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                          method.setAccessible(true);
                                          method.invoke(null, Long.MAX_VALUE);
                                      }

    @Test
                                      public void testUnixTimeToZipLong_BoundaryValues() throws Exception {
                                          // Get the private method using reflection
                                          Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                          unixTimeToZipLong.setAccessible(true);
                                          
                                          // Test just inside lower boundary
                                          ZipLong result1 = (ZipLong) unixTimeToZipLong.invoke(null, (long)Integer.MIN_VALUE);
                                          assertEquals(Integer.MIN_VALUE, result1.getValue());
                                          
                                          // Test just inside upper boundary
                                          ZipLong result2 = (ZipLong) unixTimeToZipLong.invoke(null, (long)Integer.MAX_VALUE);
                                          assertEquals(Integer.MAX_VALUE, result2.getValue());
                                      }

    @Test
                                  public void testUnixTimeToZipLong_InvalidAboveIntegerMaxValue() throws Exception {
                                      ExpectedException expectedException = ExpectedException.none();
                                      
                                      expectedException.expect(IllegalArgumentException.class);
                                      expectedException.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + (Integer.MAX_VALUE + 1L));
                                      
                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                      method.setAccessible(true);
                                      method.invoke(null, Integer.MAX_VALUE + 1L);
                                  }

    @Test
                                  public void testUnixTimeToZipLong_ExtremeNegativeValue() throws Exception {
                                      ExpectedException expectedException = ExpectedException.none();
                                      
                                      expectedException.expect(IllegalArgumentException.class);
                                      expectedException.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + Long.MIN_VALUE);
                                      
                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                      method.setAccessible(true);
                                      method.invoke(null, Long.MIN_VALUE);
                                  }

    @Test
                                  public void testDateToZipLongWithNonNullInput() {
                                      // Test non-null input - original processes, mutant returns null
                                      Date testDate = new Date(1617235200000L); // Fixed test date (April 1, 2021)
                                      
                                      // Mock the unixTimeToZipLong to return a known value
                                      ZipLong expected = new ZipLong(12345L);
                                      X5455_ExtendedTimestamp instance = new X5455_ExtendedTimestamp();
                                      try {
                                          // Use reflection to test private method
                                          java.lang.reflect.Method method = X5455_ExtendedTimestamp.class
                                              .getDeclaredMethod("dateToZipLong", Date.class);
                                          method.setAccessible(true);
                                          ZipLong result = (ZipLong) method.invoke(instance, testDate);
                                          
                                          // Verify original would process, mutant would return null
                                          assertNotNull("Should not return null for non-null input", result);
                                      } catch (Exception e) {
                                          fail("Exception occurred during test: " + e.getMessage());
                                      }
                                  }

    @Test
                             public void testDateToZipLongWithNullInput() throws Exception {
                                 // Test null input - original returns null, mutant would throw NPE
                                 Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                 dateToZipLongMethod.setAccessible(true);
                                 ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, (Date) null);
                                 assertNull("Should return null for null input", result);
                             }

    @Test
                        public void testDateToZipLongWithNullInput1() throws Exception {
                            // Test that null input returns null (original behavior)
                            // This will fail if the mutant is present (which returns ZipLong(0))
                            
                            // Use reflection to access the private method
                            Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                            dateToZipLongMethod.setAccessible(true);
                            ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, (Date) null);
                            
                            // Assert the original behavior - should be null
                            assertNull("dateToZipLong should return null for null input", result);
                            
                            // Additional check to explicitly catch the mutant
                            // If mutant is present, result would be a ZipLong(0)
                            if (result != null) {
                                assertEquals(0, result.getValue());
                                fail("Mutant detected: dateToZipLong returned ZipLong(0) instead of null for null input");
                            }
                        }

    @Test
                   public void testDateToZipLong_ConvertsToSeconds() throws Exception {
                       // Create a fixed date (e.g., 1234567890 milliseconds since epoch)
                       Date testDate = new Date(1234567890L);
                       
                       // Expected value should be in seconds (1234567890 / 1000 = 1234567)
                       long expectedSeconds = 1234567L;
                       
                       // Get the private method using reflection
                       Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                       dateToZipLongMethod.setAccessible(true);
                       
                       // Call the method
                       ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                       
                       // Verify the conversion to seconds happened properly
                       // The mutated version would pass the raw milliseconds (1234567890)
                       // which would be much larger than our expected value
                       assertEquals(expectedSeconds, result.getValue());
                       
                       // Also test null case
                       assertNull(dateToZipLongMethod.invoke(null, (Date) null));
                   }

    @Test
              public void testDateToZipLong_ConvertsTimeCorrectly() throws Exception {
                  // Setup test data - use a fixed time value (2000-01-01 00:00:00 GMT)
                  Date testDate = new Date(946684800000L); // Known timestamp
                  
                  // Create instance of the class
                  X5455_ExtendedTimestamp timestamp = new X5455_ExtendedTimestamp();
                  
                  // Get private method using reflection
                  Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                  dateToZipLongMethod.setAccessible(true);
                  
                  // Call the method
                  ZipLong result = (ZipLong) dateToZipLongMethod.invoke(timestamp, testDate);
                  
                  // Get the unixTimeToZipLong method to verify the conversion
                  Method unixTimeToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                  unixTimeToZipLongMethod.setAccessible(true);
                  
                  // Verify the conversion was correct by calling unixTimeToZipLong directly
                  ZipLong expected = (ZipLong) unixTimeToZipLongMethod.invoke(timestamp, 946684800L);
                  
                  // Assert the results match
                  assertEquals(expected, result);
              }

    @Test
              public void testDateToZipLong_ReturnsNullForNullInput() throws Exception {
                  // Test null input case
                  Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                  dateToZipLongMethod.setAccessible(true);
                  Object result = dateToZipLongMethod.invoke(null, (Date)null);
                  assertNull(result);
              }

    @Test
         public void testDateToZipLong_ThrowsIllegalArgumentExceptionForLargeDate() throws Exception {
             // Create a date with timestamp that would overflow 32-bit signed integer when converted to seconds
             // 2^31 seconds = ~68 years, so we use a date far in the future
             Date largeDate = new Date(Long.MAX_VALUE);
             
             // Get the private method using reflection
             Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
             dateToZipLongMethod.setAccessible(true);
             
             try {
                 // Invoke the private method
                 dateToZipLongMethod.invoke(null, largeDate);
                 
                 // If we reach here, no exception was thrown - which is wrong
                 fail("Expected IllegalArgumentException for date with timestamp exceeding 32-bit signed integer range");
             } catch (InvocationTargetException e) {
                 // Check if the cause is IllegalArgumentException
                 if (!(e.getCause() instanceof IllegalArgumentException)) {
                     fail("Expected IllegalArgumentException but got " + e.getCause().getClass().getName());
                 }
                 // Expected exception was thrown, test passes
             }
         }

    @Test
    public void testDateToZipLongWithLargeTimestamp() throws Exception {
        // Create a date with timestamp that exceeds 32-bit signed integer range
        // 2^31 seconds after epoch (January 19, 2038) will trigger the exception
        Date largeDate = new Date((long)Integer.MAX_VALUE * 1000L + 1000L);
        
        // Get the private method using reflection
        Method dateToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
        dateToZipLong.setAccessible(true);
        
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: ");
        
        // Call the method that should trigger the exception
        dateToZipLong.invoke(null, largeDate);
    }


}
