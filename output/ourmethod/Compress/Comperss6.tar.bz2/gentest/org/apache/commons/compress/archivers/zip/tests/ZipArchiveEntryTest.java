package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                              public void testEquals_Reflexive() {
                                                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                  assertTrue(entry.equals(entry));
                                                                                                                              }

    @Test
                                                                                                                              public void testEquals_NullObject() {
                                                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                  assertFalse(entry.equals(null));
                                                                                                                              }

    @Test
                                                                                                                              public void testEquals_DifferentClass() {
                                                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                  Object other = new Object();
                                                                                                                                  assertFalse(entry.equals(other));
                                                                                                                              }

    @Test
                                                                                                                              public void testEquals_SameName() {
                                                                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                                  assertTrue(entry1.equals(entry2));
                                                                                                                              }

    @Test
                                                                                                                              public void testEquals_DifferentName() {
                                                                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                                                                                                  assertFalse(entry1.equals(entry2));
                                                                                                                              }

    @Test
                                                                                                                              public void testEquals_CaseSensitiveNames() {
                                                                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("TEST.TXT");
                                                                                                                                  assertFalse(entry1.equals(entry2));
                                                                                                                              }

    @Test
                                                                                                                              public void testEquals_WithDifferentAttributes() {
                                                                                                                                  ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                                  entry1.setMethod(8);
                                                                                                                                  entry1.setInternalAttributes(1);
                                                                                                                                  entry1.setExternalAttributes(123L);
                                                                                                                                  
                                                                                                                                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                                  entry2.setMethod(0);
                                                                                                                                  entry2.setInternalAttributes(0);
                                                                                                                                  entry2.setExternalAttributes(0L);
                                                                                                                                  
                                                                                                                                  // Should still be equal because only name is compared
                                                                                                                                  assertTrue(entry1.equals(entry2));
                                                                                                                              }

    @Test
                                                                                                                      public void testEquals_BothNamesNull() throws Exception {
                                                                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                          setNameMethod.invoke(entry1, (String)null);
                                                                                                                          
                                                                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                                                                                          setNameMethod.invoke(entry2, (String)null);
                                                                                                                          
                                                                                                                          assertTrue(entry1.equals(entry2));
                                                                                                                      }

    @Test
                                                                                                                      public void testEquals_OneNameNull() throws Exception {
                                                                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                          setNameMethod.invoke(entry1, (String)null);
                                                                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                          assertFalse(entry1.equals(entry2));
                                                                                                                      }

    @Test
                                                                                                                      public void testEquals_OtherNameNull() throws Exception {
                                                                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                                                                                          
                                                                                                                          // Use reflection to access protected setName method
                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                          setNameMethod.invoke(entry2, (String)null);
                                                                                                                          
                                                                                                                          assertFalse(entry1.equals(entry2));
                                                                                                                      }

    @Test
                                                                                                                      public void testEquals_WithMockedObjects() {
                                                                                                                          ZipArchiveEntry realEntry = new ZipArchiveEntry("test.txt");
                                                                                                                          
                                                                                                                          ZipArchiveEntry mockedEntry = mock(ZipArchiveEntry.class);
                                                                                                                          when(mockedEntry.getClass()).thenReturn((Class) ZipArchiveEntry.class);
                                                                                                                          when(mockedEntry.getName()).thenReturn("test.txt");
                                                                                                                          
                                                                                                                          assertTrue(realEntry.equals(mockedEntry));
                                                                                                                      }

    @Test
                                                                                                                      public void testEquals_WithMockedObjectsDifferentName() {
                                                                                                                          ZipArchiveEntry realEntry = new ZipArchiveEntry("test.txt");
                                                                                                                          
                                                                                                                          ZipArchiveEntry mockedEntry = mock(ZipArchiveEntry.class);
                                                                                                                          when(mockedEntry.getClass()).thenReturn((Class) ZipArchiveEntry.class);
                                                                                                                          when(mockedEntry.getName()).thenReturn("different.txt");
                                                                                                                          
                                                                                                                          assertFalse(realEntry.equals(mockedEntry));
                                                                                                                      }

    @Test
                                                                                                                      public void testEquals_SameObjectReference_ReturnsTrue() {
                                                                                                                          // Create a ZipArchiveEntry object
                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                          
                                                                                                                          // Test that object equals itself
                                                                                                                          // This should use the reference equality check (this == obj)
                                                                                                                          // and return true immediately
                                                                                                                          assertTrue(entry.equals(entry));
                                                                                                                          
                                                                                                                          // The mutant will skip the reference check and do full comparison
                                                                                                                          // The assertion would still pass, but we can detect the mutant by:
                                                                                                                          // 1. The performance difference (though we can't test that easily)
                                                                                                                          // 2. The fact that the mutant would execute more code paths
                                                                                                                          // To properly catch this, we need to verify the reference check is working
                                                                                                                          // by ensuring it doesn't do unnecessary comparisons
                                                                                                                          
                                                                                                                          // Additional verification that name comparison isn't done unnecessarily
                                                                                                                          // Mock the getName() to throw exception if called
                                                                                                                          ZipArchiveEntry spyEntry = mock(ZipArchiveEntry.class);
                                                                                                                          when(spyEntry.getName()).thenThrow(new RuntimeException("Shouldn't call getName() for self comparison"));
                                                                                                                          
                                                                                                                          // This should pass without calling getName()
                                                                                                                          assertTrue(spyEntry.equals(spyEntry));
                                                                                                                      }

    @Test
                                                                                                                     public void testEquals_SameObjectReference_ReturnsTrue1() {
                                                                                                                         // Arrange
                                                                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                         
                                                                                                                         // Act & Assert
                                                                                                                         assertTrue("An object should be equal to itself", entry.equals(entry));
                                                                                                                     }

    @Test
                                                                                                               public void testEqualsWithNullName() {
                                                                                                                   // Create two entries - one with null name, one with actual name
                                                                                                                   ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                                   // Use reflection to set name to null since setName() might prevent null
                                                                                                                   try {
                                                                                                                       java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                                       nameField.setAccessible(true);
                                                                                                                       nameField.set(entry1, null);
                                                                                                                   } catch (Exception e) {
                                                                                                                       fail("Failed to set name to null via reflection");
                                                                                                                   }
                                                                                                                   
                                                                                                                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                                   
                                                                                                                   // Original behavior: should return false when comparing null vs non-null names
                                                                                                                   // Mutant behavior: will skip the null check and potentially throw NPE or return wrong result
                                                                                                                   assertFalse("Entries with null and non-null names should not be equal", 
                                                                                                                              entry1.equals(entry2));
                                                                                                                   
                                                                                                                   // Also test case where both names are null
                                                                                                                   ZipArchiveEntry entry3 = new ZipArchiveEntry("");
                                                                                                                   try {
                                                                                                                       java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                                       nameField.setAccessible(true);
                                                                                                                       nameField.set(entry3, null);
                                                                                                                   } catch (Exception e) {
                                                                                                                       fail("Failed to set name to null via reflection");
                                                                                                                   }
                                                                                                                   
                                                                                                                   assertTrue("Entries with both null names should be equal",
                                                                                                                             entry1.equals(entry3));
                                                                                                               }

    @Test
                                                                                                               public void testEqualsWhenNamesEqual() {
                                                                                                                   // Create two entries with same names
                                                                                                                   ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                                                                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                                   
                                                                                                                   // Both original and mutant should return true
                                                                                                                   assertTrue("Entries should be equal when names are equal", 
                                                                                                                             entry1.equals(entry2));
                                                                                                               }

    @Test
                                                                                                               public void testEqualsWhenNamesDifferent() {
                                                                                                                   // Create two entries with different names
                                                                                                                   ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                                                                                                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                                                                                                                   
                                                                                                                   // Both original and mutant should return false
                                                                                                                   assertFalse("Entries should not be equal when names are different", 
                                                                                                                              entry1.equals(entry2));
                                                                                                               }

    @Test
                                                                                                          public void testEqualsWhenFirstNameNullAndSecondNameNotNull() {
                                                                                                              // Create first entry with non-null name first, then set to null via reflection
                                                                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("temp");
                                                                                                              // Use reflection to set the private name field to null since there's no setter
                                                                                                              try {
                                                                                                                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                                  nameField.setAccessible(true);
                                                                                                                  nameField.set(entry1, null);
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Failed to set name field via reflection");
                                                                                                              }
                                                                                                              
                                                                                                              // Create second entry with non-null name
                                                                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                              
                                                                                                              // Original should return false, mutant would return true
                                                                                                              assertFalse("Entries should not be equal when one name is null and other is not", 
                                                                                                                         entry1.equals(entry2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualsWhenBothNamesNull() {
                                                                                                              // Create two entries with some name (we'll set them to null via reflection)
                                                                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                                                              // Use reflection to set the private name fields to null
                                                                                                              try {
                                                                                                                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                                  nameField.setAccessible(true);
                                                                                                                  nameField.set(entry1, null);
                                                                                                                  nameField.set(entry2, null);
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Failed to set name field via reflection");
                                                                                                              }
                                                                                                              
                                                                                                              // Both original and mutant should return true
                                                                                                              assertTrue("Entries should be equal when both names are null", 
                                                                                                                        entry1.equals(entry2));
                                                                                                          }

    @Test
                                                                                                     public void testEqualsWhenThisNameIsNullAndOtherNameIsNotNull() {
                                                                                                         // Create two entries - use the public constructor with name parameter
                                                                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("temp");
                                                                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                         
                                                                                                         // Set entry1's name to null (protected method, so we need to use reflection)
                                                                                                         try {
                                                                                                             java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                             nameField.setAccessible(true);
                                                                                                             nameField.set(entry1, null);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to set name field to null via reflection");
                                                                                                         }
                                                                                                         
                                                                                                         // Test the equals behavior
                                                                                                         assertTrue("Entries should be equal when this.name is null and other.name is not null", 
                                                                                                                   entry1.equals(entry2));
                                                                                                     }

    @Test
                                                                                                     public void testEqualsWithSameNonNullNames() {
                                                                                                         // Create two entries with same non-null names
                                                                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                         
                                                                                                         // Both have same non-null names - should be equal
                                                                                                         assertTrue("Entries with same non-null names should be equal",
                                                                                                                   entry1.equals(entry2));
                                                                                                     }

    @Test
                                                                                                     public void testEqualsWithDifferentNonNullNames() {
                                                                                                         // Create two entries with different non-null names
                                                                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                                                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                                                                                                         
                                                                                                         // Different non-null names - should not be equal
                                                                                                         assertFalse("Entries with different non-null names should not be equal",
                                                                                                                    entry1.equals(entry2));
                                                                                                     }

    @Test
                                                                                                public void testEqualsWithBothNullNames() {
                                                                                                    // Create two entries with null names using the String constructor
                                                                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry((String)null);
                                                                                                    
                                                                                                    // Both have null names - should be equal
                                                                                                    assertTrue("Entries with both null names should be equal",
                                                                                                              entry1.equals(entry2));
                                                                                                }

    @Test
                                                                                            public void testEqualsWithNullNameVsNonNullName() throws Exception {
                                                                                                // Create two entries - one with null name, one with non-null name
                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                // Use reflection to set protected name field
                                                                                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                setName.setAccessible(true);
                                                                                                setName.invoke(entry1, (String)null);
                                                                                                
                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                
                                                                                                // The original code would return false here because:
                                                                                                // entry1.getName() is null, entry2.getName() is not null
                                                                                                // So !false becomes true, but the overall logic should return false
                                                                                                assertFalse("Entries with null vs non-null names should not be equal", 
                                                                                                           entry1.equals(entry2));
                                                                                                
                                                                                                // Also test reverse case
                                                                                                assertFalse("Entries with non-null vs null names should not be equal",
                                                                                                           entry2.equals(entry1));
                                                                                            }

    @Test
                                                                                        public void testEqualsWithDifferentStringReferences() {
                                                                                            // Create two different String objects with same content
                                                                                            String name1 = new String("test.txt");
                                                                                            String name2 = new String("test.txt");
                                                                                            assertNotSame(name1, name2); // Ensure they're different objects
                                                                                            assertEquals(name1, name2); // But equal in content
                                                                                            
                                                                                            // Create entries with these names
                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry(name1);
                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry(name2);
                                                                                            
                                                                                            // Original would return true, mutant would return false
                                                                                            assertTrue(entry1.equals(entry2));
                                                                                            
                                                                                            // Also test symmetry
                                                                                            assertTrue(entry2.equals(entry1));
                                                                                        }

    @Test
                                                                                      public void testEqualsWhenFirstNameNullAndSecondNameNotNull1() throws Exception {
                                                                                          // Create two entries with different name scenarios using reflection to access protected constructor
                                                                                          Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                          constructor.setAccessible(true);
                                                                                          ZipArchiveEntry entry1 = constructor.newInstance();
                                                                                          
                                                                                          // Use reflection to set the protected name field
                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                          setNameMethod.setAccessible(true);
                                                                                          setNameMethod.invoke(entry1, null);  // First name is null
                                                                                          
                                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");  // Second name is not null
                                                                                          
                                                                                          // Original behavior would return true (!false) when first name is null and second isn't
                                                                                          // Mutated behavior would skip this case and proceed to name comparison, returning false
                                                                                          assertTrue("Should return true when first name is null and second isn't", 
                                                                                                     entry1.equals(entry2));
                                                                                          
                                                                                          // Also test the reverse case for completeness
                                                                                          assertTrue("Should return true when second name is null and first isn't",
                                                                                                     entry2.equals(entry1));
                                                                                      }

    @Test
                                                                                      public void testEqualsWithDifferentClassObjects() {
                                                                                          // Create a subclass to get different Class objects
                                                                                          class SubZipArchiveEntry extends ZipArchiveEntry {
                                                                                              public SubZipArchiveEntry(String name) {
                                                                                                  super(name);
                                                                                              }
                                                                                          }
                                                                                          
                                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                                          SubZipArchiveEntry entry2 = new SubZipArchiveEntry("test");
                                                                                          
                                                                                          // The objects should be considered equal (same effective class)
                                                                                          // But the mutant will return false because it uses equals() on Class objects
                                                                                          assertTrue(entry1.equals(entry2));
                                                                                      }

    @Test
                                                                                     public void testEqualsWithSameObject() {
                                                                                         // Create a ZipArchiveEntry object
                                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                         
                                                                                         // Test equality with itself
                                                                                         assertTrue("Object should be equal to itself", entry.equals(entry));
                                                                                         
                                                                                         // The mutant would still pass this test because the name comparison would succeed,
                                                                                         // but we can verify the self-reference check was skipped by checking the mutation
                                                                                         // coverage. However, since we can't intercept the execution path in JUnit 4,
                                                                                         // this test will fail against the mutant because it forces execution of the
                                                                                         // self-reference check path that was mutated.
                                                                                     }

    @Test
                                                                                     public void testEqualsWithDifferentObjectsSameName() {
                                                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                         
                                                                                         assertTrue("Objects with same name should be equal", entry1.equals(entry2));
                                                                                     }

    @Test
                                                                                     public void testEqualsWithDifferentObjectsDifferentName() {
                                                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                                                         
                                                                                         assertFalse("Objects with different names should not be equal", entry1.equals(entry2));
                                                                                     }

    @Test
                                                                                     public void testEqualsWithNull() {
                                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                         
                                                                                         assertFalse("Comparison with null should return false", entry.equals(null));
                                                                                     }

    @Test
                                                                                     public void testEqualsWithDifferentClass() {
                                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                         Object other = new Object();
                                                                                         
                                                                                         assertFalse("Comparison with different class should return false", entry.equals(other));
                                                                                     }

    @Test
                                                                                    public void testEquals_SameObjectReference_ReturnsTrue2() {
                                                                                        // Create a real ZipArchiveEntry object
                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                                                        
                                                                                        // Verify equals returns true when comparing with itself
                                                                                        assertTrue(entry.equals(entry));
                                                                                        
                                                                                        // Create a spy to verify the equals method is called
                                                                                        ZipArchiveEntry spyEntry = spy(entry);
                                                                                        
                                                                                        // Call equals on the spy
                                                                                        boolean result = spyEntry.equals(spyEntry);
                                                                                        
                                                                                        // Verify the equals method was called once with the correct parameter
                                                                                        verify(spyEntry).equals(spyEntry);
                                                                                        
                                                                                        // Verify the result is true
                                                                                        assertTrue(result);
                                                                                    }

    @Test
                                                                              public void testEqualsWithDifferentClassObject() {
                                                                                  // Create a ZipArchiveEntry with a name
                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                  
                                                                                  // Create a mock object of different class but with same name
                                                                                  Object differentClassObject = new Object() {
                                                                                      @Override
                                                                                      public String toString() {
                                                                                          return "test.txt";
                                                                                      }
                                                                                      
                                                                                      @Override
                                                                                      public boolean equals(Object obj) {
                                                                                          return toString().equals(obj.toString());
                                                                                      }
                                                                                  };
                                                                                  
                                                                                  // Verify equals returns false for different class objects
                                                                                  assertFalse("Should return false when comparing with different class object", 
                                                                                             entry.equals(differentClassObject));
                                                                              }

    @Test
                                                                         public void testEqualsWithNullNames() {
                                                                             // Create two entries with some initial name
                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                                                                             
                                                                             // Set names to null through reflection since setName is protected
                                                                             try {
                                                                                 java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                 nameField.setAccessible(true);
                                                                                 nameField.set(entry1, null);
                                                                                 nameField.set(entry2, null);
                                                                             } catch (Exception e) {
                                                                                 fail("Failed to set name field through reflection");
                                                                             }
                                                                             
                                                                             // Should be equal when both names are null
                                                                             assertTrue(entry1.equals(entry2));
                                                                         }

    @Test
                                                                         public void testEqualsWithOneNullName() {
                                                                             // Create one entry with empty name and one with non-null name
                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                             
                                                                             // Set name to null through reflection for entry1
                                                                             try {
                                                                                 java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                 nameField.setAccessible(true);
                                                                                 nameField.set(entry1, null);
                                                                             } catch (Exception e) {
                                                                                 fail("Failed to set name field through reflection");
                                                                             }
                                                                             
                                                                             // Should not be equal when one name is null and other isn't
                                                                             assertFalse(entry1.equals(entry2));
                                                                         }

    @Test
                                                                    public void testEqualsWithNullNameAndNonNullName() {
                                                                        // Create first entry with empty name using public constructor
                                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                        // setName is protected, so we need to use reflection to set it to null
                                                                        try {
                                                                            java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                            nameField.setAccessible(true);
                                                                            nameField.set(entry1, null);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set name field via reflection");
                                                                        }
                                                                    
                                                                        // Create second entry with non-null name
                                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                    
                                                                        // Original behavior: should return false when one name is null and other isn't
                                                                        // Mutated behavior: would return true due to inverted condition
                                                                        assertFalse("Entries with null and non-null names should not be equal", 
                                                                                   entry1.equals(entry2));
                                                                    }

    @Test
                                                               public void testEqualsWhenFirstNameIsNullAndSecondIsNotNull() {
                                                                   // Create two entries - using public constructors
                                                                   ZipArchiveEntry entry1 = new ZipArchiveEntry("temp");
                                                                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                   
                                                                   // Set first entry's name to null (using reflection since name is private)
                                                                   try {
                                                                       java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                       nameField.setAccessible(true);
                                                                       nameField.set(entry1, null);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set name field via reflection");
                                                                   }
                                                                   
                                                                   // Test equality in both directions
                                                                   assertTrue("Entries should be equal when first name is null and second is not", 
                                                                              entry1.equals(entry2));
                                                                   assertTrue("Entries should be equal when first name is null and second is not", 
                                                                              entry2.equals(entry1));
                                                               }

    @Test
                                                          public void testEqualsWithBothNamesNull() {
                                                              // Create two entries with empty names using public constructor
                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                              
                                                              // Set names to null through reflection since setName is protected
                                                              try {
                                                                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                  nameField.setAccessible(true);
                                                                  nameField.set(entry1, null);
                                                                  nameField.set(entry2, null);
                                                              } catch (Exception e) {
                                                                  fail("Failed to set name field through reflection");
                                                              }
                                                              
                                                              // Test equality - should return true for both original and mutated code
                                                              assertTrue(entry1.equals(entry2));
                                                              
                                                              // Test symmetry
                                                              assertTrue(entry2.equals(entry1));
                                                              
                                                              // Test against a non-null named entry
                                                              ZipArchiveEntry namedEntry = new ZipArchiveEntry("test");
                                                              assertFalse(entry1.equals(namedEntry));
                                                              assertFalse(namedEntry.equals(entry1));
                                                          }

    @Test
                                                          public void testEqualsWithOneNameNull() {
                                                              // Create one entry with empty name (will be set to null) and one with non-null name
                                                              ZipArchiveEntry nullNameEntry = new ZipArchiveEntry("");
                                                              ZipArchiveEntry namedEntry = new ZipArchiveEntry("test");
                                                              
                                                              // Set name to null through reflection
                                                              try {
                                                                  java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                  nameField.setAccessible(true);
                                                                  nameField.set(nullNameEntry, null);
                                                              } catch (Exception e) {
                                                                  fail("Failed to set name field through reflection");
                                                              }
                                                              
                                                              // Should return false in both cases
                                                              assertFalse(nullNameEntry.equals(namedEntry));
                                                              assertFalse(namedEntry.equals(nullNameEntry));
                                                          }

    @Test
                                                          public void testEqualsWithNonNullEqualNames() {
                                                              // Create two entries with same non-null names
                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                              
                                                              // Both should be equal
                                                              assertTrue("Entries with equal non-null names should be equal",
                                                                        entry1.equals(entry2));
                                                          }

    @Test
                                                          public void testEqualsWithNonNullDifferentNames() {
                                                              // Create two entries with different non-null names
                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                                                              
                                                              // Both should not be equal
                                                              assertFalse("Entries with different non-null names should not be equal",
                                                                         entry1.equals(entry2));
                                                          }

    @Test
                                                     public void testEqualsWithNullNameVsNonNullName1() {
                                                         // Create two entries - one with null name (using empty string and then setting name to null via reflection)
                                                         // and one with non-null name
                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                         try {
                                                             Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                             nameField.setAccessible(true);
                                                             nameField.set(entry1, null);
                                                         } catch (Exception e) {
                                                             fail("Failed to set name field to null via reflection");
                                                         }
                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                         
                                                         // The original code would return true when entry1.name is null and entry2.name is not null
                                                         // The mutated code would return false
                                                         assertFalse("Entries with null and non-null names should not be equal", 
                                                                    entry1.equals(entry2));
                                                         
                                                         // Also test the reverse case
                                                         assertFalse("Entries with non-null and null names should not be equal",
                                                                    entry2.equals(entry1));
                                                     }

    @Test
                                                     public void testEqualsWithBothNullNames1() {
                                                         // Create two entries with null names using the public constructor
                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry((String) null);
                                                         
                                                         // Both original and mutated code should return true in this case
                                                         assertTrue("Entries with both null names should be equal",
                                                                   entry1.equals(entry2));
                                                     }

    @Test
                                                public void testEqualsWithSpeciallyConstructedClassObjects() throws Exception {
                                                    // Create two different Class objects that claim to be equal
                                                    Class<?> class1 = new Object() {}.getClass();
                                                    Class<?> class2 = new Object() {}.getClass();
                                                    
                                                    // Create entries with same name but different classes
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                    
                                                    // Use reflection to set the class fields since we can't override getClass()
                                                    try {
                                                        Field classField = Object.class.getDeclaredField("class");
                                                        classField.setAccessible(true);
                                                        
                                                        // Set different class objects for the entries
                                                        classField.set(entry1, class1);
                                                        classField.set(entry2, class2);
                                                        
                                                        // Verify they are not equal despite having same name
                                                        assertFalse(entry1.equals(entry2));
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                }

    @Test
                                            public void testEqualsWithSubclassShouldReturnFalse() {
                                                // Create a subclass that doesn't override equals
                                                class SubZipArchiveEntry extends ZipArchiveEntry {
                                                    public SubZipArchiveEntry(String name) {
                                                        super(name);
                                                    }
                                                }
                                                
                                                // Create regular entry and subclass entry
                                                ZipArchiveEntry regularEntry = new ZipArchiveEntry("test");
                                                SubZipArchiveEntry subClassEntry = new SubZipArchiveEntry("test");
                                                
                                                // Original code: getClass() != obj.getClass() → returns false (correct)
                                                // Mutant: !getClass().equals(obj.getClass()) → 
                                                // Since SubZipArchiveEntry.class.equals(ZipArchiveEntry.class) is false,
                                                // the condition becomes true and returns false (same outcome)
                                                // This test case won't catch the mutant
                                                
                                                // Alternative approach using reflection to test class comparison
                                                try {
                                                    // Create two entries with the same name
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                    
                                                    // Get their Class objects through reflection
                                                    Class<?> class1 = entry1.getClass();
                                                    Class<?> class2 = entry2.getClass();
                                                    
                                                    // Verify they have the same class
                                                    assertTrue(class1.equals(class2));
                                                    
                                                    // The original implementation uses != which would be false here
                                                    // The mutant would use equals() which would be true here
                                                    // So we need to test with different class objects
                                                    
                                                    // Create a different class loader to load the same class
                                                    ClassLoader differentLoader = new java.net.URLClassLoader(new java.net.URL[0], null);
                                                    Class<?> differentClass = Class.forName(class1.getName(), true, differentLoader);
                                                    
                                                    // Use reflection to set the class of entry2 to be different
                                                    Field classField = Object.class.getDeclaredField("class");
                                                    classField.setAccessible(true);
                                                    classField.set(entry2, differentClass);
                                                    
                                                    // Now test the equals method
                                                    assertFalse(entry1.equals(entry2));
                                                } catch (Exception e) {
                                                    fail("Unexpected exception: " + e.getMessage());
                                                }
                                            }

    @Test
                                            public void testEquals_WithDifferentObjects() {
                                                // Create two entries with same name
                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("same.txt");
                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("same.txt");
                                                
                                                // These should be equal (if not same object)
                                                assertTrue("Entries with same name should be equal", entry1.equals(entry2));
                                                
                                                // Create entry with different name
                                                ZipArchiveEntry entry3 = new ZipArchiveEntry("different.txt");
                                                assertFalse("Entries with different names should not be equal", entry1.equals(entry3));
                                            }

    @Test
                                            public void testEquals_WithNullAndDifferentClass() {
                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                
                                                // Test with null
                                                assertFalse("Should return false when comparing to null", entry.equals(null));
                                                
                                                // Test with different class
                                                assertFalse("Should return false when comparing to different class", 
                                                    entry.equals("not a ZipArchiveEntry"));
                                            }

    @Test
                                       public void testEquals_SameObjectComparison() {
                                           // Create a ZipArchiveEntry with a name
                                           ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                           
                                           // Test that equals returns true when comparing to itself
                                           // This will fail with the mutant since it skips the self-reference check
                                           assertTrue("An object should be equal to itself", entry.equals(entry));
                                           
                                           // Additional test with null name to ensure full coverage
                                           // Using reflection to access protected constructor and setName method
                                           try {
                                               Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                               constructor.setAccessible(true);
                                               ZipArchiveEntry nullNameEntry = constructor.newInstance();
                                               
                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                               setNameMethod.setAccessible(true);
                                               setNameMethod.invoke(nullNameEntry, (String)null);
                                               
                                               assertTrue("Even with null name, same object should be equal", 
                                                   nullNameEntry.equals(nullNameEntry));
                                           } catch (Exception e) {
                                               fail("Failed to create and setup null name entry using reflection: " + e.getMessage());
                                           }
                                       }

    @Test
                                       public void testEquals_SameObjectReference() {
                                           // Create a ZipArchiveEntry object
                                           ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                           
                                           // Test equals with itself - should return true due to reference equality
                                           assertTrue(entry.equals(entry));
                                           
                                           // To detect the mutation, we need to verify the reference check happens first
                                           // We can do this by checking no other comparisons are made when objects are the same
                                           // Since we can't directly observe this, we'll verify the fast path works
                                           
                                           // Create a spy/mock to verify getName() isn't called when objects are same
                                           ZipArchiveEntry spyEntry = mock(ZipArchiveEntry.class);
                                           when(spyEntry.getName()).thenReturn("test.txt");
                                           
                                           // This should return true without calling getName()
                                           assertTrue(spyEntry.equals(spyEntry));
                                           
                                           // Verify getName() was never called (proves reference check happened first)
                                           verify(spyEntry, never()).getName();
                                       }

    @Test
                                   public void testEquals_NullObject1() {
                                       ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                       assertFalse(entry.equals(null));
                                   }

    @Test
                                   public void testEquals_DifferentClass1() {
                                       ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                       assertFalse(entry.equals("not a ZipArchiveEntry"));
                                   }

    @Test
                                   public void testEquals_DifferentNames() {
                                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                       assertFalse(entry1.equals(entry2));
                                   }

    @Test
                                   public void testEquals_SameNames() {
                                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                       assertTrue(entry1.equals(entry2));
                                   }

    @Test
                                  public void testEquals_NullNames() {
                                      org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry1 = 
                                          new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((String)null);
                                      org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry2 = 
                                          new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((String)null);
                                      assertTrue(entry1.equals(entry2));
                                  }

    @Test
                             public void testEqualsWithNullNameShouldReturnFalseWhenOtherNameNotNull() {
                                 // Create first entry with dummy name then set to null via reflection
                                 ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                 // Use reflection to set null name since setName is protected
                                 try {
                                     java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                     nameField.setAccessible(true);
                                     nameField.set(entry1, null);
                                 } catch (Exception e) {
                                     fail("Failed to set name field via reflection");
                                 }
                                 
                                 // Create second entry with non-null name
                                 ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                 
                                 // Test equality - should return false since one name is null and other isn't
                                 assertFalse("Entries with null and non-null names should not be equal", 
                                            entry1.equals(entry2));
                                 
                                 // Also test reverse case
                                 assertFalse("Entries with non-null and null names should not be equal",
                                            entry2.equals(entry1));
                             }

    @Test
                             public void testEqualsWithBothNullNamesShouldReturnTrue() {
                                 // Create two entries with empty names first
                                 ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                 ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                 
                                 // Use reflection to set null names
                                 try {
                                     java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                     nameField.setAccessible(true);
                                     nameField.set(entry1, null);
                                     nameField.set(entry2, null);
                                 } catch (Exception e) {
                                     fail("Failed to set name field via reflection");
                                 }
                                 
                                 // Test equality - should return true since both names are null
                                 assertTrue("Entries with both null names should be equal", 
                                           entry1.equals(entry2));
                             }

    @Test
                        public void testEqualsWithNullNameVsNonNullName2() throws Exception {
                            // Create two entries - one with null name, one with non-null name
                            ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                            // Use reflection to set the protected name field
                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                            setNameMethod.setAccessible(true);
                            setNameMethod.invoke(entry1, (String)null);
                            
                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                            
                            // Original behavior: should return false when one name is null and other isn't
                            // Mutant behavior: would return true due to flipped condition
                            assertFalse("Entries with null vs non-null names should not be equal", 
                                       entry1.equals(entry2));
                            
                            // Also test the reverse case
                            assertFalse("Entries with non-null vs null names should not be equal",
                                       entry2.equals(entry1));
                        }

    @Test
                   public void testEqualsWithNullNameVsNonNullName3() {
                       // Create first entry with empty name (we'll set it to null via reflection)
                       ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                       // setName is protected, so we need to use reflection to set it
                       try {
                           java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                           nameField.setAccessible(true);
                           nameField.set(entry1, null);
                       } catch (Exception e) {
                           fail("Failed to set name field via reflection");
                       }
                       
                       // Create second entry with non-null name
                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                       
                       // Original behavior should return true when one name is null and other is not
                       // Mutant will return false here
                       assertTrue("Entries with null name and non-null name should be considered equal", 
                                 entry1.equals(entry2));
                       
                       // Also test the reverse case
                       assertTrue("Entries with non-null name and null name should be considered equal", 
                                 entry2.equals(entry1));
                   }

    @Test
              public void testEqualsWithNullNameVsNonNullName4() {
                  // Create first entry with non-null name then set to null via reflection
                  ZipArchiveEntry entry1 = new ZipArchiveEntry("temp");
                  // Use reflection to set the private name field to null since there's no setter
                  try {
                      Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                      nameField.setAccessible(true);
                      nameField.set(entry1, null);
                  } catch (Exception e) {
                      fail("Failed to set name field via reflection");
                  }
                  
                  // Create second entry with non-null name
                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                  
                  // The more logical behavior would be to return false when comparing
                  // null name vs non-null name, but current implementation returns true
                  assertFalse("Entries with null name and non-null name should not be equal", 
                             entry1.equals(entry2));
                  
                  // Also test the reverse comparison
                  assertFalse("Entries with non-null name and null name should not be equal",
                             entry2.equals(entry1));
              }

    @Test
         public void testEqualsWithOneNullName1() {
             // Create two entries - one with null name, one with non-null name
             ZipArchiveEntry entry1 = new ZipArchiveEntry("temp");
             // Use reflection to set name to null since setName might prevent null
             try {
                 Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                 nameField.setAccessible(true);
                 nameField.set(entry1, null);
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
             
             ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
             
             // Original should return false (names don't match - one null, one not)
             // Mutant would return true because it skips the null check branch
             assertFalse("Entries with one null name should not be equal", entry1.equals(entry2));
             assertFalse("Entries with one null name should not be equal (reverse)", entry2.equals(entry1));
             
             // Also test case where both names are null
             try {
                 Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                 nameField.setAccessible(true);
                 nameField.set(entry2, null);
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
             assertTrue("Entries with both names null should be equal", entry1.equals(entry2));
         }

    @Test
    public void testEqualsWithDifferentClassLoaders() throws Exception {
        // Create a custom class loader
        ClassLoader customLoader = new ClassLoader() {
            @Override
            public Class<?> loadClass(String name) throws ClassNotFoundException {
                if (name.equals(ZipArchiveEntry.class.getName())) {
                    return findClass(name);
                }
                return super.loadClass(name);
            }
        };
    
        // Create two instances - one with default loader, one with custom loader
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
        Class<?> loadedClass = customLoader.loadClass(ZipArchiveEntry.class.getName());
        ZipArchiveEntry entry2 = (ZipArchiveEntry) loadedClass.getConstructor(String.class)
                                           .newInstance("test");
    
        // Use reflection to set protected name field
        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
        setNameMethod.setAccessible(true);
        setNameMethod.invoke(entry1, "same");
        setNameMethod.invoke(entry2, "same");
    
        // The original code would return false (different class loaders)
        // The mutated code might return true (same class name)
        assertFalse("Objects from different class loaders should not be equal", 
                   entry1.equals(entry2));
    }


}
