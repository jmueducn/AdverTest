package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteOrder;
 
public class BitInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                      public void testReadBits_ThrowsIllegalArgumentExceptionForNegativeCount() throws Exception {
                                                                          InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                          BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          try {
                                                                              bis.readBits(-1);
                                                                              fail("Expected IllegalArgumentException");
                                                                          } catch (IllegalArgumentException e) {
                                                                              assertEquals("count must not be negative or greater than " + 63, e.getMessage());
                                                                          }
                                                                      }

 @Test
                                                                      public void testReadBits_ThrowsIllegalArgumentExceptionForCountExceedingMaximum() throws Exception {
                                                                          // Setup
                                                                          InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                          BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          // Use reflection to access private MAXIMUM_CACHE_SIZE field
                                                                          Field field = BitInputStream.class.getDeclaredField("MAXIMUM_CACHE_SIZE");
                                                                          field.setAccessible(true);
                                                                          int maxCacheSize = field.getInt(bis);
                                                                          
                                                                          // Exception verification
                                                                          ExpectedException thrown = ExpectedException.none();
                                                                          thrown.expect(IllegalArgumentException.class);
                                                                          thrown.expectMessage("count must not be negative or greater than " + maxCacheSize);
                                                                          
                                                                          // Test
                                                                          bis.readBits(maxCacheSize + 1);
                                                                      }

 @Test
                                                                      public void testReadBits_ReturnsNegativeWhenStreamEnds_BigEndian() throws Exception {
                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                          when(mockInputStream.read()).thenReturn(-1);
                                                                          BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                          assertEquals(-1, bis.readBits(8));
                                                                      }

 @Test
                                                                      public void testReadBits_ReturnsNegativeWhenStreamEnds_LittleEndian() throws Exception {
                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                          when(mockInputStream.read()).thenReturn(-1);
                                                                          BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
                                                                          assertEquals(-1, bis.readBits(8));
                                                                      }

 @Test
                                                                      public void testReadBits_ReadsSingleByte_BigEndian() throws Exception {
                                                                          byte[] data = {(byte)0xAB};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          assertEquals(0xA, bis.readBits(4));
                                                                          assertEquals(0xB, bis.readBits(4));
                                                                      }

 @Test
                                                                      public void testReadBits_ReadsSingleByte_LittleEndian() throws Exception {
                                                                          byte[] data = {(byte)0xAB};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                          
                                                                          assertEquals(0xB, bis.readBits(4));
                                                                          assertEquals(0xA, bis.readBits(4));
                                                                      }

 @Test
                                                                      public void testReadBits_ReadsMultipleBytes_BigEndian() throws Exception {
                                                                          byte[] data = {(byte)0x12, (byte)0x34, (byte)0x56};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          assertEquals(0x123, bis.readBits(12));
                                                                          assertEquals(0x456, bis.readBits(12));
                                                                      }

 @Test
                                                                      public void testReadBits_ReadsMultipleBytes_LittleEndian() throws Exception {
                                                                          byte[] data = {(byte)0x12, (byte)0x34, (byte)0x56};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                          
                                                                          assertEquals(0x412, bis.readBits(12));
                                                                          assertEquals(0x634, bis.readBits(12));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesBitCaching_BigEndian() throws Exception {
                                                                          byte[] data = {(byte)0xAA, (byte)0xBB, (byte)0xCC};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          assertEquals(0xAA, bis.readBits(8));
                                                                          assertEquals(0xB, bis.readBits(4));
                                                                          assertEquals(0xBC, bis.readBits(8));
                                                                          assertEquals(0xC, bis.readBits(4));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesBitCaching_LittleEndian() throws Exception {
                                                                          byte[] data = {(byte)0xAA, (byte)0xBB, (byte)0xCC};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                          
                                                                          assertEquals(0xAA, bis.readBits(8));
                                                                          assertEquals(0xB, bis.readBits(4));
                                                                          assertEquals(0xCA, bis.readBits(8));
                                                                          assertEquals(0xB, bis.readBits(4));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesLargeBitCount_BigEndian() throws Exception {
                                                                          byte[] data = new byte[8];
                                                                          for (int i = 0; i < 8; i++) {
                                                                              data[i] = (byte)(i + 1);
                                                                          }
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          long expected = 0x0102030405060708L;
                                                                          assertEquals(expected, bis.readBits(64));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesLargeBitCount_LittleEndian() throws Exception {
                                                                          byte[] data = new byte[8];
                                                                          for (int i = 0; i < 8; i++) {
                                                                              data[i] = (byte)(i + 1);
                                                                          }
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                          
                                                                          long expected = 0x0807060504030201L;
                                                                          assertEquals(expected, bis.readBits(64));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesOverflow_BigEndian() throws Exception {
                                                                          byte[] data = new byte[8];
                                                                          for (int i = 0; i < 8; i++) {
                                                                              data[i] = (byte)0xFF;
                                                                          }
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          // Read 56 bits first (7 bytes)
                                                                          long firstRead = bis.readBits(56);
                                                                          assertEquals(0xFFFFFFFFFFFFFFL, firstRead);
                                                                          
                                                                          // Then read remaining 8 bits (1 byte)
                                                                          assertEquals(0xFF, bis.readBits(8));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesOverflow_LittleEndian() throws Exception {
                                                                          byte[] data = new byte[8];
                                                                          for (int i = 0; i < 8; i++) {
                                                                              data[i] = (byte)0xFF;
                                                                          }
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                          
                                                                          // Read 56 bits first (7 bytes)
                                                                          long firstRead = bis.readBits(56);
                                                                          assertEquals(0xFFFFFFFFFFFFFFL, firstRead);
                                                                          
                                                                          // Then read remaining 8 bits (1 byte)
                                                                          assertEquals(0xFF, bis.readBits(8));
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesPartialByteReads_BigEndian() throws Exception {
                                                                          byte[] data = {(byte)0xAA, (byte)0xBB};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          assertEquals(0x2, bis.readBits(2));  // 10 from 0xAA
                                                                          assertEquals(0xA, bis.readBits(4));  // 1010 from 0xAA
                                                                          assertEquals(0xAB, bis.readBits(8)); // remaining 10 from 0xAA and all of 0xBB
                                                                          assertEquals(0xB, bis.readBits(4));  // last nibble
                                                                      }

 @Test
                                                                      public void testReadBits_HandlesPartialByteReads_LittleEndian() throws Exception {
                                                                          byte[] data = {(byte)0xAA, (byte)0xBB};
                                                                          InputStream input = new ByteArrayInputStream(data);
                                                                          BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                          
                                                                          assertEquals(0x2, bis.readBits(2));  // 10 from 0xAA
                                                                          assertEquals(0xA, bis.readBits(4));  // 1010 from 0xAA
                                                                          assertEquals(0xBA, bis.readBits(8)); // 0xBB and remaining 10 from 0xAA
                                                                          assertEquals(0xE, bis.readBits(4));  // last nibble (1110 from 0xBB)
                                                                      }

 @Test
                                                                 public void testReadBitsOverflowCaseDetectsAndToOrMutant() throws Exception {
                                                                     // Setup input stream with test data
                                                                     byte[] testData = {0x55, 0x55}; // Binary: 01010101 01010101
                                                                     InputStream inputStream = new ByteArrayInputStream(testData);
                                                                     
                                                                     // Create BitInputStream with little-endian order
                                                                     BitInputStream bis = new BitInputStream(inputStream, ByteOrder.LITTLE_ENDIAN);
                                                                     
                                                                     // Use reflection to access private fields
                                                                     Class<?> bisClass = bis.getClass();
                                                                     Field bitsCachedField = bisClass.getDeclaredField("bitsCached");
                                                                     bitsCachedField.setAccessible(true);
                                                                     Field bitsCachedSizeField = bisClass.getDeclaredField("bitsCachedSize");
                                                                     bitsCachedSizeField.setAccessible(true);
                                                                     
                                                                     // Set up initial cache state to force overflow case
                                                                     // We'll set bitsCached to have some 0 bits that MASKS would overwrite if OR is used
                                                                     bitsCachedField.setLong(bis, 0x00); // All bits 0
                                                                     bitsCachedSizeField.setInt(bis, 56); // Almost full cache (7 bytes)
                                                                     
                                                                     // Try to read 64 bits (8 bytes) which will trigger overflow case
                                                                     long result = bis.readBits(64);
                                                                     
                                                                     // With AND operation (correct behavior), result should be 0x5500000000000000
                                                                     // With OR operation (mutant), result would be 0x55FFFFFFFFFFFFFF
                                                                     assertEquals(0x5500000000000000L, result);
                                                                     
                                                                     // Verify the remaining cache state
                                                                     assertEquals(8, bitsCachedSizeField.getInt(bis)); // Should have 8 bits left (the overflow)
                                                                     assertEquals(0x55L, bitsCachedField.getLong(bis)); // The overflow bits should be 0x55
                                                                 }

 @Test
                                                             public void testReadBitsOverflowCaseDetectsXORMutant() throws Exception {
                                                                 // Setup input stream with specific bytes
                                                                 byte[] inputBytes = new byte[]{(byte) 0xFF, (byte) 0xF0}; // 11111111 followed by 11110000
                                                                 InputStream inputStream = new ByteArrayInputStream(inputBytes);
                                                                 BitInputStream bis = new BitInputStream(inputStream, ByteOrder.LITTLE_ENDIAN);
                                                                 
                                                                 // Set up initial cache state
                                                                 bis.readBits(8); // Read first byte to populate cache (bitsCached = 0xFF, bitsCachedSize = 8)
                                                                 
                                                                 // Request more bits than available in cache to trigger overflow path
                                                                 long result = bis.readBits(12); // Should read 4 more bits from second byte (0xF0)
                                                                 
                                                                 // Verify the result - this will catch the mutant
                                                                 // Original behavior (AND): 
                                                                 // bitsCached = 0xFF (11111111)
                                                                 // MASKS[12] = 0xFFF (lower 12 bits)
                                                                 // bitsOut = 0xFF & 0xFFF = 0xFF
                                                                 // Mutant behavior (XOR):
                                                                 // bitsOut = 0xFF ^ 0xFFF = 0xF00
                                                                 assertEquals("Should return correct bits with AND operation", 0xFFL, result);
                                                                 
                                                                 // Additional verification of cache state
                                                                 // After operation, overflow should be 0 (from 0xF0 >>> 4)
                                                                 // and bitsCachedSize should be 4 (remaining bits)
                                                                 long expectedCache = 0L;
                                                                 int expectedCacheSize = 4;
                                                                 // You might need to add getters for these fields or use reflection to verify
                                                             }

 @Test
                                                           public void testReadBitsWithOverflowDetectsMaskMutation() throws Exception {
                                                               // Setup test data - we'll request 8 bits (1 byte) to make verification easy
                                                               final int count = 8;
                                                               final long testByte = 0xAB; // 10101011 in binary
                                                               
                                                               // Mock the InputStream to return our test byte
                                                               InputStream mockIn = mock(InputStream.class);
                                                               when(mockIn.read()).thenReturn((int)testByte);
                                                               
                                                               // Create BitInputStream with our mock
                                                               BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                               
                                                               // Use reflection to set private fields
                                                               Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                               bitsCachedField.setAccessible(true);
                                                               bitsCachedField.set(bis, 0x00); // Empty cache
                                                               
                                                               Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                               bitsCachedSizeField.setAccessible(true);
                                                               bitsCachedSizeField.set(bis, 0);
                                                               
                                                               // Call method - this should go through the overflow path
                                                               long result = bis.readBits(count);
                                                               
                                                               // Verify the result matches exactly what we expect
                                                               // For count=8, we should get exactly the testByte back
                                                               assertEquals("Should return exactly the 8 bits we requested", 
                                                                            testByte, result);
                                                               
                                                               // Verify we interacted with the mock as expected
                                                               verify(mockIn).read();
                                                           }

 @Test
                                                       public void testReadBitsWithOverflowDetectsMaskMutation1() throws Exception {
                                                           // Setup - create a scenario where overflowBits != 0
                                                           // We'll request 60 bits (more than 57, triggering overflow case)
                                                           int count = 60;
                                                           
                                                           // Mock input stream to return bytes that will create a known bit pattern
                                                           InputStream mockIn = mock(InputStream.class);
                                                           when(mockIn.read())
                                                               .thenReturn(0xFF)  // first byte (all 1s)
                                                               .thenReturn(0xFF)  // second byte
                                                               .thenReturn(0xFF)  // third byte
                                                               .thenReturn(0xFF)  // fourth byte
                                                               .thenReturn(0xFF)  // fifth byte
                                                               .thenReturn(0xFF)  // sixth byte
                                                               .thenReturn(0xFF)  // seventh byte (for overflow)
                                                               .thenReturn(-1);   // then EOF
                                                           
                                                           // Create BitInputStream with big-endian order
                                                           BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                           
                                                           // Call readBits - this should mask the result to 60 bits
                                                           long result = bis.readBits(count);
                                                           
                                                           // Verify the result is properly masked to 60 bits
                                                           // The correct result should be 0x0FFFFFFFFFFFFFFFL (60 bits of 1)
                                                           // If the mutant is present, it will return more bits (all 1s from cache)
                                                           long expected = (1L << count) - 1;
                                                           assertEquals("Result should be properly masked to requested bit count", 
                                                                        expected, result);
                                                           
                                                           // Verify we only read 7 bytes (56 bits in cache + 8 bits for overflow)
                                                           verify(mockIn, times(7)).read();
                                                       }

 @Test
                                                      public void testReadBitsWithOverflowPreservesCache() throws Exception {
                                                          // Setup input stream with test data
                                                          byte[] testData = new byte[8]; // Need enough bytes to trigger overflow
                                                          for (int i = 0; i < testData.length; i++) {
                                                              testData[i] = (byte) 0xFF; // All bits set to 1
                                                          }
                                                          InputStream inputStream = new ByteArrayInputStream(testData);
                                                          BitInputStream bis = new BitInputStream(inputStream, ByteOrder.BIG_ENDIAN);
                                                          
                                                          // First read - should trigger overflow handling
                                                          long firstRead = bis.readBits(64); // Enough to trigger overflow
                                                          assertEquals(0xFFFFFFFFFFFFFFFFL, firstRead);
                                                          
                                                          // Second read - should use the overflow bits if preserved
                                                          // With original code, should get remaining bits from overflow
                                                          // With mutant (bitsCached = 0), would get 0
                                                          long secondRead = bis.readBits(8);
                                                          
                                                          // Verify the overflow bits were preserved and used
                                                          // Original code would have preserved overflow bits (0xFF)
                                                          // Mutant would zero them out, making secondRead = 0
                                                          assertEquals(0xFFL, secondRead);
                                                          
                                                          // Additional verification of internal state if possible
                                                          // (Assuming we have getters for these fields or use reflection)
                                                          try {
                                                              Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                              bitsCachedField.setAccessible(true);
                                                              long bitsCached = bitsCachedField.getLong(bis);
                                                              
                                                              Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                              bitsCachedSizeField.setAccessible(true);
                                                              int bitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                              
                                                              // With original code, bitsCached should have some value from overflow
                                                              // With mutant, it would be 0
                                                              assertNotEquals(0L, bitsCached);
                                                              assertTrue(bitsCachedSize > 0);
                                                          } catch (Exception e) {
                                                              // If reflection fails, the main assertion should still catch the mutant
                                                          }
                                                      }

 @Test
                                                     public void testReadBitsWithOverflowDetectsMutant() throws Exception {
                                                         // Setup input stream that will cause overflow (bitsCachedSize >= 57)
                                                         InputStream mockIn = mock(InputStream.class);
                                                         when(mockIn.read())
                                                             .thenReturn(0xFF)  // first byte
                                                             .thenReturn(0xFF)  // second byte
                                                             .thenReturn(0xFF)  // third byte
                                                             .thenReturn(0xFF)  // fourth byte
                                                             .thenReturn(0xFF)  // fifth byte
                                                             .thenReturn(0xFF)  // sixth byte
                                                             .thenReturn(0xFF)  // seventh byte (will cause overflow)
                                                             .thenReturn(0xAA); // eighth byte (for verification)
                                                     
                                                         BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                         
                                                         // First read: read 56 bits (7 bytes) to fill cache nearly to limit
                                                         long result = bis.readBits(56);
                                                         assertEquals(0xFFFFFFFFFFFFFFL, result);
                                                         
                                                         // Second read: read 8 more bits which should cause overflow
                                                         // The first 1 bit should come from overflow of previous read
                                                         // The remaining 7 bits should come from the new byte (0xAA)
                                                         result = bis.readBits(8);
                                                         
                                                         // With original code: 
                                                         // - overflow from first 7 bytes would be 1 bit (since we read 56 of 57 bits)
                                                         // - then read 7 bits from 0xAA
                                                         // - combined value should be (1 << 7) | (0xAA >>> 1) = 0xD5
                                                         // With mutant:
                                                         // - it would ignore the overflow bit and just read 8 bits from 0xAA
                                                         assertEquals(0xD5, result);
                                                         
                                                         verify(mockIn, times(8)).read();
                                                     }

 @Test
                                                    public void testReadBitsWithOverflowDetectsMutant1() throws Exception {
                                                        // Setup input stream with test data
                                                        byte[] testData = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, 
                                                                                    (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0x0F};
                                                        InputStream inputStream = new ByteArrayInputStream(testData);
                                                        BitInputStream bis = new BitInputStream(inputStream, ByteOrder.BIG_ENDIAN);
                                                        
                                                        // First read 56 bits to almost fill the cache (7 bytes * 8 bits)
                                                        long firstRead = bis.readBits(56);
                                                        assertEquals(0xFFFFFFFFFFFFFFL, firstRead);
                                                        
                                                        // Now read 8 more bits which will cause overflow
                                                        // The last byte is 0x0F, so overflow will be 0x0F
                                                        long secondRead = bis.readBits(8);
                                                        assertEquals(0xFFL, secondRead);  // This verifies the main read
                                                        
                                                        // The key test: read again to verify overflow handling
                                                        // With the mutant (overflow + 1), this would read 0x10 instead of 0x0F
                                                        long thirdRead = bis.readBits(4);
                                                        assertEquals(0x0FL, thirdRead);  // This will fail with the mutant
                                                        
                                                        inputStream.close();
                                                    }

 @Test
                                                   public void testReadBitsWithOverflowMaintainsCacheSize() throws Exception {
                                                       // Setup - create a stream that will provide enough bytes to cause overflow
                                                       InputStream mockInput = mock(InputStream.class);
                                                       when(mockInput.read())
                                                           .thenReturn(0xFF)  // first byte
                                                           .thenReturn(0xFF)  // second byte
                                                           .thenReturn(0xFF)  // third byte
                                                           .thenReturn(0xFF)  // fourth byte
                                                           .thenReturn(0xFF)  // fifth byte
                                                           .thenReturn(0xFF)  // sixth byte
                                                           .thenReturn(0xFF)  // seventh byte
                                                           .thenReturn(0xFF)  // eighth byte (will cause overflow)
                                                           .thenReturn(0x0F); // ninth byte (for second read)
                                                   
                                                       BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                                       
                                                       // First read - 64 bits (will cause overflow)
                                                       long firstRead = bis.readBits(64);
                                                       assertEquals(0xFFFFFFFFFFFFFFFFL, firstRead);
                                                       
                                                       // Second read - should use the overflow bits
                                                       long secondRead = bis.readBits(4);
                                                       assertEquals(0x0FL, secondRead);
                                                       
                                                       // Verify the mock interactions
                                                       verify(mockInput, times(9)).read();
                                                   }

 @Test
                                                 public void testReadBitsWithOverflowDetectsMutant2() throws Exception {
                                                     // Define bit masks for different bit lengths (up to 64 bits)
                                                     final long[] MASKS = new long[65];
                                                     for (int i = 0; i < MASKS.length; i++) {
                                                         MASKS[i] = i == 64 ? -1L : (1L << i) - 1;
                                                     }
                                                     
                                                     // Setup input that will cause overflow (bitsCachedSize >= 57)
                                                     // We'll request 60 bits (count=60) when cache has 56 bits (needs 4 more)
                                                     // This will trigger the overflow path where the mutation exists
                                                     
                                                     // Mock input stream that will return one byte (8 bits) when read
                                                     InputStream mockIn = mock(InputStream.class);
                                                     when(mockIn.read()).thenReturn(0xFF); // return byte with all 1s
                                                     
                                                     // Create BitInputStream with little-endian order
                                                     BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                     
                                                     // Set up initial cache state: 56 bits cached (7 bytes)
                                                     // Using reflection to set private fields for testing
                                                     Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                     bitsCachedField.setAccessible(true);
                                                     bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set to 1
                                                     
                                                     Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                     bitsCachedSizeField.setAccessible(true);
                                                     bitsCachedSizeField.set(bis, 56);
                                                     
                                                     // Call readBits(60) - this should trigger overflow path
                                                     long result = bis.readBits(60);
                                                     
                                                     // Verify the result is correct (should be first 60 bits, but we only have 56+8=64)
                                                     // For little-endian, first 56 bits are in cache, next 4 from new byte
                                                     assertEquals(0xFFFFFFFFFFFFFFFL & MASKS[60], result);
                                                     
                                                     // Now verify the mutant would be caught by checking bitsCachedSize
                                                     // Original: bitsCachedSize should be overflowBits = 8 - (60-56) = 4
                                                     // Mutant: would set bitsCachedSize to count (60)
                                                     int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                     assertEquals(4, actualBitsCachedSize); // This would fail with the mutant
                                                     
                                                     // Also verify remaining bits in cache (overflow)
                                                     long actualBitsCached = bitsCachedField.getLong(bis);
                                                     assertEquals(0xFL, actualBitsCached); // Last 4 bits of 0xFF
                                                 }

 @Test
                                             public void testReadBitsWithOverflowDetectsMutant3() throws Exception {
                                                 // Setup - create a mock input stream that will provide 8 bytes (64 bits)
                                                 InputStream mockIn = mock(InputStream.class);
                                                 when(mockIn.read())
                                                     .thenReturn(0xFF)  // first byte (all 1s)
                                                     .thenReturn(0xFF)  // second byte
                                                     .thenReturn(0xFF)  // third byte
                                                     .thenReturn(0xFF)  // fourth byte
                                                     .thenReturn(0xFF)  // fifth byte
                                                     .thenReturn(0xFF)  // sixth byte
                                                     .thenReturn(0xFF)  // seventh byte
                                                     .thenReturn(0x0F); // eighth byte (only lower 4 bits set)
                                             
                                                 BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                 
                                                 // First read 60 bits - this will trigger the overflow path
                                                 long result = bis.readBits(60);
                                                 assertEquals(0xFFFFFFFFFFFFFFFL, result); // Verify first 60 bits read correctly
                                                 
                                                 // Now read remaining 4 bits - this is where the mutant would fail
                                                 // With the mutation, bitsCachedSize would be 5 instead of 4
                                                 result = bis.readBits(4);
                                                 assertEquals(0x0F, result); // Should get the last 4 bits (0x0F)
                                                 
                                                 // Verify no more bits are available
                                                 result = bis.readBits(1);
                                                 assertEquals(-1, result); // Should be EOF now
                                             }

 @Test
                                            public void testReadBitsOverflowCaseDetectsAndOrMutation() throws Exception {
                                                // Setup input stream to provide specific bytes
                                                byte[] inputBytes = new byte[]{(byte)0x55, (byte)0xAA}; // 01010101 10101010
                                                InputStream inputStream = new ByteArrayInputStream(inputBytes);
                                                
                                                // Create BitInputStream with little-endian order
                                                BitInputStream bis = new BitInputStream(inputStream, ByteOrder.LITTLE_ENDIAN);
                                                
                                                // First read some bits to set up the cache
                                                bis.readBits(8); // Reads first byte (0x55)
                                                
                                                // Now read more bits to trigger overflow case
                                                // We'll request 16 bits when only 8 are cached (assuming MAXIMUM_CACHE_SIZE > 16)
                                                long result = bis.readBits(16);
                                                
                                                // Verify the result - should be 0x55 (from cache) masked with 0xFFFF
                                                // With AND operation: 0x55 & 0xFFFF = 0x55
                                                // With OR operation: 0x55 | 0xFFFF = 0xFFFF (wrong)
                                                assertEquals("Should return only the cached bits properly masked", 
                                                            0x55L, result);
                                                
                                                // Additional verification - check the remaining bits in cache
                                                // After reading 16 bits when only 8 were cached, it should have read
                                                // one more byte (0xAA) and kept the remaining 8 bits in cache
                                                // For little-endian, the overflow would be (0xAA >>> 8) = 0
                                                // So cache should now be empty
                                                // We can verify by reading more bits
                                                long nextResult = bis.readBits(8);
                                                assertEquals("Should correctly read remaining bits", 
                                                            0xAAL, nextResult);
                                            }

 @Test
                                          public void testReadBitsWithOverflowDetectsAndVsXorMutant() throws Exception {
                                              // Setup input stream to return specific bytes
                                              InputStream mockIn = mock(InputStream.class);
                                              when(mockIn.read())
                                                  .thenReturn(0xFF)  // First byte (all bits set)
                                                  .thenReturn(0xFF); // Second byte (all bits set)
                                              
                                              // Create BitInputStream with little-endian order
                                              BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                              
                                              // Get private fields via reflection
                                              Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                              bitsCachedField.setAccessible(true);
                                              Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                              bitsCachedSizeField.setAccessible(true);
                                              Field masksField = BitInputStream.class.getDeclaredField("MASKS");
                                              masksField.setAccessible(true);
                                              long[] MASKS = (long[]) masksField.get(null);
                                              
                                              // Set up initial cache state to trigger overflow path
                                              // We need bitsCachedSize < count but with bitsCached having some bits set
                                              bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // Lots of bits set
                                              bitsCachedSizeField.set(bis, 56); // Just below 57 threshold
                                              
                                              // Request more bits than in cache to trigger overflow path
                                              long result = bis.readBits(60);
                                              
                                              // Verify the result - this will catch the mutant
                                              // With AND (original): result should be lower 60 bits of bitsCached (0xFFFFFFFFFFFFFFF)
                                              // With XOR (mutant): result would be different (would flip bits where mask is 1)
                                              long expected = 0xFFFFFFFFFFFFFFFL & MASKS[60];
                                              assertEquals("Mutant not detected - XOR used instead of AND", expected, result);
                                              
                                              // Verify cache state was updated properly
                                              assertEquals(4, bitsCachedSizeField.get(bis)); // overflowBits should be 4 (60-56=4, 8-4=4)
                                          }

 @Test
                                     public void testReadBitsWithOverflowDetectsMaskMutation2() throws Exception {
                                         // Setup - create a scenario where overflowBits != 0
                                         // We need bitsCachedSize < count and bitsCachedSize >= 57
                                         // Let's set count to 60 (which is >57) and mock input stream to return bytes
                                         
                                         // Mock input stream to return a byte when read() is called
                                         InputStream mockIn = mock(InputStream.class);
                                         when(mockIn.read()).thenReturn(0xFF); // return byte with all bits set
                                         
                                         // Create BitInputStream with big-endian order (easier to calculate expected values)
                                         BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                         
                                         // Use reflection to access private fields
                                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                         bitsCachedField.setAccessible(true);
                                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                         bitsCachedSizeField.setAccessible(true);
                                         Field masksField = BitInputStream.class.getDeclaredField("MASKS");
                                         masksField.setAccessible(true);
                                         long[] masks = (long[]) masksField.get(null);
                                         
                                         // Set up initial cache state to have 56 bits (just below 57)
                                         // This will trigger the overflow path when we request 60 bits
                                         bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set (7 bytes)
                                         bitsCachedSizeField.set(bis, 56);
                                         
                                         // Call method - request 60 bits (which requires overflow handling)
                                         long result = bis.readBits(60);
                                         
                                         // Verify the result is properly masked for 60 bits
                                         // With the mutation (using MASKS[0]), result would be 0
                                         // Correct behavior should return the masked 60 bits
                                         long expected = 0xFFFFFFFFFFFFFFFL & masks[60];
                                         assertEquals("Result should be properly masked for requested bit count", 
                                                     expected, result);
                                         
                                         // Verify we read one more byte from the stream
                                         verify(mockIn).read();
                                     }

 @Test
                                 public void testReadBitsOverflowCaseDetectsMaskMutation() throws Exception {
                                     // Setup input stream to return bytes that will create an overflow scenario
                                     InputStream mockIn = mock(InputStream.class);
                                     when(mockIn.read())
                                         .thenReturn(0xFF)  // First byte (all bits set)
                                         .thenReturn(0xFF); // Second byte (all bits set)
                                     
                                     BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                     
                                     // Set up internal state to trigger overflow case
                                     // We need bitsCachedSize >= 57, so we'll request 64 bits (8 bytes)
                                     // but mock only 2 bytes to force the overflow case
                                     long result = bis.readBits(64);
                                     
                                     // The mutation would return all bits (0xFFFFFFFFFFFFFFFF) 
                                     // instead of masked value (0xFFFF for 16 bits)
                                     // Since we only read 2 bytes (16 bits), the maximum possible value is 0xFFFF
                                     assertTrue("Returned value should be <= 0xFFFF", result <= 0xFFFFL);
                                     
                                     // More precise assertion - since we read two 0xFF bytes in big-endian,
                                     // the expected value should be 0xFFFF
                                     assertEquals("Should return exactly 16 bits", 0xFFFFL, result);
                                 }

 @Test
                                public void testReadBitsWithOverflowPreservesCache1() throws Exception {
                                    // Setup input stream to return specific bytes
                                    InputStream mockIn = mock(InputStream.class);
                                    when(mockIn.read())
                                        .thenReturn(0xFF)  // First byte (all bits set)
                                        .thenReturn(0xFF); // Second byte (all bits set)
                                    
                                    BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                    
                                    // First read: trigger overflow condition (read 64 bits when we have less than that)
                                    long result1 = bis.readBits(64);
                                    
                                    // Verify first read result (should get all bits from first byte)
                                    assertEquals(0xFFL, result1);
                                    
                                    // Second read: should get the overflow bits from previous read
                                    long result2 = bis.readBits(8);
                                    
                                    // Verify second read result - this will fail with the mutant
                                    // Original code would return 0xFF (overflow bits preserved)
                                    // Mutant would return 0 (because cache was zeroed)
                                    assertEquals(0xFFL, result2);
                                    
                                    // Verify the cache was properly maintained
                                    // This is implementation-specific but could be checked via reflection if needed
                                }

 @Test
                               public void testReadBitsWithOverflowDetectsMutant4() throws Exception {
                                   // Setup input stream that will return 8 bytes (64 bits)
                                   byte[] inputBytes = new byte[]{
                                       (byte)0xAA, (byte)0xBB, (byte)0xCC, (byte)0xDD,
                                       (byte)0xEE, (byte)0xFF, (byte)0x11, (byte)0x22
                                   };
                                   InputStream inputStream = new ByteArrayInputStream(inputBytes);
                                   BitInputStream bis = new BitInputStream(inputStream, ByteOrder.LITTLE_ENDIAN);
                                   
                                   // First read: 57 bits (will trigger overflow handling)
                                   long firstRead = bis.readBits(57);
                                   
                                   // Second read: 7 bits (should use the overflow bits from first read)
                                   long secondRead = bis.readBits(7);
                                   
                                   // Verify second read - with the mutation, this would be incorrect
                                   // The overflow bits from first read should be 0x22 >>> (64-57) = 0x11
                                   // So reading 7 bits should give us 0x11 & 0x7F = 0x11
                                   assertEquals(0x11, secondRead);
                                   
                                   // Verify cache state - with mutation, bitsCached would still contain old value
                                   // We can verify by reading one more bit
                                   long thirdRead = bis.readBits(1);
                                   // Should be next bit (0) from the overflow
                                   assertEquals(0, thirdRead);
                               }

 @Test
                              public void testReadBitsWithOverflowDetectsMutant5() throws Exception {
                                  // Setup input stream with test data
                                  byte[] testData = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, 
                                                              (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
                                  InputStream inputStream = new ByteArrayInputStream(testData);
                                  BitInputStream bis = new BitInputStream(inputStream, ByteOrder.BIG_ENDIAN);
                                  
                                  // First read 56 bits to nearly fill the cache (7 bytes)
                                  bis.readBits(56);
                                  
                                  // Now read 8 more bits which will cause overflow
                                  // The first 1 bit should come from cache, remaining 7 from new byte
                                  long result = bis.readBits(8);
                                  
                                  // Verify the result is correct (all 1s)
                                  assertEquals(0xFFL, result);
                                  
                                  // Now read again to verify the overflow was handled correctly
                                  // If mutant is present, this read will be corrupted
                                  long nextResult = bis.readBits(8);
                                  assertEquals(0xFFL, nextResult);
                                  
                                  // Additional verification that cache state is correct
                                  // For BIG_ENDIAN, remaining bits should be 0 after reading full bytes
                                  // If mutant added 1 to overflow, this would be wrong
                                  long finalResult = bis.readBits(8);
                                  assertEquals(0xFFL, finalResult);
                              }

 @Test
                             public void testReadBitsOverflowPreservesCacheSize() throws Exception {
                                 // Setup input that will trigger overflow condition (count > 57 bits)
                                 // We'll use count = 58 to force overflow handling
                                 final int count = 58;
                                 final int overflowBits = 6; // 64 - 58 = 6 (since we can't shift 58 bits in a long)
                                 
                                 // Mock input stream that will provide bytes
                                 InputStream mockIn = mock(InputStream.class);
                                 when(mockIn.read())
                                     .thenReturn(0xFF)  // First byte (will be read 7 times in initial loop)
                                     .thenReturn(0xFF)  // Second byte (will be read once in overflow handling)
                                     .thenReturn(0x00); // Subsequent read
                                 
                                 // Create BitInputStream with big-endian order (easier to calculate)
                                 BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                 
                                 // Use reflection to set private fields for testing
                                 Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                 bitsCachedField.setAccessible(true);
                                 Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                 bitsCachedSizeField.setAccessible(true);
                                 
                                 // First read - should trigger overflow handling
                                 long result = bis.readBits(count);
                                 
                                 // Verify bitsCachedSize was set to overflowBits (not 0)
                                 assertEquals(overflowBits, bitsCachedSizeField.getInt(bis));
                                 
                                 // Verify we can perform a subsequent read correctly
                                 // This would fail with the mutant since bitsCachedSize would be 0
                                 when(mockIn.read()).thenReturn(0xFF);
                                 long nextResult = bis.readBits(overflowBits);
                                 assertEquals(0x3F, nextResult); // 6 bits of 0xFF should be 0x3F
                             }

 @Test
                           public void testReadBits_OverflowHandling_CorrectBitsCachedSize() throws Exception {
                               // Setup - create a BitInputStream with mocked InputStream
                               InputStream mockIn = mock(InputStream.class);
                               BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                               
                               // Helper method to set private field using reflection
                               Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                               bitsCachedSizeField.setAccessible(true);
                               bitsCachedSizeField.set(bis, 57);
                               
                               Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                               bitsCachedField.setAccessible(true);
                               bitsCachedField.set(bis, 0x123456789ABCDEFL); // some dummy value
                               
                               // Mock the InputStream to return a byte when read() is called
                               when(mockIn.read()).thenReturn(0xFF); // return a byte with all bits set
                               
                               // Call the method
                               long result = bis.readBits(58);
                               
                               // Verify the bitsCachedSize is set to overflowBits (8 - (58-57)) = 7
                               int actualBitsCachedSize = (int) bitsCachedSizeField.get(bis);
                               assertEquals("bitsCachedSize should be set to overflowBits (7)", 7, actualBitsCachedSize);
                               
                               // Also verify the overflow bits were properly handled
                               long bitsCached = (long) bitsCachedField.get(bis);
                               long expectedOverflow = (0xFF >>> 1) & 0x7F; // 7 bits from the overflow
                               assertEquals("Overflow bits should be properly cached", expectedOverflow, bitsCached);
                           }

 @Test
                       public void testReadBitsWithOverflowDetectsMutant6() throws Exception {
                           // Setup input that will cause overflow (count > 57 bits)
                           final int count = 58; // Enough to trigger overflow case
                           final byte[] inputBytes = new byte[] {
                               (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, 
                               (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0x0F
                           };
                           InputStream inputStream = new ByteArrayInputStream(inputBytes);
                           BitInputStream bis = new BitInputStream(inputStream, ByteOrder.BIG_ENDIAN);
                           
                           // Read bits to fill cache (57 bits)
                           bis.readBits(57);
                           
                           // Now read more bits to trigger overflow case
                           long result = bis.readBits(count);
                           
                           // Verify the result is correct (not the main focus here)
                           assertTrue(result >= 0);
                           
                           // The key assertion: verify bitsCachedSize equals overflowBits
                           // In this case, overflowBits should be 8 - (58 - 57) = 7
                           // We need to use reflection to access private field
                           Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                           bitsCachedSizeField.setAccessible(true);
                           int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                           
                           assertEquals(7, actualBitsCachedSize); // Will fail if mutant is present (would be 8)
                           
                           // Clean up
                           bis.close();
                       }

 @Test
                      public void testReadBitsMultipleTimesDetectsCacheSizeMutation() throws Exception {
                          // Setup mock input stream that returns two bytes
                          InputStream mockIn = mock(InputStream.class);
                          when(mockIn.read())
                              .thenReturn(0xFF)  // first byte (all 1s)
                              .thenReturn(0xAA); // second byte (10101010)
                          
                          // Create BitInputStream with big-endian order
                          BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                          
                          // First read: 8 bits (should cache remaining 8 bits)
                          long firstRead = bis.readBits(8);
                          assertEquals(0xFF, firstRead);
                          
                          // Second read: 4 bits (should use cached bits and leave 4 bits)
                          long secondRead = bis.readBits(4);
                          assertEquals(0x0A, secondRead);  // top 4 bits of 0xA0 (since we're big-endian)
                          
                          // Verify cache size is properly maintained
                          // If mutation exists, bitsCachedSize would be 4 (wrong)
                          // Original code would have bitsCachedSize = 4 (correct)
                          // Need to read again to detect the difference
                          
                          // Third read: 4 bits (should use remaining cached bits)
                          long thirdRead = bis.readBits(4);
                          assertEquals(0x0A, thirdRead);  // remaining 4 bits
                          
                          // The key difference appears if we try to read again:
                          // With mutation, bitsCachedSize would be wrong and we'd try to read new bytes incorrectly
                          // Original code would properly have bitsCachedSize = 0
                          
                          // Verify no more bits are cached (should try to read new byte)
                          long fourthRead = bis.readBits(8);
                          // With mutation, this would incorrectly use cached bits (but there shouldn't be any)
                          // Original code would properly read new byte (0xAA)
                          assertEquals(0xAA, fourthRead);
                      }

 @Test
                     public void testReadBitsOverflowCaseDetectsAndXorMutant() throws Exception {
                         // Setup test where overflow occurs and bitsCached & mask != bitsCached ^ mask
                         InputStream mockIn = mock(InputStream.class);
                         when(mockIn.read())
                             .thenReturn(0xFF)  // First byte to fill cache
                             .thenReturn(0xFF); // Second byte for overflow
                         
                         // Initialize with little endian to test the mutated path
                         BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                         
                         // Set up internal state to trigger overflow path
                         // We need bitsCachedSize < count (57) but also bitsCachedSize >= 57 would cause overflow
                         // This is tricky because of the condition in the original code
                         // Let's read 64 bits (8 bytes) to ensure we hit the overflow case
                         
                         // First read 56 bits (7 bytes) to fill cache almost completely
                         for (int i = 0; i < 7; i++) {
                             bis.readBits(8);
                         }
                         
                         // Now read 8 more bits - this should trigger the overflow path
                         // With our mock setup, bitsCached will be 0xFFFFFFFFFFFFFFFF (all 1s)
                         // and we're reading with count=8, so MASKS[8] = 0xFF
                         // bitsCached & 0xFF = 0xFF
                         // bitsCached ^ 0xFF = 0xFFFFFFFFFFFFFF00 (different result)
                         long result = bis.readBits(8);
                         
                         // Verify the correct AND operation was used (not XOR)
                         assertEquals(0xFFL, result);  // Would fail if XOR was used
                         
                         // Repeat test with big endian
                         bis = new BitInputStream(mock(InputStream.class), ByteOrder.BIG_ENDIAN);
                         when(mockIn.read())
                             .thenReturn(0xFF)
                             .thenReturn(0xFF);
                         
                         for (int i = 0; i < 7; i++) {
                             bis.readBits(8);
                         }
                         result = bis.readBits(8);
                         assertEquals(0xFFL, result);
                     }

 @Test
                   public void testReadBitsWithOverflowDetectsMaskMutation3() throws Exception {
                       // Setup - create a scenario where overflowBits != 0
                       // We need bitsCachedSize < count and bitsCachedSize >= 57
                       final int count = 60; // Large enough to trigger overflow
                       final int initialBits = 56; // Just below 57 to trigger the overflow path
                       final long testByte = 0xFFL; // Will be partially read
                       
                       // Mock the InputStream to return our test byte
                       InputStream mockIn = mock(InputStream.class);
                       when(mockIn.read()).thenReturn((int)testByte);
                       
                       // Create BitInputStream with our mock
                       BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                       
                       // Manually set up the cache state to trigger overflow path
                       // Set bitsCachedSize to initialBits (56)
                       // Reflection to access private fields for test setup
                       Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                       bitsCachedSizeField.setAccessible(true);
                       bitsCachedSizeField.set(bis, initialBits);
                       
                       Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                       bitsCachedField.setAccessible(true);
                       bitsCachedField.set(bis, 0x123456789ABCDEFL); // Some arbitrary cached bits
                       
                       // Get the MASKS array via reflection
                       Field masksField = BitInputStream.class.getDeclaredField("MASKS");
                       masksField.setAccessible(true);
                       long[] MASKS = (long[]) masksField.get(null);
                       
                       // Execute
                       long result = bis.readBits(count);
                       
                       // Verify - the result should be properly masked
                       // Expected: first (count - initialBits) = 4 bits from testByte (0xF)
                       // plus initialBits (56) from cache, properly masked
                       long expected = (0x123456789ABCDEFL << 4) | 0xFL;
                       expected &= MASKS[count]; // This is what the mutant would break
                       
                       assertEquals("Result should be properly masked with MASKS[count]", expected, result);
                       
                       // Verify we read exactly one byte
                       verify(mockIn, times(1)).read();
                   }

 @Test
              public void testReadBitsWithOverflowDetectsMaskMutation4() throws Exception {
                  // Setup input stream to return specific bytes
                  InputStream mockInputStream = mock(InputStream.class);
                  when(mockInputStream.read())
                      .thenReturn(0xFF)  // First byte (all bits set)
                      .thenReturn(0xFF); // Second byte (all bits set)
                  
                  // Create BitInputStream with little-endian order
                  BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
                  
                  // Use reflection to set private fields
                  Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                  bitsCachedField.setAccessible(true);
                  Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                  bitsCachedSizeField.setAccessible(true);
                  
                  // Set up initial cache state
                  bitsCachedField.set(bis, 0x0F); // Some existing bits (lower 4 bits set)
                  bitsCachedSizeField.set(bis, 4);
                  
                  // Request 8 bits (which will need to read another byte)
                  long result = bis.readBits(8);
                  
                  // Verify the result is properly masked to 8 bits
                  // The mutant would return 0xFFFF (all bits from both bytes)
                  // Correct behavior should return only 8 bits (0xFF)
                  assertEquals("Should return only 8 bits", 0xFF, result);
                  
                  // Verify the overflow handling
                  // Original would have properly masked and stored overflow bits
                  // Mutant would have incorrect overflow bits
                  assertEquals("Should have remaining bits in cache", 4, bitsCachedSizeField.get(bis));
                  assertEquals("Should have correct overflow bits", 0x0F, bitsCachedField.get(bis));
              }

 @Test
          public void testReadBitsWithOverflowPreservesBitsForNextRead() throws Exception {
              // Setup input stream that will return two bytes
              InputStream mockIn = mock(InputStream.class);
              when(mockIn.read())
                  .thenReturn(0xFF)  // First byte (all 1s)
                  .thenReturn(0xAA); // Second byte (10101010)
              
              // Create BitInputStream with big-endian order
              BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
              
              // First read: 60 bits (will cause overflow handling)
              long firstRead = bis.readBits(60);
              
              // Verify first read (should get first 60 bits)
              assertEquals(0xFFFFFFFFFFFFFFFL, firstRead);
              
              // Second read: 4 bits (should get the remaining overflow bits)
              long secondRead = bis.readBits(4);
              
              // With original code: should get remaining 4 bits (0xA)
              // With mutant: will get 0 because overflow was set to 0
              assertEquals(0xAL, secondRead);
              
              // Verify we only read two bytes from the stream
              verify(mockIn, times(2)).read();
          }

 @Test
         public void testReadBitsWithOverflowUpdatesCacheCorrectly() throws Exception {
             // Setup test data for overflow scenario (bitsCachedSize >= 57)
             // We'll need to read enough bytes to trigger overflow handling
             InputStream mockIn = mock(InputStream.class);
             when(mockIn.read())
                 .thenReturn(0xFF)  // first byte
                 .thenReturn(0xFF)  // second byte
                 .thenReturn(0xFF)  // third byte
                 .thenReturn(0xFF)  // fourth byte
                 .thenReturn(0xFF)  // fifth byte
                 .thenReturn(0xFF)  // sixth byte
                 .thenReturn(0xFF)  // seventh byte
                 .thenReturn(0xFF); // eighth byte (will trigger overflow)
             
             BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
             
             // Use reflection to access private fields for verification
             Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
             Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
             bitsCachedField.setAccessible(true);
             bitsCachedSizeField.setAccessible(true);
             
             // First read - should fill the cache and trigger overflow handling
             long result = bis.readBits(64);  // Trying to read 64 bits (8 bytes)
             
             // Verify the cache was properly updated with overflow bits
             long actualBitsCached = (long) bitsCachedField.get(bis);
             int actualBitsCachedSize = (int) bitsCachedSizeField.get(bis);
             
             // In original code, after overflow, bitsCached should be updated to overflow value
             // In mutated code, bitsCached would retain its old value
             // For little-endian, overflow would be the upper bits of the last byte read
             assertEquals(0x0L, actualBitsCached);  // Expecting overflow bits to be 0 (since we read all 1s)
             assertEquals(0, actualBitsCachedSize);  // No remaining bits after reading 64 bits
         }

 @Test
        public void testReadBitsWithOverflowDetectsMutant7() throws Exception {
            // Setup input stream to return specific bytes that will trigger overflow path
            InputStream mockIn = mock(InputStream.class);
            when(mockIn.read())
                .thenReturn(0xFF)  // First byte to fill initial cache
                .thenReturn(0xAA); // Second byte that will cause overflow
            
            BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
            
            // First read: triggers overflow path where mutation occurs
            long result1 = bis.readBits(60); // Large enough to trigger overflow
            
            // Verify first read result (should be correct regardless of mutation)
            assertEquals(0xFFFFFFFFFFFFFFFAL, result1);
            
            // Second read: should use the cached overflow bits
            // With mutation, this would be incorrect because cache was corrupted
            long result2 = bis.readBits(4); // Read remaining 4 bits (0xA becomes 0xB with mutation)
            
            // This assertion will fail with the mutant but pass with original
            assertEquals(0xAL, result2);
            
            // Verify the cache was properly updated
            // This would catch if bitsCached was set to overflow+1 instead of overflow
            Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
            bitsCachedField.setAccessible(true);
            long actualCache = bitsCachedField.getLong(bis);
            assertEquals(0x0L, actualCache); // Should be 0 after reading all bits
            
            Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
            bitsCachedSizeField.setAccessible(true);
            int actualCacheSize = bitsCachedSizeField.getInt(bis);
            assertEquals(0, actualCacheSize); // Should be 0 after reading all bits
        }

 @Test
      public void testReadBitsWithOverflowPreservesCacheSize() throws Exception {
          // Setup - create a mock input stream that returns test bytes
          InputStream mockIn = mock(InputStream.class);
          when(mockIn.read())
              .thenReturn(0xFF)  // first byte (all bits set)
              .thenReturn(0xFF)  // second byte (all bits set)
              .thenReturn(0xFF); // third byte (all bits set)
          
          // Create BitInputStream with big-endian order (easier to calculate)
          BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
          
          // First read - should cause overflow
          long firstRead = bis.readBits(58); // Needs more than 57 bits to trigger overflow
          
          // Use reflection to access private bitsCachedSize field
          Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
          bitsCachedSizeField.setAccessible(true);
          int bitsCachedSize = bitsCachedSizeField.getInt(bis);
          
          // Verify bitsCachedSize was set to overflowBits (6 in this case)
          // Because: 58 bits requested, 56 bits from 7 bytes, need 2 more bits
          // overflowBits = 8 - 2 = 6
          assertEquals(6, bitsCachedSize);
          
          // Second read - should use the overflow bits
          long secondRead = bis.readBits(6);
          
          // Verify we got the overflow bits (last 6 bits of third byte)
          assertEquals(0x3F, secondRead); // 0xFF right-shifted by 2 is 0x3F
          
          // Verify mock interactions
          verify(mockIn, times(3)).read();
      }

 @Test
  public void testReadBitsWithOverflowFollowedByRead() throws Exception {
      // Setup input that will trigger overflow case (count > 57)
      InputStream mockInput = mock(InputStream.class);
      when(mockInput.read())
          .thenReturn(0xFF)  // First byte (all 1s)
          .thenReturn(0xFF)  // Second byte (all 1s)
          .thenReturn(0xFF)  // Third byte (all 1s)
          .thenReturn(0xFF)  // Fourth byte (all 1s)
          .thenReturn(0xFF)  // Fifth byte (all 1s)
          .thenReturn(0xFF)  // Sixth byte (all 1s)
          .thenReturn(0xFF)  // Seventh byte (all 1s)
          .thenReturn(0xFF)  // Eighth byte (all 1s)
          .thenReturn(0x0F); // Ninth byte (lower nibble)
  
      BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
      
      // First read: 64 bits (trigger overflow case)
      long result1 = bis.readBits(64);
      assertEquals(0xFFFFFFFFFFFFFFFFL, result1);
      
      // Second read: should read remaining 4 bits from ninth byte
      // With original code: bitsCachedSize would be 4 (overflowBits)
      // With mutant: bitsCachedSize would be 64 (count)
      long result2 = bis.readBits(4);
      assertEquals(0x0FL, result2);
      
      // Verify the ninth byte was only read once (proves we're using cached bits)
      verify(mockInput, times(9)).read();
  }

 @Test
     public void testReadBitsWithOverflowDetectsMutant8() throws IOException {
         // Setup - create test data that will trigger overflow
         InputStream mockInput = mock(InputStream.class);
         when(mockInput.read())
             .thenReturn(0xFF)  // first byte (all 1s)
             .thenReturn(0xFF)   // second byte
             .thenReturn(0xFF)   // third byte
             .thenReturn(0xFF)   // fourth byte
             .thenReturn(0xFF)   // fifth byte
             .thenReturn(0xFF)   // sixth byte
             .thenReturn(0xFF)   // seventh byte
             .thenReturn(0x0F); // eighth byte (only need 4 bits)
 
         BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
         
         // First read - 60 bits (will trigger overflow handling)
         long result = bis.readBits(60);
         
         // Verify the result is correct
         assertEquals(0xFFFFFFFFFFFFFFFL, result);
         
         // Now verify the cache state - this is where the mutant would fail
         // The remaining 4 bits should be in cache (0x0F & 0x0F = 0x0F)
         // Next read should get these 4 bits
         long nextResult = bis.readBits(4);
         assertEquals(0x0F, nextResult);
         
         // Verify mock interactions
         verify(mockInput, times(8)).read();
     }

}
