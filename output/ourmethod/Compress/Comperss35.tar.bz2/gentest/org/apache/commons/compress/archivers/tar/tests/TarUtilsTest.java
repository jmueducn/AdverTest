package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                       public void testVerifyCheckSum_EmptyHeader() {
                                                           byte[] emptyHeader = new byte[0];
                                                           assertFalse(TarUtils.verifyCheckSum(emptyHeader));
                                                       }

 @Test
                                               public void testVerifyCheckSum_ValidUnsignedSum() {
                                                   // Define constants for checksum offset and length (standard TAR header positions)
                                                   final int CHKSUM_OFFSET = 148;  // Standard checksum field offset in TAR header
                                                   final int CHKSUMLEN = 8;        // Standard checksum field length in TAR header
                                                   
                                                   // Create a header where unsigned sum matches stored checksum
                                                   byte[] header = new byte[512];
                                                   // Set some dummy values in the header
                                                   for (int i = 0; i < header.length; i++) {
                                                       header[i] = (byte)(i % 256);
                                                   }
                                                   
                                                   // Calculate unsigned sum (excluding checksum field)
                                                   long unsignedSum = 0;
                                                   for (int i = 0; i < header.length; i++) {
                                                       if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                           continue;
                                                       }
                                                       unsignedSum += 0xff & header[i];
                                                   }
                                                   
                                                   // Format the checksum in the header
                                                   TarUtils.formatCheckSumOctalBytes(unsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                   
                                                   assertTrue(TarUtils.verifyCheckSum(header));
                                               }

 @Test
                                               public void testVerifyCheckSum_ValidSignedSum() {
                                                   // Define checksum offset and length
                                                   final int CHKSUM_OFFSET = 148;
                                                   final int CHKSUMLEN = 8;
                                                   
                                                   // Create a header where signed sum matches stored checksum
                                                   byte[] header = new byte[512];
                                                   // Set some dummy values in the header
                                                   for (int i = 0; i < header.length; i++) {
                                                       header[i] = (byte)(i % 128); // Keep values positive for signed bytes
                                                   }
                                                   
                                                   // Calculate signed sum (excluding checksum field)
                                                   long signedSum = 0;
                                                   for (int i = 0; i < header.length; i++) {
                                                       if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                           continue;
                                                       }
                                                       signedSum += header[i];
                                                   }
                                                   
                                                   // Format the checksum in the header
                                                   TarUtils.formatCheckSumOctalBytes(signedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                   
                                                   assertTrue(TarUtils.verifyCheckSum(header));
                                               }

 @Test
                                               public void testVerifyCheckSum_InvalidChecksum() {
                                                   // Define constants that would normally be in the class
                                                   final int CHKSUM_OFFSET = 148; // Standard checksum offset in tar header
                                                   final int CHKSUMLEN = 8;       // Standard checksum length in tar header
                                                   
                                                   byte[] header = new byte[512];
                                                   // Fill with some values
                                                   for (int i = 0; i < header.length; i++) {
                                                       header[i] = (byte)(i % 256);
                                                   }
                                                   
                                                   // Set an obviously wrong checksum
                                                   TarUtils.formatCheckSumOctalBytes(0, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                   
                                                   assertFalse(TarUtils.verifyCheckSum(header));
                                               }

 @Test
                                               public void testVerifyCheckSum_NullHeader() {
                                                   ExpectedException exceptionRule = ExpectedException.none();
                                                   exceptionRule.expect(NullPointerException.class);
                                                   TarUtils.verifyCheckSum(null);
                                               }

 @Test
                                               public void testVerifyCheckSum_HeaderSmallerThanChecksumOffset() {
                                                   // Standard TAR header checksum offset is 148 bytes
                                                   final int CHKSUM_OFFSET = 148;
                                                   byte[] smallHeader = new byte[CHKSUM_OFFSET - 1];
                                                   // Fill with some values
                                                   for (int i = 0; i < smallHeader.length; i++) {
                                                       smallHeader[i] = (byte)(i % 256);
                                                   }
                                                   
                                                   // This should still work as parseOctal will handle the small buffer
                                                   // but the checksum verification will fail
                                                   assertFalse(TarUtils.verifyCheckSum(smallHeader));
                                               }

 @Test
                                               public void testVerifyCheckSum_HeaderWithNegativeBytes() {
                                                   // Define the checksum offset and length constants
                                                   final int CHKSUM_OFFSET = 148; // Standard TAR header checksum offset
                                                   final int CHKSUMLEN = 8;       // Standard TAR header checksum length
                                                   
                                                   byte[] header = new byte[512];
                                                   // Fill with negative values
                                                   for (int i = 0; i < header.length; i++) {
                                                       header[i] = (byte)(-i % 128);
                                                   }
                                                   
                                                   // Calculate both sums
                                                   long unsignedSum = 0;
                                                   long signedSum = 0;
                                                   for (int i = 0; i < header.length; i++) {
                                                       if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                           continue;
                                                       }
                                                       unsignedSum += 0xff & header[i];
                                                       signedSum += header[i];
                                                   }
                                                   
                                                   // Test with unsigned sum
                                                   TarUtils.formatCheckSumOctalBytes(unsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                   assertTrue(TarUtils.verifyCheckSum(header));
                                                   
                                                   // Test with signed sum
                                                   TarUtils.formatCheckSumOctalBytes(signedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                   assertTrue(TarUtils.verifyCheckSum(header));
                                               }

 @Test
       public void testVerifyCheckSum_ShouldSkipFirstChecksumByte() {
           // Constants from tar format (assuming typical values)
           final int CHKSUM_OFFSET = 148;
           final int CHKSUMLEN = 8;
           
           // Create a header where the first checksum byte is significant
           byte[] header = new byte[512];
           // Set a non-space value at CHKSUM_OFFSET that will affect checksum
           header[CHKSUM_OFFSET] = 'A';  // ASCII 65
           
           // Calculate expected checksums
           // 1. Original behavior (skips CHKSUM_OFFSET byte)
           long unsignedSumSkip = 0xff & ' ';  // space is 32
           long signedSumSkip = ' ';           // space is 32
           
           // 2. Mutant behavior (includes CHKSUM_OFFSET byte)
           long unsignedSumInclude = 0xff & 'A';  // 65
           long signedSumInclude = 'A';           // 65
           
           // Set stored checksum to match the "skip" version
           // This should pass original but fail mutant
           String checksumStr = String.format("%06o", unsignedSumSkip);
           byte[] checksumBytes = checksumStr.getBytes();
           System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, checksumBytes.length);
           
           // Test - should return true with original, false with mutant
           assertTrue(TarUtils.verifyCheckSum(header));
           
           // Additional verification - if we use the "include" checksum, mutant would pass
           String mutantChecksumStr = String.format("%06o", unsignedSumInclude);
           byte[] mutantChecksumBytes = mutantChecksumStr.getBytes();
           System.arraycopy(mutantChecksumBytes, 0, header, CHKSUM_OFFSET, mutantChecksumBytes.length);
           
           // This would make mutant pass, but we don't want this
           // assertTrue(TarUtils.verifyCheckSum(header));
       }

 @Test
      public void testVerifyCheckSum_DetectsChecksumFieldReplacementMutant() {
          // Constants from the class (assuming typical tar values)
          final int CHKSUM_OFFSET = 148;
          final int CHKSUMLEN = 8;
          
          // Create a header where checksum field has bytes with value 1
          byte[] header = new byte[512]; // typical tar block size
          // Set some non-zero bytes in the checksum field
          for (int i = CHKSUM_OFFSET; i < CHKSUM_OFFSET + CHKSUMLEN; i++) {
              header[i] = 1;
          }
          
          // Mock parseOctal to return a checksum that would only pass if spaces are used
          // Original computes: (1 * 8) replaced by (32 * 8) = 256 difference
          // Mutant computes: (1 * 8) replaced by (48 * 8) = 384 difference
          // So we'll set stored checksum to be original + 256 (space case)
          long originalChecksum = 1000L; // base value
          long expectedSpaceChecksum = originalChecksum + (32 * 8);
          
          // Mock parseOctal to return our expected checksum
          // (Using Mockito as statically imported)
          TarUtils mockUtils = mock(TarUtils.class);
          when(mockUtils.parseOctal(header, CHKSUM_OFFSET, CHKSUMLEN))
              .thenReturn(expectedSpaceChecksum);
          
          // The test should pass with original code (using spaces)
          // but fail with mutant (using '0's)
          assertTrue(TarUtils.verifyCheckSum(header));
          
          // Additional verification - compute what mutant would produce
          long mutantChecksum = originalChecksum + (48 * 8);
          assertFalse(expectedSpaceChecksum == mutantChecksum);
      }

 @Test
     public void testVerifyCheckSum_DetectsUnsignedSumAccumulationMutation() {
         // Constants from the class (assuming typical tar header values)
         final int CHKSUM_OFFSET = 148;
         final int CHKSUMLEN = 8;
         
         // Create a header with 3 bytes outside checksum range
         byte[] header = new byte[CHKSUM_OFFSET + CHKSUMLEN + 3];
         // Set some values outside checksum range
         header[0] = 10;
         header[1] = 20;
         header[2] = 30;
         
         // Set checksum field to spaces (as the method would do)
         for (int i = CHKSUM_OFFSET; i < CHKSUM_OFFSET + CHKSUMLEN; i++) {
             header[i] = ' ';
         }
         
         // Mock parseOctal to return the expected unsigned sum (10+20+30 = 60)
         // We need to mock the static method - this would require PowerMockito in real code
         // For this test, we'll assume parseOctal works correctly
         
         // The correct unsigned sum should be 60 (10 + 20 + 30)
         // The mutated version would only keep the last byte (30)
         long expectedSum = 60;
         
         // Set the stored checksum to match the expected sum
         // This assumes parseOctal will return this value for the checksum field
         // In real code, we'd need to mock parseOctal to return this
         // For this test, we'll directly set the checksum bytes to represent 60 in octal
         String checksumStr = String.format("%06o", expectedSum) + " ";
         byte[] checksumBytes = checksumStr.getBytes();
         System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, Math.min(CHKSUMLEN, checksumBytes.length));
         
         // Test - should return true for original, false for mutated
         assertTrue(TarUtils.verifyCheckSum(header));
         
         // Additional assertion to verify the sum calculation directly
         // This would catch the mutation where accumulation is replaced by assignment
         long unsignedSum = 0;
         for (int i = 0; i < header.length; i++) {
             byte b = header[i];
             if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                 b = ' ';
             }
             unsignedSum += 0xff & b;
         }
         assertEquals(expectedSum, unsignedSum);
     }

 @Test
    public void testVerifyCheckSum_DetectsFirstByteSkippingMutant() {
        // Constants from TarUtils (assuming typical values)
        final int CHKSUM_OFFSET = 148;
        final int CHKSUMLEN = 8;
        
        // Create a header array where first byte is significant
        byte[] header = new byte[512]; // Typical tar header size
        header[0] = 100; // Significant first byte
        // Fill rest with zeros for simplicity
        for (int i = 1; i < header.length; i++) {
            header[i] = 0;
        }
        
        // Compute expected checksum (unsigned sum)
        long expectedSum = 0xff & header[0]; // Only first byte contributes
        
        // Set the checksum field in header to match expected sum
        // Using formatOctalBytes to properly format the checksum
        TarUtils.formatOctalBytes(expectedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
        
        // Test - should return true with original code, false with mutant
        assertTrue(TarUtils.verifyCheckSum(header));
        
        // Additional verification that first byte is actually considered
        // Modify first byte and checksum should fail
        header[0] = 50;
        assertFalse(TarUtils.verifyCheckSum(header));
    }

 @Test
   public void testVerifyCheckSum_DetectsMutatedByteAccess() {
       // Create a header where bytes differ at different positions
       byte[] header = new byte[100];
       
       // Fill header with distinct values
       for (int i = 0; i < header.length; i++) {
           header[i] = (byte)(i % Byte.MAX_VALUE);
       }
       
       // Set checksum field (positions 148-155 in standard tar) to known value
       final int CHKSUM_OFFSET = 148;
       final int CHKSUMLEN = 8;
       System.arraycopy(new byte[]{'0','0','0','0','0','0','0','0'}, 0, 
                        header, CHKSUM_OFFSET, CHKSUMLEN);
       
       // Calculate expected checksum (original behavior)
       long expectedUnsignedSum = 0;
       long expectedSignedSum = 0;
       for (int i = 0; i < header.length; i++) {
           byte b = header[i];
           if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
               b = ' ';
           }
           expectedUnsignedSum += 0xff & b;
           expectedSignedSum += b;
       }
       
       // Set stored checksum to match expected calculation
       String checksumStr = String.format("%06o", expectedUnsignedSum);
       byte[] checksumBytes = checksumStr.getBytes();
       System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, checksumBytes.length);
       
       // Test - should pass with original code, fail with mutant
       assertTrue(TarUtils.verifyCheckSum(header));
       
       // Additional verification - test with different checksum values
       // This ensures the test isn't just passing by coincidence
       checksumStr = String.format("%06o", expectedUnsignedSum + 1);
       checksumBytes = checksumStr.getBytes();
       System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, checksumBytes.length);
       assertFalse(TarUtils.verifyCheckSum(header));
   }

 @Test
  public void testVerifyCheckSum_DetectsUnsignedSumMutation() {
      // Setup
      byte[] header = new byte[512];
      // Fill header with some test data (bytes that will show difference between & and |)
      for (int i = 0; i < header.length; i++) {
          header[i] = (byte)(i % 256); // Varying byte values from 0 to -1 (255)
      }
      
      // Set a known checksum in the header (CHKSUM_OFFSET assumed to be 148, CHKSUMLEN 8)
      int CHKSUM_OFFSET = 148;
      int CHKSUMLEN = 8;
      // Calculate what the correct unsigned sum should be
      long correctUnsignedSum = 0;
      for (int i = 0; i < header.length; i++) {
          byte b = header[i];
          if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
              b = ' ';
          }
          correctUnsignedSum += 0xff & b;
      }
      
      // Put the correct checksum in the header
      TarUtils.formatUnsignedOctalString(correctUnsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
      
      // Test - should return true with original code, false with mutated code
      assertTrue(TarUtils.verifyCheckSum(header));
      
      // Additional verification - check that mutated version would fail
      // This is just for demonstration, not part of the actual test
      long mutatedUnsignedSum = 0;
      for (int i = 0; i < header.length; i++) {
          byte b = header[i];
          if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
              b = ' ';
          }
          mutatedUnsignedSum += 0xff | b; // Mutated version
      }
      assertFalse(correctUnsignedSum == mutatedUnsignedSum);
  }

 @Test
 public void testVerifyCheckSum_DetectsAccumulationMutation() {
     // Constants from tar format (typically CHKSUM_OFFSET=148, CHKSUMLEN=8)
     final int CHKSUM_OFFSET = 148;
     final int CHKSUMLEN = 8;
     
     // Create a header where:
     // - First byte is 1
     // - Second byte is 2
     // - Checksum field is set to 3 (1+2)
     byte[] header = new byte[CHKSUM_OFFSET + CHKSUMLEN];
     header[0] = 1;
     header[1] = 2;
     
     // Set checksum field to 3 (1+2)
     byte[] checksumBytes = new byte[CHKSUMLEN];
     checksumBytes[CHKSUMLEN-1] = '3'; // ASCII '3' in last position
     System.arraycopy(checksumBytes, 0, header, CHKSUM_OFFSET, CHKSUMLEN);
     
     // Mock parseOctal to return 3 (the checksum we set)
     TarUtils mockUtils = mock(TarUtils.class);
     when(mockUtils.parseOctal(any(byte[].class), eq(CHKSUM_OFFSET), eq(CHKSUMLEN)))
         .thenReturn(3L);
     
     // Test - should pass with original code (1+2=3), fail with mutant (last byte=2)
     assertTrue(TarUtils.verifyCheckSum(header));
     
     // Additional verification that we're testing the right thing
     // With original code: unsignedSum would be 1+2=3 (matches checksum)
     // With mutant: unsignedSum would be 2 (last byte) which doesn't match
 }

}
