package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                           public void testGetNextZipEntry_WhenClosed_ReturnsNull() throws Exception {
                                                                                               // Arrange
                                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                               zais.close();
                                                                                               
                                                                                               // Act
                                                                                               ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                               
                                                                                               // Assert
                                                                                               assertNull(result);
                                                                                           }

 @Test
                                                                                           public void testGetNextZipEntry_WhenEOFExceptionThrown_ReturnsNull() throws Exception {
                                                                                               // Arrange
                                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                               
                                                                                               when(mockInputStream.read(any(byte[].class))).thenThrow(new EOFException());
                                                                                               
                                                                                               // Act
                                                                                               ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                               
                                                                                               // Assert
                                                                                               assertNull(result);
                                                                                           }

 @Test
                                                                                   public void testGetNextZipEntry_WhenHitCentralDirectory_ReturnsNull() throws Exception {
                                                                                       // Arrange
                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                       
                                                                                       // Use reflection to set private field hitCentralDirectory
                                                                                       Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                                                                                       hitCentralDirectoryField.setAccessible(true);
                                                                                       hitCentralDirectoryField.setBoolean(zais, true);
                                                                                       
                                                                                       // Act
                                                                                       ZipArchiveEntry result = zais.getNextZipEntry();
                                                                                       
                                                                                       // Assert
                                                                                       assertNull(result);
                                                                                   }

 @Test
                                                                           public void testGetNextZipEntry_WithUnicodeExtraFields() throws Exception {
                                                                               // Arrange
                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, "UTF-8", true);
                                                                               
                                                                               // Get LFH_BUF size via reflection since it's private
                                                                               Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
                                                                               lfhBufField.setAccessible(true);
                                                                               byte[] lfhBuf = new byte[((byte[]) lfhBufField.get(null)).length];
                                                                               
                                                                               // Setup mock to return valid LFH signature without UTF8 flag but with unicode extra fields
                                                                               // LFH_SIG
                                                                               System.arraycopy(new byte[] {0x50, 0x4b, 0x03, 0x04}, 0, lfhBuf, 0, 4);
                                                                               
                                                                               // Set version made by (platform)
                                                                               lfhBuf[4] = 0;
                                                                               lfhBuf[5] = 0;
                                                                               
                                                                               // Set GPB (no UTF8 flag)
                                                                               lfhBuf[6] = 0;
                                                                               lfhBuf[7] = 0;
                                                                               
                                                                               // Set compression method (STORED)
                                                                               lfhBuf[8] = 0;
                                                                               lfhBuf[9] = 0;
                                                                               
                                                                               // Set DOS time (simplified)
                                                                               long dosTime = System.currentTimeMillis() / 1000;
                                                                               lfhBuf[10] = (byte)(dosTime & 0xff);
                                                                               lfhBuf[11] = (byte)((dosTime >> 8) & 0xff);
                                                                               lfhBuf[12] = (byte)((dosTime >> 16) & 0xff);
                                                                               lfhBuf[13] = (byte)((dosTime >> 24) & 0xff);
                                                                               
                                                                               // Set CRC, compressed size and size (no data descriptor)
                                                                               for (int i = 14; i < 26; i++) {
                                                                                   lfhBuf[i] = (i == 18 || i == 22) ? (byte)100 : (byte)0;
                                                                               }
                                                                               
                                                                               // Set filename length (5) and extra length (20)
                                                                               lfhBuf[26] = 5;
                                                                               lfhBuf[27] = 0;
                                                                               lfhBuf[28] = 20;
                                                                               lfhBuf[29] = 0;
                                                                               
                                                                               when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                   Object[] args = invocation.getArguments();
                                                                                   byte[] buf = (byte[]) args[0];
                                                                                   System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                                                   return lfhBuf.length;
                                                                               });
                                                                               
                                                                               // Mock filename read
                                                                               when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                   Object[] args = invocation.getArguments();
                                                                                   byte[] buf = (byte[]) args[0];
                                                                                   byte[] filename = "test4".getBytes();
                                                                                   System.arraycopy(filename, 0, buf, 0, filename.length);
                                                                                   return filename.length;
                                                                               });
                                                                               
                                                                               // Mock extra data read (simulate unicode extra field)
                                                                               when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                   Object[] args = invocation.getArguments();
                                                                                   byte[] buf = (byte[]) args[0];
                                                                                   // Create a fake unicode extra field
                                                                                   byte[] extra = new byte[20];
                                                                                   System.arraycopy(new byte[]{0x75, 0x78, 0x08, 0x00}, 0, extra, 0, 4); // Unicode Path Extra Field header
                                                                                   System.arraycopy("test4".getBytes("UTF-8"), 0, extra, 4, 5); // UTF-8 version of name
                                                                                   System.arraycopy(extra, 0, buf, 0, extra.length);
                                                                                   return extra.length;
                                                                               });
                                                                               
                                                                               // Act
                                                                               ZipArchiveEntry result = zais.getNextZipEntry();
                                                                               
                                                                               // Assert
                                                                               assertNotNull(result);
                                                                               assertEquals("test4", result.getName());
                                                                           }

 @Test
                                                           public void testGetNextZipEntry_WithDataDescriptor() throws Exception {
                                                               // Arrange
                                                               InputStream mockInputStream = mock(InputStream.class);
                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                               
                                                               // Get LFH_BUF size via reflection since it's private
                                                               Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
                                                               lfhBufField.setAccessible(true);
                                                               byte[] lfhBuf = new byte[((byte[]) lfhBufField.get(null)).length];
                                                               
                                                               // Setup mock to return valid LFH signature with data descriptor flag set
                                                               byte[] lfhSigBytes = new byte[] {0x50, 0x4b, 0x03, 0x04}; // LFH signature bytes
                                                               System.arraycopy(lfhSigBytes, 0, lfhBuf, 0, 4);
                                                               // Set version made by (platform)
                                                               lfhBuf[4] = 0;
                                                               lfhBuf[5] = 0;
                                                               // Set GPB (data descriptor flag set)
                                                               lfhBuf[6] = 8; // Bit 3 indicates data descriptor
                                                               lfhBuf[7] = 0;
                                                               // Set compression method (STORED)
                                                               lfhBuf[8] = 0; // STORED = 0
                                                               lfhBuf[9] = 0;
                                                               // Set DOS time (simplified)
                                                               for (int i = 10; i < 14; i++) {
                                                                   lfhBuf[i] = 0;
                                                               }
                                                               // Skip CRC, compressed size and size (data descriptor will be used)
                                                               // Set filename length (5) and extra length (0)
                                                               lfhBuf[26] = 5;
                                                               lfhBuf[27] = 0;
                                                               lfhBuf[28] = 0;
                                                               lfhBuf[29] = 0;
                                                               
                                                               when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                   Object[] args = invocation.getArguments();
                                                                   byte[] buf = (byte[]) args[0];
                                                                   System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                                   return lfhBuf.length;
                                                               });
                                                               
                                                               // Mock filename read
                                                               when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                   Object[] args = invocation.getArguments();
                                                                   byte[] buf = (byte[]) args[0];
                                                                   byte[] filename = "test2".getBytes();
                                                                   System.arraycopy(filename, 0, buf, 0, filename.length);
                                                                   return filename.length;
                                                               });
                                                               
                                                               // Act
                                                               ZipArchiveEntry result = zais.getNextZipEntry();
                                                               
                                                               // Assert
                                                               assertNotNull(result);
                                                               assertEquals("test2", result.getName());
                                                               assertTrue(result.getGeneralPurposeBit().usesDataDescriptor());
                                                               assertEquals(-1, result.getCrc());
                                                               assertEquals(-1, result.getSize());
                                                               assertEquals(-1, result.getCompressedSize());
                                                           }

 @Test
                                                   public void testGetNextZipEntry_WithUTF8Flag() throws Exception {
                                                       // Arrange
                                                       InputStream mockInputStream = mock(InputStream.class);
                                                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                       
                                                       // Use reflection to access private LFH_BUF field
                                                       Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
                                                       lfhBufField.setAccessible(true);
                                                       byte[] originalLfhBuf = (byte[]) lfhBufField.get(null);
                                                       byte[] lfhBuf = new byte[originalLfhBuf.length];
                                                       
                                                       // Setup mock to return valid LFH signature with UTF8 flag set
                                                       System.arraycopy(new ZipLong(0x04034b50L).getBytes(), 0, lfhBuf, 0, 4);
                                                       // Set version made by (platform)
                                                       ZipShort versionMadeBy = new ZipShort(0);
                                                       System.arraycopy(versionMadeBy.getBytes(), 0, lfhBuf, 4, 2);
                                                       // Set GPB (UTF8 flag set)
                                                       ZipShort gpb = new ZipShort(1 << 11);
                                                       System.arraycopy(gpb.getBytes(), 0, lfhBuf, 6, 2); // Bit 11 indicates UTF8
                                                       // Set compression method (STORED)
                                                       ZipShort compressionMethod = new ZipShort(0);
                                                       System.arraycopy(compressionMethod.getBytes(), 0, lfhBuf, 8, 2); // 0 = STORED
                                                       // Set DOS time (using fixed value instead of ZipUtil conversion)
                                                       ZipLong dosTime = new ZipLong(0x2100709L); // Fixed DOS time value
                                                       System.arraycopy(dosTime.getBytes(), 0, lfhBuf, 10, 4);
                                                       // Set CRC, compressed size and size (no data descriptor)
                                                       ZipLong crc = new ZipLong(1234L);
                                                       System.arraycopy(crc.getBytes(), 0, lfhBuf, 14, 4);
                                                       ZipLong compressedSize = new ZipLong(100L);
                                                       System.arraycopy(compressedSize.getBytes(), 0, lfhBuf, 18, 4);
                                                       ZipLong size = new ZipLong(100L);
                                                       System.arraycopy(size.getBytes(), 0, lfhBuf, 22, 4);
                                                       // Set filename length (5) and extra length (0)
                                                       ZipShort filenameLength = new ZipShort(5);
                                                       System.arraycopy(filenameLength.getBytes(), 0, lfhBuf, 26, 2);
                                                       ZipShort extraLength = new ZipShort(0);
                                                       System.arraycopy(extraLength.getBytes(), 0, lfhBuf, 28, 2);
                                                       
                                                       when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                                           Object[] args = invocation.getArguments();
                                                           byte[] buf = (byte[]) args[0];
                                                           System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                                           return lfhBuf.length;
                                                       });
                                                       
                                                       // Mock filename read
                                                       when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                           Object[] args = invocation.getArguments();
                                                           byte[] buf = (byte[]) args[0];
                                                           byte[] filename = "test3".getBytes();
                                                           System.arraycopy(filename, 0, buf, 0, filename.length);
                                                           return filename.length;
                                                       });
                                                       
                                                       // Act
                                                       ZipArchiveEntry result = zais.getNextZipEntry();
                                                       
                                                       // Assert
                                                       assertNotNull(result);
                                                       assertEquals("test3", result.getName());
                                                       assertTrue(result.getGeneralPurposeBit().usesUTF8ForNames());
                                                   }

 @Test
                           public void testGetNextZipEntry_FirstEntryWithValidLFH() throws Exception {
                               // Arrange
                               InputStream mockInputStream = mock(InputStream.class);
                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                               
                               // Get LFH_BUF size via reflection since it's private
                               Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
                               lfhBufField.setAccessible(true);
                               byte[] lfhBuf = new byte[((byte[]) lfhBufField.get(null)).length];
                               
                               // Setup mock to return valid LFH signature and other required values
                               System.arraycopy(new byte[] {0x50, 0x4b, 0x03, 0x04}, 0, lfhBuf, 0, 4); // LFH_SIG
                               
                               // Set version made by (platform)
                               lfhBuf[4] = 0;
                               lfhBuf[5] = 0;
                               
                               // Set GPB (no UTF8 flag)
                               lfhBuf[6] = 0;
                               lfhBuf[7] = 0;
                               
                               // Set compression method (STORED)
                               lfhBuf[8] = 0;
                               lfhBuf[9] = 0;
                               
                               // Set DOS time (simplified)
                               long dosTime = System.currentTimeMillis() / 1000;
                               lfhBuf[10] = (byte)(dosTime & 0xff);
                               lfhBuf[11] = (byte)((dosTime >> 8) & 0xff);
                               lfhBuf[12] = (byte)((dosTime >> 16) & 0xff);
                               lfhBuf[13] = (byte)((dosTime >> 24) & 0xff);
                               
                               // Set CRC (1234)
                               lfhBuf[14] = (byte)(1234 & 0xff);
                               lfhBuf[15] = (byte)((1234 >> 8) & 0xff);
                               lfhBuf[16] = (byte)((1234 >> 16) & 0xff);
                               lfhBuf[17] = (byte)((1234 >> 24) & 0xff);
                               
                               // Set compressed size and size (100)
                               lfhBuf[18] = (byte)(100 & 0xff);
                               lfhBuf[19] = (byte)((100 >> 8) & 0xff);
                               lfhBuf[20] = (byte)((100 >> 16) & 0xff);
                               lfhBuf[21] = (byte)((100 >> 24) & 0xff);
                               System.arraycopy(lfhBuf, 18, lfhBuf, 22, 4); // Same value for size
                               
                               // Set filename length (5) and extra length (0)
                               lfhBuf[26] = 5;
                               lfhBuf[27] = 0;
                               lfhBuf[28] = 0;
                               lfhBuf[29] = 0;
                               
                               when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                   System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                                   return lfhBuf.length;
                               });
                               
                               // Mock filename read
                               when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                   byte[] filename = "test1".getBytes();
                                   System.arraycopy(filename, 0, buf, 0, filename.length);
                                   return filename.length;
                               });
                               
                               // Act
                               ZipArchiveEntry result = zais.getNextZipEntry();
                               
                               // Assert
                               assertNotNull(result);
                               assertEquals("test1", result.getName());
                               assertEquals(100L, result.getSize());
                               assertEquals(100L, result.getCompressedSize());
                               assertEquals(1234L, result.getCrc());
                               assertEquals(0, result.getMethod()); // STORED is 0
                           }

 @Test
                       public void testGetNextZipEntry_WhenCentralDirectorySignatureFound_ReturnsNull() throws Exception {
                           // Arrange
                           InputStream mockInputStream = mock(InputStream.class);
                           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                           
                           // Get private LFH_BUF length via reflection
                           Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("LFH_BUF");
                           lfhBufField.setAccessible(true);
                           byte[] lfhBufTemplate = (byte[]) lfhBufField.get(null);
                           byte[] lfhBuf = new byte[lfhBufTemplate.length];
                           
                           // Setup mock to return CFH signature
                           byte[] cfhSigBytes = new byte[] {(byte) 0x50, (byte) 0x4b, (byte) 0x01, (byte) 0x02};
                           System.arraycopy(cfhSigBytes, 0, lfhBuf, 0, cfhSigBytes.length);
                           
                           when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                               Object[] args = invocation.getArguments();
                               byte[] buf = (byte[]) args[0];
                               System.arraycopy(lfhBuf, 0, buf, 0, lfhBuf.length);
                               return lfhBuf.length;
                           });
                           
                           // Act
                           ZipArchiveEntry result = zais.getNextZipEntry();
                           
                           // Assert
                           assertNull(result);
                           
                           // Check private hitCentralDirectory field via reflection
                           Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
                           hitCentralDirectoryField.setAccessible(true);
                           boolean hitCentralDirectory = hitCentralDirectoryField.getBoolean(zais);
                           assertTrue(hitCentralDirectory);
                       }

 @Test
       public void testConstructorBufferInitialization() throws Exception {
           // Create a mock input stream with test data
           byte[] testData = {0x50, 0x4B, 0x03, 0x04}; // Minimal ZIP header
           InputStream mockInput = new ByteArrayInputStream(testData);
           
           // Create the stream and verify buffer initialization
           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
           
           try {
               // Use reflection to access the private buffer field
               java.lang.reflect.Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
               bufField.setAccessible(true);
               byte[] buffer = (byte[]) bufField.get(zais);
               
               // Verify buffer is properly limited to 0
               // This would fail if the mutant (limit(1)) is present
               assertEquals(0, buffer.length);
               
               // Verify this affects subsequent read operations
               // Attempt to read should properly handle empty buffer
               byte[] readBuffer = new byte[10];
               int bytesRead = zais.read(readBuffer);
               assertTrue(bytesRead > 0); // Should read from underlying stream
               
           } finally {
               zais.close();
           }
       }

 @Test
       public void testBufferInitialization() throws Exception {
           // Arrange
           InputStream mockInputStream = mock(InputStream.class);
           String encoding = "UTF-8";
           
           // Act - create the stream which should initialize the buffer
           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream, encoding);
           
           // Assert - verify buffer state through available() method
           // Original behavior should have buffer limit set to 0, meaning no bytes available initially
           assertEquals(0, zais.available());
           
           // Additional verification that we can interact with the stream properly
           byte[] testBuffer = new byte[10];
           assertEquals(-1, zais.read(testBuffer)); // Should return -1 for empty stream
       }

 @Test
       public void testConstructorBufferInitialization1() throws Exception {
           // Setup
           InputStream mockInput = new ByteArrayInputStream(new byte[0]);
           String encoding = "UTF-8";
           boolean useUnicodeExtraFields = true;
           
           // Create instance
           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput, encoding, useUnicodeExtraFields);
           
           // Test buffer state by attempting to read
           // If buffer limit was incorrectly set to 1 (mutant), read operations might behave differently
           byte[] buffer = new byte[10];
           int bytesRead = zais.read(buffer, 0, buffer.length);
           
           // Verify buffer was properly initialized by checking read behavior
           // Original behavior (limit=0) would typically return -1 for empty stream
           // Mutant might try to read 1 byte incorrectly
           assertEquals("Buffer should be properly initialized", -1, bytesRead);
           
           // Additional verification by checking available bytes
           assertEquals("No bytes should be available", 0, zais.available());
       }

 @Test
       public void testBufferInitialization1() throws Exception {
           // Setup
           ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
           String encoding = "UTF-8";
           boolean useUnicodeExtraFields = false;
           boolean allowStoredEntriesWithDataDescriptor = false;
           
           // Create instance
           ZipArchiveInputStream zais = new ZipArchiveInputStream(
               inputStream, 
               encoding, 
               useUnicodeExtraFields, 
               allowStoredEntriesWithDataDescriptor
           );
           
           // Get the buffer field through reflection
           java.lang.reflect.Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
           bufField.setAccessible(true);
           ByteBuffer buf = (ByteBuffer) bufField.get(zais);
           
           // Check buffer limit
           assertEquals("Buffer limit should be initialized to 0", 0, buf.limit());
       }

 @Test
  public void testGetNextZipEntry_ReturnsNullWhenHitCentralDirectory() throws Exception {
      // Setup
      InputStream mockInputStream = mock(InputStream.class);
      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
      
      // Use reflection to set private field hitCentralDirectory to true
      Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
      hitCentralDirectoryField.setAccessible(true);
      hitCentralDirectoryField.set(zais, true);
      
      // Ensure closed is false
      Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
      closedField.setAccessible(true);
      closedField.set(zais, false);
      
      // Test
      ZipArchiveEntry entry = zais.getNextZipEntry();
      
      // Verify
      assertNull("Should return null when hitCentralDirectory is true", entry);
      
      // Clean up
      hitCentralDirectoryField.setAccessible(false);
      closedField.setAccessible(false);
  }

 @Test
 public void testGetNextZipEntry_ReturnsNullWhenClosed() throws Exception {
     // Arrange
     InputStream mockInputStream = mock(InputStream.class);
     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
     
     // Set closed flag to true without hitting central directory
     Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
     closedField.setAccessible(true);
     closedField.setBoolean(zais, true);
     
     Field hitCentralDirectoryField = ZipArchiveInputStream.class.getDeclaredField("hitCentralDirectory");
     hitCentralDirectoryField.setAccessible(true);
     hitCentralDirectoryField.setBoolean(zais, false);
     
     // Act
     ZipArchiveEntry result = zais.getNextZipEntry();
     
     // Assert
     assertNull("Should return null when stream is closed", result);
     
     // Verify no interactions with the stream when closed
     verifyZeroInteractions(mockInputStream);
 }

}
