package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                               public void testGetEntryEncoding_DefaultConstructor() {
                                                                                                                                                                                                                                                                   // Given
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // When
                                                                                                                                                                                                                                                                   String result = factory.getEntryEncoding();
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Then
                                                                                                                                                                                                                                                                   assertNull("Default constructor should set entryEncoding to null", result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testGetEntryEncoding_ConstructorWithEncoding() {
                                                                                                                                                                                                                                                                   // Given
                                                                                                                                                                                                                                                                   String expectedEncoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(expectedEncoding);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // When
                                                                                                                                                                                                                                                                   String result = factory.getEntryEncoding();
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Then
                                                                                                                                                                                                                                                                   assertEquals("Constructor should set entryEncoding correctly", 
                                                                                                                                                                                                                                                                               expectedEncoding, result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testGetEntryEncoding_AfterSetEntryEncoding() {
                                                                                                                                                                                                                                                                   // Given
                                                                                                                                                                                                                                                                   String initialEncoding = "UTF-8";
                                                                                                                                                                                                                                                                   String newEncoding = "ISO-8859-1";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(initialEncoding);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // When
                                                                                                                                                                                                                                                                   factory.setEntryEncoding(newEncoding);
                                                                                                                                                                                                                                                                   String result = factory.getEntryEncoding();
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Then
                                                                                                                                                                                                                                                                   assertEquals("setEntryEncoding should update the entryEncoding", 
                                                                                                                                                                                                                                                                               newEncoding, result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testGetEntryEncoding_MultipleChanges() {
                                                                                                                                                                                                                                                                   // Given
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // When & Then
                                                                                                                                                                                                                                                                   assertEquals("Initial encoding should match constructor", 
                                                                                                                                                                                                                                                                               "UTF-8", factory.getEntryEncoding());
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   factory.setEntryEncoding(null);
                                                                                                                                                                                                                                                                   assertNull("After setting to null, should return null", 
                                                                                                                                                                                                                                                                              factory.getEntryEncoding());
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   factory.setEntryEncoding("ASCII");
                                                                                                                                                                                                                                                                   assertEquals("After setting to ASCII, should return ASCII", 
                                                                                                                                                                                                                                                                                "ASCII", factory.getEntryEncoding());
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testGetEntryEncoding_ThreadSafetyCheck() throws InterruptedException {
                                                                                                                                                                                                                                                                   // Given
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // When (simulate concurrent modification)
                                                                                                                                                                                                                                                                   Thread t1 = new Thread(() -> factory.setEntryEncoding("ISO-8859-1"));
                                                                                                                                                                                                                                                                   Thread t2 = new Thread(() -> factory.setEntryEncoding("ASCII"));
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   t1.start();
                                                                                                                                                                                                                                                                   t2.start();
                                                                                                                                                                                                                                                                   t1.join();
                                                                                                                                                                                                                                                                   t2.join();
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Then
                                                                                                                                                                                                                                                                   String result = factory.getEntryEncoding();
                                                                                                                                                                                                                                                                   assertTrue("Should reflect one of the set values",
                                                                                                                                                                                                                                                                             "ISO-8859-1".equals(result) || "ASCII".equals(result));
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_AR_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ARJ_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ARJ_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   String encoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                                                   // Additional verification could be done here to check encoding was used
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ZIP_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ZIP_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   String encoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_TAR_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_TAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   String encoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_JAR_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_JAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   String encoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_CPIO_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_CPIO_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   String encoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_DUMP_NoEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_DUMP_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   String encoding = "UTF-8";
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_CaseInsensitive() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result1 = factory.createArchiveInputStream("ar", input);
                                                                                                                                                                                                                                                                   ArchiveInputStream result2 = factory.createArchiveInputStream("Ar", input);
                                                                                                                                                                                                                                                                   ArchiveInputStream result3 = factory.createArchiveInputStream("AR", input);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   assertTrue(result1 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                                   assertTrue(result2 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                                   assertTrue(result3 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_AR() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArArchiveOutputStream result = (ArArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.AR, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_ZIP_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ZipArchiveOutputStream result = (ZipArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.ZIP, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_ZIP_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ZipArchiveOutputStream result = (ZipArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.ZIP, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                                   assertEquals("UTF-8", result.getEncoding());
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_TAR_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   TarArchiveOutputStream result = (TarArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.TAR, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_TAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   TarArchiveOutputStream result = (TarArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.TAR, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_JAR_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   JarArchiveOutputStream result = (JarArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.JAR, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_JAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   JarArchiveOutputStream result = (JarArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.JAR, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_CPIO_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   CpioArchiveOutputStream result = (CpioArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.CPIO, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveOutputStream_CPIO_WithEncoding() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   CpioArchiveOutputStream result = (CpioArchiveOutputStream) factory.createArchiveOutputStream(
                                                                                                                                                                                                                                                                       ArchiveStreamFactory.CPIO, out);
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                               public void testCreateArchiveInputStream_TarArchive() throws Exception {
                                                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                                   InputStream in = mock(InputStream.class);
                                                                                                                                                                                                                                                                   when(in.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // First 12 bytes don't match any known format
                                                                                                                                                                                                                                                                   when(IOUtils.readFully(in, any(byte[].class)))
                                                                                                                                                                                                                                                                       .thenReturn(12)  // First read
                                                                                                                                                                                                                                                                       .thenReturn(32)  // Dump check
                                                                                                                                                                                                                                                                       .thenReturn(512); // Tar check
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Mock TAR header
                                                                                                                                                                                                                                                                   byte[] tarHeader = new byte[512];
                                                                                                                                                                                                                                                                   when(TarArchiveInputStream.matches(tarHeader, 512)).thenReturn(true);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                                                                                                                                                                                   assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_NullArchiverName() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                               factory.createArchiveInputStream(null, input);
                                                                                                                                                                                                                                                               fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                               assertEquals("Archivername must not be null.", e.getMessage());
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_NullInputStream() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                               factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                                                                                                                                                               fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                               assertEquals("InputStream must not be null.", e.getMessage());
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_SEVEN_Z() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Define expected exception rule
                                                                                                                                                                                                                                                           ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                           expectedException.expect(org.apache.commons.compress.archivers.StreamingNotSupportedException.class);
                                                                                                                                                                                                                                                           expectedException.expectMessage("7z");
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           factory.createArchiveInputStream("7z", input);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_UnknownArchiver() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                           String unknownArchiver = "UNKNOWN";
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                               factory.createArchiveInputStream(unknownArchiver, input);
                                                                                                                                                                                                                                                               fail("Expected ArchiveException to be thrown");
                                                                                                                                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                                                                                                                                               assertEquals("Archiver: " + unknownArchiver + " not found.", e.getMessage());
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveOutputStream_NullArchiverName() throws Exception {
                                                                                                                                                                                                                                                           ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                           expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                           expectedException.expectMessage("Archivername must not be null.");
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                           factory.createArchiveOutputStream(null, out);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveOutputStream_NullOutputStream() throws Exception {
                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                               factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, null);
                                                                                                                                                                                                                                                               fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                               assertEquals("OutputStream must not be null.", e.getMessage());
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveOutputStream_UnknownArchiver() throws Exception {
                                                                                                                                                                                                                                                           ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                           expectedException.expect(ArchiveException.class);
                                                                                                                                                                                                                                                           expectedException.expectMessage("Archiver: UNKNOWN not found.");
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                           factory.createArchiveOutputStream("UNKNOWN", out);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_NoMarkSupport() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           InputStream in = mock(InputStream.class);
                                                                                                                                                                                                                                                           when(in.markSupported()).thenReturn(false);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                           expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                           expectedException.expectMessage("Mark is not supported.");
                                                                                                                                                                                                                                                           factory.createArchiveInputStream(in);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_ZipArchive() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           InputStream in = mock(InputStream.class);
                                                                                                                                                                                                                                                           when(in.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Mock ZIP signature
                                                                                                                                                                                                                                                           byte[] zipSignature = new byte[12];
                                                                                                                                                                                                                                                           byte[] zipSig = new byte[] {0x50, 0x4B, 0x03, 0x04}; // ZIP signature bytes
                                                                                                                                                                                                                                                           System.arraycopy(zipSig, 0, zipSignature, 0, 4);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(IOUtils.readFully(in, any(byte[].class))).thenReturn(12);
                                                                                                                                                                                                                                                           when(ZipArchiveInputStream.matches(zipSignature, 12)).thenReturn(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                                                                                                                                                                           assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_UnknownFormat() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                           InputStream in = mock(InputStream.class);
                                                                                                                                                                                                                                                           when(in.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(IOUtils.readFully(in, any(byte[].class)))
                                                                                                                                                                                                                                                               .thenReturn(12)  // First read
                                                                                                                                                                                                                                                               .thenReturn(32)   // Dump check
                                                                                                                                                                                                                                                               .thenReturn(512); // Tar check
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                               factory.createArchiveInputStream(in);
                                                                                                                                                                                                                                                               fail("Expected ArchiveException");
                                                                                                                                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                                                                                                                                               assertEquals("No Archiver found for the stream signature", e.getMessage());
                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testCreateArchiveInputStream_WithEntryEncoding() throws Exception {
                                                                                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                                           InputStream in = mock(InputStream.class);
                                                                                                                                                                                                                                                           when(in.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Mock ZIP signature (0x504B0304)
                                                                                                                                                                                                                                                           byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(IOUtils.readFully(in, any(byte[].class))).thenReturn(12);
                                                                                                                                                                                                                                                           when(ZipArchiveInputStream.matches(zipSignature, 12)).thenReturn(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                                                                                                                                                                           assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                                           // Additional verification could be done here to check encoding was passed through
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_SEVEN_Z() throws Exception {
                                                                                                                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       expectedException.expect(StreamingNotSupportedException.class);
                                                                                                                                                                                                                                                       expectedException.expectMessage(ArchiveStreamFactory.SEVEN_Z);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                                       factory.createArchiveOutputStream(ArchiveStreamFactory.SEVEN_Z, out);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_NullStream() throws Exception {
                                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                       expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                       expectedException.expectMessage("Stream must not be null.");
                                                                                                                                                                                                                                                       factory.createArchiveInputStream(null);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_IOException() throws Exception {
                                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                                       InputStream in = mock(InputStream.class);
                                                                                                                                                                                                                                                       when(in.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       doThrow(new IOException("Test exception")).when(in).mark(anyInt());
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                                                           factory.createArchiveInputStream(in);
                                                                                                                                                                                                                                                           fail("Expected ArchiveException");
                                                                                                                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                                                                                                                           assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                               public void testCreateArchiveInputStream_SevenZArchive() throws Exception {
                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                   org.apache.commons.compress.archivers.ArchiveStreamFactory factory = new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Mock SevenZ signature check
                                                                                                                                                                                                                   byte[] sevenZSignature = new byte[]{(byte) 0x37, (byte) 0x7A, (byte) 0xBC, (byte) 0xAF, (byte) 0x27, (byte) 0x1C};
                                                                                                                                                                                                                   InputStream in = new java.io.ByteArrayInputStream(sevenZSignature) {
                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                       public int read(byte[] buffer) throws IOException {
                                                                                                                                                                                                                           System.arraycopy(sevenZSignature, 0, buffer, 0, sevenZSignature.length);
                                                                                                                                                                                                                           return sevenZSignature.length;
                                                                                                                                                                                                                       }
                                                                                                                                                                                                                   };
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Verify exception
                                                                                                                                                                                                                   Exception exception = null;
                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                       factory.createArchiveInputStream(in);
                                                                                                                                                                                                                   } catch (org.apache.commons.compress.archivers.StreamingNotSupportedException e) {
                                                                                                                                                                                                                       exception = e;
                                                                                                                                                                                                                   }
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   org.junit.Assert.assertNotNull(exception);
                                                                                                                                                                                                                   org.junit.Assert.assertEquals(org.apache.commons.compress.archivers.ArchiveStreamFactory.SEVEN_Z, exception.getMessage());
                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                       public void testCreateArchiveInputStream_JarArchive() throws Exception {
                                                                                                                                                                           org.apache.commons.compress.archivers.ArchiveStreamFactory factory = new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                                                                                                           
                                                                                                                                                                           // Mock JAR signature (same as ZIP)
                                                                                                                                                                           byte[] jarSignature = new byte[12];
                                                                                                                                                                           byte[] zipSignature = new byte[] {0x50, 0x4b, 0x03, 0x04}; // Standard ZIP signature
                                                                                                                                                                           System.arraycopy(zipSignature, 0, jarSignature, 0, 4);
                                                                                                                                                                           
                                                                                                                                                                           // Create input stream with the mock signature
                                                                                                                                                                           java.io.ByteArrayInputStream in = new java.io.ByteArrayInputStream(jarSignature);
                                                                                                                                                                           
                                                                                                                                                                           org.apache.commons.compress.archivers.ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                                                                                           
                                                                                                                                                                           // Verify the result is not null (basic assertion)
                                                                                                                                                                           assertNotNull(result);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                   public void testCreateArchiveInputStream_AR_CaseInsensitive() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                       
                                                                                                                                                                       // Test with different case variations that should all work in original
                                                                                                                                                                       String[] testCases = {"ar", "AR", "Ar", "aR"};
                                                                                                                                                                       
                                                                                                                                                                       for (String archiverName : testCases) {
                                                                                                                                                                           try {
                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(archiverName, mockInput);
                                                                                                                                                                               assertNotNull("Should return stream for AR format: " + archiverName, result);
                                                                                                                                                                               assertTrue("Should return ArArchiveInputStream for: " + archiverName, 
                                                                                                                                                                                         result instanceof ArArchiveInputStream);
                                                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                                                               fail("Should not throw exception for valid AR format: " + archiverName);
                                                                                                                                                                           }
                                                                                                                                                                       }
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testCreateArchiveInputStreamWithARShouldBeCaseInsensitive() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                       
                                                                                                                                                                       // Test different case variations of "AR"
                                                                                                                                                                       String[] testCases = {"AR", "ar", "Ar", "aR"};
                                                                                                                                                                       
                                                                                                                                                                       for (String testCase : testCases) {
                                                                                                                                                                           // Exercise
                                                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                                                                                                                                                                           
                                                                                                                                                                           // Verify
                                                                                                                                                                           assertNotNull("Should return a stream for AR archive (case: " + testCase + ")", result);
                                                                                                                                                                           assertTrue("Should return an ArArchiveInputStream for AR archive", 
                                                                                                                                                                                     result instanceof ArArchiveInputStream);
                                                                                                                                                                       }
                                                                                                                                                                       
                                                                                                                                                                       // Also verify that completely wrong names throw exceptions
                                                                                                                                                                       try {
                                                                                                                                                                           factory.createArchiveInputStream("not_an_archive", mockInput);
                                                                                                                                                                           fail("Should throw IllegalArgumentException for unknown archive type");
                                                                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                                                                           // expected
                                                                                                                                                                       }
                                                                                                                                                                   }

    @Test
                                                                                                                                                                  public void testCreateArchiveInputStream_AR_ShouldUseProvidedInputStream() throws Exception {
                                                                                                                                                                      // Arrange
                                                                                                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                      
                                                                                                                                                                      // Act
                                                                                                                                                                      ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                                                      
                                                                                                                                                                      // Assert
                                                                                                                                                                      assertNotNull("Result should not be null", result);
                                                                                                                                                                      assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                                                                                                                      
                                                                                                                                                                      // Verify the input stream was properly passed to the constructor
                                                                                                                                                                      // This is the key assertion that will catch the mutant
                                                                                                                                                                      try {
                                                                                                                                                                          // Try to read from the stream to ensure it was constructed properly
                                                                                                                                                                          // The mutant would throw NullPointerException here
                                                                                                                                                                          result.read();
                                                                                                                                                                      } catch (NullPointerException e) {
                                                                                                                                                                          fail("ArArchiveInputStream was created with null input stream (mutant detected)");
                                                                                                                                                                      }
                                                                                                                                                                  }

    @Test
                                                                                                                                             public void testCreateArchiveInputStreamForArFormat() throws Exception {
                                                                                                                                                 // Prepare AR format signature
                                                                                                                                                 byte[] arSignature = new byte[12];
                                                                                                                                                 // AR format magic numbers
                                                                                                                                                 System.arraycopy("!<arch>\n".getBytes(), 0, arSignature, 0, 8);
                                                                                                                                                 
                                                                                                                                                 // Create mock input stream that returns AR signature
                                                                                                                                                 InputStream mockIn = mock(InputStream.class);
                                                                                                                                                 when(mockIn.markSupported()).thenReturn(true);
                                                                                                                                                 when(mockIn.read(any(byte[].class)))
                                                                                                                                                     .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                         @Override
                                                                                                                                                         public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                             byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                             System.arraycopy(arSignature, 0, buf, 0, Math.min(arSignature.length, buf.length));
                                                                                                                                                             return arSignature.length;
                                                                                                                                                         }
                                                                                                                                                     });
                                                                                                                                                 
                                                                                                                                                 // Create factory instance
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 
                                                                                                                                                 // Test the method
                                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                                                                                 
                                                                                                                                                 // Verify it's an ArArchiveInputStream
                                                                                                                                                 assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                 
                                                                                                                                                 // Try to read from the stream to verify it was constructed with the correct input
                                                                                                                                                 // This will fail if null was passed to constructor
                                                                                                                                                 try {
                                                                                                                                                     result.read();
                                                                                                                                                 } catch (NullPointerException e) {
                                                                                                                                                     fail("ArArchiveInputStream was constructed with null input stream");
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 // Verify the mock input stream was used as expected
                                                                                                                                                 verify(mockIn, atLeastOnce()).mark(anyInt());
                                                                                                                                                 verify(mockIn, atLeastOnce()).reset();
                                                                                                                                             }

    @Test
                                                                                                                                             public void testCreateArchiveInputStream_ARJ() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 String archiverName = ArchiveStreamFactory.ARJ;
                                                                                                                                                 InputStream inputStream = mock(InputStream.class);
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 
                                                                                                                                                 // Test
                                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertNotNull("Result should not be null", result);
                                                                                                                                                 assertTrue("Should return ArjArchiveInputStream for ARJ format", 
                                                                                                                                                            result instanceof ArjArchiveInputStream);
                                                                                                                                             }

    @Test
                                                                                                                                             public void testCreateArchiveInputStream_ARJ_WithEncoding1() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 String archiverName = ArchiveStreamFactory.ARJ;
                                                                                                                                                 String encoding = "UTF-8";
                                                                                                                                                 InputStream inputStream = mock(InputStream.class);
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 factory.setEntryEncoding(encoding);
                                                                                                                                                 
                                                                                                                                                 // Test
                                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertNotNull("Result should not be null", result);
                                                                                                                                                 assertTrue("Should return ArjArchiveInputStream for ARJ format with encoding", 
                                                                                                                                                            result instanceof ArjArchiveInputStream);
                                                                                                                                             }

    @Test
                                                                                                                                         public void testCreateArchiveInputStreamWithARJFormat() throws Exception {
                                                                                                                                             // Setup
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             InputStream inputStream = mock(InputStream.class);
                                                                                                                                             
                                                                                                                                             // Mock behavior to simulate ARJ format
                                                                                                                                             when(inputStream.markSupported()).thenReturn(true);
                                                                                                                                             
                                                                                                                                             // Test
                                                                                                                                             ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, inputStream);
                                                                                                                                             
                                                                                                                                             // Verify
                                                                                                                                             assertNotNull("Result should not be null", result);
                                                                                                                                             assertTrue("Should return ArjArchiveInputStream for ARJ format", 
                                                                                                                                                        result instanceof ArjArchiveInputStream);
                                                                                                                                             
                                                                                                                                             // Verify interaction with the stream
                                                                                                                                             verify(inputStream).markSupported();
                                                                                                                                         }

    @Test
                                                                                                                                            public void testCreateArchiveInputStream_ZipCaseInsensitive() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                
                                                                                                                                                // Test with lowercase "zip" which should work in original but fail in mutant
                                                                                                                                                String lowerCaseZip = "zip";
                                                                                                                                                
                                                                                                                                                // Exercise
                                                                                                                                                try {
                                                                                                                                                    Object result = factory.createArchiveInputStream(lowerCaseZip, inputStream);
                                                                                                                                                    
                                                                                                                                                    // Verify - should be ZipArchiveInputStream for original code
                                                                                                                                                    assertTrue("Should return ZipArchiveInputStream for 'zip'", 
                                                                                                                                                              result instanceof ZipArchiveInputStream);
                                                                                                                                                } catch (ArchiveException e) {
                                                                                                                                                    fail("Original code should handle case-insensitive ZIP matching");
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Additional case variations to be thorough
                                                                                                                                                String mixedCaseZip = "Zip";
                                                                                                                                                try {
                                                                                                                                                    Object result = factory.createArchiveInputStream(mixedCaseZip, inputStream);
                                                                                                                                                    assertTrue("Should return ZipArchiveInputStream for 'Zip'",
                                                                                                                                                              result instanceof ZipArchiveInputStream);
                                                                                                                                                } catch (ArchiveException e) {
                                                                                                                                                    fail("Original code should handle case-insensitive ZIP matching");
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                        public void testCreateArchiveInputStreamWithZipIgnoresCase() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                            InputStream mockInput = mock(InputStream.class);
                                                                                                                                            
                                                                                                                                            // Test with lowercase "zip" - should work with original but fail with mutant
                                                                                                                                            try {
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream("zip", mockInput);
                                                                                                                                                assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                            } catch (ArchiveException e) {
                                                                                                                                                fail("Case-insensitive ZIP matching failed - mutant detected");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Test with mixed case "Zip" - should work with original but fail with mutant
                                                                                                                                            try {
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream("Zip", mockInput);
                                                                                                                                                assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                            } catch (ArchiveException e) {
                                                                                                                                                fail("Case-insensitive ZIP matching failed - mutant detected");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Test with uppercase "ZIP" - should work with both
                                                                                                                                            try {
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream("ZIP", mockInput);
                                                                                                                                                assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                            } catch (ArchiveException e) {
                                                                                                                                                fail("Unexpected exception for uppercase ZIP");
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                       public void testCreateZipArchiveInputStreamWithEncoding() throws Exception {
                                                                                                                                           // Setup
                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                                                                           
                                                                                                                                           // Test
                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                                                                                                                           
                                                                                                                                           // Verify
                                                                                                                                           assertNotNull(result);
                                                                                                                                           assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // This is the key assertion to catch the mutant
                                                                                                                                           // The original code should pass encoding to the constructor when available
                                                                                                                                           // The mutant would ignore the encoding
                                                                                                                                           // We can verify by checking the encoding was actually used
                                                                                                                                           assertEquals("UTF-8", factory.getEntryEncoding());
                                                                                                                                           
                                                                                                                                           // Alternative verification if we can access the encoding from the stream
                                                                                                                                           // (assuming ZipArchiveInputStream has a way to get its encoding)
                                                                                                                                           if (result instanceof ZipArchiveInputStream) {
                                                                                                                                               try {
                                                                                                                                                   Field encodingField = ZipArchiveInputStream.class.getDeclaredField("encoding");
                                                                                                                                                   encodingField.setAccessible(true);
                                                                                                                                                   String actualEncoding = (String) encodingField.get(result);
                                                                                                                                                   assertEquals("UTF-8", actualEncoding);
                                                                                                                                               } catch (NoSuchFieldException e) {
                                                                                                                                                   // If we can't access the field directly, rely on the factory's encoding
                                                                                                                                                   assertEquals("UTF-8", factory.getEntryEncoding());
                                                                                                                                               }
                                                                                                                                           }
                                                                                                                                       }

    @Test
                                                                                                      public void testCreateZipArchiveInputStreamWithEncoding1() throws Exception {
                                                                                                          // Setup
                                                                                                          String testEncoding = "UTF-8";
                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                                          
                                                                                                          // Mock input stream that returns ZIP signature
                                                                                                          InputStream in = mock(InputStream.class);
                                                                                                          byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04}; // ZIP signature
                                                                                                          when(in.markSupported()).thenReturn(true);
                                                                                                          when(in.read(any(byte[].class)))
                                                                                                              .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                  @Override
                                                                                                                  public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                      byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                      System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                                                      return zipSignature.length;
                                                                                                                  }
                                                                                                              });
                                                                                                          
                                                                                                          // Execute
                                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                          
                                                                                                          // Verify
                                                                                                          assertNotNull(result);
                                                                                                          assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                      }

    @Test
                                                                                                      public void testCreateArchiveInputStream_TarCaseInsensitive() throws Exception {
                                                                                                          // Setup
                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                          String tarName = "tar"; // Lowercase version of TAR constant
                                                                                                          
                                                                                                          // Test
                                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(tarName, mockInput);
                                                                                                          
                                                                                                          // Verify
                                                                                                          assertNotNull("Should return a stream for case-insensitive TAR match", result);
                                                                                                          assertTrue("Should return TarArchiveInputStream for TAR format", 
                                                                                                                    result instanceof TarArchiveInputStream);
                                                                                                      }

    @Test(expected = ArchiveException.class)
                                                                                                      public void testCreateArchiveInputStream_TarCaseSensitiveWithMutant() throws Exception {
                                                                                                          // This test would pass with the mutant but fail with original code
                                                                                                          // Setup mutant version that uses equals() instead of equalsIgnoreCase()
                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory() {
                                                                                                              @Override
                                                                                                              public ArchiveInputStream createArchiveInputStream(String archiverName, InputStream in) 
                                                                                                                  throws ArchiveException {
                                                                                                                  if (TAR.equals(archiverName)) { // Mutated version
                                                                                                                      return new TarArchiveInputStream(in);
                                                                                                                  }
                                                                                                                  throw new ArchiveException("Archiver: " + archiverName + " not found.");
                                                                                                              }
                                                                                                          };
                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                          String tarName = "tar"; // Lowercase version of TAR constant
                                                                                                          
                                                                                                          // Test - should throw ArchiveException with mutant
                                                                                                          factory.createArchiveInputStream(tarName, mockInput);
                                                                                                      }

    @Test
                                                                                                  public void testCreateArchiveInputStreamWithTarShouldBeCaseInsensitive() throws Exception {
                                                                                                      // Setup
                                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                                      
                                                                                                      // Test different case variations of "TAR"
                                                                                                      String[] testCases = {"TAR", "tar", "Tar", "tAr"};
                                                                                                      
                                                                                                      for (String testCase : testCases) {
                                                                                                          try {
                                                                                                              // This should work in original code but fail with mutant
                                                                                                              ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                                                                                                              assertNotNull("Should create input stream for case: " + testCase, result);
                                                                                                              assertTrue("Should return TarArchiveInputStream for case: " + testCase, 
                                                                                                                        result instanceof TarArchiveInputStream);
                                                                                                          } catch (ArchiveException e) {
                                                                                                              fail("Should accept case variation: " + testCase);
                                                                                                          }
                                                                                                      }
                                                                                                  }

    @Test
                                                                                                     public void testCreateTarArchiveInputStreamWithCustomEncoding() throws Exception {
                                                                                                         // Setup
                                                                                                         String customEncoding = "ISO-8859-1";
                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                         factory.setEntryEncoding(customEncoding);
                                                                                                         InputStream mockInput = mock(InputStream.class);
                                                                                                         
                                                                                                         // Execute
                                                                                                         TarArchiveInputStream result = (TarArchiveInputStream) factory.createArchiveInputStream(
                                                                                                             ArchiveStreamFactory.TAR, mockInput);
                                                                                                         
                                                                                                         // Verify encoding using reflection
                                                                                                         Field encodingField = TarArchiveInputStream.class.getDeclaredField("encoding");
                                                                                                         encodingField.setAccessible(true);
                                                                                                         String actualEncoding = (String) encodingField.get(result);
                                                                                                         
                                                                                                         // Assert
                                                                                                         assertEquals("TarArchiveInputStream should use specified encoding", 
                                                                                                             customEncoding, actualEncoding);
                                                                                                     }

    @Test
                                                                                                public void testCreateArchiveInputStreamForTarWithCustomEncoding() throws Exception {
                                                                                                    // Setup
                                                                                                    String customEncoding = "ISO-8859-1";
                                                                                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                    factory.setEntryEncoding(customEncoding);
                                                                                                    
                                                                                                    // Create a mock input stream that will identify as TAR
                                                                                                    InputStream in = mock(InputStream.class);
                                                                                                    when(in.markSupported()).thenReturn(true);
                                                                                                    
                                                                                                    // Setup signature reading for TAR
                                                                                                    byte[] tarSignature = new byte[512];
                                                                                                    // TAR signature (ustar)
                                                                                                    System.arraycopy(new byte[] { 'u', 's', 't', 'a', 'r' }, 0, tarSignature, 257, 5);
                                                                                                    when(IOUtils.readFully(in, any(byte[].class)))
                                                                                                        .thenAnswer(invocation -> {
                                                                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                            System.arraycopy(tarSignature, 0, buf, 0, Math.min(tarSignature.length, buf.length));
                                                                                                            return tarSignature.length;
                                                                                                        });
                                                                                                    
                                                                                                    // Execute
                                                                                                    ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertTrue(result instanceof TarArchiveInputStream);
                                                                                                    TarArchiveInputStream tarStream = (TarArchiveInputStream) result;
                                                                                                    
                                                                                                    // This is the key assertion that would catch the mutant
                                                                                                    // The mutant would hardcode UTF-8 while original would use customEncoding
                                                                                                    Field encodingField = TarArchiveInputStream.class.getDeclaredField("encoding");
                                                                                                    encodingField.setAccessible(true);
                                                                                                    String actualEncoding = (String) encodingField.get(tarStream);
                                                                                                    assertEquals(customEncoding, actualEncoding);
                                                                                                }

    @Test
                                                                                            public void testCreateArchiveInputStream_JarFormat_ReturnsJarArchiveInputStream() throws Exception {
                                                                                                // Setup
                                                                                                String archiverName = ArchiveStreamFactory.JAR;
                                                                                                InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                String encoding = "UTF-8";
                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                
                                                                                                // Test with encoding
                                                                                                ArchiveInputStream resultWithEncoding = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                                assertTrue("Should return JarArchiveInputStream when JAR format specified", 
                                                                                                           resultWithEncoding instanceof JarArchiveInputStream);
                                                                                                
                                                                                                // Test without encoding
                                                                                                factory.setEntryEncoding(null);
                                                                                                ArchiveInputStream resultWithoutEncoding = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                                assertTrue("Should return JarArchiveInputStream when JAR format specified without encoding", 
                                                                                                           resultWithoutEncoding instanceof JarArchiveInputStream);
                                                                                            }

    @Test(expected = ArchiveException.class)
                                                                                            public void testCreateArchiveInputStream_JarFormatWithMutant_ThrowsException() throws Exception {
                                                                                                // This test would pass with the mutant but fail with original code
                                                                                                // Included to show what the mutant behavior would be
                                                                                                String archiverName = ArchiveStreamFactory.JAR;
                                                                                                InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                
                                                                                                // This should throw ArchiveException with the mutant
                                                                                                factory.createArchiveInputStream(archiverName, inputStream);
                                                                                            }

    @Test
                                                                                           public void testCreateArchiveInputStreamForJar() throws Exception {
                                                                                               // Setup
                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                               when(inputStream.markSupported()).thenReturn(true);
                                                                                               
                                                                                               // Mock the behavior to simulate JAR signature
                                                                                               byte[] jarSignature = new byte[12];
                                                                                               when(IOUtils.readFully(inputStream, any(byte[].class)))
                                                                                                   .thenAnswer(invocation -> {
                                                                                                       byte[] buf = (byte[]) invocation.getArguments()[1];
                                                                                                       System.arraycopy(jarSignature, 0, buf, 0, Math.min(jarSignature.length, buf.length));
                                                                                                       return jarSignature.length;
                                                                                                   });
                                                                                               when(JarArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                                                                               
                                                                                               // Test
                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, inputStream);
                                                                                               
                                                                                               // Verify
                                                                                               assertNotNull("Result should not be null", result);
                                                                                               assertTrue("Should return JarArchiveInputStream", 
                                                                                                          result instanceof JarArchiveInputStream);
                                                                                               
                                                                                               // Verify stream interactions
                                                                                               verify(inputStream).mark(anyInt());
                                                                                               verify(inputStream, atLeastOnce()).reset();
                                                                                           }

    @Test
                                                                                           public void testCreateArchiveInputStream_CPIO_CaseInsensitive() throws Exception {
                                                                                               // Setup
                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                               InputStream in = new ByteArrayInputStream(new byte[0]);
                                                                                               String lowerCaseCpio = "cpio";  // lower case version
                                                                                               
                                                                                               // Test
                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(lowerCaseCpio, in);
                                                                                               
                                                                                               // Verify
                                                                                               assertNotNull("Should return a stream for case-insensitive CPIO", result);
                                                                                               assertEquals("Should return CpioArchiveInputStream", 
                                                                                                           CpioArchiveInputStream.class, result.getClass());
                                                                                           }

    @Test
                                                                                           public void testCreateArchiveInputStream_CPIO_MixedCase() throws Exception {
                                                                                               // Setup
                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                               InputStream in = new ByteArrayInputStream(new byte[0]);
                                                                                               String mixedCaseCpio = "CpIo";  // mixed case version
                                                                                               
                                                                                               // Test
                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(mixedCaseCpio, in);
                                                                                               
                                                                                               // Verify
                                                                                               assertNotNull("Should return a stream for mixed-case CPIO", result);
                                                                                               assertEquals("Should return CpioArchiveInputStream", 
                                                                                                           CpioArchiveInputStream.class, result.getClass());
                                                                                           }

    @Test
                                                                                       public void testCreateArchiveInputStreamWithCpioCaseVariations() throws Exception {
                                                                                           // Setup
                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                           InputStream inputStream = mock(InputStream.class);
                                                                                           when(inputStream.markSupported()).thenReturn(true);
                                                                                           
                                                                                           // Mock the CPIO signature check to return true
                                                                                           byte[] signature = new byte[12];
                                                                                           when(IOUtils.readFully(inputStream, signature)).thenReturn(signature.length);
                                                                                           when(CpioArchiveInputStream.matches(signature, signature.length)).thenReturn(true);
                                                                                           
                                                                                           // Test different case variations that should work with equalsIgnoreCase
                                                                                           String[] testCases = {"CPIO", "Cpio", "cpio", "cPiO"};
                                                                                           
                                                                                           for (String testCase : testCases) {
                                                                                               try {
                                                                                                   // Exercise
                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(testCase, inputStream);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull("Should return a stream for case variation: " + testCase, result);
                                                                                                   assertTrue("Should return CpioArchiveInputStream for case variation: " + testCase, 
                                                                                                             result instanceof CpioArchiveInputStream);
                                                                                                   
                                                                                                   // Reset mock for next iteration
                                                                                                   reset(inputStream);
                                                                                                   when(inputStream.markSupported()).thenReturn(true);
                                                                                               } catch (ArchiveException e) {
                                                                                                   fail("Should not throw exception for valid case variation: " + testCase);
                                                                                               }
                                                                                           }
                                                                                       }

    @Test
                                                                                          public void testCreateArchiveInputStream_DUMP_CaseInsensitive() throws Exception {
                                                                                              // Setup
                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                              InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                              
                                                                                              // Test with lowercase "dump" which should work in original but fail in mutant
                                                                                              String archiverName = "dump";  // lowercase version
                                                                                              
                                                                                              // Execute
                                                                                              ArchiveInputStream result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                              
                                                                                              // Verify
                                                                                              assertNotNull("Should return a stream for case-insensitive DUMP format", result);
                                                                                              assertTrue("Should return DumpArchiveInputStream", result instanceof DumpArchiveInputStream);
                                                                                          }

    @Test
                                                                                          public void testCreateArchiveInputStream_DUMP_MixedCase() throws Exception {
                                                                                              // Setup
                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                              InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                              
                                                                                              // Test with mixed case "Dump" which should work in original but fail in mutant
                                                                                              String archiverName = "Dump";  // mixed case version
                                                                                              
                                                                                              // Execute
                                                                                              ArchiveInputStream result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                              
                                                                                              // Verify
                                                                                              assertNotNull("Should return a stream for case-insensitive DUMP format", result);
                                                                                              assertTrue("Should return DumpArchiveInputStream", result instanceof DumpArchiveInputStream);
                                                                                          }

    @Test
                                                                                      public void testCreateArchiveInputStreamWithDumpArchiverNameCaseInsensitive() throws Exception {
                                                                                          // Setup
                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                          InputStream inputStream = mock(InputStream.class);
                                                                                          
                                                                                          // Test with different case variations of "DUMP"
                                                                                          // Should work with all cases when using equalsIgnoreCase
                                                                                          String[] testCases = {"DUMP", "dump", "Dump"};
                                                                                          
                                                                                          for (String archiverName : testCases) {
                                                                                              try {
                                                                                                  ArchiveInputStream result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                                  assertNotNull("Should create stream for archiverName: " + archiverName, result);
                                                                                                  assertTrue("Should be DumpArchiveInputStream for " + archiverName, 
                                                                                                            result instanceof DumpArchiveInputStream);
                                                                                              } catch (ArchiveException e) {
                                                                                                  fail("Should not throw exception for valid archiver name: " + archiverName);
                                                                                              }
                                                                                          }
                                                                                      }

    @Test
                                                                                    public void testCreateArchiveInputStreamForSevenZShouldThrowException() throws Exception {
                                                                                        // Setup
                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                        
                                                                                        // Expect exception
                                                                                        ExpectedException expectedException = ExpectedException.none();
                                                                                        expectedException.expect(StreamingNotSupportedException.class);
                                                                                        expectedException.expectMessage(ArchiveStreamFactory.SEVEN_Z);
                                                                                        
                                                                                        // Test
                                                                                        factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, mockInputStream);
                                                                                    }

    @Test(expected = ArchiveException.class)
                                                                                    public void testCreateArchiveInputStream_SevenZSignature_ShouldThrowException() throws Exception {
                                                                                        // Arrange
                                                                                        InputStream input = mock(InputStream.class);
                                                                                        when(input.markSupported()).thenReturn(true);
                                                                                        
                                                                                        // Setup 7z signature
                                                                                        byte[] sevenZSignature = new byte[12];
                                                                                        // Fill with actual 7z signature bytes (simplified for example)
                                                                                        System.arraycopy(new byte[] {0x37, 0x7A, (byte)0xBC, (byte)0xAF, 0x27, 0x1C}, 0, sevenZSignature, 0, 6);
                                                                                        
                                                                                        when(IOUtils.readFully(input, any(byte[].class)))
                                                                                            .thenAnswer(invocation -> {
                                                                                                byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                System.arraycopy(sevenZSignature, 0, buffer, 0, Math.min(sevenZSignature.length, buffer.length));
                                                                                                return sevenZSignature.length;
                                                                                            });
                                                                                        
                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                        
                                                                                        // Act & Assert
                                                                                        factory.createArchiveInputStream(input);
                                                                                    }

    @Test
                                                                                    public void testCreateArchiveInputStream_AR_CaseInsensitive1() throws Exception {
                                                                                        // Setup
                                                                                        String arUpper = "AR";  // Upper case variation
                                                                                        String arLower = "ar";  // Lower case variation (likely matches AR constant)
                                                                                        String arMixed = "Ar";  // Mixed case variation
                                                                                        InputStream inputStream = mock(InputStream.class);
                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                        
                                                                                        // Test all case variations should return ArArchiveInputStream
                                                                                        assertTrue(factory.createArchiveInputStream(arUpper, inputStream) instanceof ArArchiveInputStream);
                                                                                        assertTrue(factory.createArchiveInputStream(arLower, inputStream) instanceof ArArchiveInputStream);
                                                                                        assertTrue(factory.createArchiveInputStream(arMixed, inputStream) instanceof ArArchiveInputStream);
                                                                                    }

    @Test
                                                                                public void testCreateArchiveInputStreamWithArIgnoresCase() throws Exception {
                                                                                    // Setup
                                                                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                    InputStream input = mock(InputStream.class);
                                                                                    when(input.markSupported()).thenReturn(true);
                                                                                    
                                                                                    // Mock the signature reading for AR format
                                                                                    byte[] arSignature = new byte[12];
                                                                                    when(IOUtils.readFully(input, arSignature)).thenReturn(12);
                                                                                    when(ArArchiveInputStream.matches(arSignature, 12)).thenReturn(true);
                                                                                    
                                                                                    // Test with different case variations
                                                                                    assertNotNull(factory.createArchiveInputStream("AR", input));
                                                                                    assertNotNull(factory.createArchiveInputStream("ar", input));
                                                                                    assertNotNull(factory.createArchiveInputStream("Ar", input));
                                                                                    assertNotNull(factory.createArchiveInputStream("aR", input));
                                                                                    
                                                                                    // Verify the input stream interactions
                                                                                    verify(input, times(4)).mark(anyInt());
                                                                                    verify(input, times(4)).reset();
                                                                                }

    @Test
                                                                                   public void testCreateArArchiveInputStreamWithValidStream() throws Exception {
                                                                                       // Setup
                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                       String archiverName = ArchiveStreamFactory.AR;
                                                                                       InputStream testInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                       
                                                                                       // Execute
                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(archiverName, testInputStream);
                                                                                       
                                                                                       // Verify
                                                                                       assertNotNull("Result should not be null", result);
                                                                                       assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                                       
                                                                                       // Additional verification to catch the mutant
                                                                                       try {
                                                                                           // Try to read from the stream - if input stream was null (mutant case), this would fail
                                                                                           result.read();
                                                                                       } catch (NullPointerException e) {
                                                                                           fail("Input stream was null - mutant detected");
                                                                                       } catch (Exception e) {
                                                                                           // Other exceptions are acceptable as we're not testing the actual stream content
                                                                                       }
                                                                                   }

    @Test
                                                                              public void testCreateArchiveInputStreamForArFormat1() throws Exception {
                                                                                  // Prepare AR format signature
                                                                                  byte[] arSignature = new byte[12];
                                                                                  // AR format magic numbers
                                                                                  System.arraycopy("!<arch>\n".getBytes(), 0, arSignature, 0, 8);
                                                                                  
                                                                                  // Create mock input stream that supports mark/reset and returns AR signature
                                                                                  InputStream in = mock(InputStream.class);
                                                                                  when(in.markSupported()).thenReturn(true);
                                                                                  when(in.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                      byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                      System.arraycopy(arSignature, 0, buf, 0, Math.min(arSignature.length, buf.length));
                                                                                      return arSignature.length;
                                                                                  });
                                                                                  
                                                                                  // Create factory instance
                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                  
                                                                                  // Test the method
                                                                                  ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                                  
                                                                                  // Verify the result is an ArArchiveInputStream
                                                                                  assertTrue(result instanceof ArArchiveInputStream);
                                                                                  
                                                                                  // Additional verification that the stream was constructed properly
                                                                                  // This would throw NullPointerException if mutant is present
                                                                                  try {
                                                                                      result.read();
                                                                                      // If we get here, the stream was properly constructed
                                                                                  } catch (NullPointerException e) {
                                                                                      fail("Archive stream was constructed with null input");
                                                                                  }
                                                                                  
                                                                                  // Clean up
                                                                                  result.close();
                                                                              }

    @Test
                                                                              public void testCreateArchiveInputStream_ARJ1() throws Exception {
                                                                                  // Setup
                                                                                  String archiverName = ArchiveStreamFactory.ARJ;
                                                                                  InputStream inputStream = mock(InputStream.class);
                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                  
                                                                                  // Test
                                                                                  Object result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                  
                                                                                  // Verify
                                                                                  assertNotNull("Result should not be null", result);
                                                                                  assertTrue("Should return ArjArchiveInputStream for ARJ format", 
                                                                                            result instanceof ArjArchiveInputStream);
                                                                              }

    @Test
                                                                              public void testCreateArchiveInputStream_ARJWithEncoding() throws Exception {
                                                                                  // Setup
                                                                                  String archiverName = ArchiveStreamFactory.ARJ;
                                                                                  String encoding = "UTF-8";
                                                                                  InputStream inputStream = mock(InputStream.class);
                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                  factory.setEntryEncoding(encoding);
                                                                                  
                                                                                  // Test
                                                                                  Object result = factory.createArchiveInputStream(archiverName, inputStream);
                                                                                  
                                                                                  // Verify
                                                                                  assertNotNull("Result should not be null", result);
                                                                                  assertTrue("Should return ArjArchiveInputStream for ARJ format with encoding", 
                                                                                            result instanceof ArjArchiveInputStream);
                                                                              }

    @Test
                                                                          public void testCreateArchiveInputStreamForArj() throws Exception {
                                                                              // Setup
                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                              byte[] arjSignature = new byte[] {
                                                                                  // ARJ signature bytes (simplified for test)
                                                                                  0x60, (byte)0xEA, 0x27, 0x00, 0x00, 0x00, 0x00, 0x00,
                                                                                  0x00, 0x00, 0x00, 0x00
                                                                              };
                                                                              InputStream input = new ByteArrayInputStream(arjSignature);
                                                                              
                                                                              // Test
                                                                              ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                              
                                                                              // Verify
                                                                              assertNotNull("Should return a stream for ARJ format", result);
                                                                              assertTrue("Should be an ArjArchiveInputStream", 
                                                                                         result instanceof ArjArchiveInputStream);
                                                                              
                                                                              // Cleanup
                                                                              result.close();
                                                                          }

    @Test
                                                                          public void testCreateArchiveInputStreamWithArjName() throws Exception {
                                                                              // Setup
                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                              InputStream input = mock(InputStream.class);
                                                                              when(input.markSupported()).thenReturn(true);
                                                                              
                                                                              // Test
                                                                              ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, input);
                                                                              
                                                                              // Verify
                                                                              assertNotNull("Should return a stream when ARJ name specified", result);
                                                                              assertTrue("Should be an ArjArchiveInputStream when ARJ name specified",
                                                                                         result instanceof ArjArchiveInputStream);
                                                                              
                                                                              // Cleanup
                                                                              result.close();
                                                                          }

    @Test
                                                                        public void testCreateArjArchiveInputStreamWithEncoding() throws Exception {
                                                                            // Setup
                                                                            String testEncoding = "UTF-8";
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                            factory.setEntryEncoding(testEncoding);
                                                                            
                                                                            // Test
                                                                            ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInputStream);
                                                                            
                                                                            // Verify
                                                                            assertNotNull(result);
                                                                            
                                                                            // Alternative verification without PowerMock:
                                                                            // Get the actual encoding used by the stream
                                                                            Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                            encodingField.setAccessible(true);
                                                                            String actualEncoding = (String) encodingField.get(result);
                                                                            assertEquals(testEncoding, actualEncoding);
                                                                        }

    @Test
                                                                public void testCreateArchiveInputStream_ArjWithEncoding_ShouldPassEncoding() throws Exception {
                                                                    // Setup
                                                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                    factory.setEntryEncoding("UTF-8");
                                                                    
                                                                    // Create a mock input stream that will be recognized as ARJ
                                                                    InputStream in = new ByteArrayInputStream(new byte[] {
                                                                        (byte) 0x60, (byte) 0xEA, // ARJ magic number
                                                                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0 // rest of signature bytes
                                                                    });
                                                                    
                                                                    // Execute
                                                                    ArchiveInputStream result = factory.createArchiveInputStream(in);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result instanceof ArjArchiveInputStream);
                                                                    
                                                                    // The key assertion - verify the encoding was passed correctly
                                                                    // This would fail with the mutant that passes null instead of entryEncoding
                                                                    Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                    encodingField.setAccessible(true);
                                                                    String actualEncoding = (String) encodingField.get(result);
                                                                    assertEquals("UTF-8", actualEncoding);
                                                                }

    @Test
                                                            public void testCreateArchiveInputStream_TarCaseInsensitive1() throws Exception {
                                                                // Setup
                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                InputStream mockInput = mock(InputStream.class);
                                                                
                                                                // Test different case variations that should work with equalsIgnoreCase
                                                                String[] testCases = {"tar", "TAR", "Tar", "tAr"};
                                                                
                                                                for (String testCase : testCases) {
                                                                    // Exercise
                                                                    ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                                                                    
                                                                    // Verify
                                                                    assertNotNull("Should return a stream for case: " + testCase, result);
                                                                    assertTrue("Should return TarArchiveInputStream for case: " + testCase, 
                                                                              result instanceof TarArchiveInputStream);
                                                                }
                                                                
                                                                // Also test with entry encoding
                                                                factory.setEntryEncoding("UTF-8");
                                                                for (String testCase : testCases) {
                                                                    // Exercise
                                                                    ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                                                                    
                                                                    // Verify
                                                                    assertNotNull("Should return a stream with encoding for case: " + testCase, result);
                                                                    assertTrue("Should return TarArchiveInputStream with encoding for case: " + testCase, 
                                                                              result instanceof TarArchiveInputStream);
                                                                }
                                                            }

    @Test
                                                            public void testCreateArchiveInputStreamWithTarShouldBeCaseInsensitive1() throws Exception {
                                                                // Setup
                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                InputStream inputStream = mock(InputStream.class);
                                                                
                                                                // Test different case variations of TAR
                                                                String[] testCases = {"TAR", "tar", "Tar", "tAr"};
                                                                
                                                                for (String testCase : testCases) {
                                                                    // Exercise
                                                                    ArchiveInputStream result = factory.createArchiveInputStream(testCase, inputStream);
                                                                    
                                                                    // Verify
                                                                    assertNotNull("Should return a stream for case: " + testCase, result);
                                                                    assertTrue("Should return TarArchiveInputStream for case: " + testCase, 
                                                                              result instanceof TarArchiveInputStream);
                                                                }
                                                            }

    @Test
                          public void testCreateTarArchiveInputStreamWithCustomEncoding1() throws Exception {
                              // Setup
                              String customEncoding = "ISO-8859-1";
                              ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory(customEncoding);
                              InputStream mockInputStream = mock(InputStream.class);
                              
                              // Execute
                              ArchiveInputStream result = factoryWithEncoding.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                              
                              // Verify
                              assertNotNull(result);
                              assertTrue(result instanceof TarArchiveInputStream);
                              // Verify encoding was properly passed by checking the stream's encoding if possible
                              // Note: This might require reflection to access private fields if needed
                              Field encodingField = TarArchiveInputStream.class.getDeclaredField("encoding");
                              encodingField.setAccessible(true);
                              assertEquals(customEncoding, encodingField.get(result));
                          }

    @Test
                      public void testCreateTarArchiveInputStreamWithCustomEncoding2() throws Exception {
                          // Setup
                          String customEncoding = "ISO-8859-1";
                          ArchiveStreamFactory factoryWithEncoding = new ArchiveStreamFactory(customEncoding);
                          InputStream mockInputStream = mock(InputStream.class);
                          
                          // Create a real TarArchiveInputStream (since we can't easily mock constructors in older Mockito)
                          // The actual test will verify the encoding is properly passed to the stream
                          ArchiveInputStream result = factoryWithEncoding.createArchiveInputStream(
                                  ArchiveStreamFactory.TAR, mockInputStream);
                          
                          // Verify the result is of correct type
                          assertTrue(result instanceof TarArchiveInputStream);
                          
                          // Verify encoding was properly passed through (using reflection if needed)
                          Field encodingField = TarArchiveInputStream.class.getDeclaredField("encoding");
                          encodingField.setAccessible(true);
                          String actualEncoding = (String) encodingField.get(result);
                          assertEquals(customEncoding, actualEncoding);
                      }

    @Test
                  public void testCreateArchiveInputStream_DUMP_CaseInsensitive1() throws Exception {
                      // Setup
                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                      InputStream mockInput = mock(InputStream.class);
                      
                      // Test with lowercase "dump" which should work in original but fail in mutant
                      String archiverName = "dump";
                      
                      // Exercise
                      ArchiveInputStream result = factory.createArchiveInputStream(archiverName, mockInput);
                      
                      // Verify
                      assertNotNull("Should return a stream for case-insensitive DUMP format", result);
                      assertTrue("Should return DumpArchiveInputStream", 
                                 result instanceof DumpArchiveInputStream);
                      
                      // Test with mixed case "Dump" which should work in original but fail in mutant
                      archiverName = "Dump";
                      result = factory.createArchiveInputStream(archiverName, mockInput);
                      
                      assertNotNull("Should return a stream for case-insensitive DUMP format", result);
                      assertTrue("Should return DumpArchiveInputStream", 
                                 result instanceof DumpArchiveInputStream);
                  }

    @Test
                  public void testCreateArchiveInputStreamWithDumpFormatCaseInsensitive() throws Exception {
                      // Setup
                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                      InputStream inputStream = mock(InputStream.class);
                      when(inputStream.markSupported()).thenReturn(true);
                      
                      // Mock DUMP signature match
                      byte[] dumpSignature = new byte[32];
                      when(IOUtils.readFully(inputStream, any(byte[].class)))
                          .thenReturn(dumpSignature.length);
                      when(DumpArchiveInputStream.matches(dumpSignature, dumpSignature.length))
                          .thenReturn(true);
                      
                      // Test different case variations that should work with original but fail with mutant
                      String[] testCases = {"dump", "DUMP", "Dump", "dUMP"};
                      
                      for (String testCase : testCases) {
                          try {
                              ArchiveInputStream result = factory.createArchiveInputStream(testCase, inputStream);
                              assertNotNull("Should create stream for case: " + testCase, result);
                              assertTrue("Should return DumpArchiveInputStream", 
                                        result instanceof DumpArchiveInputStream);
                          } catch (ArchiveException e) {
                              fail("Should not throw exception for valid case variation: " + testCase);
                          }
                      }
                      
                      // Verify mock interactions
                      verify(inputStream, atLeastOnce()).markSupported();
                      verify(inputStream, atLeastOnce()).mark(anyInt());
                      verify(inputStream, atLeastOnce()).reset();
                  }

    @Test
                     public void testCreateArchiveInputStream_AR_CaseInsensitive2() throws Exception {
                         // Setup
                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                         InputStream in = new ByteArrayInputStream(new byte[0]);
                         
                         // Test different case variations of AR format
                         String[] testCases = {
                             ArchiveStreamFactory.AR,  // original case
                             ArchiveStreamFactory.AR.toLowerCase(),
                             ArchiveStreamFactory.AR.toUpperCase(),
                             "Ar",  // mixed case
                             "aR"   // mixed case
                         };
                         
                         for (String archiverName : testCases) {
                             // Exercise
                             ArchiveInputStream result = factory.createArchiveInputStream(archiverName, in);
                             
                             // Verify
                             assertNotNull("Should return stream for AR format with case: " + archiverName, result);
                             assertEquals("Should return ArArchiveInputStream for case: " + archiverName, 
                                 ArArchiveInputStream.class, result.getClass());
                         }
                     }

    @Test
                 public void testCreateArchiveInputStreamWithArIgnoresCase1() throws Exception {
                     // Setup
                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                     InputStream input = mock(InputStream.class);
                     when(input.markSupported()).thenReturn(true);
                     
                     // Test different case variations of "AR"
                     String[] testCases = {"AR", "ar", "Ar", "aR"};
                     
                     for (String archiverName : testCases) {
                         // Exercise
                         ArchiveInputStream result = factory.createArchiveInputStream(archiverName, input);
                         
                         // Verify
                         assertNotNull("Should return a stream for archiverName: " + archiverName, result);
                         assertTrue("Should be ArArchiveInputStream for archiverName: " + archiverName, 
                                   result instanceof ArArchiveInputStream);
                     }
                     
                     // Verify mock interactions
                     verify(input, times(testCases.length)).markSupported();
                 }

    @Test
                    public void testCreateArjArchiveInputStreamWithEncoding1() throws Exception {
                        // Setup
                        String testEncoding = "UTF-8";
                        InputStream mockInputStream = mock(InputStream.class);
                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                        factory.setEntryEncoding(testEncoding);
                        
                        // Execute
                        ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInputStream);
                        
                        // Verify
                        assertNotNull(result);
                        assertTrue(result instanceof ArjArchiveInputStream);
                        
                        // This is the key assertion to catch the mutant
                        // The mutant would pass null instead of testEncoding to the constructor
                        verify(mockInputStream); // Verify the input stream was used
                        // We can't directly verify constructor parameters, so we check the encoding was set
                        assertEquals(testEncoding, factory.getEntryEncoding());
                        
                        // Additional verification that the stream was properly created
                        // (This assumes ArjArchiveInputStream has a way to check encoding)
                        // If not, we might need to use reflection or other means to verify
                        // the encoding was properly passed
                    }

    @Test
           public void testCreateArchiveInputStreamForArjWithEncoding() throws Exception {
               // Setup
               String testEncoding = "UTF-8";
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               factory.setEntryEncoding(testEncoding);
               
               // Mock input stream that will identify as ARJ
               InputStream in = mock(InputStream.class);
               byte[] arjSignature = new byte[] { 
                   (byte) 0x60, (byte) 0xEA, // ARJ signature bytes
                   0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00
               };
               when(in.markSupported()).thenReturn(true);
               when(IOUtils.readFully(in, any(byte[].class)))
                   .thenAnswer(invocation -> {
                       byte[] sig = (byte[]) invocation.getArguments()[0];
                       System.arraycopy(arjSignature, 0, sig, 0, arjSignature.length);
                       return arjSignature.length;
                   });
               
               // Test
               ArchiveInputStream ais = factory.createArchiveInputStream(in);
               
               // Verify
               assertTrue(ais instanceof ArjArchiveInputStream);
               // This is the key assertion that would catch the mutant
               assertEquals(testEncoding, factory.getEntryEncoding());
           }

    @Test
           public void testCreateTarArchiveInputStreamCaseInsensitive() throws Exception {
               // Arrange
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               InputStream in = new ByteArrayInputStream(new byte[0]);
               
               // Test with different case variations of "TAR"
               String[] testCases = {"TAR", "tar", "Tar", "tAr"};
               
               for (String testCase : testCases) {
                   // Act
                   ArchiveInputStream result = factory.createArchiveInputStream(testCase, in);
                   
                   // Assert
                   assertNotNull("Result should not be null for case: " + testCase, result);
                   assertTrue("Should return TarArchiveInputStream for case: " + testCase, 
                             result instanceof TarArchiveInputStream);
               }
           }

    @Test
       public void testCreateArchiveInputStreamWithTarCaseVariations() throws Exception {
           // Setup
           ArchiveStreamFactory factory = new ArchiveStreamFactory();
           InputStream mockInput = mock(InputStream.class);
           
           // Test different case variations of "tar"
           String[] testCases = {"TAR", "tar", "Tar", "tAr"};
           
           for (String testCase : testCases) {
               try {
                   // Exercise
                   ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                   
                   // Verify
                   assertNotNull("Should return a stream for case: " + testCase, result);
                   assertTrue("Should return TarArchiveInputStream for case: " + testCase, 
                             result instanceof TarArchiveInputStream);
               } catch (ArchiveException e) {
                   fail("Should not throw exception for valid case variation: " + testCase);
               }
           }
       }

    @Test
          public void testCreateArchiveInputStream_DUMP_CaseInsensitive2() throws Exception {
              // Setup
              ArchiveStreamFactory factory = new ArchiveStreamFactory();
              InputStream in = new ByteArrayInputStream(new byte[0]);
              
              // Test with lowercase "dump" - should work in original but fail in mutant
              ArchiveInputStream resultLower = factory.createArchiveInputStream("dump", in);
              assertTrue(resultLower instanceof DumpArchiveInputStream);
              
              // Test with mixed case "Dump" - should work in original but fail in mutant
              ArchiveInputStream resultMixed = factory.createArchiveInputStream("Dump", in);
              assertTrue(resultMixed instanceof DumpArchiveInputStream);
              
              // Test with uppercase "DUMP" - should work in both original and mutant
              ArchiveInputStream resultUpper = factory.createArchiveInputStream("DUMP", in);
              assertTrue(resultUpper instanceof DumpArchiveInputStream);
          }

    @Test
      public void testCreateArchiveInputStream_DumpCaseInsensitive() throws Exception {
          // Setup
          ArchiveStreamFactory factory = new ArchiveStreamFactory();
          InputStream inputStream = mock(InputStream.class);
          when(inputStream.markSupported()).thenReturn(true);
          
          // Mock DUMP signature match
          byte[] dumpSignature = new byte[32];
          when(IOUtils.readFully(inputStream, any(byte[].class)))
              .thenReturn(dumpSignature.length);
          when(DumpArchiveInputStream.matches(dumpSignature, dumpSignature.length))
              .thenReturn(true);
          
          // Test different case variations that should work with original
          String[] testCases = {"dump", "DUMP", "Dump", "dUMP"};
          
          for (String testCase : testCases) {
              try {
                  ArchiveInputStream result = factory.createArchiveInputStream(testCase, inputStream);
                  assertNotNull("Should return stream for case: " + testCase, result);
                  assertTrue("Should return DumpArchiveInputStream", 
                            result instanceof DumpArchiveInputStream);
              } catch (ArchiveException e) {
                  fail("Should not throw exception for case: " + testCase);
              }
          }
          
          // Verify mock interactions
          verify(inputStream, atLeastOnce()).markSupported();
          verify(inputStream, atLeastOnce()).mark(anyInt());
          verify(inputStream, atLeastOnce()).reset();
      }

    @Test
         public void testCreateArchiveInputStreamForSevenZShouldThrowException1() throws Exception {
             // Arrange
             ArchiveStreamFactory factory = new ArchiveStreamFactory();
             InputStream inputStream = mock(InputStream.class);
             
             // Set expectation for the original behavior
             thrown.expect(StreamingNotSupportedException.class);
             thrown.expectMessage(ArchiveStreamFactory.SEVEN_Z);
             
             // Act
             factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, inputStream);
             
             // Assert - handled by ExpectedException rule
             // If the method returns null instead of throwing, this test will fail
         }

    @Test(expected = ArchiveException.class)
    public void testCreateArchiveInputStream_SevenZSignature_ShouldThrowException1() throws Exception {
        // Arrange
        InputStream inputStream = mock(InputStream.class);
        when(inputStream.markSupported()).thenReturn(true);
        
        // Setup 7z signature
        byte[] sevenZSignature = new byte[12];
        // SevenZFile.matches expects the first 6 bytes to be '7z\xBC\xAF\x27\x1C'
        sevenZSignature[0] = '7';
        sevenZSignature[1] = 'z';
        sevenZSignature[2] = (byte) 0xBC;
        sevenZSignature[3] = (byte) 0xAF;
        sevenZSignature[4] = 0x27;
        sevenZSignature[5] = 0x1C;
        
        when(IOUtils.readFully(inputStream, any(byte[].class)))
            .thenAnswer(invocation -> {
                byte[] buffer = (byte[]) invocation.getArguments()[0];
                System.arraycopy(sevenZSignature, 0, buffer, 0, Math.min(sevenZSignature.length, buffer.length));
                return sevenZSignature.length;
            });
        
        ArchiveStreamFactory factory = new ArchiveStreamFactory();
        
        // Act
        factory.createArchiveInputStream(inputStream);
    }


}
