package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                  public void testFinish_WithUnclosedEntry_ThrowsIOException() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Use reflection to set the private haveUnclosedEntry field to true
                                                                                                                                                                                                                                                                      // This is necessary to test the exception case
                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                          java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                                                                                                                                          field.set(tarOutput, true);
                                                                                                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                                                                                                          throw new RuntimeException("Failed to set haveUnclosedEntry field", e);
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                      // Setup exception expectation
                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                          tarOutput.finish();
                                                                                                                                                                                                                                                                          fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                                                      } catch (IOException e) {
                                                                                                                                                                                                                                                                          assertEquals("This archives contains unclosed entries.", e.getMessage());
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testFinish_WhenAlreadyClosed_DoesNothing() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Set closed to true
                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                          java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                                                                                                                                                          field.setAccessible(true);
                                                                                                                                                                                                                                                                          field.set(tarOutput, true);
                                                                                                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                                                                                                          throw new RuntimeException("Failed to set closed field", e);
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                      tarOutput.finish();
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                      // Verify no interactions with the output stream
                                                                                                                                                                                                                                                                      verifyZeroInteractions(mockOutputStream);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_ShortFileName_GnuMode() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry("short.txt");
                                                                                                                                                                                                                                                                      entry.setSize(100);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      tarOut.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                      verify(mockOut, never()).write(any(byte[].class)); // Shouldn't write long name record
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                                                                                                                      String currName = (String) currNameField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals("short.txt", currName);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currSize = currSizeField.getLong(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(100, currSize);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currBytes = currBytesField.getLong(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(0, currBytes);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                                      haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                      boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(tarOut);
                                                                                                                                                                                                                                                                      assertTrue(haveUnclosedEntry);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_LongFileName_GnuMode() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      String longName = new String(new char[TarConstants.NAMELEN + 10]).replace('\0', 'a');
                                                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry(longName);
                                                                                                                                                                                                                                                                      entry.setSize(200);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      tarOut.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                      verify(mockOut).write(any(byte[].class)); // Should write long name record
                                                                                                                                                                                                                                                                      verify(mockOut).write(0); // NUL terminator
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                                                                                                                      String currName = (String) currNameField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(longName, currName);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currSize = (Long) currSizeField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(200, currSize);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currBytes = (Long) currBytesField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(0, currBytes);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                                      haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                      boolean haveUnclosedEntry = (Boolean) haveUnclosedEntryField.get(tarOut);
                                                                                                                                                                                                                                                                      assertTrue(haveUnclosedEntry);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_LongFileName_TruncateMode() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      String longName = new String(new char[TarConstants.NAMELEN + 10]).replace('\0', 'a');
                                                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry(longName);
                                                                                                                                                                                                                                                                      entry.setSize(300);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      tarOut.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                      verify(mockOut, never()).write(any(byte[].class)); // Shouldn't write long name record
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                                                                                                                      String currName = (String) currNameField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(longName, currName);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currSize = (Long) currSizeField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(300L, currSize);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currBytes = (Long) currBytesField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(0L, currBytes);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                                      haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                      boolean haveUnclosedEntry = (Boolean) haveUnclosedEntryField.get(tarOut);
                                                                                                                                                                                                                                                                      assertTrue(haveUnclosedEntry);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_LongFileName_ErrorMode() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      String longName = new String(new char[TarConstants.NAMELEN + 10]).replace('\0', 'a');
                                                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry(longName);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                                                                          tarOut.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                          fail("Expected RuntimeException for long file name");
                                                                                                                                                                                                                                                                      } catch (RuntimeException e) {
                                                                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                                                                          assertEquals("file name '" + longName + "' is too long ( > " + TarConstants.NAMELEN + " bytes)", e.getMessage());
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_DirectoryEntry() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry("dir/");
                                                                                                                                                                                                                                                                      entry.setSize(400);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      tarOut.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                                                                                                                      String currName = (String) currNameField.get(tarOut);
                                                                                                                                                                                                                                                                      assertEquals("dir/", currName);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currSize = currSizeField.getLong(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(0, currSize); // Should be 0 for directory
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                      long currBytes = currBytesField.getLong(tarOut);
                                                                                                                                                                                                                                                                      assertEquals(0, currBytes);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                                      haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                      boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(tarOut);
                                                                                                                                                                                                                                                                      assertTrue(haveUnclosedEntry);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_NullEntry() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Expect exception
                                                                                                                                                                                                                                                                      ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                      expectedException.expect(NullPointerException.class);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      tarOut.putArchiveEntry(null);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testPutArchiveEntry_ClosedStream() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      tarOut.close();
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry("file.txt");
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Expect exception
                                                                                                                                                                                                                                                                      ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                      expectedException.expect(IOException.class);
                                                                                                                                                                                                                                                                      expectedException.expectMessage("Stream has already been finished");
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      tarOut.putArchiveEntry(entry);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                              public void testFinish_WithoutUnclosedEntry_WritesTwoEOFRecords() throws Exception {
                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                  OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                                                                                                                                                  TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Ensure haveUnclosedEntry is false (default)
                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                      Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                                      haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                      haveUnclosedEntryField.set(tarOutput, false);
                                                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                                                      throw new RuntimeException("Failed to set haveUnclosedEntry field", e);
                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Create a spy to count method calls
                                                                                                                                                                                                                                                                  TarArchiveOutputStream spyOutput = spy(tarOutput);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Get the private writeEOFRecord method
                                                                                                                                                                                                                                                                  Method writeEOFRecordMethod = TarArchiveOutputStream.class.getDeclaredMethod("writeEOFRecord");
                                                                                                                                                                                                                                                                  writeEOFRecordMethod.setAccessible(true);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Count invocations
                                                                                                                                                                                                                                                                  final java.util.concurrent.atomic.AtomicInteger callCount = new java.util.concurrent.atomic.AtomicInteger(0);
                                                                                                                                                                                                                                                                  doAnswer(invocation -> {
                                                                                                                                                                                                                                                                      callCount.incrementAndGet();
                                                                                                                                                                                                                                                                      writeEOFRecordMethod.invoke(spyOutput);
                                                                                                                                                                                                                                                                      return null;
                                                                                                                                                                                                                                                                  }).when(spyOutput).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                                                                  spyOutput.finish();
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                  assertEquals(2, callCount.get());
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                             public void testCloseArchiveEntryWithZeroAssemLenShouldNotWriteBuffer() throws Exception {
                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                 currBytesField.set(tarOut, 100L);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                 currSizeField.set(tarOut, 100L);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                 assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                 assemLenField.set(tarOut, 0);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                                 haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Execute
                                                                                                                                                                                                                                                 tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify - should NOT call write when assemLen = 0
                                                                                                                                                                                                                                                 verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify other state changes
                                                                                                                                                                                                                                                 assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                                                                                                 assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                        public void testCloseArchiveEntry_OnlyClearsRemainingBuffer() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                                                            byte[] testBuffer = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                                                                            int assemblyLength = 2; // First 2 bytes are valid
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Create TarArchiveOutputStream with small buffer size to match our test data
                                                                                                                                                                                                                                            ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut, 512, testBuffer.length);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to set private fields since they're not accessible
                                                                                                                                                                                                                                            Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                                            assemBufField.setAccessible(true);
                                                                                                                                                                                                                                            assemBufField.set(tarOut, testBuffer);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                            assemLenField.setAccessible(true);
                                                                                                                                                                                                                                            assemLenField.set(tarOut, assemblyLength);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                            tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify only bytes from assemLen onward were cleared
                                                                                                                                                                                                                                            byte[] modifiedBuffer = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                                                                            byte[] expectedBuffer = new byte[]{1, 2, 0, 0, 0}; // Only last 3 bytes cleared
                                                                                                                                                                                                                                            assertArrayEquals(expectedBuffer, modifiedBuffer);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify other state changes
                                                                                                                                                                                                                                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                            currBytesField.setAccessible(true);
                                                                                                                                                                                                                                            assertEquals(assemblyLength, currBytesField.get(tarOut));
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                                            haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                                            assertFalse((boolean)haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                   public void testCloseArchiveEntry_ShouldZeroFillRemainingBuffer() throws Exception {
                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Create instance
                                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Set up test conditions:
                                                                                                                                                                                                                                       // - assemLen > 0 but less than buffer size
                                                                                                                                                                                                                                       // - currBytes == currSize to avoid exception
                                                                                                                                                                                                                                       byte[] testBuf = new byte[512]; // Default record size
                                                                                                                                                                                                                                       testBuf[0] = 0x01; // First byte has data
                                                                                                                                                                                                                                       testBuf[1] = 0x02; // Second byte has data
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                                       Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                                       assemBufField.setAccessible(true);
                                                                                                                                                                                                                                       assemBufField.set(tarOut, testBuf);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                       assemLenField.setAccessible(true);
                                                                                                                                                                                                                                       assemLenField.set(tarOut, 2);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                       currBytesField.setAccessible(true);
                                                                                                                                                                                                                                       currBytesField.set(tarOut, 100L);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                       currSizeField.setAccessible(true);
                                                                                                                                                                                                                                       currSizeField.set(tarOut, 100L);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Execute
                                                                                                                                                                                                                                       tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify:
                                                                                                                                                                                                                                       // 1. The remaining bytes (index 2-511) should be set to 0
                                                                                                                                                                                                                                       for (int i = 2; i < testBuf.length; i++) {
                                                                                                                                                                                                                                           assertEquals("Buffer at position " + i + " should be 0", 0, testBuf[i]);
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // 2. The buffer should be written with the zero-filled content
                                                                                                                                                                                                                                       // We can't verify the buffer write directly since it's private, but we can verify
                                                                                                                                                                                                                                       // that the output stream received the zero-filled data
                                                                                                                                                                                                                                       verify(mockOut).write(testBuf, 0, testBuf.length);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                          public void testCloseArchiveEntry_WithAssembledData_WritesRecord() throws IOException {
                                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                                              byte[] testAssemBuf = new byte[512]; // Assuming default record size
                                                                                                                                                                                                              int testAssemLen = 100;
                                                                                                                                                                                                              long testCurrBytes = 500;
                                                                                                                                                                                                              long testCurrSize = 600;
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Create mock OutputStream
                                                                                                                                                                                                              OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Create real TarArchiveOutputStream with default constructor
                                                                                                                                                                                                              TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Declare spyBuffer outside try block
                                                                                                                                                                                                              OutputStream spyBuffer = null;
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                                                                              try {
                                                                                                                                                                                                                  java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                  assemBufField.setAccessible(true);
                                                                                                                                                                                                                  assemBufField.set(tarOutput, testAssemBuf);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                  assemLenField.setAccessible(true);
                                                                                                                                                                                                                  assemLenField.set(tarOutput, testAssemLen);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                  currBytesField.setAccessible(true);
                                                                                                                                                                                                                  currBytesField.set(tarOutput, testCurrBytes);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                  currSizeField.setAccessible(true);
                                                                                                                                                                                                                  currSizeField.set(tarOutput, testCurrSize);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get the buffer through reflection
                                                                                                                                                                                                                  java.lang.reflect.Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                                  bufferField.setAccessible(true);
                                                                                                                                                                                                                  Object realBuffer = bufferField.get(tarOutput);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Spy on the real buffer to verify interactions
                                                                                                                                                                                                                  spyBuffer = spy((OutputStream)realBuffer);
                                                                                                                                                                                                                  bufferField.set(tarOutput, spyBuffer);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Mock the write method call instead of writeRecord
                                                                                                                                                                                                                  doNothing().when(spyBuffer).write(testAssemBuf, 0, testAssemLen);
                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                  throw new RuntimeException(e);
                                                                                                                                                                                                              }
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Execute the method
                                                                                                                                                                                                              tarOutput.closeArchiveEntry();
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Verify the behavior
                                                                                                                                                                                                              verify(spyBuffer).write(testAssemBuf, 0, testAssemLen);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Verify other state changes
                                                                                                                                                                                                              try {
                                                                                                                                                                                                                  java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                  assemLenField.setAccessible(true);
                                                                                                                                                                                                                  assertEquals(0, assemLenField.get(tarOutput));
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                  currBytesField.setAccessible(true);
                                                                                                                                                                                                                  assertEquals(testCurrBytes + testAssemLen, currBytesField.get(tarOutput));
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  java.lang.reflect.Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                                  haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                                  assertFalse((boolean)haveUnclosedEntryField.get(tarOutput));
                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                  throw new RuntimeException(e);
                                                                                                                                                                                                              }
                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                     public void testCloseArchiveEntry_AccumulatesAssemLenToCurrBytes() throws Exception {
                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                         ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to set private fields
                                                                                                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                                                                                                         currBytesField.setLong(tarOut, 100L);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                         currSizeField.setAccessible(true);
                                                                                                                                                                                                         currSizeField.setLong(tarOut, 150L);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                                                                                                         assemLenField.setInt(tarOut, 50);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                         assemBufField.setAccessible(true);
                                                                                                                                                                                                         assemBufField.set(tarOut, new byte[100]);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                                         haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                                         haveUnclosedEntryField.setBoolean(tarOut, true);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock the buffer to avoid actual IO
                                                                                                                                                                                                         Class<?> tarBufferClass = Class.forName("org.apache.commons.compress.archivers.tar.TarBuffer");
                                                                                                                                                                                                         Object mockBuffer = mock(tarBufferClass);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                         bufferField.setAccessible(true);
                                                                                                                                                                                                         bufferField.set(tarOut, mockBuffer);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                         tarOut.closeArchiveEntry();
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                         assertEquals("currBytes should accumulate assemLen", 150L, currBytesField.getLong(tarOut));
                                                                                                                                                                                                         assertEquals("assemLen should be reset", 0, assemLenField.getInt(tarOut));
                                                                                                                                                                                                         assertFalse("haveUnclosedEntry should be false", haveUnclosedEntryField.getBoolean(tarOut));
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify buffer interaction
                                                                                                                                                                                                         Method writeRecordMethod = tarBufferClass.getDeclaredMethod("writeRecord", byte[].class);
                                                                                                                                                                                                         writeRecordMethod.invoke(verify(mockBuffer), assemBufField.get(tarOut));
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                        public void testCloseArchiveEntry_ResetsAssemLenToZero() throws Exception {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                                                                            
                                                                                                                                                                                            // Set up state where we have assembled data
                                                                                                                                                                                            byte[] testData = new byte[10];
                                                                                                                                                                                            java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                            Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                            assemBufField.setAccessible(true);
                                                                                                                                                                                            byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                            System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                                                                                                                                                                                            
                                                                                                                                                                                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                            assemLenField.setAccessible(true);
                                                                                                                                                                                            assemLenField.set(tarOut, testData.length);
                                                                                                                                                                                            
                                                                                                                                                                                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                            currBytesField.setAccessible(true);
                                                                                                                                                                                            currBytesField.set(tarOut, 0L);
                                                                                                                                                                                            
                                                                                                                                                                                            Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                            currSizeField.setAccessible(true);
                                                                                                                                                                                            currSizeField.set(tarOut, testData.length);
                                                                                                                                                                                            
                                                                                                                                                                                            // Get the original buffer to verify its state later
                                                                                                                                                                                            Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                            bufferField.setAccessible(true);
                                                                                                                                                                                            Object originalBuffer = bufferField.get(tarOut);
                                                                                                                                                                                            
                                                                                                                                                                                            // Execute
                                                                                                                                                                                            tarOut.closeArchiveEntry();
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify
                                                                                                                                                                                            int finalAssemLen = (int) assemLenField.get(tarOut);
                                                                                                                                                                                            assertEquals("assemLen should be reset to 0 after closing entry", 
                                                                                                                                                                                                         0, finalAssemLen);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify buffer was written to by checking the output stream
                                                                                                                                                                                            byte[] output = out.toByteArray();
                                                                                                                                                                                            assertTrue("Output should contain the test data", output.length > 0);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                   public void testCloseArchiveEntry_WhenBytesExactlyMatchSize_ShouldNotThrow() throws Exception {
                                                                                                                                                                                       // Setup
                                                                                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                       
                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                       Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                       currSizeField.setAccessible(true);
                                                                                                                                                                                       currSizeField.set(tarOut, 100L);
                                                                                                                                                                                       
                                                                                                                                                                                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                       currBytesField.setAccessible(true);
                                                                                                                                                                                       currBytesField.set(tarOut, 100L);
                                                                                                                                                                                       
                                                                                                                                                                                       Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                       currNameField.setAccessible(true);
                                                                                                                                                                                       currNameField.set(tarOut, "testEntry");
                                                                                                                                                                                       
                                                                                                                                                                                       Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                       haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                       haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                                       
                                                                                                                                                                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                       assemLenField.setAccessible(true);
                                                                                                                                                                                       assemLenField.set(tarOut, 0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Exercise and verify - should not throw
                                                                                                                                                                                       tarOut.closeArchiveEntry();
                                                                                                                                                                                       
                                                                                                                                                                                       // Additional verification
                                                                                                                                                                                       assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                               public void testCloseArchiveEntry_throwsIOExceptionWithDetailedMessageWhenIncomplete() throws Exception {
                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                   String entryName = "testEntry.txt";
                                                                                                                                                                                   long expectedSize = 100L;
                                                                                                                                                                                   long actualBytes = 50L;
                                                                                                                                                                                   
                                                                                                                                                                                   // Create output stream mock
                                                                                                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                   
                                                                                                                                                                                   // Set object state to trigger the error condition
                                                                                                                                                                                   // Using reflection to set private fields since there are no setters
                                                                                                                                                                                   Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                   currNameField.setAccessible(true);
                                                                                                                                                                                   currNameField.set(tarOut, entryName);
                                                                                                                                                                                   
                                                                                                                                                                                   Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                   currSizeField.setAccessible(true);
                                                                                                                                                                                   currSizeField.set(tarOut, expectedSize);
                                                                                                                                                                                   
                                                                                                                                                                                   Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                   currBytesField.setAccessible(true);
                                                                                                                                                                                   currBytesField.set(tarOut, actualBytes);
                                                                                                                                                                                   
                                                                                                                                                                                   Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                                   haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                                   haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Set assemLen to 0 to skip the buffer writing part
                                                                                                                                                                                   Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                   assemLenField.setAccessible(true);
                                                                                                                                                                                   assemLenField.set(tarOut, 0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the exception and its message
                                                                                                                                                                                   try {
                                                                                                                                                                                       tarOut.closeArchiveEntry();
                                                                                                                                                                                       fail("Expected IOException to be thrown");
                                                                                                                                                                                   } catch (IOException e) {
                                                                                                                                                                                       // Verify the message contains all expected parts
                                                                                                                                                                                       assertTrue("Exception message should contain entry name", 
                                                                                                                                                                                                 e.getMessage().contains(entryName));
                                                                                                                                                                                       assertTrue("Exception message should contain actual bytes", 
                                                                                                                                                                                                 e.getMessage().contains(String.valueOf(actualBytes)));
                                                                                                                                                                                       assertTrue("Exception message should contain expected size", 
                                                                                                                                                                                                 e.getMessage().contains(String.valueOf(expectedSize)));
                                                                                                                                                                                   }
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify haveUnclosedEntry was reset (though we can't reach this point if exception was thrown)
                                                                                                                                                                                   assertFalse((boolean)haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                               }

    @Test(expected = IOException.class)
                                                                                                                                                                             public void testCloseArchiveEntry_ThrowsIOExceptionWithCorrectByteCount() throws Exception {
                                                                                                                                                                                 // Initialize TarArchiveOutputStream
                                                                                                                                                                                 ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                 TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                 
                                                                                                                                                                                 // Helper method to set private fields
                                                                                                                                                                                 java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                 field.setAccessible(true);
                                                                                                                                                                                 field.set(tarOutput, "testEntry");
                                                                                                                                                                                 
                                                                                                                                                                                 field = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                 field.setAccessible(true);
                                                                                                                                                                                 field.set(tarOutput, 100L);  // Expected size
                                                                                                                                                                                 
                                                                                                                                                                                 field = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                 field.setAccessible(true);
                                                                                                                                                                                 field.set(tarOutput, 50L);  // Actual bytes written (less than expected)
                                                                                                                                                                                 
                                                                                                                                                                                 try {
                                                                                                                                                                                     tarOutput.closeArchiveEntry();
                                                                                                                                                                                 } catch (IOException e) {
                                                                                                                                                                                     // Verify the error message contains the actual byte count (50)
                                                                                                                                                                                     assertTrue("Error message should contain actual byte count",
                                                                                                                                                                                               e.getMessage().contains("50"));
                                                                                                                                                                                     throw e;
                                                                                                                                                                                 }
                                                                                                                                                                             }

    @Test(expected = IOException.class)
                                                                                                                                                                        public void testCloseArchiveEntry_ThrowsWhenBytesIncomplete_WithCorrectMessage() throws Exception {
                                                                                                                                                                            // Create test output stream
                                                                                                                                                                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                            TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                                            Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                            currNameField.setAccessible(true);
                                                                                                                                                                            currNameField.set(tarOutput, "testEntry");
                                                                                                                                                                            
                                                                                                                                                                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                            currBytesField.setAccessible(true);
                                                                                                                                                                            currBytesField.set(tarOutput, 100L);  // Less than currSize
                                                                                                                                                                            
                                                                                                                                                                            Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                            currSizeField.setAccessible(true);
                                                                                                                                                                            currSizeField.set(tarOutput, 200L);
                                                                                                                                                                            
                                                                                                                                                                            try {
                                                                                                                                                                                tarOutput.closeArchiveEntry();
                                                                                                                                                                                fail("Expected IOException not thrown");
                                                                                                                                                                            } catch (IOException e) {
                                                                                                                                                                                // Verify the error message contains the correct wording
                                                                                                                                                                                assertTrue("Error message should contain 'before'", 
                                                                                                                                                                                          e.getMessage().contains("before the '"));
                                                                                                                                                                                throw e; // rethrow to satisfy @Test(expected)
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                   public void testCloseArchiveEntry_throwsIOExceptionWithCorrectMessageWhenBytesIncomplete() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                                                       
                                                                                                                                                                       // Declare expected exception rule
                                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set private fields since we need to test error condition
                                                                                                                                                                       // Alternatively, we could create an entry and write partial data, but this is more direct for testing
                                                                                                                                                                       java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                       currSizeField.setAccessible(true);
                                                                                                                                                                       currSizeField.set(tarOut, 100L); // Expected 100 bytes
                                                                                                                                                                       
                                                                                                                                                                       java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                       currBytesField.setAccessible(true);
                                                                                                                                                                       currBytesField.set(tarOut, 50L); // Only wrote 50 bytes
                                                                                                                                                                       
                                                                                                                                                                       java.lang.reflect.Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                       currNameField.setAccessible(true);
                                                                                                                                                                       currNameField.set(tarOut, "testEntry"); // Set entry name
                                                                                                                                                                       
                                                                                                                                                                       // Expect exception with specific message
                                                                                                                                                                       expectedException.expect(IOException.class);
                                                                                                                                                                       expectedException.expectMessage("bytes specified in the header were written");
                                                                                                                                                                       
                                                                                                                                                                       // Execute
                                                                                                                                                                       tarOut.closeArchiveEntry();
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testCloseArchiveEntrySetsHaveUnclosedEntryToFalse() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                                                       
                                                                                                                                                                       // Set initial state to have an unclosed entry
                                                                                                                                                                       Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                       haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                       haveUnclosedEntryField.set(tarOut, true);
                                                                                                                                                                       
                                                                                                                                                                       // Set other required fields to avoid exceptions
                                                                                                                                                                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                       currBytesField.setAccessible(true);
                                                                                                                                                                       currBytesField.set(tarOut, 100L);
                                                                                                                                                                       
                                                                                                                                                                       Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                       currSizeField.setAccessible(true);
                                                                                                                                                                       currSizeField.set(tarOut, 100L);
                                                                                                                                                                       
                                                                                                                                                                       // Execute
                                                                                                                                                                       tarOut.closeArchiveEntry();
                                                                                                                                                                       
                                                                                                                                                                       // Verify
                                                                                                                                                                       assertFalse("haveUnclosedEntry should be false after closing entry", 
                                                                                                                                                                                  haveUnclosedEntryField.getBoolean(tarOut));
                                                                                                                                                                   }

    @Test
                                                                                                                                                              public void testCloseArchiveEntryResetsUnclosedEntryFlag() throws Exception {
                                                                                                                                                                  // Setup
                                                                                                                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set private field since there's no public way to set it
                                                                                                                                                                  Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                  haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                  haveUnclosedEntryField.set(tarOut, true); // Set initial state
                                                                                                                                                                  
                                                                                                                                                                  // Set other required fields to avoid exceptions
                                                                                                                                                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                  currBytesField.setAccessible(true);
                                                                                                                                                                  currBytesField.set(tarOut, 100L);
                                                                                                                                                                  
                                                                                                                                                                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                  currSizeField.setAccessible(true);
                                                                                                                                                                  currSizeField.set(tarOut, 100L);
                                                                                                                                                                  
                                                                                                                                                                  // Execute
                                                                                                                                                                  tarOut.closeArchiveEntry();
                                                                                                                                                                  
                                                                                                                                                                  // Verify
                                                                                                                                                                  assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                                                                                                  
                                                                                                                                                                  // Clean up
                                                                                                                                                                  haveUnclosedEntryField.setAccessible(false);
                                                                                                                                                                  currBytesField.setAccessible(false);
                                                                                                                                                                  currSizeField.setAccessible(false);
                                                                                                                                                              }

    @Test
                                                                                                                                                            public void testCloseArchiveEntry_WithAssemLen1_ShouldProcessBuffer() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                // Setup
                                                                                                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set private fields since we need to test specific conditions
                                                                                                                                                                Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                assemLenField.setAccessible(true);
                                                                                                                                                                assemLenField.set(tarOut, 1);  // Critical value that differs between original and mutant
                                                                                                                                                                
                                                                                                                                                                Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                assemBufField.setAccessible(true);
                                                                                                                                                                byte[] testBuf = new byte[512];  // Default record size
                                                                                                                                                                testBuf[0] = 0x42;  // Set some data in first byte
                                                                                                                                                                assemBufField.set(tarOut, testBuf);
                                                                                                                                                                
                                                                                                                                                                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                currBytesField.setAccessible(true);
                                                                                                                                                                currBytesField.set(tarOut, 0L);
                                                                                                                                                                
                                                                                                                                                                Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                currSizeField.setAccessible(true);
                                                                                                                                                                currSizeField.set(tarOut, 1L);  // Expecting exactly 1 byte
                                                                                                                                                                
                                                                                                                                                                // Get the actual buffer instance to verify writes
                                                                                                                                                                Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                bufferField.setAccessible(true);
                                                                                                                                                                Object buffer = bufferField.get(tarOut);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                tarOut.closeArchiveEntry();
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                // Instead of verifying mock, we verify the state changes
                                                                                                                                                                assertEquals(1L, currBytesField.get(tarOut));
                                                                                                                                                                assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                
                                                                                                                                                                // Verify entry marked as closed
                                                                                                                                                                Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                                                                haveUnclosedEntryField.setAccessible(true);
                                                                                                                                                                assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testCloseArchiveEntryWithZeroAssemLenShouldNotWriteRecord() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                           // Setup
                                                                                                                                                           OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                           
                                                                                                                                                           // Use reflection to set test conditions
                                                                                                                                                           Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                           bufferField.setAccessible(true);
                                                                                                                                                           Object realBuffer = bufferField.get(tarOut);  // Get the actual buffer instance
                                                                                                                                                           
                                                                                                                                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                           assemLenField.setAccessible(true);
                                                                                                                                                           assemLenField.set(tarOut, 0);  // Critical test condition
                                                                                                                                                           
                                                                                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                           currBytesField.setAccessible(true);
                                                                                                                                                           currBytesField.set(tarOut, 100L);
                                                                                                                                                           
                                                                                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                           currSizeField.setAccessible(true);
                                                                                                                                                           currSizeField.set(tarOut, 100L);
                                                                                                                                                           
                                                                                                                                                           // Spy on the output stream to verify write operations
                                                                                                                                                           OutputStream spyOut = spy(mockOut);
                                                                                                                                                           Field outField = TarArchiveOutputStream.class.getDeclaredField("out");
                                                                                                                                                           outField.setAccessible(true);
                                                                                                                                                           outField.set(tarOut, spyOut);
                                                                                                                                                           
                                                                                                                                                           // Execute
                                                                                                                                                           tarOut.closeArchiveEntry();
                                                                                                                                                           
                                                                                                                                                           // Verify - with assemLen=0, no data should be written to the output stream
                                                                                                                                                           verify(spyOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                           
                                                                                                                                                           // Additional verification that other expected behavior occurred
                                                                                                                                                           assertEquals(0, assemLenField.get(tarOut));  // assemLen should be reset
                                                                                                                                                           assertFalse((Boolean) tarOut.getClass().getDeclaredField("haveUnclosedEntry").get(tarOut));
                                                                                                                                                       }

    @Test
                                                                                                                                      public void testCloseArchiveEntry_AssemblyBufferZeroing() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                          // Setup
                                                                                                                                          ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                          
                                                                                                                                          // Get private fields via reflection
                                                                                                                                          Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                          assemBufField.setAccessible(true);
                                                                                                                                          byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                          
                                                                                                                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                          assemLenField.setAccessible(true);
                                                                                                                                          
                                                                                                                                          Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                          currNameField.setAccessible(true);
                                                                                                                                          
                                                                                                                                          Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                          currSizeField.setAccessible(true);
                                                                                                                                          
                                                                                                                                          Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                          currBytesField.setAccessible(true);
                                                                                                                                          
                                                                                                                                          Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                          bufferField.setAccessible(true);
                                                                                                                                          Object originalBuffer = bufferField.get(tarOut);
                                                                                                                                          
                                                                                                                                          // Initialize test data - fill buffer with known values
                                                                                                                                          byte[] testData = new byte[assemBuf.length];
                                                                                                                                          java.util.Arrays.fill(testData, (byte)1);  // Fill with 1s
                                                                                                                                          System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                                                                                                                                          
                                                                                                                                          // Set assembly length to half the buffer
                                                                                                                                          int assemLen = assemBuf.length / 2;
                                                                                                                                          assemLenField.set(tarOut, assemLen);
                                                                                                                                          
                                                                                                                                          // Set other required fields
                                                                                                                                          currNameField.set(tarOut, "testEntry");
                                                                                                                                          currSizeField.set(tarOut, assemLen);  // To avoid the size check exception
                                                                                                                                          currBytesField.set(tarOut, 0L);
                                                                                                                                          
                                                                                                                                          // Mock the buffer to capture the written data
                                                                                                                                          Object mockBuffer = mock(originalBuffer.getClass());
                                                                                                                                          bufferField.set(tarOut, mockBuffer);
                                                                                                                                          
                                                                                                                                          // Execute
                                                                                                                                          tarOut.closeArchiveEntry();
                                                                                                                                          
                                                                                                                                          // Verify the buffer zeroing behavior
                                                                                                                                          // Original should only zero from assemLen onward
                                                                                                                                          // Mutant would zero the entire buffer
                                                                                                                                          
                                                                                                                                          // Check that bytes before assemLen remain unchanged (1s)
                                                                                                                                          for (int i = 0; i < assemLen; i++) {
                                                                                                                                              assertEquals("Byte at position " + i + " should remain unchanged", 
                                                                                                                                                          (byte)1, assemBuf[i]);
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          // Check that bytes from assemLen onward are zeroed
                                                                                                                                          for (int i = assemLen; i < assemBuf.length; i++) {
                                                                                                                                              assertEquals("Byte at position " + i + " should be zero", 
                                                                                                                                                          (byte)0, assemBuf[i]);
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          // Verify buffer was written
                                                                                                                                          try {
                                                                                                                                              Method writeRecordMethod = originalBuffer.getClass().getMethod("writeRecord", byte[].class);
                                                                                                                                              verify(mockBuffer).getClass().getMethod("writeRecord", byte[].class).invoke(mockBuffer, assemBuf);
                                                                                                                                          } catch (NoSuchMethodException | InvocationTargetException e) {
                                                                                                                                              fail("Exception occurred during verification: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                 public void testCloseArchiveEntry_ZeroesOutRemainingBuffer() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                     // Setup
                                                                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                     
                                                                                                                                     // Set up test data - partial buffer with some content
                                                                                                                                     int recordSize = tarOut.getRecordSize();
                                                                                                                                     byte[] testData = new byte[recordSize];
                                                                                                                                     java.util.Arrays.fill(testData, (byte) 0xAA); // Fill with some non-zero value
                                                                                                                                     
                                                                                                                                     // Use reflection to access private fields since we need to test internal behavior
                                                                                                                                     Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                     assemBufField.setAccessible(true);
                                                                                                                                     byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                     System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                                                                                                                                     
                                                                                                                                     Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                     assemLenField.setAccessible(true);
                                                                                                                                     int partialLength = recordSize / 2; // Use half the buffer
                                                                                                                                     assemLenField.set(tarOut, partialLength);
                                                                                                                                     
                                                                                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                     currBytesField.setAccessible(true);
                                                                                                                                     currBytesField.set(tarOut, 0L);
                                                                                                                                     
                                                                                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                     currSizeField.setAccessible(true);
                                                                                                                                     currSizeField.set(tarOut, (long) partialLength);
                                                                                                                                     
                                                                                                                                     // Execute
                                                                                                                                     tarOut.closeArchiveEntry();
                                                                                                                                     
                                                                                                                                     // Verify
                                                                                                                                     // Check that remaining buffer was zeroed out
                                                                                                                                     for (int i = partialLength; i < assemBuf.length; i++) {
                                                                                                                                         assertEquals("Buffer position " + i + " should be zero", 0, assemBuf[i]);
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     // Verify buffer was written
                                                                                                                                     verify(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                 }

    @Test
                                                                                                                    public void testCloseArchiveEntry_WithAssembledData_ShouldWriteBuffer() throws Exception {
                                                                                                                        // Setup
                                                                                                                        OutputStream mockOut = mock(OutputStream.class);
                                                                                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                        
                                                                                                                        // Use reflection to access private fields
                                                                                                                        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                        bufferField.setAccessible(true);
                                                                                                                        Object buffer = bufferField.get(tarOut); // Get the actual TarBuffer instance
                                                                                                                        
                                                                                                                        Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                        assemBufField.setAccessible(true);
                                                                                                                        byte[] assemBuf = new byte[512];
                                                                                                                        assemBufField.set(tarOut, assemBuf);
                                                                                                                        
                                                                                                                        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                        assemLenField.setAccessible(true);
                                                                                                                        assemLenField.set(tarOut, 100); // Some assembled data
                                                                                                                        
                                                                                                                        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                        currBytesField.setAccessible(true);
                                                                                                                        currBytesField.set(tarOut, 0);
                                                                                                                        
                                                                                                                        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                        currSizeField.setAccessible(true);
                                                                                                                        currSizeField.set(tarOut, 200); // Expecting 200 bytes total
                                                                                                                        
                                                                                                                        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                                        haveUnclosedEntryField.setAccessible(true);
                                                                                                                        haveUnclosedEntryField.set(tarOut, true);
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        tarOut.closeArchiveEntry();
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        // 1. Verify output stream was written to (indirect verification)
                                                                                                                        verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                        
                                                                                                                        // 2. Verify remaining bytes were zeroed out
                                                                                                                        for (int i = 100; i < assemBuf.length; i++) {
                                                                                                                            assertEquals(0, assemBuf[i]);
                                                                                                                        }
                                                                                                                        
                                                                                                                        // 3. Verify currBytes was updated correctly
                                                                                                                        assertEquals(100, currBytesField.get(tarOut));
                                                                                                                        
                                                                                                                        // 4. Verify assemLen was reset
                                                                                                                        assertEquals(0, assemLenField.get(tarOut));
                                                                                                                        
                                                                                                                        // 5. Verify haveUnclosedEntry was set to false
                                                                                                                        assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                                                                    }

    @Test
                                                                                                       public void testCloseArchiveEntry_AccumulatesAssembledLength() throws Exception {
                                                                                                           // Setup
                                                                                                           ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                           
                                                                                                           // Use reflection to set private fields
                                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                           currBytesField.setAccessible(true);
                                                                                                           currBytesField.set(tarOut, 100L);  // Previous accumulated bytes
                                                                                                           
                                                                                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                           assemLenField.setAccessible(true);
                                                                                                           assemLenField.set(tarOut, 50);     // Current assembled length
                                                                                                           
                                                                                                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                           assemBufField.setAccessible(true);
                                                                                                           assemBufField.set(tarOut, new byte[512]); // Buffer must be initialized
                                                                                                           
                                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                           currSizeField.setAccessible(true);
                                                                                                           currSizeField.set(tarOut, 200L);   // Large enough to avoid exception
                                                                                                           
                                                                                                           // Get the actual buffer instance instead of mocking
                                                                                                           Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                           bufferField.setAccessible(true);
                                                                                                           Object buffer = bufferField.get(tarOut);
                                                                                                           
                                                                                                           // Execute
                                                                                                           tarOut.closeArchiveEntry();
                                                                                                           
                                                                                                           // Verify - this is where we catch the mutant
                                                                                                           // Original: 100 + 50 = 150
                                                                                                           // Mutant: just 50
                                                                                                           assertEquals("currBytes should accumulate assemLen", 
                                                                                                                       150L, currBytesField.get(tarOut));
                                                                                                           
                                                                                                           // Additional verifications
                                                                                                           assertEquals("assemLen should be reset", 0, assemLenField.get(tarOut));
                                                                                                           
                                                                                                           Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                                           haveUnclosedEntryField.setAccessible(true);
                                                                                                           assertFalse("haveUnclosedEntry should be false", haveUnclosedEntryField.getBoolean(tarOut));
                                                                                                       }

    @Test
                                                                                                  public void testCloseArchiveEntry_ResetsAssemLenToZero1() throws Exception {
                                                                                                      // Setup
                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                      
                                                                                                      // Get private fields using reflection
                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                      currBytesField.setAccessible(true);
                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                      currSizeField.setAccessible(true);
                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                      assemLenField.setAccessible(true);
                                                                                                      Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                      assemBufField.setAccessible(true);
                                                                                                      
                                                                                                      // Set initial state where we have assembled data
                                                                                                      currBytesField.setLong(tarOut, 100);
                                                                                                      currSizeField.setLong(tarOut, 100);
                                                                                                      assemLenField.setInt(tarOut, 10); // Some assembled data
                                                                                                      
                                                                                                      byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                      byte[] testBuf = new byte[assemBuf.length];
                                                                                                      System.arraycopy(new byte[10], 0, testBuf, 0, 10);
                                                                                                      System.arraycopy(assemBuf, 0, testBuf, 10, assemBuf.length - 10);
                                                                                                      assemBufField.set(tarOut, testBuf);
                                                                                                      
                                                                                                      // Execute
                                                                                                      tarOut.closeArchiveEntry();
                                                                                                      
                                                                                                      // Verify
                                                                                                      assertEquals("assemLen should be reset to 0 after closing entry", 
                                                                                                                  0, assemLenField.getInt(tarOut));
                                                                                                      
                                                                                                      // Additional verification that buffer was written
                                                                                                      verify(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                                                  }

    @Test
                                                                                             public void testCloseArchiveEntry_throwsIOExceptionWithCompleteMessageWhenNotFullyWritten() throws Exception {
                                                                                                 // Setup
                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                 
                                                                                                 // Use reflection to set private fields
                                                                                                 Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                 currNameField.setAccessible(true);
                                                                                                 currNameField.set(tarOut, "testEntry.txt");
                                                                                                 
                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                 currSizeField.setAccessible(true);
                                                                                                 currSizeField.set(tarOut, 100L);  // Expected size
                                                                                                 
                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                 currBytesField.setAccessible(true);
                                                                                                 currBytesField.set(tarOut, 50L);   // Only written half
                                                                                                 
                                                                                                 try {
                                                                                                     // When
                                                                                                     tarOut.closeArchiveEntry();
                                                                                                     fail("Expected IOException to be thrown");
                                                                                                 } catch (IOException e) {
                                                                                                     // Then
                                                                                                     String expectedSubstring = "entry 'testEntry.txt' closed at '50' before the '100'";
                                                                                                     assertTrue("Exception message should contain entry details", 
                                                                                                               e.getMessage().contains(expectedSubstring));
                                                                                                     throw e;
                                                                                                 }
                                                                                             }

    @Test
                                                                                        public void testCloseArchiveEntry_throwsIOExceptionWithCorrectMessageWhenUnderflow() throws Exception {
                                                                                            // Setup
                                                                                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                            
                                                                                            // Use reflection to set private fields
                                                                                            Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                            currNameField.setAccessible(true);
                                                                                            currNameField.set(tarOut, "test.txt");
                                                                                            
                                                                                            Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                            currSizeField.setAccessible(true);
                                                                                            currSizeField.set(tarOut, 100L);  // Expected to write 100 bytes
                                                                                            
                                                                                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                            currBytesField.setAccessible(true);
                                                                                            currBytesField.set(tarOut, 50L);  // Only wrote 50 bytes
                                                                                            
                                                                                            // Test & Verify
                                                                                            try {
                                                                                                tarOut.closeArchiveEntry();
                                                                                                fail("Expected IOException to be thrown");
                                                                                            } catch (IOException e) {
                                                                                                // Verify the message contains the correct "written" phrase
                                                                                                assertTrue("Exception message should contain 'written'", 
                                                                                                          e.getMessage().contains("written"));
                                                                                                // The following assertion would catch the mutant:
                                                                                                assertFalse("Exception message should not contain 'read'", 
                                                                                                           e.getMessage().contains("read"));
                                                                                            }
                                                                                            
                                                                                            // Verify state was reset
                                                                                            Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                            haveUnclosedEntryField.setAccessible(true);
                                                                                            assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                                                                        }

    @Test
                                                                               public void testCloseArchiveEntry_WithSingleByteAssembledBuffer_ShouldWriteBuffer() throws Exception {
                                                                                   // Setup
                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                   
                                                                                   // Use reflection to set private fields
                                                                                   Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                   assemLenField.setAccessible(true);
                                                                                   assemLenField.set(tarOut, 1);
                                                                                   
                                                                                   Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                   assemBufField.setAccessible(true);
                                                                                   byte[] assemBuf = new byte[512]; // Default record size
                                                                                   assemBuf[0] = 0x42; // Some test data
                                                                                   assemBufField.set(tarOut, assemBuf);
                                                                                   
                                                                                   Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                   currSizeField.setAccessible(true);
                                                                                   currSizeField.set(tarOut, 1L);
                                                                                   
                                                                                   Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                   currBytesField.setAccessible(true);
                                                                                   currBytesField.set(tarOut, 0L);
                                                                                   
                                                                                   // Test
                                                                                   tarOut.closeArchiveEntry();
                                                                                   
                                                                                   // Verify
                                                                                   // 1. Current bytes should be updated (would be 0 with mutant)
                                                                                   assertEquals(1L, currBytesField.get(tarOut));
                                                                                   
                                                                                   // 2. Assembled length should be reset
                                                                                   assertEquals(0, assemLenField.get(tarOut));
                                                                                   
                                                                                   // 3. Entry should be marked as closed
                                                                                   Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                                   haveUnclosedEntryField.setAccessible(true);
                                                                                   assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                                                                   
                                                                                   // 4. Verify buffer was zeroed after position 1 (would fail with mutant)
                                                                                   byte[] currentAssemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                   for (int i = 1; i < currentAssemBuf.length; i++) {
                                                                                       assertEquals(0, currentAssemBuf[i]);
                                                                                   }
                                                                                   
                                                                                   // Verify the output stream was written to (indirect verification of buffer write)
                                                                                   verify(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                               }

    @Test
                                                                      public void testCloseArchiveEntryWithZeroAssemLen() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                          // Setup
                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                          
                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                          
                                                                          // Use reflection to set private fields since we need to test specific conditions
                                                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                          assemLenField.setAccessible(true);
                                                                          assemLenField.set(tarOut, 0); // Critical: set assemLen to 0
                                                                          
                                                                          Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                          currBytesField.setAccessible(true);
                                                                          currBytesField.set(tarOut, 100L);
                                                                          
                                                                          Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                          currSizeField.setAccessible(true);
                                                                          currSizeField.set(tarOut, 100L);
                                                                          
                                                                          // Spy on the output stream to verify interactions
                                                                          OutputStream spyOut = spy(mockOut);
                                                                          Field outField = TarArchiveOutputStream.class.getDeclaredField("out");
                                                                          outField.setAccessible(true);
                                                                          outField.set(tarOut, spyOut);
                                                                          
                                                                          // Execute
                                                                          tarOut.closeArchiveEntry();
                                                                          
                                                                          // Verify - with assemLen=0, no writes should be made to the output stream
                                                                          verify(spyOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                          
                                                                          // Additional verification that other expected behavior occurred
                                                                          assertEquals(0, assemLenField.get(tarOut)); // assemLen should be reset to 0
                                                                          Field haveUnclosedEntryField = tarOut.getClass().getDeclaredField("haveUnclosedEntry");
                                                                          haveUnclosedEntryField.setAccessible(true);
                                                                          assertFalse((boolean) haveUnclosedEntryField.get(tarOut));
                                                                      }

    @Test
                                                             public void testCloseArchiveEntry_OnlyZerosUnusedBufferPortion() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                 // Setup
                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                 // Create real TarBuffer instead of mocking since it's not public
                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                 
                                                                 // Use reflection to get the buffer field from the TarArchiveOutputStream
                                                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                 bufferField.setAccessible(true);
                                                                 Object buffer = bufferField.get(tarOut); // Get the actual buffer instance
                                                                 
                                                                 // Use reflection to set private fields since we need to test internal behavior
                                                                 Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                 assemBufField.setAccessible(true);
                                                                 byte[] assemBuf = new byte[10];
                                                                 java.util.Arrays.fill(assemBuf, (byte) 1); // Fill with 1s initially
                                                                 assemBufField.set(tarOut, assemBuf);
                                                                 
                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                 assemLenField.setAccessible(true);
                                                                 assemLenField.set(tarOut, 5); // First 5 bytes are "used"
                                                                 
                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                 currBytesField.setAccessible(true);
                                                                 currBytesField.set(tarOut, 100L);
                                                                 
                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                 currSizeField.setAccessible(true);
                                                                 currSizeField.set(tarOut, 100L);
                                                                 
                                                                 // Execute
                                                                 tarOut.closeArchiveEntry();
                                                                 
                                                                 // Verify
                                                                 byte[] modifiedBuf = (byte[]) assemBufField.get(tarOut);
                                                                 // First 5 bytes should remain 1s (not zeroed)
                                                                 for (int i = 0; i < 5; i++) {
                                                                     assertEquals("Original data was overwritten at position " + i, 
                                                                                 (byte) 1, modifiedBuf[i]);
                                                                 }
                                                                 // Bytes from assemLen (5) onward should be zeroed
                                                                 for (int i = 5; i < modifiedBuf.length; i++) {
                                                                     assertEquals("Byte not zeroed at position " + i, 
                                                                                 (byte) 0, modifiedBuf[i]);
                                                                 }
                                                                 
                                                                 // Instead of verifying with Mockito, we can check the buffer contents directly
                                                                 // since we can't mock the TarBuffer's writeRecord method
                                                                 // The verification of buffer writing is implicit in the above checks
                                                             }

    @Test
                                                public void testCloseArchiveEntry_WithAssembledData_ShouldWriteBuffer1() throws Exception {
                                                    // Setup test data
                                                    int recordSize = 512; // Default record size
                                                    byte[] testData = new byte[100];
                                                    java.util.Arrays.fill(testData, (byte) 1); // Fill with some data
                                                    
                                                    // Create mocks
                                                    OutputStream mockOut = mock(OutputStream.class);
                                                    
                                                    // Create instance and set test state
                                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                    
                                                    // Use reflection to set private fields
                                                    java.lang.reflect.Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                    currNameField.setAccessible(true);
                                                    currNameField.set(tarOut, "testEntry");
                                                    
                                                    java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                    currSizeField.setAccessible(true);
                                                    currSizeField.set(tarOut, 200L); // More than we'll write
                                                    
                                                    java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                    currBytesField.setAccessible(true);
                                                    currBytesField.set(tarOut, 100L); // Already written 100 bytes
                                                    
                                                    java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                    assemBufField.setAccessible(true);
                                                    byte[] assemBuf = new byte[recordSize];
                                                    System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                                                    assemBufField.set(tarOut, assemBuf);
                                                    
                                                    java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                    assemLenField.setAccessible(true);
                                                    assemLenField.set(tarOut, testData.length);
                                                    
                                                    // Execute
                                                    tarOut.closeArchiveEntry();
                                                    
                                                    // Verify the assembled buffer was written to the output stream
                                                    // Since we can't verify TarBuffer directly, we verify the mock OutputStream received the data
                                                    // The assembled data should be written as part of the record (512 bytes)
                                                    byte[] expectedRecord = new byte[recordSize];
                                                    System.arraycopy(testData, 0, expectedRecord, 0, testData.length);
                                                    verify(mockOut).write(expectedRecord, 0, recordSize);
                                                    
                                                    // Verify counters were updated
                                                    assertEquals(200L, currBytesField.get(tarOut)); // 100 initial + 100 from assemLen
                                                    assertEquals(0, assemLenField.get(tarOut)); // Should be reset
                                                    
                                                    java.lang.reflect.Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                    haveUnclosedEntryField.setAccessible(true);
                                                    assertFalse((boolean) haveUnclosedEntryField.get(tarOut)); // Should be marked as closed
                                                }

    @Test
                                           public void testCloseArchiveEntryAccumulatesBytesCorrectly() throws Exception {
                                               // Setup
                                               ByteArrayOutputStream out = new ByteArrayOutputStream();
                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                               
                                               // Use reflection to set private fields
                                               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                               currBytesField.setAccessible(true);
                                               currBytesField.setLong(tarOut, 100L);  // Simulate previous writes
                                               
                                               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                               currSizeField.setAccessible(true);
                                               currSizeField.setLong(tarOut, 150L);   // Total expected size
                                               
                                               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                               assemLenField.setAccessible(true);
                                               assemLenField.setInt(tarOut, 50);     // Current assembled data length
                                               
                                               Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                               assemBufField.setAccessible(true);
                                               assemBufField.set(tarOut, new byte[512]); // Standard buffer size
                                               
                                               // Execute
                                               tarOut.closeArchiveEntry();
                                               
                                               // Verify
                                               // Original: 100 + 50 = 150 (matches currSize)
                                               // Mutant: 50 (replaces previous value) which is < 150 and should throw exception
                                               // Since the mutant would set currBytes to 50, the check currBytes < currSize would be true
                                               // and throw IOException, while original would not throw
                                               
                                               // If we reach here, original behavior passed (no exception)
                                               Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                               haveUnclosedEntryField.setAccessible(true);
                                               assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                               
                                               assertEquals(150L, currBytesField.getLong(tarOut)); // Verify accumulation
                                           }

    @Test
                                           public void testMutantWouldThrowException() throws IOException, NoSuchFieldException, IllegalAccessException {
                                               // This test simulates what would happen with the mutant
                                               ByteArrayOutputStream out = new ByteArrayOutputStream();
                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                               
                                               // Get private fields using reflection
                                               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                               currBytesField.setAccessible(true);
                                               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                               currSizeField.setAccessible(true);
                                               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                               assemLenField.setAccessible(true);
                                               Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                               assemBufField.setAccessible(true);
                                               
                                               // Set values using reflection
                                               currBytesField.setLong(tarOut, 100L);
                                               currSizeField.setLong(tarOut, 150L);
                                               assemLenField.setInt(tarOut, 50);
                                               assemBufField.set(tarOut, new byte[512]);
                                               
                                               // Simulate mutant behavior
                                               int assemLen = assemLenField.getInt(tarOut);
                                               currBytesField.setLong(tarOut, assemLen); // Instead of +=
                                               
                                               // Check condition using reflection
                                               long currBytes = currBytesField.getLong(tarOut);
                                               long currSize = currSizeField.getLong(tarOut);
                                               
                                               // This should throw IOException because currBytes (50) < currSize (150)
                                               if (currBytes < currSize) {
                                                   throw new IOException("entry closed before all bytes written");
                                               }
                                           }

    @Test
                                  public void testCloseArchiveEntry_ResetsAssemLenToZero2() throws Exception {
                                      // Setup
                                      ByteArrayOutputStream out = new ByteArrayOutputStream();
                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                      
                                      // Get private fields using reflection
                                      Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                      assemBufField.setAccessible(true);
                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                      assemLenField.setAccessible(true);
                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                      currBytesField.setAccessible(true);
                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                      currSizeField.setAccessible(true);
                                      Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                      haveUnclosedEntryField.setAccessible(true);
                                      
                                      // Set initial conditions where we have assembled data
                                      byte[] testData = new byte[10];
                                      java.util.Arrays.fill(testData, (byte)1);
                                      byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                      System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                                      assemLenField.set(tarOut, testData.length);
                                      currBytesField.set(tarOut, 0);
                                      currSizeField.set(tarOut, testData.length);
                                      
                                      // Action
                                      tarOut.closeArchiveEntry();
                                      
                                      // Verification
                                      assertEquals("assemLen should be reset to 0 after closing entry", 
                                                  0, assemLenField.get(tarOut));
                                      
                                      // Additional verification that the entry was properly closed
                                      assertFalse("haveUnclosedEntry should be false after closing", 
                                                  (boolean) haveUnclosedEntryField.get(tarOut));
                                  }

    @Test
                             public void testCloseArchiveEntry_throwsIOExceptionWithEntryName() throws Exception {
                                 // Setup test data
                                 String entryName = "testEntry";
                                 long expectedSize = 100L;
                                 long actualBytes = 50L;
                                 
                                 // Create output stream mock
                                 OutputStream osMock = mock(OutputStream.class);
                                 
                                 // Create TarArchiveOutputStream with mock
                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(osMock);
                                 
                                 // Set up object state to trigger the error condition using reflection
                                 Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                 currNameField.setAccessible(true);
                                 currNameField.set(tarOut, entryName);
                                 
                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                 currSizeField.setAccessible(true);
                                 currSizeField.set(tarOut, expectedSize);
                                 
                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                 currBytesField.setAccessible(true);
                                 currBytesField.set(tarOut, actualBytes);
                                 
                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                 haveUnclosedEntryField.setAccessible(true);
                                 haveUnclosedEntryField.set(tarOut, true);
                                 
                                 // Mock the buffer to avoid NPE
                                 Class<?> tarBufferClass = Class.forName("org.apache.commons.compress.archivers.tar.TarBuffer");
                                 Object bufferMock = mock(tarBufferClass);
                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                 bufferField.setAccessible(true);
                                 bufferField.set(tarOut, bufferMock);
                                 
                                 try {
                                     tarOut.closeArchiveEntry();
                                     fail("Expected IOException to be thrown");
                                 } catch (IOException e) {
                                     // Verify the exception message contains the entry name
                                     assertTrue("Exception message should contain entry name", 
                                               e.getMessage().contains(entryName));
                                     throw e;
                                 }
                             }

    @Test
    public void testCloseArchiveEntryWithSingleByteBuffer() throws Exception {
        // Setup
        OutputStream mockOut = mock(OutputStream.class);
        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
        
        // Use reflection to set private fields
        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
        assemLenField.setAccessible(true);
        assemLenField.set(tarOut, 1);
        
        Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
        assemBufField.setAccessible(true);
        byte[] assemBuf = new byte[512]; // Default record size
        assemBuf[0] = 0x42; // Set some value in first byte
        assemBufField.set(tarOut, assemBuf);
        
        Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
        currNameField.setAccessible(true);
        currNameField.set(tarOut, "test.txt");
        
        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
        currSizeField.setAccessible(true);
        currSizeField.set(tarOut, 1L);
        
        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
        currBytesField.setAccessible(true);
        currBytesField.set(tarOut, 0L);
        
        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
        haveUnclosedEntryField.setAccessible(true);
        haveUnclosedEntryField.set(tarOut, true);
        
        // Mock the buffer using the actual type from reflection
        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
        bufferField.setAccessible(true);
        Object mockBuffer = mock(bufferField.getType());  // Mock using the actual type
        when(mockBuffer.getClass().getMethod("writeRecord", byte[].class).invoke(mockBuffer, any(byte[].class))).thenReturn(null);
        bufferField.set(tarOut, mockBuffer);
        
        // Test
        tarOut.closeArchiveEntry();
        
        // Verify behavior that should happen with original code
        // 1. Buffer should be processed (zeroed and written)
        verify(mockBuffer, times(1)).getClass().getMethod("writeRecord", byte[].class).invoke(mockBuffer, any(byte[].class));
        
        // 2. currBytes should be updated
        assertEquals(1L, currBytesField.get(tarOut));
        
        // 3. assemLen should be reset
        assertEquals(0, assemLenField.get(tarOut));
        
        // 4. Entry should be marked as closed
        assertFalse((Boolean)haveUnclosedEntryField.get(tarOut));
        
        // Additional verification that remaining bytes were zeroed
        Method writeRecordMethod = mockBuffer.getClass().getMethod("writeRecord", byte[].class);
        byte[] testBuffer = new byte[512];
        writeRecordMethod.invoke(mockBuffer, testBuffer);
        assertEquals(0, testBuffer[1]); // Second byte should be zeroed
    }


}
