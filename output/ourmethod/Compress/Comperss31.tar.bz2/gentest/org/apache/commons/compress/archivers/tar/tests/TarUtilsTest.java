package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                          public void testParseOctal_ValidOctalNumber() {
                                                                              byte[] buffer = {' ', '1', '2', '3', '4', ' ', ' '};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 7);
                                                                              assertEquals(668, result); // 1234 in octal is 668 in decimal
                                                                          }

 @Test
                                                                          public void testParseOctal_LeadingZeros() {
                                                                              byte[] buffer = {'0', '0', '1', '2', '3'};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 5);
                                                                              assertEquals(0L, result); // Leading zero should return 0
                                                                          }

 @Test
                                                                          public void testParseOctal_LeadingAndTrailingSpaces() {
                                                                              byte[] buffer = {' ', ' ', '7', '5', ' ', ' '};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                              assertEquals(61, result); // 75 in octal is 61 in decimal
                                                                          }

 @Test
                                                                          public void testParseOctal_MaximumOctalDigits() {
                                                                              byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 12);
                                                                              assertEquals(037777777777L, result); // Maximum 12-digit octal number
                                                                          }

 @Test
                                                                          public void testParseOctal_EmptyBuffer() {
                                                                              byte[] buffer = {};
                                                                              thrown.expect(IllegalArgumentException.class);
                                                                              thrown.expectMessage("Length 0 must be at least 2");
                                                                              TarUtils.parseOctal(buffer, 0, 0);
                                                                          }

 @Test
                                                                          public void testParseOctal_InvalidLength() {
                                                                              byte[] buffer = {'1'};
                                                                              thrown.expect(IllegalArgumentException.class);
                                                                              thrown.expectMessage("Length 1 must be at least 2");
                                                                              TarUtils.parseOctal(buffer, 0, 1);
                                                                          }

 @Test
                                                                          public void testParseOctal_InvalidOctalDigit() {
                                                                              byte[] buffer = {'1', '2', '8', '4'}; // '8' is invalid in octal
                                                                              thrown.expect(IllegalArgumentException.class);
                                                                              thrown.expectMessage("Invalid octal digit");
                                                                              TarUtils.parseOctal(buffer, 0, 4);
                                                                          }

 @Test
                                                                          public void testParseOctal_AllSpaces() {
                                                                              byte[] buffer = {' ', ' ', ' ', ' '};
                                                                              thrown.expect(IllegalArgumentException.class);
                                                                              thrown.expectMessage("Invalid octal digit");
                                                                              TarUtils.parseOctal(buffer, 0, 4);
                                                                          }

 @Test
                                                                          public void testParseOctal_TrailingNULs() {
                                                                              byte[] buffer = {'1', '2', '3', 0, 0, 0};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                              assertEquals(83, result); // 123 in octal is 83 in decimal
                                                                          }

 @Test
                                                                          public void testParseOctal_TrailingSpacesAndNULs() {
                                                                              byte[] buffer = {'6', '4', ' ', 0, ' ', 0};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                              assertEquals(52, result); // 64 in octal is 52 in decimal
                                                                          }

 @Test
                                                                          public void testParseOctal_OffsetParameter() {
                                                                              byte[] buffer = {'X', 'X', '1', '2', '3', 'X', 'X'};
                                                                              long result = TarUtils.parseOctal(buffer, 2, 3);
                                                                              assertEquals(83, result); // 123 in octal is 83 in decimal
                                                                          }

 @Test
                                                                          public void testParseOctal_SingleValidDigit() {
                                                                              byte[] buffer = {' ', '7', ' '};
                                                                              long result = TarUtils.parseOctal(buffer, 0, 3);
                                                                              assertEquals(7, result);
                                                                          }

 @Test
                                                                          public void testParseOctal_NonASCIIBytes() {
                                                                              byte[] buffer = {(byte)0xFF, (byte)0xFE, '1', '2'};
                                                                              thrown.expect(IllegalArgumentException.class);
                                                                              thrown.expectMessage("Invalid octal digit");
                                                                              TarUtils.parseOctal(buffer, 0, 4);
                                                                          }

 @Test
                          public void testParseOctalInvalidDigits() {
                              // Test with byte below '0' (ASCII 44 is ',')
                              byte[] buffer1 = {' ', ' ', ',', ' '};
                              try {
                                  TarUtils.parseOctal(buffer1, 0, 4);
                                  fail("Should throw IllegalArgumentException for byte below '0'");
                              } catch (IllegalArgumentException e) {
                                  // Expected
                              }
                          
                              // Test with byte above '7' (ASCII '8' is valid, '9' is invalid)
                              byte[] buffer2 = {' ', '1', '9', ' '};
                              try {
                                  TarUtils.parseOctal(buffer2, 0, 4);
                                  fail("Should throw IllegalArgumentException for byte above '7'");
                              } catch (IllegalArgumentException e) {
                                  // Expected
                              }
                          
                              // Test with valid bytes between '0' and '7'
                              byte[] buffer3 = {' ', '1', '5', ' '};
                              long result = TarUtils.parseOctal(buffer3, 0, 4);
                              assertEquals(15L, result);  // Octal 15 = decimal 13
                          }

 @Test
                         public void testParseOctalDetectsMutatedValidation() {
                             // Test with valid digits that mutant would reject
                             byte[] validZero = {' ', '0', ' '};
                             assertEquals(0L, TarUtils.parseOctal(validZero, 0, 3));
                             
                             byte[] validSeven = {' ', '7', ' '};
                             assertEquals(7L, TarUtils.parseOctal(validSeven, 0, 3));
                             
                             // Test with invalid digits that mutant would accept
                             byte[] invalidLow = {' ', (byte)('0'-1), ' '}; // '/'
                             try {
                                 TarUtils.parseOctal(invalidLow, 0, 3);
                                 fail("Should have thrown IllegalArgumentException for byte < '0'");
                             } catch (IllegalArgumentException e) {
                                 // expected
                             }
                             
                             byte[] invalidHigh = {' ', (byte)('7'+1), ' '}; // '8'
                             try {
                                 TarUtils.parseOctal(invalidHigh, 0, 3);
                                 fail("Should have thrown IllegalArgumentException for byte > '7'");
                             } catch (IllegalArgumentException e) {
                                 // expected
                             }
                             
                             // Test normal valid case
                             byte[] normalOctal = {' ', '1', '2', '3', ' '};
                             assertEquals(83L, TarUtils.parseOctal(normalOctal, 0, 5)); // 123 octal = 83 decimal
                         }

 @Test
                        public void testParseOctalWithDigit7ShouldNotThrowException() {
                            // Arrange
                            byte[] buffer = {' ', '7', ' ', ' '}; // Valid octal "7" with spaces
                            int offset = 0;
                            int length = 4;
                            
                            // Act
                            long result = TarUtils.parseOctal(buffer, offset, length);
                            
                            // Assert
                            assertEquals(7L, result); // Should parse to 7 without throwing exception
                        }

 @Test
                        public void testParseOctalWithDigit7ShouldNotThrowExceptionNoSpaces() {
                            // Arrange
                            byte[] buffer = {'7', '0'}; // Valid octal "70"
                            int offset = 0;
                            int length = 2;
                            
                            // Act
                            long result = TarUtils.parseOctal(buffer, offset, length);
                            
                            // Assert
                            assertEquals(7 * 8 + 0, result); // Should parse to 56 (70 in octal)
                        }

 @Test(expected = IllegalArgumentException.class)
                        public void testParseOctalWithInvalidDigit8ShouldThrowException() {
                            // Arrange
                            byte[] buffer = {'8'}; // Invalid octal digit
                            int offset = 0;
                            int length = 1;
                            
                            // Act - should throw
                            TarUtils.parseOctal(buffer, offset, length);
                        }

 @Test
                       public void testParseOctalWithByteEqualToZeroShouldNotThrowException() {
                           // Setup
                           byte[] buffer = new byte[] {' ', '0', '1', '2', ' '}; // Contains '0' (ASCII 48)
                           int offset = 0;
                           int length = buffer.length;
                           
                           // Test - should not throw exception for '0' in original
                           // Mutant would incorrectly process if condition was <= '0'
                           long result = TarUtils.parseOctal(buffer, offset, length);
                           
                           // Verify - '0' should be processed normally
                           assertEquals(012, result); // Octal 012 is decimal 10
                       }

 @Test(expected = IllegalArgumentException.class)
                       public void testParseOctalWithByteLessThanZeroShouldThrowException() {
                           // Setup - using '/' (ASCII 47) which is less than '0'
                           byte[] buffer = new byte[] {' ', '/', '1', '2', ' '};
                           int offset = 0;
                           int length = buffer.length;
                           
                           // Test - should throw exception
                           TarUtils.parseOctal(buffer, offset, length);
                           
                           // Exception expected
                       }

 @Test(expected = IllegalArgumentException.class)
                      public void testParseOctalWithInvalidDigitsShouldThrowException() {
                          // Arrange
                          byte[] buffer = {
                              ' ', ' ', '1', '2', '8', '4', ' ', ' '  // '8' is invalid for octal
                          };
                          int offset = 0;
                          int length = buffer.length;
                          
                          // Act - should throw IllegalArgumentException for invalid digit '8'
                          TarUtils.parseOctal(buffer, offset, length);
                          
                          // Assert - handled by the expected exception in @Test annotation
                      }

 @Test
                     public void testParseOctalDetectsMutant() {
                         // Test case that will detect the mutant by checking behavior with '0' and '7'
                         
                         // Valid octal digits that should pass in both original and mutant
                         byte[] validInput = "123456".getBytes();
                         assertEquals(342391L, TarUtils.parseOctal(validInput, 0, validInput.length));
                         
                         // Test with '0' - should throw in original but pass in mutant
                         byte[] zeroInput = "012345".getBytes();
                         try {
                             TarUtils.parseOctal(zeroInput, 0, zeroInput.length);
                             // If we get here in original, the test should fail (but pass in mutant)
                             fail("Expected IllegalArgumentException for input containing '0'");
                         } catch (IllegalArgumentException e) {
                             // Expected in original
                             assertTrue(e.getMessage().contains("exception"));
                         }
                         
                         // Test with '7' - should pass in original but throw in mutant
                         byte[] sevenInput = "123457".getBytes();
                         try {
                             assertEquals(342391L, TarUtils.parseOctal(sevenInput, 0, sevenInput.length));
                             // Passes in original, fails in mutant
                         } catch (IllegalArgumentException e) {
                             // Fails in original, passes in mutant
                             fail("Original should accept '7' but mutant throws exception");
                         }
                         
                         // Test with invalid character (< '0')
                         byte[] lowInvalidInput = "12-456".getBytes();
                         try {
                             TarUtils.parseOctal(lowInvalidInput, 0, lowInvalidInput.length);
                             fail("Expected IllegalArgumentException for input containing '-'");
                         } catch (IllegalArgumentException e) {
                             assertTrue(e.getMessage().contains("exception"));
                         }
                         
                         // Test with invalid character (> '7')
                         byte[] highInvalidInput = "123458".getBytes();
                         try {
                             TarUtils.parseOctal(highInvalidInput, 0, highInvalidInput.length);
                             fail("Expected IllegalArgumentException for input containing '8'");
                         } catch (IllegalArgumentException e) {
                             assertTrue(e.getMessage().contains("exception"));
                         }
                     }

 @Test(expected = IllegalArgumentException.class)
                    public void testParseOctal_InvalidDigit8_ShouldThrowException() {
                        // Arrange
                        byte[] buffer = {
                            ' ', ' ', '1', '2', '8', '4', ' ', ' '  // Contains invalid octal digit '8'
                        };
                        int offset = 0;
                        int length = buffer.length;
                        
                        // Act - should throw IllegalArgumentException
                        TarUtils.parseOctal(buffer, offset, length);
                        
                        // Assert - handled by expected exception in annotation
                    }

 @Test(expected = IllegalArgumentException.class)
                    public void testParseOctal_InvalidDigit9_ShouldThrowException() {
                        // Arrange
                        byte[] buffer = {
                            ' ', ' ', '1', '2', '9', '4', ' ', ' '  // Contains invalid octal digit '9'
                        };
                        int offset = 0;
                        int length = buffer.length;
                        
                        // Act - should throw IllegalArgumentException
                        TarUtils.parseOctal(buffer, offset, length);
                        
                        // Assert - handled by expected exception in annotation
                    }

 @Test(expected = IllegalArgumentException.class)
                       public void testParseOctalWithControlCharacterShouldThrow() {
                           // Create buffer with a control character (ASCII 31) which is < '0' but >= ' '
                           byte[] buffer = new byte[] {' ', ' ', '0', '1', '2', 31, '3', ' '};
                           
                           // This should throw IllegalArgumentException in original code
                           // Mutant would accept the control character (31) and try to parse it
                           TarUtils.parseOctal(buffer, 0, buffer.length);
                       }

 @Test
                       public void testParseOctalWithValidDigits() {
                           byte[] buffer = new byte[] {' ', ' ', '1', '2', '3', '4', ' '};
                           long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                           assertEquals(1234L, result);
                       }

 @Test(expected = IllegalArgumentException.class)
                       public void testParseOctalWithInvalidDigitBelowZero() {
                           byte[] buffer = new byte[] {' ', ' ', '1', '2', '/', '4', ' '}; // '/' is ASCII 47
                           TarUtils.parseOctal(buffer, 0, buffer.length);
                       }

 @Test(expected = IllegalArgumentException.class)
                       public void testParseOctalWithInvalidDigitAboveSeven() {
                           byte[] buffer = new byte[] {' ', ' ', '1', '2', '8', '4', ' '}; // '8' is invalid in octal
                           TarUtils.parseOctal(buffer, 0, buffer.length);
                       }

 @Test(expected = IllegalArgumentException.class)
                  public void testParseOctalWithInvalidCharsBetweenSpaceAndZero() {
                      // Create a buffer containing an invalid octal digit between space and '0' ('!' = 33)
                      byte[] buffer = {
                          ' ', ' ', '!', '1', '2', '3', ' ', ' '  // Contains '!' which is invalid
                      };
                      
                      // The method should throw IllegalArgumentException for invalid octal digit '!'
                      TarUtils.parseOctal(buffer, 0, buffer.length);
                      
                      // If we reach here, the test fails (mutant survived)
                      // The mutant would accept '!' as valid since it's > ' ' but < '0'
                      fail("Expected IllegalArgumentException for invalid octal digit '!'");
                  }

 @Test
                 public void testParseOctalWithInvalidDigitAfterStartShouldThrow() {
                     // Arrange
                     byte[] buffer = {
                         ' ', '1', '8', '2', ' '  // Contains '8' which is invalid, but not at start
                     };
                     int offset = 0;
                     int length = buffer.length;
                     
                     // Act & Assert
                     try {
                         TarUtils.parseOctal(buffer, offset, length);
                         fail("Expected IllegalArgumentException for invalid octal digit");
                     } catch (IllegalArgumentException e) {
                         // Expected behavior for original method
                         assertTrue(e.getMessage().contains("Invalid octal digit"));
                     }
                 }

 @Test
                public void testParseOctalBoundaryValues() {
                    byte[] buffer;
                    long result;
                    
                    // Test with valid '0' - should pass original but fail mutant
                    buffer = new byte[] {' ', '0', '1', ' '};
                    result = TarUtils.parseOctal(buffer, 0, buffer.length);
                    assertEquals(1L, result); // '01' octal is 1 decimal
                    
                    // Test with valid '7' - should pass original but fail mutant
                    buffer = new byte[] {' ', '7', '0', ' '};
                    result = TarUtils.parseOctal(buffer, 0, buffer.length);
                    assertEquals(7 * 8, result); // '70' octal is 56 decimal
                    
                    // Test with invalid '8' - should fail both
                    buffer = new byte[] {' ', '8', ' '};
                    try {
                        TarUtils.parseOctal(buffer, 0, buffer.length);
                        fail("Should throw IllegalArgumentException for invalid digit '8'");
                    } catch (IllegalArgumentException e) {
                        // expected
                    }
                    
                    // Test with invalid '/' (ASCII just below '0') - should fail both
                    buffer = new byte[] {' ', '/', ' '};
                    try {
                        TarUtils.parseOctal(buffer, 0, buffer.length);
                        fail("Should throw IllegalArgumentException for invalid digit '/'");
                    } catch (IllegalArgumentException e) {
                        // expected
                    }
                    
                    // Test with middle-range value '3' - should pass both
                    buffer = new byte[] {' ', '3', ' '};
                    result = TarUtils.parseOctal(buffer, 0, buffer.length);
                    assertEquals(3L, result);
                }

 @Test
               public void testParseOctalWithDigit() {
                   // Test that '7' is accepted as valid octal digit
                   byte[] buffer = {' ', '7', ' ', ' '}; // "7" with spaces
                   long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                   assertEquals(7L, result);
                   
                   // Test that '8' is rejected
                   byte[] invalidBuffer = {' ', '8', ' ', ' '};
                   try {
                       TarUtils.parseOctal(invalidBuffer, 0, invalidBuffer.length);
                       fail("Should have thrown IllegalArgumentException for '8'");
                   } catch (IllegalArgumentException e) {
                       // expected
                   }
                   
                   // Test that '0'-'6' are accepted
                   for (byte b = '0'; b <= '6'; b++) {
                       byte[] testBuffer = {' ', b, ' ', ' '};
                       long expected = b - '0';
                       assertEquals(expected, 
                           TarUtils.parseOctal(testBuffer, 0, testBuffer.length));
                   }
               }

 @Test(expected = IllegalArgumentException.class)
              public void testParseOctalWithNonDigitBelowZero() {
                  // Create a buffer with a non-digit character between 1 and '0' (ASCII 1 is SOH)
                  byte[] buffer = new byte[] {' ', '1', '2', '3', 1, ' '}; // 1 is SOH character
                  
                  // This should throw IllegalArgumentException in original code
                  // Mutant would pass this through since 1 <= '0' is true but 1 > '7' is false
                  TarUtils.parseOctal(buffer, 0, buffer.length);
                  
                  // If we reach here, the mutant survived
                  fail("Expected IllegalArgumentException for non-octal digit below '0'");
              }

 @Test(expected = IllegalArgumentException.class)
             public void testParseOctal_InvalidDigits_ShouldThrowException() {
                 // Arrange
                 byte[] buffer = {
                     ' ', ' ', '1', '2', '8', ' ', ' '  // '8' is invalid in octal
                 };
                 int offset = 0;
                 int length = buffer.length;
                 
                 // Act - should throw IllegalArgumentException for '8'
                 TarUtils.parseOctal(buffer, offset, length);
                 
                 // Assert - handled by expected exception
             }

 @Test(expected = IllegalArgumentException.class)
             public void testParseOctal_NonOctalDigits_ShouldThrowException() {
                 // Arrange
                 byte[] buffer = {
                     ' ', '5', '9', '3', ' '  // '9' is invalid in octal
                 };
                 int offset = 0;
                 int length = buffer.length;
                 
                 // Act - should throw IllegalArgumentException for '9'
                 TarUtils.parseOctal(buffer, offset, length);
                 
                 // Assert - handled by expected exception
             }

 @Test(expected = IllegalArgumentException.class)
             public void testParseOctal_BelowZeroDigit_ShouldThrowException() {
                 // Arrange
                 byte[] buffer = {
                     '/', '1', '2'  // '/' is ASCII 47, one below '0' (48)
                 };
                 int offset = 0;
                 int length = buffer.length;
                 
                 // Act - should throw IllegalArgumentException for '/'
                 TarUtils.parseOctal(buffer, offset, length);
                 
                 // Assert - handled by expected exception
             }

 @Test
            public void testParseOctalDetectsMutantValidation() {
                // Test case that will catch the mutant
                // The mutant would accept '0' and '7' but original rejects them
                
                // Create test buffer with valid octal digits that mutant would reject
                byte[] buffer1 = {' ', '1', '2', '3', ' '}; // "123" with spaces
                long result1 = TarUtils.parseOctal(buffer1, 0, buffer1.length);
                assertEquals(83L, result1); // 1*64 + 2*8 + 3 = 83
                
                // Test with '0' which mutant would reject but original accepts
                byte[] buffer2 = {'0', '1', '2'};
                long result2 = TarUtils.parseOctal(buffer2, 0, buffer2.length);
                assertEquals(10L, result2); // 0*64 + 1*8 + 2 = 10
                
                // Test with '7' which mutant would reject but original accepts
                byte[] buffer3 = {'7', '1', '2'};
                long result3 = TarUtils.parseOctal(buffer3, 0, buffer3.length);
                assertEquals(458L, result3); // 7*64 + 1*8 + 2 = 458
                
                // Test with invalid digits that original would reject
                try {
                    byte[] buffer4 = {'8', '1', '2'}; // '8' is invalid in octal
                    TarUtils.parseOctal(buffer4, 0, buffer4.length);
                    fail("Should have thrown IllegalArgumentException for invalid digit '8'");
                } catch (IllegalArgumentException e) {
                    // expected
                }
                
                try {
                    byte[] buffer5 = {'/', '1', '2'}; // '/' is ASCII just before '0'
                    TarUtils.parseOctal(buffer5, 0, buffer5.length);
                    fail("Should have thrown IllegalArgumentException for invalid digit '/'");
                } catch (IllegalArgumentException e) {
                    // expected
                }
                
                try {
                    byte[] buffer6 = {'0', ':', '2'}; // ':' is ASCII just after '9'
                    TarUtils.parseOctal(buffer6, 0, buffer6.length);
                    fail("Should have thrown IllegalArgumentException for invalid digit ':'");
                } catch (IllegalArgumentException e) {
                    // expected
                }
            }

 @Test
           public void testParseOctalWithDigit8ShouldThrowException() {
               // Arrange
               byte[] buffer = {' ', '1', '2', '8', '4', ' '}; // Contains '8' which is invalid for octal
               int offset = 0;
               int length = buffer.length;
               
               // Act & Assert
               try {
                   TarUtils.parseOctal(buffer, offset, length);
                   fail("Expected IllegalArgumentException for digit '8'");
               } catch (IllegalArgumentException e) {
                   // Expected behavior - original method should throw
                   assertTrue(e.getMessage().contains("invalid octal digit"));
               }
           }

 @Test(expected = IllegalArgumentException.class)
              public void testParseOctalWithControlCharacter() {
                  // Create a buffer with a control character (ASCII 31) in octal digits
                  byte[] buffer = {
                      ' ', ' ', '0', '1', '2', (byte)31, '7', ' '  // 31 is unit separator control char
                  };
                  
                  // This should throw IllegalArgumentException in original code
                  // Mutated version would accept the control character
                  TarUtils.parseOctal(buffer, 2, 5);  // Test digits 012[31]7
              }

 @Test(expected = IllegalArgumentException.class)
         public void testParseOctal_InvalidDigitAfterFirstPosition_ShouldThrowException() {
             // Arrange
             byte[] buffer = {
                 '1',  // valid octal digit
                 '8',  // invalid octal digit (should trigger exception)
                 '2'   // valid octal digit (but won't be reached)
             };
             int offset = 0;
             int length = 3;
             
             // Act
             TarUtils.parseOctal(buffer, offset, length);
             
             // Assert - exception expected
         }

 @Test
        public void testParseOctalInvalidDigits1() {
            // Test with invalid digit below '0' (ASCII 47 = '/')
            byte[] buffer1 = {' ', '/', ' '};
            try {
                TarUtils.parseOctal(buffer1, 0, 3);
                fail("Should have thrown IllegalArgumentException for character below '0'");
            } catch (IllegalArgumentException e) {
                // Expected
            }
        
            // Test with invalid digit above '7' (ASCII 56 = '8')
            byte[] buffer2 = {' ', '8', ' '};
            try {
                TarUtils.parseOctal(buffer2, 0, 3);
                fail("Should have thrown IllegalArgumentException for character above '7'");
            } catch (IllegalArgumentException e) {
                // Expected
            }
        
            // Test with valid digits (should pass)
            byte[] buffer3 = {' ', '0', ' '};  // min valid
            assertEquals(0L, TarUtils.parseOctal(buffer3, 0, 3));
            
            byte[] buffer4 = {' ', '7', ' '};  // max valid
            assertEquals(7L, TarUtils.parseOctal(buffer4, 0, 3));
            
            byte[] buffer5 = {' ', '3', ' '};  // mid valid
            assertEquals(3L, TarUtils.parseOctal(buffer5, 0, 3));
        }

 @Test
       public void testParseOctalWithDigit7ShouldPass() {
           // Setup test data with valid octal containing '7'
           byte[] buffer = {' ', '1', '7', '2', ' '}; // " 172 " with spaces
           int offset = 0;
           int length = buffer.length;
           
           // Expected behavior: '7' should be accepted as valid octal digit
           long expected = 0127; // Octal 127 = decimal 87
           long actual = TarUtils.parseOctal(buffer, offset, length);
           
           // Assert the correct parsing including digit '7'
           assertEquals("Octal string containing '7' should be parsed correctly", 
                        expected, actual);
           
           // Additional test case with just '7' as boundary
           byte[] single7Buffer = {'0', '7'}; // "07" - valid octal
           long single7Expected = 07; // Octal 7 = decimal 7
           long single7Actual = TarUtils.parseOctal(single7Buffer, 0, 2);
           assertEquals("Single digit '7' should be parsed correctly",
                        single7Expected, single7Actual);
       }

 @Test(expected = IllegalArgumentException.class)
       public void testParseOctalWithInvalidDigit8ShouldFail() {
           // Test with invalid digit to ensure validation still works
           byte[] buffer = {'0', '8'}; // "08" - invalid octal
           TarUtils.parseOctal(buffer, 0, 2);
       }

 @Test
      public void testParseOctalWithZeroDigitShouldNotThrowException() {
          // Arrange
          byte[] buffer = {' ', '0', ' '}; // Contains valid octal digit '0' with spaces
          int offset = 0;
          int length = 3;
          
          // Act
          long result = TarUtils.parseOctal(buffer, offset, length);
          
          // Assert
          assertEquals(0L, result); // Should parse successfully to 0
      }

 @Test(expected = IllegalArgumentException.class)
      public void testParseOctalWithInvalidByteBelowZeroShouldThrowException() {
          // Arrange
          byte[] buffer = {' ', '/', ' '}; // '/' is ASCII 47, just below '0' (48)
          int offset = 0;
          int length = 3;
          
          // Act
          TarUtils.parseOctal(buffer, offset, length);
          
          // Assert - exception expected
      }

 @Test
      public void testParseOctalWithValidZeroDigitInMiddle() {
          // Arrange
          byte[] buffer = {'1', '0', '7'}; // Valid octal number 107
          int offset = 0;
          int length = 3;
          
          // Act
          long result = TarUtils.parseOctal(buffer, offset, length);
          
          // Assert
          assertEquals(71L, result); // 1*64 + 0*8 + 7 = 71
      }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctalWithInvalidDigitsBelowZero() {
         byte[] buffer = {' ', ' ', '/', ' ', ' '}; // '/' is ASCII 47, below '0' (48)
         TarUtils.parseOctal(buffer, 0, buffer.length);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctalWithInvalidDigitsAboveSeven() {
         byte[] buffer = {' ', '8', ' ', ' '}; // '8' is ASCII 56, above '7' (55)
         TarUtils.parseOctal(buffer, 0, buffer.length);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctalWithInvalidDigitsMixed() {
         byte[] buffer = {'0', '1', '9', '2'}; // '9' is invalid
         TarUtils.parseOctal(buffer, 0, buffer.length);
     }

 @Test
    public void testParseOctalWithZeroAndSevenDigits() {
        // Test with '0' which should be valid but mutant would reject
        byte[] bufferWithZero = {' ', '0', '1', '2', ' '};
        long result = TarUtils.parseOctal(bufferWithZero, 0, bufferWithZero.length);
        assertEquals(012L, result); // Octal 012 is decimal 10
    
        // Test with '7' which should be valid but mutant would reject
        byte[] bufferWithSeven = {' ', '1', '7', '2', ' '};
        result = TarUtils.parseOctal(bufferWithSeven, 0, bufferWithSeven.length);
        assertEquals(0172L, result); // Octal 172 is decimal 122
    
        // Test with valid digits 1-6 which both versions accept
        byte[] bufferMiddleDigits = {' ', '1', '2', '3', '4', '5', '6', ' '};
        result = TarUtils.parseOctal(bufferMiddleDigits, 0, bufferMiddleDigits.length);
        assertEquals(0123456L, result); // Octal 123456 is decimal 42798
    
        // Test with invalid digit (8) which both versions should reject
        byte[] bufferInvalidDigit = {' ', '1', '8', '2', ' '};
        try {
            TarUtils.parseOctal(bufferInvalidDigit, 0, bufferInvalidDigit.length);
            fail("Should have thrown IllegalArgumentException for invalid digit");
        } catch (IllegalArgumentException e) {
            // Expected
        }
    }

 @Test(expected = IllegalArgumentException.class)
   public void testParseOctal_ShouldRejectDigit() {
       // Arrange
       byte[] buffer = {' ', '1', '2', '8', ' ', ' '}; // Contains '8' which is invalid for octal
       int offset = 0;
       int length = buffer.length;
       
       // Act - should throw IllegalArgumentException
       TarUtils.parseOctal(buffer, offset, length);
       
       // Assert - handled by expected exception in annotation
   }

 @Test
   public void testParseOctal_ShouldAcceptValidDigits() {
       // Arrange
       byte[] validBuffer = {' ', '1', '2', '7', ' ', ' '}; // All digits 0-7 are valid
       int offset = 0;
       int length = validBuffer.length;
       long expected = 0127L; // Octal literal for decimal 87
       
       // Act
       long result = TarUtils.parseOctal(validBuffer, offset, length);
       
       // Assert
       assertEquals("Valid octal number should be parsed correctly", expected, result);
   }

 @Test
  public void testParseOctalWithBytesBetweenSpaceAndZero() {
      // Create buffer with bytes between space (32) and '0' (48)
      // Using '!' (33) as test case since it's between space and '0'
      byte[] buffer = new byte[] {' ', '!', '1', '2', ' '};
      int offset = 0;
      int length = buffer.length;
      
      try {
          // This should parse successfully in original code
          // Mutant would throw IllegalArgumentException
          long result = TarUtils.parseOctal(buffer, offset, length);
          
          // Verify correct parsing (should ignore '!' and parse '12')
          assertEquals(10L, result); // 12 in octal is 10 in decimal
      } catch (IllegalArgumentException e) {
          // If we get here, the mutant was detected
          fail("Mutant detected: Method incorrectly rejected byte between space and '0'");
      }
  }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctal_InvalidDigitAfterFirstPosition() {
     // Arrange
     byte[] buffer = {
         '1',  // valid first digit
         '8',  // invalid octal digit (should be caught)
         '2'   // valid digit
     };
     int offset = 0;
     int length = 3;
     
     // Act
     TarUtils.parseOctal(buffer, offset, length);
     
     // Assert - exception expected
 }

}
