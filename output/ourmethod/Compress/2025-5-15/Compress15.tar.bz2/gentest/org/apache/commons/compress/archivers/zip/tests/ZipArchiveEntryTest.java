package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testEquals_Reflexive() {
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                        assertTrue(entry.equals(entry));
                                                    }

    @Test
                                                    public void testEquals_NullComparison() {
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                        assertFalse(entry.equals(null));
                                                    }

    @Test
                                                    public void testEquals_DifferentClass() {
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                        assertFalse(entry.equals("string object"));
                                                    }

    @Test
                                                    public void testEquals_DifferentNames() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("file1.txt");
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("file2.txt");
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_SameNamesDifferentOtherAttributes() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setMethod(8);
                                                        entry1.setSize(100);
                                                        entry1.setInternalAttributes(1);
                                                        entry1.setExternalAttributes(2L);
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setMethod(0);
                                                        entry2.setSize(200);
                                                        entry2.setInternalAttributes(3);
                                                        entry2.setExternalAttributes(4L);
                                                        
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_AllAttributesSame() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setMethod(8);
                                                        entry1.setSize(100);
                                                        entry1.setInternalAttributes(1);
                                                        entry1.setExternalAttributes(2L);
                                                        entry1.setComment("comment");
                                                        entry1.setTime(new Date().getTime());
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setMethod(8);
                                                        entry2.setSize(100);
                                                        entry2.setInternalAttributes(1);
                                                        entry2.setExternalAttributes(2L);
                                                        entry2.setComment("comment");
                                                        entry2.setTime(entry1.getTime());
                                                        
                                                        assertTrue(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_DifferentComments() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setComment("comment1");
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setComment("comment2");
                                                        
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_OneNullComment() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setComment(null);
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setComment("comment");
                                                        
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_BothNullComments() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setComment(null);
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setComment(null);
                                                        
                                                        assertTrue(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_DifferentTimes() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setTime(1000L);
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setTime(2000L);
                                                        
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_DifferentExtraFields() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        entry1.setCentralDirectoryExtra(new byte[]{1, 2, 3});
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        entry2.setCentralDirectoryExtra(new byte[]{4, 5, 6});
                                                        
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                                    public void testEquals_DifferentGeneralPurposeBits() {
                                                        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                        GeneralPurposeBit gpb1 = mock(GeneralPurposeBit.class);
                                                        when(gpb1.equals(any())).thenReturn(false);
                                                        entry1.setGeneralPurposeBit(gpb1);
                                                        
                                                        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                        GeneralPurposeBit gpb2 = mock(GeneralPurposeBit.class);
                                                        entry2.setGeneralPurposeBit(gpb2);
                                                        
                                                        assertFalse(entry1.equals(entry2));
                                                    }

    @Test
                                            public void testEquals_SameNameNull() {
                                                ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                ZipArchiveEntry entry2 = new ZipArchiveEntry((String)null);
                                                assertTrue(entry1.equals(entry2));
                                            }

    @Test
                                            public void testEquals_DifferentNameNullCases() {
                                                ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                assertFalse(entry1.equals(entry2));
                                            }

    @Test
                                        public void testEquals_FromDifferentConstructors() throws Exception {
                                            ZipArchiveEntry baseEntry = new ZipArchiveEntry("test.txt");
                                            baseEntry.setComment("comment");
                                            baseEntry.setTime(1000L);
                                            
                                            ZipArchiveEntry entry1 = new ZipArchiveEntry(baseEntry);
                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                            entry2.setComment("comment");
                                            entry2.setTime(1000L);
                                            
                                            assertTrue(entry1.equals(entry2));
                                        }

    @Test
                                   public void testEqualsWithNullComment() {
                                       // Create first entry with null comment
                                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                                       // Default comment is null
                                       
                                       // Create second entry with non-null comment
                                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test1");
                                       entry2.setComment("comment");
                                       
                                       // Set all other fields to be equal
                                       long time = System.currentTimeMillis();
                                       entry1.setTime(time);
                                       entry2.setTime(time);
                                       entry1.setMethod(8);
                                       entry2.setMethod(8);
                                       entry1.setSize(100);
                                       entry2.setSize(100);
                                       entry1.setInternalAttributes(1);
                                       entry2.setInternalAttributes(1);
                                       
                                       // Set platform using reflection since setPlatform is protected
                                       try {
                                           Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                           setPlatform.setAccessible(true);
                                           setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                                           setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                       } catch (Exception e) {
                                           fail("Failed to set platform via reflection: " + e.getMessage());
                                       }
                                       
                                       entry1.setExternalAttributes(123);
                                       entry2.setExternalAttributes(123);
                                       
                                       // This should return false (not throw exception) because comments differ
                                       assertFalse(entry1.equals(entry2));
                                       
                                       // Also test reverse comparison
                                       assertFalse(entry2.equals(entry1));
                                       
                                       // Test with both having null comments
                                       ZipArchiveEntry entry3 = new ZipArchiveEntry("test1");
                                       assertTrue(entry1.equals(entry3));
                                       
                                       // Test with both having empty comments
                                       entry1.setComment("");
                                       entry2.setComment("");
                                       assertTrue(entry1.equals(entry2));
                                   }

    @Test
                               public void testEquals_differentInternalAttributes_shouldNotBeEqual() {
                                   // Create two entries with same name (other fields will be default)
                                   ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                   ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                   
                                   // Set different internal attributes
                                   entry1.setInternalAttributes(1);
                                   entry2.setInternalAttributes(2);
                                   
                                   // All other fields are equal by default
                                   // Original method should return false, but mutant will return true
                                   assertFalse("Entries with different internal attributes should not be equal", 
                                              entry1.equals(entry2));
                                   
                                   // Also test the reverse comparison to ensure symmetry
                                   assertFalse("Entries with different internal attributes should not be equal", 
                                              entry2.equals(entry1));
                               }

    @Test
                             public void testEquals_shouldReturnFalseWhenPlatformsDiffer() throws Exception {
                                 // Create two entries with same name but different platforms
                                 ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                 ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                 
                                 // Set all other attributes to be equal
                                 entry1.setTime(1000L);
                                 entry2.setTime(1000L);
                                 entry1.setSize(100L);
                                 entry2.setSize(100L);
                                 entry1.setMethod(8);
                                 entry2.setMethod(8);
                                 entry1.setInternalAttributes(1);
                                 entry2.setInternalAttributes(1);
                                 entry1.setExternalAttributes(2L);
                                 entry2.setExternalAttributes(2L);
                                 
                                 // Set different platforms using reflection
                                 Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                 setPlatformMethod.setAccessible(true);
                                 setPlatformMethod.invoke(entry1, ZipArchiveEntry.PLATFORM_UNIX);
                                 setPlatformMethod.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                 
                                 // Verify they are not equal due to platform difference
                                 assertFalse("Entries with different platforms should not be equal", 
                                            entry1.equals(entry2));
                                 
                                 // Additional verification that platform is the only difference
                                 // Set platforms to be equal and verify equality
                                 setPlatformMethod.invoke(entry2, ZipArchiveEntry.PLATFORM_UNIX);
                                 assertTrue("Entries with same platforms should be equal", 
                                           entry1.equals(entry2));
                             }

    @Test
                        public void testEquals_shouldReturnFalseWhenExternalAttributesDiffer() throws Exception {
                            // Create two entries with same name (required for equality comparison)
                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                            
                            // Set all other fields to be equal
                            entry1.setTime(123456789L);
                            entry2.setTime(123456789L);
                            entry1.setInternalAttributes(1);
                            entry2.setInternalAttributes(1);
                            
                            // Use reflection to set protected platform field
                            Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                            setPlatform.setAccessible(true);
                            setPlatform.invoke(entry1, ZipArchiveEntry.PLATFORM_FAT);
                            setPlatform.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                            
                            entry1.setMethod(8);
                            entry2.setMethod(8);
                            entry1.setSize(100L);
                            entry2.setSize(100L);
                            entry1.setCrc(12345L);
                            entry2.setCrc(12345L);
                            entry1.setCompressedSize(80L);
                            entry2.setCompressedSize(80L);
                            entry1.setExtra(new byte[0]);
                            entry2.setExtra(new byte[0]);
                            
                            // Set different external attributes
                            entry1.setExternalAttributes(1L);
                            entry2.setExternalAttributes(2L);
                            
                            // The original implementation should return false
                            assertFalse("Entries with different external attributes should not be equal", 
                                       entry1.equals(entry2));
                            
                            // Also test symmetry
                            assertFalse("Entries with different external attributes should not be equal", 
                                       entry2.equals(entry1));
                        }

    @Test
                   public void testEqualsWithNullNameVsNonNullName() {
                       // Create first entry with null name
                       ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                       // Use reflection to set name to null since setName() might prevent null
                       try {
                           Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                           nameField.setAccessible(true);
                           nameField.set(entry1, null);
                       } catch (Exception e) {
                           fail("Failed to set name field via reflection");
                       }
                       
                       // Create second entry with non-null name
                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                       
                       // Set all other fields to be equal
                       entry1.setTime(1000L);
                       entry2.setTime(1000L);
                       entry1.setComment("");
                       entry2.setComment("");
                       entry1.setInternalAttributes(0);
                       entry2.setInternalAttributes(0);
                       
                       // Use reflection to set platform field
                       try {
                           Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                           platformField.setAccessible(true);
                           platformField.set(entry1, ZipArchiveEntry.PLATFORM_FAT);
                           platformField.set(entry2, ZipArchiveEntry.PLATFORM_FAT);
                       } catch (Exception e) {
                           fail("Failed to set platform field via reflection");
                       }
                       
                       entry1.setExternalAttributes(0L);
                       entry2.setExternalAttributes(0L);
                       entry1.setMethod(0);
                       entry2.setMethod(0);
                       entry1.setSize(0L);
                       entry2.setSize(0L);
                       entry1.setCrc(0L);
                       entry2.setCrc(0L);
                       entry1.setCompressedSize(0L);
                       entry2.setCompressedSize(0L);
                       entry1.setExtra(new byte[0]);
                       entry2.setExtra(new byte[0]);
                       
                       // Test equality in both directions
                       assertFalse("Entries with null vs non-null name should not be equal", 
                                  entry1.equals(entry2));
                       assertFalse("Entries with null vs non-null name should not be equal (reverse)", 
                                  entry2.equals(entry1));
                   }

    @Test
              public void testEqualsWithNullNameVsNonNullName1() throws Exception {
                  // Create first entry with null name using reflection
                  ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                  setNameMethod.setAccessible(true);
                  setNameMethod.invoke(entry1, (String)null);
                  
                  // Create second entry with non-null name
                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                  
                  // Verify they are not equal (original behavior)
                  assertFalse(entry1.equals(entry2));
                  
                  // Additional verification to ensure the comparison was done properly
                  // Create another entry with null name using reflection
                  ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                  setNameMethod.invoke(entry3, (String)null);
                  
                  // Entries with both null names should be equal
                  assertTrue(entry1.equals(entry3));
                  
                  // Verify symmetry of equals
                  assertFalse(entry2.equals(entry1));
              }

    @Test
         public void testEquals_WhenFirstNameIsNullAndSecondIsNotNull_ShouldReturnFalse() {
             // Create first entry with non-null name (we'll set it to null via reflection)
             ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
             // Use reflection to set name to null since setName() might handle null differently
             try {
                 Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                 nameField.setAccessible(true);
                 nameField.set(entry1, null);
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
             
             // Create second entry with non-null name
             ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
             
             // Assert that they should not be equal
             assertFalse("Entries should not be equal when one name is null and other isn't", 
                        entry1.equals(entry2));
             
             // Also test the reverse case
             assertFalse("Entries should not be equal when one name is null and other isn't", 
                        entry2.equals(entry1));
         }

    @Test
    public void testEqualsWithNullNameVsNonNullName2() throws Exception {
        // Create first entry with null name using reflection
        Constructor<ZipArchiveEntry> ctor = ZipArchiveEntry.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        ZipArchiveEntry entry1 = ctor.newInstance();
        Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
        setName.setAccessible(true);
        setName.invoke(entry1, (String)null);
        
        // Create second entry with non-null name using public constructor
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
        
        // Set all other fields to be equal
        long currentTime = System.currentTimeMillis();
        entry1.setTime(currentTime);
        entry2.setTime(currentTime);
        entry1.setMethod(0);
        entry2.setMethod(0);
        entry1.setSize(100);
        entry2.setSize(100);
        entry1.setInternalAttributes(0);
        entry2.setInternalAttributes(0);
        entry1.setUnixMode(0); // Alternative way to set platform
        entry2.setUnixMode(0);
        entry1.setExternalAttributes(0);
        entry2.setExternalAttributes(0);
        entry1.setComment(null);
        entry2.setComment(null);
        
        // Original should return false (not equal) because one name is null and other isn't
        // Mutant would return true
        assertFalse("Entries with null name and non-null name should not be equal", 
                   entry1.equals(entry2));
    }


}
