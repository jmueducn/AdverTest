package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testParseOctal_ValidInput() {
                                                                                            byte[] buffer = {' ', '1', '2', '3', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                                            assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                                                        }

    @Test
                                                                                        public void testParseOctal_LeadingSpaces() {
                                                                                            byte[] buffer = {' ', ' ', '7', '5', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                                            assertEquals(61L, result); // 7*8 + 5 = 61
                                                                                        }

    @Test
                                                                                        public void testParseOctal_TrailingSpace() {
                                                                                            byte[] buffer = {'1', '0', '0', ' '};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                            assertEquals(64L, result); // 1*64 = 64
                                                                                        }

    @Test
                                                                                        public void testParseOctal_TrailingNUL() {
                                                                                            byte[] buffer = {'1', '2', '3', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                            assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                                                        }

    @Test
                                                                                        public void testParseOctal_DoubleTrailingDelimiters() {
                                                                                            byte[] buffer = {'7', '7', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                            assertEquals(63L, result); // 7*8 + 7 = 63
                                                                                        }

    @Test
                                                                                        public void testParseOctal_AllNULBytes() {
                                                                                            byte[] buffer = {0, 0, 0, 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                            assertEquals(0L, result);
                                                                                        }

    @Test
                                                                                        public void testParseOctal_OffsetParameter() {
                                                                                            byte[] buffer = {'x', 'x', '1', '2', '3', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 2, 5);
                                                                                            assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                                                        }

    @Test
                                                                                        public void testParseOctal_MaximumValidOctal() {
                                                                                            byte[] buffer = {'1', '7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 11);
                                                                                            assertEquals(Long.parseLong("17777777777", 8), result);
                                                                                        }

    @Test
                                                                                        public void testParseOctal_SingleDigit() {
                                                                                            byte[] buffer = {'5', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 3);
                                                                                            assertEquals(5L, result);
                                                                                        }

    @Test
                                                                                        public void testParseOctal_EmptyButValid() {
                                                                                            byte[] buffer = {' ', ' ', 0};
                                                                                            long result = TarUtils.parseOctal(buffer, 0, 3);
                                                                                            assertEquals(0L, result);
                                                                                        }

    @Test
                                                                                public void testParseOctal_InvalidLength() {
                                                                                    try {
                                                                                        byte[] buffer = {'1'};
                                                                                        TarUtils.parseOctal(buffer, 0, 1);
                                                                                        fail("Expected IllegalArgumentException to be thrown");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        assertEquals("Length 1 must be at least 2", e.getMessage());
                                                                                    }
                                                                                }

                                                                                public void testParseOctal_InvalidTrailingCharacter() {
                                                                                    byte[] buffer = {'1', '2', '3', 'x'};
                                                                                    TarUtils.parseOctal(buffer, 0, 4);
                                                                                }

                                                                                public void testParseOctal_InvalidOctalDigit() {
                                                                                    byte[] buffer = {'1', '8', ' ', 0}; // '8' is invalid in octal
                                                                                    TarUtils.parseOctal(buffer, 0, 4);
                                                                                }


}
