package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                            public void testParseOctal_ValidInput() {
                                                                                byte[] buffer = {' ', ' ', '1', '2', '3', ' ', ' '};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 7);
                                                                                assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                                            }

 @Test
                                                                            public void testParseOctal_LeadingZeroReturnsZero() {
                                                                                byte[] buffer = {'0', '1', '2', '3'};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                assertEquals(0L, result);
                                                                            }

 @Test
                                                                            public void testParseOctal_AllSpacesReturnsZero() {
                                                                                byte[] buffer = {' ', ' ', ' ', ' '};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                assertEquals(0L, result);
                                                                            }

 @Test
                                                                            public void testParseOctal_LeadingAndTrailingSpaces() {
                                                                                byte[] buffer = {' ', ' ', '7', '5', ' ', ' '};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                                assertEquals(61L, result); // 7*8 + 5 = 61
                                                                            }

 @Test
                                                                            public void testParseOctal_TrailingNullsAndSpaces() {
                                                                                byte[] buffer = {'1', '2', '3', 0, ' ', 0};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 6);
                                                                                assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                                            }

 @Test
                                                                            public void testParseOctal_MaxValidOctalDigits() {
                                                                                byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 12);
                                                                                assertEquals(9223372036854775807L, result); // Maximum long value in octal
                                                                            }

 @Test
                                                                            public void testParseOctal_WithOffset() {
                                                                                byte[] buffer = {'x', 'x', '1', '2', '3', 'x', 'x'};
                                                                                long result = TarUtils.parseOctal(buffer, 2, 3);
                                                                                assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                                            }

 @Test
                                                                            public void testParseOctal_SingleValidDigit() {
                                                                                byte[] buffer = {' ', '1', ' '};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 3);
                                                                                assertEquals(1L, result);
                                                                            }

 @Test
                                                                            public void testParseOctal_AllZerosAfterLeadingSpace() {
                                                                                byte[] buffer = {' ', '0', '0', '0'};
                                                                                long result = TarUtils.parseOctal(buffer, 0, 4);
                                                                                assertEquals(0L, result);
                                                                            }

 @Test
                                                                    public void testParseOctal_InvalidLengthThrowsException() {
                                                                        org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                                        exceptionRule.expect(IllegalArgumentException.class);
                                                                        exceptionRule.expectMessage("Length 1 must be at least 2");
                                                                        byte[] buffer = {'1'};
                                                                        TarUtils.parseOctal(buffer, 0, 1);
                                                                    }

 @Test
                                                                    public void testParseOctal_InvalidDigitThrowsException() {
                                                                        byte[] buffer = {'1', '2', '8', '4'}; // '8' is invalid in octal
                                                                        try {
                                                                            TarUtils.parseOctal(buffer, 0, 4);
                                                                            fail("Expected IllegalArgumentException to be thrown");
                                                                        } catch (IllegalArgumentException e) {
                                                                            assertEquals("Invalid byte 56 at offset 2", e.getMessage());
                                                                        }
                                                                    }

 @Test
                                                                    public void testParseOctal_NonNumericCharacterThrowsException() {
                                                                        byte[] buffer = {'1', '2', 'a', '4'}; // 'a' is invalid
                                                                        try {
                                                                            TarUtils.parseOctal(buffer, 0, 4);
                                                                            fail("Expected IllegalArgumentException to be thrown");
                                                                        } catch (IllegalArgumentException e) {
                                                                            assertEquals("Invalid byte 97 at offset 2", e.getMessage());
                                                                        }
                                                                    }

 @Test
                            public void testParseOctal_InvalidDigits() {
                                // Test with byte below '0' (ASCII 47 is '/')
                                byte[] buffer1 = {' ', '/', '1', '2', ' '};
                                try {
                                    TarUtils.parseOctal(buffer1, 0, buffer1.length);
                                    fail("Should throw IllegalArgumentException for byte below '0'");
                                } catch (IllegalArgumentException e) {
                                    // Expected
                                }
                            
                                // Test with byte above '7' (ASCII 56 is '8')
                                byte[] buffer2 = {' ', '1', '2', '8', ' '};
                                try {
                                    TarUtils.parseOctal(buffer2, 0, buffer2.length);
                                    fail("Should throw IllegalArgumentException for byte above '7'");
                                } catch (IllegalArgumentException e) {
                                    // Expected
                                }
                            
                                // Test with valid bytes between '0'-'7'
                                byte[] buffer3 = {' ', '1', '2', '3', ' '};
                                long result = TarUtils.parseOctal(buffer3, 0, buffer3.length);
                                assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                            }

 @Test(expected = IllegalArgumentException.class)
                           public void testParseOctalDetectsMutantWithByteBelowZero() {
                               // Create buffer with byte value '/' (ASCII 47) which is just below '0'
                               byte[] buffer = new byte[] {' ', '/', '1', ' '}; // space, '/', '1', space
                               
                               // This should throw IllegalArgumentException in original code
                               // Mutated version would incorrectly process this input
                               TarUtils.parseOctal(buffer, 0, buffer.length);
                               
                               // If we reach here, the test fails (mutant survived)
                               // The expected exception annotation will catch if exception is thrown
                           }

 @Test
                              public void testParseOctalWithDigit() {
                                  // This test will catch the mutant by verifying behavior with digit '7'
                                  byte[] buffer = {' ', '7', ' ', ' '}; // Valid octal "7" with spaces
                                  
                                  // Original behavior should throw exception for '7' (since > '7' is false)
                                  // Mutated behavior would parse '7' successfully
                                  try {
                                      long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                                      // If we get here, the mutant survived
                                      fail("Expected IllegalArgumentException for digit '7'");
                                  } catch (IllegalArgumentException e) {
                                      // Expected behavior for original code
                                      assertTrue(e.getMessage().contains("not an octal digit"));
                                  }
                              }

 @Test
                              public void testParseOctalBoundaryDigits() {
                                  // Test boundary cases to ensure full coverage
                                  byte[] validBuffer = {'0', '1', '6'}; // Should always pass
                                  byte[] invalidHighBuffer = {'0', '8'}; // Should always fail
                                  byte[] invalidLowBuffer = {'/', '0'}; // ASCII '/' is before '0'
                          
                                  // Test valid range (0-6)
                                  assertEquals(6L, TarUtils.parseOctal(validBuffer, 0, validBuffer.length));
                                  
                                  // Test invalid high digit (8)
                                  try {
                                      TarUtils.parseOctal(invalidHighBuffer, 0, invalidHighBuffer.length);
                                      fail("Expected IllegalArgumentException for digit '8'");
                                  } catch (IllegalArgumentException e) {
                                      assertTrue(e.getMessage().contains("not an octal digit"));
                                  }
                                  
                                  // Test invalid low digit ('/')
                                  try {
                                      TarUtils.parseOctal(invalidLowBuffer, 0, invalidLowBuffer.length);
                                      fail("Expected IllegalArgumentException for digit '/'");
                                  } catch (IllegalArgumentException e) {
                                      assertTrue(e.getMessage().contains("not an octal digit"));
                                  }
                              }

 @Test
                         public void testParseOctalWithZeroDigitShouldNotThrowException() {
                             // Arrange
                             byte[] buffer = {' ', '0', '1', '2', ' '}; // Contains '0' surrounded by valid digits
                             int offset = 0;
                             int length = buffer.length;
                             
                             // Act
                             long result = TarUtils.parseOctal(buffer, offset, length);
                             
                             // Assert
                             // Original code: (0 << 3) + (1 << 3) + 2 = 0 + 8 + 2 = 10 in octal (8 in decimal)
                             assertEquals(8L, result);
                             
                             // The mutant would throw IllegalArgumentException for the '0' byte
                             // So if we reach this assertion, the mutant is caught
                         }

 @Test
                        public void testParseOctalWithDigitSeven() {
                            // Setup test data with digit '7' which should be valid
                            byte[] buffer = {' ', '7', '1', ' ', ' '}; // represents octal number 71
                            int offset = 0;
                            int length = buffer.length;
                            
                            // Expected behavior - should parse successfully
                            long expected = 7 * 8 + 1; // 71 in octal is 57 in decimal
                            
                            try {
                                long result = TarUtils.parseOctal(buffer, offset, length);
                                assertEquals("Should correctly parse octal number containing '7'", 
                                            expected, result);
                            } catch (IllegalArgumentException e) {
                                fail("Valid octal digit '7' should not throw exception");
                            }
                            
                            // Additional test with just '7' to be thorough
                            byte[] singleSeven = {'7', '0'}; // must have length >= 2
                            expected = 7;
                            try {
                                long result = TarUtils.parseOctal(singleSeven, 0, singleSeven.length);
                                assertEquals("Should correctly parse single digit '7'", 
                                            expected, result);
                            } catch (IllegalArgumentException e) {
                                fail("Valid octal digit '7' should not throw exception");
                            }
                        }

 @Test(expected = IllegalArgumentException.class)
                       public void testParseOctal_DetectsInvalidDigitBelowZero() {
                           // Arrange
                           byte[] buffer = new byte[] {' ', ' ', '/', '1', ' ', ' '}; // '/' is ASCII 47 (< '0')
                           int offset = 0;
                           int length = 6;
                           
                           // Act
                           TarUtils.parseOctal(buffer, offset, length);
                           
                           // Assert - expecting exception to be thrown
                           // If no exception is thrown, the test will fail
                           // This will catch the mutant since the mutant won't throw for digits < '0'
                       }

 @Test(expected = IllegalArgumentException.class)
                      public void testParseOctal_ShouldThrowExceptionForDigitsAbove() {
                          // Arrange
                          byte[] buffer = {' ', '1', '2', '8', ' '}; // Contains invalid octal digit '8'
                          int offset = 0;
                          int length = buffer.length;
                          
                          // Act
                          TarUtils.parseOctal(buffer, offset, length);
                          
                          // Assert - Expecting IllegalArgumentException for invalid digit '8'
                          // If mutant is present, this test will fail as it won't throw exception
                      }

 @Test
                         public void testParseOctalShouldRejectDigit() throws Exception {
                             byte[] buffer = {' ', '1', '2', '8', ' '}; // Contains '8' which is invalid for octal
                             int offset = 0;
                             int length = buffer.length;
                             
                             thrown.expect(IllegalArgumentException.class);
                             TarUtils.parseOctal(buffer, offset, length);
                         }

 @Test
                         public void testParseOctalShouldRejectDigit1() throws Exception {
                             byte[] buffer = {'0', '7', '9', '4'}; // Contains '9' which is invalid for octal
                             int offset = 0;
                             int length = buffer.length;
                             
                             thrown.expect(IllegalArgumentException.class);
                             TarUtils.parseOctal(buffer, offset, length);
                         }

 @Test
                         public void testParseOctalShouldAcceptValidDigits() throws Exception {
                             byte[] buffer = {' ', '1', '2', '7', ' '}; // All digits valid (0-7)
                             int offset = 0;
                             int length = buffer.length;
                             
                             long expected = 0127L; // Octal literal for decimal 87
                             long actual = TarUtils.parseOctal(buffer, offset, length);
                             assertEquals(expected, actual);
                         }

 @Test(expected = IllegalArgumentException.class)
                    public void testParseOctal_InvalidCharacterBelowZero() {
                        // Create a buffer with an invalid character below '0' (ASCII 47 is '/')
                        byte[] buffer = {' ', ' ', '/', '1', '2', ' ', ' '};
                        int offset = 0;
                        int length = buffer.length;
                        
                        // This should throw IllegalArgumentException in original code
                        // But would pass in mutated code (which we want to catch)
                        TarUtils.parseOctal(buffer, offset, length);
                    }

 @Test
                    public void testParseOctal_ValidCharacters() {
                        // Test with valid octal characters to ensure normal cases still work
                        byte[] buffer = {' ', '1', '2', '3', '4', ' ', ' '};
                        int offset = 0;
                        int length = buffer.length;
                        
                        long expected = 01234L; // Octal literal
                        long actual = TarUtils.parseOctal(buffer, offset, length);
                        
                        assertEquals("Valid octal string should parse correctly", 
                                    expected, actual);
                    }

 @Test(expected = IllegalArgumentException.class)
                    public void testParseOctal_InvalidCharacterAboveSeven() {
                        // Test with character above '7' (ASCII 56)
                        byte[] buffer = {' ', '1', '2', '8', '4', ' ', ' '};
                        int offset = 0;
                        int length = buffer.length;
                        
                        // Should throw in both original and mutated code
                        TarUtils.parseOctal(buffer, offset, length);
                    }

 @Test(expected = IllegalArgumentException.class)
                   public void testParseOctal_InvalidDigits_ShouldThrowException() {
                       // Arrange
                       byte[] buffer = {
                           ' ', ' ', '1', '2', '8', '4', ' ', ' '  // '8' is invalid in octal
                       };
                       int offset = 0;
                       int length = buffer.length;
                       
                       // Act - should throw IllegalArgumentException for '8'
                       TarUtils.parseOctal(buffer, offset, length);
                       
                       // Assert - handled by @Test(expected)
                   }

 @Test
                  public void testParseOctalWithInvalidDigits() {
                      // Test with digit below '0'
                      byte[] buffer1 = {' ', ' ', '/', ' '}; // '/' is ASCII 47, one below '0'
                      try {
                          TarUtils.parseOctal(buffer1, 0, buffer1.length);
                          fail("Should have thrown IllegalArgumentException for digit below '0'");
                      } catch (IllegalArgumentException e) {
                          assertTrue(e.getMessage().contains("Invalid octal digit"));
                      }
                  
                      // Test with digit above '7'
                      byte[] buffer2 = {' ', '8', ' ', ' '}; // '8' is ASCII 56, one above '7'
                      try {
                          TarUtils.parseOctal(buffer2, 0, buffer2.length);
                          fail("Should have thrown IllegalArgumentException for digit above '7'");
                      } catch (IllegalArgumentException e) {
                          assertTrue(e.getMessage().contains("Invalid octal digit"));
                      }
                  
                      // Test with valid digits to ensure they pass
                      byte[] validBuffer1 = {' ', '0', '1', '7', ' '}; // Boundary valid values
                      assertEquals(017L, TarUtils.parseOctal(validBuffer1, 0, validBuffer1.length));
                  
                      byte[] validBuffer2 = {'1', '2', '3', '4', '5', '6'}; // Middle valid values
                      assertEquals(0123456L, TarUtils.parseOctal(validBuffer2, 0, validBuffer2.length));
                  }

 @Test
                 public void testParseOctalInvalidDigits() {
                     byte[] buffer1 = {' ', ' ', '/', ' '};  // '/' is less than '0'
                     byte[] buffer2 = {' ', ' ', '8', ' '};  // '8' is greater than '7'
                     
                     // Test with digit less than '0'
                     try {
                         TarUtils.parseOctal(buffer1, 0, buffer1.length);
                         fail("Expected IllegalArgumentException for digit less than '0'");
                     } catch (IllegalArgumentException e) {
                         // Expected
                     }
                     
                     // Test with digit greater than '7'
                     try {
                         TarUtils.parseOctal(buffer2, 0, buffer2.length);
                         fail("Expected IllegalArgumentException for digit greater than '7'");
                     } catch (IllegalArgumentException e) {
                         // Expected
                     }
                     
                     // Test valid case to ensure it still works
                     byte[] validBuffer = {' ', '1', '2', ' '};
                     long result = TarUtils.parseOctal(validBuffer, 0, validBuffer.length);
                     assertEquals(12L, result);
                 }

 @Test
                public void testParseOctalWithZeroDigitShouldThrowException() {
                    // Arrange
                    byte[] buffer = new byte[] {' ', '0', '1', ' '}; // Contains '0' after first byte
                    int offset = 0;
                    int length = buffer.length;
                    
                    // Act & Assert
                    try {
                        TarUtils.parseOctal(buffer, offset, length);
                        fail("Expected IllegalArgumentException to be thrown");
                    } catch (IllegalArgumentException e) {
                        // Expected behavior for original code
                        assertTrue(e.getMessage().contains("not an octal digit"));
                    }
                    
                    // Additional test case with just '0' in middle position
                    byte[] buffer2 = new byte[] {'1', '0', '2'};
                    try {
                        TarUtils.parseOctal(buffer2, 0, buffer2.length);
                        fail("Expected IllegalArgumentException to be thrown");
                    } catch (IllegalArgumentException e) {
                        assertTrue(e.getMessage().contains("not an octal digit"));
                    }
                    
                    // Edge case - first byte is '0' (should return 0, not throw exception)
                    byte[] buffer3 = new byte[] {'0', '0', '1'};
                    assertEquals(0L, TarUtils.parseOctal(buffer3, 0, buffer3.length));
                }

 @Test
               public void testParseOctalWithDigit7ShouldNotThrowException() {
                   // Arrange
                   byte[] buffer = {' ', '7', ' ', ' '}; // Valid octal with digit '7' and spaces
                   int offset = 0;
                   int length = 4;
                   
                   // Act & Assert
                   try {
                       long result = TarUtils.parseOctal(buffer, offset, length);
                       // If we get here, the test passes (original behavior)
                       // Verify the parsing is correct
                       assertEquals(7L, result);
                   } catch (IllegalArgumentException e) {
                       // If we get here, the mutant survived (wrong behavior)
                       fail("Method threw IllegalArgumentException for valid octal digit '7'");
                   }
               }

 @Test
               public void testParseOctalWithDigit7ShouldReturnCorrectValue() {
                   // Arrange
                   byte[] buffer = {'7'}; // Single digit '7' (length will be adjusted)
                   int offset = 0;
                   int length = 2; // Minimum required length is 2
                   
                   // Need to pad buffer to meet length requirement
                   byte[] paddedBuffer = new byte[length];
                   System.arraycopy(buffer, 0, paddedBuffer, 0, buffer.length);
                   for (int i = buffer.length; i < length; i++) {
                       paddedBuffer[i] = ' '; // pad with spaces
                   }
                   
                   // Act
                   long result = TarUtils.parseOctal(paddedBuffer, offset, length);
                   
                   // Assert
                   assertEquals(7L, result);
               }

 @Test(expected = IllegalArgumentException.class)
              public void testParseOctal_DetectsMutant_InvalidDigitBelowZero() {
                  // Arrange
                  byte[] buffer = new byte[] {' ', '4', '7', '/', ' '}; // Contains '/' (ASCII 47) which is invalid
                  int offset = 0;
                  int length = buffer.length;
                  
                  // Act
                  TarUtils.parseOctal(buffer, offset, length);
                  
                  // Assert - expecting exception due to invalid digit
                  // If mutant is present, this test will fail as it won't throw exception for '/'
              }

 @Test(expected = IllegalArgumentException.class)
             public void testParseOctal_ShouldThrowExceptionForDigit() {
                 // Arrange
                 byte[] buffer = {' ', '7', ' ', ' '}; // Contains digit '7' which should be invalid
                 int offset = 0;
                 int length = 4;
                 
                 // Act
                 TarUtils.parseOctal(buffer, offset, length);
                 
                 // Assert - exception expected
             }

 @Test(expected = IllegalArgumentException.class)
            public void testParseOctal_ShouldThrowExceptionForDigitsAbove1() {
                // Arrange
                byte[] buffer = {' ', '1', '2', '8', ' '}; // Contains '8' which is invalid for octal
                int offset = 0;
                int length = buffer.length;
                
                // Act - should throw IllegalArgumentException
                TarUtils.parseOctal(buffer, offset, length);
                
                // Assert - handled by the expected exception in @Test annotation
            }

 @Test(expected = IllegalArgumentException.class)
               public void testParseOctalWithInvalidDigitShouldThrow() {
                   // This test will detect the mutant because:
                   // Original: should throw when encountering '8' (invalid octal)
                   // Mutant: will process '8' and return wrong result
                   byte[] buffer = {' ', '1', '2', '8', ' '}; // Contains invalid octal digit '8'
                   TarUtils.parseOctal(buffer, 0, buffer.length);
               }

 @Test
               public void testParseOctalWithValidDigits() {
                   // Valid case to ensure normal functionality works
                   byte[] buffer = {' ', '1', '2', '7', ' '}; // All valid octal digits
                   long result = TarUtils.parseOctal(buffer, 0, buffer.length);
                   assertEquals(87L, result); // 1*64 + 2*8 + 7*1 = 87
               }

 @Test(expected = IllegalArgumentException.class)
               public void testParseOctalWithNonDigitCharacter() {
                   // Test with character that's not a digit at all
                   byte[] buffer = {'a', '1', '2', '3'};
                   TarUtils.parseOctal(buffer, 0, buffer.length);
               }

 @Test(expected = IllegalArgumentException.class)
               public void testParseOctalWithDigitAbove() {
                   // Test with digit '9' which is invalid for octal
                   byte[] buffer = {'9', '1', '2', '3'};
                   TarUtils.parseOctal(buffer, 0, buffer.length);
               }

 @Test
          public void testParseOctalInvalidDigitsThrowsException() {
              byte[] buffer1 = {' ', ' ', '/', ' '};  // '/' is ASCII 47, below '0' (48)
              byte[] buffer2 = {' ', ' ', '8', ' '};  // '8' is ASCII 56, above '7' (55)
              byte[] buffer3 = {' ', ' ', '9', ' '};  // '9' is ASCII 57, above '7' (55)
              
              // Test with digit below '0'
              try {
                  TarUtils.parseOctal(buffer1, 0, buffer1.length);
                  fail("Expected IllegalArgumentException for byte below '0'");
              } catch (IllegalArgumentException e) {
                  // Expected
              }
              
              // Test with digit above '7'
              try {
                  TarUtils.parseOctal(buffer2, 0, buffer2.length);
                  fail("Expected IllegalArgumentException for byte above '7'");
              } catch (IllegalArgumentException e) {
                  // Expected
              }
              
              // Test with another digit above '7'
              try {
                  TarUtils.parseOctal(buffer3, 0, buffer3.length);
                  fail("Expected IllegalArgumentException for byte above '7'");
              } catch (IllegalArgumentException e) {
                  // Expected
              }
          }

 @Test(expected = IllegalArgumentException.class)
         public void testParseOctal_InvalidDigitsBelowZero_ThrowsException() {
             // Arrange
             byte[] buffer = {' ', '/', '1', ' '}; // '/' is ASCII 47, below '0' (48)
             int offset = 0;
             int length = 4;
             
             // Act & Assert
             TarUtils.parseOctal(buffer, offset, length);
         }

 @Test(expected = IllegalArgumentException.class)
         public void testParseOctal_InvalidDigitsAboveSeven_ThrowsException() {
             // Arrange
             byte[] buffer = {' ', '8', '1', ' '}; // '8' is above '7'
             int offset = 0;
             int length = 4;
             
             // Act & Assert
             TarUtils.parseOctal(buffer, offset, length);
         }

 @Test
         public void testParseOctal_ValidDigits_NoException() {
             // Arrange
             byte[] buffer = {' ', '3', '7', ' '}; // All valid octal digits
             int offset = 0;
             int length = 4;
             
             // Act
             long result = TarUtils.parseOctal(buffer, offset, length);
             
             // Assert
             assertEquals(31L, result); // 37 in octal is 31 in decimal
         }

 @Test
        public void testParseOctalWithZeroDigits() {
            // Test case where '0' is the first digit
            byte[] buffer1 = {'0', '1', '2', '3'};
            long result1 = TarUtils.parseOctal(buffer1, 0, 4);
            assertEquals(0123L, result1);  // Octal 0123 = decimal 83
        
            // Test case where '0' is in the middle
            byte[] buffer2 = {'1', '0', '2', '3'};
            long result2 = TarUtils.parseOctal(buffer2, 0, 4);
            assertEquals(1023L, result2);  // Octal 1023 = decimal 531
        
            // Test case with multiple zeros
            byte[] buffer3 = {'0', '0', '7', '0'};
            long result3 = TarUtils.parseOctal(buffer3, 0, 4);
            assertEquals(0070L, result3);  // Octal 0070 = decimal 56
        
            // Test case with just "00" (edge case)
            byte[] buffer4 = {'0', '0'};
            long result4 = TarUtils.parseOctal(buffer4, 0, 2);
            assertEquals(0L, result4);
        }

 @Test(expected = IllegalArgumentException.class)
       public void testParseOctalRejectsDigit() {
           // Create a buffer containing invalid octal digit '7'
           byte[] buffer = {' ', '7', ' '}; // spaces to test trimming too
           
           // Call method - should throw IllegalArgumentException
           TarUtils.parseOctal(buffer, 0, buffer.length);
           
           // If we get here, the test fails (mutant survived)
           // Because original should reject '7' but mutant accepts it
       }

 @Test
       public void testParseOctalAcceptsDigit7ButRejects() {
           // Test accepts '7' (valid octal)
           byte[] validBuffer = {'7'};
           long result = TarUtils.parseOctal(validBuffer, 0, validBuffer.length);
           assertEquals(7L, result);
           
           // Test rejects '8' (invalid octal)
           byte[] invalidBuffer = {'8'};
           try {
               TarUtils.parseOctal(invalidBuffer, 0, invalidBuffer.length);
               fail("Should have thrown IllegalArgumentException for '8'");
           } catch (IllegalArgumentException e) {
               // expected
           }
       }

 @Test
      public void testParseOctalWithZeroDigitShouldNotThrowException1() {
          byte[] buffer = {' ', '0', '1', '2', ' '}; // Valid octal "012" with spaces
          long result = TarUtils.parseOctal(buffer, 0, buffer.length);
          assertEquals(10L, result); // 012 in octal is 10 in decimal
      }

 @Test(expected = IllegalArgumentException.class)
      public void testParseOctalWithInvalidLowByteShouldThrowException() {
          byte[] buffer = {' ', '/', '1', '2', ' '}; // '/' is ASCII 47, just below '0'
          TarUtils.parseOctal(buffer, 0, buffer.length);
      }

 @Test
      public void testParseOctalWithZeroFirstDigitShouldReturnZero() {
          byte[] buffer = {'0', '0', '0', '0'}; // All zeros
          long result = TarUtils.parseOctal(buffer, 0, buffer.length);
          assertEquals(0L, result);
      }

 @Test(expected = IllegalArgumentException.class)
      public void testParseOctalWithNonOctalDigitShouldThrowException() {
          byte[] buffer = {' ', '8', '1', '2', ' '}; // '8' is invalid in octal
          TarUtils.parseOctal(buffer, 0, buffer.length);
      }

 @Test
     public void testParseOctalAcceptsDigit() {
         // Create buffer containing valid octal with digit '7'
         byte[] buffer = {' ', '1', '7', '2', ' '}; // represents octal 172 (decimal 122)
         
         // Call the method - should parse successfully
         long result = TarUtils.parseOctal(buffer, 0, buffer.length);
         
         // Verify correct parsing - 1*64 + 7*8 + 2*1 = 122
         assertEquals(122L, result);
         
         // Additional test with just '7' as input
         byte[] buffer2 = {'0', '7', '0'}; // leading 0, then 7, then trailing 0
         long result2 = TarUtils.parseOctal(buffer2, 0, buffer2.length);
         assertEquals(7L, result2);
     }

 @Test
    public void testParseOctalWithDigitAbove7ShouldThrowException() {
        // Setup test data with a digit '8' which is invalid for octal
        byte[] buffer = {' ', '1', '2', '8', ' '};
        int offset = 0;
        int length = buffer.length;
        
        try {
            TarUtils.parseOctal(buffer, offset, length);
            fail("Expected IllegalArgumentException for digit above 7");
        } catch (IllegalArgumentException e) {
            // Expected behavior - test passes
            assertTrue(e.getMessage().contains("Invalid octal digit"));
        }
    }

 @Test
    public void testParseOctalWithDigitAbove7ShouldNotProcess() {
        // Setup test data with a digit '8' which is invalid for octal
        byte[] buffer = {' ', '1', '2', '8', ' '};
        int offset = 0;
        int length = buffer.length;
        
        // This test will fail if the mutant is present, as it will process the '8'
        // The original method would throw an exception before reaching the assertion
        try {
            long result = TarUtils.parseOctal(buffer, offset, length);
            // If we get here with the mutant, the result would be incorrect
            // Original method would never reach this point
            assertNotEquals(83L, result); // 12 in octal is 10 decimal, but mutant would process '8' as digit
        } catch (IllegalArgumentException e) {
            // This is expected for the original method
        }
    }

 @Test(expected = IllegalArgumentException.class)
   public void testParseOctal_InvalidDigits_ShouldThrowException1() {
       // Arrange
       byte[] buffer = {
           ' ', ' ', '1', '2', '8', ' ', ' '  // '8' is invalid for octal
       };
       int offset = 0;
       int length = buffer.length;
       
       // Act - should throw IllegalArgumentException for invalid digit '8'
       TarUtils.parseOctal(buffer, offset, length);
       
       // Assert - handled by @Test(expected)
   }

 @Test
  public void testParseOctalInvalidDigits1() {
      // Test with digits below '0' (ASCII 47 is '/', just before '0')
      byte[] buffer1 = {' ', ' ', '/', ' '};
      try {
          TarUtils.parseOctal(buffer1, 0, 4);
          fail("Should have thrown IllegalArgumentException for digit below '0'");
      } catch (IllegalArgumentException e) {
          // Expected
      }
  
      // Test with digits above '7' (ASCII 56 is '8', just after '7')
      byte[] buffer2 = {' ', ' ', '8', ' '};
      try {
          TarUtils.parseOctal(buffer2, 0, 4);
          fail("Should have thrown IllegalArgumentException for digit above '7'");
      } catch (IllegalArgumentException e) {
          // Expected
      }
  
      // Test with valid digits to ensure they pass
      byte[] validBuffer1 = {' ', '1', '2', ' '};
      assertEquals(10L, TarUtils.parseOctal(validBuffer1, 0, 4)); // 12 in octal is 10 in decimal
  
      // Test boundary digits
      byte[] boundaryBuffer = {'0', '7'};
      assertEquals(7L, TarUtils.parseOctal(boundaryBuffer, 0, 2));
  
      // Test with all valid digits
      byte[] allValidBuffer = {'1', '2', '3', '4', '5', '6', '7'};
      assertEquals(342391L, TarUtils.parseOctal(allValidBuffer, 0, 7));
  }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctalWithInvalidDigitsShouldThrowException() {
     // Arrange
     byte[] buffer = new byte[] {' ', '1', '2', '8', ' '}; // '8' is invalid in octal
     int offset = 0;
     int length = buffer.length;
     
     // Act - should throw IllegalArgumentException for digit '8'
     TarUtils.parseOctal(buffer, offset, length);
     
     // Assert - handled by expected exception in annotation
 }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctalWithDigitBelowZeroShouldThrowException() {
     // Arrange
     byte[] buffer = new byte[] {'/', '1', '2', '3'}; // '/' is ASCII 47, below '0'
     int offset = 0;
     int length = buffer.length;
     
     // Act - should throw IllegalArgumentException for character '/'
     TarUtils.parseOctal(buffer, offset, length);
 }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctalWithNonDigitCharacterShouldThrowException() {
     // Arrange
     byte[] buffer = new byte[] {'1', '2', 'a', '3'}; // 'a' is not a valid octal digit
     int offset = 0;
     int length = buffer.length;
     
     // Act - should throw IllegalArgumentException for character 'a'
     TarUtils.parseOctal(buffer, offset, length);
 }

}
