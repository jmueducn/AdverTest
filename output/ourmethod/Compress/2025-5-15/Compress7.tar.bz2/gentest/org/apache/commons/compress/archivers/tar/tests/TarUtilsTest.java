package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                  public void testParseName_NormalCase() {
                                                      byte[] buffer = { 'f', 'i', 'l', 'e', '.', 't', 'x', 't', 0, 0, 0 };
                                                      String result = TarUtils.parseName(buffer, 0, 11);
                                                      assertEquals("file.txt", result);
                                                  }

 @Test
                                                  public void testParseName_EmptyName() {
                                                      byte[] buffer = { 0, 0, 0 };
                                                      String result = TarUtils.parseName(buffer, 0, 3);
                                                      assertEquals("", result);
                                                  }

 @Test
                                                  public void testParseName_WithSignExtension() {
                                                      byte[] buffer = { (byte) 0xFF, (byte) 0xFE, 0 };
                                                      String result = TarUtils.parseName(buffer, 0, 3);
                                                      // After masking with 0xFF, should become positive chars
                                                      assertEquals("\u00FF\u00FE", result);
                                                  }

 @Test
                                                  public void testParseName_OffsetAndLength() {
                                                      byte[] buffer = { 'a', 'b', 'c', 'd', 'e', 'f', 0 };
                                                      String result = TarUtils.parseName(buffer, 2, 3);
                                                      assertEquals("cde", result);
                                                  }

 @Test
                                                  public void testParseName_NullTerminatedBeforeEnd() {
                                                      byte[] buffer = { 'a', 'b', 0, 'c', 'd', 0 };
                                                      String result = TarUtils.parseName(buffer, 0, 6);
                                                      assertEquals("ab", result);
                                                  }

 @Test
                                                  public void testParseName_NoNullTerminator() {
                                                      byte[] buffer = { 'a', 'b', 'c', 'd', 'e', 'f' };
                                                      String result = TarUtils.parseName(buffer, 0, 6);
                                                      assertEquals("abcdef", result);
                                                  }

 @Test
                                                  public void testParseName_ZeroLength() {
                                                      byte[] buffer = { 'a', 'b', 'c' };
                                                      String result = TarUtils.parseName(buffer, 0, 0);
                                                      assertEquals("", result);
                                                  }

 @Test
                                          public void testParseName_NegativeOffset() {
                                              byte[] buffer = { 'a', 'b', 'c' };
                                              try {
                                                  TarUtils.parseName(buffer, -1, 3);
                                                  fail("Expected ArrayIndexOutOfBoundsException to be thrown");
                                              } catch (ArrayIndexOutOfBoundsException e) {
                                                  // Expected exception
                                              }
                                          }

 @Test
  public void testParseNameWithFullRangeLoop() {
      // Setup test data that will exercise the full loop range
      byte[] buffer = new byte[] {65, 66, 67, 68, 69, 0, 0, 0}; // ABCDE followed by nulls
      int offset = 0;
      int length = 8;
      
      // Call the method
      String result = TarUtils.parseName(buffer, offset, length);
      
      // Verify the result
      assertEquals("ABCDE", result);
      
      // Additional verification to ensure full loop behavior
      // The mutation shouldn't affect output in this case, but we can add more thorough checks
      byte[] buffer2 = new byte[] {65, 66, 67, 68, 69, 70, 71, 72}; // No null bytes
      String result2 = TarUtils.parseName(buffer2, offset, length);
      assertEquals("ABCDEFGH", result2);
      
      // Edge case with exactly one character
      byte[] buffer3 = new byte[] {65};
      String result3 = TarUtils.parseName(buffer3, 0, 1);
      assertEquals("A", result3);
      
      // Case with null byte at start
      byte[] buffer4 = new byte[] {0, 66, 67, 68};
      String result4 = TarUtils.parseName(buffer4, 0, 4);
      assertEquals("", result4);
  }

 @Test
 public void testParseNameWithNullByteInMiddle() {
     // Create a buffer with content: 'a', 'b', 0, 'c', 'd'
     byte[] buffer = new byte[] {97, 98, 0, 99, 100};
     int offset = 0;
     int length = 5;
     
     // Expected behavior: should stop at null byte and return "ab"
     // Mutant behavior: would return "ab" immediately (same in this case)
     // Need to test with null byte not at end
     
     // Test with null byte in middle and data after
     String result = TarUtils.parseName(buffer, offset, length);
     
     // Original would process until length (but break on null), so should be "ab"
     assertEquals("ab", result);
     
     // To really catch the mutant, we need to verify it didn't process beyond null
     // Check length is correct (2 chars before null)
     assertEquals(2, result.length());
     
     // Check content is exactly what we expect
     assertEquals('a', result.charAt(0));
     assertEquals('b', result.charAt(1));
     
     // Additional test case where null is not at end but we have more data
     byte[] buffer2 = new byte[] {97, 0, 98, 99, 100};
     String result2 = TarUtils.parseName(buffer2, offset, length);
     
     // Should be just "a" since null is at position 1
     assertEquals("a", result2);
     assertEquals(1, result2.length());
 }

}
