package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                           public void testGetEntryEncoding_DefaultConstructor() {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               assertNull("Default constructor should initialize entryEncoding to null", 
                                                                                                                                                                                                                                                         factory.getEntryEncoding());
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testGetEntryEncoding_ConstructorWithEncoding() {
                                                                                                                                                                                                                                               String encoding = "UTF-8";
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                               assertEquals("Constructor should set entryEncoding", 
                                                                                                                                                                                                                                                           encoding, factory.getEntryEncoding());
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testGetEntryEncoding_AfterSetter() {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               String newEncoding = "ISO-8859-1";
                                                                                                                                                                                                                                               factory.setEntryEncoding(newEncoding);
                                                                                                                                                                                                                                               assertEquals("Setter should update entryEncoding", 
                                                                                                                                                                                                                                                           newEncoding, factory.getEntryEncoding());
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testGetEntryEncoding_EmptyString() {
                                                                                                                                                                                                                                               String encoding = "";
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory(encoding);
                                                                                                                                                                                                                                               assertEquals("Empty string should be valid encoding", 
                                                                                                                                                                                                                                                           encoding, factory.getEntryEncoding());
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testGetEntryEncoding_NullEncoding() {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory(null);
                                                                                                                                                                                                                                               assertNull("Null encoding should be allowed", factory.getEntryEncoding());
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testGetEntryEncoding_ThreadSafety() throws InterruptedException {
                                                                                                                                                                                                                                               final ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                               final String[] results = new String[2];
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Thread 1
                                                                                                                                                                                                                                               Thread t1 = new Thread(() -> {
                                                                                                                                                                                                                                                   results[0] = factory.getEntryEncoding();
                                                                                                                                                                                                                                               });
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Thread 2
                                                                                                                                                                                                                                               Thread t2 = new Thread(() -> {
                                                                                                                                                                                                                                                   factory.setEntryEncoding("ISO-8859-1");
                                                                                                                                                                                                                                                   results[1] = factory.getEntryEncoding();
                                                                                                                                                                                                                                               });
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               t1.start();
                                                                                                                                                                                                                                               t2.start();
                                                                                                                                                                                                                                               t1.join();
                                                                                                                                                                                                                                               t2.join();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Due to volatile, we should see either:
                                                                                                                                                                                                                                               // 1. Both threads see UTF-8 (if t1 runs first)
                                                                                                                                                                                                                                               // 2. t1 sees UTF-8 and t2 sees ISO-8859-1 (if t1 runs before t2's set)
                                                                                                                                                                                                                                               // 3. Both see ISO-8859-1 (if t2 runs completely first)
                                                                                                                                                                                                                                               assertTrue("Thread 1 should see either original or updated value",
                                                                                                                                                                                                                                                        "UTF-8".equals(results[0]) || "ISO-8859-1".equals(results[0]));
                                                                                                                                                                                                                                               assertEquals("Thread 2 should see updated value", 
                                                                                                                                                                                                                                                           "ISO-8859-1", results[1]);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_ArFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, inputStream);
                                                                                                                                                                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_ArjFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test without encoding
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with encoding
                                                                                                                                                                                                                                               factory.setEntryEncoding("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_ZipFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test without encoding
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with encoding
                                                                                                                                                                                                                                               factory.setEntryEncoding("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_TarFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test without encoding
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with encoding
                                                                                                                                                                                                                                               factory.setEntryEncoding("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_JarFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test without encoding
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with encoding
                                                                                                                                                                                                                                               factory.setEntryEncoding("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_CpioFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test without encoding
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with encoding
                                                                                                                                                                                                                                               factory.setEntryEncoding("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_DumpFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test without encoding
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with encoding
                                                                                                                                                                                                                                               factory.setEntryEncoding("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_CaseInsensitiveFormat() throws Exception {
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with lowercase
                                                                                                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream("ar", inputStream);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with mixed case
                                                                                                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream("ZiP", inputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_AR() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.AR, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof ArArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_ZIP_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_ZIP_WithEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.ZIP, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                               assertEquals("UTF-8", ((ZipArchiveOutputStream)result).getEncoding());
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_TAR_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof TarArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_TAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.TAR, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof TarArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_JAR_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof JarArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_JAR_WithEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof JarArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_CPIO_WithoutEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.CPIO, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof CpioArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_CPIO_WithEncoding() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveOutputStream result = factory.createArchiveOutputStream(ArchiveStreamFactory.CPIO, out);
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof CpioArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveOutputStream_CaseInsensitive() throws Exception {
                                                                                                                                                                                                                                               OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with different case variations
                                                                                                                                                                                                                                               ArchiveOutputStream result1 = factory.createArchiveOutputStream("zip", out);
                                                                                                                                                                                                                                               ArchiveOutputStream result2 = factory.createArchiveOutputStream("Zip", out);
                                                                                                                                                                                                                                               ArchiveOutputStream result3 = factory.createArchiveOutputStream("ZIP", out);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result1);
                                                                                                                                                                                                                                               assertNotNull(result2);
                                                                                                                                                                                                                                               assertNotNull(result3);
                                                                                                                                                                                                                                               assertTrue(result1 instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                               assertTrue(result2 instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                               assertTrue(result3 instanceof ZipArchiveOutputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_ZipFormat1() throws Exception {
                                                                                                                                                                                                                                               // ZIP signature: 50 4B 03 04
                                                                                                                                                                                                                                               byte[] zipSignature = {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_JarFormat1() throws Exception {
                                                                                                                                                                                                                                               // JAR signature is same as ZIP
                                                                                                                                                                                                                                               byte[] jarSignature = {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(jarSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_ArFormat1() throws Exception {
                                                                                                                                                                                                                                               // AR signature: "!<arch>"
                                                                                                                                                                                                                                               byte[] arSignature = {0x21, 0x3C, 0x61, 0x72, 0x63, 0x68, 0x3E, 0x0A, 0, 0, 0, 0};
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(arSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_CpioFormat1() throws Exception {
                                                                                                                                                                                                                                               // CPIO signature: "070707" or "070701" or "070702"
                                                                                                                                                                                                                                               byte[] cpioSignature = {0x30, 0x37, 0x30, 0x37, 0x30, 0x37, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(cpioSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_DumpFormat1() throws Exception {
                                                                                                                                                                                                                                               // Dump signature: starts with "DUMP"
                                                                                                                                                                                                                                               byte[] dumpSignature = new byte[32];
                                                                                                                                                                                                                                               System.arraycopy(new byte[]{'D', 'U', 'M', 'P'}, 0, dumpSignature, 0, 4);
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(dumpSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_TarFormat1() throws Exception {
                                                                                                                                                                                                                                               // Tar signature: try to create a valid tar header
                                                                                                                                                                                                                                               byte[] tarSignature = new byte[512];
                                                                                                                                                                                                                                               // Fill with zeros except for checksum
                                                                                                                                                                                                                                               tarSignature[148] = '0'; // checksum field starts at offset 148
                                                                                                                                                                                                                                               tarSignature[156] = ' '; // typeflag
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testCreateArchiveInputStream_WithEntryEncoding() throws Exception {
                                                                                                                                                                                                                                               // ZIP signature: 50 4B 03 04
                                                                                                                                                                                                                                               byte[] zipSignature = {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                               assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_NullInputStream() throws Exception {
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                       expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                       expectedException.expectMessage("InputStream must not be null.");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_NullOutputStream() {
                                                                                                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                       expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                       expectedException.expectMessage("OutputStream must not be null.");
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveOutputStream_SEVEN_Z() throws Exception {
                                                                                                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                       expectedException.expect(StreamingNotSupportedException.class);
                                                                                                                                                                                                                                       expectedException.expectMessage(ArchiveStreamFactory.SEVEN_Z);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       factory.createArchiveOutputStream(ArchiveStreamFactory.SEVEN_Z, out);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_ArjFormat1() throws Exception {
                                                                                                                                                                                                                                       // ARJ signature: 0x60 0xEA
                                                                                                                                                                                                                                       byte[] arjSignature = {(byte)0x60, (byte)0xEA, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                       InputStream input = new ByteArrayInputStream(arjSignature);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                                                                       assertTrue(result instanceof ArjArchiveInputStream);
                                                                                                                                                                                                                                   }

    @Test(expected = ArchiveException.class)
                                                                                                                                                                                                                                   public void testCreateArchiveInputStream_IOExceptionDuringRead() throws Exception {
                                                                                                                                                                                                                                       InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                       when(mockStream.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                       when(mockStream.read(any(byte[].class))).thenThrow(new IOException("Test IO Exception"));
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                       factory.createArchiveInputStream(mockStream);
                                                                                                                                                                                                                                   }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_UnmarkableStream() throws Exception {
                                                                                                                                                                                                                                   InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                   when(mockStream.markSupported()).thenReturn(false);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   factory.createArchiveInputStream(mockStream);
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                           public void testCreateArchiveInputStream_NullArchiverName() throws Exception {
                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                               InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                               
                                                                                                                                                                                               try {
                                                                                                                                                                                                   factory.createArchiveInputStream(null, inputStream);
                                                                                                                                                                                                   fail("Expected IllegalArgumentException");
                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                   assertEquals("Archivername must not be null.", e.getMessage());
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testCreateArchiveInputStream_SevenZFormat() throws Exception {
                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                               InputStream inputStream = mock(InputStream.class);
                                                                                                                                                                                               
                                                                                                                                                                                               try {
                                                                                                                                                                                                   factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, inputStream);
                                                                                                                                                                                                   fail("Expected StreamingNotSupportedException");
                                                                                                                                                                                               } catch (StreamingNotSupportedException e) {
                                                                                                                                                                                                   assertEquals(ArchiveStreamFactory.SEVEN_Z, e.getMessage());
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testCreateArchiveOutputStream_NullArchiverName() {
                                                                                                                                                                                               try {
                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                   fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                   assertEquals("Archivername must not be null.", e.getMessage());
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testCreateArchiveOutputStream_UnknownArchiver() throws Exception {
                                                                                                                                                                                               try {
                                                                                                                                                                                                   OutputStream out = mock(OutputStream.class);
                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                   factory.createArchiveOutputStream("UNKNOWN", out);
                                                                                                                                                                                                   fail("Expected ArchiveException to be thrown");
                                                                                                                                                                                               } catch (ArchiveException e) {
                                                                                                                                                                                                   assertEquals("Archiver: UNKNOWN not found.", e.getMessage());
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testCreateArchiveInputStream_SevenZFormat1() throws Exception {
                                                                                                                                                                                               // 7z signature: "7z" followed by 0xBC 0xAF 0x27 0x1C
                                                                                                                                                                                               byte[] sevenZSignature = {(byte)0x37, (byte)0x7A, (byte)0xBC, (byte)0xAF, (byte)0x27, (byte)0x1C, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(sevenZSignature);
                                                                                                                                                                                               
                                                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                               try {
                                                                                                                                                                                                   factory.createArchiveInputStream(input);
                                                                                                                                                                                                   fail("Expected StreamingNotSupportedException");
                                                                                                                                                                                               } catch (StreamingNotSupportedException e) {
                                                                                                                                                                                                   assertEquals(ArchiveStreamFactory.SEVEN_Z, e.getMessage());
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testCreateArchiveInputStream_UnknownFormat() throws Exception {
                                                                                                                                                                                               org.apache.commons.compress.archivers.ArchiveStreamFactory factory = new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                                                                                                                               
                                                                                                                                                   {
                                                                                                                                                                                                   org.junit.Assert.fail("Expected ArchiveException to be thrown");
                                                                                                                                                   }{
                                                                                                                                                                                               }
                                                                                                                                                                                           }

    @Test
                                                                                                                                                   public void testCreateArchiveInputStream_AR_CaseInsensitive() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                       
                                                                                                                                                       // Test different case variations of AR archiver name
                                                                                                                                                       String[] testCases = {"ar", "Ar", "aR", "AR"};
                                                                                                                                                       
                                                                                                                                                       for (String testCase : testCases) {
                                                                                                                                                           try {
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInputStream);
                                                                                                                                                               // Verify the returned stream is of correct type
                                                                                                                                                               assertTrue("Should return ArArchiveInputStream for case variation: " + testCase, 
                                                                                                                                                                         result instanceof ArArchiveInputStream);
                                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                                               fail("Should not throw ArchiveException for valid case variation: " + testCase);
                                                                                                                                                           }
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       // Also test with exact match to ensure basic functionality works
                                                                                                                                                       try {
                                                                                                                                                           ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                                           assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                           fail("Should not throw ArchiveException for exact match");
                                                                                                                                                       }
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testCreateArchiveInputStreamWithArIgnoresCase() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                                       
                                                                                                                                                       // Test with uppercase - should work in both original and mutated
                                                                                                                                                       ArchiveInputStream upperStream = factory.createArchiveInputStream("AR", mockInput);
                                                                                                                                                       assertTrue(upperStream instanceof ArArchiveInputStream);
                                                                                                                                                       
                                                                                                                                                       // Test with lowercase - should fail in mutated version
                                                                                                                                                       try {
                                                                                                                                                           ArchiveInputStream lowerStream = factory.createArchiveInputStream("ar", mockInput);
                                                                                                                                                           assertTrue(lowerStream instanceof ArArchiveInputStream);
                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                           fail("Case insensitive matching failed for 'ar'");
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       // Test with mixed case - should fail in mutated version
                                                                                                                                                       try {
                                                                                                                                                           ArchiveInputStream mixedStream = factory.createArchiveInputStream("Ar", mockInput);
                                                                                                                                                           assertTrue(mixedStream instanceof ArArchiveInputStream);
                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                           fail("Case insensitive matching failed for 'Ar'");
                                                                                                                                                       }
                                                                                                                                                   }

    @Test
                                                                                                                                                  public void testCreateArArchiveInputStreamWithNonNullStream() throws Exception {
                                                                                                                                                      // Setup
                                                                                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                      
                                                                                                                                                      // Test
                                                                                                                                                      ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                                      
                                                                                                                                                      // Verify
                                                                                                                                                      assertNotNull("Returned stream should not be null", result);
                                                                                                                                                      assertTrue("Should return ArArchiveInputStream", 
                                                                                                                                                                 result instanceof ArArchiveInputStream);
                                                                                                                                                      
                                                                                                                                                      // This would fail if the mutant is present since it would pass null to constructor
                                                                                                                                                      try {
                                                                                                                                                          result.read(); // Try to read to verify stream was properly constructed
                                                                                                                                                      } catch (NullPointerException e) {
                                                                                                                                                          fail("Stream was constructed with null input stream (mutant detected)");
                                                                                                                                                      }
                                                                                                                                                  }

    @Test
                                                                                                                                                 public void testCreateArchiveInputStreamForArFormat() throws Exception {
                                                                                                                                                     // Setup
                                                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                                                     
                                                                                                                                                     // Mock the input stream to return AR format signature
                                                                                                                                                     when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                                     byte[] arSignature = new byte[12];
                                                                                                                                                     System.arraycopy("!<arch>\n".getBytes(), 0, arSignature, 0, 8); // AR signature
                                                                                                                                                     when(IOUtils.readFully(mockInput, any(byte[].class)))
                                                                                                                                                         .thenAnswer(invocation -> {
                                                                                                                                                             byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                             System.arraycopy(arSignature, 0, buf, 0, arSignature.length);
                                                                                                                                                             return arSignature.length;
                                                                                                                                                         });
                                                                                                                                                     
                                                                                                                                                     // Test
                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                                                                     
                                                                                                                                                     // Verify
                                                                                                                                                     assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                     
                                                                                                                                                     // Additional check to catch the mutant - verify the stream is properly initialized
                                                                                                                                                     // This will throw NullPointerException if the mutant is present
                                                                                                                                                     try {
                                                                                                                                                         result.read();
                                                                                                                                                         // If we get here, the stream was properly initialized
                                                                                                                                                     } catch (NullPointerException e) {
                                                                                                                                                         fail("ArArchiveInputStream was initialized with null input stream");
                                                                                                                                                     }
                                                                                                                                                 }

    @Test
                                                                                                                                             public void testCreateArchiveInputStreamWithEncoding() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                                                                 
                                                                                                                                                 // Test with ZIP format (could use any format that supports encoding)
                                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                                                                                                                                 
                                                                                                                                                 // Verify that the encoded version was created
                                                                                                                                                 // The mutant would create the non-encoded version instead
                                                                                                                                                 assertTrue("Should create ZipArchiveInputStream with encoding", 
                                                                                                                                                            result instanceof ZipArchiveInputStream);
                                                                                                                                                 
                                                                                                                                                 // Additional verification that encoding was actually used
                                                                                                                                                 // This depends on implementation details, but we can verify the stream was created
                                                                                                                                                 verify(mockInput, never()).close(); // Ensure stream wasn't closed during creation
                                                                                                                                                 
                                                                                                                                                 // Test with another format (TAR) to be thorough
                                                                                                                                                 result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInput);
                                                                                                                                                 assertTrue("Should create TarArchiveInputStream with encoding", 
                                                                                                                                                            result instanceof TarArchiveInputStream);
                                                                                                                                             }

    @Test
                                                                                                                                            public void testCreateArchiveInputStream_ZipWithEncoding_ShouldUseEncoding() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                String testEncoding = "UTF-8";
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                                                                                
                                                                                                                                                // Mock input stream that will identify as ZIP format
                                                                                                                                                InputStream mockInput = mock(InputStream.class);
                                                                                                                                                when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                                
                                                                                                                                                // Mock signature reading behavior
                                                                                                                                                byte[] zipSignature = new byte[12];
                                                                                                                                                System.arraycopy(new byte[] {0x50, 0x4B, 0x03, 0x04}, 0, zipSignature, 0, 4); // ZIP signature
                                                                                                                                                when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                                    byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                    System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                                                                                    return zipSignature.length;
                                                                                                                                                });
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                // Verify encoding was set by checking the factory's encoding
                                                                                                                                                assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                                                                                
                                                                                                                                                // Cleanup
                                                                                                                                                result.close();
                                                                                                                                            }

    @Test
                                                                                                                                       public void testCreateArchiveInputStreamWithNullEntryEncoding() throws Exception {
                                                                                                                                           // Setup
                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                           InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                           
                                                                                                                                           // Test for ARJ format
                                                                                                                                           ArchiveInputStream arjStream = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInput);
                                                                                                                                           assertTrue(arjStream instanceof ArjArchiveInputStream);
                                                                                                                                           // Verify constructor without entryEncoding was used
                                                                                                                                           // Note: Removed mock verification since we're using real stream
                                                                                                                                           
                                                                                                                                           // Test for ZIP format
                                                                                                                                           ArchiveInputStream zipStream = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                                                                                                                           assertTrue(zipStream instanceof ZipArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for TAR format
                                                                                                                                           ArchiveInputStream tarStream = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInput);
                                                                                                                                           assertTrue(tarStream instanceof TarArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for JAR format
                                                                                                                                           ArchiveInputStream jarStream = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput);
                                                                                                                                           assertTrue(jarStream instanceof JarArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for CPIO format
                                                                                                                                           ArchiveInputStream cpioStream = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInput);
                                                                                                                                           assertTrue(cpioStream instanceof CpioArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for DUMP format
                                                                                                                                           ArchiveInputStream dumpStream = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInput);
                                                                                                                                           assertTrue(dumpStream instanceof DumpArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Cleanup
                                                                                                                                           arjStream.close();
                                                                                                                                           zipStream.close();
                                                                                                                                           tarStream.close();
                                                                                                                                           jarStream.close();
                                                                                                                                           cpioStream.close();
                                                                                                                                           dumpStream.close();
                                                                                                                                       }

    @Test
                                                                                                                                       public void testCreateArchiveInputStreamWithNonNullEntryEncoding() throws Exception {
                                                                                                                                           // Setup
                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                           InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                           String encoding = "UTF-8";
                                                                                                                                           factory.setEntryEncoding(encoding);
                                                                                                                                           
                                                                                                                                           // Test for ARJ format
                                                                                                                                           ArchiveInputStream arjStream = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInput);
                                                                                                                                           assertTrue(arjStream instanceof ArjArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for ZIP format
                                                                                                                                           ArchiveInputStream zipStream = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                                                                                                                           assertTrue(zipStream instanceof ZipArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for TAR format
                                                                                                                                           ArchiveInputStream tarStream = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInput);
                                                                                                                                           assertTrue(tarStream instanceof TarArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for JAR format
                                                                                                                                           ArchiveInputStream jarStream = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput);
                                                                                                                                           assertTrue(jarStream instanceof JarArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for CPIO format
                                                                                                                                           ArchiveInputStream cpioStream = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInput);
                                                                                                                                           assertTrue(cpioStream instanceof CpioArchiveInputStream);
                                                                                                                                           
                                                                                                                                           // Test for DUMP format
                                                                                                                                           ArchiveInputStream dumpStream = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInput);
                                                                                                                                           assertTrue(dumpStream instanceof DumpArchiveInputStream);
                                                                                                                                       }

    @Test
                                                                                                                                   public void testCreateZipArchiveInputStreamWithNullEncoding() throws Exception {
                                                                                                                                       // Setup
                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                       factory.setEntryEncoding(null); // Explicitly set to null
                                                                                                                                       
                                                                                                                                       // Mock a ZIP archive input stream
                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                       when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                       
                                                                                                                                       // Mock the signature reading behavior for ZIP format
                                                                                                                                       byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04}; // ZIP signature
                                                                                                                                       when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                           System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                                                                           return zipSignature.length;
                                                                                                                                       });
                                                                                                                                       
                                                                                                                                       // Test
                                                                                                                                       ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       assertNotNull(result);
                                                                                                                                       assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                   }

    @Test
                                                                                                                               public void testCreateArchiveInputStreamForTarByName() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                                                                   
                                                                                                                                   // Mock behavior for markSupported
                                                                                                                                   when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInput);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertNotNull("Result should not be null", result);
                                                                                                                                   assertTrue("Should return TarArchiveInputStream", 
                                                                                                                                             result instanceof TarArchiveInputStream);
                                                                                                                                   
                                                                                                                                   // Verify stream interactions
                                                                                                                                   verify(mockInput).markSupported();
                                                                                                                                   // No need to verify other interactions since we're testing the archiverName path
                                                                                                                               }

    @Test
                                                                                                                              public void testCreateArchiveInputStream_TarFormat_ReturnsTarArchiveInputStream() throws Exception {
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                  
                                                                                                                                  // Test with exact case match
                                                                                                                                  ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                                                                  assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                  
                                                                                                                                  // Test with different case to verify case insensitivity
                                                                                                                                  result = factory.createArchiveInputStream("tar", mockInputStream);
                                                                                                                                  assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                  
                                                                                                                                  result = factory.createArchiveInputStream("TaR", mockInputStream);
                                                                                                                                  assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                              }

    @Test
                                                                                                                              public void testCreateArchiveInputStream_TarFormatWithEncoding_ReturnsTarArchiveInputStream() throws Exception {
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                  factory.setEntryEncoding("UTF-8");
                                                                                                                                  ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                                                                  assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                              }

    @Test
                                                                                                                          public void testCreateArchiveInputStream_JarMixedCase() throws Exception {
                                                                                                                              // Setup
                                                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                                              String mixedCaseJar = "JAr";  // Mixed case to test the mutation
                                                                                                                              
                                                                                                                              // Test
                                                                                                                              ArchiveInputStream result = factory.createArchiveInputStream(mixedCaseJar, mockInput);
                                                                                                                              
                                                                                                                              // Verify
                                                                                                                              assertNotNull("Should return a stream for JAR format", result);
                                                                                                                              assertTrue("Should return JarArchiveInputStream", result instanceof JarArchiveInputStream);
                                                                                                                              
                                                                                                                              // Additional verification for encoding case
                                                                                                                              factory.setEntryEncoding("UTF-8");
                                                                                                                              result = factory.createArchiveInputStream(mixedCaseJar, mockInput);
                                                                                                                              assertNotNull("Should return a stream for JAR format with encoding", result);
                                                                                                                              assertTrue("Should return JarArchiveInputStream with encoding", result instanceof JarArchiveInputStream);
                                                                                                                          }

    @Test
                                                                                                                          public void testCreateArchiveInputStreamWithJarShouldNotCallToLowerCase() throws Exception {
                                                                                                                              // Setup
                                                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                                              when(mockInput.markSupported()).thenReturn(true);
                                                                                                                              
                                                                                                                              // Mock the signature reading for JAR format
                                                                                                                              byte[] jarSignature = "JAR_SIGNATURE".getBytes();
                                                                                                                              when(IOUtils.readFully(any(InputStream.class), any(byte[].class)))
                                                                                                                                  .thenReturn(jarSignature.length);
                                                                                                                              when(JarArchiveInputStream.matches(any(byte[].class), anyInt()))
                                                                                                                                  .thenReturn(true);
                                                                                                                              
                                                                                                                              // Test with different case variations
                                                                                                                              String[] testCases = {"JAR", "jar", "Jar", "jAr"};
                                                                                                                              
                                                                                                                              for (String testCase : testCases) {
                                                                                                                                  // Execute
                                                                                                                                  ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  assertNotNull(result);
                                                                                                                                  assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                  
                                                                                                                                  // Verify no redundant toLowerCase() call was made
                                                                                                                                  // This is implicit in the test since we're verifying the correct behavior
                                                                                                                                  // without the mutation's inefficient call
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Additional verification that the method works with the constant directly
                                                                                                                              ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput);
                                                                                                                              assertNotNull(result);
                                                                                                                              assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                          }

    @Test
                                                                                                                         public void testCreateArchiveInputStreamForCpio() throws Exception {
                                                                                                                             // Setup
                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                             
                                                                                                                             // Test with CPIO format and null encoding
                                                                                                                             try {
                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                                                                                                                                 // Verify correct type is returned for original code
                                                                                                                                 assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                 // Verify no encoding version was used
                                                                                                                                 assertNull(factory.getEntryEncoding());
                                                                                                                             } catch (ArchiveException e) {
                                                                                                                                 fail("Original code should create CpioArchiveInputStream but got exception: " + e.getMessage());
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Test with CPIO format and specific encoding
                                                                                                                             String testEncoding = "UTF-8";
                                                                                                                             factory.setEntryEncoding(testEncoding);
                                                                                                                             try {
                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                                                                                                                                 // Verify correct type is returned for original code
                                                                                                                                 assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                 // Verify encoding was passed through
                                                                                                                                 assertEquals(testEncoding, factory.getEntryEncoding());
                                                                                                                             } catch (ArchiveException e) {
                                                                                                                                 fail("Original code should create CpioArchiveInputStream with encoding but got exception: " + e.getMessage());
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Test case-insensitive matching
                                                                                                                             try {
                                                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream("cpio", mockInputStream);
                                                                                                                                 assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                             } catch (ArchiveException e) {
                                                                                                                                 fail("Original code should handle case-insensitive CPIO names but got exception: " + e.getMessage());
                                                                                                                             }
                                                                                                                         }

    @Test
                                                                                                                        public void testCreateArchiveInputStreamForCpio1() throws Exception {
                                                                                                                            // Setup
                                                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                            InputStream mockInput = mock(InputStream.class);
                                                                                                                            when(mockInput.markSupported()).thenReturn(true);
                                                                                                                            
                                                                                                                            // Create a mock CPIO signature
                                                                                                                            byte[] cpioSignature = new byte[12];
                                                                                                                            System.arraycopy(new byte[] {0x30, 0x37, 0x30, 0x37, 0x30}, 0, cpioSignature, 0, 5); // CPIO magic number
                                                                                                                            
                                                                                                                            // Mock the behavior
                                                                                                                            when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                System.arraycopy(cpioSignature, 0, buf, 0, Math.min(cpioSignature.length, buf.length));
                                                                                                                                return cpioSignature.length;
                                                                                                                            });
                                                                                                                            
                                                                                                                            // Test
                                                                                                                            ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInput);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertNotNull("Should return a stream for CPIO", result);
                                                                                                                            assertTrue("Should return a CpioArchiveInputStream", 
                                                                                                                                       result instanceof CpioArchiveInputStream);
                                                                                                                            
                                                                                                                            // Verify the stream was properly configured
                                                                                                                            verify(mockInput).mark(anyInt());
                                                                                                                            verify(mockInput, atLeastOnce()).reset();
                                                                                                                        }

    @Test
                                                                                                                    public void testCreateArchiveInputStream_DumpCaseInsensitive() throws Exception {
                                                                                                                        // Setup
                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                                                        String dumpLowerCase = "dump";  // Lowercase version of DUMP constant
                                                                                                                        
                                                                                                                        // Test and verify
                                                                                                                        try {
                                                                                                                            ArchiveInputStream result = factory.createArchiveInputStream(dumpLowerCase, mockInputStream);
                                                                                                                            assertTrue("Should return DumpArchiveInputStream for case-insensitive match", 
                                                                                                                                      result instanceof DumpArchiveInputStream);
                                                                                                                        } catch (ArchiveException e) {
                                                                                                                            fail("Original code should handle case-insensitive DUMP format");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Also test with mixed case
                                                                                                                        String dumpMixedCase = "Dump";
                                                                                                                        try {
                                                                                                                            ArchiveInputStream result = factory.createArchiveInputStream(dumpMixedCase, mockInputStream);
                                                                                                                            assertTrue("Should return DumpArchiveInputStream for case-insensitive match", 
                                                                                                                                      result instanceof DumpArchiveInputStream);
                                                                                                                        } catch (ArchiveException e) {
                                                                                                                            fail("Original code should handle case-insensitive DUMP format");
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testCreateArchiveInputStream_DumpCaseInsensitive1() throws Exception {
                                                                                                                        // Setup
                                                                                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                        InputStream mockInput = mock(InputStream.class);
                                                                                                                        
                                                                                                                        // Test exact match (should work in both original and mutated)
                                                                                                                        try {
                                                                                                                            factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInput);
                                                                                                                            // If we get here, the test passed for exact match
                                                                                                                        } catch (ArchiveException e) {
                                                                                                                            fail("Exact match case failed");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test lowercase (should work in original, fail in mutated)
                                                                                                                        try {
                                                                                                                            factory.createArchiveInputStream("dump", mockInput);
                                                                                                                            // If we get here, the original behavior is preserved
                                                                                                                        } catch (ArchiveException e) {
                                                                                                                            fail("Case insensitive matching failed - mutation detected");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test mixed case (should work in original, fail in mutated)
                                                                                                                        try {
                                                                                                                            factory.createArchiveInputStream("Dump", mockInput);
                                                                                                                            // If we get here, the original behavior is preserved
                                                                                                                        } catch (ArchiveException e) {
                                                                                                                            fail("Case insensitive matching failed - mutation detected");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test other variation (should work in original, fail in mutated)
                                                                                                                        try {
                                                                                                                            factory.createArchiveInputStream("DuMp", mockInput);
                                                                                                                            // If we get here, the original behavior is preserved
                                                                                                                        } catch (ArchiveException e) {
                                                                                                                            fail("Case insensitive matching failed - mutation detected");
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                       public void testCreateArchiveInputStreamForSevenZShouldThrowException() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                           
                                                                                                                           // Set expectation for the exception
                                                                                                                           thrown.expect(StreamingNotSupportedException.class);
                                                                                                                           thrown.expectMessage(ArchiveStreamFactory.SEVEN_Z);
                                                                                                                           
                                                                                                                           // Act
                                                                                                                           factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, mockInputStream);
                                                                                                                           
                                                                                                                           // Assertion is handled by the ExpectedException rule
                                                                                                                       }

    @Test(expected = StreamingNotSupportedException.class)
                                                                                                                  public void testCreateArchiveInputStream_SevenZFormat_ShouldThrowException() throws Exception {
                                                                                                                      // Arrange
                                                                                                                      byte[] sevenZSignature = new byte[12];
                                                                                                                      // Setup SevenZ signature bytes (simplified for test)
                                                                                                                      System.arraycopy(new byte[] {0x37, 0x7A, (byte)0xBC, (byte)0xAF, 0x27, 0x1C}, 0, 
                                                                                                                                      sevenZSignature, 0, 6);
                                                                                                                      
                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                      when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                      doAnswer(invocation -> {
                                                                                                                          byte[] buffer = (byte[]) invocation.getArguments()[0];
                                                                                                                          System.arraycopy(sevenZSignature, 0, buffer, 0, Math.min(sevenZSignature.length, buffer.length));
                                                                                                                          return sevenZSignature.length;
                                                                                                                      }).when(mockInputStream).read(any(byte[].class));
                                                                                                                      
                                                                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                      
                                                                                                                      // Act & Assert (expect exception)
                                                                                                                      factory.createArchiveInputStream(mockInputStream);
                                                                                                                  }

    @Test(expected = ArchiveException.class)
                                                                                                              public void testCreateArchiveInputStream_UnsupportedArchiver_ShouldIncludeArchiverNameInException() throws Exception {
                                                                                                                  // Arrange
                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                  String unsupportedArchiver = "UNSUPPORTED_FORMAT";
                                                                                                                  
                                                                                                                  try {
                                                                                                                      // Act
                                                                                                                      factory.createArchiveInputStream(unsupportedArchiver, mockInputStream);
                                                                                                                  } catch (ArchiveException e) {
                                                                                                                      // Assert
                                                                                                                      String expectedMessage = "Archiver: " + unsupportedArchiver + " not found.";
                                                                                                                      assertEquals("Exception message should include the unsupported archiver name", 
                                                                                                                                  expectedMessage, e.getMessage());
                                                                                                                      throw e; // rethrow to satisfy @Test(expected)
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                 public void testCreateArchiveInputStream_UnrecognizedFormat_ShouldThrowExceptionWithArchiverName() throws Exception {
                                                                                                     // Arrange
                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                     InputStream in = mock(InputStream.class);
                                                                                                     
                                                                                                     // Mock behavior for initial checks
                                                                                                     when(in.markSupported()).thenReturn(true);
                                                                                                     
                                                                                                     // Mock behavior for signature reading
                                                                                                     byte[] fakeSignature = new byte[12]; // Invalid signature
                                                                                                     when(in.read(any(byte[].class)))
                                                                                                         .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                             @Override
                                                                                                             public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                 byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                 System.arraycopy(fakeSignature, 0, buf, 0, Math.min(fakeSignature.length, buf.length));
                                                                                                                 return fakeSignature.length;
                                                                                                             }
                                                                                                         });
                                                                                                     
                                                                                                     // Act & Assert
                                                                                                     try {
                                                                                                         factory.createArchiveInputStream(in);
                                                                                                         fail("Expected ArchiveException to be thrown");
                                                                                                     } catch (org.apache.commons.compress.archivers.ArchiveException e) {
                                                                                                         // Verify the exception message contains the expected archiver name format
                                                                                                         assertTrue("Exception message should contain archiver name", 
                                                                                                                   e.getMessage().contains("No Archiver found"));
                                                                                                         throw e;
                                                                                                     }
                                                                                                 }

    @Test
                                                                                             public void testCreateArchiveInputStream_AR_CaseInsensitive1() throws Exception {
                                                                                                 // Setup
                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                 
                                                                                                 // Test with lowercase 'ar' which should work in original but fail in mutated version
                                                                                                 String lowercaseAr = "ar";
                                                                                                 
                                                                                                 // Exercise and verify
                                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(lowercaseAr, mockInputStream);
                                                                                                 assertNotNull("Should return stream for lowercase AR format", result);
                                                                                                 assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                                                 
                                                                                                 // Test with mixed case 'Ar' which should work in original but fail in mutated version
                                                                                                 String mixedCaseAr = "Ar";
                                                                                                 result = factory.createArchiveInputStream(mixedCaseAr, mockInputStream);
                                                                                                 assertNotNull("Should return stream for mixed case AR format", result);
                                                                                                 assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                                                 
                                                                                                 // Test with uppercase 'AR' which should work in both original and mutated
                                                                                                 String uppercaseAr = ArchiveStreamFactory.AR;
                                                                                                 result = factory.createArchiveInputStream(uppercaseAr, mockInputStream);
                                                                                                 assertNotNull("Should return stream for uppercase AR format", result);
                                                                                                 assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                                             }

    @Test
                                                                                             public void testCreateArchiveInputStream_AR_CaseInsensitive2() throws Exception {
                                                                                                 // Setup
                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                 
                                                                                                 // Test different case variations of AR archiver name
                                                                                                 String[] testCases = {"AR", "ar", "Ar", "aR"};
                                                                                                 
                                                                                                 for (String testCase : testCases) {
                                                                                                     // Exercise
                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInput);
                                                                                                     
                                                                                                     // Verify
                                                                                                     assertNotNull("Should return a stream for AR archiver name: " + testCase, result);
                                                                                                     assertTrue("Should return ArArchiveInputStream for: " + testCase, 
                                                                                                               result instanceof ArArchiveInputStream);
                                                                                                 }
                                                                                                 
                                                                                                 // Also test that invalid case variations fail after mutation
                                                                                                 try {
                                                                                                     factory.createArchiveInputStream("invalid", mockInput);
                                                                                                     fail("Should throw IllegalArgumentException for invalid archiver name");
                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                     // expected
                                                                                                 }
                                                                                             }

    @Test
                                                                                            public void testCreateArArchiveInputStreamWithValidStream() throws Exception {
                                                                                                // Setup
                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                
                                                                                                // Test
                                                                                                ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                
                                                                                                // Verify
                                                                                                assertNotNull("Returned stream should not be null", result);
                                                                                                assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                                                                                                
                                                                                                // Additional verification to ensure the stream was created with correct input
                                                                                                // This would typically throw NPE if mutant is present
                                                                                                try {
                                                                                                    result.read();
                                                                                                } catch (NullPointerException e) {
                                                                                                    fail("ArArchiveInputStream was created with null input stream (mutant detected)");
                                                                                                }
                                                                                            }

    @Test
                                                                                           public void testCreateArArchiveInputStreamDoesNotPassNull() throws Exception {
                                                                                               // Create a mock input stream that will identify as AR format
                                                                                               InputStream mockIn = mock(InputStream.class);
                                                                                               when(mockIn.markSupported()).thenReturn(true);
                                                                                               
                                                                                               // AR signature bytes (magic number for AR format)
                                                                                               byte[] arSignature = "!<arch>\n".getBytes();
                                                                                               when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                   System.arraycopy(arSignature, 0, buf, 0, Math.min(arSignature.length, buf.length));
                                                                                                   return arSignature.length;
                                                                                               });
                                                                                               
                                                                                               // Create the factory and test
                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                               
                                                                                               // Verify we got an AR archive stream
                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                               
                                                                                               // Now verify the stream actually uses our mock input
                                                                                               // by attempting to read from it and verifying the mock interaction
                                                                                               result.read();
                                                                                               verify(mockIn).read(any(byte[].class));
                                                                                               
                                                                                               // Alternative verification - check the stream's internal input isn't null
                                                                                               // This requires reflection but is more direct
                                                                                               Field inField = ArArchiveInputStream.class.getDeclaredField("in");
                                                                                               inField.setAccessible(true);
                                                                                               InputStream wrappedStream = (InputStream) inField.get(result);
                                                                                               assertSame(mockIn, wrappedStream);
                                                                                           }

    @Test
                                                                                       public void testCreateArchiveInputStreamWithEncoding1() throws Exception {
                                                                                           // Setup
                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                           factory.setEntryEncoding("UTF-8");
                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                           
                                                                                           // Test all archive types that support encoding
                                                                                           String[] archiveTypes = {
                                                                                               ArchiveStreamFactory.ARJ,
                                                                                               ArchiveStreamFactory.ZIP,
                                                                                               ArchiveStreamFactory.TAR,
                                                                                               ArchiveStreamFactory.JAR,
                                                                                               ArchiveStreamFactory.CPIO,
                                                                                               ArchiveStreamFactory.DUMP
                                                                                           };
                                                                                           
                                                                                           for (String type : archiveTypes) {
                                                                                               try {
                                                                                                   // This should create encoded stream in original, but basic in mutant
                                                                                                   ArchiveInputStream stream = factory.createArchiveInputStream(type, mockInput);
                                                                                                   
                                                                                                   // Verify the stream is of encoded type (original behavior)
                                                                                                   // For example, check if it's a ZipArchiveInputStream with encoding
                                                                                                   if (type.equalsIgnoreCase(ArchiveStreamFactory.ZIP)) {
                                                                                                       assertTrue("Should create encoded stream for " + type,
                                                                                                           stream instanceof ZipArchiveInputStream);
                                                                                                       // Additional checks could verify encoding was used
                                                                                                   }
                                                                                                   // Similar checks for other types...
                                                                                                   
                                                                                               } catch (Exception e) {
                                                                                                   fail("Should not throw exception for " + type + ": " + e.getMessage());
                                                                                               }
                                                                                           }
                                                                                           
                                                                                           // Additional test with null encoding
                                                                                           factory.setEntryEncoding(null);
                                                                                           for (String type : archiveTypes) {
                                                                                               try {
                                                                                                   ArchiveInputStream stream = factory.createArchiveInputStream(type, mockInput);
                                                                                                   // Should create basic stream
                                                                                                   if (type.equalsIgnoreCase(ArchiveStreamFactory.ZIP)) {
                                                                                                       assertTrue("Should create basic stream for " + type,
                                                                                                           stream instanceof ZipArchiveInputStream);
                                                                                                   }
                                                                                                   // Similar checks for other types...
                                                                                               } catch (Exception e) {
                                                                                                   fail("Should not throw exception for " + type + ": " + e.getMessage());
                                                                                               }
                                                                                           }
                                                                                       }

    @Test
                                                                                      public void testCreateArchiveInputStreamWithEntryEncoding() throws Exception {
                                                                                          // Setup
                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                          when(mockInput.markSupported()).thenReturn(true);
                                                                                          
                                                                                          // Setup ZIP signature
                                                                                          byte[] zipSignature = new byte[12];
                                                                                          System.arraycopy(new byte[] {0x50, 0x4B, 0x03, 0x04}, 0, zipSignature, 0, 4);
                                                                                          when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                              byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                              System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                              return zipSignature.length;
                                                                                          });
                                                                                          
                                                                                          // Test case 1: With entry encoding
                                                                                          factory.setEntryEncoding("UTF-8");
                                                                                          ArchiveInputStream result = factory.createArchiveInputStream(mockInput);
                                                                                          assertTrue("Should return ZipArchiveInputStream with encoding", 
                                                                                                     result instanceof ZipArchiveInputStream);
                                                                                          
                                                                                          // Verify constructor with encoding was called
                                                                                          // In original code, this would fail if mutant exists (== instead of !=)
                                                                                          
                                                                                          // Test case 2: Without entry encoding
                                                                                          factory.setEntryEncoding(null);
                                                                                          result = factory.createArchiveInputStream(mockInput);
                                                                                          assertTrue("Should return ZipArchiveInputStream without encoding", 
                                                                                                     result instanceof ZipArchiveInputStream);
                                                                                          
                                                                                          // Verify constructor without encoding was called
                                                                                          // In original code, this would fail if mutant exists (== instead of !=)
                                                                                          
                                                                                          // Additional verification could be done by checking constructor parameters
                                                                                          // but requires more complex mocking/spying
                                                                                      }

    @Test
                                                                                 public void testCreateArjArchiveInputStreamWithCustomEncoding() throws Exception {
                                                                                     // Setup
                                                                                     String testEncoding = "ISO-8859-1";
                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                     
                                                                                     // Test
                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInputStream);
                                                                                     
                                                                                     // Verify
                                                                                     assertTrue(result instanceof ArjArchiveInputStream);
                                                                                     // Verify encoding was passed correctly by checking the field value through reflection
                                                                                     Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                                     encodingField.setAccessible(true);
                                                                                     assertEquals(testEncoding, encodingField.get(result));
                                                                                 }

    @Test
                                                                                 public void testCreateArchiveInputStreamForArjWithCustomEncoding() throws Exception {
                                                                                     // Setup
                                                                                     String testEncoding = "ISO-8859-1";
                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                                                                                     
                                                                                     // Mock input stream that will identify as ARJ archive
                                                                                     InputStream mockIn = mock(InputStream.class);
                                                                                     when(mockIn.markSupported()).thenReturn(true);
                                                                                     
                                                                                     // Setup signature reading to return ARJ signature
                                                                                     byte[] arjSignature = new byte[12];
                                                                                     // ARJ signature magic numbers
                                                                                     arjSignature[0] = (byte) 0x60;
                                                                                     arjSignature[1] = (byte) 0xEA;
                                                                                     when(IOUtils.readFully(mockIn, any(byte[].class)))
                                                                                         .thenAnswer(invocation -> {
                                                                                             byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                             System.arraycopy(arjSignature, 0, buf, 0, Math.min(arjSignature.length, buf.length));
                                                                                             return arjSignature.length;
                                                                                         });
                                                                                     
                                                                                     // Execute
                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                     
                                                                                     // Verify
                                                                                     assertTrue(result instanceof ArjArchiveInputStream);
                                                                                     // Verify encoding is properly set
                                                                                     Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                                                                                     encodingField.setAccessible(true);
                                                                                     assertEquals(testEncoding, encodingField.get(result));
                                                                                     
                                                                                     // Cleanup
                                                                                     result.close();
                                                                                 }

    @Test
                                                                             public void testCreateArchiveInputStreamWithNullEncodingShouldNotUseEncoding() throws Exception {
                                                                                 // Setup
                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                 String format = ArchiveStreamFactory.ZIP;
                                                                                 
                                                                                 // Test with null encoding
                                                                                 ArchiveInputStream result = factory.createArchiveInputStream(format, mockInput);
                                                                                 
                                                                                 // Verify - should create basic ZipArchiveInputStream without encoding
                                                                                 assertTrue(result instanceof ZipArchiveInputStream);
                                                                                 try {
                                                                                     // Try to access encoding field through reflection to verify it's null
                                                                                     Field encodingField = ZipArchiveInputStream.class.getDeclaredField("encoding");
                                                                                     encodingField.setAccessible(true);
                                                                                     assertNull(encodingField.get(result));
                                                                                 } catch (NoSuchFieldException e) {
                                                                                     // If field doesn't exist, that's also acceptable as it means no encoding was set
                                                                                 }
                                                                                 
                                                                                 // Additional verification - check no encoding was passed to constructor
                                                                                 // This would fail with the mutant since it would try to use encoding
                                                                                 verify(mockInput, never()).close(); // Ensure no side effects
                                                                             }

    @Test
                                                                            public void testCreateArchiveInputStream_ZipFormat_NoEntryEncoding_UsesDefaultConstructor() throws Exception {
                                                                                // Setup
                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                factory.setEntryEncoding(null); // Explicitly set to null
                                                                                
                                                                                // Create a mock input stream that returns ZIP signature
                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                when(mockIn.markSupported()).thenReturn(true);
                                                                                
                                                                                // ZIP signature (first 4 bytes are 'PK' magic number)
                                                                                byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                
                                                                                // Mock the readFully behavior
                                                                                when(mockIn.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                    byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                    System.arraycopy(zipSignature, 0, buf, 0, Math.min(zipSignature.length, buf.length));
                                                                                    return zipSignature.length;
                                                                                });
                                                                                
                                                                                // Test
                                                                                ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                                                                                
                                                                                // Verify - should use ZipArchiveInputStream(InputStream) constructor
                                                                                // If mutant is present, it would use ZipArchiveInputStream(InputStream, String) with null encoding
                                                                                assertTrue(result instanceof ZipArchiveInputStream);
                                                                                
                                                                                // Additional verification to ensure no encoding was passed
                                                                                // This is implementation-specific, but we can verify the encoding wasn't used
                                                                                // by checking if the encoding field is null in the created stream
                                                                                Field encodingField = ZipArchiveInputStream.class.getDeclaredField("encoding");
                                                                                encodingField.setAccessible(true);
                                                                                assertNull(encodingField.get(result));
                                                                            }

    @Test
                                                                        public void testCreateArchiveInputStream_JarExactCase() throws Exception {
                                                                            // Setup
                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                            InputStream mockInput = mock(InputStream.class);
                                                                            
                                                                            // Get the exact case of JAR constant using reflection since it's public
                                                                            Field jarField = ArchiveStreamFactory.class.getField("JAR");
                                                                            String jarConstant = (String) jarField.get(null);
                                                                            
                                                                            // Test with exact case match
                                                                            ArchiveInputStream result = factory.createArchiveInputStream(jarConstant, mockInput);
                                                                            
                                                                            // Verify
                                                                            assertNotNull("Should return stream for exact case match", result);
                                                                            assertTrue("Should return JarArchiveInputStream", 
                                                                                       result instanceof JarArchiveInputStream);
                                                                            
                                                                            // Also test with lowercase to ensure original functionality still works
                                                                            ArchiveInputStream lowerResult = factory.createArchiveInputStream(jarConstant.toLowerCase(), mockInput);
                                                                            assertNotNull("Should return stream for lowercase", lowerResult);
                                                                            assertTrue("Should return JarArchiveInputStream", 
                                                                                       lowerResult instanceof JarArchiveInputStream);
                                                                        }

    @Test
                                                                        public void testCreateArchiveInputStreamWithJarArchiverNameCaseVariations() throws Exception {
                                                                            // Setup
                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                            InputStream mockInput = mock(InputStream.class);
                                                                            
                                                                            // Test with exact case match
                                                                            ArchiveInputStream result1 = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput);
                                                                            assertTrue(result1 instanceof JarArchiveInputStream);
                                                                            
                                                                            // Test with uppercase
                                                                            ArchiveInputStream result2 = factory.createArchiveInputStream(ArchiveStreamFactory.JAR.toUpperCase(), mockInput);
                                                                            assertTrue(result2 instanceof JarArchiveInputStream);
                                                                            
                                                                            // Test with lowercase
                                                                            ArchiveInputStream result3 = factory.createArchiveInputStream(ArchiveStreamFactory.JAR.toLowerCase(), mockInput);
                                                                            assertTrue(result3 instanceof JarArchiveInputStream);
                                                                            
                                                                            // Test with mixed case
                                                                            ArchiveInputStream result4 = factory.createArchiveInputStream("jAr", mockInput);
                                                                            assertTrue(result4 instanceof JarArchiveInputStream);
                                                                            
                                                                            // Test with non-ASCII characters (should still work)
                                                                            ArchiveInputStream result5 = factory.createArchiveInputStream("JÄR", mockInput);
                                                                            assertTrue(result5 instanceof JarArchiveInputStream);
                                                                            
                                                                            // Verify that the method was called with the exact archiver name (not lowercased)
                                                                            // This would fail if the mutant was present
                                                                            verify(mockInput, times(5)).mark(anyInt());
                                                                            verify(mockInput, times(5)).reset();
                                                                        }

    @Test
                                                                       public void testCreateArchiveInputStream_CPIO_ShouldReturnCpioArchiveInputStream() throws Exception {
                                                                           // Arrange
                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                           String cpioArchiverName = ArchiveStreamFactory.CPIO; // Using the constant
                                                                           
                                                                           // Act
                                                                           ArchiveInputStream result = factory.createArchiveInputStream(cpioArchiverName, mockInputStream);
                                                                           
                                                                           // Assert
                                                                           assertNotNull("Result should not be null", result);
                                                                           assertTrue("Should return CpioArchiveInputStream", 
                                                                                      result instanceof CpioArchiveInputStream);
                                                                           
                                                                           // Additional test with different case to verify equalsIgnoreCase
                                                                           ArchiveInputStream result2 = factory.createArchiveInputStream("cpio", mockInputStream);
                                                                           assertNotNull("Result should not be null for case variation", result2);
                                                                           assertTrue("Should return CpioArchiveInputStream for case variation",
                                                                                      result2 instanceof CpioArchiveInputStream);
                                                                           
                                                                           // Test with entry encoding
                                                                           factory.setEntryEncoding("UTF-8");
                                                                           ArchiveInputStream resultWithEncoding = factory.createArchiveInputStream(cpioArchiverName, mockInputStream);
                                                                           assertNotNull("Result with encoding should not be null", resultWithEncoding);
                                                                           assertTrue("Should return CpioArchiveInputStream with encoding",
                                                                                      resultWithEncoding instanceof CpioArchiveInputStream);
                                                                       }

    @Test
                                                                  public void testCreateArchiveInputStream_CPIO_ExplicitRequest() throws Exception {
                                                                      // Prepare test data
                                                                      String cpioSignature = "070707"; // Simplified CPIO signature for testing
                                                                      InputStream inputStream = new ByteArrayInputStream(cpioSignature.getBytes());
                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                      
                                                                      // Test the method - no need to mock static methods for explicit request
                                                                      ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, inputStream);
                                                                      
                                                                      // Verify the result
                                                                      assertNotNull("Result should not be null", result);
                                                                      assertTrue("Should return CpioArchiveInputStream", 
                                                                               result instanceof CpioArchiveInputStream);
                                                                  }

    @Test
                                                              public void testCreateArchiveInputStream_DUMP_CaseInsensitive() throws Exception {
                                                                  // Setup
                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                  
                                                                  // Test with lowercase "dump" - should work in original but fail in mutant
                                                                  try {
                                                                      ArchiveInputStream result = factory.createArchiveInputStream("dump", mockInputStream);
                                                                      assertNotNull("Should create DumpArchiveInputStream for 'dump'", result);
                                                                      assertTrue("Should be instance of DumpArchiveInputStream", 
                                                                                result instanceof DumpArchiveInputStream);
                                                                  } catch (ArchiveException e) {
                                                                      fail("Original method should handle case-insensitive 'dump'");
                                                                  }
                                                                  
                                                                  // Test with mixed case "Dump" - should work in original but fail in mutant
                                                                  try {
                                                                      ArchiveInputStream result = factory.createArchiveInputStream("Dump", mockInputStream);
                                                                      assertNotNull("Should create DumpArchiveInputStream for 'Dump'", result);
                                                                      assertTrue("Should be instance of DumpArchiveInputStream", 
                                                                                result instanceof DumpArchiveInputStream);
                                                                  } catch (ArchiveException e) {
                                                                      fail("Original method should handle case-insensitive 'Dump'");
                                                                  }
                                                                  
                                                                  // Test with uppercase "DUMP" - should work in both original and mutant
                                                                  try {
                                                                      ArchiveInputStream result = factory.createArchiveInputStream("DUMP", mockInputStream);
                                                                      assertNotNull("Should create DumpArchiveInputStream for 'DUMP'", result);
                                                                      assertTrue("Should be instance of DumpArchiveInputStream", 
                                                                                result instanceof DumpArchiveInputStream);
                                                                  } catch (ArchiveException e) {
                                                                      fail("Should handle 'DUMP' in both original and mutant");
                                                                  }
                                                              }

    @Test
                                         public void testCreateArchiveInputStream_DumpCaseInsensitive2() throws Exception {
                                             // Setup
                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                             InputStream inputStream = mock(InputStream.class);
                                             
                                             // Mock DUMP signature
                                             when(inputStream.markSupported()).thenReturn(true);
                                             byte[] dumpSignature = new byte[32];
                                             // Setup dump signature bytes
                                             when(IOUtils.readFully(inputStream, any(byte[].class)))
                                                 .thenAnswer(invocation -> {
                                                     byte[] buf = (byte[]) invocation.getArguments()[0];
                                                     System.arraycopy(dumpSignature, 0, buf, 0, dumpSignature.length);
                                                     return dumpSignature.length;
                                                 });
                                             when(DumpArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(true);
                                             
                                             // Test case variations
                                             // Should work with all these variations in original code
                                             // but fail with mutated code for non-exact matches
                                             String[] testCases = {"DUMP", "dump", "Dump", "duMP"};
                                             
                                             for (String testCase : testCases) {
                                                 try {
                                                     ArchiveInputStream result = factory.createArchiveInputStream(testCase, inputStream);
                                                     assertNotNull("Should create stream for " + testCase, result);
                                                     assertTrue("Should be DumpArchiveInputStream", 
                                                               result instanceof DumpArchiveInputStream);
                                                 } catch (ArchiveException e) {
                                                     fail("Failed for case: " + testCase);
                                                 }
                                             }
                                         }

    @Test(expected = StreamingNotSupportedException.class)
                                     public void testCreateArchiveInputStream_SevenZ_ShouldThrowException() throws Exception {
                                         // Arrange
                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                         InputStream mockInputStream = mock(InputStream.class);
                                         
                                         // Act
                                         factory.createArchiveInputStream(ArchiveStreamFactory.SEVEN_Z, mockInputStream);
                                         
                                         // Assert - Expecting StreamingNotSupportedException to be thrown
                                         // If mutant is present (returns null), this test will fail
                                     }

    @Test(expected = StreamingNotSupportedException.class)
                                    public void testCreateArchiveInputStream_SevenZFormat_ShouldThrowException1() throws Exception {
                                        // Arrange
                                        byte[] sevenZSignature = new byte[12];
                                        // Setup SevenZ signature (first 6 bytes are 0x7z in ASCII)
                                        sevenZSignature[0] = '7';
                                        sevenZSignature[1] = 'z';
                                        sevenZSignature[2] = (byte) 0xBC;
                                        sevenZSignature[3] = (byte) 0xAF;
                                        sevenZSignature[4] = 0x27;
                                        sevenZSignature[5] = 0x1C;
                                        
                                        InputStream mockInputStream = mock(InputStream.class);
                                        when(mockInputStream.markSupported()).thenReturn(true);
                                        when(mockInputStream.read(any(byte[].class))).thenAnswer(invocation -> {
                                            byte[] buffer = (byte[]) invocation.getArguments()[0];
                                            System.arraycopy(sevenZSignature, 0, buffer, 0, Math.min(sevenZSignature.length, buffer.length));
                                            return sevenZSignature.length;
                                        });
                                        
                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                        
                                        // Act & Assert (expect exception)
                                        factory.createArchiveInputStream(mockInputStream);
                                    }

    @Test(expected = ArchiveException.class)
                                public void testCreateArchiveInputStream_UnknownFormat_ShouldThrowExceptionWithArchiverName() throws Exception {
                                    // Arrange
                                    InputStream mockInputStream = mock(InputStream.class);
                                    when(mockInputStream.markSupported()).thenReturn(true);
                                    
                                    // Mock signature that doesn't match any known format
                                    byte[] unknownSignature = new byte[12];
                                    when(IOUtils.readFully(mockInputStream, any(byte[].class)))
                                        .thenReturn(unknownSignature.length);
                                    
                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                    
                                    // Act
                                    try {
                                        factory.createArchiveInputStream(mockInputStream);
                                    } catch (ArchiveException e) {
                                        // Assert
                                        assertTrue("Exception message should contain archiver name", 
                                                  e.getMessage().contains("No Archiver found for the stream signature"));
                                        throw e;
                                    }
                                }

    @Test
                               public void testCreateArchiveInputStreamWithUnknownArchiverShouldIncludeArchiverNameInException() throws Exception {
                                   // Arrange
                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                   String unknownArchiver = "UNKNOWN_FORMAT";
                                   InputStream mockedInputStream = mock(InputStream.class);
                                   
                                   try {
                                       // Act
                                       factory.createArchiveInputStream(unknownArchiver, mockedInputStream);
                                       fail("Expected ArchiveException to be thrown");
                                   } catch (ArchiveException e) {
                                       // Assert
                                       assertEquals("Archiver: " + unknownArchiver + " not found.", e.getMessage());
                                   }
                               }

    @Test
                               public void testCreateArchiveInputStream_AR_CaseInsensitive3() throws Exception {
                                   // Setup
                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                   InputStream mockInput = mock(InputStream.class);
                                   
                                   // Test different case variations of AR archiver name
                                   String[] testCases = {"AR", "ar", "Ar", "aR"};
                                   
                                   for (String archiverName : testCases) {
                                       // Exercise
                                       Object result = factory.createArchiveInputStream(archiverName, mockInput);
                                       
                                       // Verify
                                       assertNotNull("Should return a stream for " + archiverName, result);
                                       assertTrue("Should return ArArchiveInputStream for " + archiverName, 
                                                  result instanceof ArArchiveInputStream);
                                   }
                               }

    @Test
                           public void testCreateArchiveInputStreamWithCaseInsensitiveAR() throws Exception {
                               // Setup
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               InputStream mockInputStream = mock(InputStream.class);
                               
                               // Test with different case variations of "AR"
                               String[] testCases = {"ar", "Ar", "aR", "AR"};
                               
                               for (String testCase : testCases) {
                                   // Exercise
                                   ArchiveInputStream result = factory.createArchiveInputStream(testCase, mockInputStream);
                                   
                                   // Verify
                                   assertNotNull("Should return stream for AR archiver with case: " + testCase, result);
                                   assertTrue("Should return ArArchiveInputStream for case: " + testCase, 
                                             result instanceof ArArchiveInputStream);
                               }
                           }

    @Test
                          public void testCreateArArchiveInputStreamWithNonNullStream1() throws Exception {
                              // Setup
                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                              InputStream mockInputStream = mock(InputStream.class);
                              
                              // Test
                              ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                              
                              // Verify
                              assertNotNull("Result should not be null", result);
                              assertTrue("Should return ArArchiveInputStream", result instanceof ArArchiveInputStream);
                              
                              // This is the key assertion to catch the mutant
                              // The mutant would either throw NPE here or have null input stream
                              try {
                                  result.read(); // Try to read from the stream
                              } catch (NullPointerException e) {
                                  fail("Input stream should not be null in ArArchiveInputStream");
                              }
                          }

    @Test
                         public void testCreateArchiveInputStreamForArFormat1() throws Exception {
                             // Prepare AR archive signature
                             byte[] arSignature = new byte[12];
                             // AR signature is "!<arch>\n" (8 bytes) followed by file entries
                             System.arraycopy("!<arch>\n".getBytes(), 0, arSignature, 0, 8);
                             
                             // Create mock input stream
                             InputStream in = mock(InputStream.class);
                             when(in.markSupported()).thenReturn(true);
                             
                             // First mark/read for initial signature check
                             when(in.read(any(byte[].class))).thenAnswer(invocation -> {
                                 byte[] buf = (byte[]) invocation.getArguments()[0];
                                 System.arraycopy(arSignature, 0, buf, 0, Math.min(arSignature.length, buf.length));
                                 return arSignature.length;
                             });
                             
                             // Create factory instance
                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                             
                             // Test the method
                             ArchiveInputStream result = factory.createArchiveInputStream(in);
                             
                             // Verify the result is an AR archive stream with the correct input
                             assertTrue(result instanceof ArArchiveInputStream);
                             
                             // This is the key assertion to catch the mutant - verify the stream was created with our input
                             // The mutant would pass null instead of 'in'
                             Field inField = ArArchiveInputStream.class.getDeclaredField("in");
                             inField.setAccessible(true);
                             InputStream wrappedStream = (InputStream) inField.get(result);
                             assertSame(in, wrappedStream);
                         }

    @Test
                    public void testCreateArchiveInputStreamForArjWithCustomEncoding1() throws Exception {
                        // Setup
                        String testEncoding = "ISO-8859-1";
                        ArchiveStreamFactory factory = new ArchiveStreamFactory(testEncoding);
                        factory.setEntryEncoding(testEncoding);
                        
                        // Create a mock input stream that will be recognized as ARJ
                        InputStream in = mock(InputStream.class);
                        when(in.markSupported()).thenReturn(true);
                        
                        // ARJ signature bytes
                        byte[] arjSignature = new byte[] {
                            (byte) 0x60, (byte) 0xEA, // ARJ magic number
                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0 // rest of signature
                        };
                        
                        // Mock the behavior of reading signature
                        when(in.read(any(byte[].class))).thenAnswer(invocation -> {
                            byte[] buffer = (byte[]) invocation.getArguments()[0];
                            System.arraycopy(arjSignature, 0, buffer, 0, Math.min(arjSignature.length, buffer.length));
                            return arjSignature.length;
                        });
                        
                        // Test
                        ArchiveInputStream result = factory.createArchiveInputStream(in);
                        
                        // Verify
                        assertTrue(result instanceof ArjArchiveInputStream);
                        // Verify encoding through the factory
                        assertEquals(testEncoding, factory.getEntryEncoding());
                    }

    @Test
                public void testCreateArjArchiveInputStreamWithCustomEncoding1() throws Exception {
                    // Setup
                    String testEncoding = "ISO-8859-1";
                    InputStream mockInputStream = mock(InputStream.class);
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    factory.setEntryEncoding(testEncoding);
                    
                    // Test
                    ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInputStream);
                    
                    // Verify
                    assertTrue(result instanceof ArjArchiveInputStream);
                    // Use reflection to get the encoding field since it might be private
                    Field encodingField = ArjArchiveInputStream.class.getDeclaredField("encoding");
                    encodingField.setAccessible(true);
                    String actualEncoding = (String) encodingField.get(result);
                    assertEquals(testEncoding, actualEncoding);
                    
                    // Cleanup
                    result.close();
                }

    @Test
            public void testCreateArchiveInputStream_JarCaseSensitivity() throws Exception {
                // Setup
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                InputStream mockInput = mock(InputStream.class);
                String jarArchiverName = ArchiveStreamFactory.JAR; // Get the exact case of JAR constant
                
                // Test with exact case match of JAR constant
                ArchiveInputStream result = factory.createArchiveInputStream(jarArchiverName, mockInput);
                
                // Verify
                assertNotNull("Should return a stream for exact case match of JAR", result);
                assertTrue("Should return JarArchiveInputStream", result instanceof JarArchiveInputStream);
                
                // Additional test with lowercase to ensure basic functionality
                ArchiveInputStream lowerCaseResult = factory.createArchiveInputStream(jarArchiverName.toLowerCase(), mockInput);
                assertNotNull("Should return a stream for lowercase JAR", lowerCaseResult);
                assertTrue("Should return JarArchiveInputStream", lowerCaseResult instanceof JarArchiveInputStream);
                
                // Additional test with mixed case to ensure basic functionality
                ArchiveInputStream mixedCaseResult = factory.createArchiveInputStream("jAr", mockInput);
                assertNotNull("Should return a stream for mixed case JAR", mixedCaseResult);
                assertTrue("Should return JarArchiveInputStream", mixedCaseResult instanceof JarArchiveInputStream);
            }

    @Test
            public void testCreateArchiveInputStreamWithJarArchiverName() throws Exception {
                // Test with null archiverName - original handles it, mutant throws NPE
                try {
                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                    factory.createArchiveInputStream(null, mock(InputStream.class));
                    fail("Expected IllegalArgumentException");
                } catch (IllegalArgumentException e) {
                    // Expected
                }
                
                // Test with exact match
                InputStream input = mock(InputStream.class);
                when(input.markSupported()).thenReturn(true);
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                try {
                    factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                    // Should throw ArchiveException since we didn't mock the signature reading
                } catch (ArchiveException e) {
                    // Expected
                }
                
                // Test with mixed case
                try {
                    factory.createArchiveInputStream("jAr", input);
                    // Should throw ArchiveException since we didn't mock the signature reading
                } catch (ArchiveException e) {
                    // Expected
                }
                
                // Test with non-ASCII characters
                try {
                    factory.createArchiveInputStream("JÄR", input);
                    // Should throw ArchiveException since we didn't mock the signature reading
                } catch (ArchiveException e) {
                    // Expected
                }
                
                // Test with empty string
                try {
                    factory.createArchiveInputStream("", input);
                    fail("Expected ArchiveException");
                } catch (ArchiveException e) {
                    // Expected
                }
            }

    @Test
               public void testCreateArchiveInputStream_DUMP_CaseInsensitive1() throws Exception {
                   // Arrange
                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                   InputStream mockInput = mock(InputStream.class);
                   
                   // Act - test with different case variations of DUMP
                   ArchiveInputStream resultLower = factory.createArchiveInputStream("dump", mockInput);
                   ArchiveInputStream resultUpper = factory.createArchiveInputStream("DUMP", mockInput);
                   ArchiveInputStream resultMixed = factory.createArchiveInputStream("Dump", mockInput);
                   
                   // Assert - all variations should return DumpArchiveInputStream
                   assertTrue("Lowercase 'dump' should return DumpArchiveInputStream", 
                              resultLower instanceof DumpArchiveInputStream);
                   assertTrue("Uppercase 'DUMP' should return DumpArchiveInputStream", 
                              resultUpper instanceof DumpArchiveInputStream);
                   assertTrue("Mixed case 'Dump' should return DumpArchiveInputStream", 
                              resultMixed instanceof DumpArchiveInputStream);
               }

    @Test
               public void testCreateArchiveInputStream_DUMP_WithEncoding_CaseInsensitive() throws Exception {
                   // Arrange
                   ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
                   InputStream mockInput = mock(InputStream.class);
                   
                   // Act - test with different case variations of DUMP with encoding
                   ArchiveInputStream resultLower = factory.createArchiveInputStream("dump", mockInput);
                   ArchiveInputStream resultUpper = factory.createArchiveInputStream("DUMP", mockInput);
                   ArchiveInputStream resultMixed = factory.createArchiveInputStream("Dump", mockInput);
                   
                   // Assert - all variations should return DumpArchiveInputStream
                   assertTrue("Lowercase 'dump' with encoding should return DumpArchiveInputStream", 
                              resultLower instanceof DumpArchiveInputStream);
                   assertTrue("Uppercase 'DUMP' with encoding should return DumpArchiveInputStream", 
                              resultUpper instanceof DumpArchiveInputStream);
                   assertTrue("Mixed case 'Dump' with encoding should return DumpArchiveInputStream", 
                              resultMixed instanceof DumpArchiveInputStream);
               }

    @Test
          public void testCreateArchiveInputStream_DumpCaseInsensitive3() throws Exception {
              // Setup
              ArchiveStreamFactory factory = new ArchiveStreamFactory();
              InputStream mockInput = mock(InputStream.class);
              when(mockInput.markSupported()).thenReturn(true);
              
              // Mock DUMP signature
              byte[] dumpSignature = "DUMP_SIGNATURE".getBytes();
              // Setup mock to return DUMP signature when read
              when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                  byte[] buf = (byte[]) invocation.getArguments()[0];
                  System.arraycopy(dumpSignature, 0, buf, 0, Math.min(dumpSignature.length, buf.length));
                  return buf.length;
              });
              
              // Test exact case match (should pass in both original and mutated)
              ArchiveInputStream exactCaseStream = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInput);
              assertNotNull(exactCaseStream);
              assertTrue(exactCaseStream instanceof DumpArchiveInputStream);
              
              // Test lowercase (should pass in original, fail in mutated)
              ArchiveInputStream lowerCaseStream = factory.createArchiveInputStream("dump", mockInput);
              assertNotNull(lowerCaseStream);
              assertTrue(lowerCaseStream instanceof DumpArchiveInputStream);
              
              // Test mixed case (should pass in original, fail in mutated)
              ArchiveInputStream mixedCaseStream = factory.createArchiveInputStream("Dump", mockInput);
              assertNotNull(mixedCaseStream);
              assertTrue(mixedCaseStream instanceof DumpArchiveInputStream);
              
              // Test other case variation (should pass in original, fail in mutated)
              ArchiveInputStream otherCaseStream = factory.createArchiveInputStream("DuMp", mockInput);
              assertNotNull(otherCaseStream);
              assertTrue(otherCaseStream instanceof DumpArchiveInputStream);
          }

    @Test(expected = ArchiveException.class)
      public void testCreateArchiveInputStreamWithUnsupportedArchiver_ShouldThrowExceptionWithArchiverName() throws Exception {
          // Arrange
          ArchiveStreamFactory factory = new ArchiveStreamFactory();
          InputStream mockInputStream = mock(InputStream.class);
          String unsupportedArchiver = "UNSUPPORTED_FORMAT";
          
          try {
              // Act
              factory.createArchiveInputStream(unsupportedArchiver, mockInputStream);
              fail("Expected ArchiveException to be thrown");
          } catch (ArchiveException e) {
              // Assert
              String expectedMessage = "Archiver: " + unsupportedArchiver + " not found.";
              String actualMessage = e.getMessage();
              assertEquals("Exception message should contain the unsupported archiver name", 
                          expectedMessage, actualMessage);
              throw e; // rethrow to satisfy @Test(expected)
          }
      }

    @Test(expected = ArchiveException.class)
      public void testCreateArchiveInputStream_UnrecognizedFormat_ShouldThrowExceptionWithArchiverName1() throws Exception {
          // Arrange
          ArchiveStreamFactory factory = new ArchiveStreamFactory();
          byte[] unrecognizedSignature = new byte[12]; // Doesn't match any known format
          InputStream input = new ByteArrayInputStream(unrecognizedSignature);
          
          try {
              // Act
              factory.createArchiveInputStream(input);
              fail("Expected ArchiveException to be thrown");
          } catch (ArchiveException e) {
              // Assert
              assertTrue("Exception message should contain archiver name", 
                        e.getMessage().contains("No Archiver found for the stream signature"));
              throw e;
          }
      }

    @Test
     public void testCreateArjArchiveInputStreamWithoutEncoding() throws Exception {
         // Setup
         ArchiveStreamFactory factory = new ArchiveStreamFactory();
         InputStream mockInput = mock(InputStream.class);
         
         // Test with ARJ format and null entry encoding
         ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ARJ, mockInput);
         
         // Verify
         assertNotNull("Result should not be null", result);
         assertTrue("Should return ArjArchiveInputStream", 
                    result instanceof ArjArchiveInputStream);
         
         // Additional verification to catch the mutant
         try {
             // This will fail if the mutant is present (using constructor with null encoding)
             // as it would be a different constructor call
             Method getEntryEncoding = ArjArchiveInputStream.class.getMethod("getEntryEncoding");
             Object encoding = getEntryEncoding.invoke(result);
             assertNull("Entry encoding should be null when not specified", encoding);
         } catch (NoSuchMethodException e) {
             // If getEntryEncoding doesn't exist, we can't verify further
             // But the type check above should be sufficient
         }
     }

    @Test
    public void testCreateArjArchiveInputStreamWithNullEncoding() throws Exception {
        // Setup
        ArchiveStreamFactory factory = new ArchiveStreamFactory();
        factory.setEntryEncoding(null); // Explicitly set to null
        
        // Create a mock input stream that will be recognized as ARJ format
        InputStream in = mock(InputStream.class);
        when(in.markSupported()).thenReturn(true);
        
        // ARJ signature bytes
        byte[] arjSignature = new byte[] { 
            0x60, (byte)0xEA, 0x00, 0x00, // ARJ magic number
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        };
        
        // Mock the behavior for signature reading
        when(in.read(any(byte[].class))).thenAnswer(invocation -> {
            byte[] buffer = (byte[]) invocation.getArguments()[0];
            System.arraycopy(arjSignature, 0, buffer, 0, Math.min(buffer.length, arjSignature.length));
            return arjSignature.length;
        });
        
        // Test
        ArchiveInputStream result = factory.createArchiveInputStream(in);
        
        // Verify
        assertNotNull("Should return a stream for ARJ format", result);
        assertTrue("Should be an ARJ archive stream", result instanceof ArjArchiveInputStream);
        
        // Additional verification to catch the mutant
        // The mutant would use the 2-arg constructor with null encoding,
        // while original uses 1-arg constructor when encoding is null
        // We can verify this by checking if the stream behaves differently
        // with null encoding in 1-arg vs 2-arg constructor
        
        // Try to read from the stream - if mutant is present and causes different behavior,
        // this might throw an exception or behave differently
        try {
            result.read();
        } catch (Exception e) {
            fail("Stream should be properly initialized. Exception: " + e.getMessage());
        }
    }


}
