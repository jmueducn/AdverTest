package gentest.org.apache.commons.compress.archivers.sevenz.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.sevenz.*;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.LinkedList;
import java.util.zip.CRC32;
import org.apache.commons.compress.utils.BoundedInputStream;
import org.apache.commons.compress.utils.CRC32VerifyingInputStream;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class SevenZFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                          public void testGetCurrentStream_SingleStream() throws Exception {
                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(mock(File.class));
                                                                                                                                                                                                                                                              InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                              streams.add(mockStream);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                                                                                                                              Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                              archiveField.setAccessible(true);
                                                                                                                                                                                                                                                              archiveField.set(sevenZFile, new Object()); // Dummy object since we can't mock Archive
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                              currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                              currentEntryField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              Field streamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                              streamsField.setAccessible(true);
                                                                                                                                                                                                                                                              streamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test by accessing private method via reflection
                                                                                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                              assertSame(mockStream, result);
                                                                                                                                                                                                                                                              assertEquals(1, streams.size()); // No streams removed
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testGetCurrentStream_MultipleStreams() throws Exception {
                                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                                              SevenZFile sevenZFile = new SevenZFile(mock(File.class));
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              InputStream mockStream1 = mock(InputStream.class);
                                                                                                                                                                                                                                                              InputStream mockStream2 = mock(InputStream.class);
                                                                                                                                                                                                                                                              InputStream mockStream3 = mock(InputStream.class);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                              streams.add(mockStream1);
                                                                                                                                                                                                                                                              streams.add(mockStream2);
                                                                                                                                                                                                                                                              streams.add(mockStream3);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                                                                                                                              Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                              deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                              deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                              currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                              currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Use reflection to call private method
                                                                                                                                                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                                                              assertSame(mockStream3, result); // First two should be removed
                                                                                                                                                                                                                                                              assertEquals(1, streams.size());
                                                                                                                                                                                                                                                              verify(mockStream1).close();
                                                                                                                                                                                                                                                              verify(mockStream2).close();
                                                                                                                                                                                                                                                              verify(mockStream1, atLeastOnce()).skip(anyLong());
                                                                                                                                                                                                                                                              verify(mockStream2, atLeastOnce()).skip(anyLong());
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                      public void testGetCurrentStream_EmptyFile() throws Exception {
                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                          File tempFile = File.createTempFile("empty", ".7z");
                                                                                                                                                                                                                                                          tempFile.deleteOnExit();
                                                                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Set private fields using reflection
                                                                                                                                                                                                                                                          Class<?> sevenZFileClass = sevenZFile.getClass();
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Create a minimal archive structure through reflection
                                                                                                                                                                                                                                                          Object archive = sevenZFileClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                                                                          Object[] filesArray = (Object[]) Array.newInstance(archive.getClass().getDeclaredField("files").getType().getComponentType(), 1);
                                                                                                                                                                                                                                                          Array.set(filesArray, 0, archive);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Set fields
                                                                                                                                                                                                                                                          Field archiveField = sevenZFileClass.getDeclaredField("archive");
                                                                                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                                                                                          archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                          filesField.setAccessible(true);
                                                                                                                                                                                                                                                          filesField.set(archive, filesArray);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          Field sizeField = archive.getClass().getDeclaredField("size");
                                                                                                                                                                                                                                                          sizeField.setAccessible(true);
                                                                                                                                                                                                                                                          sizeField.set(archive, 0L);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          Field currentEntryIndexField = sevenZFileClass.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          Field deferredBlockStreamsField = sevenZFileClass.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Get current stream through reflection
                                                                                                                                                                                                                                                          Method getCurrentStreamMethod = sevenZFileClass.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                                                          assertNotNull(result);
                                                                                                                                                                                                                                                          assertEquals(0, result.available());
                                                                                                                                                                                                                                                          assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                      public void testGetCurrentStream_NoStreamsThrowsException() throws Exception {
                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                          File mockFile = mock(File.class);
                                                                                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Set private fields needed for the test using reflection
                                                                                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Get the private method via reflection
                                                                                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Expect exception
                                                                                                                                                                                                                                                          ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                          expectedException.expect(IllegalStateException.class);
                                                                                                                                                                                                                                                          expectedException.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Test
                                                                                                                                                                                                                                                          getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                 public void testGetCurrentStream_EmptyFile_ReturnsEmptyStream() throws Exception {
                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Mock entry with size 0
                                                                                                                                                                                                                                                     SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                     when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                                                                                                     Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                     archiveField.setAccessible(true);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Create a minimal archive structure using reflection
                                                                                                                                                                                                                                                     Object archive = new Object() {
                                                                                                                                                                                                                                                         public Object[] files = new Object[] {
                                                                                                                                                                                                                                                             new Object() {
                                                                                                                                                                                                                                                                 public SevenZArchiveEntry getEntry() { return entry; }
                                                                                                                                                                                                                                                                 public long getSize() { return 0L; }
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                     archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                     currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                     currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                     deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                     deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Test by invoking private method via reflection
                                                                                                                                                                                                                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                     getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                     InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                     assertEquals(0, result.available()); // Should be empty stream
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Cleanup
                                                                                                                                                                                                                                                     result.close();
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                            public void testGetCurrentStreamWithZeroSizeFile() throws Exception {
                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Create a mock entry with zero size
                                                                                                                                                                                                                                                SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                                when(mockEntry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                                                                                                Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                                archiveField.setAccessible(true);
                                                                                                                                                                                                                                                Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get the files field from archive and set our mock entry
                                                                                                                                                                                                                                                Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                                                filesField.setAccessible(true);
                                                                                                                                                                                                                                                Object[] files = (Object[]) filesField.get(archive);
                                                                                                                                                                                                                                                files[0] = mockEntry;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                                currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                                currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                                ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                                streams.add(new ByteArrayInputStream(new byte[10])); // non-empty stream
                                                                                                                                                                                                                                                deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get the private method via reflection
                                                                                                                                                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test
                                                                                                                                                                                                                                                InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                                                assertEquals(0, result.available()); // Should be empty stream
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Cleanup
                                                                                                                                                                                                                                                result.close();
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                       public void testGetCurrentStreamWithNegativeFileSize() throws Exception {
                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to get archive field and create mock objects
                                                                                                                                                                                                                                           Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                           archiveField.setAccessible(true);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create mock archive object using Mockito's generic mock
                                                                                                                                                                                                                                           Object mockArchive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                                                                                                                           Object mockFile = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File"));
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Mock file size behavior
                                                                                                                                                                                                                                           when(mockFile.getClass().getMethod("getSize").invoke(mockFile)).thenReturn(-1L);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create files array
                                                                                                                                                                                                                                           Object[] files = {mockFile};
                                                                                                                                                                                                                                           when(mockArchive.getClass().getField("files").get(mockArchive)).thenReturn(files);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Set mock archive
                                                                                                                                                                                                                                           archiveField.set(sevenZFile, mockArchive);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Set current entry index
                                                                                                                                                                                                                                           Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                           currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                           currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Get getCurrentStream method via reflection
                                                                                                                                                                                                                                           Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                           getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                           InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify the original behavior (should not be empty stream)
                                                                                                                                                                                                                                           assertFalse("Should not return empty stream for negative size", 
                                                                                                                                                                                                                                                      result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Clean up if needed
                                                                                                                                                                                                                                           if (result != null) {
                                                                                                                                                                                                                                               result.close();
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                       public void testGetCurrentStreamWithZeroFileSize() throws Exception {
                                                                                                                                                                                                                                           // Create a temporary 7z file with a zero-size entry
                                                                                                                                                                                                                                           File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                                           tempFile.deleteOnExit();
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           try (SevenZOutputFile out = new SevenZOutputFile(tempFile)) {
                                                                                                                                                                                                                                               SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                                                                                               entry.setName("empty.txt");
                                                                                                                                                                                                                                               entry.setSize(0);
                                                                                                                                                                                                                                               out.putArchiveEntry(entry);
                                                                                                                                                                                                                                               out.closeArchiveEntry();
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Open the file and set up the test
                                                                                                                                                                                                                                           SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to get the private method
                                                                                                                                                                                                                                           Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                           getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Set currentEntryIndex to 0 using reflection
                                                                                                                                                                                                                                           Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                           currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                           currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Invoke the method
                                                                                                                                                                                                                                           InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify behavior
                                                                                                                                                                                                                                           assertTrue("Should return empty stream for zero size", 
                                                                                                                                                                                                                                                     result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                           assertEquals(0, result.available());
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Clean up
                                                                                                                                                                                                                                           result.close();
                                                                                                                                                                                                                                           sevenZFile.close();
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                  public void testGetCurrentStreamWithZeroSizeFile1() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to create and setup archive
                                                                                                                                                                                                                                      Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                                                      Object archive = mock(archiveClass);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                      when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Create files array through reflection
                                                                                                                                                                                                                                      Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$File");
                                                                                                                                                                                                                                      Object[] files = (Object[]) Array.newInstance(fileClass, 1);
                                                                                                                                                                                                                                      Object file = fileClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                                                      Method setEntryMethod = fileClass.getMethod("setEntry", SevenZArchiveEntry.class);
                                                                                                                                                                                                                                      setEntryMethod.invoke(file, entry);
                                                                                                                                                                                                                                      files[0] = file;
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      when(archive.getClass().getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                                                                      Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                                      archiveField.setAccessible(true);
                                                                                                                                                                                                                                      archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                      currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                      currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                      deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Test - use reflection to call private method
                                                                                                                                                                                                                                      Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                      getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                      InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                                      assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                                      assertEquals(0, result.available());
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Cleanup
                                                                                                                                                                                                                                      result.close();
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                  public void testGetCurrentStreamWithOneSizeFile() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Mock entry
                                                                                                                                                                                                                                      SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                                      when(entry.getSize()).thenReturn(1L);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                                                                                      Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                      currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                      currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Prepare deferred block streams
                                                                                                                                                                                                                                      ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                                                                                                                                                                                      InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                      deferredBlockStreams.add(mockStream);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                      deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                      deferredBlockStreamsField.set(sevenZFile, deferredBlockStreams);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Get the private method via reflection
                                                                                                                                                                                                                                      Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                      getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                      InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                      assertSame(mockStream, result);
                                                                                                                                                                                                                                      // In mutant version, this would return an empty ByteArrayInputStream instead
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                             public void testGetCurrentStream_NonZeroSizeFile_ShouldNotReturnEmptyStream() throws Exception {
                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Create a real entry with non-zero size
                                                                                                                                                                                                                                 SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                                                                                 entry.setSize(100L); // Non-zero size
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Set private fields using reflection
                                                                                                                                                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                                 currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Setup deferredBlockStreams with a mock stream
                                                                                                                                                                                                                                 InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                                                                                 ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                                                                 streams.add(mockStream);
                                                                                                                                                                                                                                 Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                                 deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                                 deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Get the private method via reflection
                                                                                                                                                                                                                                 Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                                 getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                 InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                 assertNotEquals("Should not return empty stream for non-zero size file", 
                                                                                                                                                                                                                                                ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                                                                 assertSame("Should return the first deferred stream", mockStream, result);
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                        public void testGetCurrentStreamWithZeroSizeFile2() throws Exception {
                                                                                                                                                                                                                            // Create a temporary empty 7z file
                                                                                                                                                                                                                            File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                                                            tempFile.deleteOnExit();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create SevenZFile instance
                                                                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to set currentEntryIndex to 0
                                                                                                                                                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to set deferredBlockStreams to empty list
                                                                                                                                                                                                                            Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                            deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                            deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access the private getCurrentStream method
                                                                                                                                                                                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                            InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Verify the result is an empty ByteArrayInputStream
                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                            assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                                                                                                                            assertEquals(0, result.available());
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Clean up
                                                                                                                                                                                                                            result.close();
                                                                                                                                                                                                                            sevenZFile.close();
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                   public void testGetCurrentStream_EmptyEntry_ReturnsEmptyStream() throws Exception {
                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Create a mock entry with size 0
                                                                                                                                                                                                                       SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                                       when(mockEntry.getSize()).thenReturn(0L);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                                                                       Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Set files array in archive
                                                                                                                                                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                                                       filesField.setAccessible(true);
                                                                                                                                                                                                                       SevenZArchiveEntry[] entries = {mockEntry};
                                                                                                                                                                                                                       filesField.set(archive, entries);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                       currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                       deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                                       deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Test - use reflection to call private method
                                                                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                       InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                       assertEquals(0, result.available());
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Cleanup
                                                                                                                                                                                                                       result.close();
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                              public void testGetCurrentStream_EmptyFile_ShouldReturnEmptyStream() throws Exception {
                                                                                                                                                                                                                  // Create a temporary empty 7z file
                                                                                                                                                                                                                  File emptyFile = File.createTempFile("empty", ".7z");
                                                                                                                                                                                                                  emptyFile.deleteOnExit();
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create SevenZFile instance
                                                                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(emptyFile);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set currentEntryIndex to 0
                                                                                                                                                                                                                  Field entryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                                  entryIndexField.setAccessible(true);
                                                                                                                                                                                                                  entryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Also ensure deferredBlockStreams is initialized
                                                                                                                                                                                                                  Field streamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                                  streamsField.setAccessible(true);
                                                                                                                                                                                                                  streamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get the private getCurrentStream method via reflection
                                                                                                                                                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertNotNull("Should not return null for empty file", result);
                                                                                                                                                                                                                  assertEquals("Should return ByteArrayInputStream for empty file", 
                                                                                                                                                                                                                      ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify it's truly empty
                                                                                                                                                                                                                  assertEquals(-1, result.read());
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Clean up
                                                                                                                                                                                                                  result.close();
                                                                                                                                                                                                                  sevenZFile.close();
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                     public void testGetCurrentStreamWithZeroSizeFile3() throws Exception {
                                                                                                                                                                                                         // Setup - create a zero-size file entry
                                                                                                                                                                                                         SevenZArchiveEntry[] files = new SevenZArchiveEntry[1];
                                                                                                                                                                                                         SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                                         when(entry.getSize()).thenReturn(0L);
                                                                                                                                                                                                         files[0] = entry;
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create mock SevenZFile
                                                                                                                                                                                                         SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to set the private archive field
                                                                                                                                                                                                         Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                         archiveField.setAccessible(true);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create mock Archive through reflection since it's package-private
                                                                                                                                                                                                         Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                         Object archive = mock(archiveClass);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Set up archive mock behavior
                                                                                                                                                                                                         Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                                         filesField.setAccessible(true);
                                                                                                                                                                                                         filesField.set(archive, files);
                                                                                                                                                                                                         
                                                                                                                                                                                                         archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Set up deferredBlockStreams to be empty
                                                                                                                                                                                                         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                         deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                                         deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Get the private getCurrentStream method via reflection
                                                                                                                                                                                                         Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                         getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Test and verify
                                                                                                                                                                                                         InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                         assertNotNull("Should return a stream", result);
                                                                                                                                                                                                         assertEquals("Should return empty ByteArrayInputStream", 
                                                                                                                                                                                                             ByteArrayInputStream.class, result.getClass());
                                                                                                                                                                                                         assertEquals("Stream should be empty", -1, result.read());
                                                                                                                                                                                                     }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                public void testGetCurrentStreamWithEmptyDeferredStreamsShouldThrow() throws Exception {
                                                                                                                                                                                                    // Setup test with empty deferredBlockStreams
                                                                                                                                                                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Use reflection to access private field since we need to test internal state
                                                                                                                                                                                                    Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                    deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                    ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                    deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set currentEntryIndex to a non-zero size entry
                                                                                                                                                                                                    Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                    currentEntryField.setAccessible(true);
                                                                                                                                                                                                    currentEntryField.set(sevenZFile, 0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Get the private getCurrentStream method
                                                                                                                                                                                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                    getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Invoke the method which should throw IllegalStateException
                                                                                                                                                                                                    getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testGetCurrentStreamWithNonEmptyDeferredStreamsShouldNotThrow() throws Exception {
                                                                                                                                                                                                    // Setup test with non-empty deferredBlockStreams
                                                                                                                                                                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Use reflection to access private field
                                                                                                                                                                                                    Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                                    deferredStreamsField.setAccessible(true);
                                                                                                                                                                                                    ArrayList<InputStream> deferredStreams = new ArrayList<>();
                                                                                                                                                                                                    deferredStreams.add(new ByteArrayInputStream(new byte[10])); // Add a stream
                                                                                                                                                                                                    deferredStreamsField.set(sevenZFile, deferredStreams);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set currentEntryIndex to a non-zero size entry
                                                                                                                                                                                                    Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                                    currentEntryField.setAccessible(true);
                                                                                                                                                                                                    currentEntryField.set(sevenZFile, 0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create archive and entry through reflection
                                                                                                                                                                                                    Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                                    Object archive = archiveClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                    Class<?> entryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$Entry");
                                                                                                                                                                                                    Object entry = entryClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set size for entry
                                                                                                                                                                                                    Method setSizeMethod = entryClass.getDeclaredMethod("setSize", long.class);
                                                                                                                                                                                                    setSizeMethod.setAccessible(true);
                                                                                                                                                                                                    setSizeMethod.invoke(entry, 1L); // Non-zero size
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set files in archive
                                                                                                                                                                                                    Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                                    filesField.setAccessible(true);
                                                                                                                                                                                                    filesField.set(archive, Array.newInstance(entryClass, 1));
                                                                                                                                                                                                    Array.set(filesField.get(archive), 0, entry);
                                                                                                                                                                                                    
                                                                                                                                                                                                    Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                                    archiveField.setAccessible(true);
                                                                                                                                                                                                    archiveField.set(sevenZFile, archive);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Get private method via reflection
                                                                                                                                                                                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                                    getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // This should proceed normally in original, but would throw in mutant
                                                                                                                                                                                                    InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                                }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                           public void testGetCurrentStream_EmptyDeferredBlockStreams_ShouldThrowException() throws Exception {
                                                                                                                                                                                               // Setup
                                                                                                                                                                                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                               
                                                                                                                                                                                               // Use reflection to access private field since we can't set it directly
                                                                                                                                                                                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                               deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                               
                                                                                                                                                                                               // Set deferredBlockStreams to empty list (not null)
                                                                                                                                                                                               deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                                               
                                                                                                                                                                                               // Set currentEntryIndex to point to a non-zero size entry
                                                                                                                                                                                               Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                               currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                               currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                               
                                                                                                                                                                                               // Create a simple archive structure using reflection
                                                                                                                                                                                               Object archive = new Object();
                                                                                                                                                                                               Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                               filesField.setAccessible(true);
                                                                                                                                                                                               
                                                                                                                                                                                               Object[] files = new Object[1];
                                                                                                                                                                                               Object file = new Object();
                                                                                                                                                                                               Field sizeField = file.getClass().getDeclaredField("size");
                                                                                                                                                                                               sizeField.setAccessible(true);
                                                                                                                                                                                               sizeField.set(file, 1L); // Non-zero size
                                                                                                                                                                                               
                                                                                                                                                                                               files[0] = file;
                                                                                                                                                                                               filesField.set(archive, files);
                                                                                                                                                                                               
                                                                                                                                                                                               Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                               archiveField.setAccessible(true);
                                                                                                                                                                                               archiveField.set(sevenZFile, archive);
                                                                                                                                                                                               
                                                                                                                                                                                               // Get the private method via reflection
                                                                                                                                                                                               Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                               getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                               
                                                                                                                                                                                               // This should throw IllegalStateException
                                                                                                                                                                                               getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                      public void testGetCurrentStreamWithNonEmptyStreamsShouldNotThrowException() throws Exception {
                                                                                                                                                                                          // Setup
                                                                                                                                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to access private fields since we need to set test conditions
                                                                                                                                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create non-empty deferredBlockStreams
                                                                                                                                                                                          ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                                                                                          streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3}));
                                                                                                                                                                                          deferredBlockStreamsField.set(sevenZFile, streams);
                                                                                                                                                                                          
                                                                                                                                                                                          // Set currentEntryIndex to point to a non-zero size entry
                                                                                                                                                                                          Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                          archiveField.setAccessible(true);
                                                                                                                                                                                          Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                          
                                                                                                                                                                                          // Get the files array from archive using reflection
                                                                                                                                                                                          Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                                                                          filesField.setAccessible(true);
                                                                                                                                                                                          Object[] entries = (Object[]) filesField.get(archive);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock the entry size
                                                                                                                                                                                          Object entry = entries[0];
                                                                                                                                                                                          Method getSizeMethod = entry.getClass().getDeclaredMethod("getSize");
                                                                                                                                                                                          getSizeMethod.setAccessible(true);
                                                                                                                                                                                          when(getSizeMethod.invoke(entry)).thenReturn(1L); // Non-zero size
                                                                                                                                                                                          
                                                                                                                                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                          currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                                          
                                                                                                                                                                                          // Test - should not throw exception with original code
                                                                                                                                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                                          assertNotNull(result);
                                                                                                                                                                                          
                                                                                                                                                                                          // Cleanup
                                                                                                                                                                                          result.close();
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                             public void testGetCurrentStreamThrowsExceptionWhenEmpty() throws Exception {
                                                                                                                                                                                 // Setup ExpectedException rule
                                                                                                                                                                                 ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                 
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                                                                 when(entry.getSize()).thenReturn(1L); // Non-zero size
                                                                                                                                                                                 
                                                                                                                                                                                 // Create real SevenZFile instance instead of mocking
                                                                                                                                                                                 File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                                                 tempFile.deleteOnExit();
                                                                                                                                                                                 SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                 Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                                 currentEntryIndexField.setAccessible(true);
                                                                                                                                                                                 currentEntryIndexField.set(sevenZFile, -1); // Set to -1 to indicate no current entry
                                                                                                                                                                                 
                                                                                                                                                                                 Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                                 archiveField.setAccessible(true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Create minimal archive structure
                                                                                                                                                                                 Object archive = archiveField.get(sevenZFile);
                                                                                                                                                                                 if (archive == null) {
                                                                                                                                                                                     // If archive is null, create a basic one
                                                                                                                                                                                     Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                                     archive = archiveClass.newInstance();
                                                                                                                                                                                     Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                                     filesField.setAccessible(true);
                                                                                                                                                                                     filesField.set(archive, new SevenZArchiveEntry[]{entry});
                                                                                                                                                                                     archiveField.set(sevenZFile, archive);
                                                                                                                                                                                 }
                                                                                                                                                                                 
                                                                                                                                                                                 // Expect IllegalStateException with specific message
                                                                                                                                                                                 exception.expect(IllegalStateException.class);
                                                                                                                                                                                 exception.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                                                                 
                                                                                                                                                                                 // Test
                                                                                                                                                                                 Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                                 getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                                 getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                             }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                        public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set currentEntryIndex to 0
                                                                                                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Ensure deferredBlockStreams is empty
                                                                                                                                                                            Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                            deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                                                                            ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                                                                                                            deferredBlockStreamsField.set(sevenZFile, emptyList);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to call private getCurrentStream method
                                                                                                                                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                            getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                   public void testGetCurrentStream_ThrowsExceptionWhenNoEntry() throws Exception {
                                                                                                                                                                       // Setup
                                                                                                                                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                                                       
                                                                                                                                                                       // Create a real SevenZArchiveEntry with size > 0
                                                                                                                                                                       SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                                                                       entry.setSize(1L);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set private fields since we need to test error case
                                                                                                                                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                                                       archiveField.setAccessible(true);
                                                                                                                                                                       
                                                                                                                                                                       // Create a mock archive object using reflection since Archive class is not public
                                                                                                                                                                       Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                                                                                                                                       Object archive = archiveClass.getDeclaredConstructor().newInstance();
                                                                                                                                                                       
                                                                                                                                                                       // Set the files field in archive
                                                                                                                                                                       Field filesField = archiveClass.getDeclaredField("files");
                                                                                                                                                                       filesField.setAccessible(true);
                                                                                                                                                                       SevenZArchiveEntry[] entries = {entry};
                                                                                                                                                                       filesField.set(archive, entries);
                                                                                                                                                                       
                                                                                                                                                                       archiveField.set(sevenZFile, archive);
                                                                                                                                                                       
                                                                                                                                                                       Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                       currentEntryField.set(sevenZFile, 0);
                                                                                                                                                                       
                                                                                                                                                                       Field streamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                       streamsField.setAccessible(true);
                                                                                                                                                                       ArrayList<InputStream> emptyStreams = new ArrayList<>();
                                                                                                                                                                       streamsField.set(sevenZFile, emptyStreams);
                                                                                                                                                                       
                                                                                                                                                                       // Get the private method via reflection
                                                                                                                                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                       getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                       
                                                                                                                                                                       try {
                                                                                                                                                                           // Invoke the private method
                                                                                                                                                                           getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                                           fail("Expected IllegalStateException but no exception was thrown");
                                                                                                                                                                       } catch (InvocationTargetException e) {
                                                                                                                                                                           // Check if the cause is IllegalStateException
                                                                                                                                                                           if (!(e.getCause() instanceof IllegalStateException)) {
                                                                                                                                                                               fail("Expected IllegalStateException but got " + e.getCause().getClass().getName());
                                                                                                                                                                           }
                                                                                                                                                                       }
                                                                                                                                                                   }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                              public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry1() throws Exception {
                                                                                                                                                                  // Arrange
                                                                                                                                                                  File mockFile = mock(File.class);
                                                                                                                                                                  when(mockFile.getAbsolutePath()).thenReturn("test.7z");
                                                                                                                                                                  
                                                                                                                                                                  // Create SevenZFile with empty deferredBlockStreams
                                                                                                                                                                  SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                  Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                                                  
                                                                                                                                                                  Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                                                  deferredBlockStreamsField.setAccessible(true);
                                                                                                                                                                  deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to call private getCurrentStream method
                                                                                                                                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                                  
                                                                                                                                                                  // Act & Assert (should throw IllegalStateException)
                                                                                                                                                                  getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                              }

    @Test
                                                                                                                                                 public void testGetCurrentStreamThrowsCorrectExceptionMessage() throws IOException {
                                                                                                                                                     // Create a temporary 7z file for testing
                                                                                                                                                     File tempFile = File.createTempFile("test", ".7z");
                                                                                                                                                     tempFile.deleteOnExit();
                                                                                                                                                     
                                                                                                                                                     SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                                                     try {
                                                                                                                                                         try {
                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                             Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                                             getCurrentStreamMethod.setAccessible(true);
                                                                                                                                                             getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                                             fail("Expected IllegalStateException to be thrown");
                                                                                                                                                         } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                                                                                             fail("Reflection failed: " + e.getMessage());
                                                                                                                                                         } catch (InvocationTargetException e) {
                                                                                                                                                             Throwable cause = e.getCause();
                                                                                                                                                             if (cause instanceof IllegalStateException) {
                                                                                                                                                                 assertEquals("No current 7z entry (call getNextEntry() first.", cause.getMessage());
                                                                                                                                                                 throw (IllegalStateException) cause;
                                                                                                                                                             }
                                                                                                                                                             fail("Expected IllegalStateException but got " + cause.getClass().getName());
                                                                                                                                                         }
                                                                                                                                                     } finally {
                                                                                                                                                         sevenZFile.close();
                                                                                                                                                     }
                                                                                                                                                 }

    @Test
                                                                                                                                        public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry2() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                                            
                                                                                                                                            // Use reflection to set private fields
                                                                                                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                            archiveField.setAccessible(true);
                                                                                                                                            // Create mock Archive instance via reflection
                                                                                                                                            Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.SevenZFile$Archive");
                                                                                                                                            Object archive = mock(archiveClass);
                                                                                                                                            archiveField.set(sevenZFile, archive);
                                                                                                                                            
                                                                                                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                            currentEntryIndexField.setAccessible(true);
                                                                                                                                            currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                                            
                                                                                                                                            Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                            deferredBlockStreamsField.setAccessible(true);
                                                                                                                                            deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                                                                                                                            
                                                                                                                                            // Mock Archive.File
                                                                                                                                            Class<?> fileClass = Class.forName("org.apache.commons.compress.archivers.sevenz.SevenZFile$Archive$File");
                                                                                                                                            Object file = mock(fileClass);
                                                                                                                                            when(fileClass.getMethod("getSize").invoke(file)).thenReturn(1L);
                                                                                                                                            
                                                                                                                                            // Set up files array
                                                                                                                                            Object[] files = new Object[]{file};
                                                                                                                                            when(archiveClass.getMethod("getFiles").invoke(archive)).thenReturn(files);
                                                                                                                                            
                                                                                                                                            // Get the private method
                                                                                                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                            getCurrentStreamMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Expect IllegalStateException specifically
                                                                                                                                            thrown.expect(IllegalStateException.class);
                                                                                                                                            thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                                                                            
                                                                                                                                            // Test
                                                                                                                                            getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                        }

    @Test
                                                                                                                               public void testGetCurrentStreamWithZeroSizeFile4() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                   SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                   when(entry.getSize()).thenReturn(0L);
                                                                                                                                   
                                                                                                                                   // Set currentEntryIndex to 0 using reflection
                                                                                                                                   Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                   currentEntryField.setAccessible(true);
                                                                                                                                   currentEntryField.set(sevenZFile, 0);
                                                                                                                                   
                                                                                                                                   // Mock getNextEntry to return our mock entry
                                                                                                                                   when(sevenZFile.getNextEntry()).thenReturn(entry);
                                                                                                                                   
                                                                                                                                   // Get the private getCurrentStream method via reflection
                                                                                                                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                   getCurrentStreamMethod.setAccessible(true);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertNotNull(result);
                                                                                                                                   assertEquals(0, result.available());
                                                                                                                                   assertTrue(result instanceof ByteArrayInputStream);
                                                                                                                               }

    @Test
                                                                                                                               public void testGetCurrentStreamWithNegativeSizeFile() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   SevenZFile sevenZFile = mock(SevenZFile.class);
                                                                                                                                   
                                                                                                                                   // Use reflection to set up archive field
                                                                                                                                   Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                                                                   archiveField.setAccessible(true);
                                                                                                                                   Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                                                                                                   archiveField.set(sevenZFile, archive);
                                                                                                                                   
                                                                                                                                   SevenZArchiveEntry[] files = new SevenZArchiveEntry[1];
                                                                                                                                   SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                                                                                   when(entry.getSize()).thenReturn(-1L);  // Negative size
                                                                                                                                   files[0] = entry;
                                                                                                                                   
                                                                                                                                   Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                                                   filesField.setAccessible(true);
                                                                                                                                   filesField.set(archive, files);
                                                                                                                                   
                                                                                                                                   // Set currentEntryIndex to 0
                                                                                                                                   Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                                   currentEntryField.setAccessible(true);
                                                                                                                                   currentEntryField.set(sevenZFile, 0);
                                                                                                                                   
                                                                                                                                   // Add a dummy stream to deferredBlockStreams
                                                                                                                                   Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                                   deferredStreamsField.setAccessible(true);
                                                                                                                                   List<InputStream> deferredBlockStreams = new ArrayList<>();
                                                                                                                                   InputStream dummyStream = mock(InputStream.class);
                                                                                                                                   deferredBlockStreams.add(dummyStream);
                                                                                                                                   deferredStreamsField.set(sevenZFile, deferredBlockStreams);
                                                                                                                                   
                                                                                                                                   // Test - use reflection to call private method
                                                                                                                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                                   getCurrentStreamMethod.setAccessible(true);
                                                                                                                                   InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   // Original code (== 0) would return the dummyStream
                                                                                                                                   // Mutated code (< 1) would return empty ByteArrayInputStream
                                                                                                                                   assertSame(dummyStream, result);  // This will fail if mutant is present
                                                                                                                               }

    @Test
                                                                                                                          public void testGetCurrentStreamDetectsSizeCheckMutant() throws Exception {
                                                                                                                              // Setup test objects
                                                                                                                              SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                              
                                                                                                                              // Create a real entry with non-zero size
                                                                                                                              SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                                                                              entry.setSize(100L); // Non-zero size
                                                                                                                              
                                                                                                                              // Use reflection to set private fields
                                                                                                                              Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                              currentEntryIndexField.setAccessible(true);
                                                                                                                              currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                              
                                                                                                                              // Set deferredBlockStreams to have one stream (not empty)
                                                                                                                              ArrayList<InputStream> streams = new ArrayList<>();
                                                                                                                              InputStream mockStream = mock(InputStream.class);
                                                                                                                              streams.add(mockStream);
                                                                                                                              
                                                                                                                              Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                              deferredStreamsField.setAccessible(true);
                                                                                                                              deferredStreamsField.set(sevenZFile, streams);
                                                                                                                              
                                                                                                                              // Get the private getCurrentStream method
                                                                                                                              Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                              getCurrentStreamMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // Test the method
                                                                                                                              InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                              
                                                                                                                              // Verify behavior - should NOT return empty stream for non-zero size file
                                                                                                                              assertFalse("Should not return empty stream for non-zero size file", 
                                                                                                                                         result instanceof ByteArrayInputStream && ((ByteArrayInputStream)result).available() == 0);
                                                                                                                              
                                                                                                                              // Verify we got the expected stream
                                                                                                                              assertEquals(mockStream, result);
                                                                                                                          }

    @Test(expected = IllegalStateException.class)
                                                                                                                     public void testGetCurrentStreamThrowsWhenEmpty() throws Exception {
                                                                                                                         // Setup test data
                                                                                                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                                                         
                                                                                                                         // Use reflection to access private fields since we need to set up test state
                                                                                                                         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                         deferredBlockStreamsField.setAccessible(true);
                                                                                                                         
                                                                                                                         // Create empty streams list to trigger the condition
                                                                                                                         ArrayList<InputStream> emptyStreams = new ArrayList<>();
                                                                                                                         deferredBlockStreamsField.set(sevenZFile, emptyStreams);
                                                                                                                         
                                                                                                                         // Set currentEntryIndex to a non-zero size entry
                                                                                                                         Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                                                         currentEntryIndexField.setAccessible(true);
                                                                                                                         currentEntryIndexField.set(sevenZFile, 0);
                                                                                                                         
                                                                                                                         // Get the private getCurrentStream method
                                                                                                                         Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                         getCurrentStreamMethod.setAccessible(true);
                                                                                                                         
                                                                                                                         // This should throw IllegalStateException
                                                                                                                         getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                     }

    @Test
                                                                                                            public void testGetCurrentStreamWithEmptyDeferredBlockStreams() throws Exception {
                                                                                                                // Create a temporary file for SevenZFile constructor
                                                                                                                File tempFile = File.createTempFile("test", ".7z");
                                                                                                                tempFile.deleteOnExit();
                                                                                                                
                                                                                                                // Create SevenZFile instance
                                                                                                                SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                
                                                                                                                try {
                                                                                                                    // Use reflection to access private field
                                                                                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                    deferredBlockStreamsField.setAccessible(true);
                                                                                                                    
                                                                                                                    // Set up empty but initialized deferredBlockStreams
                                                                                                                    deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                                    
                                                                                                                    // Get the private method using reflection
                                                                                                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                    getCurrentStreamMethod.setAccessible(true);
                                                                                                                    
                                                                                                                    // This should throw IllegalStateException
                                                                                                                    try {
                                                                                                                        getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                                        fail("Expected IllegalStateException");
                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                        assertTrue(e.getCause() instanceof IllegalStateException);
                                                                                                                    }
                                                                                                                } finally {
                                                                                                                    sevenZFile.close();
                                                                                                                    tempFile.delete();
                                                                                                                }
                                                                                                            }

    @Test(expected = NullPointerException.class)
                                                                                                            public void testGetCurrentStreamWithNullDeferredBlockStreams() throws Exception {
                                                                                                                // Create a temporary file for testing
                                                                                                                File tempFile = File.createTempFile("test", ".7z");
                                                                                                                tempFile.deleteOnExit();
                                                                                                                
                                                                                                                // Create SevenZFile instance
                                                                                                                SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                                                                
                                                                                                                // Use reflection to set deferredBlockStreams to null
                                                                                                                Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                                                deferredBlockStreamsField.setAccessible(true);
                                                                                                                deferredBlockStreamsField.set(sevenZFile, null);
                                                                                                                
                                                                                                                // Use reflection to access private getCurrentStream method
                                                                                                                Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                                                getCurrentStreamMethod.setAccessible(true);
                                                                                                                
                                                                                                                // This should throw NPE
                                                                                                                getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                            }

    @Test(expected = IllegalStateException.class)
                                                                                                   public void testGetCurrentStreamWithEmptyDeferredStreamsShouldThrowException() throws Exception {
                                                                                                       // Setup - create a mock entry with non-zero size
                                                                                                       SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                                                                       when(mockEntry.getSize()).thenReturn(1L); // Non-zero size
                                                                                                       SevenZArchiveEntry[] entries = {mockEntry};
                                                                                                       
                                                                                                       // Create mock file for SevenZFile constructor
                                                                                                       File mockFile = mock(File.class);
                                                                                                       SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                                                       
                                                                                                       // Mock archive and set it via reflection
                                                                                                       Object archive = mock(sevenZFile.getClass().getDeclaredField("archive").getType());
                                                                                                       Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                       filesField.setAccessible(true);
                                                                                                       filesField.set(archive, entries);
                                                                                                       
                                                                                                       Field archiveField = sevenZFile.getClass().getDeclaredField("archive");
                                                                                                       archiveField.setAccessible(true);
                                                                                                       archiveField.set(sevenZFile, archive);
                                                                                                       
                                                                                                       // Set currentEntryIndex via reflection
                                                                                                       Field indexField = sevenZFile.getClass().getDeclaredField("currentEntryIndex");
                                                                                                       indexField.setAccessible(true);
                                                                                                       indexField.set(sevenZFile, 0);
                                                                                                       
                                                                                                       // Get and invoke the private getCurrentStream method
                                                                                                       Method getCurrentStream = sevenZFile.getClass().getDeclaredMethod("getCurrentStream");
                                                                                                       getCurrentStream.setAccessible(true);
                                                                                                       getCurrentStream.invoke(sevenZFile);
                                                                                                   }

    @Test
                                                                                              public void testGetCurrentStreamThrowsCorrectExceptionWhenEmpty() throws Exception {
                                                                                                  // Setup
                                                                                                  SevenZFile sevenZFile = new SevenZFile(mock(File.class));
                                                                                                  
                                                                                                  // Use reflection to set private fields since we need to test specific state
                                                                                                  // Create mock files array with non-zero size to avoid early return
                                                                                                  Object file = mock(Object.class);
                                                                                                  when(file.getClass().getMethod("getSize").invoke(file)).thenReturn(1L);
                                                                                                  Object[] files = new Object[]{file};
                                                                                                  
                                                                                                  // Set private fields using reflection
                                                                                                  Class<?> sevenZFileClass = sevenZFile.getClass();
                                                                                                  Field archiveField = sevenZFileClass.getDeclaredField("archive");
                                                                                                  archiveField.setAccessible(true);
                                                                                                  Object archive = mock(Object.class);
                                                                                                  archiveField.set(sevenZFile, archive);
                                                                                                  
                                                                                                  Field filesField = archive.getClass().getDeclaredField("files");
                                                                                                  filesField.setAccessible(true);
                                                                                                  filesField.set(archive, files);
                                                                                                  
                                                                                                  Field currentEntryIndexField = sevenZFileClass.getDeclaredField("currentEntryIndex");
                                                                                                  currentEntryIndexField.setAccessible(true);
                                                                                                  currentEntryIndexField.set(sevenZFile, 0);
                                                                                                  
                                                                                                  Field deferredBlockStreamsField = sevenZFileClass.getDeclaredField("deferredBlockStreams");
                                                                                                  deferredBlockStreamsField.setAccessible(true);
                                                                                                  deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                                  
                                                                                                  // Test
                                                                                                  Method getCurrentStreamMethod = sevenZFileClass.getDeclaredMethod("getCurrentStream");
                                                                                                  getCurrentStreamMethod.setAccessible(true);
                                                                                                  
                                                                                                  try {
                                                                                                      getCurrentStreamMethod.invoke(sevenZFile);
                                                                                                      fail("Expected IllegalStateException");
                                                                                                  } catch (InvocationTargetException e) {
                                                                                                      Throwable cause = e.getCause();
                                                                                                      assertEquals(IllegalStateException.class, cause.getClass());
                                                                                                      assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                                                                                                  }
                                                                                              }

    @Test
                                                                                         public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry3() throws Exception {
                                                                                             // Setup test data
                                                                                             SevenZFile sevenZFile = new SevenZFile(new java.io.File("test.7z"));
                                                                                             
                                                                                             // Set private fields using reflection
                                                                                             java.lang.reflect.Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                             currentEntryIndexField.setAccessible(true);
                                                                                             currentEntryIndexField.set(sevenZFile, 0);
                                                                                             
                                                                                             java.lang.reflect.Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                             deferredBlockStreamsField.setAccessible(true);
                                                                                             deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                                             
                                                                                             // Get the private getCurrentStream method
                                                                                             java.lang.reflect.Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                             getCurrentStreamMethod.setAccessible(true);
                                                                                             
                                                                                             // Expect IllegalStateException
                                                                                             thrown.expect(IllegalStateException.class);
                                                                                             thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                                             
                                                                                             // Call method under test via reflection
                                                                                             getCurrentStreamMethod.invoke(sevenZFile);
                                                                                         }

    @Test
                                                                                public void testGetCurrentStreamThrowsCorrectExceptionWhenEmpty1() throws Exception {
                                                                                    // Setup
                                                                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                                    
                                                                                    // Use reflection to access private field since we can't set it directly
                                                                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                                    deferredBlockStreamsField.setAccessible(true);
                                                                                    ArrayList<InputStream> emptyList = new ArrayList<>();
                                                                                    deferredBlockStreamsField.set(sevenZFile, emptyList);
                                                                                    
                                                                                    // Set currentEntryIndex to point to a non-zero size entry
                                                                                    Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                                    currentEntryIndexField.setAccessible(true);
                                                                                    currentEntryIndexField.set(sevenZFile, 0);
                                                                                    
                                                                                    // Get the archive instance and modify its files array through reflection
                                                                                    Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                                    archiveField.setAccessible(true);
                                                                                    Object archive = archiveField.get(sevenZFile);
                                                                                    
                                                                                    // Create and set files array
                                                                                    Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
                                                                                    Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
                                                                                    Object fileEntry = fileEntryClass.getDeclaredConstructor().newInstance();
                                                                                    
                                                                                    // Set size for the file entry
                                                                                    Method setSize = fileEntryClass.getDeclaredMethod("setSize", long.class);
                                                                                    setSize.setAccessible(true);
                                                                                    setSize.invoke(fileEntry, 1L); // Non-zero size
                                                                                    
                                                                                    files[0] = fileEntry;
                                                                                    
                                                                                    // Set files array in archive
                                                                                    Field filesField = archive.getClass().getDeclaredField("files");
                                                                                    filesField.setAccessible(true);
                                                                                    filesField.set(archive, files);
                                                                                    
                                                                                    // Test and verify
                                                                                    try {
                                                                                        Method getCurrentStream = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                                        getCurrentStream.setAccessible(true);
                                                                                        getCurrentStream.invoke(sevenZFile);
                                                                                    } catch (InvocationTargetException e) {
                                                                                        Throwable cause = e.getCause();
                                                                                        assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                                                                                        throw new RuntimeException(cause);
                                                                                    }
                                                                                }

    @Test
                                                                           public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoDeferredStreams() throws Exception {
                                                                               // Create a real SevenZFile instance with a mock file
                                                                               File mockFile = mock(File.class);
                                                                               SevenZFile sevenZFile = new SevenZFile(mockFile);
                                                                               
                                                                               // Use reflection to set private fields
                                                                               Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                                               archiveField.setAccessible(true);
                                                                               
                                                                               Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                               currentEntryIndexField.setAccessible(true);
                                                                               
                                                                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                               deferredBlockStreamsField.setAccessible(true);
                                                                               
                                                                               // Setup test objects
                                                                               SevenZArchiveEntry entry = mock(SevenZArchiveEntry.class);
                                                                               when(entry.getSize()).thenReturn(1L); // Non-zero size
                                                                               
                                                                               // Configure test scenario
                                                                               currentEntryIndexField.set(sevenZFile, 0);
                                                                               deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                                                               archiveField.set(sevenZFile, new Object() {
                                                                                   public SevenZArchiveEntry[] files = new SevenZArchiveEntry[]{entry};
                                                                               });
                                                                               
                                                                               // Get the private method
                                                                               Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                               getCurrentStreamMethod.setAccessible(true);
                                                                               
                                                                               // Expect specific exception
                                                                               thrown.expect(IllegalStateException.class);
                                                                               thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                                                               
                                                                               // Execute test
                                                                               getCurrentStreamMethod.invoke(sevenZFile);
                                                                           }

    @Test
                                                                      public void testGetCurrentStreamWithNegativeFileSize1() throws Exception {
                                                                          // Setup
                                                                          SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                                          
                                                                          // Use reflection to set private fields since we need to test edge cases
                                                                          // Create a mock entry with negative size
                                                                          SevenZArchiveEntry mockEntry = new SevenZArchiveEntry();
                                                                          Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
                                                                          sizeField.setAccessible(true);
                                                                          sizeField.set(mockEntry, -1L);
                                                                          
                                                                          // Set current entry index
                                                                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                                          currentEntryIndexField.setAccessible(true);
                                                                          currentEntryIndexField.set(sevenZFile, 0);
                                                                          
                                                                          // Set empty deferred block streams
                                                                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                          deferredBlockStreamsField.setAccessible(true);
                                                                          deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                                          
                                                                          // Set entries list
                                                                          Field entriesField = SevenZFile.class.getDeclaredField("entries");
                                                                          entriesField.setAccessible(true);
                                                                          entriesField.set(sevenZFile, new SevenZArchiveEntry[]{mockEntry});
                                                                          
                                                                          // Get the private getCurrentStream method
                                                                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                          getCurrentStreamMethod.setAccessible(true);
                                                                          
                                                                          // Test
                                                                          InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                          
                                                                          // Verify
                                                                          assertNotNull(result);
                                                                          assertEquals(0, result.available()); // Should be empty stream
                                                                          
                                                                          // Clean up
                                                                          result.close();
                                                                      }

    @Test
                                                                 public void testGetCurrentStreamDetectsSizeCheckMutant1() throws Exception {
                                                                     // Setup test objects - create a real 7z file with one entry
                                                                     File tempFile = File.createTempFile("test", ".7z");
                                                                     tempFile.deleteOnExit();
                                                                     try (SevenZOutputFile out = new SevenZOutputFile(tempFile)) {
                                                                         SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                                                         entry.setName("test.txt");
                                                                         entry.setSize(100L);
                                                                         out.putArchiveEntry(entry);
                                                                         out.write(new byte[100]);
                                                                         out.closeArchiveEntry();
                                                                     }
                                                                     
                                                                     SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                                     sevenZFile.getNextEntry(); // Move to first entry
                                                                     
                                                                     // Set up deferredBlockStreams with one stream
                                                                     ArrayList<InputStream> streams = new ArrayList<>();
                                                                     InputStream mockStream = mock(InputStream.class);
                                                                     when(mockStream.available()).thenReturn(100);
                                                                     streams.add(mockStream);
                                                                     
                                                                     // Use reflection to set private field for testing
                                                                     Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                                     deferredBlockStreamsField.setAccessible(true);
                                                                     deferredBlockStreamsField.set(sevenZFile, streams);
                                                                     
                                                                     // Use reflection to access private method
                                                                     Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                                     getCurrentStreamMethod.setAccessible(true);
                                                                     InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                                     
                                                                     // Verify behavior
                                                                     assertNotEquals("Should not return empty stream for non-zero size file", 
                                                                                    0, result.available());
                                                                     assertSame("Should return the expected stream", mockStream, result);
                                                                 }

    @Test(expected = IllegalStateException.class)
                                                        public void testGetCurrentStream_ShouldThrowWhenEmpty() throws Exception {
                                                            // Setup mock objects
                                                            SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                            when(mockEntry.getSize()).thenReturn(1L); // Non-zero size
                                                            
                                                            // Create SevenZFile instance with empty file
                                                            File tempFile = File.createTempFile("test", ".7z");
                                                            tempFile.deleteOnExit();
                                                            SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                            
                                                            // Use reflection to inject mock entry into archive
                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                            archiveField.setAccessible(true);
                                                            Object archive = archiveField.get(sevenZFile);
                                                            
                                                            Field filesField = archive.getClass().getDeclaredField("files");
                                                            filesField.setAccessible(true);
                                                            filesField.set(archive, new SevenZArchiveEntry[]{mockEntry});
                                                            
                                                            // Use reflection to access private getCurrentStream method
                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                            getCurrentStreamMethod.setAccessible(true);
                                                            
                                                            // This should throw IllegalStateException
                                                            getCurrentStreamMethod.invoke(sevenZFile);
                                                        }

    @Test
                                                        public void testGetCurrentStream_ShouldNotThrowWhenNotEmpty() throws Exception {
                                                            // Setup
                                                            File tempFile = File.createTempFile("test", ".7z");
                                                            tempFile.deleteOnExit();
                                                            SevenZFile sevenZFile = new SevenZFile(tempFile);
                                                            
                                                            // Use reflection to access private deferredBlockStreams field
                                                            Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                            deferredBlockStreamsField.setAccessible(true);
                                                            @SuppressWarnings("unchecked")
                                                            List<InputStream> deferredBlockStreams = (List<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                                                            deferredBlockStreams.add(new ByteArrayInputStream(new byte[10]));
                                                            
                                                            // Mock archive and entry
                                                            SevenZArchiveEntry mockEntry = mock(SevenZArchiveEntry.class);
                                                            when(mockEntry.getSize()).thenReturn(1L); // Non-zero size
                                                            
                                                            // Use reflection to set currentEntryIndex and archive
                                                            Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                            currentEntryIndexField.setAccessible(true);
                                                            currentEntryIndexField.setInt(sevenZFile, 0);
                                                            
                                                            // Create mock archive using reflection since Archive class is not public
                                                            Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
                                                            Object mockArchive = mock(archiveClass);
                                                            Field filesField = archiveClass.getDeclaredField("files");
                                                            filesField.setAccessible(true);
                                                            filesField.set(mockArchive, new SevenZArchiveEntry[]{mockEntry});
                                                            
                                                            Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                            archiveField.setAccessible(true);
                                                            archiveField.set(sevenZFile, mockArchive);
                                                            
                                                            // Test - use reflection to call private getCurrentStream method
                                                            Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                            getCurrentStreamMethod.setAccessible(true);
                                                            InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                            assertNotNull(result);
                                                            
                                                            // Cleanup
                                                            sevenZFile.close();
                                                        }

    @Test(expected = IllegalStateException.class)
                                                   public void testGetCurrentStream_EmptyDeferredBlockStreams_ShouldThrowException1() throws Exception {
                                                       // Setup
                                                       SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                       
                                                       // Use reflection to access private fields since we need to test internal behavior
                                                       Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                       archiveField.setAccessible(true);
                                                       Object archive = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.Archive"));
                                                       archiveField.set(sevenZFile, archive);
                                                       
                                                       Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                       currentEntryIndexField.setAccessible(true);
                                                       currentEntryIndexField.set(sevenZFile, 0);
                                                       
                                                       // Create a non-zero size entry
                                                       Object entry = mock(Class.forName("org.apache.commons.compress.archivers.sevenz.ArchiveEntry"));
                                                       when(entry.getClass().getMethod("getSize").invoke(entry)).thenReturn(1L);
                                                       Object[] entries = new Object[]{entry};
                                                       when(archive.getClass().getField("files").get(archive)).thenReturn(entries);
                                                       
                                                       // Set deferredBlockStreams to empty list (not null)
                                                       Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                       deferredBlockStreamsField.setAccessible(true);
                                                       deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>());
                                                       
                                                       // Use reflection to call private method
                                                       Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                       getCurrentStreamMethod.setAccessible(true);
                                                       getCurrentStreamMethod.invoke(sevenZFile);
                                                       
                                                       // If we reach here, the test fails (mutant survives)
                                                   }

    @Test
                                              public void testGetCurrentStreamWithNonEmptyDeferredStreams() throws Exception {
                                                  // Setup
                                                  SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                                  
                                                  // Use reflection to access private fields since we need to set up test state
                                                  Field deferredStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                                  deferredStreamsField.setAccessible(true);
                                                  
                                                  // Create a non-empty deferredBlockStreams
                                                  ArrayList<InputStream> streams = new ArrayList<>();
                                                  streams.add(new ByteArrayInputStream(new byte[]{1, 2, 3})); // Add a dummy stream
                                                  deferredStreamsField.set(sevenZFile, streams);
                                                  
                                                  // Set currentEntryIndex to a non-zero size entry using reflection
                                                  Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                                  archiveField.setAccessible(true);
                                                  Object archive = archiveField.get(sevenZFile);
                                                  
                                                  // Get the files field from archive and set its size
                                                  Field filesField = archive.getClass().getDeclaredField("files");
                                                  filesField.setAccessible(true);
                                                  Object[] entries = (Object[]) filesField.get(archive);
                                                  Object entry = entries[0];
                                                  
                                                  // Mock the getSize() method on the entry
                                                  Method getSizeMethod = entry.getClass().getDeclaredMethod("getSize");
                                                  getSizeMethod.setAccessible(true);
                                                  when(getSizeMethod.invoke(entry)).thenReturn(1L); // Non-zero size
                                                  
                                                  Field currentEntryField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                                  currentEntryField.setAccessible(true);
                                                  currentEntryField.set(sevenZFile, 0);
                                                  
                                                  // Test - should return the stream when deferredBlockStreams is not empty
                                                  Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                                  getCurrentStreamMethod.setAccessible(true);
                                                  InputStream result = (InputStream) getCurrentStreamMethod.invoke(sevenZFile);
                                                  
                                                  assertNotNull(result);
                                                  assertEquals(1, result.read()); // Verify we can read from the stream
                                                  
                                                  // Cleanup
                                                  result.close();
                                              }

    @Test
                                     public void testGetCurrentStreamShouldThrowWhenStreamsEmpty() throws Exception {
                                         // Arrange
                                         SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                         
                                         // Set currentEntryIndex using reflection
                                         Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                         currentEntryIndexField.setAccessible(true);
                                         currentEntryIndexField.set(sevenZFile, 0);
                                         
                                         // Set empty deferredBlockStreams
                                         Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                         deferredBlockStreamsField.setAccessible(true);
                                         deferredBlockStreamsField.set(sevenZFile, new ArrayList<>());
                                         
                                         // Get private getCurrentStream method
                                         Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                         getCurrentStreamMethod.setAccessible(true);
                                         
                                         // Expect IllegalStateException
                                         thrown.expect(IllegalStateException.class);
                                         thrown.expectMessage("No current 7z entry (call getNextEntry() first).");
                                         
                                         // Act
                                         getCurrentStreamMethod.invoke(sevenZFile);
                                     }

    @Test(expected = IllegalStateException.class)
                                public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoEntry4() throws Exception {
                                    // Setup
                                    SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                                    
                                    // Use reflection to set private fields since we need to test internal state
                                    Field archiveField = SevenZFile.class.getDeclaredField("archive");
                                    archiveField.setAccessible(true);
                                    Object archive = new Object(); // We don't need to mock Archive since we'll set fields directly
                                    
                                    // Create a SevenZArchiveEntry with non-zero size
                                    SevenZArchiveEntry entry = new SevenZArchiveEntry();
                                    entry.setSize(1L);
                                    
                                    // Set up files array in archive
                                    Field filesField = archive.getClass().getDeclaredField("files");
                                    filesField.setAccessible(true);
                                    SevenZArchiveEntry[] entries = new SevenZArchiveEntry[]{entry};
                                    filesField.set(archive, entries);
                                    
                                    archiveField.set(sevenZFile, archive);
                                    
                                    Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                                    currentEntryIndexField.setAccessible(true);
                                    currentEntryIndexField.set(sevenZFile, 0);
                                    
                                    // Set deferredBlockStreams to empty
                                    Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                                    deferredBlockStreamsField.setAccessible(true);
                                    @SuppressWarnings("unchecked")
                                    ArrayList<InputStream> emptyList = new ArrayList<>();
                                    deferredBlockStreamsField.set(sevenZFile, emptyList);
                                    
                                    // Get getCurrentStream method via reflection and invoke it
                                    Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                    getCurrentStreamMethod.setAccessible(true);
                                    getCurrentStreamMethod.invoke(sevenZFile);
                                }

    @Test
                           public void testGetCurrentStream_ShouldThrowExceptionWhenNoEntry() throws Exception {
                               // Arrange
                               SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
                               
                               // Use reflection to set private fields to create test condition
                               Field archiveField = SevenZFile.class.getDeclaredField("archive");
                               archiveField.setAccessible(true);
                               Object archive = mock(archiveField.getType());
                               archiveField.set(sevenZFile, archive);
                               
                               Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                               currentEntryIndexField.setAccessible(true);
                               currentEntryIndexField.set(sevenZFile, 0);
                               
                               SevenZArchiveEntry archiveEntry = mock(SevenZArchiveEntry.class);
                               when(archiveEntry.getSize()).thenReturn(1L); // Non-zero size
                               SevenZArchiveEntry[] entries = new SevenZArchiveEntry[]{archiveEntry};
                               
                               Field filesField = archive.getClass().getDeclaredField("files");
                               filesField.setAccessible(true);
                               filesField.set(archive, entries);
                               
                               Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                               deferredBlockStreamsField.setAccessible(true);
                               deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>()); // Empty list
                               
                               // Act & Assert
                               try {
                                   Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                                   getCurrentStreamMethod.setAccessible(true);
                                   getCurrentStreamMethod.invoke(sevenZFile);
                                   fail("Expected IllegalStateException but no exception was thrown");
                               } catch (InvocationTargetException e) {
                                   Throwable cause = e.getCause();
                                   assertTrue(cause instanceof IllegalStateException);
                                   assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                               }
                           }

    @Test(expected = IllegalStateException.class)
                  public void testGetCurrentStreamThrowsCorrectExceptionWhenNoDeferredStreams() throws Exception {
                      // Create a temporary file for SevenZFile constructor
                      File tempFile = File.createTempFile("test", ".7z");
                      try {
                          SevenZFile sevenZFile = new SevenZFile(tempFile);
                          
                          // Set currentEntryIndex to a valid value using reflection
                          Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
                          currentEntryIndexField.setAccessible(true);
                          currentEntryIndexField.setInt(sevenZFile, 0);
                          
                          // Ensure deferredBlockStreams is empty
                          Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
                          deferredBlockStreamsField.setAccessible(true);
                          @SuppressWarnings("unchecked")
                          List<InputStream> deferredBlockStreams = (List<InputStream>) deferredBlockStreamsField.get(sevenZFile);
                          deferredBlockStreams.clear();
                          
                          // Get the private method using reflection
                          Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                          getCurrentStreamMethod.setAccessible(true);
                          
                          // This should throw IllegalStateException
                          getCurrentStreamMethod.invoke(sevenZFile);
                      } finally {
                          tempFile.delete();
                      }
                  }

    @Test
         public void testGetCurrentStreamThrowsCorrectExceptionWhenNoEntry() throws Exception {
             // Setup
             SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
             
             // Use reflection to access private field since we can't set it directly
             Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
             deferredBlockStreamsField.setAccessible(true);
             ArrayList<InputStream> deferredBlockStreams = new ArrayList<>();
             deferredBlockStreamsField.set(sevenZFile, deferredBlockStreams);
             
             // Set currentEntryIndex to a valid value that won't trigger the empty stream case
             Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
             currentEntryIndexField.setAccessible(true);
             currentEntryIndexField.set(sevenZFile, 0);
             
             // Create archive instance via reflection
             Class<?> archiveClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive");
             Object archive = archiveClass.getDeclaredConstructor().newInstance();
             
             // Create files array via reflection
             Class<?> fileEntryClass = Class.forName("org.apache.commons.compress.archivers.sevenz.Archive$FileEntry");
             Object[] files = (Object[]) Array.newInstance(fileEntryClass, 1);
             Object fileEntry = fileEntryClass.getDeclaredConstructor().newInstance();
             
             // Set size for the file entry
             Method setSizeMethod = fileEntryClass.getDeclaredMethod("setSize", long.class);
             setSizeMethod.setAccessible(true);
             setSizeMethod.invoke(fileEntry, 1L); // Non-zero size
             
             files[0] = fileEntry;
             
             // Set files array in archive
             Field filesField = archiveClass.getDeclaredField("files");
             filesField.setAccessible(true);
             filesField.set(archive, files);
             
             // Set archive in SevenZFile
             Field archiveField = SevenZFile.class.getDeclaredField("archive");
             archiveField.setAccessible(true);
             archiveField.set(sevenZFile, archive);
             
             try {
                 // Method under test
                 Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
                 getCurrentStreamMethod.setAccessible(true);
                 getCurrentStreamMethod.invoke(sevenZFile);
                 fail("Expected IllegalStateException");
             } catch (InvocationTargetException e) {
                 // Verify the exception message
                 Throwable cause = e.getCause();
                 assertEquals(IllegalStateException.class, cause.getClass());
                 assertEquals("No current 7z entry (call getNextEntry() first).", cause.getMessage());
                 throw new Exception(cause);
             }
         }

    @Test(expected = IllegalStateException.class)
    public void testGetCurrentStreamThrowsIllegalStateExceptionWhenNoDeferredStreams1() throws Exception {
        // Setup test objects
        SevenZFile sevenZFile = new SevenZFile(new File("test.7z"));
        
        // Use reflection to set private fields since we need to control test conditions
        Field currentEntryIndexField = SevenZFile.class.getDeclaredField("currentEntryIndex");
        currentEntryIndexField.setAccessible(true);
        currentEntryIndexField.set(sevenZFile, 0); // Set to valid index
        
        Field deferredBlockStreamsField = SevenZFile.class.getDeclaredField("deferredBlockStreams");
        deferredBlockStreamsField.setAccessible(true);
        deferredBlockStreamsField.set(sevenZFile, new ArrayList<InputStream>()); // Empty list
        
        // Get the private method via reflection
        Method getCurrentStreamMethod = SevenZFile.class.getDeclaredMethod("getCurrentStream");
        getCurrentStreamMethod.setAccessible(true);
        
        // This should throw IllegalStateException
        getCurrentStreamMethod.invoke(sevenZFile);
    }


}
