package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_NoBytesWritten() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(0, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterWritingSingleByte() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              byte[] data = {1};
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, 1);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(1, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterWritingMultipleBytes() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              byte[] data = {1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, 5);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(5, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterWritingLargeAmountOfData() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              byte[] data = new byte[1024 * 1024]; // 1MB
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(data.length, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterMultipleWrites() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              byte[] data1 = {1, 2, 3};
                                                                                                                                                                                                                                                                                              byte[] data2 = {4, 5};
                                                                                                                                                                                                                                                                                              byte[] data3 = {6, 7, 8, 9};
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.write(data1, 0, data1.length);
                                                                                                                                                                                                                                                                                              tarOut.write(data2, 0, data2.length);
                                                                                                                                                                                                                                                                                              tarOut.write(data3, 0, data3.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(9, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterClosingStream() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              byte[] data = {1, 2, 3};
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(3, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterFinishingStream() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              byte[] data = {1, 2, 3};
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.finish();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(3, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterWritingArchiveEntry() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                                                                                                                                              byte[] data = {1, 2, 3, 4, 5};
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.putArchiveEntry(mockEntry);
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(5, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetCount_AfterWritingMultipleArchiveEntries() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                                                                                                                                                                                                                                                                              ArchiveEntry mockEntry1 = mock(ArchiveEntry.class);
                                                                                                                                                                                                                                                                                              ArchiveEntry mockEntry2 = mock(ArchiveEntry.class);
                                                                                                                                                                                                                                                                                              byte[] data1 = {1, 2, 3};
                                                                                                                                                                                                                                                                                              byte[] data2 = {4, 5, 6, 7};
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                                                              tarOut.putArchiveEntry(mockEntry1);
                                                                                                                                                                                                                                                                                              tarOut.write(data1, 0, data1.length);
                                                                                                                                                                                                                                                                                              tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              tarOut.putArchiveEntry(mockEntry2);
                                                                                                                                                                                                                                                                                              tarOut.write(data2, 0, data2.length);
                                                                                                                                                                                                                                                                                              tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                                                              assertEquals(7, tarOut.getCount());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_WithNoDataWritten() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(0, tarOut.getBytesWritten());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_AfterWritingData() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              CountingOutputStream countingOs = new CountingOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(countingOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Simulate writing some data
                                                                                                                                                                                                                                                                                              byte[] data = "test data".getBytes();
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(data.length, tarOut.getBytesWritten());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_AfterMultipleWrites() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              CountingOutputStream countingOs = new CountingOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(countingOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Simulate multiple writes
                                                                                                                                                                                                                                                                                              byte[] data1 = "first".getBytes();
                                                                                                                                                                                                                                                                                              byte[] data2 = "second".getBytes();
                                                                                                                                                                                                                                                                                              tarOut.write(data1, 0, data1.length);
                                                                                                                                                                                                                                                                                              tarOut.write(data2, 0, data2.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(data1.length + data2.length, tarOut.getBytesWritten());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_AfterClosingStream() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              CountingOutputStream countingOs = new CountingOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(countingOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Write some data and close
                                                                                                                                                                                                                                                                                              byte[] data = "test".getBytes();
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              tarOut.close();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(data.length, tarOut.getBytesWritten());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_WithLargeData() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              CountingOutputStream countingOs = new CountingOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(countingOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Create large data (1MB)
                                                                                                                                                                                                                                                                                              byte[] largeData = new byte[1024 * 1024];
                                                                                                                                                                                                                                                                                              for (int i = 0; i < largeData.length; i++) {
                                                                                                                                                                                                                                                                                                  largeData[i] = (byte)(i % 256);
                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              tarOut.write(largeData, 0, largeData.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(largeData.length, tarOut.getBytesWritten());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_WithEmptyWrites() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              CountingOutputStream countingOs = new CountingOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(countingOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Write empty data
                                                                                                                                                                                                                                                                                              byte[] emptyData = new byte[0];
                                                                                                                                                                                                                                                                                              tarOut.write(emptyData, 0, emptyData.length);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              assertEquals(0, tarOut.getBytesWritten());
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                          public void testGetBytesWritten_AfterArchiveOperations() throws Exception {
                                                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                                                              OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                              CountingOutputStream countingOs = new CountingOutputStream(mockOs);
                                                                                                                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(countingOs);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                                                                                                                                              when(mockEntry.getName()).thenReturn("test.txt");
                                                                                                                                                                                                                                                                                              when(mockEntry.getSize()).thenReturn(10L);
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Perform archive operations
                                                                                                                                                                                                                                                                                              tarOut.putArchiveEntry(mockEntry);
                                                                                                                                                                                                                                                                                              byte[] data = "test data".getBytes();
                                                                                                                                                                                                                                                                                              tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                              tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                              // Act & Assert
                                                                                                                                                                                                                                                                                              // Should include both data and tar header bytes
                                                                                                                                                                                                                                                                                              assertTrue(tarOut.getBytesWritten() > data.length);
                                                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                                                  public void testWrite_EmptyWriteDoesNothing() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                      byte[] data = new byte[10];
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                                      tarOut.write(data, 0, 0);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify nothing was written
                                                                                                                                                                                                                                                                                      verifyZeroInteractions(mockOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify assemLen is 0 using reflection
                                                                                                                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                      int assemLenValue = (int) assemLenField.get(tarOut);
                                                                                                                                                                                                                                                                                      assertEquals(0, assemLenValue);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testWrite_CompletesPartialRecord() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                                                                      Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                                                                                      recordBufField.setAccessible(true);
                                                                                                                                                                                                                                                                                      byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                      assemLenField.set(tarOut, recordBuf.length - 5); // Almost full
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      byte[] data = new byte[10];
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                                      tarOut.write(data, 0, 5); // Should complete the record
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      verify(mockOut).write(any(byte[].class), eq(0), eq(recordBuf.length));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                                                                                                                                      assertEquals(recordBuf.length, currBytesField.get(tarOut));
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testWrite_AddsToPartialRecord() throws IOException {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to set assemLen
                                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                          assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                          assemLenField.set(tarOut, 10);
                                                                                                                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                                                                                                                          fail("Failed to set assemLen via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      byte[] data = new byte[20];
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Test - write less than remaining record space
                                                                                                                                                                                                                                                                                      tarOut.write(data, 0, 15);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      verifyZeroInteractions(mockOut); // Shouldn't write to output yet
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to get assemLen
                                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                          assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                          int assemLenValue = (int) assemLenField.get(tarOut);
                                                                                                                                                                                                                                                                                          assertEquals(25, assemLenValue); // Combined length
                                                                                                                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                                                                                                                          fail("Failed to get assemLen via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testWrite_WritesCompleteRecords() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Get record size through reflection since it's private
                                                                                                                                                                                                                                                                                      Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                                                                                      recordBufField.setAccessible(true);
                                                                                                                                                                                                                                                                                      byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                                                                                                      int recordSize = recordBuf.length;
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      byte[] data = new byte[recordSize * 3]; // 3 full records
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                                      tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      verify(mockOut, times(3)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify private fields through reflection
                                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                                      assertEquals(recordSize * 3, currBytesField.getLong(tarOut));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                      assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testWrite_MixedFullAndPartialRecords() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                                                                      Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                                                                                      recordBufField.setAccessible(true);
                                                                                                                                                                                                                                                                                      byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                                                                                                      int recordSize = recordBuf.length;
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      byte[] data = new byte[recordSize * 2 + 10]; // 2 full + partial
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                                      tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      verify(mockOut, times(2)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                                      long currBytes = currBytesField.getLong(tarOut);
                                                                                                                                                                                                                                                                                      assertEquals(recordSize * 2, currBytes);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                      int assemLen = assemLenField.getInt(tarOut);
                                                                                                                                                                                                                                                                                      assertEquals(10, assemLen);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testWrite_ExactRecordSize() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Use reflection to access private fields
                                                                                                                                                                                                                                                                                      Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                                                                                      recordBufField.setAccessible(true);
                                                                                                                                                                                                                                                                                      byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      byte[] data = new byte[recordBuf.length]; // Exactly one record
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                                      tarOut.write(data, 0, data.length);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                      verify(mockOut).write(any(byte[].class), eq(0), eq(recordBuf.length));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify internal state using reflection
                                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                                      assertEquals(recordBuf.length, currBytesField.getLong(tarOut));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                                                      assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testWrite_ThrowsWhenExceedingSize() throws Exception {
                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Set private fields using reflection
                                                                                                                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                                      currSizeField.set(tarOut, 100L);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                      currBytesField.set(tarOut, 95L);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                                                                                                                      currNameField.set(tarOut, "test.txt");
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      byte[] data = new byte[10];
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                          tarOut.write(data, 0, 10);
                                                                                                                                                                                                                                                                          fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                                                      } catch (IOException e) {
                                                                                                                                                                                                                                                                          assertEquals("request to write '10' bytes exceeds size in header of '100' bytes for entry 'test.txt'", 
                                                                                                                                                                                                                                                                              e.getMessage());
                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                             public void testWriteExactlyFillsEntry() throws Exception {
                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                                                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                                                                                 currSizeField.setAccessible(true);
                                                                                                                                                                                                                                                                 currSizeField.set(tarOut, 100L);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                                                                 currBytesField.setAccessible(true);
                                                                                                                                                                                                                                                                 currBytesField.set(tarOut, 50L);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 int numToWrite = 50;     // Will make currBytes + numToWrite == currSize
                                                                                                                                                                                                                                                                 byte[] testData = new byte[numToWrite];
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Test - should NOT throw exception with original code
                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                     tarOut.write(testData, 0, numToWrite);
                                                                                                                                                                                                                                                                 } catch (IOException e) {
                                                                                                                                                                                                                                                                     fail("Should not throw exception when write exactly fills remaining space");
                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                 assertEquals(100L, currBytesField.get(tarOut));  // Should have updated currBytes
                                                                                                                                                                                                                                                                 verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                             }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                         public void testWrite_ThrowsWhenExceedingEntrySize() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Set up entry with limited size
                                                                                                                                                                                                                                                             ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                                                                                                             when(mockEntry.getSize()).thenReturn(100L);
                                                                                                                                                                                                                                                             tarOut.putArchiveEntry(mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Current state: currBytes=0, currSize=100
                                                                                                                                                                                                                                                             // Try to write 101 bytes (should throw)
                                                                                                                                                                                                                                                             byte[] data = new byte[101];
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // This should throw IOException in original code
                                                                                                                                                                                                                                                             // Mutant would not throw here
                                                                                                                                                                                                                                                             tarOut.write(data, 0, 101);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify no bytes were actually written (since exception should be thrown first)
                                                                                                                                                                                                                                                             verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                   public void testWriteWithEmptyAssemblyBuffer() throws Exception {
                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                       ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set up initial conditions where assemLen = 0
                                                                                                                                                                                                                                                       byte[] testData = new byte[100];
                                                                                                                                                                                                                                                       java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Get record size through reflection
                                                                                                                                                                                                                                                       java.lang.reflect.Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                                                       recordBufField.setAccessible(true);
                                                                                                                                                                                                                                                       byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                                                                       int recordSize = recordBuf.length;
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Get initial output size
                                                                                                                                                                                                                                                       int initialSize = out.size();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Test with data smaller than record size to trigger assembly path
                                                                                                                                                                                                                                                       int writeSize = recordSize / 2;
                                                                                                                                                                                                                                                       tarOut.write(testData, 0, writeSize);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify no full record was written (output size shouldn't change)
                                                                                                                                                                                                                                                       assertEquals(initialSize, out.size());
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify data was added to assembly buffer using reflection
                                                                                                                                                                                                                                                       java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                       assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                       int assemLen = assemLenField.getInt(tarOut);
                                                                                                                                                                                                                                                       assertEquals(writeSize, assemLen);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify assembly buffer content
                                                                                                                                                                                                                                                       java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                                                       assemBufField.setAccessible(true);
                                                                                                                                                                                                                                                       byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                                                                                       for (int i = 0; i < writeSize; i++) {
                                                                                                                                                                                                                                                           assertEquals(testData[i], assemBuf[i]);
                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                              public void testWriteWhenAssemblyPlusWriteExactlyEqualsRecordSize() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                  ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                  int recordSize = 512; // Default record size
                                                                                                                                                                                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out, recordSize);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Set up initial state with assembly buffer partially filled
                                                                                                                                                                                                                                                  int initialAssemLen = 100;
                                                                                                                                                                                                                                                  byte[] testData = new byte[initialAssemLen + (recordSize - initialAssemLen)];
                                                                                                                                                                                                                                                  java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Set internal state through reflection
                                                                                                                                                                                                                                                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                                                  assemLenField.setAccessible(true);
                                                                                                                                                                                                                                                  assemLenField.set(tarOut, initialAssemLen);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                                                  assemBufField.setAccessible(true);
                                                                                                                                                                                                                                                  byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                                                                                  System.arraycopy(testData, 0, assemBuf, 0, initialAssemLen);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Instead of mocking TarBuffer directly, we'll verify the output
                                                                                                                                                                                                                                                  // Test - write exactly enough to complete the record
                                                                                                                                                                                                                                                  int bytesToWrite = recordSize - initialAssemLen;
                                                                                                                                                                                                                                                  tarOut.write(testData, initialAssemLen, bytesToWrite);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Verify - should write a complete record by checking output size
                                                                                                                                                                                                                                                  // Since we can't mock TarBuffer, we verify the output contains our data
                                                                                                                                                                                                                                                  tarOut.close();
                                                                                                                                                                                                                                                  byte[] output = out.toByteArray();
                                                                                                                                                                                                                                                  assertTrue(output.length >= recordSize); // At least one full record was written
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Clean up
                                                                                                                                                                                                                                                  tarOut.close();
                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                         public void testWriteDetectsMutantWhenAssemblingFullRecord() throws Exception {
                                                                                                                                                                                                                             // Setup test with specific buffer sizes
                                                                                                                                                                                                                             int recordSize = 512;
                                                                                                                                                                                                                             ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out, recordSize);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Set up initial state with partial assembled data using reflection
                                                                                                                                                                                                                             int initialAssemLen = 300;
                                                                                                                                                                                                                             Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                             assemLenField.setAccessible(true);
                                                                                                                                                                                                                             assemLenField.set(tarOut, initialAssemLen);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Prepare test data that would exactly fill the remaining space in record
                                                                                                                                                                                                                             byte[] testData = new byte[300]; // 300 + 300 > 512 (would trigger the condition)
                                                                                                                                                                                                                             java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Instead of mocking TarBuffer directly, we'll use the original buffer
                                                                                                                                                                                                                             // but verify the output stream's state after write operation
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Set recordBuf and assemBuf through reflection
                                                                                                                                                                                                                             Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                             recordBufField.setAccessible(true);
                                                                                                                                                                                                                             recordBufField.set(tarOut, new byte[recordSize]);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                             assemBufField.setAccessible(true);
                                                                                                                                                                                                                             assemBufField.set(tarOut, new byte[recordSize]);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Execute test
                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                 tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify the output stream contains the expected data
                                                                                                                                                                                                                                 byte[] writtenData = out.toByteArray();
                                                                                                                                                                                                                                 assertTrue(writtenData.length >= recordSize); // At least one full record should be written
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify remaining state
                                                                                                                                                                                                                                 int remainingAssemLen = assemLenField.getInt(tarOut);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Should have 88 bytes remaining (300+300-512)
                                                                                                                                                                                                                                 assertEquals(88, remainingAssemLen);
                                                                                                                                                                                                                             } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                                                                 // The mutant would throw this exception
                                                                                                                                                                                                                                 fail("Mutant detected - incorrect buffer length calculation caused ArrayIndexOutOfBoundsException");
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                public void testWrite_DetectsCurrBytesSubtractionMutant() throws Exception {
                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create test instance with standard configuration
                                                                                                                                                                                                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to access and modify private fields
                                                                                                                                                                                                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                                    assemLenField.setAccessible(true);
                                                                                                                                                                                                                    assemLenField.set(tarOut, 100); // Existing partial assembly
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                                    recordBufField.setAccessible(true);
                                                                                                                                                                                                                    recordBufField.set(tarOut, new byte[512]); // Standard TAR record size
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                                    assemBufField.setAccessible(true);
                                                                                                                                                                                                                    assemBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                                    currBytesField.setAccessible(true);
                                                                                                                                                                                                                    currBytesField.set(tarOut, 0); // Start with 0 bytes written
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create test data that will trigger the assembly branch
                                                                                                                                                                                                                    byte[] testData = new byte[500]; // More than remaining space in record (512-100=412)
                                                                                                                                                                                                                    java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                    tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                    // Verify currBytes was increased by record length (would fail with mutant)
                                                                                                                                                                                                                    assertEquals("currBytes should increase by record length", 
                                                                                                                                                                                                                                512, currBytesField.getInt(tarOut));
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify the output stream received data (indirectly verifies record was written)
                                                                                                                                                                                                                    verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify remaining state
                                                                                                                                                                                                                    assertEquals("Assembly length should be reset", 
                                                                                                                                                                                                                                0, assemLenField.getInt(tarOut));
                                                                                                                                                                                                                    assertEquals("Remaining bytes to write should be adjusted", 
                                                                                                                                                                                                                                500 - 412, testData.length - 412);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                       public void testWriteWithAssemblyDetectsOffsetMutation() throws Exception {
                                                                                                                                                                                                           // Setup test data
                                                                                                                                                                                                           int recordSize = 512; // Default tar record size
                                                                                                                                                                                                           byte[] wBuf = new byte[recordSize * 2]; // Larger than record size
                                                                                                                                                                                                           java.util.Arrays.fill(wBuf, (byte)1); // Fill with test data
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Initialize with partial assembly using ByteArrayOutputStream we can verify
                                                                                                                                                                                                           ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to set private fields
                                                                                                                                                                                                           java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                           assemLenField.setAccessible(true);
                                                                                                                                                                                                           assemLenField.set(tarOut, recordSize / 2); // Half a record already assembled
                                                                                                                                                                                                           
                                                                                                                                                                                                           java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                           assemBufField.setAccessible(true);
                                                                                                                                                                                                           byte[] assemBuf = new byte[recordSize];
                                                                                                                                                                                                           java.util.Arrays.fill(assemBuf, 0, recordSize / 2, (byte)2);
                                                                                                                                                                                                           assemBufField.set(tarOut, assemBuf);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Initial write offset
                                                                                                                                                                                                           int initialOffset = 100;
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute write
                                                                                                                                                                                                           tarOut.write(wBuf, initialOffset, recordSize); // Write exactly one record's worth
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify the offset was correctly advanced
                                                                                                                                                                                                           int expectedOffset = initialOffset + (recordSize - (recordSize / 2));
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify the assembly buffer was updated correctly
                                                                                                                                                                                                           byte[] updatedAssemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                                           int updatedAssemLen = (int) assemLenField.get(tarOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify the final assembly state
                                                                                                                                                                                                           assertEquals("Assembly buffer should be updated correctly",
                                                                                                                                                                                                                       recordSize / 2,
                                                                                                                                                                                                                       updatedAssemLen);
                                                                                                                                                                                                                       
                                                                                                                                                                                                           // Verify the output contains the expected data
                                                                                                                                                                                                           byte[] output = baos.toByteArray();
                                                                                                                                                                                                           assertTrue("Output should contain assembled data",
                                                                                                                                                                                                                      output.length > 0);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Additional verification that the offset calculation was correct
                                                                                                                                                                                                           assertEquals("Offset calculation should be correct",
                                                                                                                                                                                                                       expectedOffset,
                                                                                                                                                                                                                       initialOffset + (recordSize - (recordSize / 2)));
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                  public void testWriteDetectsNumToWriteMutant() throws Exception {
                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                      ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(bos);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Get private fields via reflection
                                                                                                                                                                                                      Class<?> tarOutClass = tarOut.getClass();
                                                                                                                                                                                                      java.lang.reflect.Field recordBufField = tarOutClass.getDeclaredField("recordBuf");
                                                                                                                                                                                                      recordBufField.setAccessible(true);
                                                                                                                                                                                                      byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                      
                                                                                                                                                                                                      java.lang.reflect.Field assemLenField = tarOutClass.getDeclaredField("assemLen");
                                                                                                                                                                                                      assemLenField.setAccessible(true);
                                                                                                                                                                                                      
                                                                                                                                                                                                      java.lang.reflect.Field currBytesField = tarOutClass.getDeclaredField("currBytes");
                                                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Set up initial state where assemLen > 0
                                                                                                                                                                                                      byte[] testData = new byte[1024]; // Larger than default record size
                                                                                                                                                                                                      java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // First write - partially fill assembly buffer
                                                                                                                                                                                                      int firstWriteSize = recordBuf.length / 2;
                                                                                                                                                                                                      tarOut.write(testData, 0, firstWriteSize);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify assembly buffer has data
                                                                                                                                                                                                      assertEquals(firstWriteSize, assemLenField.getInt(tarOut));
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Second write - should trigger the mutated code path
                                                                                                                                                                                                      int secondWriteSize = recordBuf.length; // Enough to fill record
                                                                                                                                                                                                      tarOut.write(testData, 0, secondWriteSize);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify numToWrite was handled correctly
                                                                                                                                                                                                      int expectedRemaining = secondWriteSize - (recordBuf.length - firstWriteSize);
                                                                                                                                                                                                      assertTrue(expectedRemaining >= 0); // Verify test logic
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify final state
                                                                                                                                                                                                      assertEquals(0, assemLenField.getInt(tarOut)); // Assembly buffer should be empty
                                                                                                                                                                                                      assertEquals(recordBuf.length, currBytesField.getInt(tarOut)); // Should have written one full record
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Clean up
                                                                                                                                                                                                      tarOut.close();
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                         public void testWriteWithZeroBytesShouldNotEnterLoop() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set up initial state
                                                                                                                                                                                             byte[] testData = new byte[0];  // Empty data
                                                                                                                                                                                             int offset = 0;
                                                                                                                                                                                             int numToWrite = 0;  // This is the key value to test
                                                                                                                                                                                             
                                                                                                                                                                                             // Execute
                                                                                                                                                                                             tarOut.write(testData, offset, numToWrite);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify no writes were made to the underlying stream
                                                                                                                                                                                             verify(mockOut, never()).write(any(byte[].class));
                                                                                                                                                                                             verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify state variables
                                                                                                                                                                                             Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                             assemLenField.setAccessible(true);
                                                                                                                                                                                             assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                                             
                                                                                                                                                                                             Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                             currBytesField.setAccessible(true);
                                                                                                                                                                                             assertEquals(0L, currBytesField.get(tarOut));
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                public void testWriteWithExactRecordSize() throws Exception {
                                                                                                                                                                                    // Setup
                                                                                                                                                                                    int recordSize = 512; // Default tar record size
                                                                                                                                                                                    byte[] testData = new byte[recordSize];
                                                                                                                                                                                    java.util.Arrays.fill(testData, (byte)1); // Fill with test data
                                                                                                                                                                                    
                                                                                                                                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create real TarArchiveOutputStream and inject mock output stream
                                                                                                                                                                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private fields
                                                                                                                                                                                    Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                    bufferField.setAccessible(true);
                                                                                                                                                                                    Object buffer = bufferField.get(tarOut); // Don't cast to TarBuffer
                                                                                                                                                                                    
                                                                                                                                                                                    Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                    recordBufField.setAccessible(true);
                                                                                                                                                                                    byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                    
                                                                                                                                                                                    Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                    assemBufField.setAccessible(true);
                                                                                                                                                                                    byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                    
                                                                                                                                                                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                    assemLenField.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                    currBytesField.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test exact record size write
                                                                                                                                                                                    tarOut.write(testData, 0, recordSize);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify behavior - should write directly to buffer
                                                                                                                                                                                    // Since we can't mock TarBuffer directly, we verify the output stream was written to
                                                                                                                                                                                    verify(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify internal state through reflection
                                                                                                                                                                                    assertEquals(0, assemLenField.getInt(tarOut)); // No assembly should occur
                                                                                                                                                                                    assertEquals(recordSize, currBytesField.getLong(tarOut)); // Bytes should be counted
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testWriteMultipleRecordsAccumulatesBytesCorrectly() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                               // Setup
                                                                                                                                                                               OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to get record buffer size
                                                                                                                                                                               Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                               recordBufField.setAccessible(true);
                                                                                                                                                                               byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                               int recordSize = recordBuf.length;
                                                                                                                                                                               
                                                                                                                                                                               // Set up test data that will require multiple record writes
                                                                                                                                                                               int dataSize = recordSize * 3; // Enough for 3 full records
                                                                                                                                                                               byte[] testData = new byte[dataSize];
                                                                                                                                                                               
                                                                                                                                                                               // Set current entry size large enough to accept all writes
                                                                                                                                                                               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                               currSizeField.setAccessible(true);
                                                                                                                                                                               currSizeField.setLong(tarOut, dataSize + 100);
                                                                                                                                                                               
                                                                                                                                                                               // Act
                                                                                                                                                                               tarOut.write(testData, 0, dataSize);
                                                                                                                                                                               
                                                                                                                                                                               // Assert
                                                                                                                                                                               // Verify currBytes was accumulated properly (should be 3 * recordSize)
                                                                                                                                                                               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                               currBytesField.setAccessible(true);
                                                                                                                                                                               long actualBytes = currBytesField.getLong(tarOut);
                                                                                                                                                                               
                                                                                                                                                                               assertEquals("currBytes should accumulate total bytes written", 
                                                                                                                                                                                           recordSize * 3, actualBytes);
                                                                                                                                                                               
                                                                                                                                                                               // Verify output stream received the writes (3 records worth of data)
                                                                                                                                                                               verify(mockOut, times(3)).write(any(byte[].class), anyInt(), eq(recordSize));
                                                                                                                                                                           }

    @Test
                                                                                                                                                                      public void testWriteWithMultipleRecordsDetectsNumToWriteMutation() throws IOException {
                                                                                                                                                                          // Setup
                                                                                                                                                                          int recordSize = 512; // Default tar record size
                                                                                                                                                                          int blockSize = 10240; // Default block size
                                                                                                                                                                          ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out, blockSize, recordSize);
                                                                                                                                                                          
                                                                                                                                                                          // Create a test entry
                                                                                                                                                                          ArchiveEntry entry = mock(ArchiveEntry.class);
                                                                                                                                                                          when(entry.getSize()).thenReturn(2000L); // Larger than one record
                                                                                                                                                                          tarOut.putArchiveEntry(entry);
                                                                                                                                                                          
                                                                                                                                                                          // Test data - needs to span multiple records (2000 bytes > 512*3)
                                                                                                                                                                          byte[] data = new byte[2000];
                                                                                                                                                                          java.util.Random random = new java.util.Random();
                                                                                                                                                                          random.nextBytes(data); // Fill with random data
                                                                                                                                                                          
                                                                                                                                                                          // Execute
                                                                                                                                                                          tarOut.write(data, 0, data.length);
                                                                                                                                                                          tarOut.closeArchiveEntry();
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          // The key verification is that all bytes were processed correctly
                                                                                                                                                                          // With the mutation, numToWrite would be incorrectly set to recordSize
                                                                                                                                                                          // instead of being decremented, causing either:
                                                                                                                                                                          // 1. Infinite loop (if we didn't have closeArchiveEntry)
                                                                                                                                                                          // 2. Incorrect final state
                                                                                                                                                                          
                                                                                                                                                                          // Check that all bytes were written (indirectly verifies numToWrite was decremented)
                                                                                                                                                                          assertEquals(2000, tarOut.getBytesWritten() % blockSize);
                                                                                                                                                                          
                                                                                                                                                                          // Check the output contains our data
                                                                                                                                                                          byte[] written = out.toByteArray();
                                                                                                                                                                          byte[] writtenData = java.util.Arrays.copyOfRange(written, 512, 512 + 2000); // Skip header
                                                                                                                                                                          assertArrayEquals(data, writtenData);
                                                                                                                                                                          
                                                                                                                                                                          tarOut.close();
                                                                                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                                                                                  public void testWrite_ExactSizeBoundary_ShouldNotThrowInOriginalButDoesInMutant() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                      
                                                                                                                                                                      // Set up state where currBytes + numToWrite exactly equals currSize
                                                                                                                                                                      long currSize = 100L;
                                                                                                                                                                      long currBytes = 90L;
                                                                                                                                                                      int numToWrite = 10;
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields since they're not publicly accessible
                                                                                                                                                                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                      currSizeField.setAccessible(true);
                                                                                                                                                                      currSizeField.set(tarOut, currSize);
                                                                                                                                                                      
                                                                                                                                                                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                      currBytesField.setAccessible(true);
                                                                                                                                                                      currBytesField.set(tarOut, currBytes);
                                                                                                                                                                      
                                                                                                                                                                      Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                      currNameField.setAccessible(true);
                                                                                                                                                                      currNameField.set(tarOut, "testEntry");
                                                                                                                                                                      
                                                                                                                                                                      // Create test buffer
                                                                                                                                                                      byte[] buffer = new byte[numToWrite];
                                                                                                                                                                      
                                                                                                                                                                      // This should throw IOException in the mutant (>=) but not in original (>)
                                                                                                                                                                      tarOut.write(buffer, 0, numToWrite);
                                                                                                                                                                      
                                                                                                                                                                      // If we get here in the original code, the test fails (since we expected exception)
                                                                                                                                                                      // In mutant, the exception will be thrown as expected
                                                                                                                                                                  }

    @Test
                                                                                                                                                                public void testWriteWithZeroAssemLenShouldNotExecuteAssemblyLogic() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                                                                                                                                                                    
                                                                                                                                                                    // Get private fields via reflection
                                                                                                                                                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                    assemLenField.setAccessible(true);
                                                                                                                                                                    Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                    assemBufField.setAccessible(true);
                                                                                                                                                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                    currBytesField.setAccessible(true);
                                                                                                                                                                    Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                    recordBufField.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Set initial conditions: assemLen = 0, small write that wouldn't fill a record
                                                                                                                                                                    byte[] data = new byte[10]; // small write
                                                                                                                                                                    int recordSize = tarOut.getRecordSize();
                                                                                                                                                                    
                                                                                                                                                                    // Verify initial state
                                                                                                                                                                    assertEquals(0, assemLenField.getInt(tarOut)); // assemLen starts at 0
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    tarOut.write(data, 0, data.length);
                                                                                                                                                                    
                                                                                                                                                                    // Verify behavior - original would skip the assembly block (assemLen > 0 is false)
                                                                                                                                                                    // Mutant would enter the block (assemLen >= 0 is true)
                                                                                                                                                                    
                                                                                                                                                                    // In original code, data should be copied directly to assemBuf (via the while loop)
                                                                                                                                                                    // and assemLen should be updated to data.length
                                                                                                                                                                    assertEquals(data.length, assemLenField.getInt(tarOut));
                                                                                                                                                                    
                                                                                                                                                                    // Verify no record was written (since we didn't fill a complete record)
                                                                                                                                                                    // This would be different if mutant executed the assembly block
                                                                                                                                                                    assertEquals(0, out.size());
                                                                                                                                                                    
                                                                                                                                                                    // Verify assemBuf contains our data (only first 10 bytes)
                                                                                                                                                                    byte[] expectedAssemBuf = new byte[recordSize];
                                                                                                                                                                    System.arraycopy(data, 0, expectedAssemBuf, 0, data.length);
                                                                                                                                                                    assertArrayEquals(expectedAssemBuf, (byte[]) assemBufField.get(tarOut));
                                                                                                                                                                    
                                                                                                                                                                    // Verify currBytes wasn't incremented (no full record written)
                                                                                                                                                                    assertEquals(0, currBytesField.getLong(tarOut));
                                                                                                                                                                }

    @Test
                                                                                                                                                           public void testWriteWithExactBufferSize() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                               int recordSize = 512; // Default TAR record size
                                                                                                                                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out, recordSize);
                                                                                                                                                               
                                                                                                                                                               // Set up initial assembly buffer state
                                                                                                                                                               byte[] initialData = new byte[256]; // Half of record size
                                                                                                                                                               tarOut.write(initialData, 0, initialData.length); // assemLen = 256 now
                                                                                                                                                               
                                                                                                                                                               // Write exactly enough to fill the record (256 + 256 = 512)
                                                                                                                                                               byte[] testData = new byte[256];
                                                                                                                                                               tarOut.write(testData, 0, testData.length);
                                                                                                                                                               
                                                                                                                                                               // Verify behavior by checking the output
                                                                                                                                                               // Since we can't mock TarBuffer, we verify that the output contains our data
                                                                                                                                                               byte[] result = out.toByteArray();
                                                                                                                                                               assertTrue(result.length >= recordSize); // At least one full record should be written
                                                                                                                                                               
                                                                                                                                                               // Clean up
                                                                                                                                                               tarOut.close();
                                                                                                                                                           }

    @Test
                                                                                                                                          public void testWriteWithPartialAssembledBuffer() throws Exception {
                                                                                                                                              // Setup test data
                                                                                                                                              int recordSize = 512; // Default tar record size
                                                                                                                                              byte[] wBuf = new byte[1024]; // Test write buffer
                                                                                                                                              java.util.Arrays.fill(wBuf, (byte)1); // Fill with test data
                                                                                                                                              
                                                                                                                                              // Create partial assembled buffer
                                                                                                                                              int assemLen = 300;
                                                                                                                                              byte[] assemBuf = new byte[recordSize];
                                                                                                                                              java.util.Arrays.fill(assemBuf, 0, assemLen, (byte)2);
                                                                                                                                              
                                                                                                                                              // Mock dependencies
                                                                                                                                              OutputStream osMock = mock(OutputStream.class);
                                                                                                                                              
                                                                                                                                              // Create test instance
                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(osMock);
                                                                                                                                              
                                                                                                                                              // Set private fields using reflection
                                                                                                                                              java.lang.reflect.Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                              recordBufField.setAccessible(true);
                                                                                                                                              recordBufField.set(tarOut, new byte[recordSize]);
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                              assemBufField.setAccessible(true);
                                                                                                                                              assemBufField.set(tarOut, assemBuf);
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                              assemLenField.setAccessible(true);
                                                                                                                                              assemLenField.set(tarOut, assemLen);
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                              currSizeField.setAccessible(true);
                                                                                                                                              currSizeField.set(tarOut, Long.MAX_VALUE);
                                                                                                                                              
                                                                                                                                              // Call method under test
                                                                                                                                              tarOut.write(wBuf, 0, 500); // Should trigger the mutated code path
                                                                                                                                              
                                                                                                                                              // Verify behavior
                                                                                                                                              // Correct aLen should be 512-300=212
                                                                                                                                              // Verify the correct amount was written to output stream
                                                                                                                                              org.mockito.ArgumentCaptor<byte[]> recordCaptor = org.mockito.ArgumentCaptor.forClass(byte[].class);
                                                                                                                                              verify(osMock, atLeastOnce()).write(recordCaptor.capture(), anyInt(), anyInt());
                                                                                                                                              byte[] writtenData = recordCaptor.getValue();
                                                                                                                                              
                                                                                                                                              // First part should be from assemBuf (value 2)
                                                                                                                                              for (int i = 0; i < assemLen; i++) {
                                                                                                                                                  assertEquals(2, writtenData[i]);
                                                                                                                                              }
                                                                                                                                              // Second part should be from wBuf (value 1)
                                                                                                                                              for (int i = assemLen; i < recordSize; i++) {
                                                                                                                                                  assertEquals(1, writtenData[i]);
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Verify state was updated correctly
                                                                                                                                              java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                              currBytesField.setAccessible(true);
                                                                                                                                              assertEquals(512, currBytesField.get(tarOut)); // Should increment by record size
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                                                                                                                              wOffsetField.setAccessible(true);
                                                                                                                                              assertEquals(212, wOffsetField.get(tarOut)); // Should advance by aLen (512-300)
                                                                                                                                              
                                                                                                                                              java.lang.reflect.Field numToWriteField = TarArchiveOutputStream.class.getDeclaredField("numToWrite");
                                                                                                                                              numToWriteField.setAccessible(true);
                                                                                                                                              assertEquals(288, numToWriteField.get(tarOut)); // Should be 500-212
                                                                                                                                              
                                                                                                                                              assertEquals(0, assemLenField.get(tarOut)); // Should be reset
                                                                                                                                          }

    @Test
                                                                                                                                     public void testWrite_DetectsCurrBytesMutation() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                         // Setup
                                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                         
                                                                                                                                         // Use reflection to set initial state
                                                                                                                                         Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                         bufferField.setAccessible(true);
                                                                                                                                         Object realBuffer = bufferField.get(tarOut);
                                                                                                                                         
                                                                                                                                         Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                         recordBufField.setAccessible(true);
                                                                                                                                         byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                         int recordSize = recordBuf.length;
                                                                                                                                         
                                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                                         assemLenField.set(tarOut, 10); // Set some assembled data
                                                                                                                                         
                                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                                         long initialBytes = 100;
                                                                                                                                         currBytesField.set(tarOut, initialBytes);
                                                                                                                                         
                                                                                                                                         // Test data - needs to trigger the assembly path
                                                                                                                                         byte[] testData = new byte[recordSize * 2]; // Enough to trigger full record write
                                                                                                                                         java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                         
                                                                                                                                         // Act
                                                                                                                                         tarOut.write(testData, 0, testData.length);
                                                                                                                                         
                                                                                                                                         // Assert - verify currBytes was incremented correctly
                                                                                                                                         long finalBytes = (long) currBytesField.get(tarOut);
                                                                                                                                         assertEquals("currBytes should increase by record size", 
                                                                                                                                                    initialBytes + recordSize, 
                                                                                                                                                    finalBytes);
                                                                                                                                     }

    @Test
                                                                                                            public void testWriteWithPartialAssemblyDetectsOffsetMutation() throws IOException, NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
                                                                                                                // Setup test data
                                                                                                                byte[] testData = new byte[1024]; // Larger than record size
                                                                                                                java.util.Arrays.fill(testData, (byte)1); // Fill with test pattern
                                                                                                                
                                                                                                                // Create output stream with mocked output
                                                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                
                                                                                                                // Get the actual buffer created by TarArchiveOutputStream using reflection
                                                                                                                Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                bufferField.setAccessible(true);
                                                                                                                Object buffer = bufferField.get(tarOut);
                                                                                                                
                                                                                                                // Spy on the actual buffer instead of mocking it directly
                                                                                                                Object spyBuffer = spy(buffer);
                                                                                                                bufferField.set(tarOut, spyBuffer);
                                                                                                                
                                                                                                                // Set record size to known value (512 is standard tar record size)
                                                                                                                Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                recordBufField.setAccessible(true);
                                                                                                                byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                int recordSize = recordBuf.length;
                                                                                                                
                                                                                                                // Set up partial assembly buffer
                                                                                                                Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                assemLenField.setAccessible(true);
                                                                                                                assemLenField.set(tarOut, recordSize / 2); // Half full
                                                                                                                
                                                                                                                Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                assemBufField.setAccessible(true);
                                                                                                                byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                java.util.Arrays.fill(assemBuf, 0, recordSize / 2, (byte)2); // Different pattern
                                                                                                                
                                                                                                                // Write enough data to trigger full record write
                                                                                                                int writeSize = recordSize; // Enough to complete the record
                                                                                                                tarOut.write(testData, 0, writeSize);
                                                                                                                
                                                                                                                // Verify the buffer was written correctly by checking the mock output stream
                                                                                                                verify(mockOut, times(1)).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                
                                                                                                                // Verify subsequent writes use correct offset
                                                                                                                // The mutation would cause this to fail as it would use wrong offset
                                                                                                                tarOut.write(testData, recordSize / 2, 10); // Write some more
                                                                                                                verify(mockOut, times(2)).write(any(byte[].class), anyInt(), anyInt());
                                                                                                            }

    @Test
                                                                                               public void testWriteDetectsNumToWriteMutant1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                   // Setup
                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                   
                                                                                                   // Get the actual buffer instance created by TarArchiveOutputStream
                                                                                                   Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                   bufferField.setAccessible(true);
                                                                                                   Object buffer = bufferField.get(tarOut);
                                                                                                   Object spyBuffer = spy(buffer);
                                                                                                   bufferField.set(tarOut, spyBuffer);
                                                                                                   
                                                                                                   Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                   recordBufField.setAccessible(true);
                                                                                                   byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                   int recordSize = recordBuf.length;
                                                                                                   
                                                                                                   // Set up test data - we want to trigger the first branch where assemLen > 0
                                                                                                   // and (assemLen + numToWrite) >= recordBuf.length
                                                                                                   byte[] testData = new byte[recordSize * 2]; // Enough to fill two records
                                                                                                   java.util.Arrays.fill(testData, (byte)1);
                                                                                                   
                                                                                                   // Set initial assembly buffer state
                                                                                                   Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                   assemLenField.setAccessible(true);
                                                                                                   assemLenField.set(tarOut, recordSize / 2); // Half full assembly buffer
                                                                                                   
                                                                                                   Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                   assemBufField.setAccessible(true);
                                                                                                   byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                   java.util.Arrays.fill(assemBuf, 0, recordSize/2, (byte)2);
                                                                                                   
                                                                                                   // Set current entry state
                                                                                                   Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                   currSizeField.setAccessible(true);
                                                                                                   currSizeField.set(tarOut, recordSize * 3L); // Enough space
                                                                                                   
                                                                                                   // Execute
                                                                                                   tarOut.write(testData, 0, testData.length);
                                                                                                   
                                                                                                   // Verify - the key is checking numToWrite was properly decremented
                                                                                                   // In original code, after first write, numToWrite should be recordSize * 2 - (recordSize/2) = 1.5 * recordSize
                                                                                                   // Then in the while loop it processes the remaining data
                                                                                                   
                                                                                                   // Verify the output stream was written to appropriately
                                                                                                   verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                   
                                                                                                   // Verify final assembly buffer contains the remaining half record
                                                                                                   byte[] finalAssemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                   int finalAssemLen = (int) assemLenField.get(tarOut);
                                                                                                   assertEquals(recordSize/2, finalAssemLen);
                                                                                                   for (int i = 0; i < finalAssemLen; i++) {
                                                                                                       assertEquals((byte)1, finalAssemBuf[i]);
                                                                                                   }
                                                                                                   
                                                                                                   // Verify bytes written count
                                                                                                   Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                   currBytesField.setAccessible(true);
                                                                                                   assertEquals(recordSize * 2, currBytesField.get(tarOut)); // Two full records written
                                                                                               }

    @Test
                                                                                      public void testWriteWithExactBlockSizeShouldNotLoopWhenZero() throws Exception {
                                                                                          // Setup
                                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                          
                                                                                          // Set up test data - write exactly one record's worth of data
                                                                                          int recordSize = tarOut.getRecordSize();
                                                                                          byte[] testData = new byte[recordSize];
                                                                                          java.util.Arrays.fill(testData, (byte)1);
                                                                                          
                                                                                          // Create a real entry to set the required fields
                                                                                          ArchiveEntry entry = tarOut.createArchiveEntry(new File("test.txt"), "test.txt");
                                                                                          
                                                                                          // Use reflection to set private fields
                                                                                          Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                          currSizeField.setAccessible(true);
                                                                                          currSizeField.set(tarOut, recordSize * 2L); // Allow writing our test data
                                                                                          
                                                                                          // Execute
                                                                                          tarOut.putArchiveEntry(entry);
                                                                                          tarOut.write(testData, 0, recordSize);
                                                                                          
                                                                                          // Verify the output stream was written to exactly once
                                                                                          verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                          
                                                                                          // Verify counters using reflection
                                                                                          Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                          currBytesField.setAccessible(true);
                                                                                          assertEquals(recordSize, currBytesField.get(tarOut));
                                                                                          
                                                                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                          assemLenField.setAccessible(true);
                                                                                          assertEquals(0, assemLenField.get(tarOut));
                                                                                          
                                                                                          // Verify no more interactions with the output stream
                                                                                          verifyNoMoreInteractions(mockOut);
                                                                                      }

    @Test
                                                                                 public void testWriteWithExactRecordSize1() throws Exception {
                                                                                     // Setup
                                                                                     int recordSize = 512; // Default tar record size
                                                                                     byte[] testData = new byte[recordSize];
                                                                                     java.util.Arrays.fill(testData, (byte)1); // Fill with test data
                                                                                     
                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                     
                                                                                     // Use reflection to set private fields
                                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                     currSizeField.setAccessible(true);
                                                                                     currSizeField.set(tarOut, recordSize * 2); // Allow writing
                                                                                     
                                                                                     Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                     assemLenField.setAccessible(true);
                                                                                     assemLenField.set(tarOut, 0); // Empty assembly buffer
                                                                                     
                                                                                     // Execute - write exactly one record's worth of data
                                                                                     tarOut.write(testData, 0, recordSize);
                                                                                     
                                                                                     // Verify - should write immediately, not buffer
                                                                                     verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                     
                                                                                     // Verify internal state using reflection
                                                                                     assertEquals(0, assemLenField.getInt(tarOut)); // Nothing should be buffered
                                                                                     
                                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                     currBytesField.setAccessible(true);
                                                                                     assertEquals(recordSize, currBytesField.getInt(tarOut)); // Bytes written should increase
                                                                                     
                                                                                     // The mutant would buffer this instead of writing immediately,
                                                                                     // so this test would fail with the mutant
                                                                                 }

    @Test
                                                                            public void testWriteAccumulatesBytesCorrectly() throws Exception {
                                                                                // Setup
                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                
                                                                                // Create a mock entry to set up the state
                                                                                TarArchiveEntry entry = new TarArchiveEntry("test.txt");
                                                                                entry.setSize(1024); // Large enough to avoid size exception
                                                                                tarOut.putArchiveEntry(entry);
                                                                            
                                                                                // Create test data that's larger than one record (default record size is 512)
                                                                                byte[] data = new byte[1024]; // 2 full records
                                                                                java.util.Arrays.fill(data, (byte)1);
                                                                                
                                                                                // Action - write the data
                                                                                tarOut.write(data, 0, data.length);
                                                                                
                                                                                // Verification
                                                                                // Use reflection to access private currBytes field
                                                                                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                currBytesField.setAccessible(true);
                                                                                long currBytes = (long) currBytesField.get(tarOut);
                                                                                
                                                                                assertEquals("Total bytes written should accumulate properly", 
                                                                                            1024, currBytes);
                                                                                
                                                                                // Additional verification that we wrote exactly 2 records
                                                                                verify(mockOut, times(2)).write(any(byte[].class), eq(0), eq(512));
                                                                            }

    @Test
                                                                   public void testWriteWithMultipleRecordsDetectsNumToWriteMutation1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                       // Setup
                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                       
                                                                       // Get the record size through reflection
                                                                       Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                       recordBufField.setAccessible(true);
                                                                       byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                       int recordSize = recordBuf.length;
                                                                       
                                                                       // Prepare test data - needs to be larger than 2 records to detect the mutation
                                                                       byte[] testData = new byte[recordSize * 3];
                                                                       java.util.Arrays.fill(testData, (byte)1);
                                                                       
                                                                       // Set current entry info
                                                                       Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                       currSizeField.setAccessible(true);
                                                                       currSizeField.set(tarOut, recordSize * 4L); // Enough space
                                                                       
                                                                       // Execute
                                                                       tarOut.write(testData, 0, testData.length);
                                                                       
                                                                       // Verify - mutation would cause wrong number of writes
                                                                       // Original: 3 writes (1 per full record)
                                                                       // Mutant: Would keep writing due to numToWrite not being decremented properly
                                                                       // Verify through mock output stream instead of buffer
                                                                       verify(mockOut, atLeast(3)).write(any(byte[].class), anyInt(), anyInt());
                                                                       
                                                                       // Verify final currBytes - original would be 3*recordSize
                                                                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                       currBytesField.setAccessible(true);
                                                                       assertEquals(recordSize * 3L, currBytesField.get(tarOut));
                                                                       
                                                                       // Verify assemLen is 0 since all data should be written
                                                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                       assemLenField.setAccessible(true);
                                                                       assertEquals(0, assemLenField.get(tarOut));
                                                                   }

    @Test
                                                              public void testWriteExactlyToSizeLimit() throws Exception {
                                                                  // Setup
                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                  
                                                                  // Use reflection to set private fields
                                                                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                  currSizeField.setAccessible(true);
                                                                  currSizeField.set(tarOut, 100L);
                                                                  
                                                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                  currBytesField.setAccessible(true);
                                                                  currBytesField.set(tarOut, 50L);
                                                                  
                                                                  byte[] data = new byte[50]; // exactly fills remaining space
                                                                  
                                                                  // Test - should not throw exception in original code
                                                                  tarOut.write(data, 0, 50);
                                                                  
                                                                  // Verify
                                                                  assertEquals(100L, currBytesField.get(tarOut)); // Verify bytes were written
                                                                  verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                              }

    @Test
                                                              public void testWriteExceedingSizeLimit() throws Exception {
                                                                  // Setup
                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                  
                                                                  // Use reflection to set private fields
                                                                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                  currSizeField.setAccessible(true);
                                                                  currSizeField.set(tarOut, 100L);
                                                                  
                                                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                  currBytesField.setAccessible(true);
                                                                  currBytesField.set(tarOut, 50L);
                                                                  
                                                                  byte[] data = new byte[51]; // exceeds remaining space
                                                                  
                                                                  // Test - should throw exception
                                                                  try {
                                                                      tarOut.write(data, 0, 51);
                                                                      fail("Expected IOException to be thrown");
                                                                  } catch (IOException e) {
                                                                      // Expected behavior
                                                                  }
                                                              }

    @Test
                                                         public void testWriteWithZeroAssemLenShouldSkipAssemblyBlock() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                             // Setup
                                                             ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                             
                                                             // Set initial conditions where assemLen == 0
                                                             Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                             assemLenField.setAccessible(true);
                                                             assemLenField.set(tarOut, 0);
                                                             
                                                             byte[] testData = new byte[10]; // Small data that wouldn't trigger assembly
                                                             Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                             recordBufField.setAccessible(true);
                                                             byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                             
                                                             // Get the original buffer before we potentially modify it
                                                             Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                             bufferField.setAccessible(true);
                                                             Object originalBuffer = bufferField.get(tarOut);
                                                             
                                                             // Execute
                                                             tarOut.write(testData, 0, testData.length);
                                                             
                                                             // Verify - with original code, writeRecord shouldn't be called in this case
                                                             // Since we can't mock TarBuffer, we verify by checking the output stream is empty
                                                             // (since no complete records should have been written)
                                                             assertEquals(0, baos.size());
                                                             
                                                             // Verify assemLen was updated correctly (original would go to the while loop)
                                                             assertEquals(testData.length, assemLenField.get(tarOut));
                                                             
                                                             // Verify buffer wasn't modified
                                                             assertEquals(originalBuffer, bufferField.get(tarOut));
                                                         }

    @Test
                                                    public void testWrite_AssembledDataExactlyFillsBuffer() throws Exception {
                                                        // Setup
                                                        OutputStream mockOut = mock(OutputStream.class);
                                                        int recordSize = 512; // Default tar record size
                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                        
                                                        // Use reflection to set private fields
                                                        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                        assemLenField.setAccessible(true);
                                                        Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                        assemBufField.setAccessible(true);
                                                        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                        currBytesField.setAccessible(true);
                                                        
                                                        // Set up state where assembled length + new data exactly equals buffer size
                                                        byte[] testData = new byte[recordSize];
                                                        int initialAssembled = recordSize / 2;
                                                        int dataToWrite = recordSize - initialAssembled;
                                                        
                                                        // Set initial assembled data
                                                        assemLenField.set(tarOut, initialAssembled);
                                                        byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                        System.arraycopy(new byte[initialAssembled], 0, assemBuf, 0, initialAssembled);
                                                        
                                                        // Test
                                                        tarOut.write(testData, 0, dataToWrite);
                                                        
                                                        // Verify - should write exactly one full record
                                                        verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                        
                                                        // Verify assembly buffer was reset
                                                        assertEquals(0, assemLenField.get(tarOut));
                                                        
                                                        // Verify current bytes was incremented
                                                        assertEquals(recordSize, currBytesField.get(tarOut));
                                                    }

    @Test
                                           public void testWriteWithPartialRecordAndBufferOverflow() throws Exception {
                                               // Setup test data
                                               int recordSize = 512; // Default tar record size
                                               byte[] wBuf = new byte[600]; // Larger than record size
                                               java.util.Arrays.fill(wBuf, (byte)1); // Fill with test data
                                               
                                               // Mock dependencies
                                               OutputStream osMock = mock(OutputStream.class);
                                               
                                               // Create test instance
                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(osMock);
                                               
                                               // Use reflection to set private fields
                                               Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                               bufferField.setAccessible(true);
                                               Object bufferMock = mock(bufferField.getType());
                                               bufferField.set(tarOut, bufferMock);
                                               
                                               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                               assemLenField.setAccessible(true);
                                               assemLenField.set(tarOut, 300); // Partial record exists
                                               
                                               Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                               assemBufField.setAccessible(true);
                                               assemBufField.set(tarOut, new byte[recordSize]);
                                               
                                               Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                               recordBufField.setAccessible(true);
                                               recordBufField.set(tarOut, new byte[recordSize]);
                                               
                                               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                               currBytesField.setAccessible(true);
                                               currBytesField.set(tarOut, 0);
                                               
                                               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                               currSizeField.setAccessible(true);
                                               currSizeField.set(tarOut, 2000); // Large enough to not trigger size check
                                               
                                               // Test write operation that should trigger the mutated code path
                                               tarOut.write(wBuf, 0, 400); // Total write (300+400) > recordSize
                                               
                                               // Verify behavior that would catch the mutant
                                               // Correct behavior: should write one full record (512 bytes) and leave 188 bytes in assembly
                                               // Mutant behavior: would try to write 812 bytes (300+512) causing array bounds issues
                                               
                                               // Verify one full record was written to the output stream
                                               verify(osMock, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                               
                                               // Verify correct number of bytes were accounted for
                                               assertEquals(512, currBytesField.getInt(tarOut)); // Should have written one full record
                                               
                                               // Verify remaining bytes are properly handled
                                               assertEquals(188, assemLenField.getInt(tarOut)); // 300 + 400 - 512 = 188 bytes remaining
                                               
                                               // Verify correct offset advancement
                                               // Original would advance by 212 (512-300), mutant would advance by -188 (300+512-400)
                                               // But mutant would fail earlier with array bounds exception
                                           }

    @Test
                                      public void testWrite_DetectsCurrBytesMutation1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                          // Setup
                                          OutputStream mockOut = mock(OutputStream.class);
                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                          
                                          // Use reflection to set up test conditions
                                          Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                          bufferField.setAccessible(true);
                                          Object buffer = bufferField.get(tarOut);
                                          
                                          Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                          recordBufField.setAccessible(true);
                                          byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                          int recordSize = recordBuf.length;
                                          
                                          Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                          assemLenField.setAccessible(true);
                                          assemLenField.set(tarOut, recordSize - 10); // Nearly full assembly buffer
                                          
                                          Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                          currBytesField.setAccessible(true);
                                          long initialBytes = 100;
                                          currBytesField.set(tarOut, initialBytes);
                                          
                                          // Test data - will trigger the mutated code path
                                          byte[] testData = new byte[20]; // Enough to fill buffer and trigger write
                                          int offset = 0;
                                          
                                          // Execute
                                          tarOut.write(testData, offset, testData.length);
                                          
                                          // Verify
                                          long finalBytes = (long) currBytesField.get(tarOut);
                                          // Original should be initial + recordSize, mutant would be initial - recordSize
                                          assertEquals("currBytes should increase by record size", 
                                                      initialBytes + recordSize, 
                                                      finalBytes);
                                          
                                          // Verify output stream interaction
                                          verify(mockOut).write(any(byte[].class), anyInt(), anyInt());
                                      }

    @Test
                             public void testWriteUpdatesOffsetCorrectlyWhenCompletingRecord() throws Exception {
                                 // Setup test data
                                 byte[] testData = new byte[1024]; // Larger than record size
                                 java.util.Arrays.fill(testData, (byte)1); // Fill with dummy data
                                 int initialOffset = 100;
                                 int writeSize = 512; // Should trigger record completion
                                 
                                 // Create output stream that we can inspect
                                 ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(byteOut);
                                 
                                 // Use reflection to set private fields
                                 java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                 assemLenField.setAccessible(true);
                                 assemLenField.set(tarOut, 200); // Existing assembled data
                                 
                                 java.lang.reflect.Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                 currBytesField.setAccessible(true);
                                 currBytesField.set(tarOut, 0);
                                 
                                 java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                 currSizeField.setAccessible(true);
                                 currSizeField.set(tarOut, Long.MAX_VALUE); // Avoid size limit
                                 
                                 // Create spy to verify behavior
                                 ByteArrayOutputStream mockOut = new ByteArrayOutputStream();
                                 TarArchiveOutputStream spyTarOut = spy(new TarArchiveOutputStream(mockOut));
                                 
                                 // Copy the needed fields to spy
                                 assemLenField.set(spyTarOut, 200);
                                 currBytesField.set(spyTarOut, 0);
                                 currSizeField.set(spyTarOut, Long.MAX_VALUE);
                                 
                                 // Record initial offset
                                 int originalOffset = initialOffset;
                                 
                                 // Perform write
                                 spyTarOut.write(testData, initialOffset, writeSize);
                                 
                                 // Verify offset was increased correctly
                                 int recordSize = spyTarOut.getRecordSize();
                                 int assemLen = (int)assemLenField.get(spyTarOut);
                                 int expectedOffsetIncrease = recordSize - assemLen;
                                 
                                 assertEquals("Write offset should increase by record length minus assembled length",
                                            originalOffset + expectedOffsetIncrease,
                                            initialOffset + expectedOffsetIncrease);
                                 
                                 // Verify data was written by checking the output stream
                                 assertTrue("Output stream should contain written data", mockOut.size() > 0);
                             }

    @Test
                        public void testWriteWithPartialAssemblyBuffer() throws Exception {
                            // Setup
                            OutputStream mockOut = mock(OutputStream.class);
                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                            
                            // Get private fields via reflection
                            Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                            recordBufField.setAccessible(true);
                            byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                            int recordSize = recordBuf.length;
                            
                            Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                            assemLenField.setAccessible(true);
                            
                            Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                            assemBufField.setAccessible(true);
                            byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                            
                            Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                            currBytesField.setAccessible(true);
                            
                            // Set up initial state with partial assembly buffer
                            int initialAssemLen = recordSize / 2;
                            byte[] testData = new byte[recordSize]; // Enough to complete the record
                            
                            // Set initial assembly buffer state
                            assemLenField.set(tarOut, initialAssemLen);
                            System.arraycopy(new byte[initialAssemLen], 0, assemBuf, 0, initialAssemLen);
                            
                            // Set current entry info
                            TarArchiveEntry entry = new TarArchiveEntry("testEntry");
                            entry.setSize(recordSize * 2); // Enough space
                            tarOut.putArchiveEntry(entry);
                            
                            // Action - write exactly enough to complete the record
                            tarOut.write(testData, 0, recordSize - initialAssemLen);
                            
                            // Verification
                            // Should have written one complete record
                            verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                            
                            // Check assembly buffer is empty
                            assertEquals(0, assemLenField.get(tarOut));
                            
                            // Check bytes written counter
                            assertEquals(recordSize, currBytesField.get(tarOut));
                        }

    @Test
                   public void testWriteWithExactRecordSizeShouldNotLoopInfinitely() throws Exception {
                       // Setup
                       OutputStream mockOut = mock(OutputStream.class);
                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                       
                       // Set up test data that will exactly fill one record
                       int recordSize = tarOut.getRecordSize();
                       byte[] testData = new byte[recordSize];
                       java.util.Arrays.fill(testData, (byte)1);
                       
                       // Set current entry parameters
                       TarArchiveEntry entry = new TarArchiveEntry("test.txt");
                       entry.setSize(recordSize * 2); // Allow writing
                       tarOut.putArchiveEntry(entry);
                       
                       // Test the write operation
                       tarOut.write(testData, 0, recordSize);
                       
                       // Verify behavior - should write exactly one record
                       verify(mockOut, times(1)).write(any(byte[].class), anyInt(), eq(recordSize));
                       
                       // Verify internal state using reflection
                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                       currBytesField.setAccessible(true);
                       assertEquals(recordSize, currBytesField.get(tarOut));
                       
                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                       assemLenField.setAccessible(true);
                       assertEquals(0, assemLenField.get(tarOut));
                       
                       // Clean up
                       tarOut.closeArchiveEntry();
                   }

    @Test
              public void testWriteWithExactRecordSizeShouldWriteDirectly() throws Exception {
                  // Setup
                  OutputStream mockOut = mock(OutputStream.class);
                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                  
                  // Get record size through public method
                  int recordSize = tarOut.getRecordSize();
                  byte[] testData = new byte[recordSize];
                  
                  // Set initial state using reflection
                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                  currSizeField.setAccessible(true);
                  currSizeField.set(tarOut, recordSize * 2); // Allow writing
                  
                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                  assemLenField.setAccessible(true);
                  assemLenField.set(tarOut, 0);
                  
                  // Test - write exactly one record's worth of data
                  tarOut.write(testData, 0, recordSize);
                  
                  // Verify behavior through output stream interactions
                  verify(mockOut, times(1)).write(testData, 0, recordSize);
                  
                  // Verify internal state through reflection
                  assertEquals(0, assemLenField.getInt(tarOut)); // Nothing should be in assembly buffer
                  
                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                  currBytesField.setAccessible(true);
                  assertEquals(recordSize, currBytesField.getInt(tarOut)); // Bytes written should increase
              }

    @Test
          public void testWriteMultipleCompleteRecordsAccumulatesBytesCorrectly() throws Exception {
              // Setup
              ByteArrayOutputStream baos = new ByteArrayOutputStream();
              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
              
              // Set up a test entry
              ArchiveEntry entry = mock(ArchiveEntry.class);
              when(entry.getSize()).thenReturn(1024L); // Large enough for our test
              tarOut.putArchiveEntry(entry);
              
              // Prepare test data - need enough to trigger multiple writes
              int recordSize = tarOut.getRecordSize();
              byte[] data = new byte[recordSize * 3]; // 3 full records
              
              // Write the data
              tarOut.write(data, 0, data.length);
              
              // Verify currBytes was accumulated correctly
              Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
              currBytesField.setAccessible(true);
              long actualBytes = (long) currBytesField.get(tarOut);
              
              assertEquals("currBytes should accumulate all written bytes", 
                           data.length, actualBytes);
              
              tarOut.closeArchiveEntry();
          }

    @Test
    public void testWrite_DetectsNumToWriteMutation() throws IOException, NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        // Setup
        OutputStream mockOut = mock(OutputStream.class);
        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
        
        // Use reflection to access buffer and set up test conditions
        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
        bufferField.setAccessible(true);
        Object buffer = bufferField.get(tarOut);
        
        Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
        recordBufField.setAccessible(true);
        byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
        int recordSize = recordBuf.length;
        
        // Test data - write 3 full records plus partial
        byte[] testData = new byte[recordSize * 3 + 10];
        java.util.Arrays.fill(testData, (byte)1);
        
        // Set current entry parameters
        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
        currSizeField.setAccessible(true);
        currSizeField.set(tarOut, testData.length * 2L); // Plenty of space
        
        // Execute
        tarOut.write(testData, 0, testData.length);
        
        // Verify - should write 3 full records
        Method writeRecordMethod = buffer.getClass().getDeclaredMethod("writeRecord", byte[].class);
        writeRecordMethod.setAccessible(true);
        
        // Verify final state
        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
        currBytesField.setAccessible(true);
        assertEquals(recordSize * 3, currBytesField.get(tarOut));
        
        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
        assemLenField.setAccessible(true);
        assertEquals(10, assemLenField.get(tarOut));
    }


}
