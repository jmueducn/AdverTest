package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                public void testSetName_NullName() throws Exception {
                                                                                                                    // Create entry using public constructor
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, (String)null);
                                                                                                                    
                                                                                                                    assertNull(entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_EmptyName() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, "");
                                                                                                                    assertEquals("", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_NonFatPlatform() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                    
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "path\\\\to\\\\file");
                                                                                                                    
                                                                                                                    assertEquals("path\\\\to\\\\file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_FatPlatformWithForwardSlashes() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                                                                                                    
                                                                                                                    // Use reflection to call protected setPlatform method
                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to call protected setName method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, "path/to/file");
                                                                                                                    
                                                                                                                    assertEquals("path/to/file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_FatPlatformWithBackslashes() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setPlatform method
                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, "path\\\\to\\\\file");
                                                                                                                    
                                                                                                                    assertEquals("path/to/file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_FatPlatformWithMixedSlashes() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                                                                                                    
                                                                                                                    // Use reflection to set platform
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to set name
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "path\\\\to/file");
                                                                                                                    
                                                                                                                    assertEquals("path/to/file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_FatPlatformWithExistingForwardSlash() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to set platform
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to set name
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "path/to\\\\file");
                                                                                                                    
                                                                                                                    assertEquals("path/to\\\\file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_NonFatPlatformWithBackslashes() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to call protected setPlatform method
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                    
                                                                                                                    // Use reflection to call protected setName method
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "path\\\\to\\\\file");
                                                                                                                    
                                                                                                                    assertEquals("path\\\\to\\\\file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_ThroughConstructor() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test\\\\file.txt");
                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    assertEquals("test/file.txt", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_UnicodeCharacters() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setPlatform method
                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, "中文\\\\文件.txt");
                                                                                                                    
                                                                                                                    assertEquals("中文/文件.txt", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_MultipleConsecutiveBackslashes() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setPlatform method
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "path\\\\\\\\to\\\\\\\\file");
                                                                                                                    
                                                                                                                    assertEquals("path//to//file", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_OnlyBackslash() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setPlatform method
                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, "\\\\");
                                                                                                                    
                                                                                                                    assertEquals("/", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_OnlyForwardSlash() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setPlatform method
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "/");
                                                                                                                    
                                                                                                                    assertEquals("/", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_BackslashAtStart() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "\\\\file.txt");
                                                                                                                    
                                                                                                                    assertEquals("/file.txt", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetName_BackslashAtEnd() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    
                                                                                                                    // Use reflection to access protected setPlatform method
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                    setName.setAccessible(true);
                                                                                                                    setName.invoke(entry, "file.txt\\\\");
                                                                                                                    
                                                                                                                    assertEquals("file.txt/", entry.getName());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_NormalValues() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    String name = "testFile.txt";
                                                                                                                    byte[] rawName = name.getBytes();
                                                                                                                    
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                        "setName", String.class, byte[].class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Name should be set correctly", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should be set correctly", rawName, entry.getRawName());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_EmptyName() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    String name = "";
                                                                                                                    byte[] rawName = name.getBytes();
                                                                                                                    
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                        "setName", String.class, byte[].class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Empty name should be allowed", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should match empty string", rawName, entry.getRawName());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_NullRawName() throws Exception {
                                                                                                                    String name = "testFile.txt";
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry(name);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                        "setName", String.class, byte[].class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, name, null);
                                                                                                                    
                                                                                                                    assertEquals("Name should be set correctly", name, entry.getName());
                                                                                                                    assertNull("Raw name should be null", entry.getRawName());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_UnicodeCharacters() throws Exception {
                                                                                                                    String name = "测试文件.txt";
                                                                                                                    byte[] rawName = name.getBytes();
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry(name);
                                                                                                                    
                                                                                                                    // Use reflection to access protected setName(String, byte[]) method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                        "setName", String.class, byte[].class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Unicode name should be preserved", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should match unicode bytes", rawName, entry.getRawName());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_LongName() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                                                                                                    StringBuilder longNameBuilder = new StringBuilder();
                                                                                                                    for (int i = 0; i < 1000; i++) {
                                                                                                                        longNameBuilder.append("a");
                                                                                                                    }
                                                                                                                    String name = longNameBuilder.toString();
                                                                                                                    byte[] rawName = name.getBytes();
                                                                                                                    
                                                                                                                    // Use reflection to access protected method
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                        "setName", String.class, byte[].class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Long name should be preserved", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should match long name bytes", rawName, entry.getRawName());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_DirectoryPath() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("");
                                                                                                                    String name = "path/to/directory/";
                                                                                                                    byte[] rawName = name.getBytes();
                                                                                                                    
                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                        "setName", String.class, byte[].class);
                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                    setNameMethod.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Directory path should be preserved", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should match directory path bytes", rawName, entry.getRawName());
                                                                                                                    assertTrue("Entry should be recognized as directory", entry.isDirectory());
                                                                                                                }

    @Test
                                                                                                                public void testSetNameWithRawName_PlatformSpecificEncoding() throws Exception {
                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                    String name = "testFile.txt";
                                                                                                                    byte[] rawName = name.getBytes();
                                                                                                                    
                                                                                                                    // Get protected methods via reflection
                                                                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    Method setNameWithRaw = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                    setPlatform.setAccessible(true);
                                                                                                                    setNameWithRaw.setAccessible(true);
                                                                                                                    
                                                                                                                    // Set platform to UNIX
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                    setNameWithRaw.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Name should be set correctly on UNIX platform", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should match on UNIX platform", rawName, entry.getRawName());
                                                                                                                    
                                                                                                                    // Set platform to FAT
                                                                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    setNameWithRaw.invoke(entry, name, rawName);
                                                                                                                    
                                                                                                                    assertEquals("Name should be set correctly on FAT platform", name, entry.getName());
                                                                                                                    assertArrayEquals("Raw name should match on FAT platform", rawName, entry.getRawName());
                                                                                                                }

    @Test
                                                                                                        public void testSetNameWithRawName_NullName() throws Exception {
                                                                                                            // Create entry using accessible constructor
                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                            byte[] rawName = "test".getBytes();
                                                                                                            
                                                                                                            // Get the protected method via reflection
                                                                                                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                "setName", String.class, byte[].class);
                                                                                                            setNameMethod.setAccessible(true);
                                                                                                            
                                                                                                            // Invoke the method with null name
                                                                                                            setNameMethod.invoke(entry, null, rawName);
                                                                                                        }

    @Test
                                                                                                   public void testSetNameWithBothSlashesShouldConvertBackslashes() throws Exception {
                                                                                                       // Setup
                                                                                                       ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                       
                                                                                                       // Use reflection to set platform to FAT
                                                                                                       Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                       setPlatformMethod.setAccessible(true);
                                                                                                       setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                       
                                                                                                       // Test name with both forward and back slashes
                                                                                                       String testName = "path\\\\with/both\\\\slashes";
                                                                                                       String expectedName = "path/with/both/slashes";
                                                                                                       
                                                                                                       // Use reflection to set name
                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                       setNameMethod.setAccessible(true);
                                                                                                       setNameMethod.invoke(entry, testName);
                                                                                                       
                                                                                                       // Verify
                                                                                                       assertEquals("Backslashes should be converted even when forward slashes exist", 
                                                                                                                   expectedName, entry.getName());
                                                                                                   }

    @Test
                                                                                                   public void testSetNameWithForwardSlashShouldSetRawName() throws Exception {
                                                                                                       // Arrange
                                                                                                       String nameWithForwardSlash = "path/to/file.txt";
                                                                                                       ZipArchiveEntry entry = new ZipArchiveEntry(nameWithForwardSlash);
                                                                                                       byte[] expectedRawName = nameWithForwardSlash.getBytes();
                                                                                                       
                                                                                                       // Use reflection to access protected setName method
                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                           "setName", String.class, byte[].class);
                                                                                                       setNameMethod.setAccessible(true);
                                                                                                       
                                                                                                       // Act
                                                                                                       setNameMethod.invoke(entry, nameWithForwardSlash, expectedRawName);
                                                                                                       
                                                                                                       // Assert
                                                                                                       assertArrayEquals("Raw name should be set when name contains forward slash", 
                                                                                                                        expectedRawName, entry.getRawName());
                                                                                                   }

    @Test
                                                                                                   public void testSetNameWithBackslashShouldNotSetRawName() throws Exception {
                                                                                                       // Arrange
                                                                                                       ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                       String nameWithBackslash = "path\\\\to\\\\file.txt";
                                                                                                       byte[] rawName = nameWithBackslash.getBytes();
                                                                                                       
                                                                                                       // Get the protected setName method via reflection
                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                           "setName", String.class, byte[].class);
                                                                                                       setNameMethod.setAccessible(true);
                                                                                                       
                                                                                                       // Act
                                                                                                       setNameMethod.invoke(entry, nameWithBackslash, rawName);
                                                                                                       
                                                                                                       // Assert
                                                                                                       assertNull("Raw name should not be set when name contains backslash", 
                                                                                                                 entry.getRawName());
                                                                                                   }

    @Test
                                                                                              public void testSetNameWithSlashInMiddleShouldReplaceBackslashes() {
                                                                                                  // Setup
                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                  
                                                                                                  // Need to set platform to FAT - assuming there's a way to do this
                                                                                                  // Since setPlatform is protected, we'll use reflection
                                                                                                  try {
                                                                                                      Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                      setPlatform.setAccessible(true);
                                                                                                      setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to set platform via reflection");
                                                                                                  }
                                                                                                  
                                                                                                  // Get the protected setName method
                                                                                                  Method setNameMethod;
                                                                                                  try {
                                                                                                      setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                      setNameMethod.setAccessible(true);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to get setName method via reflection");
                                                                                                      return;
                                                                                                  }
                                                                                                  
                                                                                                  // Test case that will detect the mutant
                                                                                                  String nameWithSlashInMiddle = "path\\\\to\\\\file/name";
                                                                                                  try {
                                                                                                      setNameMethod.invoke(entry, nameWithSlashInMiddle);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to invoke setName");
                                                                                                  }
                                                                                                  
                                                                                                  // Verify - original would replace backslashes, mutant wouldn't
                                                                                                  assertEquals("path/to/file/name", entry.getName());
                                                                                                  
                                                                                                  // Additional test case for name starting with slash
                                                                                                  String nameStartingWithSlash = "/path\\\\to\\\\file";
                                                                                                  try {
                                                                                                      setNameMethod.invoke(entry, nameStartingWithSlash);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to invoke setName");
                                                                                                  }
                                                                                                  
                                                                                                  // Verify - original wouldn't modify, mutant would
                                                                                                  assertEquals("/path\\\\to\\\\file", entry.getName());
                                                                                                  
                                                                                                  // Test case without any slashes (same behavior)
                                                                                                  String nameWithoutSlashes = "path\\\\to\\\\file";
                                                                                                  try {
                                                                                                      setNameMethod.invoke(entry, nameWithoutSlashes);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to invoke setName");
                                                                                                  }
                                                                                                  assertEquals("path/to/file", entry.getName());
                                                                                              }

    @Test
                                                                                              public void testSetNameWithDifferentSlashPositions() throws Exception {
                                                                                                  // Create test entry using public constructor
                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                                                                                  
                                                                                                  // Get the protected setName(String, byte[]) method via reflection
                                                                                                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                      "setName", String.class, byte[].class);
                                                                                                  setNameMethod.setAccessible(true);
                                                                                                  
                                                                                                  // Test case 1: Name without any slashes - should pass both original and mutant
                                                                                                  setNameMethod.invoke(entry, "validName", "validName".getBytes());
                                                                                                  assertEquals("validName", entry.getName());
                                                                                                  
                                                                                                  // Test case 2: Name starting with slash - should fail both original and mutant
                                                                                                  try {
                                                                                                      setNameMethod.invoke(entry, "/invalidName", "/invalidName".getBytes());
                                                                                                      fail("Should have thrown IllegalArgumentException for name starting with slash");
                                                                                                  } catch (InvocationTargetException e) {
                                                                                                      assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                                                                  }
                                                                                                  
                                                                                                  // Test case 3: Name with slash not at start - this catches the mutant
                                                                                                  // Original would reject, mutant would accept
                                                                                                  try {
                                                                                                      setNameMethod.invoke(entry, "invalid/Name", "invalid/Name".getBytes());
                                                                                                      fail("Should have thrown IllegalArgumentException for name containing slash");
                                                                                                  } catch (InvocationTargetException e) {
                                                                                                      assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                                                                  }
                                                                                              }

    @Test
                                                                                         public void testSetName_BackslashConversionOnFATPlatform() throws Exception {
                                                                                             // Setup
                                                                                             ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                             
                                                                                             // Use reflection to access protected setPlatform method
                                                                                             Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                             setPlatform.setAccessible(true);
                                                                                             setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                             
                                                                                             // Test input with backslashes
                                                                                             String inputName = "path\\\\to\\\\file.txt";
                                                                                             String expectedName = "path/to/file.txt";
                                                                                             
                                                                                             // Use reflection to access protected setName method
                                                                                             Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                             setName.setAccessible(true);
                                                                                             setName.invoke(entry, inputName);
                                                                                             
                                                                                             // Verify
                                                                                             assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                                                                         expectedName, entry.getName());
                                                                                             
                                                                                             // Additional verification that no conversion happens when '/' is present
                                                                                             String inputWithSlash = "path/to\\\\file.txt";
                                                                                             setName.invoke(entry, inputWithSlash);
                                                                                             assertEquals("No conversion should happen when name contains forward slash",
                                                                                                         inputWithSlash, entry.getName());
                                                                                         }

    @Test
                                                                                         public void testSetNamePathSeparatorConversion() throws Exception {
                                                                                             // Get the protected setName method via reflection
                                                                                             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                             setNameMethod.setAccessible(true);
                                                                                             
                                                                                             // Test backslash conversion (original should convert to forward slash)
                                                                                             ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                             setNameMethod.invoke(entry1, "folder\\\\subfolder\\\\file.txt", null);
                                                                                             assertEquals("folder/subfolder/file.txt", entry1.getName());
                                                                                             
                                                                                             // Test forward slash remains unchanged
                                                                                             ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                                             setNameMethod.invoke(entry2, "folder/subfolder/file.txt", null);
                                                                                             assertEquals("folder/subfolder/file.txt", entry2.getName());
                                                                                             
                                                                                             // Test mixed slashes
                                                                                             ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                                                                             setNameMethod.invoke(entry3, "folder\\\\subfolder/file.txt", null);
                                                                                             assertEquals("folder/subfolder/file.txt", entry3.getName());
                                                                                             
                                                                                             // Test multiple consecutive backslashes
                                                                                             ZipArchiveEntry entry4 = new ZipArchiveEntry("dummy");
                                                                                             setNameMethod.invoke(entry4, "folder\\\\\\\\subfolder\\\\\\\\file.txt", null);
                                                                                             assertEquals("folder//subfolder//file.txt", entry4.getName());
                                                                                             
                                                                                             // Test empty name
                                                                                             ZipArchiveEntry entry5 = new ZipArchiveEntry("dummy");
                                                                                             setNameMethod.invoke(entry5, "", null);
                                                                                             assertEquals("", entry5.getName());
                                                                                         }

    @Test
                                                                                    public void testSetNameShouldConvertBackslashesToForwardSlashesOnFatPlatform() throws Exception {
                                                                                        // Setup
                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                        
                                                                                        // Use reflection to access protected setPlatform method
                                                                                        Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                        setPlatformMethod.setAccessible(true);
                                                                                        setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                        
                                                                                        // Input with backslashes
                                                                                        String inputName = "path\\\\to\\\\file.txt";
                                                                                        String expectedName = "path/to/file.txt";
                                                                                        
                                                                                        // Use reflection to access protected setName method
                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                        setNameMethod.setAccessible(true);
                                                                                        setNameMethod.invoke(entry, inputName);
                                                                                        
                                                                                        // Verify
                                                                                        assertEquals("Backslashes should be converted to forward slashes", 
                                                                                                    expectedName, 
                                                                                                    entry.getName());
                                                                                    }

    @Test
                                                                                    public void testSetNameShouldConvertBackslashesToForwardSlashes() throws Exception {
                                                                                        // Create test entry using accessible constructor
                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                                                                        
                                                                                        // Test with Windows-style path
                                                                                        String windowsPath = "dir\\\\subdir\\\\file.txt";
                                                                                        String expectedUnixPath = "dir/subdir/file.txt";
                                                                                        byte[] rawName = new byte[0]; // rawName content not relevant for this test
                                                                                        
                                                                                        // Get the protected method via reflection
                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                            "setName", String.class, byte[].class);
                                                                                        setNameMethod.setAccessible(true);
                                                                                        
                                                                                        // Call the method via reflection
                                                                                        setNameMethod.invoke(entry, windowsPath, rawName);
                                                                                        
                                                                                        // Verify the name has been converted
                                                                                        assertEquals("Backslashes should be converted to forward slashes", 
                                                                                                    expectedUnixPath, 
                                                                                                    entry.getName());
                                                                                        
                                                                                        // Verify rawName was set
                                                                                        assertSame("rawName should be set as provided", 
                                                                                                  rawName, 
                                                                                                  entry.getRawName());
                                                                                    }

    @Test
                                                                               public void testSetNameShouldReplaceBackslashesWithForwardSlashesOnFatPlatform() throws Exception {
                                                                                   // Setup
                                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                   
                                                                                   // Use reflection to access protected setPlatform method
                                                                                   Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                   setPlatformMethod.setAccessible(true);
                                                                                   setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                   
                                                                                   // Test input with backslashes
                                                                                   String inputName = "path\\\\to\\\\file";
                                                                                   String expectedName = "path/to/file";
                                                                                   
                                                                                   // Use reflection to access protected setName method
                                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                   setNameMethod.setAccessible(true);
                                                                                   setNameMethod.invoke(entry, inputName);
                                                                                   
                                                                                   // Verify
                                                                                   assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                                                               expectedName, entry.getName());
                                                                               }

    @Test
                                                                               public void testSetNameWithBackslashes() throws Exception {
                                                                                   // Create test input with backslashes
                                                                                   String inputName = "path\\\\to\\\\file.txt";
                                                                                   byte[] rawName = new byte[0];
                                                                                   
                                                                                   // Create entry using public constructor
                                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                                                                   
                                                                                   // Get the protected setName method via reflection
                                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                       "setName", String.class, byte[].class);
                                                                                   setNameMethod.setAccessible(true);
                                                                                   
                                                                                   // Set name using reflection
                                                                                   setNameMethod.invoke(entry, inputName, rawName);
                                                                                   
                                                                                   // Verify the name was properly converted
                                                                                   String expectedName = "path/to/file.txt";
                                                                                   String actualName = entry.getName();
                                                                                   
                                                                                   // This assertion will fail for the mutant (would get "path.to.file.txt")
                                                                                   assertEquals("Backslashes should be converted to forward slashes", 
                                                                                               expectedName, actualName);
                                                                                   
                                                                                   // Additional test cases for edge conditions
                                                                                   // Test empty string
                                                                                   setNameMethod.invoke(entry, "", rawName);
                                                                                   assertEquals("Empty name should remain empty", "", entry.getName());
                                                                                   
                                                                                   // Test name with no backslashes
                                                                                   setNameMethod.invoke(entry, "normal/path.txt", rawName);
                                                                                   assertEquals("Normal path should remain unchanged", 
                                                                                               "normal/path.txt", entry.getName());
                                                                                   
                                                                                   // Test multiple consecutive backslashes
                                                                                   setNameMethod.invoke(entry, "path\\\\\\\\to\\\\\\\\file.txt", rawName);
                                                                                   assertEquals("Multiple backslashes should all be converted",
                                                                                               "path//to//file.txt", entry.getName());
                                                                                   
                                                                                   // Test backslash at start/end
                                                                                   setNameMethod.invoke(entry, "\\\\path\\\\to\\\\file\\\\", rawName);
                                                                                   assertEquals("Edge backslashes should be converted",
                                                                                               "/path/to/file/", entry.getName());
                                                                               }

    @Test
                                                                          public void testSetNameWithBackslashesOnFatPlatform() throws Exception {
                                                                              // Setup - use public constructor
                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                              
                                                                              // Use reflection to access protected setPlatform method
                                                                              Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                              setPlatformMethod.setAccessible(true);
                                                                              setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                              
                                                                              // Input with backslashes
                                                                              String inputName = "path\\\\to\\\\file.txt";
                                                                              
                                                                              // Expected output (forward slashes)
                                                                              String expectedName = "path/to/file.txt";
                                                                              
                                                                              // Use reflection to access protected setName method
                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                              setNameMethod.setAccessible(true);
                                                                              setNameMethod.invoke(entry, inputName);
                                                                              
                                                                              // Verify
                                                                              assertEquals("Backslashes should be converted to forward slashes", 
                                                                                          expectedName, entry.getName());
                                                                          }

    @Test
                                                                          public void testSetNameWithBackslashes1() throws Exception {
                                                                              // Test case to detect the path separator mutation
                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                                                              String testName = "path\\\\to\\\\file.txt";
                                                                              byte[] rawName = new byte[0];
                                                                              
                                                                              // Get the protected setName method via reflection
                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                  "setName", String.class, byte[].class);
                                                                              setNameMethod.setAccessible(true);
                                                                              
                                                                              // Call the method under test
                                                                              setNameMethod.invoke(entry, testName, rawName);
                                                                              
                                                                              // Verify the name was properly converted
                                                                              String expectedName = "path/to/file.txt";
                                                                              String actualName = entry.getName();
                                                                              
                                                                              // This assertion will fail if the mutant is present (would get "path to file.txt")
                                                                              assertEquals("Backslashes should be converted to forward slashes", 
                                                                                          expectedName, 
                                                                                          actualName);
                                                                              
                                                                              // Additional test cases for thoroughness
                                                                              // Case with multiple consecutive backslashes
                                                                              setNameMethod.invoke(entry, "path\\\\\\\\to\\\\\\\\\\\\file.txt", rawName);
                                                                              assertEquals("path//to///file.txt", entry.getName());
                                                                              
                                                                              // Case with mixed slashes
                                                                              setNameMethod.invoke(entry, "path\\\\to/file.txt", rawName);
                                                                              assertEquals("path/to/file.txt", entry.getName());
                                                                              
                                                                              // Case with no backslashes
                                                                              setNameMethod.invoke(entry, "path/to/file.txt", rawName);
                                                                              assertEquals("path/to/file.txt", entry.getName());
                                                                              
                                                                              // Case with only backslashes
                                                                              setNameMethod.invoke(entry, "\\\\\\\\\\\\", rawName);
                                                                              assertEquals("///", entry.getName());
                                                                          }

    @Test
                                                                     public void testSetNameWithBackslashesOnFatPlatform1() throws Exception {
                                                                         // Setup
                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                         
                                                                         // Use reflection to access protected setPlatform method
                                                                         Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                         setPlatform.setAccessible(true);
                                                                         setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                         
                                                                         // Test input with backslashes
                                                                         String inputName = "path\\\\to\\\\file.txt";
                                                                         String expectedName = "path/to/file.txt";
                                                                         
                                                                         // Use reflection to access protected setName method
                                                                         Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                         setName.setAccessible(true);
                                                                         setName.invoke(entry, inputName);
                                                                         
                                                                         // Verify
                                                                         assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                                                    expectedName, entry.getName());
                                                                         
                                                                         // Additional verification that no null characters exist
                                                                         assertFalse("Name should not contain null characters",
                                                                                    entry.getName().contains("\0"));
                                                                     }

    @Test
                                                                     public void testSetNameWithBackslashes2() throws Exception {
                                                                         // Create test data
                                                                         String inputName = "folder\\\\subfolder\\\\file.txt";
                                                                         byte[] rawName = new byte[0];
                                                                         
                                                                         // Expected result after proper backslash replacement
                                                                         String expectedName = "folder/subfolder/file.txt";
                                                                         
                                                                         // Create and test the entry
                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use public constructor
                                                                         
                                                                         // Use reflection to access protected setName method
                                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                             "setName", String.class, byte[].class);
                                                                         setNameMethod.setAccessible(true);
                                                                         setNameMethod.invoke(entry, inputName, rawName);
                                                                         
                                                                         // Verify the name was properly processed
                                                                         assertEquals("Backslashes should be replaced with forward slashes", 
                                                                                     expectedName, entry.getName());
                                                                         
                                                                         // Additional verification that no null characters were introduced
                                                                         assertFalse("Name should not contain null characters",
                                                                                   entry.getName().contains("\\0"));
                                                                     }

    @Test
                                                                     public void testSetNameWithMultipleBackslashes() {
                                                                         // Test case with multiple consecutive backslashes
                                                                         String inputName = "folder\\\\\\\\subfolder\\\\\\\\\\\\file.txt";
                                                                         byte[] rawName = new byte[0];
                                                                         
                                                                         String expectedName = "folder//subfolder///file.txt";
                                                                         
                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                         
                                                                         try {
                                                                             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                 "setName", String.class, byte[].class);
                                                                             setNameMethod.setAccessible(true);
                                                                             setNameMethod.invoke(entry, inputName, rawName);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to invoke protected setName method via reflection");
                                                                         }
                                                                         
                                                                         assertEquals("Multiple backslashes should all be replaced",
                                                                                     expectedName, entry.getName());
                                                                         
                                                                         assertFalse("Name should not contain null characters",
                                                                                   entry.getName().contains("\\0"));
                                                                     }

    @Test
                                                                public void testSetName_ShouldReplaceBackslashesOnFatPlatform() {
                                                                    // Setup
                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                    
                                                                    // Set platform to FAT (need to use reflection since setPlatform is protected)
                                                                    try {
                                                                        Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                        setPlatform.setAccessible(true);
                                                                        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set platform via reflection");
                                                                    }
                                                                    
                                                                    String inputName = "path\\\\to\\\\file";
                                                                    String expectedName = "path/to/file";
                                                                    
                                                                    // Test (need to use reflection since setName is protected)
                                                                    try {
                                                                        Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                        setName.setAccessible(true);
                                                                        setName.invoke(entry, inputName);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set name via reflection");
                                                                    }
                                                                    
                                                                    // Verify
                                                                    assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                                               expectedName, entry.getName());
                                                                }

    @Test
                                                                public void testSetNameWithRawNameShouldHandlePlatformFatCorrectly() throws Exception {
                                                                    // Setup
                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                    
                                                                    // Use reflection to access protected setPlatform method
                                                                    Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                    setPlatform.setAccessible(true);
                                                                    // Set platform to FAT to trigger the condition
                                                                    setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                    
                                                                    String name = "test.txt";
                                                                    byte[] rawName = new byte[]{'t', 'e', 's', 't', '.', 't', 'x', 't'};
                                                                    
                                                                    // Use reflection to access protected setName method
                                                                    Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                    setName.setAccessible(true);
                                                                    // Execute
                                                                    setName.invoke(entry, name, rawName);
                                                                    
                                                                    // Verify
                                                                    // In original code, rawName should be set directly
                                                                    // In mutated code (with && false), rawName might not be set properly
                                                                    assertArrayEquals("Raw name should be set correctly", 
                                                                                     rawName, 
                                                                                     entry.getRawName());
                                                                    assertEquals("Name should be set correctly", 
                                                                                name, 
                                                                                entry.getName());
                                                                    
                                                                    // Additional verification that platform FAT behavior is correct
                                                                    assertEquals("Platform should remain FAT", 
                                                                                ZipArchiveEntry.PLATFORM_FAT, 
                                                                                entry.getPlatform());
                                                                }

    @Test
                                                           public void testSetNameWithBackslashesOnFatPlatform2() throws Exception {
                                                               // Setup
                                                               ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                               
                                                               // Use reflection to set platform to FAT since setPlatform is protected
                                                               Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                                               platformField.setAccessible(true);
                                                               platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                               
                                                               // Test case where name has backslashes but no forward slashes
                                                               String nameWithBackslashes = "path\\\\to\\\\file";
                                                               
                                                               // Use reflection to call protected setName method
                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                               setNameMethod.setAccessible(true);
                                                               setNameMethod.invoke(entry, nameWithBackslashes);
                                                               
                                                               // Verify - original would replace backslashes, mutant wouldn't
                                                               String expected = "path/to/file"; // Original behavior
                                                               String actual = entry.getName();
                                                               assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                                           expected, actual);
                                                               
                                                               // Additional verification that the name was actually set
                                                               assertNotNull("Name should not be null", actual);
                                                           }

    @Test
                                                           public void testSetNameWithSlashShouldHandleDirectoryEntry() throws Exception {
                                                               // Setup
                                                               ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                                               String nameWithSlash = "path/to/file";
                                                               byte[] rawName = nameWithSlash.getBytes();
                                                               
                                                               // Get protected method via reflection
                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                   "setName", String.class, byte[].class);
                                                               setNameMethod.setAccessible(true);
                                                               
                                                               // Execute
                                                               setNameMethod.invoke(entry, nameWithSlash, rawName);
                                                               
                                                               // Verify
                                                               assertEquals("Name should be set exactly as provided", 
                                                                           nameWithSlash, entry.getName());
                                                               assertArrayEquals("Raw name should be set exactly as provided",
                                                                               rawName, entry.getRawName());
                                                               
                                                               // Additional check for directory handling
                                                               String directoryName = "directory/";
                                                               byte[] dirRawName = directoryName.getBytes();
                                                               setNameMethod.invoke(entry, directoryName, dirRawName);
                                                               assertTrue("Entry with trailing slash should be recognized as directory",
                                                                         entry.isDirectory());
                                                           }

    @Test
                                                      public void testSetNameWithBackslashesAndWhitespace() throws Exception {
                                                          // Setup
                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use public constructor
                                                          
                                                          // Use reflection to access protected setPlatform method
                                                          Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                          setPlatformMethod.setAccessible(true);
                                                          setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                          
                                                          // Test input with backslashes and whitespace
                                                          String inputName = "  test\\\\file.txt  ";
                                                          String expectedOriginal = "  test/file.txt  "; // Original preserves whitespace
                                                          String expectedMutant = "test/file.txt";       // Mutant trims whitespace
                                                          
                                                          // Use reflection to access protected setName method
                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                          setNameMethod.setAccessible(true);
                                                          setNameMethod.invoke(entry, inputName);
                                                          
                                                          // Verify
                                                          // This will fail if the mutant is present (trim is called)
                                                          assertEquals("Whitespace should be preserved when replacing backslashes", 
                                                                      expectedOriginal, entry.getName());
                                                          
                                                          // Additional verification that the name was set at all
                                                          assertNotNull("Name should not be null after setting", entry.getName());
                                                      }

    @Test
                                                      public void testSetNamePreservesWhitespace() throws Exception {
                                                          // Get the protected setName method via reflection
                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                              "setName", String.class, byte[].class);
                                                          setNameMethod.setAccessible(true);
                                                      
                                                          // Test with leading whitespace
                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                          String nameWithLeadingSpace = "  test.txt";
                                                          setNameMethod.invoke(entry1, nameWithLeadingSpace, nameWithLeadingSpace.getBytes());
                                                          assertEquals("Original should preserve leading space", 
                                                                      nameWithLeadingSpace, entry1.getName());
                                                      
                                                          // Test with trailing whitespace
                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                          String nameWithTrailingSpace = "test.txt  ";
                                                          setNameMethod.invoke(entry2, nameWithTrailingSpace, nameWithTrailingSpace.getBytes());
                                                          assertEquals("Original should preserve trailing space", 
                                                                      nameWithTrailingSpace, entry2.getName());
                                                      
                                                          // Test with both leading and trailing whitespace
                                                          ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                                          String nameWithSpaces = "  test.txt  ";
                                                          setNameMethod.invoke(entry3, nameWithSpaces, nameWithSpaces.getBytes());
                                                          assertEquals("Original should preserve all whitespace", 
                                                                      nameWithSpaces, entry3.getName());
                                                      
                                                          // Test with backslashes and whitespace
                                                          ZipArchiveEntry entry4 = new ZipArchiveEntry("dummy");
                                                          String nameWithBoth = "  test\\\\file.txt  ";
                                                          String expected = "  test/file.txt  "; // Only backslashes should be replaced
                                                          setNameMethod.invoke(entry4, nameWithBoth, nameWithBoth.getBytes());
                                                          assertEquals("Original should replace backslashes but preserve whitespace",
                                                                      expected, entry4.getName());
                                                      }

    @Test
                                                 public void testSetNameWithMixedSlashesShouldDetectMutant() throws Exception {
                                                     // Setup
                                                     ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use public constructor
                                                     
                                                     // Use reflection to access protected setPlatform method
                                                     Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                     setPlatformMethod.setAccessible(true);
                                                     setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                     
                                                     // Test case that would catch the mutant
                                                     String testName = "path\\\\with/both/slashes";
                                                     
                                                     // Use reflection to access protected setName method
                                                     Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                     setNameMethod.setAccessible(true);
                                                     setNameMethod.invoke(entry, testName);
                                                     
                                                     // Verify - should convert backslashes only if no forward slashes present (original behavior)
                                                     // The mutant would fail this assertion because it checks for backslashes instead
                                                     String expected = "path/with/both/slashes"; // Only backslashes should be converted
                                                     assertEquals("Name with mixed slashes should only convert backslashes", 
                                                                  expected, entry.getName());
                                                     
                                                     // Additional verification for clarity
                                                     assertTrue("Name should still contain forward slashes", 
                                                                entry.getName().contains("/"));
                                                 }

    @Test
                                                 public void testSetNameWithDifferentPathSeparators() throws Exception {
                                                     // Get the protected setName method via reflection
                                                     Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                         "setName", String.class, byte[].class);
                                                     setNameMethod.setAccessible(true);
                                                     
                                                     // Test with no slashes - should work in both original and mutant
                                                     ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                     setNameMethod.invoke(entry1, "testfile.txt", "testfile.txt".getBytes());
                                                     assertArrayEquals("testfile.txt".getBytes(), entry1.getRawName());
                                                     
                                                     // Test with forward slash - should work in original, mutant might fail
                                                     ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                     setNameMethod.invoke(entry2, "path/to/file.txt", "path/to/file.txt".getBytes());
                                                     assertArrayEquals("path/to/file.txt".getBytes(), entry2.getRawName());
                                                     
                                                     // Test with backslash - should fail in original, mutant might pass
                                                     // This is the key test to catch the mutant
                                                     try {
                                                         ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                                         setNameMethod.invoke(entry3, "path\\\\to\\\\file.txt", "path\\\\to\\\\file.txt".getBytes());
                                                         fail("Should have thrown IllegalArgumentException for backslashes");
                                                     } catch (InvocationTargetException e) {
                                                         // Expected behavior for original code
                                                         assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                         assertTrue(e.getCause().getMessage().contains("Invalid entry name"));
                                                     }
                                                     
                                                     // Test with mixed slashes - should fail
                                                     try {
                                                         ZipArchiveEntry entry4 = new ZipArchiveEntry("dummy");
                                                         setNameMethod.invoke(entry4, "path/to\\\\file.txt", "path/to\\\\file.txt".getBytes());
                                                         fail("Should have thrown IllegalArgumentException for mixed slashes");
                                                     } catch (InvocationTargetException e) {
                                                         // Expected behavior
                                                         assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                         assertTrue(e.getCause().getMessage().contains("Invalid entry name"));
                                                     }
                                                 }

    @Test
                                            public void testSetNameWithSlashNotAtStart() throws Exception {
                                                // Setup
                                                // Use reflection to access protected constructor
                                                Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                constructor.setAccessible(true);
                                                ZipArchiveEntry entry = constructor.newInstance();
                                                
                                                // Use reflection to set platform
                                                Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                setPlatform.setAccessible(true);
                                                setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                
                                                // Test case where name contains "/" but not at start
                                                String nameWithSlash = "path\\to\\file/name";
                                                String expected = "path/to/file/name";
                                                
                                                // Use reflection to set name
                                                Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                setName.setAccessible(true);
                                                setName.invoke(entry, nameWithSlash);
                                                
                                                // Verify
                                                // Original would replace all backslashes since "/" is not at start
                                                // Mutant would NOT replace backslashes since "/" is not at start (index != 0)
                                                assertEquals("Backslashes should be replaced when / is not at start", 
                                                            expected, entry.getName());
                                                
                                                // Additional verification that the name was set
                                                assertNotNull(entry.getName());
                                            }

    @Test
                                            public void testSetNameWithDifferentSlashPatterns() throws Exception {
                                                // Use reflection to access protected setName(String, byte[]) method
                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                setNameMethod.setAccessible(true);
                                                
                                                // Test name without any slashes (should be accepted by both original and mutated)
                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                setNameMethod.invoke(entry1, "testFile", "testFile".getBytes());
                                                assertEquals("testFile", entry1.getName());
                                                assertArrayEquals("testFile".getBytes(), entry1.getRawName());
                                            
                                                // Test name starting with slash (should be rejected by original, accepted by mutated)
                                                try {
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                    setNameMethod.invoke(entry2, "/testFile", "/testFile".getBytes());
                                                    // If we get here, the mutant survived (original would throw exception)
                                                    fail("Expected exception for name starting with slash");
                                                } catch (InvocationTargetException e) {
                                                    assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                }
                                            
                                                // Test name containing slash but not at start (should be rejected by original, accepted by mutated)
                                                try {
                                                    ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                                    setNameMethod.invoke(entry3, "test/File", "test/File".getBytes());
                                                    // If we get here, the mutant survived (original would throw exception)
                                                    fail("Expected exception for name containing slash");
                                                } catch (InvocationTargetException e) {
                                                    assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                }
                                            
                                                // Test name with multiple slashes (should be rejected by original, accepted by mutated if any starts with slash)
                                                try {
                                                    ZipArchiveEntry entry4 = new ZipArchiveEntry("dummy");
                                                    setNameMethod.invoke(entry4, "test/File/Path", "test/File/Path".getBytes());
                                                    // If we get here, the mutant survived (original would throw exception)
                                                    fail("Expected exception for name containing multiple slashes");
                                                } catch (InvocationTargetException e) {
                                                    assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                }
                                            }

    @Test
                                       public void testSetName_BackslashConversionOnFatPlatform() throws Exception {
                                           // Setup
                                           ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                           
                                           // Use reflection to set platform to FAT since setPlatform is protected
                                           Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                           platformField.setAccessible(true);
                                           platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                           
                                           // Test input with backslashes
                                           String inputName = "path\\\\to\\\\file.txt";
                                           String expectedName = "path/to/file.txt";
                                           
                                           // Execute - use reflection to call protected setName method
                                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                           setNameMethod.setAccessible(true);
                                           setNameMethod.invoke(entry, inputName);
                                           
                                           // Verify
                                           assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                       expectedName, entry.getName());
                                           
                                           // Additional verification that no forward slashes were converted to backslashes
                                           String inputWithForwardSlashes = "path/to/file.txt";
                                           setNameMethod.invoke(entry, inputWithForwardSlashes);
                                           assertEquals("Forward slashes should remain unchanged",
                                                       inputWithForwardSlashes, entry.getName());
                                       }

    @Test
                                       public void testSetNamePathSeparatorConversion1() throws Exception {
                                           // Get the protected setName method via reflection
                                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                           setNameMethod.setAccessible(true);
                                           
                                           // Test backslash to forward slash conversion
                                           ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                           setNameMethod.invoke(entry1, "path\\\\to\\\\file.txt", null);
                                           assertEquals("Original should convert \\\\ to /", "path/to/file.txt", entry1.getName());
                                           
                                           // Test forward slashes remain unchanged
                                           ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                           setNameMethod.invoke(entry2, "path/to/file.txt", null);
                                           assertEquals("Original should keep / unchanged", "path/to/file.txt", entry2.getName());
                                           
                                           // Test mixed slashes
                                           ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                           setNameMethod.invoke(entry3, "path\\\\to/file.txt", null);
                                           assertEquals("Original should convert all \\\\ to /", "path/to/file.txt", entry3.getName());
                                           
                                           // Test multiple consecutive backslashes
                                           ZipArchiveEntry entry4 = new ZipArchiveEntry("dummy");
                                           setNameMethod.invoke(entry4, "path\\\\\\\\to\\\\\\\\file.txt", null);
                                           assertEquals("Original should convert all \\\\ to /", "path//to//file.txt", entry4.getName());
                                       }

    @Test
                                  public void testSetName_ShouldConvertBackslashesToForwardSlashesOnFatPlatform() throws Exception {
                                      // Arrange
                                      ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                      
                                      // Use reflection to access protected setPlatform method
                                      Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                      setPlatformMethod.setAccessible(true);
                                      setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                      
                                      String inputName = "path\\\\to\\\\file.txt";
                                      String expectedName = "path/to/file.txt";
                                      
                                      // Use reflection to access protected setName method
                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                      setNameMethod.setAccessible(true);
                                      
                                      // Act
                                      setNameMethod.invoke(entry, inputName);
                                      
                                      // Assert
                                      assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                  expectedName, entry.getName());
                                  }

    @Test
                                  public void testSetNameShouldConvertBackslashesToForwardSlashes1() throws Exception {
                                      // Create a new ZipArchiveEntry using accessible constructor
                                      ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                      
                                      // Test with a Windows-style path containing backslashes
                                      String windowsPath = "folder\\\\subfolder\\\\file.txt";
                                      byte[] rawName = windowsPath.getBytes();
                                      
                                      // Use reflection to access the protected setName method
                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                          "setName", String.class, byte[].class);
                                      setNameMethod.setAccessible(true);
                                      setNameMethod.invoke(entry, windowsPath, rawName);
                                      
                                      // Verify the name has been converted to Unix-style path
                                      assertEquals("folder/subfolder/file.txt", entry.getName());
                                      
                                      // Also verify the rawName was set correctly
                                      assertArrayEquals(rawName, entry.getRawName());
                                  }

    @Test
                                  public void testSetNameWithForwardSlashesShouldRemainUnchanged() throws Exception {
                                      // Create a new ZipArchiveEntry using public constructor
                                      ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                      
                                      // Test with a Unix-style path containing forward slashes
                                      String unixPath = "folder/subfolder/file.txt";
                                      byte[] rawName = unixPath.getBytes();
                                      
                                      // Get the protected setName method via reflection
                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                          "setName", String.class, byte[].class);
                                      setNameMethod.setAccessible(true);
                                      
                                      // Call the method under test using reflection
                                      setNameMethod.invoke(entry, unixPath, rawName);
                                      
                                      // Verify the name remains unchanged
                                      assertEquals(unixPath, entry.getName());
                                      
                                      // Verify the rawName was set correctly
                                      assertArrayEquals(rawName, entry.getRawName());
                                  }

    @Test
                                  public void testSetNameWithMixedSlashesShouldConvertAllToForwardSlashes() throws Exception {
                                      // Create a new ZipArchiveEntry using public constructor
                                      ZipArchiveEntry entry = new ZipArchiveEntry("temp");
                                      
                                      // Test with a mixed path containing both types of slashes
                                      String mixedPath = "folder\\\\subfolder/file.txt";
                                      byte[] rawName = mixedPath.getBytes();
                                      
                                      // Get the protected setName method via reflection
                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                          "setName", String.class, byte[].class);
                                      setNameMethod.setAccessible(true);
                                      
                                      // Call the method under test
                                      setNameMethod.invoke(entry, mixedPath, rawName);
                                      
                                      // Verify all backslashes were converted to forward slashes
                                      assertEquals("folder/subfolder/file.txt", entry.getName());
                                      
                                      // Verify the rawName was set correctly
                                      assertArrayEquals(rawName, entry.getRawName());
                                  }

    @Test
                             public void testSetName_BackslashReplacement() throws Exception {
                                 // Setup
                                 ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use public constructor
                                 
                                 // Use reflection to set platform to FAT
                                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                 setPlatform.setAccessible(true);
                                 setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                 
                                 // Input with backslashes
                                 String inputName = "path\\\\to\\\\file.txt";
                                 
                                 // Expected output (forward slashes)
                                 String expectedName = "path/to/file.txt";
                                 
                                 // Use reflection to call setName
                                 Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                 setName.setAccessible(true);
                                 setName.invoke(entry, inputName);
                                 
                                 // Verify
                                 assertEquals("Backslashes should be replaced with forward slashes", 
                                             expectedName, entry.getName());
                             }

    @Test
                             public void testSetNameWithBackslashes3() throws Exception {
                                 // Create test input with backslashes
                                 String inputName = "path\\\\to\\\\file.txt";
                                 byte[] rawName = new byte[0];
                                 
                                 // Create entry using public constructor
                                 ZipArchiveEntry entry = new ZipArchiveEntry("");
                                 
                                 // Use reflection to access protected setName method
                                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                     "setName", String.class, byte[].class);
                                 setNameMethod.setAccessible(true);
                                 setNameMethod.invoke(entry, inputName, rawName);
                                 
                                 // Verify backslashes were replaced with forward slashes
                                 assertEquals("Path separator replacement failed", 
                                            "path/to/file.txt", entry.getName());
                                 
                                 // Also verify rawName was set correctly
                                 assertSame("Raw name not set correctly", rawName, entry.getRawName());
                             }

    @Test
                             public void testSetNameWithMixedSlashes() throws Exception {
                                 // Create test input with mixed slashes
                                 String inputName = "path\\\\to/mixed/file.txt";
                                 byte[] rawName = new byte[0];
                                 
                                 // Create entry using public constructor
                                 ZipArchiveEntry entry = new ZipArchiveEntry("");
                                 
                                 // Use reflection to access protected setName method
                                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                     "setName", String.class, byte[].class);
                                 setNameMethod.setAccessible(true);
                                 setNameMethod.invoke(entry, inputName, rawName);
                                 
                                 // Verify all backslashes were replaced, forward slashes remain
                                 assertEquals("Mixed path separator handling failed",
                                            "path/to/mixed/file.txt", entry.getName());
                             }

    @Test
                             public void testSetNameWithNoBackslashes() throws Exception {
                                 // Create test input with no backslashes
                                 String inputName = "path/to/file.txt";
                                 byte[] rawName = new byte[0];
                                 
                                 // Create entry using public constructor
                                 ZipArchiveEntry entry = new ZipArchiveEntry(inputName);
                                 
                                 // Use reflection to access protected setName method
                                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                     "setName", String.class, byte[].class);
                                 setNameMethod.setAccessible(true);
                                 setNameMethod.invoke(entry, inputName, rawName);
                                 
                                 // Verify name remains unchanged
                                 assertEquals("Name should remain unchanged when no backslashes present",
                                            "path/to/file.txt", entry.getName());
                             }

    @Test
                        public void testSetName_BackslashReplacement1() throws Exception {
                            // Setup - use public constructor with dummy name
                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                            
                            // Use reflection to set platform to FAT since setPlatform is protected
                            Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                            setPlatform.setAccessible(true);
                            setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                            
                            // Test input with backslashes
                            String inputName = "folder\\\\subfolder\\\\file.txt";
                            String expectedName = "folder/subfolder/file.txt";
                            
                            // Use reflection to call setName since it's protected
                            Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                            setName.setAccessible(true);
                            setName.invoke(entry, inputName);
                            
                            // Verify
                            assertEquals("Backslashes should be replaced with forward slashes", 
                                        expectedName, entry.getName());
                        }

    @Test
                        public void testSetNameWithBackslashes4() throws Exception {
                            // Setup
                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                            String inputName = "path\\\\to\\\\file.txt";
                            byte[] rawName = new byte[]{'p','a','t','h','\\','t','o','\\','f','i','l','e','.','t','x','t'};
                            
                            // Get protected method via reflection
                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                            setNameMethod.setAccessible(true);
                            
                            // Execute
                            setNameMethod.invoke(entry, inputName, rawName);
                            
                            // Verify
                            // Original behavior: backslashes should be replaced with forward slashes
                            // Mutated behavior: backslashes would be replaced with spaces
                            assertEquals("path/to/file.txt", entry.getName());
                            
                            // Verify rawName is unchanged
                            assertArrayEquals(rawName, entry.getRawName());
                            
                            // Additional test with multiple consecutive backslashes
                            String inputName2 = "path\\\\\\\\to\\\\\\\\file.txt";
                            setNameMethod.invoke(entry, inputName2, rawName);
                            assertEquals("path//to//file.txt", entry.getName());
                            
                            // Test with mixed slashes
                            String inputName3 = "path\\\\to/file.txt";
                            setNameMethod.invoke(entry, inputName3, rawName);
                            assertEquals("path/to/file.txt", entry.getName());
                            
                            // Test with no backslashes (should remain unchanged)
                            String inputName4 = "path/to/file.txt";
                            setNameMethod.invoke(entry, inputName4, rawName);
                            assertEquals("path/to/file.txt", entry.getName());
                        }

    @Test
                   public void testSetNameShouldReplaceBackslashesWithForwardSlashesOnFATPlatform() throws Exception {
                       // Setup
                       ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                       
                       // Use reflection to access protected setPlatform method
                       Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                       setPlatformMethod.setAccessible(true);
                       setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                       
                       // Input with Windows-style path
                       String inputPath = "dir\\\\subdir\\\\file.txt";
                       String expectedPath = "dir/subdir/file.txt";
                       
                       // Use reflection to access protected setName method
                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                       setNameMethod.setAccessible(true);
                       setNameMethod.invoke(entry, inputPath);
                       
                       // Verify
                       assertEquals("Backslashes should be replaced with forward slashes", 
                                  expectedPath, 
                                  entry.getName());
                       
                       // Additional verification that no null characters exist
                       assertFalse("Path should not contain null characters",
                                 entry.getName().contains("\0"));
                   }

    @Test
                   public void testSetNameWithBackslashes5() throws Exception {
                       // Create test object using accessible constructor
                       ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                       
                       // Get the protected setName method via reflection
                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                           "setName", String.class, byte[].class);
                       setNameMethod.setAccessible(true);
                       
                       // Test case with backslashes that should be converted
                       String windowsPath = "folder\\\\subfolder\\\\file.txt";
                       byte[] rawName = windowsPath.getBytes();
                       
                       // Call the method via reflection
                       setNameMethod.invoke(entry, windowsPath, rawName);
                       
                       // Verify the name was properly converted
                       assertEquals("folder/subfolder/file.txt", entry.getName());
                       
                       // Verify no null characters exist in the name
                       assertFalse(entry.getName().contains("\0"));
                       
                       // Verify rawName was set correctly
                       assertArrayEquals(rawName, entry.getRawName());
                       
                       // Additional edge case - multiple consecutive backslashes
                       String multiBackslash = "folder\\\\\\\\sub\\\\\\\\file.txt";
                       setNameMethod.invoke(entry, multiBackslash, multiBackslash.getBytes());
                       assertEquals("folder//sub//file.txt", entry.getName());
                       assertFalse(entry.getName().contains("\0"));
                       
                       // Edge case - backslash at start/end
                       String edgePath = "\\\\start\\\\end\\\\";
                       setNameMethod.invoke(entry, edgePath, edgePath.getBytes());
                       assertEquals("/start/end/", entry.getName());
                       assertFalse(entry.getName().contains("\0"));
                   }

    @Test
              public void testSetNameWithBackslashesOnFatPlatform3() throws Exception {
                  // Setup
                  ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                  
                  // Use reflection to access protected setPlatform method
                  Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                  setPlatformMethod.setAccessible(true);
                  setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                  
                  String inputName = "path\\\\to\\\\file";
                  
                  // Use reflection to access protected setName method
                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                  setNameMethod.setAccessible(true);
                  setNameMethod.invoke(entry, inputName);
                  
                  // Verify
                  String resultName = entry.getName();
                  assertNotEquals("Backslashes should be replaced on FAT platform", 
                                 inputName, resultName);
                  assertEquals("path/to/file", resultName);
              }

    @Test
              public void testSetNameWithRawNameShouldSetRawNameWhenPlatformIsFAT() throws Exception {
                  // Setup
                  ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                  // Set platform to FAT (this might need reflection since setPlatform is protected)
                  Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                  platformField.setAccessible(true);
                  platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                  
                  String testName = "test.txt";
                  byte[] testRawName = testName.getBytes();
                  
                  // Test
                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                  setNameMethod.setAccessible(true);
                  setNameMethod.invoke(entry, testName, testRawName);
                  
                  // Verify
                  assertEquals("Name should be set", testName, entry.getName());
                  assertArrayEquals("Raw name should be set when platform is FAT", 
                                   testRawName, entry.getRawName());
                  
                  // Additional verification that the FAT platform handling was executed
                  // This would fail with the mutant since the condition is always false
              }

    @Test
         public void testSetNameWithBackslashesOnFatPlatform4() throws Exception {
             // Setup
             ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
             
             // Use reflection to set protected platform field
             Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
             setPlatformMethod.setAccessible(true);
             setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
             
             String testName = "path\\\\to\\\\file";
             
             // Use reflection to call protected setName method
             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
             setNameMethod.setAccessible(true);
             setNameMethod.invoke(entry, testName);
             
             // Verify
             // Original behavior would replace backslashes, mutated version won't
             // So we expect the name to remain unchanged with the mutation
             assertEquals("path\\\\to\\\\file", entry.getName());
             
             // Additional verification that the condition was supposed to trigger
             assertTrue(testName != null && testName.indexOf("/") == -1);
         }

    @Test
         public void testSetNameWithSlash() throws Exception {
             // Create a new entry using accessible constructor
             ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
             
             // Get the protected setName method via reflection
             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                 "setName", String.class, byte[].class);
             setNameMethod.setAccessible(true);
             
             // Test with name containing slash
             String nameWithSlash = "path/to/file";
             byte[] rawNameWithSlash = nameWithSlash.getBytes();
             setNameMethod.invoke(entry, nameWithSlash, rawNameWithSlash);
             
             // Verify rawName was set correctly
             assertArrayEquals(rawNameWithSlash, entry.getRawName());
             
             // Test with name without slash
             String nameWithoutSlash = "file";
             byte[] rawNameWithoutSlash = nameWithoutSlash.getBytes();
             setNameMethod.invoke(entry, nameWithoutSlash, rawNameWithoutSlash);
             
             // Verify rawName was set correctly
             assertArrayEquals(rawNameWithoutSlash, entry.getRawName());
         }

    @Test
    public void testSetNameWithBackslashesAndWhitespace1() throws Exception {
        // Setup
        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use public constructor
        
        // Use reflection to set protected platform field
        Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
        setPlatform.setAccessible(true);
        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
        
        // Create a name with backslashes that will result in leading/trailing spaces after replacement
        String nameWithBackslashes = " \\\\ test \\\\ ";
        String expectedWithoutTrim = " / test / "; // Expected if no trim
        String expectedWithTrim = "/ test /";    // Expected if trim is applied
        
        // Test
        // Use reflection to call protected setName method
        Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
        setName.setAccessible(true);
        setName.invoke(entry, nameWithBackslashes);
        
        // Verify
        // Original should preserve spaces, mutated version would trim
        assertEquals("Name with backslashes should have spaces preserved after replacement", 
                    expectedWithoutTrim, entry.getName());
        
        // Additional check to ensure the test would catch the mutant
        assertNotEquals("Test should fail if trim was applied (mutant behavior)",
                       expectedWithTrim, entry.getName());
    }

    @Test
    public void testSetNameWithWhitespaceShouldNotTrim() {
        // Create test entry with dummy name (will be overwritten)
        ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
        
        // Prepare test name with backslashes and whitespace
        String testName = "  test\\\\path\\\\name  ";
        byte[] rawName = testName.getBytes();
        
        // Call the method (using reflection since it's protected)
        try {
            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                "setName", String.class, byte[].class);
            setNameMethod.setAccessible(true);
            setNameMethod.invoke(entry, testName, rawName);
        } catch (Exception e) {
            fail("Failed to invoke setName method via reflection");
        }
        
        // Verify the name field - should have converted backslashes but NOT trimmed
        String expectedName = "  test/path/name  "; // Only replace, no trim
        assertEquals("Name should have backslashes replaced but not trimmed", 
            expectedName, entry.getName());
        
        // Verify rawName remains unchanged
        assertArrayEquals("Raw name should remain unchanged", 
            rawName, entry.getRawName());
    }


}
