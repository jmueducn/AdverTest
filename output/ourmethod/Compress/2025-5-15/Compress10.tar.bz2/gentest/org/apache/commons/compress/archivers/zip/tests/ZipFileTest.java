package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipException;
 
public class ZipFileTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
    public void testResolveLocalFileHeaderData_StandardEntry() throws Exception {
        // Setup test data using reflection to access private inner classes
        Class<?> zipFileClass = org.apache.commons.compress.archivers.zip.ZipFile.class;
        
        // Get inner class types via reflection
        Class<?>[] declaredClasses = zipFileClass.getDeclaredClasses();
        Class<?> offsetEntryClass = null;
        for (Class<?> clazz : declaredClasses) {
            if (clazz.getSimpleName().equals("OffsetEntry")) {
                offsetEntryClass = clazz;
                break;
            }
        }
        assertNotNull("OffsetEntry class not found", offsetEntryClass);
        
        // Create maps using reflection with proper types
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entries = 
            new java.util.HashMap<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object>();
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, String> entriesWithoutUTF8Flag = 
            new java.util.HashMap<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, String>();
        
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
            new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("test.txt");
        java.io.File tempFile = java.io.File.createTempFile("test", ".zip");
        tempFile.deleteOnExit();
        org.apache.commons.compress.archivers.zip.ZipFile tempZipFile = 
            new org.apache.commons.compress.archivers.zip.ZipFile(tempFile);
        
        // Create mock archive
        
        // Create OffsetEntry instance
        java.lang.reflect.Constructor<?> offsetEntryConstructor = 
            offsetEntryClass.getDeclaredConstructor(zipFileClass, long.class);
        offsetEntryConstructor.setAccessible(true);
        Object offsetEntry = offsetEntryConstructor.newInstance(tempZipFile, 0L);
        
        java.lang.reflect.Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
        headerOffsetField.setAccessible(true);
        headerOffsetField.set(offsetEntry, 100L);
        entries.put(entry, offsetEntry);
        
        // Mock the archive
        // Mock file name length (2 bytes) and extra field length (4 bytes)
{
{
                // First read - filename length (2 bytes)
{
                }
                // Second read - extra field length (4 bytes)
{
                }
            }
}
        
        // Mock skipping filename (8 bytes)
{
}
        
        // Mock reading extra field data
        byte[] extraData = new byte[]{0x01, 0x02, 0x03, 0x04};
{
{
            }
}
        
        // Create ZipFile instance and set private fields using reflection
        org.apache.commons.compress.archivers.zip.ZipFile zipFile = 
            new org.apache.commons.compress.archivers.zip.ZipFile(tempFile);
        java.lang.reflect.Field archiveField = zipFileClass.getDeclaredField("archive");
        archiveField.setAccessible(true);
        
        java.lang.reflect.Field entriesField = zipFileClass.getDeclaredField("entries");
        entriesField.setAccessible(true);
        entriesField.set(zipFile, entries);
        
        // Execute
        java.lang.reflect.Method method = zipFileClass.getDeclaredMethod(
            "resolveLocalFileHeaderData", java.util.Map.class);
        method.setAccessible(true);
        method.invoke(zipFile, entriesWithoutUTF8Flag);
        
        // Verify
        org.junit.Assert.assertArrayEquals(extraData, entry.getExtra());
        
        java.lang.reflect.Field dataOffsetField = offsetEntryClass.getDeclaredField("dataOffset");
        dataOffsetField.setAccessible(true);
        long dataOffset = dataOffsetField.getLong(offsetEntry);
        org.junit.Assert.assertEquals(100L + 26 + 8 + 4, dataOffset); // LFH_OFFSET_FOR_FILENAME_LENGTH is 26
        
        org.junit.Assert.assertEquals(1, entries.size());
        
        // Clean up
        tempZipFile.close();
        zipFile.close();
    }

    @Test
    public void testResolveLocalFileHeaderData_EntryWithUTF8Flag() throws Exception {
        // Setup test data
        ZipArchiveEntry entry = new ZipArchiveEntry("original.txt");
        
        // Define inner classes
        class OffsetEntry {
            long headerOffset;
            long dataOffset;
        }
        class NameAndComment {
            String name;
            String comment;
            NameAndComment(String name, String comment) {
                this.name = name;
                this.comment = comment;
            }
        }
        
        // Initialize required maps
        Map<ZipArchiveEntry, OffsetEntry> entries = new HashMap<ZipArchiveEntry, OffsetEntry>();
        Map<ZipArchiveEntry, NameAndComment> entriesWithoutUTF8Flag = new HashMap<ZipArchiveEntry, NameAndComment>();
        Map<String, ZipArchiveEntry> nameMap = new HashMap<String, ZipArchiveEntry>();
        
        OffsetEntry offsetEntry = new OffsetEntry();
        offsetEntry.headerOffset = 100L;
        entries.put(entry, offsetEntry);
        
        // Add to entriesWithoutUTF8Flag
        NameAndComment nc = new NameAndComment("modified.txt", null);
        entriesWithoutUTF8Flag.put(entry, nc);
        
        // Mock file operations
        RandomAccessFile mockArchive = mock(RandomAccessFile.class);
        when(mockArchive.read(any(byte[].class))).thenAnswer(invocation -> {
{
}{
            }
            return null;
        });
        
        when(mockArchive.skipBytes(12)).thenReturn(12);
        
        // Create ZipFile instance and set private fields using reflection
        File tempFile = File.createTempFile("test", ".zip");
        tempFile.deleteOnExit();
        ZipFile zipFile = new ZipFile(tempFile, "UTF-8");
        
        try {
            Field archiveField = ZipFile.class.getDeclaredField("archive");
            archiveField.setAccessible(true);
            archiveField.set(zipFile, mockArchive);
            
            Field entriesField = ZipFile.class.getDeclaredField("entries");
            entriesField.setAccessible(true);
            entriesField.set(zipFile, entries);
            
            Field nameMapField = ZipFile.class.getDeclaredField("nameMap");
            nameMapField.setAccessible(true);
            nameMapField.set(zipFile, nameMap);
            
            // Execute
            Method resolveMethod = ZipFile.class.getDeclaredMethod("resolveLocalFileHeaderData", Map.class);
            resolveMethod.setAccessible(true);
            resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
            
            // Verify name was updated
            assertEquals("modified.txt", entry.getName());
            assertEquals(1, nameMap.size());
            assertTrue(nameMap.containsKey("modified.txt"));
            assertFalse(nameMap.containsKey("original.txt"));
        } finally {
            zipFile.close();
        }
    }

    @Test
    public void testResolveLocalFileHeaderData_EmptyExtraField() throws Exception {
        // Setup test data
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
            new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("empty.txt");
        
        // Create OffsetEntry instance via reflection
        Class<?> zipFileClass = org.apache.commons.compress.archivers.zip.ZipFile.class;
        Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
        Object offsetEntry = offsetEntryClass.getDeclaredConstructor().newInstance();
        java.lang.reflect.Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
        headerOffsetField.setAccessible(true);
        headerOffsetField.set(offsetEntry, 200L);
        
        // Create entries map
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entries = 
            new java.util.HashMap<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object>();
        entries.put(entry, offsetEntry);
        
        // Create entriesWithoutUTF8Flag map with correct type
        Class<?> nameAndCommentClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$NameAndComment");
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entriesWithoutUTF8Flag = 
            new java.util.HashMap<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object>();
        
        // Mock file operations
{
{
}{
            }
}
        
        // Create ZipFile instance and inject mock
        java.io.File tempFile = java.io.File.createTempFile("test", ".zip");
        tempFile.deleteOnExit();
        org.apache.commons.compress.archivers.zip.ZipFile zipFile = 
            new org.apache.commons.compress.archivers.zip.ZipFile(tempFile);
        
        java.lang.reflect.Field archiveField = zipFileClass.getDeclaredField("archive");
        archiveField.setAccessible(true);
        
        java.lang.reflect.Field entriesField = zipFileClass.getDeclaredField("entries");
        entriesField.setAccessible(true);
        entriesField.set(zipFile, entries);
        
        // Execute
        java.lang.reflect.Method resolveMethod = zipFileClass.getDeclaredMethod(
            "resolveLocalFileHeaderData", java.util.Map.class);
        resolveMethod.setAccessible(true);
        resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
        
        // Verify
        org.junit.Assert.assertNull(entry.getExtra());
        java.lang.reflect.Field dataOffsetField = offsetEntryClass.getDeclaredField("dataOffset");
        dataOffsetField.setAccessible(true);
        long dataOffset = (long) dataOffsetField.get(offsetEntry);
        org.junit.Assert.assertEquals(200L + 26 + 5 + 0, dataOffset);
        
        // Clean up
        zipFile.close();
    }

    @Test
    public void testResolveLocalFileHeaderData_MultipleEntries() throws Exception {
        // Setup test data
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry1 = 
            new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("file1.txt");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry2 = 
            new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("file2.txt");
        
        // Create mock objects
        java.io.File mockFile = new java.io.File("test.zip");
        
        // Create ZipFile with encoding parameter
        org.apache.commons.compress.archivers.zip.ZipFile zipFile = 
            new org.apache.commons.compress.archivers.zip.ZipFile(mockFile, "UTF-8");
        
        // Create OffsetEntry instances using reflection
        Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
        java.lang.reflect.Constructor<?> offsetEntryConstructor = offsetEntryClass.getDeclaredConstructor(
            org.apache.commons.compress.archivers.zip.ZipFile.class, long.class);
        offsetEntryConstructor.setAccessible(true);
        Object offset1 = offsetEntryConstructor.newInstance(zipFile, 100L);
        Object offset2 = offsetEntryConstructor.newInstance(zipFile, 200L);
        
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> originalEntries = 
            new java.util.LinkedHashMap<>();
        originalEntries.put(entry1, offset1);
        originalEntries.put(entry2, offset2);
        
        // Use reflection to set the entries map and archive
        try {
            java.lang.reflect.Field entriesField = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("entries");
            entriesField.setAccessible(true);
            entriesField.set(zipFile, originalEntries);
            
            java.lang.reflect.Field archiveField = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("archive");
            archiveField.setAccessible(true);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set up test", e);
        }
        
        // Create entriesWithoutUTF8Flag map
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entriesWithoutUTF8Flag = 
            new java.util.HashMap<>();
        
        // Mock file operations - first two calls for entry1
{
{
}{
                }
}
{
{
}{
                }
}
        
        byte[] extraData = new byte[]{0x01, 0x02, 0x03, 0x04};
{
}
        
        // Execute
        java.lang.reflect.Method resolveMethod = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredMethod(
            "resolveLocalFileHeaderData", java.util.Map.class);
        resolveMethod.setAccessible(true);
        resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
        
        // Verify both entries were processed
        org.junit.Assert.assertEquals(2, originalEntries.size());
        org.junit.Assert.assertArrayEquals(extraData, entry1.getExtra());
        org.junit.Assert.assertNull(entry2.getExtra());
        
        java.lang.reflect.Field dataOffsetField = offsetEntryClass.getDeclaredField("dataOffset");
        dataOffsetField.setAccessible(true);
        org.junit.Assert.assertEquals(100L + 26 + 8 + 4, dataOffsetField.get(offset1));
        org.junit.Assert.assertEquals(200L + 26 + 8 + 0, dataOffsetField.get(offset2));
    }

    @Test
    public void testResolveLocalFileHeaderData_FailedSkipFileName() throws Exception {
        // Setup test data
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entries = 
            new java.util.HashMap<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object>();
        java.util.Map<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object> entriesWithoutUTF8Flag = 
            new java.util.HashMap<org.apache.commons.compress.archivers.zip.ZipArchiveEntry, Object>();
        
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = 
            new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("fail.txt");
        
        // Create OffsetEntry instance via reflection
        Class<?> offsetEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry");
        Object offsetEntry = offsetEntryClass.getDeclaredConstructor().newInstance();
        java.lang.reflect.Field headerOffsetField = offsetEntryClass.getDeclaredField("headerOffset");
        headerOffsetField.setAccessible(true);
        headerOffsetField.set(offsetEntry, 300L);
        
        entries.put(entry, offsetEntry);
        
        // Mock file operations
        org.mockito.stubbing.Answer<Void> answer = new org.mockito.stubbing.Answer<Void>() {
            @Override
            public Void answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                byte[] b = (byte[]) invocation.getArguments()[0];
                if (b.length == 2) {
                    b[0] = 0x0A; // 10 chars filename
                    b[1] = 0x00;
                }
                return null;
            }
        };
        
        // Mock failed skip
        
        // Create test instance using reflection
        org.apache.commons.compress.archivers.zip.ZipFile zipFile = 
            new org.apache.commons.compress.archivers.zip.ZipFile("test.zip");
        java.lang.reflect.Field archiveField = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("archive");
        archiveField.setAccessible(true);
        
        java.lang.reflect.Field entriesField = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredField("entries");
        entriesField.setAccessible(true);
        entriesField.set(zipFile, entries);
        
        // Execute and verify exception
        try {
            java.lang.reflect.Method resolveMethod = org.apache.commons.compress.archivers.zip.ZipFile.class.getDeclaredMethod(
                "resolveLocalFileHeaderData", java.util.Map.class);
            resolveMethod.setAccessible(true);
            resolveMethod.invoke(zipFile, entriesWithoutUTF8Flag);
            fail("Expected RuntimeException");
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            assertTrue(cause instanceof RuntimeException);
            assertEquals("failed to skip file name in local file header", cause.getMessage());
        }
    }


}
