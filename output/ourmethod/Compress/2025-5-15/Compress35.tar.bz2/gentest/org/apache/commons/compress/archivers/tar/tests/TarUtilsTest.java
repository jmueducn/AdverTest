package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                    public void testVerifyCheckSum_EmptyHeader() {
                                                        // Edge case: empty header (should fail as it can't contain a checksum)
                                                        byte[] emptyHeader = new byte[0];
                                                        assertFalse(TarUtils.verifyCheckSum(emptyHeader));
                                                    }

 @Test
                                            public void testVerifyCheckSum_ValidUnsignedSum() {
                                                // Define tar header constants
                                                final int CHKSUM_OFFSET = 148; // Standard tar checksum field offset
                                                final int CHKSUMLEN = 8;       // Standard tar checksum field length
                                                
                                                // Create a header with known values that will produce a matching unsigned sum
                                                byte[] header = new byte[512]; // Standard tar block size
                                                // Fill with some data
                                                for (int i = 0; i < header.length; i++) {
                                                    header[i] = (byte) (i % 256);
                                                }
                                                
                                                // Compute expected unsigned sum (excluding checksum field)
                                                long unsignedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    byte b = header[i];
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        b = ' ';
                                                    }
                                                    unsignedSum += 0xff & b;
                                                }
                                                
                                                // Format the checksum into the header
                                                TarUtils.formatCheckSumOctalBytes(unsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(TarUtils.verifyCheckSum(header));
                                            }

 @Test
                                            public void testVerifyCheckSum_ValidSignedSum() {
                                                // Define tar header constants
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                // Create a header with known values that will produce a matching signed sum
                                                byte[] header = new byte[512];
                                                // Fill with values that will produce negative bytes for signed sum
                                                for (int i = 0; i < header.length; i++) {
                                                    header[i] = (byte) (i % 128 - 64); // Range -64 to 63
                                                }
                                                
                                                // Compute expected signed sum (excluding checksum field)
                                                long signedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    byte b = header[i];
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        b = ' ';
                                                    }
                                                    signedSum += b;
                                                }
                                                
                                                // Format the checksum into the header
                                                TarUtils.formatCheckSumOctalBytes(signedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(TarUtils.verifyCheckSum(header));
                                            }

 @Test
                                            public void testVerifyCheckSum_InvalidChecksum() {
                                                // Define constants
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                // Create a header with a clearly wrong checksum
                                                byte[] header = new byte[512];
                                                // Fill with some data
                                                for (int i = 0; i < header.length; i++) {
                                                    header[i] = (byte) i;
                                                }
                                                
                                                // Set an obviously wrong checksum
                                                TarUtils.formatCheckSumOctalBytes(0, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertFalse(TarUtils.verifyCheckSum(header));
                                            }

 @Test
                                            public void testVerifyCheckSum_MinimumLengthHeader() {
                                                // Define constants for checksum field position and length
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                // Edge case: header just big enough to contain checksum field
                                                byte[] minimalHeader = new byte[CHKSUM_OFFSET + CHKSUMLEN];
                                                // Fill with zeros
                                                for (int i = 0; i < minimalHeader.length; i++) {
                                                    minimalHeader[i] = 0;
                                                }
                                                
                                                // Compute expected sum (all zeros except spaces in checksum field)
                                                long expectedSum = 0;
                                                for (int i = 0; i < minimalHeader.length; i++) {
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        expectedSum += ' ';
                                                    } else {
                                                        expectedSum += 0;
                                                    }
                                                }
                                                
                                                // Format the checksum
                                                TarUtils.formatCheckSumOctalBytes(expectedSum, minimalHeader, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(TarUtils.verifyCheckSum(minimalHeader));
                                            }

 @Test
                                            public void testVerifyCheckSum_WithNegativeBytes() {
                                                // Define constants
                                                final int CHKSUM_OFFSET = 148;
                                                final int CHKSUMLEN = 8;
                                                
                                                // Test with negative byte values
                                                byte[] header = new byte[512];
                                                // Fill with negative values
                                                for (int i = 0; i < header.length; i++) {
                                                    header[i] = (byte) -1;
                                                }
                                                
                                                // Compute expected unsigned sum (all bytes are 0xFF when unsigned)
                                                long unsignedSum = 0;
                                                for (int i = 0; i < header.length; i++) {
                                                    if (CHKSUM_OFFSET <= i && i < CHKSUM_OFFSET + CHKSUMLEN) {
                                                        unsignedSum += ' ';
                                                    } else {
                                                        unsignedSum += 0xFF;
                                                    }
                                                }
                                                
                                                // Format the checksum
                                                org.apache.commons.compress.archivers.tar.TarUtils.formatCheckSumOctalBytes(
                                                    unsignedSum, header, CHKSUM_OFFSET, CHKSUMLEN);
                                                
                                                assertTrue(org.apache.commons.compress.archivers.tar.TarUtils.verifyCheckSum(header));
                                            }

 @Test
    public void testComputeCheckSumDetectsMutatedLoop() {
        // Create a byte array where values differ from their indices
        byte[] testBuf = new byte[] { (byte)0xFF, 0x00, 0x01, 0x7F };
        
        // Expected checksum calculation:
        // Original: (0xFF & BYTE_MASK) + (0x00 & BYTE_MASK) + (0x01 & BYTE_MASK) + (0x7F & BYTE_MASK)
        // Assuming BYTE_MASK is 0xFF (common for byte masking):
        // 255 + 0 + 1 + 127 = 383
        
        // Mutated version would calculate:
        // 0 + 1 + 2 + 3 = 6 (completely wrong)
        
        long expected = 383L; // Expected sum of actual byte values
        long actual = TarUtils.computeCheckSum(testBuf);
        
        assertEquals("Checksum should sum byte values, not indices", expected, actual);
    }

 @Test
   public void testComputeCheckSumDetectsBitwiseOperatorMutation() {
       // Create test data where AND and OR operations would differ
       byte[] testData = new byte[] {
           (byte) 0x80,  // Binary: 10000000 - will differ between & and |
           (byte) 0xFF,  // Binary: 11111111 - same for & and |
           (byte) 0x00,  // Binary: 00000000 - same for & and |
           (byte) 0x55   // Binary: 01010101 - same for & and |
       };
       
       // Calculate expected checksum using AND logic (original)
       long expectedSum = 0;
       for (byte b : testData) {
           expectedSum += 0xFF & b;
       }
       
       // Call the method under test
       long actualSum = TarUtils.computeCheckSum(testData);
       
       // Assert the checksum matches the expected AND-based calculation
       assertEquals("Checksum should be calculated using bitwise AND", 
                    expectedSum, actualSum);
       
       // Additional assertion to explicitly show the OR case would be different
       long mutatedSum = 0;
       for (byte b : testData) {
           mutatedSum += 0xFF | b;  // This is what the mutant does
       }
       assertNotEquals("Mutant using OR should produce different result", 
                      mutatedSum, actualSum);
   }

 @Test
  public void testComputeCheckSumWithNegativeBytes() {
      // Create a byte array containing negative values
      byte[] testArray = new byte[] { -1, -2, -3, -4 };
      
      // Calculate expected value using BYTE_MASK (0xFF)
      long expected = 0;
      for (byte b : testArray) {
          expected += 0xFF & b;
      }
      
      // Call the method and get actual result
      long actual = TarUtils.computeCheckSum(testArray);
      
      // Assert they are equal - this will fail if the mutant is present
      assertEquals("Checksum should handle negative bytes correctly", expected, actual);
      
      // Additional assertion to verify the mutant would produce wrong result
      long mutantResult = 0;
      for (byte b : testArray) {
          mutantResult += b;  // This is what the mutant does
      }
      assertNotEquals("Test should detect mutant", mutantResult, actual);
  }

 @Test
     public void testComputeCheckSumDetectsMutant() {
         // Test empty array
         byte[] emptyArray = new byte[0];
         assertEquals(0, TarUtils.computeCheckSum(emptyArray));
         
         // Test single byte
         byte[] singleByteArray = new byte[]{(byte) 0x01};
         assertEquals(1, TarUtils.computeCheckSum(singleByteArray));
         
         // Test multiple bytes including negative values
         byte[] multiByteArray = new byte[]{(byte) 0x01, (byte) 0xFF, (byte) 0x7F};
         // Expected: 1 + (0xFF & 0xFF) + (0x7F & 0xFF) = 1 + 255 + 127 = 383
         assertEquals(383, TarUtils.computeCheckSum(multiByteArray));
         
         // Test with all possible byte values
         byte[] allBytes = new byte[256];
         for (int i = 0; i < 256; i++) {
             allBytes[i] = (byte) (i - 128); // covers all byte values from -128 to 127
         }
         // Expected sum is sum of 0..255 = 255*256/2 = 32640
         assertEquals(32640, TarUtils.computeCheckSum(allBytes));
     }

}
