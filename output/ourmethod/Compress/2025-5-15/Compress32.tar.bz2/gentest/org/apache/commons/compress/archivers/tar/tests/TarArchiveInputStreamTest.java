package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class TarArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_PathHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create headers map
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("path", "/test/path/file.txt");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Mock the TarArchiveInputStream and its current entry
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set the current entry since it's protected
                                                                                                                                                                                                                                                                                                       Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the behavior
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setName("/test/path/file.txt");
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_LinkPathHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set the private currentEntry field
                                                                                                                                                                                                                                                                                                       Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Create and populate headers
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("linkpath", "/link/path");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call the method
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the behavior
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setLinkName("/link/path");
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_GidHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set the private currEntry field
                                                                                                                                                                                                                                                                                                       Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Create and populate headers
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("gid", "1001");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to call the private method
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the interaction
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setGroupId(1001L);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_UidHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Initialize tar input stream
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set current entry since it's protected
                                                                                                                                                                                                                                                                                                       Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Create and populate headers
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("uid", "1000");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call method under test
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setUserId(1000L);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_UnameHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set private field for testing
                                                                                                                                                                                                                                                                                                       Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Create headers map
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("uname", "testuser");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call private method using reflection
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the interaction
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setUserName("testuser");
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_SizeHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create headers map
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("size", "1024");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Mock TarArchiveInputStream and its current entry
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set current entry since setCurrentEntry is protected
                                                                                                                                                                                                                                                                                                       Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the size was set
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setSize(1024L);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_DevMinorHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set the private currEntry field
                                                                                                                                                                                                                                                                                                       Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Create and populate headers
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("SCHILY.devminor", "123");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call the private method using reflection
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the interaction
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setDevMinor(123);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_DevMajorHeader() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create headers map
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("SCHILY.devmajor", "456");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Mock TarArchiveInputStream and its current entry
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set private currentEntry field
                                                                                                                                                                                                                                                                                                       Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the behavior
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setDevMajor(456);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_MultipleHeaders() throws Exception {
                                                                                                                                                                                                                                                                                                       // Initialize mock objects
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to set current entry since it's protected
                                                                                                                                                                                                                                                                                                       Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                                                       currEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                       currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Initialize headers
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("path", "/multi/path");
                                                                                                                                                                                                                                                                                                       headers.put("uid", "1000");
                                                                                                                                                                                                                                                                                                       headers.put("gid", "1001");
                                                                                                                                                                                                                                                                                                       headers.put("size", "2048");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Call the method (using reflection since it's private)
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Verify the interactions
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setName("/multi/path");
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setUserId(1000L);
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setGroupId(1001L);
                                                                                                                                                                                                                                                                                                       verify(mockEntry).setSize(2048L);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_EmptyHeaders() throws Exception {
                                                                                                                                                                                                                                                                                                       // Create mock input stream
                                                                                                                                                                                                                                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Create empty headers map
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to access private method
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Invoke the method with empty headers
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // No verification needed as no headers means no setters called
                                                                                                                                                                                                                                                                                                   }

    @Test(expected = NumberFormatException.class)
                                                                                                                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_MtimeWithInvalidFormat() throws Exception {
                                                                                                                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                                                                       headers.put("mtime", "notadouble");
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                                       TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInput);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Need to set current entry first since applyPaxHeadersToCurrentEntry works on current entry
                                                                                                                                                                                                                                                                                                       TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                                                                       Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                                                                       setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                                                                       setCurrentEntry.invoke(tarInputStream, entry);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Need to access the private method
                                                                                                                                                                                                                                                                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                                                                       method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_GnameHeader() {
                                                                                                                                                                                                                                                               // Create headers map
                                                                                                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                               headers.put("gname", "testgroup");
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create mock TarArchiveInputStream and entry
                                                                                                                                                                                                                                                               TarArchiveInputStream tarInputStream = mock(TarArchiveInputStream.class);
                                                                                                                                                                                                                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to set currentEntry field since it's protected
                                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                                   Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                                   currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                                   currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                                                                   fail("Failed to set current entry via reflection");
                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to call the private method
                                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                                   Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                       "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                                                                   method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                                                                   fail("Failed to invoke applyPaxHeadersToCurrentEntry via reflection");
                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Verify the group name was set
                                                                                                                                                                                                                                                               verify(mockEntry).setGroupName("testgroup");
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_MtimeHeader() throws Exception {
                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                               headers.put("mtime", "1234567890.123");
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInput);
                                                                                                                                                                                                                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to set currentEntry since it's private
                                                                                                                                                                                                                                                               Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                               currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                               currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to access and invoke the private method
                                                                                                                                                                                                                                                               Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                   "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                               applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Test
                                                                                                                                                                                                                                                               applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                                                               verify(mockEntry).setModTime(1234567890123L);
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_UnknownHeader() throws Exception {
                                                                                                                                                                                                                                                               Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                               headers.put("unknown", "value");
                                                                                                                                                                                                                                                               InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInput);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                                                                                                               Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                   "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                                                                               method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // No verification needed as unknown headers should be ignored
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_InvalidNumberFormat() throws Exception {
                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                               headers.put("uid", "notanumber");
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInput);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Set current entry (required for the method to work)
                                                                                                                                                                                                                                                               TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                               Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                               currEntryField.setAccessible(true);
                                                                                                                                                                                                                                                               currEntryField.set(tarInputStream, entry);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Expected exception
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Test
                                                                                                                                                                                                                                                               Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                   "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                                                                               method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_EmptyNumberValue() throws Exception {
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                               headers.put("uid", "");
                                                                                                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                                                                                                               Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                   "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_NullEntry() throws Exception {
                                                                                                                                                                                                                                                               // Create input stream with dummy input
                                                                                                                                                                                                                                                               InputStream input = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(input);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Set up expected exception rule
                                                                                                                                                                                                                                                               ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                               expectedException.expect(NullPointerException.class);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to set current entry to null
                                                                                                                                                                                                                                                               Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                               setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                               setCurrentEntryMethod.invoke(tarInputStream, (TarArchiveEntry)null);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create headers map
                                                                                                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                               headers.put("path", "/test/path");
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to call private method
                                                                                                                                                                                                                                                               Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                               applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                               applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                  public void testApplyPaxHeadersToCurrentEntry_LinkPathWithDifferentStringInstance() throws Exception {
                                                                                                                                                                                                                      // Create test data with a "linkpath" key that's a different String instance
                                                                                                                                                                                                                      Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                      String linkPathKey = new String("linkpath"); // Different instance than literal
                                                                                                                                                                                                                      String expectedLinkName = "testLink";
                                                                                                                                                                                                                      headers.put(linkPathKey, expectedLinkName);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create mock entry and input stream
                                                                                                                                                                                                                      TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                      TarArchiveInputStream tais = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                                      Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                      setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                      setCurrentEntryMethod.invoke(tais, mockEntry);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                      Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                      applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                      applyPaxHeadersMethod.invoke(tais, headers);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify the link name was set (would fail with mutant)
                                                                                                                                                                                                                      verify(mockEntry).setLinkName(expectedLinkName);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                             public void testApplyPaxHeadersToCurrentEntryWithNullKey() throws Exception {
                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                 headers.put(null, "someValue"); // Add null key
                                                                                                                                                                                                                 headers.put("linkpath", "testLink"); // Add regular linkpath
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                                 Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                 setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                 setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                 Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                 applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                 applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                 // Should process the valid "linkpath" entry and skip null key
                                                                                                                                                                                                                 verify(mockEntry).setLinkName("testLink");
                                                                                                                                                                                                                 // No other interactions should occur for null key
                                                                                                                                                                                                                 verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                        public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldSetLinkNameNotName() throws Exception {
                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                            TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                            TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                                            Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                            setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                            setCurrentEntryMethod.invoke(inputStream, entry);
                                                                                                                                                                                                            
                                                                                                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                            String linkPath = "test/link/path";
                                                                                                                                                                                                            headers.put("linkpath", linkPath);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                            Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                            applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                            applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                            // Original behavior should call setLinkName
                                                                                                                                                                                                            verify(entry).setLinkName(linkPath);
                                                                                                                                                                                                            // Ensure setName is NOT called with the linkpath value (this catches the mutant)
                                                                                                                                                                                                            verify(entry, never()).setName(linkPath);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Additional verification that other methods aren't called unexpectedly
                                                                                                                                                                                                            verify(entry, never()).setName(anyString());
                                                                                                                                                                                                            verify(entry, never()).setGroupId(anyLong());
                                                                                                                                                                                                            verify(entry, never()).setGroupName(anyString());
                                                                                                                                                                                                            verify(entry, never()).setUserId(anyLong());
                                                                                                                                                                                                            verify(entry, never()).setUserName(anyString());
                                                                                                                                                                                                            verify(entry, never()).setSize(anyLong());
                                                                                                                                                                                                            verify(entry, never()).setModTime(anyLong());
                                                                                                                                                                                                            verify(entry, never()).setDevMinor(anyInt());
                                                                                                                                                                                                            verify(entry, never()).setDevMajor(anyInt());
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldSetCorrectValue() throws Exception {
                                                                                                                                                                                                       // Create test data
                                                                                                                                                                                                       String testLinkPath = "test/link/path";
                                                                                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                       headers.put("linkpath", testLinkPath);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create mock entry
                                                                                                                                                                                                       TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create instance
                                                                                                                                                                                                       TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to set current entry (protected method)
                                                                                                                                                                                                       Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                       setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                       setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to call applyPaxHeadersToCurrentEntry (private method)
                                                                                                                                                                                                       Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                       applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                       applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify the link name was set with the correct value
                                                                                                                                                                                                       verify(mockEntry).setLinkName(testLinkPath);
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                              public void testApplyPaxHeadersToCurrentEntry_DetectsGidMutant() throws Exception {
                                                                                                                                                                                                  // Create test data with a "gid" key that's a different String instance
                                                                                                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                  String gidKey = new String("gid"); // Different instance than literal "gid"
                                                                                                                                                                                                  headers.put(gidKey, "1234");
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create mock entry to verify behavior
                                                                                                                                                                                                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create instance and set current entry using reflection
                                                                                                                                                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                  Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                  setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                  setCurrentEntry.invoke(tarInput, mockEntry);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Call the method using reflection
                                                                                                                                                                                                  Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                  applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                  applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify the group ID was set - this would fail with the mutant
                                                                                                                                                                                                  verify(mockEntry).setGroupId(1234L);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Also verify no other interactions to ensure we're testing specifically the gid case
                                                                                                                                                                                                  verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntryWithNullKey1() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                                             Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                             setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                             setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                                                                                                             
                                                                                                                                                                                             // Create headers map with null key
                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                             headers.put(null, "123");  // This would cause NPE in mutant
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                             Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                             applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                             applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify no interaction with entry for null key
                                                                                                                                                                                             verify(mockEntry, never()).setGroupId(anyLong());
                                                                                                                                                                                             // Verify other properties weren't accidentally set
                                                                                                                                                                                             verify(mockEntry, never()).setName(anyString());
                                                                                                                                                                                             verify(mockEntry, never()).setLinkName(anyString());
                                                                                                                                                                                             // ... other verifications as needed
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_GroupId() throws Exception {
                                                                                                                                                                                        // Setup
                                                                                                                                                                                        TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                        setCurrentEntry.invoke(inputStream, entry);
                                                                                                                                                                                        
                                                                                                                                                                                        // Create headers with a non-zero gid value
                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                        headers.put("gid", "12345");  // Non-zero value
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                        applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify
                                                                                                                                                                                        assertEquals("Group ID should be set to the parsed header value", 
                                                                                                                                                                                                    12345L, entry.getGroupId());
                                                                                                                                                                                        
                                                                                                                                                                                        // Additional test with different value to ensure it's not hardcoded
                                                                                                                                                                                        TarArchiveEntry entry2 = new TarArchiveEntry("test2");
                                                                                                                                                                                        setCurrentEntry.invoke(inputStream, entry2);
                                                                                                                                                                                        headers.put("gid", "67890");
                                                                                                                                                                                        applyPaxHeaders.invoke(inputStream, headers);
                                                                                                                                                                                        assertEquals("Group ID should be set to the new parsed header value", 
                                                                                                                                                                                                    67890L, entry2.getGroupId());
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                               public void testApplyPaxHeadersToCurrentEntry_HandlesLargeGroupId() throws Exception {
                                                                                                                                                                                   // Setup
                                                                                                                                                                                   TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                   TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                   
                                                                                                                                                                                   // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                   Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                       "setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                   setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                   setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                   
                                                                                                                                                                                   // Create headers with a group ID larger than Integer.MAX_VALUE
                                                                                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                   long largeGroupId = (long)Integer.MAX_VALUE + 1;
                                                                                                                                                                                   headers.put("gid", String.valueOf(largeGroupId));
                                                                                                                                                                                   
                                                                                                                                                                                   // Execute
                                                                                                                                                                                   Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                       "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                   method.invoke(tarInput, headers);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify
                                                                                                                                                                                   assertEquals("Group ID should be set correctly for large values", 
                                                                                                                                                                                       largeGroupId, entry.getGroupId());
                                                                                                                                                                               }

    @Test
                                                                                                                                                                          public void testApplyPaxHeadersToCurrentEntry_DetectsGnameStringComparisonMutant() throws Exception {
                                                                                                                                                                              // Create test data with a "gname" key that's a different String object
                                                                                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                                                                                              String gnameKey = new String("gname"); // Different object than literal "gname"
                                                                                                                                                                              String expectedGroupName = "testgroup";
                                                                                                                                                                              headers.put(gnameKey, expectedGroupName);
                                                                                                                                                                              
                                                                                                                                                                              // Create mock entry to verify behavior
                                                                                                                                                                              TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                              
                                                                                                                                                                              // Create instance and set current entry using reflection
                                                                                                                                                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                              Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                              setCurrentEntry.setAccessible(true);
                                                                                                                                                                              setCurrentEntry.invoke(tarInput, mockEntry);
                                                                                                                                                                              
                                                                                                                                                                              // Call method under test using reflection
                                                                                                                                                                              Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                              applyPaxHeaders.setAccessible(true);
                                                                                                                                                                              applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                              
                                                                                                                                                                              // Verify group name was set - this will fail with mutant but pass with original
                                                                                                                                                                              verify(mockEntry).setGroupName(expectedGroupName);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                     public void testApplyPaxHeadersToCurrentEntryWithNullKey2() throws Exception {
                                                                                                                                                                         // Setup
                                                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                                                         headers.put(null, "testGroup");  // Add null key
                                                                                                                                                                         
                                                                                                                                                                         TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                         
                                                                                                                                                                         // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                         setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                                         
                                                                                                                                                                         // Execute - use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                         Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                         applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                         applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                         
                                                                                                                                                                         // Verify
                                                                                                                                                                         verify(mockEntry, never()).setGroupName(anyString());  // Should not try to set group name for null key
                                                                                                                                                                         
                                                                                                                                                                         // Also verify no NPE was thrown - implicit in test passing
                                                                                                                                                                     }

    @Test
                                                                                                                                                                public void testApplyPaxHeadersToCurrentEntry_GroupName() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                    TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                    Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                    setCurrentEntry.setAccessible(true);
                                                                                                                                                                    setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                    
                                                                                                                                                                    // Prepare headers with gname
                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                    String expectedGroupName = "testgroup";
                                                                                                                                                                    headers.put("gname", expectedGroupName);
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                    Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                    applyPaxHeaders.setAccessible(true);
                                                                                                                                                                    applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("Group name should be set from headers", 
                                                                                                                                                                                expectedGroupName, 
                                                                                                                                                                                entry.getGroupName());
                                                                                                                                                                    
                                                                                                                                                                    // Additional verification that no other fields were affected
                                                                                                                                                                    assertEquals("test", entry.getName()); // original name should remain
                                                                                                                                                                    assertEquals(0, entry.getSize()); // size should remain default
                                                                                                                                                                }

    @Test
                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameWhenGnameHeaderPresent() throws Exception {
                                                                                                                                                               // Arrange
                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                               
                                                                                                                                                               // Use reflection to call protected setCurrentEntry method
                                                                                                                                                               Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                               setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                               setCurrentEntryMethod.invoke(tarInputStream, mockEntry);
                                                                                                                                                               
                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                               String expectedGroupName = "testGroup";
                                                                                                                                                               headers.put("gname", expectedGroupName);
                                                                                                                                                               
                                                                                                                                                               // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                               Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                               applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                               applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                                               
                                                                                                                                                               // Assert
                                                                                                                                                               // Verify group name was set correctly
                                                                                                                                                               verify(mockEntry).setGroupName(expectedGroupName);
                                                                                                                                                               // Verify user name was NOT set with this value (to catch the mutant)
                                                                                                                                                               verify(mockEntry, never()).setUserName(expectedGroupName);
                                                                                                                                                               
                                                                                                                                                               // Additional verifications that other methods weren't called unexpectedly
                                                                                                                                                               verify(mockEntry, never()).setName(anyString());
                                                                                                                                                               verify(mockEntry, never()).setLinkName(anyString());
                                                                                                                                                               verify(mockEntry, never()).setGroupId(anyLong());
                                                                                                                                                               verify(mockEntry, never()).setUserId(anyLong());
                                                                                                                                                               verify(mockEntry, never()).setSize(anyLong());
                                                                                                                                                               verify(mockEntry, never()).setModTime(anyLong());
                                                                                                                                                               verify(mockEntry, never()).setDevMinor(anyInt());
                                                                                                                                                               verify(mockEntry, never()).setDevMajor(anyInt());
                                                                                                                                                           }

    @Test
                                                                                                                                                      public void testApplyPaxHeadersToCurrentEntry_UidWithDifferentStringObject() throws Exception {
                                                                                                                                                          // Create test data with a different String object for "uid" key
                                                                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                                                                          String uidKey = new String("uid"); // Different object than literal "uid"
                                                                                                                                                          headers.put(uidKey, "1234");
                                                                                                                                                          
                                                                                                                                                          // Mock the current entry
                                                                                                                                                          TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                          
                                                                                                                                                          // Create instance
                                                                                                                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                          
                                                                                                                                                          // Use reflection to set current entry (protected method)
                                                                                                                                                          Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                          setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                          setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                          
                                                                                                                                                          // Use reflection to call applyPaxHeadersToCurrentEntry (private method)
                                                                                                                                                          Method applyMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                          applyMethod.setAccessible(true);
                                                                                                                                                          applyMethod.invoke(tarInput, headers);
                                                                                                                                                          
                                                                                                                                                          // Verify the userId was set (should pass in original, fail in mutant)
                                                                                                                                                          verify(mockEntry).setUserId(1234L);
                                                                                                                                                          
                                                                                                                                                          // Also verify no other unexpected interactions
                                                                                                                                                          verifyNoMoreInteractions(mockEntry);
                                                                                                                                                      }

    @Test
                                                                                                                                                 public void testApplyPaxHeadersToCurrentEntryWithNullKey3() throws Exception {
                                                                                                                                                     // Setup
                                                                                                                                                     TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                     
                                                                                                                                                     // Use reflection to call protected setCurrentEntry method
                                                                                                                                                     Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                     setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                     setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                                                                     
                                                                                                                                                     // Create headers with null key that would trigger the uid case if not null
                                                                                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                                                                                     headers.put(null, "123"); // null key with value that would be parsed as uid
                                                                                                                                                     
                                                                                                                                                     // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                     Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                     applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                     
                                                                                                                                                     // Exercise and verify
                                                                                                                                                     try {
                                                                                                                                                         applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                                                                         // If we get here, the test passes (original behavior)
                                                                                                                                                     } catch (InvocationTargetException e) {
                                                                                                                                                         if (e.getCause() instanceof NullPointerException) {
                                                                                                                                                             // If we get here, the mutant was detected
                                                                                                                                                             fail("NullPointerException was thrown, indicating the mutant was detected");
                                                                                                                                                         }
                                                                                                                                                         throw e;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     // Additional verification that no uid was set (since key was null)
                                                                                                                                                     verify(mockEntry, never()).setUserId(anyLong());
                                                                                                                                                 }

    @Test
                                                                                                                                            public void testApplyPaxHeadersToCurrentEntry_HandlesLargeUserId() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                
                                                                                                                                                // Use reflection to access protected setCurrentEntry method
                                                                                                                                                Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                
                                                                                                                                                // Create headers with a user ID larger than Integer.MAX_VALUE
                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                long largeUserId = (long)Integer.MAX_VALUE + 1;
                                                                                                                                                headers.put("uid", String.valueOf(largeUserId));
                                                                                                                                                
                                                                                                                                                // Execute
                                                                                                                                                Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                method.setAccessible(true);
                                                                                                                                                method.invoke(tarInput, headers);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertEquals("User ID should be set correctly for values > Integer.MAX_VALUE", 
                                                                                                                                                            largeUserId, entry.getUserId());
                                                                                                                                            }

    @Test
                                                                                                                                       public void testApplyPaxHeadersToCurrentEntry_DetectsUnameStringComparisonMutant() throws Exception {
                                                                                                                                           // Create test data with a new String instance for "uname" key
                                                                                                                                           Map<String, String> headers = new HashMap<>();
                                                                                                                                           String unameKey = new String("uname"); // Force new String instance
                                                                                                                                           String expectedUserName = "testuser";
                                                                                                                                           headers.put(unameKey, expectedUserName);
                                                                                                                                           
                                                                                                                                           // Create mock TarArchiveEntry
                                                                                                                                           TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                                           
                                                                                                                                           // Create instance
                                                                                                                                           TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                           
                                                                                                                                           // Use reflection to call protected setCurrentEntry method
                                                                                                                                           Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                           setCurrentEntryMethod.setAccessible(true);
                                                                                                                                           setCurrentEntryMethod.invoke(tarInput, currEntry);
                                                                                                                                           
                                                                                                                                           // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                           Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                           applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                           applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                           
                                                                                                                                           // Verify the user name was set - this will fail with the mutant
                                                                                                                                           verify(currEntry).setUserName(expectedUserName);
                                                                                                                                       }

    @Test
                                                                                                                                  public void testApplyPaxHeadersToCurrentEntryWithNullKey4() {
                                                                                                                                      // Setup
                                                                                                                                      Map<String, String> headers = new HashMap<>();
                                                                                                                                      headers.put(null, "testUser"); // Add null key
                                                                                                                                      
                                                                                                                                      TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                      TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                      
                                                                                                                                      // Use reflection to set the private currEntry field since there's no setter
                                                                                                                                      try {
                                                                                                                                          Field field = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                          field.setAccessible(true);
                                                                                                                                          field.set(tarInput, mockEntry);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set currEntry field via reflection");
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Exercise
                                                                                                                                      try {
                                                                                                                                          // Use reflection to access and invoke the private method
                                                                                                                                          Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                              "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                          method.setAccessible(true);
                                                                                                                                          method.invoke(tarInput, headers);
                                                                                                                                          // If we get here, the test passes (original behavior)
                                                                                                                                      } catch (NullPointerException e) {
                                                                                                                                          // If we get here, the mutant was detected
                                                                                                                                          fail("Mutant detected: Method threw NullPointerException when handling null key");
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to invoke applyPaxHeadersToCurrentEntry via reflection: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Verify no interaction with mockEntry since null key should be ignored
                                                                                                                                      verifyZeroInteractions(mockEntry);
                                                                                                                                  }

    @Test
                                                                                                                              public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserName_WhenUnameHeaderPresent() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                  
                                                                                                                                  // Use reflection to set the private currEntry field since there's no public setter
                                                                                                                                  Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                  currEntryField.setAccessible(true);
                                                                                                                                  currEntryField.set(tarInputStream, mockEntry);
                                                                                                                                  
                                                                                                                                  // Prepare headers with uname
                                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                                  String expectedUserName = "testuser";
                                                                                                                                  headers.put("uname", expectedUserName);
                                                                                                                                  
                                                                                                                                  // Get the method via reflection since it's private
                                                                                                                                  Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                      "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                  method.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  method.invoke(tarInputStream, headers);
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  verify(mockEntry).setUserName(expectedUserName); // This will fail with the mutant
                                                                                                                              }

    @Test
                                                                                                                             public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserName_WhenUnameHeaderPresent1() throws Exception {
                                                                                                                                 // Setup
                                                                                                                                 TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                 TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                 
                                                                                                                                 // Use reflection to access protected setCurrentEntry method
                                                                                                                                 Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                 setCurrentEntryMethod.setAccessible(true);
                                                                                                                                 setCurrentEntryMethod.invoke(tarInputStream, mockEntry);
                                                                                                                                 
                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                 String expectedUserName = "testuser";
                                                                                                                                 headers.put("uname", expectedUserName);
                                                                                                                                 
                                                                                                                                 // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                 Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                 applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                 applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 verify(mockEntry).setUserName(expectedUserName);
                                                                                                                             }

    @Test
                                                                                                                        public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserName_WhenUnameHeaderPresent2() throws Exception {
                                                                                                                            // Setup
                                                                                                                            TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                            TarArchiveEntry currEntry = new TarArchiveEntry("test");
                                                                                                                            
                                                                                                                            // Use reflection to access protected setCurrentEntry method
                                                                                                                            Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                            setCurrentEntryMethod.setAccessible(true);
                                                                                                                            setCurrentEntryMethod.invoke(tarInput, currEntry);
                                                                                                                            
                                                                                                                            // Prepare headers with uname
                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                            String expectedUserName = "testuser";
                                                                                                                            headers.put("uname", expectedUserName);
                                                                                                                            
                                                                                                                            // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                            Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                            applyPaxHeadersMethod.setAccessible(true);
                                                                                                                            applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals("User name should be set", expectedUserName, currEntry.getUserName());
                                                                                                                            assertNull("Group name should not be set for uname header", currEntry.getGroupName());
                                                                                                                        }

    @Test
                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_SizeWithDifferentStringInstance() throws Exception {
                                                                                                                       // Create a new String with same content but different instance
                                                                                                                       String sizeKey = new String("size");
                                                                                                                       
                                                                                                                       // Create test headers map
                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                       headers.put(sizeKey, "12345");  // Using different String instance for key
                                                                                                                       
                                                                                                                       // Create mock entry
                                                                                                                       TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                                                       
                                                                                                                       // Create test instance
                                                                                                                       TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                       
                                                                                                                       // Use reflection to call protected setCurrentEntry method
                                                                                                                       Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                       setCurrentEntryMethod.setAccessible(true);
                                                                                                                       setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                       
                                                                                                                       // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                       Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                       applyPaxHeadersMethod.setAccessible(true);
                                                                                                                       applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                       
                                                                                                                       // Verify the size was set (would fail with mutant)
                                                                                                                       verify(entry).setSize(12345L);
                                                                                                                       
                                                                                                                       // Also verify no other interactions to ensure we hit exactly the size case
                                                                                                                       verifyNoMoreInteractions(entry);
                                                                                                                   }

    @Test
                                                                                                              public void testApplyPaxHeadersToCurrentEntryWithNullKeyShouldNotThrow() throws Exception {
                                                                                                                  // Setup
                                                                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                  TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                  
                                                                                                                  // Use reflection to call protected setCurrentEntry method
                                                                                                                  Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                  setCurrentEntryMethod.setAccessible(true);
                                                                                                                  setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                  
                                                                                                                  // Create headers with null key and size value
                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                  headers.put(null, "12345");  // Null key with size value
                                                                                                                  
                                                                                                                  // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                  Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                  applyPaxHeadersMethod.setAccessible(true);
                                                                                                                  
                                                                                                                  // Execute - should not throw exception
                                                                                                                  applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                  
                                                                                                                  // Verify - size should not be set (remains 0)
                                                                                                                  assertEquals(0, entry.getSize());
                                                                                                                  
                                                                                                                  // Additional verification that other null key cases are handled
                                                                                                                  headers.clear();
                                                                                                                  headers.put(null, null);
                                                                                                                  applyPaxHeadersMethod.invoke(tarInput, headers);  // Should not throw
                                                                                                              }

    @Test
                                                                                                         public void testApplyPaxHeadersToCurrentEntry_DetectsLinkpathStringReferenceMutant() throws Exception {
                                                                                                             // Create headers map with "linkpath" as a different String instance
                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                             String linkpathKey = new String("linkpath"); // Different instance than literal
                                                                                                             String linkpathValue = "test/link/path";
                                                                                                             headers.put(linkpathKey, linkpathValue);
                                                                                                             
                                                                                                             // Mock the current entry
                                                                                                             TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                             
                                                                                                             // Create test instance
                                                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                             
                                                                                                             // Use reflection to set current entry
                                                                                                             Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                             setCurrentEntry.setAccessible(true);
                                                                                                             setCurrentEntry.invoke(tarInput, currEntry);
                                                                                                             
                                                                                                             // Use reflection to call applyPaxHeadersToCurrentEntry
                                                                                                             Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                             applyPaxHeaders.setAccessible(true);
                                                                                                             applyPaxHeaders.invoke(tarInput, headers);
                                                                                                             
                                                                                                             // Verify the linkpath was properly processed
                                                                                                             verify(currEntry).setLinkName(linkpathValue);
                                                                                                         }

    @Test
                                                                                                    public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldSetLinkNameNotName1() throws Exception {
                                                                                                        // Setup
                                                                                                        TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                        TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                        
                                                                                                        // Use reflection to call protected setCurrentEntry method
                                                                                                        Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                        setCurrentEntryMethod.setAccessible(true);
                                                                                                        setCurrentEntryMethod.invoke(inputStream, mockEntry);
                                                                                                        
                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                        String linkPathValue = "test/link/path";
                                                                                                        headers.put("linkpath", linkPathValue);
                                                                                                        
                                                                                                        // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                        Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                        applyPaxHeadersMethod.setAccessible(true);
                                                                                                        applyPaxHeadersMethod.invoke(inputStream, headers);
                                                                                                        
                                                                                                        // Verify
                                                                                                        // Verify setLinkName was called with the correct value
                                                                                                        verify(mockEntry).setLinkName(linkPathValue);
                                                                                                        // Verify setName was never called with the linkpath value
                                                                                                        verify(mockEntry, never()).setName(linkPathValue);
                                                                                                        // Verify no other unexpected interactions
                                                                                                        verifyNoMoreInteractions(mockEntry);
                                                                                                    }

    @Test
                                                                                               public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldBeSetCorrectly() {
                                                                                                   // Prepare test data
                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                   String expectedLinkName = "test/link/path";
                                                                                                   headers.put("linkpath", expectedLinkName);
                                                                                                   
                                                                                                   // Create mock objects
                                                                                                   TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                   TarArchiveInputStream tarInput = new TarArchiveInputStream(null);
                                                                                                   
                                                                                                   // Set the current entry using reflection
                                                                                                   try {
                                                                                                       java.lang.reflect.Field field = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                       field.setAccessible(true);
                                                                                                       field.set(tarInput, mockEntry);
                                                                                                   } catch (Exception e) {
                                                                                                       throw new RuntimeException("Failed to set currEntry field", e);
                                                                                                   }
                                                                                                   
                                                                                                   // Call the private method using reflection
                                                                                                   try {
                                                                                                       java.lang.reflect.Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                           "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                       method.setAccessible(true);
                                                                                                       method.invoke(tarInput, headers);
                                                                                                   } catch (Exception e) {
                                                                                                       throw new RuntimeException("Failed to invoke applyPaxHeadersToCurrentEntry", e);
                                                                                                   }
                                                                                                   
                                                                                                   // Verify the interaction
                                                                                                   verify(mockEntry).setLinkName(eq(expectedLinkName));
                                                                                                   
                                                                                                   // Additional verification that it wasn't called with null
                                                                                                   verify(mockEntry, never()).setLinkName(isNull(String.class));
                                                                                               }

    @Test
                                                                                          public void testApplyPaxHeadersToCurrentEntry_DetectsGidStringReferenceMutation() throws Exception {
                                                                                              // Create a new String object with same content as "gid" but different reference
                                                                                              String gidKey = new String("gid");
                                                                                              
                                                                                              // Create headers map with our special gid key
                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                              headers.put(gidKey, "12345");  // Use our dynamically created key
                                                                                              
                                                                                              // Create mock entry
                                                                                              TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                              
                                                                                              // Create test instance
                                                                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                              
                                                                                              // Use reflection to set current entry (protected method)
                                                                                              Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                              setCurrentEntry.setAccessible(true);
                                                                                              setCurrentEntry.invoke(tarInput, entry);
                                                                                              
                                                                                              // Use reflection to call applyPaxHeadersToCurrentEntry (private method)
                                                                                              Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                              applyPaxHeaders.setAccessible(true);
                                                                                              applyPaxHeaders.invoke(tarInput, headers);
                                                                                              
                                                                                              // Verify the group ID was set (would fail with == comparison)
                                                                                              verify(entry).setGroupId(12345L);
                                                                                              
                                                                                              // Also verify no other interactions to ensure we only processed gid
                                                                                              verifyNoMoreInteractions(entry);
                                                                                          }

    @Test
                                                                                     public void testApplyPaxHeadersToCurrentEntry_HandlesLargeGroupId1() throws Exception {
                                                                                         // Setup
                                                                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                         TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                         
                                                                                         // Use reflection to call protected setCurrentEntry method
                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                         setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                         
                                                                                         // Create headers with a group ID larger than Integer.MAX_VALUE
                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                         long largeGroupId = 2147483648L; // Integer.MAX_VALUE + 1
                                                                                         headers.put("gid", String.valueOf(largeGroupId));
                                                                                         
                                                                                         // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                         Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                         applyPaxHeadersMethod.setAccessible(true);
                                                                                         applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals("Group ID should be set correctly for large values", 
                                                                                                     largeGroupId, entry.getGroupId());
                                                                                         
                                                                                         // Additional verification that the value was indeed parsed as long
                                                                                         assertTrue("Group ID should be greater than Integer.MAX_VALUE", 
                                                                                                    entry.getGroupId() > Integer.MAX_VALUE);
                                                                                     }

    @Test
                                                                                public void testApplyPaxHeadersToCurrentEntry_DetectsGnameStringReferenceMutation() {
                                                                                    // Create test data with a "gname" key that's a different string instance
                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                    String gnameKey = new String("gname"); // Different instance than literal "gname"
                                                                                    String groupName = "testGroup";
                                                                                    headers.put(gnameKey, groupName);
                                                                                    
                                                                                    // Create mock entry to verify behavior
                                                                                    TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                    
                                                                                    // Create instance
                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                    
                                                                                    // Use reflection to set current entry (since setCurrentEntry is protected)
                                                                                    try {
                                                                                        Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                            "setCurrentEntry", TarArchiveEntry.class);
                                                                                        setCurrentEntryMethod.setAccessible(true);
                                                                                        setCurrentEntryMethod.invoke(tarInput, currEntry);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set current entry via reflection: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    // Call the method (using reflection since it's private)
                                                                                    try {
                                                                                        Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                            "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                        method.setAccessible(true);
                                                                                        method.invoke(tarInput, headers);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to invoke method via reflection: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    // Verify the group name was set - this will fail with mutated version
                                                                                    verify(currEntry).setGroupName(groupName);
                                                                                    
                                                                                    // Also verify no other interactions to ensure we're testing just the gname case
                                                                                    verifyNoMoreInteractions(currEntry);
                                                                                }

    @Test
                                                                           public void testApplyPaxHeadersToCurrentEntry_DetectUidMutant() throws Exception {
                                                                               // Create test objects
                                                                               TarArchiveEntry currEntry = new TarArchiveEntry("test");
                                                                               TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                               
                                                                               // Use reflection to call protected setCurrentEntry method
                                                                               Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                               setCurrentEntry.setAccessible(true);
                                                                               setCurrentEntry.invoke(inputStream, currEntry);
                                                                               
                                                                               // Create headers map with "uid" as a different String object
                                                                               Map<String, String> headers = new HashMap<>();
                                                                               String uidKey = new String("uid"); // Different object than literal "uid"
                                                                               headers.put(uidKey, "1234");
                                                                               
                                                                               // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                               Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                               applyPaxHeaders.setAccessible(true);
                                                                               applyPaxHeaders.invoke(inputStream, headers);
                                                                               
                                                                               // Verify the uid was set (would fail with mutant)
                                                                               assertEquals(1234L, currEntry.getUserId());
                                                                               
                                                                               // Additional verification that other fields weren't modified
                                                                               assertEquals("test", currEntry.getName());
                                                                               assertEquals(0, currEntry.getSize());
                                                                           }

    @Test
                                                                      public void testApplyPaxHeadersToCurrentEntry_UserIdHandlesLargeNumbers() throws Exception {
                                                                          // Setup
                                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                          TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                          
                                                                          // Use reflection to set current entry
                                                                          Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                          setCurrentEntry.setAccessible(true);
                                                                          setCurrentEntry.invoke(tarInput, entry);
                                                                          
                                                                          // Create headers with user ID above Integer.MAX_VALUE
                                                                          Map<String, String> headers = new HashMap<>();
                                                                          long largeUserId = (long)Integer.MAX_VALUE + 1;
                                                                          headers.put("uid", String.valueOf(largeUserId));
                                                                          
                                                                          // Use reflection to call private method
                                                                          Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                          applyPaxHeaders.setAccessible(true);
                                                                          applyPaxHeaders.invoke(tarInput, headers);
                                                                          
                                                                          // Verify
                                                                          verify(entry).setUserId(largeUserId); // This will fail in mutant which tries to parse as int
                                                                          
                                                                          // Additional test with regular value
                                                                          headers.put("uid", "12345");
                                                                          applyPaxHeaders.invoke(tarInput, headers);
                                                                          verify(entry).setUserId(12345L);
                                                                      }

    @Test
                                                                      public void testApplyPaxHeadersToCurrentEntry_UserIdFailsWhenTooLargeForInt() throws Exception {
                                                                          // This test expects exception from the mutant version
                                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                          TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                          
                                                                          // Use reflection to access protected setCurrentEntry method
                                                                          Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                          setCurrentEntry.setAccessible(true);
                                                                          setCurrentEntry.invoke(tarInput, entry);
                                                                          
                                                                          Map<String, String> headers = new HashMap<>();
                                                                          long largeUserId = (long)Integer.MAX_VALUE + 1;
                                                                          headers.put("uid", String.valueOf(largeUserId));
                                                                          
                                                                          // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                          Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                          applyPaxHeaders.setAccessible(true);
                                                                          
                                                                          // In mutant version, this will throw NumberFormatException
                                                                          // because Integer.parseInt can't handle the large number
                                                                          applyPaxHeaders.invoke(tarInput, headers);
                                                                      }

    @Test
                                                                 public void testApplyPaxHeadersToCurrentEntry_DetectUnameStringComparisonMutant() throws Exception {
                                                                     // Create test data with a "uname" key that's a different String instance
                                                                     Map<String, String> headers = new HashMap<>();
                                                                     String unameKey = new String("uname"); // Different instance than literal
                                                                     String expectedUserName = "testuser";
                                                                     headers.put(unameKey, expectedUserName);
                                                                     
                                                                     // Create mock entry
                                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                     
                                                                     // Create instance
                                                                     TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                     
                                                                     // Use reflection to set current entry
                                                                     Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                     setCurrentEntryMethod.setAccessible(true);
                                                                     setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                     
                                                                     // Use reflection to call applyPaxHeadersToCurrentEntry
                                                                     Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                     applyPaxHeadersMethod.setAccessible(true);
                                                                     applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                     
                                                                     // Verify the user name was set - this will fail with the mutant
                                                                     verify(mockEntry).setUserName(expectedUserName);
                                                                 }

    @Test
                                                             public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserNameFromHeaders() throws Exception {
                                                                 // Setup
                                                                 TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                 TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                 
                                                                 // Use reflection to set the private currEntry field since there's no setter
                                                                 Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                 currEntryField.setAccessible(true);
                                                                 currEntryField.set(tarInputStream, mockEntry);
                                                                 
                                                                 // Prepare headers with a username
                                                                 Map<String, String> headers = new HashMap<>();
                                                                 String expectedUserName = "testuser";
                                                                 headers.put("uname", expectedUserName);
                                                                 
                                                                 // Call the method
                                                                 Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                 method.setAccessible(true);
                                                                 method.invoke(tarInputStream, headers);
                                                                 
                                                                 // Verify
                                                                 verify(mockEntry).setUserName(expectedUserName); // This will fail if mutant is present
                                                             }

    @Test
                                                           public void testApplyPaxHeadersToCurrentEntry_UserNameShouldSetUserNameNotGroupName() throws Exception {
                                                               // Create test data
                                                               Map<String, String> headers = new HashMap<>();
                                                               String testUserName = "testuser";
                                                               headers.put("uname", testUserName);
                                                               
                                                               // Create mock entry
                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                               
                                                               // Create instance
                                                               TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                               
                                                               // Use reflection to set current entry (protected method)
                                                               Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                               setCurrentEntry.setAccessible(true);
                                                               setCurrentEntry.invoke(tarInput, mockEntry);
                                                               
                                                               // Use reflection to call method under test (private method)
                                                               Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                               applyPaxHeaders.setAccessible(true);
                                                               applyPaxHeaders.invoke(tarInput, headers);
                                                               
                                                               // Verify behavior
                                                               verify(mockEntry).setUserName(testUserName);  // Should be called in original
                                                               verify(mockEntry, never()).setGroupName(testUserName);  // Should not be called for uname header
                                                               
                                                               // Additional verification to ensure no other unexpected interactions
                                                               verifyNoMoreInteractions(mockEntry);
                                                           }

    @Test
                                                      public void testApplyPaxHeadersToCurrentEntry_SizeHeaderWithDifferentStringObject() throws Exception {
                                                          // Setup
                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                          TarArchiveEntry entry = new TarArchiveEntry("test");
                                                          
                                                          // Use reflection to call protected setCurrentEntry
                                                          Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                          setCurrentEntry.setAccessible(true);
                                                          setCurrentEntry.invoke(tarInput, entry);
                                                          
                                                          // Create headers with "size" key that's a different String object
                                                          Map<String, String> headers = new HashMap<>();
                                                          String sizeKey = new String("size"); // Different object than literal "size"
                                                          headers.put(sizeKey, "12345");
                                                          
                                                          // Use reflection to call private applyPaxHeadersToCurrentEntry
                                                          Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                          applyPaxHeaders.setAccessible(true);
                                                          applyPaxHeaders.invoke(tarInput, headers);
                                                          
                                                          // Verify - original code would set size, mutant would skip
                                                          assertEquals(12345L, entry.getSize());
                                                      }

    @Test
                                                 public void testApplyPaxHeadersToCurrentEntry_DetectsLinkPathStringComparisonMutant() throws Exception {
                                                     // Create test data with constructed string to avoid string interning
                                                     Map<String, String> headers = new HashMap<>();
                                                     String linkPathKey = new String("linkpath"); // Force new String instance
                                                     String linkPathValue = "test/link/path";
                                                     headers.put(linkPathKey, linkPathValue);
                                                     
                                                     // Create mock entry and set up test class
                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                     TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                     
                                                     // Use reflection to call protected setCurrentEntry method
                                                     Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                     setCurrentEntryMethod.setAccessible(true);
                                                     setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                     
                                                     // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                     Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                     applyPaxHeadersMethod.setAccessible(true);
                                                     applyPaxHeadersMethod.invoke(tarInput, headers);
                                                     
                                                     // Verify the link name was set - this will fail with mutated code
                                                     verify(mockEntry).setLinkName(linkPathValue);
                                                     
                                                     // Additional verification that no other properties were set
                                                     verify(mockEntry, never()).setName(any());
                                                     verify(mockEntry, never()).setGroupId(anyLong());
                                                     verify(mockEntry, never()).setGroupName(anyString());
                                                     verify(mockEntry, never()).setUserId(anyLong());
                                                     verify(mockEntry, never()).setUserName(anyString());
                                                     verify(mockEntry, never()).setSize(anyLong());
                                                     verify(mockEntry, never()).setModTime(anyLong());
                                                     verify(mockEntry, never()).setDevMinor(anyInt());
                                                     verify(mockEntry, never()).setDevMajor(anyInt());
                                                 }

    @Test
                                            public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldSetLinkNameNotName2() throws Exception {
                                                // Create test data
                                                Map<String, String> headers = new HashMap<>();
                                                headers.put("linkpath", "/path/to/link");
                                                
                                                // Create mock entry
                                                TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                
                                                // Create instance
                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                
                                                // Use reflection to set current entry (protected method)
                                                Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                setCurrentEntryMethod.setAccessible(true);
                                                setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                
                                                // Use reflection to call applyPaxHeadersToCurrentEntry (private method)
                                                Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                applyPaxHeadersMethod.setAccessible(true);
                                                applyPaxHeadersMethod.invoke(tarInput, headers);
                                                
                                                // Verify linkpath was processed correctly
                                                verify(mockEntry).setLinkName("/path/to/link");
                                                verify(mockEntry, never()).setName("/path/to/link");
                                                
                                                // Additional verification that other methods weren't called unexpectedly
                                                verify(mockEntry, never()).setName(anyString());
                                                verify(mockEntry, never()).setGroupId(anyLong());
                                                verify(mockEntry, never()).setGroupName(anyString());
                                                verify(mockEntry, never()).setUserId(anyLong());
                                                verify(mockEntry, never()).setUserName(anyString());
                                                verify(mockEntry, never()).setSize(anyLong());
                                                verify(mockEntry, never()).setModTime(anyLong());
                                                verify(mockEntry, never()).setDevMinor(anyInt());
                                                verify(mockEntry, never()).setDevMajor(anyInt());
                                            }

    @Test
                                       public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldBeSetCorrectly1() throws Exception {
                                           // Prepare test data
                                           Map<String, String> headers = new HashMap<>();
                                           String expectedLinkPath = "test/link/path";
                                           headers.put("linkpath", expectedLinkPath);
                                           
                                           // Create mock objects
                                           TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                           InputStream mockStream = mock(InputStream.class);
                                           
                                           // Create instance and set current entry using reflection
                                           TarArchiveInputStream tarInput = new TarArchiveInputStream(mockStream);
                                           Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                           setCurrentEntryMethod.setAccessible(true);
                                           setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                           
                                           // Call the method under test using reflection
                                           Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                           applyPaxHeadersMethod.setAccessible(true);
                                           applyPaxHeadersMethod.invoke(tarInput, headers);
                                           
                                           // Verify the link path was set correctly
                                           verify(mockEntry).setLinkName(expectedLinkPath);
                                           
                                           // Additional verification that it wasn't set to null
                                           verify(mockEntry, never()).setLinkName(null);
                                       }

    @Test
                                  public void testApplyPaxHeadersToCurrentEntry_DetectsGidStringReferenceMutation1() throws Exception {
                                      // Create a new String object with same content but different reference
                                      String gidKey = new String("gid");
                                      
                                      // Create headers map with the non-interned gid key
                                      Map<String, String> headers = new HashMap<>();
                                      headers.put(gidKey, "1234");
                                      
                                      // Create mock entry to verify behavior
                                      TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                      
                                      // Create test instance
                                      TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                      
                                      // Use reflection to set current entry (protected method)
                                      Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                      setCurrentEntry.setAccessible(true);
                                      setCurrentEntry.invoke(tarInput, entry);
                                      
                                      // Use reflection to call applyPaxHeadersToCurrentEntry (private method)
                                      Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                      applyPaxHeaders.setAccessible(true);
                                      applyPaxHeaders.invoke(tarInput, headers);
                                      
                                      // Verify the group ID was set - this will fail with the mutant
                                      verify(entry).setGroupId(1234L);
                                      
                                      // Additional verification that no other setters were called
                                      verify(entry, never()).setName(any());
                                      verify(entry, never()).setLinkName(any());
                                      verify(entry, never()).setGroupName(any());
                                      verify(entry, never()).setUserId(any());
                                      verify(entry, never()).setUserName(any());
                                      verify(entry, never()).setSize(anyLong());
                                      verify(entry, never()).setModTime(anyLong());
                                      verify(entry, never()).setDevMinor(anyInt());
                                      verify(entry, never()).setDevMajor(anyInt());
                                  }

    @Test
                             public void testApplyPaxHeadersToCurrentEntryWithLargeGroupId() throws Exception {
                                 // Setup
                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                 TarArchiveEntry entry = new TarArchiveEntry("test");
                                 
                                 // Use reflection to access protected setCurrentEntry method
                                 Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                 setCurrentEntryMethod.setAccessible(true);
                                 setCurrentEntryMethod.invoke(tarInput, entry);
                                 
                                 // Create headers with a group ID larger than Integer.MAX_VALUE
                                 Map<String, String> headers = new HashMap<>();
                                 long largeGroupId = (long)Integer.MAX_VALUE + 1;
                                 headers.put("gid", String.valueOf(largeGroupId));
                                 
                                 // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                 Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                 applyPaxHeadersMethod.setAccessible(true);
                                 applyPaxHeadersMethod.invoke(tarInput, headers);
                                 
                                 // Verify
                                 assertEquals("Group ID should be set as long value", 
                                             largeGroupId, entry.getGroupId());
                                 
                                 // Additional verification that no exception was thrown
                                 assertTrue("Method should complete successfully", true);
                             }

    @Test
                        public void testApplyPaxHeadersToCurrentEntry_DetectsGnameMutant() throws Exception {
                            // Create a new string with same content but different object reference
                            String gnameKey = new String("gname");
                            String expectedGroupName = "testGroup";
                            
                            // Create headers map with the gname key
                            Map<String, String> headers = new HashMap<>();
                            headers.put(gnameKey, expectedGroupName);
                            
                            // Create mock TarArchiveEntry
                            TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                            
                            // Create instance
                            TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                            
                            // Use reflection to set current entry
                            Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                            setCurrentEntry.setAccessible(true);
                            setCurrentEntry.invoke(tarInput, currEntry);
                            
                            // Use reflection to call applyPaxHeadersToCurrentEntry
                            Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                            applyPaxHeaders.setAccessible(true);
                            applyPaxHeaders.invoke(tarInput, headers);
                            
                            // Verify the group name was set
                            verify(currEntry).setGroupName(expectedGroupName);
                            
                            // Additional verification that no other properties were set
                            verify(currEntry, never()).setName(anyString());
                            verify(currEntry, never()).setLinkName(anyString());
                            verify(currEntry, never()).setGroupId(anyLong());
                            verify(currEntry, never()).setUserId(anyLong());
                            verify(currEntry, never()).setUserName(anyString());
                            verify(currEntry, never()).setSize(anyLong());
                            verify(currEntry, never()).setModTime(anyLong());
                            verify(currEntry, never()).setDevMinor(anyInt());
                            verify(currEntry, never()).setDevMajor(anyInt());
                        }

    @Test
                   public void testApplyPaxHeadersToCurrentEntry_UserIdExceedsIntegerMax() throws Exception {
                       // Setup
                       TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                       TarArchiveEntry entry = mock(TarArchiveEntry.class);
                       
                       // Use reflection to access protected setCurrentEntry method
                       Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                       setCurrentEntryMethod.setAccessible(true);
                       setCurrentEntryMethod.invoke(tarInput, entry);
                       
                       // Create headers with a user ID that exceeds Integer.MAX_VALUE
                       Map<String, String> headers = new HashMap<>();
                       long largeUserId = Integer.MAX_VALUE + 1L; // This is 2^31, which is too big for int
                       headers.put("uid", String.valueOf(largeUserId));
                       
                       // Use reflection to access private applyPaxHeadersToCurrentEntry method
                       Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                       applyPaxHeadersMethod.setAccessible(true);
                       applyPaxHeadersMethod.invoke(tarInput, headers);
                       
                       // Verify
                       // The original code would handle this correctly with Long.parseLong
                       // The mutant would fail with Integer.parseInt
                       verify(entry).setUserId(largeUserId); // Verify it was set with the correct long value
                       
                       // Additional verification that the value was indeed treated as long
                       verify(entry, never()).setUserId(anyInt()); // Ensure no int version was called
                   }

    @Test
              public void testApplyPaxHeadersToCurrentEntry_DetectUnameStringComparisonMutant1() throws Exception {
                  // Create test data with "uname" key that's not reference-equal to literal
                  Map<String, String> headers = new HashMap<>();
                  String unameKey = new String("uname"); // Different object but same content
                  String expectedUserName = "testuser";
                  headers.put(unameKey, expectedUserName);
                  
                  // Create mock entry and input stream
                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                  TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                  
                  // Use reflection to call protected setCurrentEntry method
                  Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                  setCurrentEntryMethod.setAccessible(true);
                  setCurrentEntryMethod.invoke(tarInput, mockEntry);
                  
                  // Use reflection to call private applyPaxHeadersToCurrentEntry method
                  Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                  applyPaxHeadersMethod.setAccessible(true);
                  applyPaxHeadersMethod.invoke(tarInput, headers);
                  
                  // Verify the user name was set - this will fail for the mutant
                  verify(mockEntry).setUserName(expectedUserName);
                  
                  // Also verify no other unexpected interactions
                  verifyNoMoreInteractions(mockEntry);
              }

    @Test
         public void testApplyPaxHeadersToCurrentEntry_UserNameShouldBeSetFromHeaders() throws Exception {
             // Setup
             TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
             
             // Use reflection to call protected setCurrentEntry method
             Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
             setCurrentEntryMethod.setAccessible(true);
             setCurrentEntryMethod.invoke(inputStream, mockEntry);
             
             Map<String, String> headers = new HashMap<>();
             String expectedUserName = "testuser";
             headers.put("uname", expectedUserName);
             
             // Use reflection to call private applyPaxHeadersToCurrentEntry method
             Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
             applyPaxHeadersMethod.setAccessible(true);
             applyPaxHeadersMethod.invoke(inputStream, headers);
             
             // Verify
             verify(mockEntry).setUserName(expectedUserName);
             // Additional verification that it's not set to empty string
             verify(mockEntry, never()).setUserName("");
         }

    @Test
    public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserName_WhenUnameHeaderPresent3() throws Exception {
        // Arrange
        TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
        TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
        
        // Use reflection to access protected setCurrentEntry method
        Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
        setCurrentEntryMethod.setAccessible(true);
        setCurrentEntryMethod.invoke(tarInputStream, mockEntry);
        
        Map<String, String> headers = new HashMap<>();
        String expectedUserName = "testuser";
        headers.put("uname", expectedUserName);
        
        // Use reflection to access private applyPaxHeadersToCurrentEntry method
        Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
        applyPaxHeadersMethod.setAccessible(true);
        applyPaxHeadersMethod.invoke(tarInputStream, headers);
        
        // Assert
        // Verify setUserName was called with the correct value
        verify(mockEntry).setUserName(expectedUserName);
        // Verify setGroupName was NOT called with this value (to catch the mutant)
        verify(mockEntry, never()).setGroupName(expectedUserName);
    }


}
