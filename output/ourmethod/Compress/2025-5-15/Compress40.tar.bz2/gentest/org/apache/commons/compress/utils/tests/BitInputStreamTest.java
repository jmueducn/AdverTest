package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteOrder;
 
public class BitInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                          public void testReadBits_CountZero_ReturnsZero() throws Exception {
                                                                                              byte[] data = {0x12, 0x34};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(0, bis.readBits(0));
                                                                                          }

    @Test
                                                                                          public void testReadBits_BigEndian_SingleByte() throws Exception {
                                                                                              byte[] data = {(byte)0xAA}; // 10101010
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(0b1010, bis.readBits(4));
                                                                                              assertEquals(0b1010, bis.readBits(4));
                                                                                          }

    @Test
                                                                                          public void testReadBits_LittleEndian_SingleByte() throws Exception {
                                                                                              byte[] data = {(byte)0xAA}; // 10101010
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                                              
                                                                                              assertEquals(0b1010, bis.readBits(4));
                                                                                              assertEquals(0b1010, bis.readBits(4));
                                                                                          }

    @Test
                                                                                          public void testReadBits_BigEndian_MultipleBytes() throws Exception {
                                                                                              byte[] data = {(byte)0x12, (byte)0x34, (byte)0x56};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(0x123, bis.readBits(12));
                                                                                              assertEquals(0x45, bis.readBits(8));
                                                                                              assertEquals(0x6, bis.readBits(4));
                                                                                          }

    @Test
                                                                                          public void testReadBits_LittleEndian_MultipleBytes() throws Exception {
                                                                                              byte[] data = {(byte)0x12, (byte)0x34, (byte)0x56};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.LITTLE_ENDIAN);
                                                                                              
                                                                                              assertEquals(0x412, bis.readBits(12));
                                                                                              assertEquals(0x65, bis.readBits(8));
                                                                                          }

    @Test
                                                                                          public void testReadBits_EndOfStream_ReturnsNegative() throws Exception {
                                                                                              byte[] data = {};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(-1, bis.readBits(8));
                                                                                          }

    @Test
                                                                                          public void testReadBits_PartialEndOfStream() throws Exception {
                                                                                              byte[] data = {(byte)0x12};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(0x12, bis.readBits(8));
                                                                                              assertTrue(bis.readBits(8) < 0);
                                                                                          }

    @Test
                                                                                          public void testReadBits_LargeCountWithOverflow() throws Exception {
                                                                                              // Test with count > 57 bits (which triggers the overflow handling)
                                                                                              byte[] data = new byte[8];
                                                                                              for (int i = 0; i < 8; i++) {
                                                                                                  data[i] = (byte)0xFF; // All bits set
                                                                                              }
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              // Read 64 bits (should use overflow handling)
                                                                                              assertEquals(0xFFFFFFFFFFFFFFFFL, bis.readBits(64));
                                                                                          }

    @Test
                                                                                          public void testReadBits_MixedSizes() throws Exception {
                                                                                              byte[] data = {(byte)0x12, (byte)0x34, (byte)0x56, (byte)0x78};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(0x1, bis.readBits(4));
                                                                                              assertEquals(0x234, bis.readBits(12));
                                                                                              assertEquals(0x56, bis.readBits(8));
                                                                                              assertEquals(0x7, bis.readBits(4));
                                                                                              assertEquals(0x8, bis.readBits(4));
                                                                                          }

    @Test
                                                                                          public void testReadBits_ClearCacheBetweenReads() throws Exception {
                                                                                              byte[] data = {(byte)0x12, (byte)0x34};
                                                                                              InputStream input = new ByteArrayInputStream(data);
                                                                                              BitInputStream bis = new BitInputStream(input, ByteOrder.BIG_ENDIAN);
                                                                                              
                                                                                              assertEquals(0x12, bis.readBits(8));
                                                                                              bis.clearBitCache();
                                                                                              assertEquals(0x34, bis.readBits(8));
                                                                                          }

    @Test
                                                                                      public void testReadBits_InvalidCount_ThrowsException() throws Exception {
                                                                                          // Setup mock input stream
                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                          
                                                                                          // Create BitInputStream instance
                                                                                          BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
                                                                                          
                                                                                          // Setup expected exception rule
                                                                                          ExpectedException expectedException = ExpectedException.none();
                                                                                          expectedException.expect(IllegalArgumentException.class);
                                                                                          expectedException.expectMessage("count must not be negative or greater than 63");
                                                                                          
                                                                                          // Test the method with invalid count
                                                                                          bis.readBits(-1);
                                                                                      }

    @Test
                                                                                  public void testReadBitsOverflowCaseDetectsBitwiseOperatorMutant() throws Exception {
                                                                                      // Setup mock input stream to return specific bytes
                                                                                      InputStream mockIn = mock(InputStream.class);
                                                                                      when(mockIn.read())
                                                                                          .thenReturn(0xFF)  // First byte (all bits set)
                                                                                          .thenReturn(0xAA); // Second byte (10101010 pattern)
                                                                                  
                                                                                      // Create BitInputStream with little-endian byte order
                                                                                      BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                      
                                                                                      // Set up internal state to trigger overflow case
                                                                                      // bitsCachedSize needs to be < count but >= 57 would cause overflow
                                                                                      // We'll set count to 60 (which is > 57) to trigger the overflow case
                                                                                      int count = 60;
                                                                                      
                                                                                      // The mutation affects the case where overflowBits != 0
                                                                                      // We need to ensure we hit this case by having bitsCachedSize < count initially
                                                                                      
                                                                                      // Call readBits - this should use the AND operation with MASKS[count]
                                                                                      long result = bis.readBits(count);
                                                                                      
                                                                                      // Verify the result - with AND operation, only the lower 'count' bits should be set
                                                                                      // With OR operation, additional bits would be set incorrectly
                                                                                      long expected = 0xFFFFFFFFFFFFFFFL & ((1L << count) - 1); // Only lower 60 bits set
                                                                                      
                                                                                      assertEquals("The read bits should match exactly the lower count bits", 
                                                                                                  expected, result);
                                                                                      
                                                                                      // Verify the mock interactions
                                                                                      verify(mockIn, times(2)).read();
                                                                                  }

    @Test
                                                                                public void testReadBitsOverflowCaseDetectsAndVsXorMutant() throws Exception {
                                                                                    // Setup
                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                    when(mockIn.read())
                                                                                        .thenReturn(0xFF)  // First byte read (all bits 1)
                                                                                        .thenReturn(0xAA);  // Second byte read (10101010 pattern)
                                                                                    
                                                                                    BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                    
                                                                                    // Force overflow case by setting bitsCachedSize close to limit
                                                                                    // We use reflection to access private fields since we need to set up specific state
                                                                                    Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                    bitsCachedField.setAccessible(true);
                                                                                    bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set (7 bytes)
                                                                                    
                                                                                    Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                    bitsCachedSizeField.setAccessible(true);
                                                                                    bitsCachedSizeField.set(bis, 56);
                                                                                    
                                                                                    // Test - read 57 bits (will trigger overflow case)
                                                                                    long result = bis.readBits(57);
                                                                                    
                                                                                    // Verify - with AND operation we expect:
                                                                                    // First 56 bits: all 1s (from bitsCached)
                                                                                    // Next 1 bit: 1 (from first bit of 0xAA)
                                                                                    long mask56 = (1L << 56) - 1; // Equivalent to MASKS[56]
                                                                                    long expected = (0xFFFFFFFFFFFFFFL & mask56) | (1L << 56);
                                                                                    
                                                                                    assertEquals("Mutant not detected - XOR operation used instead of AND", expected, result);
                                                                                    
                                                                                    // Verify overflow bits were properly set (8-1=7 bits from 0xAA)
                                                                                    long remainingBits = (long)bitsCachedField.get(bis);
                                                                                    int remainingSize = (int)bitsCachedSizeField.get(bis);
                                                                                    assertEquals(0xAA >>> 1, remainingBits);
                                                                                    assertEquals(7, remainingSize);
                                                                                }

    @Test
                                                                            public void testReadBitsWithOverflowDetectsMutant() throws Exception {
                                                                                // Setup - create a scenario where overflowBits != 0
                                                                                // We need bitsCachedSize < count and bitsCachedSize >= 57
                                                                                // Let's set count to 58 (greater than 57) and bitsCachedSize to 56
                                                                                // This will trigger the overflow case
                                                                                
                                                                                // Mock input stream to return a test byte
                                                                                InputStream mockIn = mock(InputStream.class);
                                                                                when(mockIn.read()).thenReturn(0xFF); // return byte with all 1s
                                                                                
                                                                                // Create BitInputStream with little-endian order
                                                                                BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                                
                                                                                // Set up initial cache state
                                                                                // Using reflection to set private fields for testing
                                                                                Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                                bitsCachedField.setAccessible(true);
                                                                                bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set to 1
                                                                                
                                                                                Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                                bitsCachedSizeField.setAccessible(true);
                                                                                bitsCachedSizeField.set(bis, 56);
                                                                                
                                                                                // Test reading 58 bits (will need to read one more byte with overflow)
                                                                                long result = bis.readBits(58);
                                                                                
                                                                                // Verify the result - should be 56 bits from cache + 2 bits from new byte
                                                                                // With little-endian, new byte (0xFF) is shifted left by 56
                                                                                // Expected result is 0xFFFFFFFFFFFFFF | (0x3 << 56) = 0x3FFFFFFFFFFFFFF
                                                                                // Then masked with 58 bits (though long only has 64 bits)
                                                                                // The important part is that it's not masked with MASKS[0] (which would be 0)
                                                                                assertNotEquals(0L, result); // This would fail with the mutant
                                                                                assertEquals(0x03FFFFFFFFFFFFFFL, result);
                                                                                
                                                                                // Verify bitsCached and bitsCachedSize are updated correctly
                                                                                assertEquals(6, bitsCachedSizeField.get(bis)); // overflowBits = 8-2 = 6
                                                                                assertEquals(0x3FL, bitsCachedField.get(bis)); // remaining 6 bits from the byte
                                                                            }

    @Test
                                                                          public void testReadBitsWithOverflowDetectsMaskMutation() throws Exception {
                                                                              // Setup mock input stream to return specific bytes
                                                                              InputStream mockIn = mock(InputStream.class);
                                                                              when(mockIn.read())
                                                                                  .thenReturn(0xFF)  // First byte (all bits set)
                                                                                  .thenReturn(0x0F); // Second byte (lower 4 bits set)
                                                                              
                                                                              // Create BitInputStream with little-endian order
                                                                              BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                              
                                                                              // Set initial cache state to force overflow case
                                                                              // We'll request 60 bits when cache is empty to trigger overflow handling
                                                                              long result = bis.readBits(60);
                                                                              
                                                                              // Calculate masks directly instead of accessing private MASKS array
                                                                              long mask16 = (1L << 16) - 1;
                                                                              long mask61 = (1L << 61) - 1;
                                                                              
                                                                              // Expected value when masking 60 bits from 16 available bits (should be all 16 bits)
                                                                              long expected = 0xFFFFL & mask16;
                                                                              assertEquals(expected, result);
                                                                              
                                                                              // Additional verification - check that the mutant would produce wrong result
                                                                              // If mutant was active, it would try to use MASKS[61] which would likely be 0
                                                                              long mutantExpected = 0xFFFFL & mask61;
                                                                              assertNotEquals("Test should fail if mutant is present", mutantExpected, result);
                                                                          }

    @Test
                                                                      public void testReadBitsWithOverflowPreservesBitsForNextRead() throws Exception {
                                                                          // Setup mock input stream to return bytes that will cause overflow
                                                                          InputStream mockIn = mock(InputStream.class);
                                                                          when(mockIn.read())
                                                                              .thenReturn(0xFF)  // first byte
                                                                              .thenReturn(0xFF)  // second byte
                                                                              .thenReturn(0xFF)  // third byte
                                                                              .thenReturn(0xFF)  // fourth byte
                                                                              .thenReturn(0xFF)  // fifth byte
                                                                              .thenReturn(0xFF)  // sixth byte
                                                                              .thenReturn(0xFF)  // seventh byte
                                                                              .thenReturn(0x0F); // eighth byte (will cause overflow)
                                                                      
                                                                          BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                          
                                                                          // First read: read 56 bits (7 bytes) - fills cache but doesn't trigger overflow
                                                                          long firstRead = bis.readBits(56);
                                                                          assertEquals(0xFFFFFFFFFFFFFFL, firstRead);
                                                                          
                                                                          // Second read: read 8 bits - will trigger overflow handling
                                                                          // The eighth byte (0x0F) will be split: 4 bits used, 4 bits overflow
                                                                          long secondRead = bis.readBits(8);
                                                                          assertEquals(0xF0L, secondRead);  // First 4 bits from 0x0F shifted left 4
                                                                          
                                                                          // Third read: should use the overflow bits (4 bits from 0x0F)
                                                                          // This will fail with the mutant since it sets bitsCached to 0 instead of overflow
                                                                          long thirdRead = bis.readBits(4);
                                                                          assertEquals(0x0FL, thirdRead);  // Last 4 bits from 0x0F
                                                                          
                                                                          // Verify we've read exactly 8 bytes (56 + 8 + 4 = 68 bits)
                                                                          verify(mockIn, times(8)).read();
                                                                      }

    @Test
                                                                     public void testReadBitsWithOverflowDetectsMutant1() throws Exception {
                                                                         // Setup mock input stream to return specific bytes
                                                                         InputStream mockIn = mock(InputStream.class);
                                                                         when(mockIn.read())
                                                                             .thenReturn(0xFF)  // First byte (all 1s)
                                                                             .thenReturn(0xAA); // Second byte (10101010)
                                                                         
                                                                         // Create BitInputStream with big-endian order
                                                                         BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                         
                                                                         // Force the overflow condition by:
                                                                         // 1. First reading 56 bits (7 bytes) to fill cache to 56 bits
                                                                         // 2. Then reading 9 more bits which will trigger overflow path
                                                                         
                                                                         // First read 56 bits (7 bytes) to fill cache to 56 bits (just below 57)
                                                                         for (int i = 0; i < 7; i++) {
                                                                             bis.readBits(8);
                                                                         }
                                                                         
                                                                         // Now read 9 bits which will trigger the overflow path
                                                                         // First 8 bits come from next byte (0xAA), 1 bit comes from overflow
                                                                         long result = bis.readBits(9);
                                                                         
                                                                         // Verify the result is correct (first 8 bits of 0xAA shifted left 1 bit)
                                                                         assertEquals(0xAA << 1, result);
                                                                         
                                                                         // The key assertion - verify bitsCached contains the overflow (last 7 bits of 0xAA)
                                                                         // With the mutant, bitsCached would still contain previous value
                                                                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                         bitsCachedField.setAccessible(true);
                                                                         long actualBitsCached = bitsCachedField.getLong(bis);
                                                                         
                                                                         assertEquals(0xAA & 0x7F, actualBitsCached); // 0x7F masks last 7 bits
                                                                         
                                                                         // Also verify bitsCachedSize is correct (7 bits remaining)
                                                                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                         bitsCachedSizeField.setAccessible(true);
                                                                         int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                         
                                                                         assertEquals(7, actualBitsCachedSize);
                                                                     }

    @Test
                                                                    public void testReadBitsWithOverflowDetectsMutant2() throws Exception {
                                                                        // Setup mock input stream to return specific bytes
                                                                        InputStream mockIn = mock(InputStream.class);
                                                                        when(mockIn.read())
                                                                            .thenReturn(0xFF)  // First byte to fill initial cache
                                                                            .thenReturn(0xAA); // Second byte that will cause overflow
                                                                        
                                                                        // Create BitInputStream with little-endian order
                                                                        BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                        
                                                                        // First read to fill the cache (8 bits)
                                                                        bis.readBits(8);
                                                                        
                                                                        // Now read more bits to trigger overflow case
                                                                        // We'll request 57 bits which is more than the 8 we have cached
                                                                        // This will trigger the overflow handling path where the mutant exists
                                                                        long result = bis.readBits(57);
                                                                        
                                                                        // Verify the result is correct (we don't care about exact value here)
                                                                        // The key is to check the cache state after the operation
                                                                        // Get the private bitsCached field using reflection
                                                                        Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                        bitsCachedField.setAccessible(true);
                                                                        long actualBitsCached = bitsCachedField.getLong(bis);
                                                                        
                                                                        // The overflow value should be 0xAA (10101010) shifted right by (57-8=49) bits
                                                                        // But since we're in little-endian, the overflow is (nextByte >>> bitsToAddCount)
                                                                        // bitsToAddCount = 57 - 8 = 49
                                                                        // overflow = (0xAA >>> 49) & MASKS[8-49] (but since 49 > 8, this would be 0)
                                                                        // So expected bitsCached should be 0 (overflow was 0)
                                                                        assertEquals(0L, actualBitsCached);
                                                                        
                                                                        // Also verify bitsCachedSize is correct
                                                                        Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                        bitsCachedSizeField.setAccessible(true);
                                                                        int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                        assertEquals(0, actualBitsCachedSize);
                                                                    }

    @Test
                                                                    public void testReadBitsWithOverflowDetectsMutant3() throws Exception {
                                                                        // Setup mock input stream to return specific bytes
                                                                        InputStream mockIn = mock(InputStream.class);
                                                                        when(mockIn.read())
                                                                            .thenReturn(0xFF)  // First byte to fill initial cache (8 bits)
                                                                            .thenReturn(0x01); // Second byte that will cause overflow
                                                                        
                                                                        // Create BitInputStream with big-endian order (makes overflow calculation clearer)
                                                                        BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                                                        
                                                                        // First read to fill the cache (8 bits)
                                                                        bis.readBits(8);
                                                                        
                                                                        // Now read 9 bits to trigger overflow case (we have 8, need 1 more)
                                                                        // This will read the 0x01 byte and:
                                                                        // bitsToAddCount = 1, overflowBits = 7
                                                                        // For big-endian:
                                                                        // bitsToAdd = (0x01 >>> 7) & MASKS[1] = 0
                                                                        // overflow = 0x01 & MASKS[7] = 1
                                                                        bis.readBits(9);
                                                                        
                                                                        // Get the private bitsCached field using reflection
                                                                        Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                                        bitsCachedField.setAccessible(true);
                                                                        long actualBitsCached = bitsCachedField.getLong(bis);
                                                                        
                                                                        // Original: bitsCached should be overflow (1)
                                                                        // Mutant: bitsCached would be overflow << 1 (2)
                                                                        assertEquals(1L, actualBitsCached);
                                                                        
                                                                        // Also verify bitsCachedSize is correct (should be overflowBits = 7)
                                                                        Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                        bitsCachedSizeField.setAccessible(true);
                                                                        int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                        assertEquals(7, actualBitsCachedSize);
                                                                    }

    @Test
                                                                  public void testReadBitsOverflowCaseDetectsMutant() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                      // Setup mock input stream to return specific bytes
                                                                      InputStream mockIn = mock(InputStream.class);
                                                                      when(mockIn.read())
                                                                          .thenReturn(0xFF)  // First byte (all 1s)
                                                                          .thenReturn(0xFF)  // Second byte
                                                                          .thenReturn(0xFF)  // Third byte
                                                                          .thenReturn(0xFF)  // Fourth byte
                                                                          .thenReturn(0xFF)  // Fifth byte
                                                                          .thenReturn(0xFF)  // Sixth byte
                                                                          .thenReturn(0xFF)  // Seventh byte (total 56 bits)
                                                                          .thenReturn(0x0F); // Eighth byte (4 bits needed, 4 overflow)
                                                                      
                                                                      BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                                      
                                                                      // First read 56 bits to fill the cache almost to overflow (56 < 57)
                                                                      bis.readBits(56);
                                                                      
                                                                      // Now read 60 bits - this will trigger the overflow case
                                                                      // Original: bitsCachedSize should be set to overflowBits (4)
                                                                      // Mutant: bitsCachedSize will be set to 0
                                                                      bis.readBits(60);
                                                                      
                                                                      // Use reflection to access private bitsCachedSize field
                                                                      Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                      bitsCachedSizeField.setAccessible(true);
                                                                      int bitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                      
                                                                      // Verify the bitsCachedSize is properly set to overflowBits (4)
                                                                      // This will fail for the mutant which sets it to 0
                                                                      assertEquals("bitsCachedSize should equal overflowBits after overflow case", 
                                                                                   4, bitsCachedSize);
                                                                      
                                                                      // Additional verification that the next read works correctly
                                                                      // This depends on bitsCachedSize being correct
                                                                      when(mockIn.read()).thenReturn(0xFF);
                                                                      long result = bis.readBits(4);
                                                                      assertEquals("Should be able to read remaining overflow bits", 
                                                                                  0x0F, result);
                                                                  }

    @Test
                                                             public void testReadBitsWithOverflow_ShouldSetCorrectCacheSize() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                 // Setup
                                                                 InputStream mockInput = mock(InputStream.class);
                                                                 when(mockInput.read())
                                                                     .thenReturn(0xFF)  // first byte (will be read until bitsCachedSize >= 57)
                                                                     .thenReturn(0xFF)  // second byte
                                                                     .thenReturn(0xFF)  // third byte
                                                                     .thenReturn(0xFF)  // fourth byte
                                                                     .thenReturn(0xFF)  // fifth byte
                                                                     .thenReturn(0xFF)  // sixth byte
                                                                     .thenReturn(0xFF)  // seventh byte (will trigger overflow)
                                                                     .thenReturn(-1);   // end of stream
                                                                 
                                                                 BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                                 
                                                                 // Test a count that will trigger overflow (count > 57)
                                                                 int count = 58;
                                                                 long result = bis.readBits(count);
                                                                 
                                                                 // Use reflection to access private bitsCachedSize field
                                                                 Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                 bitsCachedSizeField.setAccessible(true);
                                                                 int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                 
                                                                 // Verify the bitsCachedSize is set to overflowBits (8 - (58 - 57) = 7)
                                                                 // This will fail with the mutant which sets it to count (58)
                                                                 assertEquals(7, actualBitsCachedSize);
                                                                 
                                                                 // Also verify the result is correct (all 58 bits set)
                                                                 assertEquals((1L << 58) - 1, result);
                                                                 
                                                                 // Verify we read exactly 7 bytes (6 to fill cache + 1 for overflow)
                                                                 verify(mockInput, times(7)).read();
                                                             }

    @Test
                                                        public void testReadBitsWithOverflowDetectsMutant4() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                            // Setup - create a scenario where overflow will occur (bitsCachedSize >= 57)
                                                            InputStream mockIn = mock(InputStream.class);
                                                            when(mockIn.read())
                                                                .thenReturn(0xFF)  // first byte (will be shifted in)
                                                                .thenReturn(0xFF)  // second byte
                                                                .thenReturn(0xFF)  // third byte
                                                                .thenReturn(0xFF)  // fourth byte
                                                                .thenReturn(0xFF)  // fifth byte
                                                                .thenReturn(0xFF)  // sixth byte
                                                                .thenReturn(0xFF)  // seventh byte (will cause overflow)
                                                                .thenReturn(-1);   // end of stream
                                                            
                                                            // Test both byte orders
                                                            for (ByteOrder byteOrder : new ByteOrder[]{ByteOrder.LITTLE_ENDIAN, ByteOrder.BIG_ENDIAN}) {
                                                                BitInputStream bis = new BitInputStream(mockIn, byteOrder);
                                                                
                                                                // Get access to private bitsCachedSize field
                                                                Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                                bitsCachedSizeField.setAccessible(true);
                                                                
                                                                // First read 56 bits to fill cache almost to limit (7 bytes * 8 bits)
                                                                bis.readBits(56);
                                                                
                                                                // Now read 8 more bits - this will trigger overflow handling
                                                                // We're reading 8 bits when we have 56 cached (total 64 requested)
                                                                // This will leave 0 overflow bits (8 - (64-56) = 0)
                                                                long result = bis.readBits(8);
                                                                
                                                                // Verify the cache size is exactly overflowBits (which should be 0)
                                                                // This will fail with the mutant which sets it to overflowBits + 1
                                                                int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
                                                                assertEquals("Cache size should equal overflowBits after overflow handling", 
                                                                            0, actualBitsCachedSize);
                                                                
                                                                // Verify we got the expected bits (all 1s in this case)
                                                                assertEquals(0xFFL, result);
                                                                
                                                                // Reset for next iteration
                                                                reset(mockIn);
                                                                when(mockIn.read())
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(0xFF)
                                                                    .thenReturn(-1);
                                                            }
                                                        }

    @Test
                                                    public void testReadBitsWithOverflowDetectsBitwiseOperatorMutant() throws Exception {
                                                        // Setup mock input stream to return specific bytes
                                                        InputStream mockIn = mock(InputStream.class);
                                                        when(mockIn.read())
                                                            .thenReturn(0xFF)  // first byte (all 1s)
                                                            .thenReturn(0xAA); // second byte (10101010)
                                                        
                                                        // Create BitInputStream with little-endian order
                                                        BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                        
                                                        // Set up initial cache state to force overflow case
                                                        // We'll request 60 bits (more than 57 triggers overflow logic)
                                                        int count = 60;
                                                        
                                                        // Call method and verify result
                                                        long result = bis.readBits(count);
                                                        
                                                        // The correct behavior should mask the bits, not OR them
                                                        // With the mutation (using | instead of &), the result would be different
                                                        // For little-endian, first byte is 0xFF, second byte masked to 4 bits (0xA)
                                                        // Expected: 0x0000000000000AFF (since we take 60 bits from 64 bits read)
                                                        // Mutated would OR with mask, producing incorrect value
                                                        assertEquals(0x0000000000000AFFL, result);
                                                        
                                                        // Verify mock interactions
                                                        verify(mockIn, times(2)).read();
                                                    }

    @Test
                                                  public void testReadBits_DetectsBitwiseOperatorMutant() throws Exception {
                                                      // Setup
                                                      InputStream mockInput = mock(InputStream.class);
                                                      when(mockInput.read())
                                                          .thenReturn(0xFF)  // First byte (all 1s)
                                                          .thenReturn(0xAA); // Second byte (10101010)
                                                      
                                                      BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                                      
                                                      // Use reflection to access private fields
                                                      Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                                      bitsCachedField.setAccessible(true);
                                                      Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                                      bitsCachedSizeField.setAccessible(true);
                                                      
                                                      // Force the overflow case by setting up cache state
                                                      // Set bitsCachedSize to 56 (MAXIMUM_CACHE_SIZE - 8 to trigger overflow)
                                                      bitsCachedField.set(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set (7 bytes)
                                                      bitsCachedSizeField.set(bis, 56);
                                                      
                                                      // Request 60 bits (will need to read one more byte with overflow)
                                                      int count = 60;
                                                      
                                                      // Expected behavior:
                                                      // Original: bitsOut = bitsCached & MASKS[count] (60 bits)
                                                      // Should return lower 60 bits of (0xFFFFFFFFFFFFFF + (0xAA & 0xF) << 56)
                                                      // Which is 0xFFFFFFFFFFFFFF & 0x0FFFFFFFFFFFFFFF (no change)
                                                      // Mutant: bitsOut = bitsCached ^ MASKS[count] would flip bits
                                                      
                                                      // Execute
                                                      long result = bis.readBits(count);
                                                      
                                                      // Verify - should equal the AND operation result
                                                      long expected = 0xFFFFFFFFFFFFFFL;
                                                      assertEquals("Mutant not detected - XOR used instead of AND", expected, result);
                                                      
                                                      // Verify cache state was updated correctly using reflection
                                                      assertEquals(4, bitsCachedSizeField.get(bis)); // overflowBits = 4 (8 - (60-56))
                                                      assertEquals(0xAL, bitsCachedField.get(bis));  // overflow should be upper 4 bits of 0xAA (1010)
                                                  }

    @Test
                                              public void testReadBitsDetectsMaskMutation() throws IOException {
                                                  // Setup test data - we'll test reading 4 bits (0101) from a byte
                                                  byte[] testData = {(byte)0x5A}; // binary: 01011010
                                                  InputStream mockInputStream = mock(InputStream.class);
                                                  when(mockInputStream.read()).thenReturn((int)testData[0] & 0xFF);
                                                  
                                                  // Create BitInputStream with little-endian order
                                                  BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.LITTLE_ENDIAN);
                                                  
                                                  // First read 4 bits - should be 0101 (5 in decimal)
                                                  long result = bis.readBits(4);
                                                  
                                                  // Verify the result matches expected bits
                                                  assertEquals(5L, result); // This will fail if mutant is present (would return 0 or 1)
                                                  
                                                  // Verify interaction with mock
                                                  verify(mockInputStream, times(1)).read();
                                              }

    @Test
                                             public void testReadBitsWithOverflowDetectsMaskMutation1() throws Exception {
                                                 // Setup mock input stream to return specific bytes
                                                 InputStream mockIn = mock(InputStream.class);
                                                 when(mockIn.read()).thenReturn(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF);
                                                 
                                                 // Create BitInputStream with little-endian order
                                                 BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                 
                                                 // Force the overflow condition by:
                                                 // 1. First read 56 bits (7 bytes) to fill cache nearly completely
                                                 bis.readBits(56);
                                                 
                                                 // 2. Now read 8 more bits which will trigger the overflow path
                                                 // The original code should return exactly 8 bits (0xFF)
                                                 // The mutant will try to mask 9 bits (count+1) which would throw ArrayIndexOutOfBoundsException
                                                 // or return incorrect value if MASKS array is large enough
                                                 long result = bis.readBits(8);
                                                 
                                                 // Verify exactly 8 bits are returned (0xFF)
                                                 assertEquals(0xFF, result);
                                                 
                                                 // Verify mock interactions
                                                 verify(mockIn, times(8)).read(); // 7 for initial 56 bits + 1 for the overflow byte
                                             }

    @Test
                                            public void testReadBitsWithOverflowPreservesCache() throws Exception {
                                                // Setup mock input stream to return test bytes
                                                InputStream mockIn = mock(InputStream.class);
                                                when(mockIn.read())
                                                    .thenReturn(0xFF)  // first byte (all bits set)
                                                    .thenReturn(0xAA)  // second byte (overflow byte)
                                                    .thenReturn(0x55); // third byte (for verification)
                                                
                                                // Create BitInputStream with little-endian order
                                                BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                                
                                                // First read: 57 bits (will trigger overflow handling on next read)
                                                long firstRead = bis.readBits(57);
                                                assertEquals((1L << 57) - 1, firstRead); // all 57 bits should be 1
                                                
                                                // Second read: 8 bits (should use the overflow bits from previous read)
                                                // The overflow from reading 57 bits of 0xFF and 0xAA would be:
                                                // - For original: overflow would be 0xAA >>> (64-57) = 0x55
                                                // - For mutant: overflow would be 0
                                                long secondRead = bis.readBits(8);
                                                
                                                // Verify the read bits (should be the overflow bits)
                                                // Original would return 0x55, mutant would return 0
                                                assertEquals(0x55, secondRead);
                                                
                                                // Verify the cache state for next read
                                                // Original would have bitsCached = 0 (since all overflow bits were consumed)
                                                // Mutant would also have bitsCached = 0, but for wrong reasons
                                                // So we need another read to detect the difference
                                                
                                                // Third read: 8 bits (should come from new byte)
                                                long thirdRead = bis.readBits(8);
                                                assertEquals(0x55, thirdRead); // comes from mock's third byte
                                                
                                                // Verify mock interactions
                                                verify(mockIn, times(3)).read();
                                            }

    @Test
                                           public void testReadBitsWithOverflowPreservesStateForNextRead() throws IOException {
                                               // Setup mock input stream to return bytes that will cause overflow
                                               InputStream mockIn = mock(InputStream.class);
                                               when(mockIn.read())
                                                   .thenReturn(0xFF)  // First byte (all 1s)
                                                   .thenReturn(0xFF)  // Second byte (all 1s)
                                                   .thenReturn(0xFF); // Third byte (all 1s)
                                               
                                               BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                               
                                               // First read: 57 bits (will cause overflow)
                                               long firstRead = bis.readBits(57);
                                               assertEquals((1L << 57) - 1, firstRead); // Should read all 57 bits as 1
                                               
                                               // Second read: 7 bits (should come from overflow)
                                               long secondRead = bis.readBits(7);
                                               // With original code: should be last 7 bits of third byte (all 1s)
                                               // With mutant: would be something else as it didn't store overflow
                                               assertEquals(0x7F, secondRead); // 7 bits of 1s
                                               
                                               // Verify we only read 3 bytes from the stream
                                               verify(mockIn, times(3)).read();
                                           }

    @Test
                                          public void testReadBitsWithOverflowDetectsMutant5() throws IOException {
                                              // Setup mock input stream that will return specific bytes
                                              InputStream mockIn = mock(InputStream.class);
                                              when(mockIn.read())
                                                  .thenReturn(0xFF)  // first byte (all 1s)
                                                  .thenReturn(0xFF)  // second byte
                                                  .thenReturn(0xFF)  // third byte
                                                  .thenReturn(0xFF)  // fourth byte
                                                  .thenReturn(0xFF)  // fifth byte
                                                  .thenReturn(0xFF)  // sixth byte
                                                  .thenReturn(0xFF)  // seventh byte
                                                  .thenReturn(0x0F); // eighth byte (only lower 4 bits set)
                                          
                                              BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                              
                                              // First read: request 64 bits (8 bytes) which will trigger overflow condition
                                              // The method will read 7 full bytes (56 bits) and then 8 bits from the 8th byte
                                              // but since we can't store more than 57 bits, it will take 4 bits from the 8th byte
                                              // and leave 4 bits as overflow
                                              long result = bis.readBits(64);
                                              
                                              // Verify the first read result (should be 0xFFFFFFFFFFFFFFF0)
                                              assertEquals(0xFFFFFFFFFFFFFFF0L, result);
                                              
                                              // Now verify the overflow bits are properly preserved for next read
                                              // The remaining 4 bits should be 0x0F (lower 4 bits of last byte)
                                              // With the mutation (<<1), this would be 0x1E instead
                                              result = bis.readBits(4);
                                              assertEquals(0x0F, result);  // This will fail if mutation is present
                                              
                                              // Verify we read exactly 8 bytes from the stream
                                              verify(mockIn, times(8)).read();
                                          }

    @Test
                                         public void testReadBits_OverflowHandlingPreservesCacheSize() throws IOException {
                                             // Setup mock input stream that will return 8 bytes (64 bits)
                                             InputStream mockIn = mock(InputStream.class);
                                             when(mockIn.read())
                                                 .thenReturn(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF);
                                             
                                             // Create BitInputStream with big-endian order
                                             BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                             
                                             // First read: 57 bits (will trigger overflow handling)
                                             long result1 = bis.readBits(57);
                                             assertEquals((1L << 57) - 1, result1); // Should get all 57 bits set
                                             
                                             // Verify internal state after first read
                                             // Original code would have bitsCachedSize = 7 (64-57=7 overflow bits)
                                             // Mutant would have bitsCachedSize = 0
                                             
                                             // Second read: remaining 7 bits
                                             long result2 = bis.readBits(7);
                                             assertEquals(0x7FL, result2); // Should get remaining 7 bits (all set)
                                             
                                             // Verify mock interactions
                                             verify(mockIn, times(8)).read(); // Should have read exactly 8 bytes
                                         }

    @Test
                                       public void testReadBits_OverflowScenario_DetectsMutant() throws IOException {
                                           // Setup - create a scenario where overflow occurs (count > 57)
                                           InputStream mockInput = mock(InputStream.class);
                                           when(mockInput.read())
                                               .thenReturn(0xFF)  // first byte
                                               .thenReturn(0xFF)  // second byte
                                               .thenReturn(0xFF)  // third byte
                                               .thenReturn(0xFF)  // fourth byte
                                               .thenReturn(0xFF)  // fifth byte
                                               .thenReturn(0xFF)  // sixth byte
                                               .thenReturn(0xFF)  // seventh byte
                                               .thenReturn(0xFF); // eighth byte (overflow byte)
                                           
                                           BitInputStream bis = new BitInputStream(mockInput, ByteOrder.LITTLE_ENDIAN);
                                           
                                           // First read 57 bits (7 full bytes + 1 bit from 8th byte)
                                           long result = bis.readBits(57);
                                           assertEquals(0x1FFFFFFFFFFFFFFL, result); // 57 bits of 1s
                                           
                                           // Verify bitsCachedSize should be 7 (8 - 1 bit taken) after overflow
                                           // This is where the mutant would fail - it would set it to count (57)
                                           
                                           // Subsequent read should get the remaining 7 bits
                                           result = bis.readBits(7);
                                           assertEquals(0x7F, result); // remaining 7 bits of the 8th byte
                                           
                                           // Verify no more bits are cached
                                           try {
                                               Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                               bitsCachedSizeField.setAccessible(true);
                                               int remainingBits = bitsCachedSizeField.getInt(bis);
                                               assertEquals(0, remainingBits);
                                           } catch (NoSuchFieldException | IllegalAccessException e) {
                                               fail("Failed to access bitsCachedSize field: " + e.getMessage());
                                           }
                                       }

    @Test
                                  public void testReadBitsWithOverflowDetectsMutant6() throws IOException, NoSuchFieldException, IllegalAccessException {
                                      // Setup - create a scenario where overflow will occur (count > 57)
                                      InputStream mockInput = mock(InputStream.class);
                                      when(mockInput.read()).thenReturn(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF);
                                      
                                      BitInputStream bis = new BitInputStream(mockInput, ByteOrder.BIG_ENDIAN);
                                      
                                      // Use reflection to access private fields
                                      Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                      bitsCachedSizeField.setAccessible(true);
                                      Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                      bitsCachedField.setAccessible(true);
                                      
                                      // First read to fill the cache (57 bits)
                                      bis.readBits(57);
                                      
                                      // Now read more to trigger overflow case
                                      // The overflowBits should be 7 (since 64-57=7)
                                      long result = bis.readBits(8);
                                      
                                      // Verify the cache size is correctly set to overflowBits (7)
                                      // This will fail with the mutant which would set it to 8
                                      assertEquals(7, bitsCachedSizeField.getInt(bis));
                                      
                                      // Also verify the overflow bits were properly stored
                                      assertEquals(0x1L, bitsCachedField.getLong(bis)); // Only the highest bit should remain (0xFF >>> 7 = 0x1)
                                      
                                      // Verify the returned bits are correct
                                      assertEquals(0xFF, result);
                                  }

    @Test
                              public void testReadBitsDetectsBitwiseOperatorMutant() throws IOException {
                                  // Setup - create a mock InputStream that will return specific bytes
                                  InputStream mockIn = mock(InputStream.class);
                                  when(mockIn.read())
                                      .thenReturn(0xFF)  // first byte (all 1s)
                                      .thenReturn(0xAA); // second byte (10101010 pattern)
                                  
                                  // Create BitInputStream with little-endian order
                                  BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                  
                                  // Force the overflow case by:
                                  // 1. First reading 56 bits (7 bytes) to nearly fill the cache
                                  // 2. Then reading 8 more bits which will trigger the overflow path
                                  bis.readBits(56);  // fills cache with 56 bits (7 bytes of 0xFF)
                                  
                                  // Now read 8 bits which will trigger the overflow case where the mutant exists
                                  // With original code (using &), this should return 0xFF (11111111)
                                  // With mutant (using |), this would return 0xFF | 0xAA = 0xFF (same in this case)
                                  // So we need a different test case
                                  
                                  // Reset and try a different pattern that will show the difference
                                  mockIn = mock(InputStream.class);
                                  when(mockIn.read())
                                      .thenReturn(0x55)  // 01010101
                                      .thenReturn(0x0F); // 00001111
                                  
                                  bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                  bis.readBits(56);  // fills cache with 56 bits of 0x55 pattern
                                  
                                  // Now read 4 bits - this will:
                                  // 1. Need to read another byte (0x0F)
                                  // 2. Take first 4 bits (since 56 + 8 > 57 limit)
                                  // Original: (cached & mask) = 0x...55 & 0xF = 0x5
                                  // Mutant: (cached | mask) = 0x...55 | 0xF = 0xF
                                  long result = bis.readBits(4);
                                  
                                  // Verify the correct behavior (AND operation)
                                  assertEquals(0x5, result);  // This will fail if mutant is present (would get 0xF)
                                  
                                  // Additional verification for big-endian case
                                  mockIn = mock(InputStream.class);
                                  when(mockIn.read())
                                      .thenReturn(0xAA)  // 10101010
                                      .thenReturn(0xF0); // 11110000
                                  
                                  bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                                  bis.readBits(56);  // fills cache with 56 bits of 0xAA pattern
                                  
                                  // Read 4 bits - in big-endian, this takes the high bits
                                  // Original: (cached >> (size-count)) & mask = (0x...AA >> 52) & 0xF = 0xA
                                  // Mutant in overflow case would use OR instead of AND
                                  result = bis.readBits(4);
                                  assertEquals(0xA, result);  // Would fail with mutant (would get 0xF)
                              }

    @Test
                             public void testReadBitsOverflowCaseDetectsAndVsXorMutant1() throws Exception {
                                 // Setup mock input stream to return specific bytes
                                 InputStream mockIn = mock(InputStream.class);
                                 when(mockIn.read())
                                     .thenReturn(0xFF)  // First byte (all 1s)
                                     .thenReturn(0xAA); // Second byte (10101010)
                                 
                                 // Create BitInputStream with little-endian order
                                 BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                                 
                                 // Set up internal state to trigger overflow case
                                 // bitsCached = 0xFFFFFFFF (32 bits)
                                 // bitsCachedSize = 32
                                 // count = 40 (needs 8 more bits, but will trigger overflow handling)
                                 Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                                 bitsCachedField.setAccessible(true);
                                 bitsCachedField.set(bis, 0xFFFFFFFFL);
                                 
                                 Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                                 bitsCachedSizeField.setAccessible(true);
                                 bitsCachedSizeField.set(bis, 32);
                                 
                                 // Get MASKS array through reflection
                                 Field masksField = BitInputStream.class.getDeclaredField("MASKS");
                                 masksField.setAccessible(true);
                                 long[] masks = (long[]) masksField.get(null);
                                 
                                 // Calculate expected value - should use AND operation
                                 long expected = 0xFFFFFFFFL & masks[40]; // AND operation
                                 long unexpected = 0xFFFFFFFFL ^ masks[40]; // XOR operation (mutant)
                                 
                                 // Verify the actual result matches AND operation, not XOR
                                 long result = bis.readBits(40);
                                 assertEquals("Output should be result of AND operation with mask", expected, result);
                                 assertNotEquals("Output should not match XOR operation result", unexpected, result);
                                 
                                 // Verify the remaining bits were properly handled
                                 long remainingBits = (long) bitsCachedField.get(bis);
                                 assertEquals("Remaining bits should be properly set", 0xAA >>> 8, remainingBits);
                             }

    @Test
                           public void testReadBitsWithOverflowDetectsMaskMutation2() throws Exception {
                               // Setup - create a scenario where overflowBits != 0
                               // We need bitsCachedSize < count and bitsCachedSize >= 57
                               // Let's set count to 60 (which is >57) and bitsCachedSize to 56 (which is <60)
                               
                               // Mock input stream to return a test byte when read
                               InputStream mockIn = mock(InputStream.class);
                               when(mockIn.read()).thenReturn(0xFF); // return byte with all 1s
                               
                               // Create BitInputStream with little-endian order
                               BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                               
                               // Use reflection to access private fields
                               Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                               bitsCachedField.setAccessible(true);
                               Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                               bitsCachedSizeField.setAccessible(true);
                               
                               // Set up internal state to trigger the overflow case
                               // bitsCachedSize = 56 (7 bytes), bitsCached = some value
                               bitsCachedField.setLong(bis, 0xFFFFFFFFFFFFFFL); // 56 bits set to 1
                               bitsCachedSizeField.setInt(bis, 56);
                               
                               // Request 60 bits (which will need overflow handling)
                               long result = bis.readBits(60);
                               
                               // Verify the result is properly masked for 60 bits
                               // Since we're in little-endian mode and overflowBits case,
                               // the result should be the first 60 bits of our 64-bit value
                               // With the mutation, this would return 0 instead
                               assertEquals(0xFFFFFFFFFFFFFFFL, result);
                               
                               // Verify the remaining bits are properly cached
                               assertEquals(4, bitsCachedSizeField.getInt(bis)); // 60-56=4 bits overflow
                               assertEquals(0xFL, bitsCachedField.getLong(bis)); // last 4 bits should be cached
                           }

    @Test
                      public void testReadBitsWithOverflowDetectsMutant7() throws Exception {
                          // Setup mock input stream to return specific bytes
                          InputStream mockIn = mock(InputStream.class);
                          when(mockIn.read())
                              .thenReturn(0xFF)  // First byte (all 1s)
                              .thenReturn(0xAA); // Second byte (10101010)
                          
                          // Create BitInputStream with little-endian order
                          BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                          
                          // Set up test where we request 60 bits (forcing overflow case)
                          // First read will cache 56 bits (7 bytes), second read will handle overflow
                          long result = bis.readBits(60);
                          
                          // Verify the result only contains exactly 60 bits
                          // The mutant would allow 61 bits through due to MASKS[count+1]
                          long expectedMax = (1L << 60) - 1;  // Maximum 60-bit value
                          assertTrue("Result should not exceed 60 bits", result <= expectedMax);
                          
                          // Verify the exact bits when count=60
                          // With the mutation, some bits might be incorrectly included
                          // Calculate expected 60-bit value:
                          // First byte (0xFF) provides 8 bits (all 1s)
                          // Second byte (0xAA) provides 4 bits (1010) to make total 12 bits
                          // Then we need 48 more bits (60 total) which will be 0 (since we only have 2 bytes)
                          // In little-endian: 0xAAFF (1010101011111111) followed by 48 0s
                          long expectedValue = 0xAAFFL;
                          assertEquals("Result should match exactly 60 bits from input", expectedValue, result);
                      }

    @Test
                  public void testReadBitsWithOverflowPreservesCache1() throws Exception {
                      // Setup mock input stream that will return bytes in sequence
                      InputStream mockIn = mock(InputStream.class);
                      when(mockIn.read())
                          .thenReturn(0xFF)  // First byte (all 1s)
                          .thenReturn(0xAA); // Second byte (10101010)
                      
                      // Create BitInputStream with little-endian order
                      BitInputStream bis = new BitInputStream(mockIn, ByteOrder.LITTLE_ENDIAN);
                      
                      // First read: 57 bits (will trigger overflow handling)
                      long firstRead = bis.readBits(57);
                      
                      // Verify first read (should get 57 bits from first byte)
                      assertEquals((1L << 57) - 1, firstRead);
                      
                      // Second read: 7 bits (should get remaining overflow bits)
                      long secondRead = bis.readBits(7);
                      
                      // In original code: should get remaining 7 bits (0x7F) from overflow
                      // In mutated code: will get 0 because overflow was set to 0
                      assertEquals(0x7F, secondRead);
                      
                      // Verify mock interactions
                      verify(mockIn, times(2)).read();
                  }

    @Test
                 public void testReadBitsWithOverflowDetectsMutant8() throws Exception {
                     // Setup mock input stream that will return bytes when needed
                     InputStream mockIn = mock(InputStream.class);
                     when(mockIn.read())
                         .thenReturn(0xFF)  // First byte to fill cache
                         .thenReturn(0xFF)  // Second byte to fill cache
                         .thenReturn(0xFF)  // Third byte to fill cache
                         .thenReturn(0xFF)  // Fourth byte to fill cache
                         .thenReturn(0xFF)  // Fifth byte to fill cache
                         .thenReturn(0xFF)  // Sixth byte to fill cache
                         .thenReturn(0xFF)  // Seventh byte to fill cache
                         .thenReturn(0x0F); // Eighth byte (will cause overflow)
                 
                     // Test both byte orders
                     for (ByteOrder byteOrder : new ByteOrder[]{ByteOrder.LITTLE_ENDIAN, ByteOrder.BIG_ENDIAN}) {
                         BitInputStream bis = new BitInputStream(mockIn, byteOrder);
                         
                         // First read: fill the cache to 56 bits (7 bytes)
                         bis.readBits(56);
                         
                         // Second read: request 60 bits which will trigger overflow path
                         // This should read one more byte (8 bits) and handle overflow
                         long result = bis.readBits(60);
                         
                         // Verify the result is correct (56 bits from cache + 4 bits from new byte)
                         assertEquals(0xFFFFFFFFFFFFFFFL, result);
                         
                         // Now verify the cache contains the remaining 4 bits (overflow)
                         // This is where the mutant would fail - it would keep the old cache value
                         Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                         bitsCachedField.setAccessible(true);
                         long actualCache = bitsCachedField.getLong(bis);
                         
                         if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                             assertEquals(0xFL, actualCache);
                         } else {
                             assertEquals(0x0L, actualCache); // For BIG_ENDIAN, overflow is masked differently
                         }
                         
                         // Also verify bitsCachedSize is correct
                         Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                         bitsCachedSizeField.setAccessible(true);
                         int actualSize = bitsCachedSizeField.getInt(bis);
                         assertEquals(4, actualSize);
                     }
                 }

    @Test
                public void testReadBitsWithOverflowDetectsMutant9() throws IOException {
                    // Setup mock input stream to return specific bytes
                    InputStream mockIn = mock(InputStream.class);
                    when(mockIn.read())
                        .thenReturn(0xFF)  // First byte (all 1s)
                        .thenReturn(0xAA); // Second byte (10101010)
                    
                    // Create BitInputStream with big-endian order (easier to predict)
                    BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
                    
                    // First read: 57 bits (will trigger overflow case)
                    long result1 = bis.readBits(57);
                    
                    // Verify first read result (should be 57 bits from first byte)
                    assertEquals((1L << 57) - 1, result1);
                    
                    // Second read: should get remaining 7 bits from second byte (1010101)
                    long result2 = bis.readBits(7);
                    
                    // With original code: result2 should be 0x55 (01010101)
                    // With mutant: bits would be shifted left by 1, becoming 0xAA (10101010)
                    assertEquals(0x55, result2);
                    
                    // Verify bitsCached contains exactly what we expect (remaining 1 bit)
                    // This is implementation-specific and might need reflection to verify
                    // Alternatively, we could do another read to verify
                    long result3 = bis.readBits(1);
                    assertEquals(0, result3); // Should be the last 0 bit
                }

    @Test
              public void testReadBitsWithOverflowPreservesCacheSize() throws IOException, NoSuchFieldException, IllegalAccessException {
                  // Setup mock input stream that will trigger overflow case
                  InputStream mockIn = mock(InputStream.class);
                  when(mockIn.read())
                      .thenReturn(0xFF)  // first byte (8 bits)
                      .thenReturn(0xFF)  // second byte (16 bits)
                      .thenReturn(0xFF)  // third byte (24 bits)
                      .thenReturn(0xFF)  // fourth byte (32 bits)
                      .thenReturn(0xFF)  // fifth byte (40 bits)
                      .thenReturn(0xFF)  // sixth byte (48 bits)
                      .thenReturn(0xFF)  // seventh byte (56 bits)
                      .thenReturn(0xFF); // eighth byte (64 bits - triggers overflow)
              
                  // Test both byte orders
                  for (ByteOrder byteOrder : new ByteOrder[]{ByteOrder.LITTLE_ENDIAN, ByteOrder.BIG_ENDIAN}) {
                      BitInputStream bis = new BitInputStream(mockIn, byteOrder);
                      
                      // Read 64 bits which will trigger the overflow case
                      long result = bis.readBits(64);
                      
                      // Use reflection to access private fields
                      Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
                      bitsCachedSizeField.setAccessible(true);
                      int bitsCachedSize = (int) bitsCachedSizeField.get(bis);
                      
                      Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
                      bitsCachedField.setAccessible(true);
                      long bitsCached = (long) bitsCachedField.get(bis);
              
                      // Verify the cache size is properly set to overflowBits (8 in this case)
                      assertEquals("Cache size should be set to overflowBits after overflow", 8, bitsCachedSize);
                      
                      // Verify we have the overflow bits properly cached
                      assertEquals(0xFFL, bitsCached);
                      
                      // Reset mock for next iteration
                      reset(mockIn);
                      when(mockIn.read())
                          .thenReturn(0xFF)
                          .thenReturn(0xFF)
                          .thenReturn(0xFF)
                          .thenReturn(0xFF)
                          .thenReturn(0xFF)
                          .thenReturn(0xFF)
                          .thenReturn(0xFF)
                          .thenReturn(0xFF);
                  }
              }

    @Test
         public void testReadBits_OverflowCondition_DetectsMutant() throws IOException, NoSuchFieldException, IllegalAccessException {
             // Setup
             InputStream mockInputStream = mock(InputStream.class);
             when(mockInputStream.read())
                 .thenReturn(0xFF)  // first byte (all bits set)
                 .thenReturn(0xFF)  // second byte
                 .thenReturn(0xFF)  // third byte (will trigger overflow)
                 .thenReturn(-1);   // EOF
             
             BitInputStream bis = new BitInputStream(mockInputStream, ByteOrder.BIG_ENDIAN);
             
             // Initialize cache to nearly full state (56 bits)
             bis.readBits(56);  // This will fill the cache with 7 bytes (56 bits)
             
             // Test - read 8 more bits (total 64 bits requested, which triggers overflow)
             long result = bis.readBits(8);
             
             // Verify the bitsCachedSize after overflow should be 0 (8 - (64-56) = 0)
             // This is where the mutant would fail - it would set bitsCachedSize to 8 (count)
             Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
             bitsCachedSizeField.setAccessible(true);
             int actualBitsCachedSize = bitsCachedSizeField.getInt(bis);
             
             assertEquals(0, actualBitsCachedSize);  // This will catch the mutant
             assertEquals(0xFFL, result);  // Verify we got the correct bits
             
             // Additional verification for the overflow bits
             Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
             bitsCachedField.setAccessible(true);
             long actualBitsCached = bitsCachedField.getLong(bis);
             
             assertEquals(0L, actualBitsCached);  // No bits should remain in cache after overflow
         }

    @Test
    public void testReadBitsWithOverflowDetectsMutant10() throws Exception {
        // Setup mock input stream to return specific bytes
        InputStream mockIn = mock(InputStream.class);
        when(mockIn.read())
            .thenReturn(0xFF)  // First byte (all 1s)
            .thenReturn(0xFF)  // Second byte
            .thenReturn(0xFF)  // Third byte
            .thenReturn(0xFF)  // Fourth byte
            .thenReturn(0xFF)  // Fifth byte
            .thenReturn(0xFF)  // Sixth byte
            .thenReturn(0xFF)  // Seventh byte
            .thenReturn(0x0F); // Eighth byte (only lower 4 bits set)
        
        BitInputStream bis = new BitInputStream(mockIn, ByteOrder.BIG_ENDIAN);
        
        // First read 56 bits (7 bytes) to fill cache almost completely
        bis.readBits(56);
        
        // Now read 5 more bits - this will trigger the overflow condition
        long result = bis.readBits(5);
        
        // Verify the result is correct (not the main focus here)
        assertEquals(0x1FL, result); // Expected 5 bits from overflow
        
        // Use reflection to access private fields
        Field bitsCachedSizeField = BitInputStream.class.getDeclaredField("bitsCachedSize");
        bitsCachedSizeField.setAccessible(true);
        int bitsCachedSize = bitsCachedSizeField.getInt(bis);
        
        Field bitsCachedField = BitInputStream.class.getDeclaredField("bitsCached");
        bitsCachedField.setAccessible(true);
        long bitsCached = bitsCachedField.getLong(bis);
        
        // Critical assertion: verify bitsCachedSize is set correctly to overflowBits (4)
        assertEquals(4, bitsCachedSize);
        
        // Define MASKS locally since we can't access the original
        final long[] MASKS = new long[65];
        for (int i = 0; i < MASKS.length; i++) {
            MASKS[i] = (1L << i) - 1;
        }
        
        // Verify the remaining bits in cache are correct
        assertEquals(0x0FL & MASKS[4], bitsCached);
    }


}
