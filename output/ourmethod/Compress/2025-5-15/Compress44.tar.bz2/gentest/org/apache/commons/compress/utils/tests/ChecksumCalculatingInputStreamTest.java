package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Checksum;
 
public class ChecksumCalculatingInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testConstructor_ValidParameters_SuccessfullyInitialized() {
                                                                                            // Arrange
                                                                                            Checksum mockChecksum = mock(Checksum.class);
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            
                                                                                            // Act
                                                                                            ChecksumCalculatingInputStream stream = 
                                                                                                new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                                            
                                                                                            // No exception means success
                                                                                            // We can't directly verify private fields without reflection,
                                                                                            // but the constructor's main job is to assign these fields
                                                                                        }

    @Test
                                                                                        public void testConstructor_NullChecksum_ThrowsNullPointerException() {
                                                                                            // Arrange
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            thrown.expectMessage("Parameter checksum must not be null");
                                                                                            
                                                                                            // Act
                                                                                            new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                                        }

    @Test
                                                                                        public void testConstructor_NullInputStream_ThrowsNullPointerException() {
                                                                                            // Arrange
                                                                                            Checksum mockChecksum = mock(Checksum.class);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            thrown.expectMessage("Parameter in must not be null");
                                                                                            
                                                                                            // Act
                                                                                            new ChecksumCalculatingInputStream(mockChecksum, null);
                                                                                        }

    @Test
                                                                                        public void testConstructor_BothParametersNull_ThrowsNullPointerExceptionForChecksumFirst() {
                                                                                            // Arrange
                                                                                            // Expect exception for checksum parameter first
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            thrown.expectMessage("Parameter checksum must not be null");
                                                                                            
                                                                                            // Act
                                                                                            new ChecksumCalculatingInputStream(null, null);
                                                                                        }

    @Test
                                                                                   public void testConstructorWithNullInputStreamShouldThrowException() {
                                                                                       // Setup
                                                                                       Checksum mockChecksum = mock(Checksum.class);
                                                                                       InputStream nullInputStream = null;
                                                                                       
                                                                                       // Expect exception
                                                                                       thrown.expect(NullPointerException.class);
                                                                                       thrown.expectMessage("Parameter in must not be null");
                                                                                       
                                                                                       // Test
                                                                                       new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                                   }

    @Test
                                                                                   public void testConstructorWithNonNullInputStreamShouldNotThrowException() {
                                                                                       // Setup
                                                                                       Checksum mockChecksum = mock(Checksum.class);
                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                       
                                                                                       // No exception expected
                                                                                       new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                                       
                                                                                       // If we reach here, test passes (mutant would have thrown exception)
                                                                                   }

    @Test
                                                                                   public void testConstructorWithNullChecksumShouldThrowException() {
                                                                                       // Setup
                                                                                       Checksum nullChecksum = null;
                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                       
                                                                                       // Expect exception
                                                                                       thrown.expect(NullPointerException.class);
                                                                                       thrown.expectMessage("Parameter checksum must not be null");
                                                                                       
                                                                                       // Test
                                                                                       new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                                                   }

    @Test
                                                                              public void testConstructorWithValidParametersShouldNotThrowException() {
                                                                                  // Prepare test data - both parameters are non-null
                                                                                  Checksum checksum = mock(Checksum.class);
                                                                                  InputStream inputStream = mock(InputStream.class);
                                                                                  
                                                                                  // This should not throw any exception with original code
                                                                                  // But will throw exception with mutated code (if (true))
                                                                                  ChecksumCalculatingInputStream stream = 
                                                                                      new ChecksumCalculatingInputStream(checksum, inputStream);
                                                                                  
                                                                                  // Verify fields were properly set
                                                                                  // (This part is not strictly necessary for catching the mutant,
                                                                                  // but good practice to verify constructor behavior)
                                                                                  assertNotNull(stream);
                                                                                  // Could use reflection to verify private fields if needed
                                                                              }

    @Test
                                                                                 public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull() {
                                                                                     // Prepare test data
                                                                                     Checksum mockChecksum = mock(Checksum.class);
                                                                                     InputStream nullInputStream = null;
                                                                             
                                                                                     // Set expectation
                                                                                     thrown.expect(NullPointerException.class);
                                                                                     thrown.expectMessage("Parameter in must not be null");
                                                                             
                                                                                     // Execute test
                                                                                     new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                                 }

    @Test
                                                                                 public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull() {
                                                                                     // Prepare test data
                                                                                     Checksum nullChecksum = null;
                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                             
                                                                                     // Set expectation
                                                                                     thrown.expect(NullPointerException.class);
                                                                                     thrown.expectMessage("Parameter checksum must not be null");
                                                                             
                                                                                     // Execute test
                                                                                     new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                                                 }

    @Test
                                                                                 public void testConstructorSucceedsWithValidParameters() {
                                                                                     // Prepare test data
                                                                                     Checksum mockChecksum = mock(Checksum.class);
                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                             
                                                                                     // Execute test - should not throw any exception
                                                                                     new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                                 }

    @Test
                                                                                public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull1() {
                                                                                    // Setup
                                                                                    Checksum mockChecksum = mock(Checksum.class);
                                                                                    
                                                                                    // Expect exception
                                                                                    thrown.expect(NullPointerException.class);
                                                                                    thrown.expectMessage("Parameter in must not be null");
                                                                                    
                                                                                    // Test - this should throw NullPointerException
                                                                                    new ChecksumCalculatingInputStream(mockChecksum, null);
                                                                                }

    @Test
                                                                                public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull1() {
                                                                                    // Setup
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    
                                                                                    // Expect exception
                                                                                    thrown.expect(NullPointerException.class);
                                                                                    thrown.expectMessage("Parameter checksum must not be null");
                                                                                    
                                                                                    // Test - this should throw NullPointerException
                                                                                    new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                                }

    @Test
                                                                               public void testConstructorSetsChecksumFieldCorrectly() throws Exception {
                                                                                   // Create mock objects
                                                                                   Checksum mockChecksum = mock(Checksum.class);
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   
                                                                                   // Create instance with valid parameters
                                                                                   ChecksumCalculatingInputStream stream = 
                                                                                       new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                                   
                                                                                   // Use reflection to access private checksum field
                                                                                   Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                                                   checksumField.setAccessible(true);
                                                                                   Checksum actualChecksum = (Checksum) checksumField.get(stream);
                                                                                   
                                                                                   // Verify the checksum field was set correctly
                                                                                   assertNotNull("Checksum field should not be null", actualChecksum);
                                                                                   assertSame("Checksum field should be the same as provided checksum", 
                                                                                             mockChecksum, actualChecksum);
                                                                               }

    @Test
                                                                          public void testConstructorSetsInputStreamFieldCorrectly() throws Exception {
                                                                              // Arrange
                                                                              Checksum checksum = mock(Checksum.class);
                                                                              InputStream inputStream = mock(InputStream.class);
                                                                              
                                                                              // Act
                                                                              ChecksumCalculatingInputStream stream = 
                                                                                  new ChecksumCalculatingInputStream(checksum, inputStream);
                                                                              
                                                                              // Assert - verify the field was set correctly using reflection
                                                                              Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                                              inField.setAccessible(true);
                                                                              InputStream actualIn = (InputStream) inField.get(stream);
                                                                              
                                                                              assertSame("InputStream field should be set to provided input stream", 
                                                                                        inputStream, actualIn);
                                                                          }

    @Test(expected = NullPointerException.class)
                                                                             public void testConstructorWithNullChecksumShouldThrowException1() {
                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                 new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                             }

    @Test(expected = NullPointerException.class)
                                                                             public void testConstructorWithNullInputStreamShouldThrowException1() {
                                                                                 Checksum mockChecksum = mock(Checksum.class);
                                                                                 new ChecksumCalculatingInputStream(mockChecksum, null);
                                                                             }

    @Test
                                                                        public void testConstructorWithNonNullChecksumShouldNotThrowException() throws IOException {
                                                                            // Prepare test data
                                                                            Checksum mockChecksum = mock(Checksum.class);
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            
                                                                            // This should not throw exception in original code
                                                                            // Will throw exception in mutated version due to || true condition
                                                                            try {
                                                                                new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                            } catch (NullPointerException e) {
                                                                                fail("Constructor threw NullPointerException with non-null checksum");
                                                                            }
                                                                            
                                                                            // Verify mocks were properly initialized if needed
                                                                            verify(mockChecksum, never()).reset(); // Just an example interaction
                                                                            verify(mockInputStream, never()).close(); // Just an example interaction
                                                                        }

    @Test
                                                                   public void testConstructorShouldNotThrowExceptionWhenInputStreamIsNotNull() {
                                                                       try {
                                                                           // Create mock objects
                                                                           Checksum checksum = mock(Checksum.class);
                                                                           InputStream inputStream = mock(InputStream.class);
                                                                           
                                                                           // This should not throw exception with original code
                                                                           // But will throw exception with mutant (in == null || true)
                                                                           ChecksumCalculatingInputStream stream = 
                                                                               new ChecksumCalculatingInputStream(checksum, inputStream);
                                                                           
                                                                           // Additional assertion to verify fields were set
                                                                           assertNotNull(stream);
                                                                       } catch (NullPointerException e) {
                                                                           fail("Constructor threw NullPointerException when InputStream was not null");
                                                                       }
                                                                   }

    @Test
                                                                   public void testConstructorShouldThrowWhenInputStreamIsNull() {
                                                                       // Prepare
                                                                       Checksum mockChecksum = mock(Checksum.class);
                                                                       InputStream nullInputStream = null;
                                                                       
                                                                       // Expect
                                                                       thrown.expect(NullPointerException.class);
                                                                       thrown.expectMessage("Parameter in must not be null");
                                                                       
                                                                       // Execute
                                                                       new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                   }

    @Test
                                                                   public void testConstructorShouldThrowWhenChecksumIsNull() {
                                                                       // Prepare
                                                                       Checksum nullChecksum = null;
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       
                                                                       // Expect
                                                                       thrown.expect(NullPointerException.class);
                                                                       thrown.expectMessage("Parameter checksum must not be null");
                                                                       
                                                                       // Execute
                                                                       new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                                   }

    @Test
                                                                   public void testConstructorShouldNotThrowWhenParametersAreValid() {
                                                                       // Prepare
                                                                       Checksum mockChecksum = mock(Checksum.class);
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       
                                                                       // Execute (should not throw)
                                                                       new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                   }

    @Test(expected = NullPointerException.class)
                                                              public void testConstructor_WhenInputStreamIsNull_ThrowsExceptionWithCorrectMessage() {
                                                                  // Arrange
                                                                  Checksum mockChecksum = mock(Checksum.class);
                                                                  InputStream nullInputStream = null;
                                                                  String expectedMessage = "Parameter in must not be null";
                                                                  
                                                                  try {
                                                                      // Act
                                                                      new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                  } catch (NullPointerException e) {
                                                                      // Assert
                                                                      assertEquals("Exception message should match original specification", 
                                                                                   expectedMessage, e.getMessage());
                                                                      throw e; // rethrow to satisfy @Test annotation
                                                                  }
                                                              }

    @Test
                                                                public void testConstructorThrowsNPEWhenInputStreamIsNull() {
                                                                    // Prepare
                                                                    Checksum mockChecksum = mock(Checksum.class);
                                                                    InputStream nullInputStream = null;
                                                                    
                                                                    // Expect exception
                                                                    thrown.expect(NullPointerException.class);
                                                                    thrown.expectMessage("Parameter in must not be null");
                                                                    
                                                                    // Execute
                                                                    new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                }

    @Test
                                                                public void testConstructorThrowsNPEWhenChecksumIsNull() {
                                                                    // Prepare
                                                                    Checksum nullChecksum = null;
                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                    
                                                                    // Expect exception
                                                                    thrown.expect(NullPointerException.class);
                                                                    thrown.expectMessage("Parameter checksum must not be null");
                                                                    
                                                                    // Execute
                                                                    new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                                }

    @Test
                                                                public void testConstructorSuccessWithValidParameters() {
                                                                    // Prepare
                                                                    Checksum mockChecksum = mock(Checksum.class);
                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                    
                                                                    // Execute (should not throw)
                                                                    ChecksumCalculatingInputStream stream = 
                                                                        new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                    
                                                                    // Verify fields are set (though they're private, we can test through other methods)
                                                                    // This is just to show the happy path works
                                                                }

    @Test
                                                               public void testConstructorWithNonNullInputStreamShouldNotThrowException1() {
                                                                   // Prepare test data
                                                                   Checksum mockChecksum = mock(Checksum.class);
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   
                                                                   // This should not throw an exception with original code
                                                                   // Will throw NullPointerException with mutated code
                                                                   new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                   
                                                                   // If we reach here, test passes (no exception thrown)
                                                                   // The mutant will fail by throwing NullPointerException
                                                               }

    @Test(expected = NullPointerException.class)
                                                               public void testConstructorWithNullChecksumShouldThrowException2() {
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   new ChecksumCalculatingInputStream(null, mockInputStream);
                                                               }

    @Test(expected = NullPointerException.class)
                                                               public void testConstructorWithNullInputStreamShouldThrowException2() {
                                                                   Checksum mockChecksum = mock(Checksum.class);
                                                                   new ChecksumCalculatingInputStream(mockChecksum, null);
                                                               }

    @Test
                                                              public void testConstructorShouldThrowWhenInputStreamIsNull1() {
                                                                  // Prepare
                                                                  Checksum mockChecksum = mock(Checksum.class);
                                                                  InputStream nullInputStream = null;
                                                                  
                                                                  // Expect exception
                                                                  thrown.expect(NullPointerException.class);
                                                                  thrown.expectMessage("Parameter in must not be null");
                                                                  
                                                                  // Execute
                                                                  new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                              }

    @Test(expected = NullPointerException.class)
                                                         public void testConstructor_WhenInputStreamIsNull_ShouldThrowNullPointerException() {
                                                             // Arrange
                                                             Checksum checksum = mock(Checksum.class);
                                                             InputStream nullInputStream = null;
                                                             
                                                             // Act & Assert
                                                             new ChecksumCalculatingInputStream(checksum, nullInputStream);
                                                         }

    @Test
                                                         public void testConstructor_WhenInputStreamIsNull_ShouldThrowWithCorrectMessage() {
                                                             // Arrange
                                                             Checksum checksum = mock(Checksum.class);
                                                             InputStream nullInputStream = null;
                                                             
                                                             try {
                                                                 // Act
                                                                 new ChecksumCalculatingInputStream(checksum, nullInputStream);
                                                                 fail("Expected NullPointerException to be thrown");
                                                             } catch (NullPointerException e) {
                                                                 // Assert
                                                                 assertEquals("Parameter in must not be null", e.getMessage());
                                                             }
                                                         }

    @Test
                                                        public void testConstructorSetsChecksumFieldCorrectly1() throws Exception {
                                                            // Arrange
                                                            Checksum mockChecksum = mock(Checksum.class);
                                                            InputStream mockInputStream = mock(InputStream.class);
                                                            
                                                            // Act
                                                            ChecksumCalculatingInputStream stream = 
                                                                new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                            
                                                            // Assert - verify checksum field was set properly
                                                            // Option 1: If getValue() uses the checksum
                                                            when(mockChecksum.getValue()).thenReturn(123L);
                                                            assertEquals(123L, stream.getValue());
                                                            
                                                            // Option 2: Using reflection to directly check the field
                                                            Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                            checksumField.setAccessible(true);
                                                            assertSame(mockChecksum, checksumField.get(stream));
                                                        }

    @Test
                                                           public void testConstructorSetsInputStreamFieldCorrectly1() throws Exception {
                                                               // Arrange
                                                               Checksum mockChecksum = mock(Checksum.class);
                                                               InputStream mockInputStream = mock(InputStream.class);
                                                               
                                                               // Act
                                                               ChecksumCalculatingInputStream stream = 
                                                                   new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                               
                                                               // Use reflection to access private field for verification
                                                               Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                               inField.setAccessible(true);
                                                               InputStream actualInputStream = (InputStream) inField.get(stream);
                                                               
                                                               // Assert
                                                               assertEquals("Input stream field should be set to provided input stream",
                                                                          mockInputStream, actualInputStream);
                                                           }

    @Test
                                                          public void testConstructorWithValidParametersShouldNotThrow() throws Exception {
                                                              // Prepare test data - both parameters are non-null
                                                              Checksum mockChecksum = mock(Checksum.class);
                                                              InputStream mockInputStream = mock(InputStream.class);
                                                              
                                                              // This test will pass with original code but fail with mutated code
                                                              // because mutated code will always throw NPE for checksum parameter
                                                              try {
                                                                  ChecksumCalculatingInputStream stream = 
                                                                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                  
                                                                  // Additional assertions to verify proper initialization
                                                                  assertNotNull(stream);
                                                                  // Could add reflection checks to verify fields if needed
                                                              } catch (NullPointerException e) {
                                                                  fail("Constructor threw NullPointerException with valid parameters");
                                                              }
                                                          }

    @Test(expected = NullPointerException.class)
                                                          public void testConstructorWithNullChecksumShouldThrow() throws Exception {
                                                              InputStream mockInputStream = mock(InputStream.class);
                                                              new ChecksumCalculatingInputStream(null, mockInputStream);
                                                          }

    @Test(expected = NullPointerException.class)
                                                          public void testConstructorWithNullInputStreamShouldThrow() throws Exception {
                                                              Checksum mockChecksum = mock(Checksum.class);
                                                              new ChecksumCalculatingInputStream(mockChecksum, null);
                                                          }

    @Test
                                                    public void testConstructorWithNonNullInputStreamShouldNotThrow() throws Exception {
                                                        // Prepare test data - non-null parameters
                                                        Checksum checksum = mock(Checksum.class);
                                                        InputStream inputStream = mock(InputStream.class);
                                                        
                                                        // This should not throw exception with original code
                                                        // But will throw with mutated code
                                                        ChecksumCalculatingInputStream stream = 
                                                            new ChecksumCalculatingInputStream(checksum, inputStream);
                                                        
                                                        // Verify fields were properly set using reflection
                                                        Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                        checksumField.setAccessible(true);
                                                        assertSame(checksum, checksumField.get(stream));
                                                        
                                                        Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                        inField.setAccessible(true);
                                                        assertSame(inputStream, inField.get(stream));
                                                    }

    @Test
                                                    public void testConstructorShouldThrowWhenInputStreamIsNull2() {
                                                        // Prepare
                                                        Checksum mockChecksum = mock(Checksum.class);
                                                        InputStream nullInputStream = null;
                                                        
                                                        // Expect
                                                        thrown.expect(NullPointerException.class);
                                                        thrown.expectMessage("Parameter in must not be null");
                                                        
                                                        // Execute
                                                        new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                    }

    @Test
                                              public void constructor_shouldInitializeFields_whenParametersAreValid() throws Exception {
                                                  // Arrange
                                                  Checksum mockChecksum = mock(Checksum.class);
                                                  InputStream mockInputStream = mock(InputStream.class);
                                                  
                                                  // Act
                                                  ChecksumCalculatingInputStream stream = 
                                                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                  
                                                  // Assert - Use reflection to access private fields
                                                  Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                  checksumField.setAccessible(true);
                                                  assertSame(mockChecksum, checksumField.get(stream));
                                                  
                                                  Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                  inField.setAccessible(true);
                                                  assertSame(mockInputStream, inField.get(stream));
                                              }

    @Test
                              public void constructor_shouldThrowNullPointerExceptionWithCorrectMessage_whenInputStreamIsNull() {
                                  // Arrange
                                  java.util.zip.Checksum mockChecksum = mock(java.util.zip.Checksum.class);
                                  java.io.InputStream nullInputStream = null;
                                  
                                  // Act & Assert
                                  try {
                                      new org.apache.commons.compress.utils.ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                      org.junit.Assert.fail("Expected NullPointerException");
                                  } catch (NullPointerException e) {
                                      org.junit.Assert.assertEquals("Parameter in must not be null", e.getMessage());
                                  }
                              }

    @Test
                  public void constructor_shouldThrowNullPointerExceptionWithCorrectMessage_whenChecksumIsNull() {
                      // Arrange
                      java.util.zip.Checksum nullChecksum = null;
                      java.io.InputStream mockInputStream = mock(java.io.InputStream.class);
                      
                      try {
                          // Act
                          new org.apache.commons.compress.utils.ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                          org.junit.Assert.fail("Expected NullPointerException");
                      } catch (NullPointerException e) {
                          // Assert
                          org.junit.Assert.assertEquals("Parameter checksum must not be null", e.getMessage());
                      }
                  }

    @Test(expected = NullPointerException.class)
             public void testConstructorWithMutatedNullCheckForInputStream() throws Exception {
                 // Prepare test data - both parameters are valid (non-null)
                 Checksum mockChecksum = mock(Checksum.class);
                 InputStream mockInputStream = mock(InputStream.class);
                 
                 // This should not throw exception in original code, but will throw in mutated code
                 new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                 
                 // If we reach here in original code, test fails (no exception thrown)
                 // In mutated code, exception will be thrown and test will pass (detecting the mutant)
                 // We need to fail explicitly if no exception is thrown
                 fail("Expected NullPointerException to be thrown due to mutant, but it wasn't");
             }

    @Test
                public void testConstructorShouldThrowWhenInputStreamIsNull3() {
                    // Prepare test data
                    Checksum mockChecksum = mock(Checksum.class);
                    InputStream nullInputStream = null;
            
                    // Set expectation
                    thrown.expect(NullPointerException.class);
                    thrown.expectMessage("Parameter in must not be null");
            
                    // Execute test
                    new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                }

    @Test
                public void testConstructorShouldThrowWhenChecksumIsNull1() {
                    // Prepare test data
                    Checksum nullChecksum = null;
                    InputStream mockInputStream = mock(InputStream.class);
            
                    // Set expectation
                    thrown.expect(NullPointerException.class);
                    thrown.expectMessage("Parameter checksum must not be null");
            
                    // Execute test
                    new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                }

    @Test
                public void testConstructorShouldNotThrowWithValidParameters() {
                    // Prepare test data
                    Checksum mockChecksum = mock(Checksum.class);
                    InputStream mockInputStream = mock(InputStream.class);
            
                    // Execute test - should not throw any exception
                    new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                }

    @Test
               public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull2() {
                   // Setup
                   Checksum mockChecksum = mock(Checksum.class);
                   InputStream nullInputStream = null;
                   
                   // Expect exception
                   thrown.expect(NullPointerException.class);
                   thrown.expectMessage("Parameter in must not be null");
                   
                   // Test
                   new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
               }

    @Test
               public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull2() {
                   // Setup
                   Checksum nullChecksum = null;
                   InputStream mockInputStream = mock(InputStream.class);
                   
                   // Expect exception
                   thrown.expect(NullPointerException.class);
                   thrown.expectMessage("Parameter checksum must not be null");
                   
                   // Test
                   new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
               }

    @Test
              public void testConstructorInitializesChecksumFieldCorrectly() {
                  // Prepare test data
                  Checksum mockChecksum = mock(Checksum.class);
                  InputStream mockInputStream = mock(InputStream.class);
                  
                  // Create instance
                  ChecksumCalculatingInputStream stream = 
                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                  
                  // Verify checksum field was properly initialized
                  // We need to use reflection to access the private field for verification
                  try {
                      java.lang.reflect.Field checksumField = 
                          ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                      checksumField.setAccessible(true);
                      Checksum actualChecksum = (Checksum) checksumField.get(stream);
                      
                      // Assert that the checksum field contains our mock object
                      assertSame("Checksum field should be initialized with provided checksum object",
                                mockChecksum, actualChecksum);
                  } catch (NoSuchFieldException | IllegalAccessException e) {
                      fail("Failed to access checksum field for verification: " + e.getMessage());
                  }
              }

    @Test
             public void testConstructorSetsInputStreamFieldCorrectly2() throws Exception {
                 // Prepare test data
                 Checksum mockChecksum = mock(Checksum.class);
                 InputStream mockInputStream = mock(InputStream.class);
                 
                 // Create instance
                 ChecksumCalculatingInputStream stream = 
                     new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                 
                 // Verify the field was set correctly (not null)
                 // We need to use reflection to access the private field
                 try {
                     java.lang.reflect.Field inField = ChecksumCalculatingInputStream.class
                         .getDeclaredField("in");
                     inField.setAccessible(true);
                     InputStream actualIn = (InputStream) inField.get(stream);
                     
                     // Assert that the field was set to the provided input stream (not null)
                     assertSame("InputStream field should be set to the provided input stream", 
                              mockInputStream, actualIn);
                 } catch (NoSuchFieldException | IllegalAccessException e) {
                     fail("Failed to access private field 'in' for verification");
                 }
             }

    @Test
             public void testConstructorSetsInputStreamFieldCorrectlyThroughBehavior() throws Exception {
                 // Prepare test data
                 Checksum mockChecksum = mock(Checksum.class);
                 byte[] testData = {1, 2, 3};
                 InputStream realInputStream = new ByteArrayInputStream(testData);
                 
                 // Create instance
                 ChecksumCalculatingInputStream stream = 
                     new ChecksumCalculatingInputStream(mockChecksum, realInputStream);
                 
                 // Verify behavior depends on the correct input stream being set
                 // Read from the stream - if in was set to null, this would throw NullPointerException
                 byte[] buffer = new byte[3];
                 int bytesRead = stream.read(buffer);
                 
                 // Verify we could read from the stream (would fail if in was null)
                 assertEquals(3, bytesRead);
                 assertArrayEquals(testData, buffer);
             }

    @Test
            public void testConstructorWithValidChecksumShouldNotThrowException() throws Exception {
                // Prepare test data
                Checksum mockChecksum = mock(Checksum.class);
                InputStream mockInputStream = mock(InputStream.class);
                
                // This test should pass with original code but fail with mutated code
                // Original code should accept non-null checksum
                // Mutated code will throw NPE regardless due to "|| true"
                new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                
                // No exception expected - if we reach here, test passes for original code
            }

    @Test
            public void testConstructorWithNullChecksumShouldThrowException3() throws Exception {
                // Prepare test data
                InputStream mockInputStream = mock(InputStream.class);
                
                // Set expectation
                thrown.expect(NullPointerException.class);
                thrown.expectMessage("Parameter checksum must not be null");
                
                // Execute test
                new ChecksumCalculatingInputStream(null, mockInputStream);
            }

    @Test
            public void testConstructorWithNullInputStreamShouldThrowException3() throws Exception {
                // Prepare test data
                Checksum mockChecksum = mock(Checksum.class);
                
                // Set expectation
                thrown.expect(NullPointerException.class);
                thrown.expectMessage("Parameter in must not be null");
                
                // Execute test
                new ChecksumCalculatingInputStream(mockChecksum, null);
            }

    @Test
       public void testConstructorWithNonNullParametersShouldNotThrowException() {
           // Prepare non-null test objects
           Checksum checksum = mock(Checksum.class);
           InputStream inputStream = mock(InputStream.class);
           
           // This should not throw exception with original code
           // But will throw exception with mutated code
           ChecksumCalculatingInputStream stream = 
               new ChecksumCalculatingInputStream(checksum, inputStream);
           
           // Verify fields were properly set
           assertNotNull(stream);
           // Additional assertions to verify proper initialization
           assertEquals(checksum, stream.getValue()); // Assuming getValue() returns checksum
       }

    @Test
          public void testConstructorThrowsNPEWhenChecksumIsNull1() {
              // Setup
              InputStream mockInputStream = mock(InputStream.class);
              
              // Expect exception
              thrown.expect(NullPointerException.class);
              thrown.expectMessage("Parameter checksum must not be null");
              
              // Test
              new ChecksumCalculatingInputStream(null, mockInputStream);
          }

    @Test
          public void testConstructorThrowsNPEWhenInputStreamIsNull1() {
              // Setup
              Checksum mockChecksum = mock(Checksum.class);
              
              // Expect exception
              thrown.expect(NullPointerException.class);
              thrown.expectMessage("Parameter in must not be null");
              
              // Test - this would fail with the mutant since it won't throw exception
              new ChecksumCalculatingInputStream(mockChecksum, null);
          }

    @Test
    public void testConstructorThrowsCorrectExceptionMessageWhenInputStreamIsNull() {
        // Setup
        Checksum mockChecksum = mock(Checksum.class);
        ExpectedException exceptionRule = ExpectedException.none();
        
        // Expect exception
        exceptionRule.expect(NullPointerException.class);
        exceptionRule.expectMessage("Parameter in must not be null");
        
        // Test - this should throw NullPointerException
        new ChecksumCalculatingInputStream(mockChecksum, null);
    }

    @Test
    public void testConstructorThrowsExceptionWhenChecksumIsNull() {
        // Setup
        InputStream mockInputStream = mock(InputStream.class);
        ExpectedException exceptionRule = ExpectedException.none();
        exceptionRule.expect(NullPointerException.class);
        exceptionRule.expectMessage("Parameter checksum must not be null");
        
        // Test - this should throw NullPointerException
        new ChecksumCalculatingInputStream(null, mockInputStream);
    }

    @Test
    public void testConstructorInitializesFieldsWhenParametersAreValid() throws Exception {
        // Setup
        Checksum mockChecksum = mock(Checksum.class);
        InputStream mockInputStream = mock(InputStream.class);
        
        // Test
        ChecksumCalculatingInputStream stream = 
            new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
        
        // Verify fields are initialized using reflection
        Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
        checksumField.setAccessible(true);
        assertSame(mockChecksum, checksumField.get(stream));
        
        Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
        inField.setAccessible(true);
        assertSame(mockInputStream, inField.get(stream));
    }


}
