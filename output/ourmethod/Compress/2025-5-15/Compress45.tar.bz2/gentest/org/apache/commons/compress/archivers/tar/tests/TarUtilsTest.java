package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_PositiveWithinOctalRange() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 5;
                                                                                                       int length = 8; // UIDLEN is typically 8
                                                                                                       long value = 1000L; // Within octal range for UIDLEN
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       // Verify the buffer contains octal representation
                                                                                                       // (Assuming formatLongOctalBytes works correctly)
                                                                                                       assertNotEquals(0, buf[offset]); // First byte shouldn't be null
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_NegativeValue() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 3;
                                                                                                       int length = 8;
                                                                                                       long value = -1000L;
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       assertEquals((byte)0xff, buf[offset]); // Should mark as negative
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_LongBinaryFormat() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 0;
                                                                                                       int length = 8; // <9, so uses formatLongBinary
                                                                                                       long value = Long.MAX_VALUE; // Too big for octal
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       assertEquals((byte)0x80, buf[offset]); // Positive marker
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_BigIntegerBinaryFormat() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 2;
                                                                                                       int length = 9; // >=9, so uses formatBigIntegerBinary
                                                                                                       long value = Long.MAX_VALUE;
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       assertEquals((byte)0x80, buf[offset]); // Positive marker
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_ZeroValue() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 5;
                                                                                                       int length = 8;
                                                                                                       long value = 0L;
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       // Should be stored as octal
                                                                                                       assertNotEquals(0, buf[offset]); // First byte shouldn't be null
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_MaxOctalValue() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 1;
                                                                                                       int length = 8;
                                                                                                       long value = 07777777L; // MAXID for UIDLEN (8)
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       // Should be stored as octal
                                                                                                       assertNotEquals(0, buf[offset]); // First byte shouldn't be null
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_JustAboveOctalThreshold() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 4;
                                                                                                       int length = 8;
                                                                                                       long value = 07777777L + 1; // Just above MAXID for UIDLEN
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       // Should be stored as binary
                                                                                                       assertEquals((byte)0x80, buf[offset]); // Positive marker
                                                                                                   }

 @Test
                                                                                                   public void testFormatLongOctalOrBinaryBytes_NonUIDLengthOctal() {
                                                                                                       byte[] buf = new byte[20];
                                                                                                       int offset = 2;
                                                                                                       int length = 12; // Not UIDLEN, so MAXSIZE applies
                                                                                                       long value = 077777777777L; // Within octal range for non-UID
                                                                                                       
                                                                                                       int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
                                                                                                       
                                                                                                       assertEquals(offset + length, result);
                                                                                                       // Should be stored as octal
                                                                                                       assertNotEquals(0, buf[offset]); // First byte shouldn't be null
                                                                                                   }

 @Test
                                                                                           public void testFormatLongOctalOrBinaryBytes_NullBuffer() {
                                                                                               org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                                                               exceptionRule.expect(NullPointerException.class);
                                                                                               TarUtils.formatLongOctalOrBinaryBytes(100L, null, 0, 8);
                                                                                           }

 @Test
           public void testFormatLongOctalOrBinaryBytes_LengthBoundary() {
               // Test case for length = 8 (should use formatLongBinary)
               byte[] buf8 = new byte[8];
               long value = 12345L; // Value that will trigger binary formatting
               int offset = 0;
               int length = 8;
               
               // Call the method
               int result8 = TarUtils.formatLongOctalOrBinaryBytes(value, buf8, offset, length);
               
               // Verify it used formatLongBinary by checking the first byte
               // formatLongBinary would set the first byte differently than formatBigIntegerBinary
               assertEquals(offset + length, result8);
               assertNotEquals((byte)0x80, buf8[offset]); // formatLongBinary doesn't set this marker
               
               // Test case for length = 9 (should use formatBigIntegerBinary)
               byte[] buf9 = new byte[9];
               length = 9;
               
               // Call the method
               int result9 = TarUtils.formatLongOctalOrBinaryBytes(value, buf9, offset, length);
               
               // Verify it used formatBigIntegerBinary by checking the first byte
               // formatBigIntegerBinary sets the first byte to 0x80 for positive numbers
               assertEquals(offset + length, result9);
               assertEquals((byte)0x80, buf9[offset]); // formatBigIntegerBinary sets this marker
           }

 @Test
          public void testFormatLongOctalOrBinaryBytes_DetectsLengthCheckMutant() {
              // Setup test with length < 9 to trigger the mutated condition
              long value = 12345L; // Value that will force binary formatting
              byte[] buf = new byte[20];
              int offset = 0;
              int length = 8; // Less than 9 to test the mutated condition
              
              // Call the method
              int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
              
              // Verify the result offset
              assertEquals(offset + length, result);
              
              // The key verification - check the first byte which is set differently in each binary format
              // formatLongBinary would set this to 0x80 for positive numbers
              // formatBigIntegerBinary would set this to 0x00 for positive numbers
              // Since we're testing for the mutant (which skips formatLongBinary), we expect 0x00 if mutant exists
              // But the correct behavior should be 0x80
              assertEquals((byte) 0x80, buf[offset]);
              
              // Additional verification - check the last byte which is set differently
              // formatLongBinary would set this to the LSB of the value
              // formatBigIntegerBinary would set this differently (as part of big integer format)
              // For our test value 12345, LSB is 0x39
              assertEquals((byte) 0x39, buf[offset + length - 1]);
          }

 @Test
         public void testFormatLongOctalOrBinaryBytes_DetectsNegativeParameterMutation() {
             // Setup
             long positiveValue = 12345L;  // A positive value
             byte[] buffer = new byte[10]; // Length < 9 to trigger formatLongBinary
             int offset = 0;
             int length = 8;               // Less than 9 to use formatLongBinary
             
             // Execute
             int result = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buffer, offset, length);
             
             // Verify
             // The first byte should be 0x80 for positive values (original behavior)
             // The mutant would set it to 0xff (treating as negative)
             assertEquals("First byte should indicate positive number", (byte) 0x80, buffer[offset]);
             assertEquals("Should return correct offset", offset + length, result);
             
             // Additional verification that the rest of the buffer was modified
             boolean bufferModified = false;
             for (int i = offset + 1; i < offset + length; i++) {
                 if (buffer[i] != 0) {
                     bufferModified = true;
                     break;
                 }
             }
             assertTrue("Buffer should contain formatted data", bufferModified);
         }

 @Test
        public void testFormatLongOctalOrBinaryBytes_NegativeValueWithLengthLessThan() {
            // Setup
            long negativeValue = -12345L;
            byte[] buf = new byte[20];
            int offset = 5;
            int length = 8; // less than 9 to trigger formatLongBinary
            
            // Call the method
            int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
            
            // Verify the offset + length return value
            assertEquals(offset + length, result);
            
            // Verify the marker byte is set correctly for negative value (0xff)
            assertEquals((byte) 0xff, buf[offset]);
            
            // Additional verification that formatLongBinary was called with correct negative flag
            // Since formatLongBinary is private, we can't mock it directly, but we can verify
            // its effect through the buffer contents. The marker byte being 0xff confirms
            // that the negative flag was properly passed (would be 0x80 if false was used)
        }

 @Test
       public void testFormatLongOctalOrBinaryBytes_DetectNegatedNegativeParameterInBigIntegerBinary() {
           // Setup
           long positiveValue = 123456789L;
           long negativeValue = -123456789L;
           int length = 9; // To trigger formatBigIntegerBinary path
           byte[] buf = new byte[length];
           int offset = 0;
           
           // Test positive value
           int resultPos = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
           assertEquals(offset + length, resultPos);
           // First byte should be 0x80 for positive values
           assertEquals((byte)0x80, buf[offset]);
           
           // Test negative value
           buf = new byte[length]; // Reset buffer
           int resultNeg = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
           assertEquals(offset + length, resultNeg);
           // First byte should be 0xff for negative values
           assertEquals((byte)0xff, buf[offset]);
           
           // Additional test with larger length
           length = 12;
           buf = new byte[length];
           resultNeg = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
           assertEquals(offset + length, resultNeg);
           assertEquals((byte)0xff, buf[offset]);
       }

 @Test
      public void testFormatLongOctalOrBinaryBytes_NegativeValueWithShortLength_ShouldPassCorrectNegativeFlag() {
          // Setup
          long negativeValue = -12345L;
          byte[] buf = new byte[8]; // length < 9
          int offset = 0;
          int length = 8;
          
          // Execute
          int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
          
          // Verify
          // The first byte should indicate negative (0xff)
          assertEquals((byte) 0xff, buf[offset]);
          
          // The result should be offset + length
          assertEquals(offset + length, result);
          
          // Additional verification that the binary representation is correct
          // Since formatLongBinary is private, we can verify some expected properties:
          // For a negative value, the remaining bytes should represent the absolute value
          // We'll check that the buffer isn't all zeros (which might happen if negative flag was wrong)
          boolean nonZeroFound = false;
          for (int i = offset + 1; i < offset + length; i++) {
              if (buf[i] != 0) {
                  nonZeroFound = true;
                  break;
              }
          }
          assertTrue("Buffer should contain non-zero values for negative number", nonZeroFound);
      }

 @Test
     public void testFormatLongOctalOrBinaryBytes_DetectNegativeParameterMutation() {
         // Setup
         long positiveValue = 12345L; // Positive value that will trigger binary formatting
         byte[] buf = new byte[20];
         int offset = 0;
         int length = 8; // Less than 9 to trigger formatLongBinary
         
         // Call the method
         int result = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
         
         // Verify the result offset
         assertEquals(offset + length, result);
         
         // Verify the first byte is set correctly for positive number (0x80)
         assertEquals((byte)0x80, buf[offset]);
         
         // Verify the remaining bytes don't look like a negative number was formatted
         // For a positive number, the binary representation shouldn't have all 1s in high bits
         boolean looksLikeNegative = true;
         for (int i = offset + 1; i < offset + length; i++) {
             if (buf[i] != (byte)0xFF) {
                 looksLikeNegative = false;
                 break;
             }
         }
         assertFalse("Binary representation looks like a negative number was formatted", 
                    looksLikeNegative);
     }

 @Test
    public void testFormatLongOctalOrBinaryBytes_NegativeValueWithShortLength() {
        // Setup
        long negativeValue = -12345L;
        byte[] buf = new byte[20];
        int offset = 0;
        int length = 8; // Less than 9 to trigger formatLongBinary
        
        // Action
        int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
        
        // Verification
        // Check that the first byte is set to 0xff for negative values
        assertEquals((byte)0xff, buf[offset]);
        
        // Verify the position after writing
        assertEquals(offset + length, result);
        
        // Additional verification that the negative flag was properly passed to formatLongBinary
        // We can check some characteristic of negative binary representation
        // For example, in two's complement, negative numbers have MSB set
        boolean msbSet = (buf[offset + 1] & 0x80) != 0;
        assertTrue("MSB should be set for negative number representation", msbSet);
        
        // Also verify that the value can be properly reconstructed as negative
        // (This assumes parseOctalOrBinary can handle binary format)
        long parsedValue = TarUtils.parseOctalOrBinary(buf, offset, length);
        assertEquals(negativeValue, parsedValue);
    }

 @Test
   public void testFormatLongOctalOrBinaryBytes_BigIntegerNegativeFlag() {
       // Setup
       long positiveValue = 1234567890123456789L; // Large positive value requiring BigInteger
       long negativeValue = -1234567890123456789L; // Large negative value requiring BigInteger
       int length = 9; // Force BigInteger path
       byte[] buf = new byte[20];
       int offset = 0;
       
       // Test positive value
       int resultPos = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
       assertEquals(offset + length, resultPos);
       // First byte should indicate positive (0x80)
       assertEquals((byte)0x80, buf[offset]);
       
       // Test negative value
       int resultNeg = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
       assertEquals(offset + length, resultNeg);
       // First byte should indicate negative (0xff)
       assertEquals((byte)0xff, buf[offset]);
       
       // Additional check: verify the negative flag was passed correctly to formatBigIntegerBinary
       // This would require mocking formatBigIntegerBinary, but since it's private,
       // we rely on the output buffer verification above
   }

 @Test
  public void testFormatLongOctalOrBinaryBytes_DetectNegativeFlagMutation() {
      // Setup
      long positiveValue = 123456789L; // Positive value
      int length = 9; // Length >= 9 to trigger formatBigIntegerBinary
      byte[] buf = new byte[length];
      int offset = 0;
      
      // Call the method
      int result = TarUtils.formatLongOctalOrBinaryBytes(positiveValue, buf, offset, length);
      
      // Verify the result offset
      assertEquals(offset + length, result);
      
      // Verify the first byte - should be 0x80 for positive values
      // If mutant is present, it would be 0xff instead
      assertEquals((byte)0x80, buf[offset]);
      
      // Additional verification - check that the remaining bytes contain the positive value
      // This would fail if the value was incorrectly treated as negative
      long parsedValue = TarUtils.parseOctalOrBinary(buf, offset, length);
      assertEquals(positiveValue, parsedValue);
  }

 @Test
 public void testFormatLongOctalOrBinaryBytes_NegativeValueWithBigIntegerPath() {
     // Setup
     long negativeValue = -123456789L;
     byte[] buf = new byte[20];
     int offset = 0;
     int length = 9; // Triggers BigInteger path
     
     // Call method
     int result = TarUtils.formatLongOctalOrBinaryBytes(negativeValue, buf, offset, length);
     
     // Verify
     // Check that the marker byte indicates negative (0xff)
     assertEquals((byte)0xff, buf[offset]);
     
     // Verify the result position
     assertEquals(offset + length, result);
     
     // Additional checks to ensure negative handling was correct
     // Since formatBigIntegerBinary is private, we check some expected side effects:
     // The first byte after offset should be modified (not zero)
     assertNotEquals(0, buf[offset+1]);
     
     // If we had access to parse methods, we could verify round-trip:
     // long parsed = TarUtils.parseOctalOrBinary(buf, offset, length);
     // assertEquals(negativeValue, parsed);
 }

}
