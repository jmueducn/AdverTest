package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                  public void testParseOctal_ValidNumbers() {
                                                                                                      // Test various valid octal numbers
                                                                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', '0'}, 0, 2));
                                                                                                      assertEquals(1L, TarUtils.parseOctal(new byte[]{'0', '1'}, 0, 2));
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{'0', '7'}, 0, 2));
                                                                                                      assertEquals(10L, TarUtils.parseOctal(new byte[]{'0', '1', '0'}, 0, 3));
                                                                                                      assertEquals(63L, TarUtils.parseOctal(new byte[]{'0', '7', '7'}, 0, 3));
                                                                                                      assertEquals(511L, TarUtils.parseOctal(new byte[]{'0', '7', '7', '7'}, 0, 4));
                                                                                                  }

 @Test
                                                                                                  public void testParseOctal_LeadingSpaces() {
                                                                                                      // Test with leading spaces
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{' ', ' ', '0', '7'}, 0, 4));
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{' ', '0', '7'}, 0, 3));
                                                                                                  }

 @Test
                                                                                                  public void testParseOctal_TrailingSpacesOrNulls() {
                                                                                                      // Test with trailing spaces/NULs
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{'0', '7', ' ', ' '}, 0, 4));
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{'0', '7', '\0', '\0'}, 0, 4));
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{'0', '7', ' ', '\0'}, 0, 4));
                                                                                                  }

 @Test
                                                                                                  public void testParseOctal_WithOffset() {
                                                                                                      // Test with non-zero offset
                                                                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{'x', 'y', '0', '7'}, 2, 2));
                                                                                                      assertEquals(63L, TarUtils.parseOctal(new byte[]{'a', 'b', '0', '7', '7'}, 2, 3));
                                                                                                  }

 @Test
                                                                                                  public void testParseOctal_MaxValue() {
                                                                                                      // Test maximum possible value (22 octal digits)
                                                                                                      byte[] maxOctal = new byte[22];
                                                                                                      for (int i = 0; i < 22; i++) {
                                                                                                          maxOctal[i] = '7';
                                                                                                      }
                                                                                                      assertEquals(Long.MAX_VALUE, TarUtils.parseOctal(maxOctal, 0, 22));
                                                                                                  }

 @Test
                                                                                                  public void testParseOctal_ZeroAfterTrimming() {
                                                                                                      // Test case where after trimming only zero remains
                                                                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', ' ', ' '}, 0, 3));
                                                                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', '\0', '\0'}, 0, 3));
                                                                                                  }

 @Test
                                                                                          public void testParseOctal_InvalidLength() {
                                                                                              // Test with length < 2
                                                                                              try {
                                                                                                  TarUtils.parseOctal(new byte[]{'1'}, 0, 1);
                                                                                                  fail("Expected IllegalArgumentException");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  assertEquals("Length 1 must be at least 2", e.getMessage());
                                                                                              }
                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                          public void testParseOctal_InvalidDigits() {
                                                                                              TarUtils.parseOctal(new byte[]{'0', '9'}, 0, 2);
                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                          public void testParseOctal_InvalidDigits1() {
                                                                                              TarUtils.parseOctal(new byte[]{'0', 'a'}, 0, 2);
                                                                                          }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
          public void testParseOctalTrailingTrimWithStartEqualsEnd() {
              // Create a buffer where trimming would make start equal end
              byte[] buffer = new byte[] {' ', '1', '2', '3', ' '};
              int offset = 0;
              int length = buffer.length;
              
              // This should throw ArrayIndexOutOfBoundsException with the mutant
              // because it will try to access buffer[-1] when start equals end
              TarUtils.parseOctal(buffer, offset, length);
              
              // With original code, this would throw IllegalArgumentException
              // because after trimming we'd have valid digits to parse
              // The mutant fails by throwing ArrayIndexOutOfBoundsException instead
          }

 @Test
         public void testParseOctalWithMultipleTrailingSpaces() {
             // Setup test with multiple trailing spaces that would expose the mutant
             byte[] buffer = {' ', '1', '2', '3', ' ', ' ', ' '}; // "123   "
             int offset = 0;
             int length = buffer.length;
             
             // Expected behavior: should parse "123" (83 in decimal)
             // With mutant (end = end - 2), it would:
             // 1st iteration: end=6 -> end=4 (skips index 5)
             // 2nd iteration: end=4 -> end=2 (should stop here)
             // Would incorrectly parse "12" (10 in decimal)
             
             long expected = 83L; // 1*64 + 2*8 + 3*1
             long actual = TarUtils.parseOctal(buffer, offset, length);
             
             assertEquals("Should correctly parse number with multiple trailing spaces", 
                         expected, actual);
         }

 @Test(expected = IllegalArgumentException.class)
        public void testParseOctal_AllSpacesWithMutationDetection() {
            // Arrange
            byte[] buffer = {' ', ' ', ' ', ' '}; // All spaces
            int offset = 0;
            int length = 4;
            
            // Act
            TarUtils.parseOctal(buffer, offset, length);
            
            // Assert
            // Expecting IllegalArgumentException because:
            // Original: start == end after trimming (throws)
            // Mutant: start >= end after trimming (also throws)
            // But we need a case where they differ...
            // Let me adjust the test to show the difference:
        }

 @Test
        public void testParseOctal_DetectStartGreaterThanEndMutation() {
            // This test would pass on original but fail on mutant
            // However, in this case it's tricky because the method's
            // trimming logic prevents start > end naturally
            
            // Better test: create a case where after trimming, start == end
            // Original throws, mutant would also throw
            // So we need to test the boundary where mutation would differ
            
            // The only way the mutant differs is if start > end, which
            // would require invalid buffer manipulation
            
            // Since we can't naturally create start > end with the method's
            // current logic, this mutant might be equivalent (no test can kill it)
            // But we can test the boundary case where start == end
            
            try {
                byte[] buffer = {' ', ' ', ' '}; // All spaces, length 3
                TarUtils.parseOctal(buffer, 0, 3);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // Both original and mutant throw here
                // This shows the mutation doesn't actually change behavior
                // in any testable way with the current method constraints
            }
            
            // Conclusion: This mutant is actually equivalent - it doesn't
            // change observable behavior because start can never be > end
            // in the current method implementation
        }

 @Test(expected = IllegalArgumentException.class)
       public void testParseOctal_AllSpacesShouldThrowException() {
           // Arrange
           byte[] buffer = {' ', ' ', ' ', ' '}; // All spaces
           int offset = 0;
           int length = 4;
           
           // Act
           TarUtils.parseOctal(buffer, offset, length);
           
           // Assert - Expecting IllegalArgumentException to be thrown
           // If mutant is present (if(false)), this test will fail because:
           // 1. It won't throw at the start==end check
           // 2. It will proceed to the digit validation and throw a different exception
           //    about invalid digits (which would make the test fail)
       }

 @Test(expected = IllegalArgumentException.class)
       public void testParseOctal_AllNULsShouldThrowException() {
           // Arrange
           byte[] buffer = {0, 0, 0, 0}; // All NUL bytes
           int offset = 0;
           int length = 4;
           
           // Act
           TarUtils.parseOctal(buffer, offset, length);
           
           // Assert - Expecting IllegalArgumentException to be thrown
           // Similar to above, mutant would cause this to fail
       }

 @Test(expected = IllegalArgumentException.class)
      public void testParseOctal_AllSpacesAfterTrimming_ShouldThrowWithDetailedMessage() {
          // Arrange
          byte[] buffer = new byte[] {' ', ' ', ' ', ' '}; // All spaces
          int offset = 0;
          int length = buffer.length;
          
          try {
              // Act
              TarUtils.parseOctal(buffer, offset, length);
          } catch (IllegalArgumentException e) {
              // Assert
              // Original behavior would include details from exceptionMessage
              // Mutant would just return "Invalid octal number"
              assertFalse("Exception message should not be generic", 
                         e.getMessage().equals("Invalid octal number"));
              assertTrue("Exception message should contain details", 
                        e.getMessage().contains("offset=") || 
                        e.getMessage().contains("length=") ||
                        e.getMessage().contains("current byte="));
              throw e;
          }
      }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctal_AllSpacesWithDifferentOffsetAndLength() throws Exception {
         // Arrange
         byte[] buffer = new byte[] {' ', ' ', ' ', ' '}; // All spaces
         int offset = 1;
         int length = 3; // Different from offset
         
         try {
             // Act
             TarUtils.parseOctal(buffer, offset, length);
         } catch (IllegalArgumentException e) {
             // Assert
             // The exception message should contain the original length (3)
             // If it contains offset (1) instead, the mutant survives
             assertTrue("Exception message should contain original length",
                       e.getMessage().contains("length=3") || 
                       e.getMessage().contains("Length 3"));
             throw e;
         }
     }

 @Test
        public void testParseOctalWithLeadingZeroReturnsZero() {
            // Test case specifically to catch the return 0L -> return 1L mutant
            byte[] buffer = {0, '1', '2', '3'}; // Buffer starts with 0
            long result = TarUtils.parseOctal(buffer, 0, 4);
            assertEquals("Method should return 0 when buffer starts with 0", 0L, result);
        }

 @Test
        public void testParseOctalValidNumber() {
            byte[] buffer = {' ', '1', '2', '3', ' ', 0}; // With spaces and null
            long result = TarUtils.parseOctal(buffer, 0, 6);
            assertEquals("Should parse octal number correctly", 0123L, result); // 0123 octal = 83 decimal
        }

 @Test(expected = IllegalArgumentException.class)
        public void testParseOctalInvalidLength() {
            byte[] buffer = {'1'};
            TarUtils.parseOctal(buffer, 0, 1); // Length < 2 should throw
        }

 @Test(expected = IllegalArgumentException.class)
        public void testParseOctalInvalidDigits() {
            byte[] buffer = {' ', '8', ' '}; // '8' is invalid in octal
            TarUtils.parseOctal(buffer, 0, 3);
        }

 @Test(expected = IllegalArgumentException.class)
        public void testParseOctalAllSpaces() {
            byte[] buffer = {' ', ' ', ' '};
            TarUtils.parseOctal(buffer, 0, 3);
        }

 @Test
       public void testParseOctalWithLeadingZeroReturnsZero1() {
           // Test case specifically designed to catch the return 0L -> return -1L mutant
           byte[] buffer = new byte[]{0, '1', '2', '3'}; // First byte is 0
           long result = TarUtils.parseOctal(buffer, 0, 4);
           assertEquals("Method should return 0 when first byte is 0", 0L, result);
       }

 @Test
       public void testParseOctalWithNonZeroValue() {
           // Additional test to verify normal parsing still works
           byte[] buffer = new byte[]{'1', '2', '3', '4'};
           long result = TarUtils.parseOctal(buffer, 0, 4);
           assertEquals("Method should correctly parse octal number", 01234L, result);
       }

 @Test(expected = IllegalArgumentException.class)
       public void testParseOctalWithInvalidLength() {
           // Verify length validation still works
           byte[] buffer = new byte[]{'1'};
           TarUtils.parseOctal(buffer, 0, 1);
       }

 @Test
       public void testParseOctalWithSpaces() {
           // Test with leading and trailing spaces
           byte[] buffer = new byte[]{' ', ' ', '1', '2', ' ', ' '};
           long result = TarUtils.parseOctal(buffer, 0, 6);
           assertEquals("Method should handle spaces correctly", 012L, result);
       }

 @Test(expected = IllegalArgumentException.class)
  public void testParseOctal_InvalidLengthThrowsIllegalArgumentException() {
      // Test case for length < 2
      byte[] buffer = {'1', '2'};
      TarUtils.parseOctal(buffer, 0, 1); // length 1 < 2 should throw IllegalArgumentException
  }

 @Test(expected = IllegalArgumentException.class)
  public void testParseOctal_InvalidOctalDigitThrowsIllegalArgumentException() {
      // Test case for invalid octal digit (should be 0-7)
      byte[] buffer = {'1', '8', ' '}; // '8' is invalid octal digit
      TarUtils.parseOctal(buffer, 0, 3);
  }

 @Test
  public void testParseOctal_ValidInput() {
      // Valid input test to ensure normal functionality works
      byte[] buffer = {' ', '1', '2', '3', ' '};
      long result = TarUtils.parseOctal(buffer, 0, 5);
      assertEquals(83L, result); // octal 123 = decimal 83
  }

 @Test(expected = IllegalArgumentException.class)
  public void testParseOctal_AllSpacesThrowsIllegalArgumentException() {
      // Test case where input contains only spaces after trimming
      byte[] buffer = {' ', ' ', ' '};
      TarUtils.parseOctal(buffer, 0, 3);
  }

 @Test
     public void testParseOctalThrowsIllegalArgumentExceptionForShortLength() {
         byte[] buffer = {'0', '1'};
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Length 1 must be at least 2");
         TarUtils.parseOctal(buffer, 0, 1);
     }

 @Test
     public void testParseOctalThrowsIllegalArgumentExceptionForInvalidDigits() {
         byte[] buffer = {' ', '8', ' '}; // '8' is invalid in octal
         thrown.expect(IllegalArgumentException.class);
         // The exact message might vary based on exceptionMessage implementation
         thrown.expectMessage("Invalid octal digit");
         TarUtils.parseOctal(buffer, 0, 3);
     }

 @Test
     public void testParseOctalThrowsIllegalArgumentExceptionForAllSpaces() {
         byte[] buffer = {' ', ' ', ' '};
         thrown.expect(IllegalArgumentException.class);
         // The exact message might vary based on exceptionMessage implementation
         thrown.expectMessage("Invalid octal digit");
         TarUtils.parseOctal(buffer, 0, 3);
     }

}
