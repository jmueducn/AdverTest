package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                           public void testParseOctal_ValidInput() {
                                                               byte[] buffer = {' ', '1', '2', '3', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 6);
                                                               assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
                                                           }

 @Test
                                                           public void testParseOctal_LeadingZeroReturnsZero() {
                                                               byte[] buffer = {'0', '1', '2', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 5);
                                                               assertEquals(0L, result);
                                                           }

 @Test
                                                           public void testParseOctal_AllSpacesReturnsZero() {
                                                               byte[] buffer = {' ', ' ', ' ', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 5);
                                                               assertEquals(0L, result);
                                                           }

 @Test
                                                           public void testParseOctal_MultipleTrailingSpaces() {
                                                               byte[] buffer = {'1', '2', ' ', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 5);
                                                               assertEquals(10L, result); // 1*8 + 2 = 10
                                                           }

 @Test
                                                           public void testParseOctal_MultipleTrailingNulls() {
                                                               byte[] buffer = {'1', '2', 0, 0, 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 5);
                                                               assertEquals(10L, result);
                                                           }

 @Test
                                                           public void testParseOctal_MaxValidOctalDigits() {
                                                               byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 12);
                                                               assertEquals(1073741823L, result); // Maximum value for 10 octal digits
                                                           }

 @Test
                                                           public void testParseOctal_WithOffset() {
                                                               byte[] buffer = {'X', 'X', '1', '2', '3', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 2, 4);
                                                               assertEquals(83L, result);
                                                           }

 @Test
                                                           public void testParseOctal_SingleValidDigit() {
                                                               byte[] buffer = {'1', ' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 3);
                                                               assertEquals(1L, result);
                                                           }

 @Test
                                                           public void testParseOctal_EmptyButValidTrailer() {
                                                               byte[] buffer = {' ', 0};
                                                               long result = TarUtils.parseOctal(buffer, 0, 2);
                                                               assertEquals(0L, result);
                                                           }

 @Test
                                                   public void testParseOctal_InvalidDigitThrowsException() {
                                                       org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                       exceptionRule.expect(IllegalArgumentException.class);
                                                       exceptionRule.expectMessage("Invalid octal digit");
                                                       byte[] buffer = {'1', '8', ' ', 0}; // '8' is invalid in octal
                                                       TarUtils.parseOctal(buffer, 0, 4);
                                                   }

 @Test(expected = IllegalArgumentException.class)
           public void testParseOctal_LengthLessThan2_ShouldIncludeLengthInErrorMessage() {
               // Arrange
               byte[] buffer = new byte[10];
               int offset = 0;
               int invalidLength = 1; // Length less than 2
               
               try {
                   // Act
                   TarUtils.parseOctal(buffer, offset, invalidLength);
               } catch (IllegalArgumentException e) {
                   // Assert
                   String expectedMessage = "Length " + invalidLength + " must be at least 2";
                   assertTrue("Exception message should contain the invalid length", 
                             e.getMessage().contains(expectedMessage));
                   throw e;
               }
           }

 @Test(expected = IllegalArgumentException.class)
          public void testParseOctal_LengthLessThan2_ThrowsIllegalArgumentException() {
              // Arrange
              byte[] buffer = {'1', '2', '3'};
              int offset = 0;
              int length = 1; // Length < 2 to trigger the exception
              
              // Act & Assert
              TarUtils.parseOctal(buffer, offset, length);
          }

 @Test(expected = IllegalArgumentException.class)
         public void testParseOctal_LengthValidation() {
             // Arrange
             byte[] buffer = new byte[]{'1', '2'}; // length=2 valid octal
             int offset = 0;
             int length = 2;
             
             try {
                 // Act
                 TarUtils.parseOctal(buffer, offset, length);
             } catch (IllegalArgumentException e) {
                 // Assert
                 assertEquals("Length 2 must be at least 2", e.getMessage());
                 throw e; // rethrow to satisfy @Test(expected)
             }
         }

 @Test(expected = IllegalArgumentException.class)
        public void testParseOctal_LengthLessThan2_ThrowsException() {
            // Arrange
            byte[] buffer = new byte[]{'0', '1'}; // Content doesn't matter for this test
            int offset = 0;
            int length = 1; // Length < 2 to trigger the condition
            
            // Act - This should throw IllegalArgumentException in original code
            // but would return -1L in mutated code
            TarUtils.parseOctal(buffer, offset, length);
            
            // Assertion is handled by the @Test(expected) annotation
        }

 @Test
        public void testParseOctal_LengthExactly2_DoesNotThrow() {
            // Arrange
            byte[] buffer = new byte[]{'0', '1'};
            int offset = 0;
            int length = 2; // Edge case - exactly 2
            
            // Act
            long result = TarUtils.parseOctal(buffer, offset, length);
            
            // Assert - just verify no exception is thrown
            // We could add more assertions about the return value if needed
            assertTrue(result >= 0);
        }

 @Test(expected = IllegalArgumentException.class)
       public void testParseOctal_InvalidLength_ShouldThrowExceptionWithCorrectLength() {
           // Arrange
           byte[] buffer = new byte[]{'1', '2', '3'};
           int offset = 0;
           int length = 1; // Invalid length (less than 2)
           
           try {
               // Act
               TarUtils.parseOctal(buffer, offset, length);
           } catch (IllegalArgumentException e) {
               // Assert
               String expectedMessage = "Length 1 must be at least 2";
               assertEquals("Exception message should show correct length value", 
                           expectedMessage, e.getMessage());
               throw e; // rethrow to satisfy @Test(expected)
           }
       }

 @Test
      public void testParseOctalWithLeadingZeroShouldReturnZero() {
          // Arrange
          byte[] buffer = {0, '1', '2', ' ', 0}; // Octal "012" with leading NUL and trailing space+NUL
          int offset = 0;
          int length = buffer.length;
          
          // Act
          long result = TarUtils.parseOctal(buffer, offset, length);
          
          // Assert
          assertEquals("Should return 0 when buffer starts with NUL", 0L, result);
      }

 @Test
      public void testParseOctalWithLeadingOneShouldNotReturnZero() {
          // Arrange
          byte[] buffer = {1, '1', '2', ' ', 0}; // Octal "112" with leading SOH and trailing space+NUL
          int offset = 0;
          int length = buffer.length;
          
          // Act
          long result = TarUtils.parseOctal(buffer, offset, length);
          
          // Assert
          assertNotEquals("Should not return 0 when buffer starts with 1", 0L, result);
          assertEquals("Should parse octal number correctly", 74L, result); // 112 in octal is 74 in decimal
      }

 @Test
     public void testParseOctalWithLeadingSpacesBeforeZero() {
         // Create a buffer with spaces, then '0', then valid octal digits
         byte[] buffer = {' ', ' ', '0', '1', '2', ' ', 0};
         int offset = 0;
         int length = buffer.length;
         
         // Original behavior should parse "012" as octal (which is 10 in decimal)
         // Mutant behavior would return 0L immediately because buffer[offset] is space (not 0)
         // but we need to test when buffer[offset] is 0 after spaces
         
         // Alternative test case that would catch this mutant:
         byte[] mutantCatchBuffer = {' ', '0', '1', '2', ' ', 0};
         offset = 0;
         length = mutantCatchBuffer.length;
         
         // Original behavior: should parse "012" (10 in decimal) because first non-space is '0'
         // Mutant behavior: would return 0L immediately because buffer[offset] is space
         
         // But to specifically catch the changed condition, we need:
         byte[] directTestBuffer = {0, ' ', '1', '2', ' ', 0};
         offset = 0;
         length = directTestBuffer.length;
         
         try {
             long result = TarUtils.parseOctal(directTestBuffer, offset, length);
             // If we get here, mutant wasn't caught - original would throw exception
             // because after skipping spaces we have digits
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             // This is expected for original code
         }
         
         // More direct test for the specific mutant:
         byte[] mutantRevealingBuffer = {' ', 0, '1', '2', ' ', 0};
         offset = 0;
         length = mutantRevealingBuffer.length;
         
         // Original: would skip space, see 0, return 0L
         // Mutant: would check buffer[0] (space), not return 0, then proceed to parse
         long originalResult = TarUtils.parseOctal(mutantRevealingBuffer, offset, length);
         assertEquals(0L, originalResult);  // This would pass for original, fail for mutant
         
         // The mutant would actually try to parse the '0' '1' '2' sequence and return 10
         // So we need to make sure the test fails if we get 10 instead of 0
     }

 @Test
     public void testParseOctalReturnsZeroOnlyForFirstNonSpaceZero() {
         // Buffer where:
         // - Original offset position is space
         // - First non-space character is 0
         // - Followed by other digits
         byte[] buffer = {' ', 0, '1', '2', ' ', 0};
         int offset = 0;
         int length = buffer.length;
         
         // Original behavior should return 0L (first non-space is 0)
         // Mutant behavior would see buffer[offset] is space, not 0, and proceed to parse
         long result = TarUtils.parseOctal(buffer, offset, length);
         
         // Assert we get 0 (original behavior) not 10 (012 in octal)
         assertEquals(0L, result);
         
         // Additional check to ensure we're not parsing the subsequent digits
         assertNotEquals(10L, result);
     }

 @Test
    public void testParseOctalWithLeadingZeroReturnsZero() {
        // Arrange
        byte[] buffer = {0, '1', '2', ' '}; // Buffer starts with 0
        int offset = 0;
        int length = 4;
        
        // Act
        long result = TarUtils.parseOctal(buffer, offset, length);
        
        // Assert
        assertEquals("Method should return 0 when first byte is 0", 0L, result);
    }

 @Test
   public void testParseOctalWithLeadingZeroReturnsZero1() {
       // Arrange
       byte[] buffer = {0, '1', '2', ' '}; // Buffer starts with 0
       int offset = 0;
       int length = 4;
       
       // Act
       long result = TarUtils.parseOctal(buffer, offset, length);
       
       // Assert
       assertEquals("Method should return 0 when buffer starts with 0", 0L, result);
   }

 @Test
  public void testParseOctalWithLeadingZeroReturnsZero2() {
      // Arrange
      byte[] buffer = {0, '1', '2', ' '}; // Buffer starts with 0
      int offset = 0;
      int length = 4;
      
      // Act
      long result = TarUtils.parseOctal(buffer, offset, length);
      
      // Assert
      assertEquals("Method should return 0 when buffer starts with 0", 0L, result);
  }

 @Test
 public void testParseOctalWithZeroValueShouldReturnZeroInsteadOfThrowingException() {
     // Arrange
     byte[] buffer = {0, '1', '2', ' '}; // Buffer starts with 0
     int offset = 0;
     int length = 4;
     
     try {
         // Act
         long result = TarUtils.parseOctal(buffer, offset, length);
         
         // Assert - original behavior should return 0
         assertEquals(0L, result);
     } catch (IllegalArgumentException e) {
         // If we get here, the mutant survived
         fail("Original method should return 0 for zero value, but got exception: " + e.getMessage());
     }
 }

 @Test(expected = IllegalArgumentException.class)
 public void testParseOctalWithZeroValueMutantBehavior() {
     // Arrange
     byte[] buffer = {0, '1', '2', ' '}; // Buffer starts with 0
     int offset = 0;
     int length = 4;
     
     // Act - mutant behavior should throw exception
     TarUtils.parseOctal(buffer, offset, length);
     
     // If we get here without exception, the test fails
     fail("Mutant should throw IllegalArgumentException for zero value");
 }

}
