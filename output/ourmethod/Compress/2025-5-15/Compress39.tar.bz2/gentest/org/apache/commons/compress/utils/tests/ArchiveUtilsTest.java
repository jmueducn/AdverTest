package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ArchiveUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                             public void testSanitize_NormalStringWithinLimit() {
                                                 String input = "This is a normal string 123";
                                                 String result = ArchiveUtils.sanitize(input);
                                                 assertEquals(input, result);
                                             }

 @Test
                                             public void testSanitize_StringWithControlCharacters() {
                                                 String input = "Text\u0000With\u001FControl\u007FChars";
                                                 String expected = "Text?With?Control?Chars";
                                                 String result = ArchiveUtils.sanitize(input);
                                                 assertEquals(expected, result);
                                             }

 @Test
                                             public void testSanitize_StringWithUnicodeSpecials() {
                                                 // Unicode SPECIALS block contains characters from U+FFF0 to U+FFFF
                                                 String input = "Text\uFFF0With\uFFFDUnicode\uFFFFSpecials";
                                                 String expected = "Text?With?Unicode?Specials";
                                                 String result = ArchiveUtils.sanitize(input);
                                                 assertEquals(expected, result);
                                             }

 @Test
                                             public void testSanitize_EmptyString() {
                                                 String input = "";
                                                 String result = ArchiveUtils.sanitize(input);
                                                 assertEquals("", result);
                                             }

 @Test
                                             public void testSanitize_MixedCharacters() {
                                                 String input = "N\u00FCrmal\u0001T\uFFF0xt"; // Contains normal, control, and special chars
                                                 String expected = "Nürmal?T?xt";
                                                 String result = ArchiveUtils.sanitize(input);
                                                 assertEquals(expected, result);
                                             }

 @Test
                                     public void testSanitize_StringExceedingLengthLimit() throws Exception {
                                         // Get the private MAX_SANITIZED_NAME_LENGTH constant using reflection
                                         Field maxLengthField = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
                                         maxLengthField.setAccessible(true);
                                         int maxLength = maxLengthField.getInt(null);
                                         
                                         // Create a string longer than MAX length
                                         StringBuilder longString = new StringBuilder();
                                         for (int i = 0; i < maxLength + 10; i++) {
                                             longString.append('a');
                                         }
                                         String input = longString.toString();
                                         String result = ArchiveUtils.sanitize(input);
                                         
                                         // Should be truncated to MAX length with last 3 chars replaced by dots
                                         assertEquals(maxLength, result.length());
                                         assertEquals("...", result.substring(maxLength - 3));
                                     }

 @Test
                                     public void testSanitize_NullString() {
                                         ExpectedException exception = ExpectedException.none();
                                         exception.expect(NullPointerException.class);
                                         ArchiveUtils.sanitize(null);
                                     }

 @Test
                                     public void testSanitize_ExactlyMaxLength() {
                                         // Get the MAX_SANITIZED_NAME_LENGTH constant from ArchiveUtils
                                         int maxLength;
                                         try {
                                             Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
                                             field.setAccessible(true);
                                             maxLength = field.getInt(null);
                                         } catch (Exception e) {
                                             throw new RuntimeException("Failed to access MAX_SANITIZED_NAME_LENGTH", e);
                                         }
                                         
                                         // Create string of exactly MAX length
                                         StringBuilder exactLengthString = new StringBuilder();
                                         for (int i = 0; i < maxLength; i++) {
                                             exactLengthString.append('a');
                                         }
                                         String input = exactLengthString.toString();
                                         String result = ArchiveUtils.sanitize(input);
                                         
                                         // Should remain unchanged (no truncation or dots)
                                         assertEquals(maxLength, result.length());
                                         assertEquals(input, result);
                                     }

 @Test
                                     public void testSanitize_OneCharOverMaxLength() {
                                         // Define the max length constant used by the sanitize method
                                         final int MAX_SANITIZED_NAME_LENGTH = 255;
                                         
                                         // Create string of MAX length + 1
                                         StringBuilder overLengthString = new StringBuilder();
                                         for (int i = 0; i < MAX_SANITIZED_NAME_LENGTH + 1; i++) {
                                             overLengthString.append('a');
                                         }
                                         String input = overLengthString.toString();
                                         String result = ArchiveUtils.sanitize(input);
                                         
                                         // Should be truncated to MAX length with last 3 chars replaced by dots
                                         assertEquals(MAX_SANITIZED_NAME_LENGTH, result.length());
                                         assertEquals("...", result.substring(MAX_SANITIZED_NAME_LENGTH - 3));
                                     }

 @Test
                                 public void testSanitize_ExactMaxLength_ShouldNotTruncate() {
                                     // Setup
                                     int MAX_SANITIZED_NAME_LENGTH = 10; // Assuming this is the value, adjust if different
                                     String input = "1234567890"; // Exactly MAX_SANITIZED_NAME_LENGTH characters
                                     
                                     // Test
                                     String result = ArchiveUtils.sanitize(input);
                                     
                                     // Verify
                                     assertEquals("Original string should remain unchanged when length equals MAX_SANITIZED_NAME_LENGTH", 
                                                  input, result);
                                     
                                     // Additional verification that no dots were added
                                     assertFalse("String should not contain dots when length equals MAX_SANITIZED_NAME_LENGTH",
                                                result.contains("..."));
                                 }

 @Test
                           public void testSanitize_StringLongerThanMaxLength_ShouldReplaceLastThreeCharsWithDots() {
                               // Setup
                               String longString = "ThisIsAStringThatIsLongerThanTheMaxLength";
                               int originalMaxLength = 0; // Initialize with default value
                               
                               try {
                                   // Use reflection to get original MAX_SANITIZED_NAME_LENGTH
                                   Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
                                   field.setAccessible(true);
                                   originalMaxLength = (int) field.get(null);
                                   
                                   // Set to small value for testing
                                   field.set(null, 10);
                                   
                                   // Test
                                   String result = ArchiveUtils.sanitize(longString);
                                   
                                   // Verify
                                   assertEquals(10, result.length());
                                   assertEquals("ThisIsA...", result); // Should have 3 dots at end
                                   
                                   // Test with string exactly one character longer than max
                                   String boundaryString = "1234567890X";
                                   result = ArchiveUtils.sanitize(boundaryString);
                                   assertEquals(10, result.length());
                                   assertEquals("1234567...", result); // Should have 3 dots at end
                               } catch (Exception e) {
                                   fail("Exception occurred during test: " + e.getMessage());
                               } finally {
                                   try {
                                       // Reset MAX_SANITIZED_NAME_LENGTH
                                       Field field = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
                                       field.setAccessible(true);
                                       field.set(null, originalMaxLength);
                                   } catch (Exception e) {
                                       // Ignore reset failure
                                   }
                               }
                           }

 @Test
                      public void testSanitizeWithVeryLongStringDetectsStringBuilderMutation() throws Exception {
                          // Use reflection to access private MAX_SANITIZED_NAME_LENGTH field
                          Field maxLengthField = ArchiveUtils.class.getDeclaredField("MAX_SANITIZED_NAME_LENGTH");
                          maxLengthField.setAccessible(true);
                          int MAX_SANITIZED_NAME_LENGTH = maxLengthField.getInt(null);
                          
                          // Create a string much longer than MAX_SANITIZED_NAME_LENGTH
                          // Using a length that would force multiple resizes in original version
                          int veryLongLength = MAX_SANITIZED_NAME_LENGTH * 10;
                          StringBuilder longStringBuilder = new StringBuilder(veryLongLength);
                          for (int i = 0; i < veryLongLength; i++) {
                              longStringBuilder.append('a'); // Using 'a' as it's a safe character
                          }
                          String veryLongString = longStringBuilder.toString();
                          
                          // The mutation would be more efficient in memory handling
                          // While the test can't directly detect the mutation, 
                          // this extreme case would make the performance difference noticeable
                          
                          // Time the operation (indirect way to detect the mutation)
                          long startTime = System.nanoTime();
                          String result = ArchiveUtils.sanitize(veryLongString);
                          long duration = System.nanoTime() - startTime;
                          
                          // Verify the result is properly sanitized
                          assertEquals(MAX_SANITIZED_NAME_LENGTH, result.length());
                          assertTrue(result.endsWith("..."));
                          
                          // The mutated version should be faster as it avoids resizes
                          // Set a reasonable threshold (this would need calibration)
                          long threshold = 1000000; // 1ms in nanoseconds
                          assertTrue("Performance should be better with pre-sized StringBuilder", 
                                    duration < threshold);
                      }

 @Test
                  public void testSanitizeWithNullUnicodeBlockCharacter() {
                      // Find a character that returns null UnicodeBlock
                      // Character '\uFFFF' is typically one such character
                      char nullBlockChar = '\uFFFF';
                      String input = "test" + nullBlockChar + "string";
                      
                      // Original behavior should replace null block char with '?'
                      String result = ArchiveUtils.sanitize(input);
                      
                      // Verify the null block char was replaced
                      assertFalse("Null UnicodeBlock character should be replaced", 
                                 result.contains(String.valueOf(nullBlockChar)));
                      assertTrue("Null UnicodeBlock character should become '?'", 
                                result.contains("?"));
                      
                      // Also verify other characters remain unchanged
                      assertTrue(result.startsWith("test"));
                      assertTrue(result.endsWith("string"));
                  }

 @Test
                  public void testSanitizeWithSpecialsBlockCharacter() {
                      // Find a character from Unicode SPECIALS block
                      // Character '\uFFF0' is in SPECIALS block
                      char specialsChar = '\uFFF0';
                      String input = "test" + specialsChar + "string";
                      
                      // Both original and mutant should replace SPECIALS char with '?'
                      String result = ArchiveUtils.sanitize(input);
                      
                      // Verify the SPECIALS char was replaced
                      assertFalse("SPECIALS UnicodeBlock character should be replaced", 
                                 result.contains(String.valueOf(specialsChar)));
                      assertTrue("SPECIALS UnicodeBlock character should become '?'", 
                                result.contains("?"));
                  }

 @Test
                  public void testSanitizeWithNormalCharacter() {
                      // Regular character that has a non-null, non-SPECIALS block
                      char normalChar = 'a';
                      String input = "test" + normalChar + "string";
                      
                      String result = ArchiveUtils.sanitize(input);
                      
                      // Verify normal character remains unchanged
                      assertTrue("Normal character should remain unchanged",
                                result.contains(String.valueOf(normalChar)));
                      assertFalse("Normal character should not be replaced with '?'",
                                 result.contains("?"));
                  }

 @Test
                 public void testSanitizeStringBuilderInitialization() {
                     // Setup
                     String longInput = "ThisIsAReallyLongStringThatExceedsTheMaximumLengthForSanitization";
                     String controlChars = "TextWith\u0000Control\u001FChars";
                     
                     // Test with long string to force StringBuilder operations
                     String result1 = ArchiveUtils.sanitize(longInput);
                     assertNotNull(result1);
                     
                     // Test with control characters
                     String result2 = ArchiveUtils.sanitize(controlChars);
                     assertEquals("TextWith?Control?Chars", result2);
                     
                     // Test empty string
                     String result3 = ArchiveUtils.sanitize("");
                     assertEquals("", result3);
                     
                     // Test exact boundary case
                     String boundaryInput = "123456789012345"; // assuming MAX_SANITIZED_NAME_LENGTH is 15
                     String result4 = ArchiveUtils.sanitize(boundaryInput);
                     assertEquals(boundaryInput, result4);
                     
                     // Test one over boundary
                     String overBoundary = "1234567890123456"; // assuming MAX_SANITIZED_NAME_LENGTH is 15
                     String result5 = ArchiveUtils.sanitize(overBoundary);
                     assertEquals("123456789012...", result5);
                 }

 @Test
               public void testSanitizeWithExactMaxLength() {
                   // Determine max length by finding when the method starts truncating
                   int maxLen = 255; // Common default for filename lengths
                   StringBuilder sb = new StringBuilder();
                   for (int i = 0; i < maxLen + 10; i++) {
                       sb.append('a');
                   }
                   String longInput = sb.toString();
                   String truncated = ArchiveUtils.sanitize(longInput);
                   maxLen = truncated.length(); // This will be the actual MAX_SANITIZED_NAME_LENGTH
                   
                   // Now create a string with exactly maxLen characters
                   sb = new StringBuilder();
                   for (int i = 0; i < maxLen; i++) {
                       sb.append('a'); // Using 'a' as it's a safe character that won't be replaced
                   }
                   String input = sb.toString();
                   
                   // The original method should return the same string unchanged
                   String result = ArchiveUtils.sanitize(input);
                   
                   // Verify the length is correct
                   assertEquals(maxLen, result.length());
                   
                   // Verify the content is unchanged
                   assertEquals(input, result);
                   
                   // The mutated version would throw ArrayIndexOutOfBoundsException
                   // which would make the test fail
               }

 @Test
           public void testSanitizeProcessesFirstCharacter() {
               // Arrange
               String input = "\u0000ABC"; // First character is control character (should be replaced)
               String expected = "?ABC"; // First character should be '?'
               
               // Act
               String result = ArchiveUtils.sanitize(input);
               
               // Assert
               assertEquals("First character should be processed", expected, result);
               assertEquals("Output length should match input length", input.length(), result.length());
               assertEquals("First character should be sanitized", '?', result.charAt(0));
           }

 @Test
           public void testSanitizeProcessesFirstCharacterWhenSpecial() {
               // Arrange
               String input = "\uFFF0ABC"; // First character is in Unicode SPECIALS block
               String expected = "?ABC"; // First character should be '?'
               
               // Act
               String result = ArchiveUtils.sanitize(input);
               
               // Assert
               assertEquals("First character in SPECIALS block should be replaced", expected, result);
           }

 @Test
           public void testSanitizeProcessesFirstCharacterWhenValid() {
               // Arrange
               String input = "ABCD"; // All characters valid
               String expected = "ABCD"; // Should remain unchanged
               
               // Act
               String result = ArchiveUtils.sanitize(input);
               
               // Assert
               assertEquals("Valid first character should be preserved", expected, result);
           }

 @Test
          public void testIsArrayZeroDetectsMutant() {
              // Test with all zeros - should return true
              byte[] allZeros = new byte[]{0, 0, 0, 0};
              assertTrue("All zero array should return true", 
                        ArchiveUtils.isArrayZero(allZeros, allZeros.length));
              
              // Test with one non-zero - should return false
              byte[] oneNonZero = new byte[]{0, 0, 1, 0};
              assertFalse("Array with non-zero should return false", 
                         ArchiveUtils.isArrayZero(oneNonZero, oneNonZero.length));
              
              // Test with all non-zeros - should return false
              byte[] allNonZeros = new byte[]{1, 2, 3, 4};
              assertFalse("All non-zero array should return false", 
                         ArchiveUtils.isArrayZero(allNonZeros, allNonZeros.length));
              
              // Test empty array - should return true
              byte[] empty = new byte[0];
              assertTrue("Empty array should return true", 
                        ArchiveUtils.isArrayZero(empty, empty.length));
          }

 @Test
         public void testSanitizeWithZeroAndNegativeBytes() {
             // Setup
             String inputWithNullChar = "test\u0000string"; // contains null character (0)
             String inputWithSpecialChars = "test\u0080string"; // contains negative byte value
             
             // Test with null character (0)
             String result1 = ArchiveUtils.sanitize(inputWithNullChar);
             // Null character should be replaced with '?'
             assertFalse(result1.contains("\u0000"));
             assertTrue(result1.contains("?"));
             
             // Test with negative byte value character
             String result2 = ArchiveUtils.sanitize(inputWithSpecialChars);
             // Special character should be replaced with '?'
             assertFalse(result2.contains("\u0080"));
             assertTrue(result2.contains("?"));
             
             // Verify both cases are handled the same way (original behavior)
             // The mutant would handle these differently
             assertEquals(result1.indexOf('?'), result2.indexOf('?'));
             assertEquals(result1.length(), result2.length());
         }

 @Test
        public void testSanitizeWithControlCharacters() {
            // Setup
            String inputWithControlChars = "Hello\u0008World"; // Contains backspace control char
            String inputWithNormalChars = "HelloWorld";
            String inputWithUnicodeSpecials = "Hello\uFFF0World"; // Contains Unicode special
            
            // Test control characters - should be replaced with '?'
            String result1 = ArchiveUtils.sanitize(inputWithControlChars);
            assertFalse("Control characters should be replaced", result1.contains("\u0008"));
            assertTrue("Control characters should become '?'", result1.contains("?"));
            
            // Test normal characters - should pass through unchanged
            String result2 = ArchiveUtils.sanitize(inputWithNormalChars);
            assertEquals("Normal characters should pass through", inputWithNormalChars, result2);
            
            // Test Unicode specials - should be replaced with '?'
            String result3 = ArchiveUtils.sanitize(inputWithUnicodeSpecials);
            assertFalse("Unicode specials should be replaced", result3.contains("\uFFF0"));
            assertTrue("Unicode specials should become '?'", result3.contains("?"));
            
            // Test mixed case
            String mixedInput = "He\u0008llo\uFFF0World";
            String expected = "He?llo?World";
            assertEquals("Mixed input should be properly sanitized", expected, ArchiveUtils.sanitize(mixedInput));
        }

 @Test
           public void testSanitizeWithControlCharacters1() {
               // String with control characters and special Unicode
               String input = "Normal\u0000Text\u001FWith\uFFFFControls";
               String expected = "Normal?Text?With?Controls";
               
               String result = ArchiveUtils.sanitize(input);
               assertEquals(expected, result);
           }

 @Test
           public void testSanitizeSpecialUnicode() {
               // Test with characters from SPECIALS Unicode block
               String input = "Normal\uFFF0Special\uFFFDChars";
               String expected = "Normal?Special?Chars";
               
               String result = ArchiveUtils.sanitize(input);
               assertEquals(expected, result);
           }

 @Test
           public void testSanitizeMixedContent() {
               // Test with mixed valid and invalid characters
               String input = "A\u0000B\u001CC\uFFFD\uFFFFD";
               String expected = "A?B?C??D";
               
               String result = ArchiveUtils.sanitize(input);
               assertEquals(expected, result);
           }

 @Test
      public void testSanitizeLongString() {
          // Define the max length constant that matches the implementation
          final int MAX_SANITIZED_NAME_LENGTH = 255;
          
          // Create a string longer than MAX length
          char[] longChars = new char[MAX_SANITIZED_NAME_LENGTH + 5];
          Arrays.fill(longChars, 'a');
          String longInput = new String(longChars);
          
          String result = ArchiveUtils.sanitize(longInput);
          // Should be truncated with last 3 chars replaced by dots
          assertEquals(MAX_SANITIZED_NAME_LENGTH, result.length());
          assertTrue(result.endsWith("..."));
      }

 @Test
      public void testSanitize() {
          // Test short string (no truncation needed)
          String shortInput = "Hello";
          assertEquals("Hello", ArchiveUtils.sanitize(shortInput));
  
          // Test string with exactly MAX length
          String exactLengthInput = "1234567890";
          assertEquals("1234567890", ArchiveUtils.sanitize(exactLengthInput));
  
          // Test long string (should be truncated with dots)
          String longInput = "ThisIsALongString";
          String expectedLong = "1234567..."; // Assuming MAX_LENGTH=10
          assertEquals(expectedLong, ArchiveUtils.sanitize(longInput));
  
          // Test string with control characters
          String controlCharInput = "Hello\u0001World";
          assertEquals("Hello?World", ArchiveUtils.sanitize(controlCharInput));
  
          // Test string with Unicode specials
          String specialsInput = "Hello\uFFF0World";
          assertEquals("Hello?World", ArchiveUtils.sanitize(specialsInput));
  
          // Test empty string
          assertEquals("", ArchiveUtils.sanitize(""));
  
          // Test string with only control characters
          assertEquals("???", ArchiveUtils.sanitize("\u0001\u0002\u0003"));
      }

 @Test
     public void testSanitize_shortStringNoSpecialChars() {
         String input = "test123";
         String result = ArchiveUtils.sanitize(input);
         assertEquals("test123", result);
     }

 @Test
     public void testSanitize_longStringGetsTruncated() {
         String input = "thisisalongstring";
         String result = ArchiveUtils.sanitize(input);
         assertEquals("thisisa...", result); // Should be truncated to 10 chars with last 3 as dots
     }

 @Test
     public void testSanitize_exactLengthString() {
         String input = "exactlength";
         String result = ArchiveUtils.sanitize(input);
         assertEquals("exactlength", result); // Exactly MAX length, no truncation
     }

 @Test
     public void testSanitize_controlCharsReplaced() {
         String input = "test\u0000\u001F";
         String result = ArchiveUtils.sanitize(input);
         assertEquals("test??", result); // Control chars should be replaced with ?
     }

 @Test
     public void testSanitize_specialUnicodeReplaced() {
         String input = "test\uFFF0"; // Unicode special block character
         String result = ArchiveUtils.sanitize(input);
         assertEquals("test?", result); // Special block should be replaced with ?
     }

 @Test
     public void testSanitize_emptyString() {
         String input = "";
         String result = ArchiveUtils.sanitize(input);
         assertEquals("", result);
     }

 @Test
     public void testSanitize_nullString() {
         String input = null;
         String result = ArchiveUtils.sanitize(input);
         assertNull(result);
     }

}
