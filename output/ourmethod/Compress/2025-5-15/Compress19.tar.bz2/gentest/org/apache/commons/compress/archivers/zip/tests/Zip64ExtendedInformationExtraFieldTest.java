package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.util.zip.ZipException;
 
public class Zip64ExtendedInformationExtraFieldTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                public void testReparseCentralDirectoryData_AllFieldsPresent() throws Exception {
                                                                                    final int DWORD = 8; // Size of 8-byte integer
                                                                                    final int WORD = 4;  // Size of 4-byte integer
                                                                                    
                                                                                    byte[] data = new byte[DWORD * 3 + WORD];
                                                                                    // Populate test data
                                                                                    System.arraycopy(new ZipEightByteInteger(1000L).getBytes(), 0, data, 0, DWORD);
                                                                                    System.arraycopy(new ZipEightByteInteger(500L).getBytes(), 0, data, DWORD, DWORD);
                                                                                    System.arraycopy(new ZipEightByteInteger(200L).getBytes(), 0, data, DWORD*2, DWORD);
                                                                                    System.arraycopy(new ZipLong(1).getBytes(), 0, data, DWORD*3, WORD);
                                                                                    
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    // Use reflection to set private field since there's no public setter
                                                                                    Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    
                                                                                    field.reparseCentralDirectoryData(true, true, true, true);
                                                                                    
                                                                                    assertEquals(1000L, field.getSize().getLongValue());
                                                                                    assertEquals(500L, field.getCompressedSize().getLongValue());
                                                                                    assertEquals(200L, field.getRelativeHeaderOffset().getLongValue());
                                                                                    assertEquals(1L, field.getDiskStartNumber().getValue());
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_OnlySizes() throws Exception {
                                                                                    // Define constants
                                                                                    final int DWORD = 8; // Size of ZipEightByteInteger
                                                                                    final int WORD = 4;   // Size of ZipLong
                                                                                    
                                                                                    byte[] data = new byte[DWORD * 2];
                                                                                    System.arraycopy(new ZipEightByteInteger(1000L).getBytes(), 0, data, 0, DWORD);
                                                                                    System.arraycopy(new ZipEightByteInteger(500L).getBytes(), 0, data, DWORD, DWORD);
                                                                                    
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    
                                                                                    // Use reflection to set private field
                                                                                    Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    
                                                                                    field.reparseCentralDirectoryData(true, true, false, false);
                                                                                    
                                                                                    assertEquals(1000L, field.getSize().getLongValue());
                                                                                    assertEquals(500L, field.getCompressedSize().getLongValue());
                                                                                    assertNull(field.getRelativeHeaderOffset());
                                                                                    assertNull(field.getDiskStartNumber());
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_OnlyHeaderOffset() throws Exception {
                                                                                    final int DWORD = 8;
                                                                                    byte[] data = new byte[DWORD];
                                                                                    System.arraycopy(new org.apache.commons.compress.archivers.zip.ZipEightByteInteger(200L).getBytes(), 0, data, 0, DWORD);
                                                                                    
                                                                                    org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField field = 
                                                                                        new org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField();
                                                                                    
                                                                                    // Use reflection to set private field
                                                                                    java.lang.reflect.Field rawDataField = field.getClass().getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    
                                                                                    field.reparseCentralDirectoryData(false, false, true, false);
                                                                                    
                                                                                    assertNull(field.getSize());
                                                                                    assertNull(field.getCompressedSize());
                                                                                    assertEquals(200L, field.getRelativeHeaderOffset().getLongValue());
                                                                                    assertNull(field.getDiskStartNumber());
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_OnlyDiskStart() throws Exception {
                                                                                    final int WORD = 4; // size of ZipLong
                                                                                    byte[] data = new byte[WORD];
                                                                                    System.arraycopy(new ZipLong(1).getBytes(), 0, data, 0, WORD);
                                                                                    
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    // Use reflection to set private field
                                                                                    Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    
                                                                                    field.reparseCentralDirectoryData(false, false, false, true);
                                                                                    
                                                                                    assertNull(field.getSize());
                                                                                    assertNull(field.getCompressedSize());
                                                                                    assertNull(field.getRelativeHeaderOffset());
                                                                                    assertEquals(1L, field.getDiskStartNumber().getValue());
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_InvalidLengthAllFields() throws Exception {
                                                                                    final int DWORD = 8; // size of long
                                                                                    final int WORD = 4;  // size of int
                                                                                    byte[] data = new byte[DWORD * 3 + WORD - 1]; // One byte short
                                                                                    
                                                                                    thrown.expect(ZipException.class);
                                                                                    thrown.expectMessage("central directory zip64 extended information extra field's length doesn't match central directory data.  Expected length 28 but is 27");
                                                                                
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    field.reparseCentralDirectoryData(true, true, true, true);
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_InvalidLengthSizesOnly() throws Exception {
                                                                                    final int DWORD = 8;
                                                                                    byte[] data = new byte[DWORD * 2 - 1]; // One byte short for sizes
                                                                                    
                                                                                    thrown.expect(ZipException.class);
                                                                                    thrown.expectMessage("central directory zip64 extended information extra field's length doesn't match central directory data.  Expected length 16 but is 15");
                                                                                    
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    field.reparseCentralDirectoryData(true, true, false, false);
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_EmptyDataWithFlagsTrue() throws Exception {
                                                                                    byte[] data = new byte[0];
                                                                                    
                                                                                    thrown.expect(ZipException.class);
                                                                                    thrown.expectMessage("central directory zip64 extended information extra field's length doesn't match central directory data.  Expected length 28 but is 0");
                                                                                    
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    Field rawCentralDirectoryDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawCentralDirectoryDataField.setAccessible(true);
                                                                                    rawCentralDirectoryDataField.set(field, data);
                                                                                    
                                                                                    field.reparseCentralDirectoryData(true, true, true, true);
                                                                                }

    @Test
                                                                                public void testReparseCentralDirectoryData_MixedFields() throws Exception {
                                                                                    final int DWORD = 8; // size of long
                                                                                    final int WORD = 4;  // size of int
                                                                                    
                                                                                    byte[] data = new byte[DWORD * 2 + WORD];
                                                                                    System.arraycopy(new ZipEightByteInteger(1000L).getBytes(), 0, data, 0, DWORD);
                                                                                    System.arraycopy(new ZipLong(1).getBytes(), 0, data, DWORD, WORD);
                                                                                    System.arraycopy(new ZipEightByteInteger(200L).getBytes(), 0, data, DWORD + WORD, DWORD);
                                                                                
                                                                                    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                                                                    
                                                                                    // Use reflection to set private field
                                                                                    Field rawDataField = Zip64ExtendedInformationExtraField.class.getDeclaredField("rawCentralDirectoryData");
                                                                                    rawDataField.setAccessible(true);
                                                                                    rawDataField.set(field, data);
                                                                                    
                                                                                    field.reparseCentralDirectoryData(true, false, true, true);
                                                                                
                                                                                    assertEquals(1000L, field.getSize().getLongValue());
                                                                                    assertNull(field.getCompressedSize());
                                                                                    assertEquals(200L, field.getRelativeHeaderOffset().getLongValue());
                                                                                    assertEquals(1L, field.getDiskStartNumber().getValue());
                                                                                }

    @Test
                                        public void testReparseCentralDirectoryData_NullInput() throws ZipException {
                                            Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();
                                            field.reparseCentralDirectoryData(true, true, true, true);
                                            // Should not throw any exception with null input
                                            assertNull(field.getSize());
                                            assertNull(field.getCompressedSize());
                                            assertNull(field.getRelativeHeaderOffset());
                                            assertNull(field.getDiskStartNumber());
                                        }


}
