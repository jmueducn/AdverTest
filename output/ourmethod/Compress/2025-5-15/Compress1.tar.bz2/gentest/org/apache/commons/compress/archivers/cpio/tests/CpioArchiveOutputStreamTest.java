package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class CpioArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                             public void testClose_WhenNotClosed_CallsFinishAndSuperClose() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 
                                                                                                                                 // Use reflection to set closed field to false
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 closedField.setBoolean(stream, false);
                                                                                                                             
                                                                                                                                 // Act
                                                                                                                                 stream.close();
                                                                                                                             
                                                                                                                                 // Assert
                                                                                                                                 assertTrue(closedField.getBoolean(stream));
                                                                                                                                 verify(mockOut).close(); // Verify super.close() was called
                                                                                                                                 // Note: We can't directly verify finish() was called as it's not mocked,
                                                                                                                                 // but the behavior implies it was called before super.close()
                                                                                                                             }

    @Test
                                                                                                                             public void testClose_WhenAlreadyClosed_DoesNothing() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 
                                                                                                                                 // Use reflection to set private closed field
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 closedField.setBoolean(stream, true);
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 stream.close();
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 verify(mockOut, never()).close(); // super.close() not called
                                                                                                                             }

    @Test
                                                                                                                             public void testClose_WhenSuperCloseThrowsException_SetsClosedTrue() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 doThrow(new IOException("Close failed")).when(mockOut).close();
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 
                                                                                                                                 // Use reflection to access private 'closed' field
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 closedField.setBoolean(stream, false);
                                                                                                                                 
                                                                                                                                 // Set up expected exception
                                                                                                                                 ExpectedException expectedException = ExpectedException.none();
                                                                                                                                 expectedException.expect(IOException.class);
                                                                                                                                 expectedException.expectMessage("Close failed");
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 stream.close();
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 assertTrue(closedField.getBoolean(stream)); // closed flag should still be set to true
                                                                                                                             }

    @Test
                                                                                                                         public void testClose_WhenFinishThrowsException_StillCloses() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut) {
                                                                                                                                 @Override
                                                                                                                                 public void finish() throws IOException {
                                                                                                                                     throw new IOException("Finish failed");
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Use reflection to access private 'closed' field
                                                                                                                             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                             closedField.setAccessible(true);
                                                                                                                             closedField.set(stream, false);
                                                                                                                             
                                                                                                                             try {
                                                                                                                                 // Act
                                                                                                                                 stream.close();
                                                                                                                                 fail("Expected IOException to be thrown");
                                                                                                                             } catch (IOException e) {
                                                                                                                                 // Assert exception
                                                                                                                                 assertEquals("Finish failed", e.getMessage());
                                                                                                                                 
                                                                                                                                 // Assert stream was closed
                                                                                                                                 assertTrue((boolean) closedField.get(stream));
                                                                                                                                 verify(mockOut).close(); // super.close() should still be called
                                                                                                                             }
                                                                                                                         }

    @Test
                                                                                                                     public void testCloseWhenNotClosedShouldExecuteCloseOperations() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                         CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                         
                                                                                                                         // Use reflection to verify internal state since 'closed' is private
                                                                                                                         Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                         closedField.setAccessible(true);
                                                                                                                         boolean initialClosedState = (boolean) closedField.get(stream);
                                                                                                                         assertFalse("Stream should start not closed", initialClosedState);
                                                                                                                         
                                                                                                                         // Act
                                                                                                                         stream.close();
                                                                                                                         
                                                                                                                         // Assert
                                                                                                                         // Verify finish() was called (we can check finished flag)
                                                                                                                         Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
                                                                                                                         finishedField.setAccessible(true);
                                                                                                                         assertTrue("finish() should have been called", (boolean) finishedField.get(stream));
                                                                                                                         
                                                                                                                         // Verify super.close() was called (via mock verification)
                                                                                                                         verify(mockOut).close();
                                                                                                                         
                                                                                                                         // Verify closed flag was set
                                                                                                                         assertTrue("closed flag should be true", (boolean) closedField.get(stream));
                                                                                                                         
                                                                                                                         // Clean up
                                                                                                                         closedField.setAccessible(false);
                                                                                                                         finishedField.setAccessible(false);
                                                                                                                     }

    @Test
                                                                                                                    public void testCloseShouldNotCallFinishWhenAlreadyClosed() throws Exception {
                                                                                                                        // Setup
                                                                                                                        OutputStream mockOut = mock(OutputStream.class);
                                                                                                                        CpioArchiveOutputStream stream = spy(new CpioArchiveOutputStream(mockOut));
                                                                                                                        
                                                                                                                        // First close
                                                                                                                        stream.close();
                                                                                                                        
                                                                                                                        // Verify finish was called once
                                                                                                                        verify(stream, times(1)).finish();
                                                                                                                        
                                                                                                                        // Second close attempt
                                                                                                                        stream.close();
                                                                                                                        
                                                                                                                        // Verify finish wasn't called again (mutant would call it twice)
                                                                                                                        verify(stream, times(1)).finish();
                                                                                                                    }

    @Test
                                                                                                                   public void testCloseShouldNotCallFinishWhenAlreadyClosed1() throws Exception {
                                                                                                                       // Setup
                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                       
                                                                                                                       // First close - should work normally
                                                                                                                       stream.close();
                                                                                                                       
                                                                                                                       // Verify initial close worked using reflection
                                                                                                                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                       closedField.setAccessible(true);
                                                                                                                       assertTrue((boolean) closedField.get(stream));
                                                                                                                       
                                                                                                                       // Reset mock to track subsequent calls
                                                                                                                       reset(mockOut);
                                                                                                                       
                                                                                                                       // Second close attempt - should do nothing in original, but mutant will try to close again
                                                                                                                       stream.close();
                                                                                                                       
                                                                                                                       // Verify super.close() wasn't called again (mock would have recorded it)
                                                                                                                       verify(mockOut, never()).close();
                                                                                                                   }

    @Test
                                                                                                              public void testCloseWhenNotClosedShouldExecuteCloseOperations1() throws Exception {
                                                                                                                  // Create a spy of the output stream to verify interactions
                                                                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                                                                  
                                                                                                                  // Create instance with mock output stream
                                                                                                                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                  
                                                                                                                  // Verify initial state (closed should be false)
                                                                                                                  Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                  closedField.setAccessible(true);
                                                                                                                  assertFalse(closedField.getBoolean(stream));
                                                                                                                  
                                                                                                                  // Spy on the stream to verify finish() is called
                                                                                                                  CpioArchiveOutputStream spyStream = spy(stream);
                                                                                                                  doNothing().when(spyStream).finish();
                                                                                                                  
                                                                                                                  // Call close()
                                                                                                                  spyStream.close();
                                                                                                                  
                                                                                                                  // Verify the expected behavior:
                                                                                                                  // 1. finish() was called
                                                                                                                  verify(spyStream).finish();
                                                                                                                  // 2. super.close() was called (through the mock output stream)
                                                                                                                  verify(mockOut).close();
                                                                                                                  // 3. closed flag is set to true
                                                                                                                  assertTrue(closedField.getBoolean(spyStream));
                                                                                                                  
                                                                                                                  // This test will fail on the mutant because:
                                                                                                                  // - finish() won't be called (verification will fail)
                                                                                                                  // - mockOut.close() won't be called (verification will fail)
                                                                                                                  // - closed flag will remain false (assertion will fail)
                                                                                                              }

    @Test
                                                                                                         public void testCloseShouldCallFinishExactlyOnce() throws Exception {
                                                                                                             // Create a spy of the class to track method calls
                                                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                             CpioArchiveOutputStream spyStream = spy(stream);
                                                                                                             
                                                                                                             // Use reflection to access and modify the private 'closed' field
                                                                                                             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                             closedField.setAccessible(true);
                                                                                                             closedField.set(spyStream, false);
                                                                                                             
                                                                                                             // Mock the finish method to track calls
                                                                                                             doNothing().when(spyStream).finish();
                                                                                                             
                                                                                                             // Perform the close operation
                                                                                                             spyStream.close();
                                                                                                             
                                                                                                             // Verify finish was called exactly once
                                                                                                             verify(spyStream, times(1)).finish();
                                                                                                             
                                                                                                             // Verify the output stream was closed
                                                                                                             verify(mockOut).close();
                                                                                                             
                                                                                                             // Verify the closed flag was set to true
                                                                                                             assertTrue((boolean) closedField.get(spyStream));
                                                                                                         }

    @Test
                                                                                                     public void testCloseShouldCallSuperClose() throws Exception {
                                                                                                         // Create a mock OutputStream to verify close() calls
                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                         
                                                                                                         // Create our test subject with the mock output stream
                                                                                                         CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                         
                                                                                                         // Call the close method
                                                                                                         stream.close();
                                                                                                         
                                                                                                         // Verify the parent close was called exactly once
                                                                                                         verify(mockOut).close();
                                                                                                         
                                                                                                         // Try to interact with stream to verify it's closed
                                                                                                         try {
                                                                                                             stream.write(0); // Should throw IOException if closed
                                                                                                             fail("Expected IOException after close");
                                                                                                         } catch (IOException expected) {
                                                                                                             // Expected behavior
                                                                                                         }
                                                                                                     }

    @Test
                                                                                                    public void testCloseShouldCallSuperClose1() throws Exception {
                                                                                                        // Create a mock OutputStream to verify close() calls
                                                                                                        OutputStream mockOut = mock(OutputStream.class);
                                                                                                        
                                                                                                        // Create our test subject with the mock output stream
                                                                                                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                        
                                                                                                        // Call the close method
                                                                                                        stream.close();
                                                                                                        
                                                                                                        // Verify the parent close was called exactly once
                                                                                                        verify(mockOut).close();
                                                                                                        
                                                                                                        // Verify close is idempotent by calling again
                                                                                                        stream.close();
                                                                                                        verify(mockOut, times(1)).close(); // Still only called once
                                                                                                    }

    @Test
                                                                                               public void testCloseShouldCallSuperCloseExactlyOnce() throws Exception {
                                                                                                   // Create a mock OutputStream to track close calls
                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                   
                                                                                                   // Create the CpioArchiveOutputStream with our mock
                                                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                   
                                                                                                   // Get the private closed field using reflection
                                                                                                   Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                   closedField.setAccessible(true);
                                                                                                   
                                                                                                   // Ensure the stream isn't closed initially
                                                                                                   assertFalse((boolean) closedField.get(stream));
                                                                                                   
                                                                                                   // Call the close method
                                                                                                   stream.close();
                                                                                                   
                                                                                                   // Verify super.close() was called exactly once
                                                                                                   verify(mockOut, times(1)).close();
                                                                                                   
                                                                                                   // Verify the closed flag was set
                                                                                                   assertTrue((boolean) closedField.get(stream));
                                                                                                   
                                                                                                   // Verify no more interactions with the mock
                                                                                                   verifyNoMoreInteractions(mockOut);
                                                                                               }

    @Test
                                                                                               public void testMultipleCloseCallsOnlyCloseOnce() throws Exception {
                                                                                                   // Setup
                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                   
                                                                                                   // First close
                                                                                                   stream.close();
                                                                                                   
                                                                                                   // Second close attempt
                                                                                                   stream.close();
                                                                                                   
                                                                                                   // Verify underlying stream was only closed once
                                                                                                   verify(mockOut, times(1)).close();
                                                                                                   // With mutant, this would fail as close() would be called multiple times
                                                                                                   // because closed flag remains false
                                                                                               }

    @Test
                                                                                          public void testCloseSetsClosedFlagToTrue() throws Exception {
                                                                                              // Setup
                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                              CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                              
                                                                                              // Get the closed field via reflection
                                                                                              Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                              closedField.setAccessible(true);
                                                                                              
                                                                                              // Verify initial state
                                                                                              assertFalse((boolean) closedField.get(stream)); // Should start as not closed
                                                                                              
                                                                                              // Execute close
                                                                                              stream.close();
                                                                                              
                                                                                              // Verify closed flag was set to true (will fail with mutant)
                                                                                              assertTrue("Stream should be marked as closed after close()", 
                                                                                                        (boolean) closedField.get(stream));
                                                                                              
                                                                                              // Verify finish and super.close were called exactly once
                                                                                              verify(mockOut, times(1)).close();
                                                                                              // Note: Can't verify finish() call directly since it's not mocked,
                                                                                              // but the closed flag being true implies it was called
                                                                                          }

    @Test
                                                                                      public void testCloseSetsClosedFlag() throws Exception {
                                                                                          // Arrange
                                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                          
                                                                                          // Act - First close
                                                                                          stream.close();
                                                                                          
                                                                                          // Assert - Verify closed flag is set
                                                                                          Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                          closedField.setAccessible(true);
                                                                                          boolean isClosed = closedField.getBoolean(stream);
                                                                                          assertTrue("Stream should be marked as closed after close()", isClosed);
                                                                                          
                                                                                          // Verify finish() and super.close() were called once
                                                                                          // (Note: This requires knowing the behavior of finish() and super.close())
                                                                                          // Reset mock for verification
                                                                                          reset(mockOut);
                                                                                          
                                                                                          // Act - Second close attempt
                                                                                          stream.close();
                                                                                          
                                                                                          // Assert - Verify no additional operations performed
                                                                                          // Since we can't directly verify finish() calls without knowing its behavior,
                                                                                          // we verify that the underlying stream's close() isn't called again
                                                                                          verify(mockOut, never()).close();
                                                                                      }

    @Test
                                                                                    public void testCloseSetsClosedFlagCorrectly() throws Exception {
                                                                                        // Create a real output stream (we'll use ByteArrayOutputStream for testing)
                                                                                        OutputStream out = new ByteArrayOutputStream();
                                                                                        
                                                                                        // Create the CpioArchiveOutputStream instance
                                                                                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                        
                                                                                        // Get the closed field using reflection
                                                                                        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                        closedField.setAccessible(true);
                                                                                        
                                                                                        // Verify initial state is not closed
                                                                                        assertFalse((boolean) closedField.get(stream));
                                                                                        
                                                                                        // First close - should set closed to true
                                                                                        stream.close();
                                                                                        assertTrue((boolean) closedField.get(stream));
                                                                                        
                                                                                        // Second close - should keep closed as true (mutant would toggle it back to false)
                                                                                        stream.close();
                                                                                        assertTrue("Stream should remain closed after multiple close calls", 
                                                                                                  (boolean) closedField.get(stream));
                                                                                        
                                                                                        // Additional verification that parent close was called (though we can't directly test this)
                                                                                        // The important part is the closed flag behavior
                                                                                    }

    @Test
                                                                               public void testCloseCallsFinishWhenNotClosed() throws Exception {
                                                                                   // Create a mock output stream
                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                   
                                                                                   // Create CpioArchiveOutputStream with unfinished state
                                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                   stream.putNextEntry(new CpioArchiveEntry("test")); // Create an open entry
                                                                                   
                                                                                   // Use reflection to access private fields
                                                                                   Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
                                                                                   finishedField.setAccessible(true);
                                                                                   Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                   closedField.setAccessible(true);
                                                                                   
                                                                                   // Verify initial state
                                                                                   assertFalse((boolean) finishedField.get(stream)); // Should be false before closing
                                                                                   
                                                                                   // Close the stream
                                                                                   stream.close();
                                                                                   
                                                                                   // Verify finish() was called by checking finished flag
                                                                                   assertTrue((boolean) finishedField.get(stream)); // Would be false if mutant survives
                                                                                   
                                                                                   // Verify stream is marked as closed
                                                                                   assertTrue((boolean) closedField.get(stream));
                                                                                   
                                                                                   // Verify parent close was called
                                                                                   verify(mockOut).close();
                                                                               }

    @Test
                                                                          public void testCloseShouldCallSuperClose2() throws Exception {
                                                                              // Create a mock OutputStream and wrap it in a FilterOutputStream
                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                              FilterOutputStream spyFilterOut = spy(new FilterOutputStream(mockOut));
                                                                              
                                                                              // Create the test subject with our spied FilterOutputStream
                                                                              CpioArchiveOutputStream testStream = new CpioArchiveOutputStream(spyFilterOut);
                                                                              
                                                                              // Call the method under test
                                                                              testStream.close();
                                                                              
                                                                              // Verify super.close() was called
                                                                              verify(spyFilterOut).close();
                                                                              
                                                                              // Verify the stream is closed by attempting an operation that should fail
                                                                              try {
                                                                                  testStream.write(0);
                                                                                  fail("Should have thrown IOException after close");
                                                                              } catch (IOException expected) {
                                                                                  // expected behavior
                                                                              }
                                                                          }

    @Test
                                                                          public void testCloseCallsFinish() throws Exception {
                                                                              // Create mock OutputStream
                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                              
                                                                              // Create CpioArchiveOutputStream instance with NEW format
                                                                              CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut, CpioArchiveOutputStream.FORMAT_NEW);
                                                                              
                                                                              // Set closed to false (initial state)
                                                                              // Note: Since closed is private, we'll test through behavior
                                                                              // Alternatively, we could use reflection to set it if needed
                                                                              
                                                                              // Call close()
                                                                              stream.close();
                                                                              
                                                                              // Verify finish() was called by checking its side effects
                                                                              // Since finish() is supposed to set finished=true, we can verify that
                                                                              // Note: This assumes finish() sets finished=true
                                                                              // If we can't access finished directly, we need another way
                                                                              
                                                                              // Alternative verification: Mock finish() and verify it was called
                                                                              // Since we can't mock partial objects, we'll need to spy on real object
                                                                              CpioArchiveOutputStream spyStream = spy(stream);
                                                                              doNothing().when(spyStream).finish();
                                                                              
                                                                              spyStream.close();
                                                                              verify(spyStream).finish();
                                                                              
                                                                              // Also verify super.close() was called through mock OutputStream
                                                                              verify(mockOut).close();
                                                                          }

    @Test
                                                                          public void testCloseCallsFinishAndUpdatesState() throws Exception {
                                                                              // Create mock OutputStream
                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                              
                                                                              // Create real stream instance
                                                                              CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                              
                                                                              // Call close()
                                                                              stream.close();
                                                                              
                                                                              // Use reflection to verify internal state
                                                                              Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
                                                                              finishedField.setAccessible(true);
                                                                              boolean finished = finishedField.getBoolean(stream);
                                                                              
                                                                              Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                              closedField.setAccessible(true);
                                                                              boolean closed = closedField.getBoolean(stream);
                                                                              
                                                                              // Assert that both flags are set
                                                                              assertTrue("finished should be true after close", finished);
                                                                              assertTrue("closed should be true after close", closed);
                                                                              
                                                                              // Verify output stream was closed
                                                                              verify(mockOut).close();
                                                                          }

    @Test
                                                                public void testCloseShouldCallFinishExactlyOnce1() throws Exception {
                                                                    // Arrange
                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                    CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                    
                                                                    // Use reflection to set the closed field to false
                                                                    Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                    closedField.setAccessible(true);
                                                                    closedField.set(stream, false);
                                                                    
                                                                    // Spy on the stream to verify finish() calls
                                                                    CpioArchiveOutputStream spyStream = spy(stream);
                                                                    
                                                                    // Act
                                                                    spyStream.close();
                                                                    
                                                                    // Assert
                                                                    verify(spyStream, times(1)).finish(); // Should be called exactly once
                                                                    
                                                                    // Verify closed field is true using reflection
                                                                    assertTrue((boolean) closedField.get(spyStream));
                                                                    
                                                                    // Verify parent close was called
                                                                    verify(spyStream).close();
                                                                }

    @Test
                                                                public void testCloseShouldCallSuperClose3() throws Exception {
                                                                    // Arrange
                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                    CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                    
                                                                    // Ensure the stream isn't already closed
                                                                    // (Assuming closed starts as false, but we can force it if needed)
                                                                    
                                                                    // Act
                                                                    stream.close();
                                                                    
                                                                    // Assert
                                                                    // Verify that the underlying OutputStream's close was called
                                                                    // This would happen through super.close() in the original code
                                                                    verify(mockOut).close();
                                                                    
                                                                    // Also verify the closed flag is set (though this isn't the main point)
                                                                    // This would require reflection to check the private field
                                                                    // But the key assertion is the verify above
                                                                }

    @Test
                                                          public void testCloseShouldCallSuperCloseExactlyOnce1() throws Exception {
                                                              // Create a mock OutputStream to track close calls
                                                              OutputStream mockOut = mock(OutputStream.class);
                                                              
                                                              // Create the CpioArchiveOutputStream with our mock
                                                              CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                              
                                                              // Use reflection to set closed field to false
                                                              Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                              closedField.setAccessible(true);
                                                              closedField.set(stream, false);
                                                              
                                                              // Call the close method
                                                              stream.close();
                                                              
                                                              // Verify super.close() was called exactly once
                                                              verify(mockOut, times(1)).close();
                                                              
                                                              // Additional assertions to ensure proper state
                                                              assertTrue((boolean) closedField.get(stream));
                                                          }

    @Test
                                                     public void testCloseSetsClosedFlagCorrectly1() throws Exception {
                                                         // Create a real output stream (we'll use ByteArrayOutputStream since it's simple)
                                                         OutputStream mockOut = new ByteArrayOutputStream();
                                                         
                                                         // Create the CpioArchiveOutputStream instance
                                                         CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                         
                                                         // Get the closed field via reflection
                                                         Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                         closedField.setAccessible(true);
                                                         
                                                         // Verify initial state is not closed
                                                         assertFalse((boolean) closedField.get(stream));
                                                         
                                                         // First close call - should set closed to true
                                                         stream.close();
                                                         assertTrue("After first close(), closed should be true", (boolean) closedField.get(stream));
                                                         
                                                         // Second close call - should keep closed as true (mutant would toggle it back to false)
                                                         stream.close();
                                                         assertTrue("After second close(), closed should remain true", (boolean) closedField.get(stream));
                                                         
                                                         // Additional verification that parent close was called (optional)
                                                         // This would typically require mocking the parent class, but since we're using
                                                         // a real output stream, we can verify it was closed by checking operations
                                                         try {
                                                             stream.write(1); // Should throw IOException as stream is closed
                                                             fail("Should have thrown IOException after close");
                                                         } catch (IOException expected) {
                                                             // Expected behavior
                                                         }
                                                     }

    @Test
                                                public void testCloseCallsFinishWhenNotClosed1() throws Exception {
                                                    // Create a real output stream to wrap (we'll use a ByteArrayOutputStream)
                                                    OutputStream mockOut = new ByteArrayOutputStream();
                                                    
                                                    // Create a spy of the CpioArchiveOutputStream so we can verify finish() is called
                                                    CpioArchiveOutputStream stream = spy(new CpioArchiveOutputStream(mockOut));
                                                    
                                                    // Call the close method
                                                    stream.close();
                                                    
                                                    // Verify that finish() was called exactly once
                                                    verify(stream, times(1)).finish();
                                                    
                                                    // Verify the stream is now closed by attempting an operation that should fail
                                                    try {
                                                        stream.putNextEntry(new CpioArchiveEntry("test"));
                                                        fail("Should have thrown IOException as stream should be closed");
                                                    } catch (IOException expected) {
                                                        // expected behavior
                                                    }
                                                    
                                                    // Verify parent stream was closed by checking mockOut
                                                    try {
                                                        mockOut.write(0);
                                                        fail("Underlying stream should be closed");
                                                    } catch (IOException expected) {
                                                        // expected behavior
                                                    }
                                                }

    @Test
                                           public void testCloseShouldCallSuperClose4() throws Exception {
                                               // Create a mock OutputStream that will be wrapped by CpioArchiveOutputStream
                                               OutputStream mockOut = mock(OutputStream.class);
                                               
                                               // Create the CpioArchiveOutputStream with the mock
                                               CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                               
                                               // Get the closed field via reflection
                                               Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                               closedField.setAccessible(true);
                                               
                                               // Ensure the stream isn't closed initially
                                               assertFalse((boolean) closedField.get(stream));
                                               
                                               // Call the close method we're testing
                                               stream.close();
                                               
                                               // Verify that the stream is now marked as closed
                                               assertTrue((boolean) closedField.get(stream));
                                               
                                               // Verify that the underlying OutputStream's close() was called
                                               verify(mockOut).close();
                                               
                                               // Get the finished field via reflection
                                               Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
                                               finishedField.setAccessible(true);
                                               
                                               // Verify that finish() was called (which should set finished to true)
                                               assertTrue((boolean) finishedField.get(stream));
                                           }

    @Test
                                      public void testCloseCallsFinish1() throws Exception {
                                          // Arrange
                                          OutputStream mockOut = mock(OutputStream.class);
                                          CpioArchiveOutputStream spyStream = spy(new CpioArchiveOutputStream(mockOut));
                                          
                                          // Act
                                          spyStream.close();
                                          
                                          // Assert
                                          verify(spyStream).finish();
                                          verify(mockOut).close();
                                          
                                          // Check closed flag using reflection
                                          Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                          closedField.setAccessible(true);
                                          assertTrue((boolean) closedField.get(spyStream));
                                      }

    @Test
                                  public void testCloseCallsFinish2() throws Exception {
                                      // Arrange
                                      OutputStream mockOut = mock(OutputStream.class);
                                      CpioArchiveOutputStream spyStream = spy(new CpioArchiveOutputStream(mockOut));
                                      
                                      // Use reflection to access and modify the private closed field
                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                      closedField.setAccessible(true);
                                      closedField.setBoolean(spyStream, false); // Set closed to false to enter the if block
                                      
                                      // Act
                                      spyStream.close();
                                      
                                      // Assert
                                      // Verify finish() was called exactly once during close
                                      verify(spyStream, times(1)).finish();
                                      // Verify super.close() was called
                                      verify(spyStream, times(1)).close();
                                      // Verify closed flag was set through reflection
                                      assertTrue(closedField.getBoolean(spyStream));
                                  }

    @Test
                             public void testCloseShouldCallFinishExactlyOnce2() throws Exception {
                                 // Create a spy of the class to track method calls
                                 OutputStream mockOut = mock(OutputStream.class);
                                 CpioArchiveOutputStream spyStream = spy(new CpioArchiveOutputStream(mockOut));
                                 
                                 // Use reflection to access and modify the private closed field
                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                 closedField.setAccessible(true);
                                 closedField.setBoolean(spyStream, false);
                                 
                                 // Mock the finish method to track calls
                                 doNothing().when(spyStream).finish();
                                 
                                 // Perform the close operation
                                 spyStream.close();
                                 
                                 // Verify finish was called exactly once
                                 verify(spyStream, times(1)).finish();
                                 
                                 // Verify the rest of the close operation proceeded normally
                                 verify(mockOut).close(); // Verify underlying stream was closed
                                 assertTrue(closedField.getBoolean(spyStream)); // Verify closed flag was set
                                 
                                 // Additional verification that close is idempotent
                                 spyStream.close();
                                 verify(spyStream, times(1)).finish(); // finish() should still only be called once
                             }

    @Test
                        public void testClose_CallsSuperCloseWhenNotClosed() throws Exception {
                            // Create a mock OutputStream to verify close() is called
                            OutputStream mockOut = mock(OutputStream.class);
                            
                            // Create the CpioArchiveOutputStream with our mock
                            CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                            
                            // Get the closed field via reflection
                            Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                            closedField.setAccessible(true);
                            
                            // Ensure the stream is not closed initially
                            assertFalse(closedField.getBoolean(stream));
                            
                            // Close the stream
                            stream.close();
                            
                            // Verify the parent's close was called exactly once
                            verify(mockOut, times(1)).close();
                            
                            // Verify the closed flag is set
                            assertTrue(closedField.getBoolean(stream));
                        }

    @Test
                   public void testCloseShouldCallSuperCloseExactlyOnce2() throws Exception {
                       // Create a mock OutputStream to pass to constructor
                       OutputStream mockOut = mock(OutputStream.class);
                       
                       // Create a spy of FilterOutputStream to track close calls
                       FilterOutputStream spyFilterOut = spy(new FilterOutputStream(mockOut));
                       
                       // Create the CpioArchiveOutputStream with our spy
                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(spyFilterOut);
                       
                       // Use reflection to set closed field to false
                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                       closedField.setAccessible(true);
                       closedField.set(stream, false);
                       
                       // Call the close method
                       stream.close();
                       
                       // Verify super.close() was called exactly once
                       verify(spyFilterOut, times(1)).close();
                       
                       // Verify closed flag was set using reflection
                       assertTrue((boolean) closedField.get(stream));
                   }

    @Test
              public void testCloseSetsClosedFlagAndIdempotent() throws Exception {
                  // Create a real output stream (we can use ByteArrayOutputStream since we're testing state, not I/O)
                  OutputStream mockOut = new ByteArrayOutputStream();
                  
                  // Create the CpioArchiveOutputStream (starts with closed=false)
                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                  
                  // Get the closed field using reflection
                  Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                  closedField.setAccessible(true);
                  
                  // First close - should set closed to true
                  stream.close();
                  assertTrue("Stream should be closed after first close()", 
                      (boolean) closedField.get(stream));
                  
                  // Second close - should keep closed as true (mutant would toggle it back to false)
                  stream.close();
                  assertTrue("Stream should remain closed after second close()", 
                      (boolean) closedField.get(stream));
                  
                  // Verify finish() and super.close() were called exactly once each
                  // (Note: This requires mocking or spying if we want to verify exact calls)
              }

    @Test
         public void testClose_CallsFinishWhenNotClosed() throws Exception {
             // Create a mock output stream
             OutputStream mockOut = mock(OutputStream.class);
             
             // Create a CpioArchiveOutputStream that isn't closed
             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
             
             // Use reflection to verify it's not closed initially
             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
             closedField.setAccessible(true);
             assertFalse(closedField.getBoolean(stream));
             
             // Spy on the stream to verify finish() is called
             CpioArchiveOutputStream spyStream = spy(stream);
             
             // Close the stream
             spyStream.close();
             
             // Verify finish() was called exactly once
             verify(spyStream, times(1)).finish();
             
             // Verify the stream is now marked as closed using reflection
             assertTrue(closedField.getBoolean(spyStream));
             
             // Verify the underlying stream was closed
             verify(mockOut).close();
             
             // Verify the finished flag is set (important for catching the mutant)
             Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
             finishedField.setAccessible(true);
             assertTrue(finishedField.getBoolean(spyStream));
         }

    @Test
    public void testCloseShouldCallSuperClose5() throws Exception {
        // Create a mock OutputStream to verify close() is called
        OutputStream mockOut = mock(OutputStream.class);
        
        // Create our stream with the mock output
        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
        
        // Get the private closed field via reflection
        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
        closedField.setAccessible(true);
        
        // Ensure initial state is not closed
        assertFalse(closedField.getBoolean(stream));
        
        // Call close() - should propagate to super.close()
        stream.close();
        
        // Verify the mock's close() was called exactly once
        verify(mockOut, times(1)).close();
        
        // Verify the closed flag was set
        assertTrue(closedField.getBoolean(stream));
    }


}
