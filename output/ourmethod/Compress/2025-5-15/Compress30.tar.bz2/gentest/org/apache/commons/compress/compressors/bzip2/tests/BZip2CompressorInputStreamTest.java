package gentest.org.apache.commons.compress.compressors.bzip2.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.compressors.bzip2.*;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.compress.compressors.CompressorInputStream;
 
public class BZip2CompressorInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_WhenStreamClosed_ThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                                                                          bzStream.close(); // This should set in = null
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          // Expect exception
                                                                                                                                                                                                                                                                                                                                                                                          thrown.expect(IOException.class);
                                                                                                                                                                                                                                                                                                                                                                                          thrown.expectMessage("stream closed");
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          // Act
                                                                                                                                                                                                                                                                                                                                                                                          bzStream.read();
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_WhenStreamNeverInitialized_ThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          // Expect exception
                                                                                                                                                                                                                                                                                                                                                                                          thrown.expect(IOException.class);
                                                                                                                                                                                                                                                                                                                                                                                          thrown.expectMessage("stream closed");
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          // Act
                                                                                                                                                                                                                                                                                                                                                                                          bzStream.read();
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_ZeroLength() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 0);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, result);
                                                                                                                                                                                                                                                                                                                                                                                          verify(mockInput, never()).read();
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_SuccessfulRead() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                          when(mockInput.read()).thenReturn(65, 66, 67, -1);
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 2, 4);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(3, result);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[0]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[1]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(65, dest[2]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(66, dest[3]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(67, dest[4]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[5]);
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_NoDataAvailable() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                          when(mockInput.read()).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(-1, result);
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_PartialRead() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                          when(mockInput.read()).thenReturn(65, 66, -1);
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(2, result);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(65, dest[0]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(66, dest[1]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(0, dest[2]);
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                      public void testRead_ExactlyFillsBuffer() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                          when(mockInput.read()).thenReturn(65, 66, 67, 68, 69, -1);
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[5];
                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                          int result = stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(5, result);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(65, dest[0]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(66, dest[1]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(67, dest[2]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(68, dest[3]);
                                                                                                                                                                                                                                                                                                                                                                                          assertEquals(69, dest[4]);
                                                                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                                                              public void testRead_WhenRead0ThrowsIOException_PropagatesException() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                  // Arrange
                                                                                                                                                                                                                                                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                                                                  when(mockInputStream.read()).thenThrow(new IOException("read error"));
                                                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                  // Expect exception
                                                                                                                                                                                                                                                                                                                                                                                  thrown.expect(IOException.class);
                                                                                                                                                                                                                                                                                                                                                                                  thrown.expectMessage("read error");
                                                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                  // Act
                                                                                                                                                                                                                                                                                                                                                                                  bzStream.read();
                                                                                                                                                                                                                                                                                                                                                                              }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                                                                                                                                              public void testRead_OffsetPlusLengthExceedsDestLength() throws IOException {
                                                                                                                                                                                                                                                                                                                                                                                  InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                                                                                                                                      stream.read(dest, 5, 6);
                                                                                                                                                                                                                                                                                                                                                                                      fail("Expected IndexOutOfBoundsException");
                                                                                                                                                                                                                                                                                                                                                                                  } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                                                                                                                                      assertEquals("offs(5) + len(6) > dest.length(10).", e.getMessage());
                                                                                                                                                                                                                                                                                                                                                                                      throw e;
                                                                                                                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                                                                      public void testRead_WhenStreamOpenAndRead0ReturnsPositive() throws Exception {
                                                                                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Use reflection to mock the private read0() method behavior
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream spyBzStream = spy(bzStream);
                                                                                                                                                                                                                                                                                                                                          Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                                                                                                                          read0Method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                          when(read0Method.invoke(spyBzStream)).thenReturn(42);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Act
                                                                                                                                                                                                                                                                                                                                          int result = spyBzStream.read();
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Assert
                                                                                                                                                                                                                                                                                                                                          assertEquals(42, result);
                                                                                                                                                                                                                                                                                                                                          // Verify the stream is still open by checking the private 'in' field using reflection
                                                                                                                                                                                                                                                                                                                                          Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                                                                                                                                                                                          inField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                          InputStream internalStream = (InputStream) inField.get(spyBzStream);
                                                                                                                                                                                                                                                                                                                                          assertNotNull(internalStream);
                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                      public void testRead_WhenStreamOpenAndRead0ReturnsNegative() throws Exception {
                                                                                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Use reflection to mock read0() behavior
                                                                                                                                                                                                                                                                                                                                          Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                                                                                                                          read0Method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream spyBzStream = spy(bzStream);
                                                                                                                                                                                                                                                                                                                                          when(read0Method.invoke(spyBzStream)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Act
                                                                                                                                                                                                                                                                                                                                          int result = spyBzStream.read();
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Assert
                                                                                                                                                                                                                                                                                                                                          assertEquals(-1, result);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Note: Removed verification of protected count() method as it's not directly verifiable
                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                      public void testRead_WhenCountThrowsRuntimeException_PropagatesException() throws Exception {
                                                                                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream bzStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Use reflection to access private read0() method
                                                                                                                                                                                                                                                                                                                                          Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                                                                                                                          read0Method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Mock read0() to return valid value
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream spyBzStream = spy(bzStream);
                                                                                                                                                                                                                                                                                                                                          when(read0Method.invoke(spyBzStream)).thenReturn(10);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Use reflection to access protected count() method
                                                                                                                                                                                                                                                                                                                                          Method countMethod = CompressorInputStream.class.getDeclaredMethod("count", long.class);
                                                                                                                                                                                                                                                                                                                                          countMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Mock count() to throw exception when called through reflection
                                                                                                                                                                                                                                                                                                                                          doAnswer(invocation -> {
                                                                                                                                                                                                                                                                                                                                              throw new RuntimeException("count error");
                                                                                                                                                                                                                                                                                                                                          }).when(spyBzStream).read();
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Expect exception
                                                                                                                                                                                                                                                                                                                                          thrown.expect(RuntimeException.class);
                                                                                                                                                                                                                                                                                                                                          thrown.expectMessage("count error");
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Act
                                                                                                                                                                                                                                                                                                                                          spyBzStream.read();
                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                      public void testRead_NegativeOffset() throws IOException {
                                                                                                                                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          // Exception verification
                                                                                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                                                                                              stream.read(dest, -1, 5);
                                                                                                                                                                                                                                                                                                                                              fail("Expected IndexOutOfBoundsException");
                                                                                                                                                                                                                                                                                                                                          } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                                                                                              assertEquals("offs(-1) < 0.", e.getMessage());
                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                                                                                                                      public void testRead_NegativeLength() throws IOException {
                                                                                                                                                                                                                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                                                                                              stream.read(dest, 0, -1);
                                                                                                                                                                                                                                                                                                                                              fail("Expected IndexOutOfBoundsException");
                                                                                                                                                                                                                                                                                                                                          } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                                                                                              assertEquals("len(-1) < 0.", e.getMessage());
                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                                             public void testReadWhenStreamIsNull() throws IOException {
                                                                                                                                                                                                                                                                                                 // Create stream with null input (closed stream case)
                                                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // This should throw IOException in original, but mutated version would try to read
                                                                                                                                                                                                                                                                                                 bzip2Stream.read();
                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                             public void testReadWhenStreamIsNotNull() throws IOException {
                                                                                                                                                                                                                                                                                                 // Setup mock input stream
                                                                                                                                                                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                 when(mockInputStream.read()).thenReturn(42);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Create BZip2 stream with mock input
                                                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Test read() which internally calls read0()
                                                                                                                                                                                                                                                                                                 int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                                                 assertEquals(42, result);
                                                                                                                                                                                                                                                                                             }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                                             public void testReadThrowsIOExceptionWhenStreamClosed() throws IOException {
                                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                                 InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                                                                 byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                 bzip2Stream.close(); // This should set in to null
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Act
                                                                                                                                                                                                                                                                                                 // This should throw IOException with "stream closed" in original code
                                                                                                                                                                                                                                                                                                 // Mutant would not throw exception here
                                                                                                                                                                                                                                                                                                 bzip2Stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                             public void testReadDoesNotThrowWhenStreamOpen() throws IOException {
                                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                                 byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                                 when(mockInputStream.read()).thenReturn(-1); // Simulate EOF
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Act
                                                                                                                                                                                                                                                                                                 // Original code should work fine here
                                                                                                                                                                                                                                                                                                 // Mutant would throw exception here (wrong behavior)
                                                                                                                                                                                                                                                                                                 int result = bzip2Stream.read(dest, 0, 5);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Assert
                                                                                                                                                                                                                                                                                                 assertEquals(-1, result); // Verify EOF handling
                                                                                                                                                                                                                                                                                             }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                                         public void testReadWithNullStreamThrowsIOException() throws IOException {
                                                                                                                                                                                                                                                                                             // Create an instance with null input stream
                                                                                                                                                                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // This should throw IOException with "stream closed" message
                                                                                                                                                                                                                                                                                             // If the mutant is present, it will either:
                                                                                                                                                                                                                                                                                             // 1. Not throw any exception (if read0() handles null)
                                                                                                                                                                                                                                                                                             // 2. Throw NullPointerException (if read0() doesn't handle null)
                                                                                                                                                                                                                                                                                             bzIn.read();
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // The test will fail if no exception is thrown (mutant case)
                                                                                                                                                                                                                                                                                             // or if wrong exception is thrown (also mutant case)
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testReadWithNonNullInputStream() throws IOException {
                                                                                                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                             int offs = 0;
                                                                                                                                                                                                                                                                                             int len = 5;
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Create a mock input stream that will return some data
                                                                                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                                             when(mockInputStream.read()).thenReturn(65, 66, 67, -1); // Return A,B,C then EOF
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Create the compressor stream with our mock input
                                                                                                                                                                                                                                                                                             BZip2CompressorInputStream compressorStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Act and Assert
                                                                                                                                                                                                                                                                                             // With original code, this should read successfully
                                                                                                                                                                                                                                                                                             // With mutated code (if(true)), this will throw IOException
                                                                                                                                                                                                                                                                                             int bytesRead = compressorStream.read(dest, offs, len);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Verify we read 3 bytes (A,B,C)
                                                                                                                                                                                                                                                                                             assertEquals(3, bytesRead);
                                                                                                                                                                                                                                                                                             assertEquals('A', dest[0]);
                                                                                                                                                                                                                                                                                             assertEquals('B', dest[1]);
                                                                                                                                                                                                                                                                                             assertEquals('C', dest[2]);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Verify we interacted with the mock input stream
                                                                                                                                                                                                                                                                                             verify(mockInputStream, times(4)).read(); // 3 bytes + EOF check
                                                                                                                                                                                                                                                                                         }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                                        public void testReadThrowsIOExceptionWhenStreamClosed1() throws IOException {
                                                                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                                                                            BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                            // Use reflection to set the private 'in' field to null to simulate closed stream
                                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                                Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                                                                                                                                                inField.setAccessible(true);
                                                                                                                                                                                                                                                                                                inField.set(stream, null);
                                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                                fail("Failed to set up test via reflection");
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Act & Assert
                                                                                                                                                                                                                                                                                            // This should throw IOException with "stream closed" message
                                                                                                                                                                                                                                                                                            // If the mutant is present, this will either not throw an exception
                                                                                                                                                                                                                                                                                            // or throw a different exception (like NullPointerException)
                                                                                                                                                                                                                                                                                            stream.read(dest, 0, 1);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                       public void testReadThrowsIOExceptionWhenStreamIsNull() throws Exception {
                                                                                                                                                                                                                                                                                           // Setup - create stream with null input
                                                                                                                                                                                                                                                                                           InputStream nullStream = null;
                                                                                                                                                                                                                                                                                           BZip2CompressorInputStream stream = new BZip2CompressorInputStream(nullStream);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                                                               // Execute
                                                                                                                                                                                                                                                                                               stream.read();
                                                                                                                                                                                                                                                                                               fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                                                                           } catch (IOException e) {
                                                                                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                                                                                               assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Note: The mutant would not throw the exception here, causing the test to fail
                                                                                                                                                                                                                                                                                           // and thus detecting the mutant
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testReadThrowsCorrectExceptionWhenStreamClosed() throws Exception {
                                                                                                                                                                                                                                                                                           // Prepare test data
                                                                                                                                                                                                                                                                                           byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                           int offs = 0;
                                                                                                                                                                                                                                                                                           int len = 5;
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Set expectation for the exception
                                                                                                                                                                                                                                                                                           thrown.expect(IOException.class);
                                                                                                                                                                                                                                                                                           thrown.expectMessage("stream closed");
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Create instance with null stream (simulating closed stream)
                                                                                                                                                                                                                                                                                           BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           // Call method that should throw
                                                                                                                                                                                                                                                                                           stream.read(dest, offs, len);
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                  public void testReadWhenStreamClosedThrowsCorrectException() throws IOException {
                                                                                                                                                                                                                                                                                      // Prepare
                                                                                                                                                                                                                                                                                      InputStream nullInputStream = null;
                                                                                                                                                                                                                                                                                      BZip2CompressorInputStream stream = new BZip2CompressorInputStream(nullInputStream);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Execute and Verify
                                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                                          stream.read();
                                                                                                                                                                                                                                                                                          fail("Expected IOException");
                                                                                                                                                                                                                                                                                      } catch (IOException e) {
                                                                                                                                                                                                                                                                                          assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                  }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                              public void testReadWhenStreamClosedThrowsIOException() throws Exception {
                                                                                                                                                                                                                                                                                  // Create a BZip2CompressorInputStream with null input stream to simulate closed state
                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                                                      // This should throw IOException with "stream closed" message
                                                                                                                                                                                                                                                                                      bzIn.read();
                                                                                                                                                                                                                                                                                  } catch (IOException e) {
                                                                                                                                                                                                                                                                                      // Additional verification of the exception message
                                                                                                                                                                                                                                                                                      assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                                                                                      throw e;
                                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                                              }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                              public void testReadThrowsIOExceptionWhenStreamClosed2() throws Exception {
                                                                                                                                                                                                                                                                                  // Arrange
                                                                                                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                  int offs = 0;
                                                                                                                                                                                                                                                                                  int len = 5;
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Create instance with null input stream to simulate closed stream
                                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Act - should throw IOException
                                                                                                                                                                                                                                                                                  bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                  // Assertion is handled by the expected exception in the @Test annotation
                                                                                                                                                                                                                                                                                  // If NullPointerException is thrown instead, the test will fail
                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                 public void testReadWhenStreamClosedThrowsException() throws IOException {
                                                                                                                                                                                                                                                                                     // Create an instance with null input stream to simulate closed stream
                                                                                                                                                                                                                                                                                     BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream((InputStream) null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Set expectation for the exception
                                                                                                                                                                                                                                                                                     thrown.expect(IOException.class);
                                                                                                                                                                                                                                                                                     thrown.expectMessage("stream closed");
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Call the method that should throw
                                                                                                                                                                                                                                                                                     bzIn.read();
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // If we reach here, the test fails because no exception was thrown
                                                                                                                                                                                                                                                                                     // The mutant would return -1 instead of throwing exception
                                                                                                                                                                                                                                                                                 }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                             public void testReadThrowsIOExceptionWhenStreamClosed3() throws Exception {
                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                 byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                 int offs = 0;
                                                                                                                                                                                                                                                                                 int len = 5;
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Create stream with null input to simulate closed stream
                                                                                                                                                                                                                                                                                 BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Act - should throw IOException
                                                                                                                                                                                                                                                                                 stream.read(dest, offs, len);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Assert - handled by expected exception
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                            public void testReadThrowsIOExceptionWhenStreamClosed4() throws IOException {
                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                                int offs = 0;
                                                                                                                                                                                                                                                                                int len = 5;
                                                                                                                                                                                                                                                                                BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                                                                    stream.read(dest, offs, len);
                                                                                                                                                                                                                                                                                    fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                                                                } catch (IOException e) {
                                                                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                                                                    assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                        public void testReadWithZeroLengthShouldReturnImmediately() throws IOException {
                                                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                            int offs = 0;
                                                                                                                                                                                                                                                                            int len = 0;
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Mock the InputStream to verify no reads occur
                                                                                                                                                                                                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                                                                            int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                                                                            assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                                                                                                                                                            verify(mockInputStream, never()).read(); // Verify no actual read occurred
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                       public void testReadWithZeroLength() throws IOException {
                                                                                                                                                                                                                                                                           // Create mock InputStream that returns test data
                                                                                                                                                                                                                                                                           InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                                                                                           when(mockIn.read()).thenReturn(0, 42, -1);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Create instance of BZip2CompressorInputStream with mock stream
                                                                                                                                                                                                                                                                           BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test zero-length read
                                                                                                                                                                                                                                                                           int result = bzIn.read();
                                                                                                                                                                                                                                                                           assertEquals(0, result);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test non-zero length read
                                                                                                                                                                                                                                                                           result = bzIn.read();
                                                                                                                                                                                                                                                                           assertEquals(42, result);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test EOF case
                                                                                                                                                                                                                                                                           result = bzIn.read();
                                                                                                                                                                                                                                                                           assertEquals(-1, result);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test closed stream case
                                                                                                                                                                                                                                                                           BZip2CompressorInputStream closedBzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                                               closedBzIn.read();
                                                                                                                                                                                                                                                                               fail("Expected IOException");
                                                                                                                                                                                                                                                                           } catch (IOException e) {
                                                                                                                                                                                                                                                                               assertEquals("stream closed", e.getMessage());
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                       }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                       public void testReadWithClosedStream() throws IOException {
                                                                                                                                                                                                                                                                           // Create stream with null input to simulate closed stream
                                                                                                                                                                                                                                                                           BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                           closedStream.read(); // Should throw IOException
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                   public void testReadWithZeroLengthShouldReturnZeroWithoutReading() throws Exception {
                                                                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                       int offs = 0;
                                                                                                                                                                                                                                                                       int len = 0;  // This is the key test case
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                                                                       int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                                                                       assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                                                                                                                                                       verifyZeroInteractions(mockInputStream);  // Ensure no read attempts were made
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                  public void testReadWithEmptyStream() throws IOException {
                                                                                                                                                                                                                                                                      // Create mock InputStream
                                                                                                                                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                      // Mock read() behavior to simulate empty stream
                                                                                                                                                                                                                                                                      when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Create BZip2CompressorInputStream with mock
                                                                                                                                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // The method should return -1 for EOF and count -1
                                                                                                                                                                                                                                                                      int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      assertEquals("Should return -1 for EOF", -1, result);
                                                                                                                                                                                                                                                                      // Verify the count was updated with -1 (would need access to count variable or verify via side effects)
                                                                                                                                                                                                                                                                      // This part would depend on how count() is implemented
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testReadWithZeroLengthData() throws IOException {
                                                                                                                                                                                                                                                                      // Create mock InputStream
                                                                                                                                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                      // Create BZip2CompressorInputStream with mock
                                                                                                                                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Mock read0() behavior through the actual stream's read method
                                                                                                                                                                                                                                                                      when(mockInputStream.read())
                                                                                                                                                                                                                                                                          .thenReturn(0)    // Simulate read of zero bytes
                                                                                                                                                                                                                                                                          .thenReturn(-1);  // Then EOF
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // First read should handle zero-length case properly
                                                                                                                                                                                                                                                                      int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify the result
                                                                                                                                                                                                                                                                      assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // If we need to verify count was updated, we would need reflection
                                                                                                                                                                                                                                                                      // But since count is private and not exposed, we can't verify it directly
                                                                                                                                                                                                                                                                      // without breaking encapsulation
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testReadWithValidData() throws IOException {
                                                                                                                                                                                                                                                                      // Create mock InputStream
                                                                                                                                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                      // Mock read() to return valid data
                                                                                                                                                                                                                                                                      when(mockInputStream.read()).thenReturn(65); // 'A'
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Create BZip2CompressorInputStream with mock
                                                                                                                                                                                                                                                                      BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      assertEquals("Should return valid data", 65, result);
                                                                                                                                                                                                                                                                      // Verify count was updated with 1
                                                                                                                                                                                                                                                                  }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                  public void testReadThrowsExceptionWhenStreamClosed() throws IOException {
                                                                                                                                                                                                                                                                      // Create stream with null input
                                                                                                                                                                                                                                                                      BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // This should throw IOException
                                                                                                                                                                                                                                                                      closedStream.read();
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                              public void testReadWithZeroLengthShouldReturnZero() throws IOException {
                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Test len=0 case (should return 0, but mutant would throw exception)
                                                                                                                                                                                                                                                                  int result = bzIn.read(dest, 0, 0);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                  assertEquals("Should return 0 when length is 0", 0, result);
                                                                                                                                                                                                                                                              }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                              public void testReadWithNegativeLengthShouldThrowException() throws IOException {
                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Test len=-1 case (should throw exception, but mutant would return 0)
                                                                                                                                                                                                                                                                  bzIn.read(dest, 0, -1);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                             public void testReadHandlesNegativeLengthCorrectly() throws IOException {
                                                                                                                                                                                                                                                                 // Setup mock InputStream
                                                                                                                                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                 // Setup mock to return -2 (negative length, not EOF)
                                                                                                                                                                                                                                                                 when(mockInputStream.read()).thenReturn(-2);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Create BZip2 stream with mock input
                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Call the read method
                                                                                                                                                                                                                                                                 int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Verify the count was properly handled (should be -1 for original, might be different for mutant)
                                                                                                                                                                                                                                                                 assertEquals(-2, result);
                                                                                                                                                                                                                                                                 // We would need to verify the count() method was called with -1
                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                             public void testReadHandlesEOFCorrectly() throws IOException {
                                                                                                                                                                                                                                                                 // Setup mock InputStream
                                                                                                                                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                 // Setup mock to return -1 (EOF)
                                                                                                                                                                                                                                                                 when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Create BZip2 stream with mock input
                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Call the read method
                                                                                                                                                                                                                                                                 int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Verify the count was properly handled (should be -1)
                                                                                                                                                                                                                                                                 assertEquals(-1, result);
                                                                                                                                                                                                                                                                 // Verify count() was called with -1
                                                                                                                                                                                                                                                                 // Note: Since count() appears to be a private method, we can't verify it directly
                                                                                                                                                                                                                                                                 // without reflection, but the main behavior (returning -1) is verified
                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                             public void testReadHandlesPositiveLengthCorrectly() throws IOException {
                                                                                                                                                                                                                                                                 // Setup mock InputStream
                                                                                                                                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                                 // Setup mock to return 5 (positive length)
                                                                                                                                                                                                                                                                 when(mockInputStream.read()).thenReturn(5);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Create BZip2CompressorInputStream with mock
                                                                                                                                                                                                                                                                 BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Call the read method
                                                                                                                                                                                                                                                                 int result = bzip2Stream.read();
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 // Verify the result was properly handled (should be 5)
                                                                                                                                                                                                                                                                 assertEquals(5, result);
                                                                                                                                                                                                                                                                 // Verify count() was called with 1 (though count is private and would need reflection to verify)
                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                         public void testReadHandlesZeroLengthCorrectly() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                             // Setup mock to return -1 (EOF)
                                                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                             when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create BZip2 stream with mock input
                                                                                                                                                                                                                                                             BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Call the read method
                                                                                                                                                                                                                                                             int result = bzip2Stream.read();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify we got EOF (-1)
                                                                                                                                                                                                                                                             assertEquals(-1, result);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify the count was properly set (should be -1 for EOF)
                                                                                                                                                                                                                                                             // Note: Testing count would require reflection since it's private
                                                                                                                                                                                                                                                             Field countField = BZip2CompressorInputStream.class.getDeclaredField("count");
                                                                                                                                                                                                                                                             countField.setAccessible(true);
                                                                                                                                                                                                                                                             long count = countField.getLong(bzip2Stream);
                                                                                                                                                                                                                                                             assertEquals(-1, count);
                                                                                                                                                                                                                                                         }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                         public void testReadWhenStreamClosedThrowsException1() throws IOException {
                                                                                                                                                                                                                                                             // Create stream with null input
                                                                                                                                                                                                                                                             BZip2CompressorInputStream closedStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                             closedStream.read(new byte[10], 0, 5);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                     public void testReadWithNonZeroLengthShouldNotReturnImmediately() throws Exception {
                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                         byte[] dest = new byte[10];
                                                                                                                                                                                                                                                         int offs = 0;
                                                                                                                                                                                                                                                         int len = 5;  // Non-zero length
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Mock the input stream to return some data
                                                                                                                                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                         when(mockInputStream.read()).thenReturn(65);  // Return 'A'
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Create test instance with mock stream
                                                                                                                                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                                                         int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                                         // Original behavior: Should read data and return number of bytes read (1 in this case)
                                                                                                                                                                                                                                                         // Mutant behavior: Will return 0 immediately
                                                                                                                                                                                                                                                         assertNotEquals("Method should not return 0 for non-zero length", 0, result);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Additional verification that read was attempted
                                                                                                                                                                                                                                                         verify(mockInputStream, atLeastOnce()).read();
                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                public void testReadWithZeroLengthShouldNotCount() throws IOException {
                                                                                                                                                                                                                                                    // Create mock input stream and real bzip2 stream
                                                                                                                                                                                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                    BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create a spy to monitor calls
                                                                                                                                                                                                                                                    BZip2CompressorInputStream spyStream = spy(bzip2Stream);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Record initial bytes read count
                                                                                                                                                                                                                                                    long initialCount = spyStream.getBytesRead();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Test with len = 0 (should not count)
                                                                                                                                                                                                                                                    spyStream.read(new byte[10], 0, 0);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify bytes read count didn't change
                                                                                                                                                                                                                                                    assertEquals(initialCount, spyStream.getBytesRead());
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify the underlying read was attempted (indirectly)
                                                                                                                                                                                                                                                    verify(spyStream, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testReadWithNonZeroLengthShouldCount() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                    // Create mock input stream that returns test data
                                                                                                                                                                                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                    when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(1);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create real BZip2CompressorInputStream with mock input
                                                                                                                                                                                                                                                    BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Test with len > 0 (should count)
                                                                                                                                                                                                                                                    bzip2Stream.read(new byte[10], 0, 5);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify count was incremented by checking the protected bytesRead field
                                                                                                                                                                                                                                                    Field bytesReadField = CompressorInputStream.class.getDeclaredField("bytesRead");
                                                                                                                                                                                                                                                    bytesReadField.setAccessible(true);
                                                                                                                                                                                                                                                    long bytesRead = bytesReadField.getLong(bzip2Stream);
                                                                                                                                                                                                                                                    assertEquals(1, bytesRead);
                                                                                                                                                                                                                                                }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                            public void testReadThrowsExceptionWhenStreamClosed1() throws Exception {
                                                                                                                                                                                                                                                // Setup stream with null input
                                                                                                                                                                                                                                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to set in to null since constructor sets it
                                                                                                                                                                                                                                                Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                                                                                                inField.setAccessible(true);
                                                                                                                                                                                                                                                inField.set(bzIn, null);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                bzIn.read();
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testReadWithZeroLengthShouldReturnZero1() throws IOException {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                                byte[] dest = new byte[10];
                                                                                                                                                                                                                                                int offs = 0;
                                                                                                                                                                                                                                                int len = 0;  // Zero length case
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals("When len=0, should return 0", 0, result);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify no interaction with the stream should occur
                                                                                                                                                                                                                                                verifyZeroInteractions(mockInputStream);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                       public void testReadReturnsZeroWhenRead0ReturnsZero() throws Exception {
                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                           BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create a spy and mock the private read0() method using reflection
                                                                                                                                                                                                                                           BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                                                                                                                                                           Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                                                           read0Method.setAccessible(true);
                                                                                                                                                                                                                                           when(read0Method.invoke(spyBzIn)).thenReturn(0);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                           int result = spyBzIn.read();
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                           assertEquals("Should return 0 when read0 returns 0", 0, result);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify count was called with 1 through reflection
                                                                                                                                                                                                                                           Method countMethod = CompressorInputStream.class.getDeclaredMethod("count", long.class);
                                                                                                                                                                                                                                           countMethod.setAccessible(true);
                                                                                                                                                                                                                                           countMethod.invoke(spyBzIn, 1L);
                                                                                                                                                                                                                                           // Can't verify with Mockito since it's protected, but we can verify the side effect
                                                                                                                                                                                                                                           // by checking the bytesRead field if needed
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                   public void testReadWithZeroLengthShouldReturnZeroNotNegativeOne() throws IOException {
                                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Act - call read with len = 0
                                                                                                                                                                                                                                       int result = bzIn.read(dest, 0, 0);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Assert - should return 0, not -1
                                                                                                                                                                                                                                       assertEquals("Zero-length read should return 0", 0, result);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify no interaction with the stream should happen
                                                                                                                                                                                                                                       verifyZeroInteractions(mockInputStream);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                          public void testReadShouldReturnZeroWhenRead0ReturnsZero() throws Exception {
                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Create a spy to observe behavior
                                                                                                                                                                                                              BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Use reflection to access private read0() method
                                                                                                                                                                                                              Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                                                                                              read0Method.setAccessible(true);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Mock the behavior by overriding the method in the spy
                                                                                                                                                                                                              doAnswer(invocation -> {
                                                                                                                                                                                                                  // When read() is called, it will call our implementation which returns 0
                                                                                                                                                                                                                  return 0;
                                                                                                                                                                                                              }).when(spyBzIn).read();
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Act
                                                                                                                                                                                                              int result = spyBzIn.read();
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                              assertEquals("Method should return 0 when read0 returns 0", 0, result);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Verify stream remains open
                                                                                                                                                                                                              Field inField = CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                                                              inField.setAccessible(true);
                                                                                                                                                                                                              assertNotNull("Stream should remain open", inField.get(spyBzIn));
                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                      public void testRead_DetectsReturnLenMutant() throws IOException {
                                                                                                                                                                                                          // Create a mock InputStream
                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Create the BZip2CompressorInputStream with our mock
                                                                                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Mock read0() to return 0 (simulating no data read but not EOF)
                                                                                                                                                                                                          // Note: Since read0() is private, we'll need to mock the InputStream behavior
                                                                                                                                                                                                          // that would cause read0() to return 0
                                                                                                                                                                                                          when(mockInputStream.read()).thenReturn(0);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Call the read method
                                                                                                                                                                                                          int result = bzIn.read();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify it returns 0 (original behavior) and not len (mutant behavior)
                                                                                                                                                                                                          assertEquals("Should return 0 when no data is read", 0, result);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify the count was updated properly (1 for successful read, even if 0 bytes)
                                                                                                                                                                                                          // Note: This assumes count() increments by 1 for non-negative returns
                                                                                                                                                                                                          // We might need to verify internal state or use a spy if count() has visible side effects
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Clean up
                                                                                                                                                                                                          bzIn.close();
                                                                                                                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                                                                                                                      public void testRead_ThrowsWhenStreamClosed() throws IOException {
                                                                                                                                                                                                          // Create BZip2CompressorInputStream with null stream
                                                                                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // This should throw IOException
                                                                                                                                                                                                          bzIn.read();
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testReadWithZeroLengthReturnsZeroNotLen() throws IOException {
                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                                                                                          int offs = 0;
                                                                                                                                                                                                          int len = 0;
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Mock the input stream to verify no reads occur
                                                                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Act
                                                                                                                                                                                                          int result = bzIn.read(dest, offs, len);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Assert
                                                                                                                                                                                                          assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                                                                                          verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Additional check to ensure the mutant would fail
                                                                                                                                                                                                          assertNotEquals("Should not return len (0 in this case)", len, result);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                     public void testReadDetectsHiCalculationMutant() throws IOException {
                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                         byte[] dest = new byte[10];
                                                                                                                                                                                                         int offs = 2;
                                                                                                                                                                                                         int len = 5;
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock input stream to return 3 bytes before EOF
                                                                                                                                                                                                         InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                                         when(mockIn.read()).thenReturn(1, 2, 3, -1);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create test instance with our mock stream
                                                                                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Test - should read 3 bytes into positions 2,3,4
                                                                                                                                                                                                         int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                         assertEquals(3, bytesRead);
                                                                                                                                                                                                         assertEquals(1, dest[2]);
                                                                                                                                                                                                         assertEquals(2, dest[3]);
                                                                                                                                                                                                         assertEquals(3, dest[4]);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Positions outside read range should remain 0
                                                                                                                                                                                                         assertEquals(0, dest[0]);
                                                                                                                                                                                                         assertEquals(0, dest[1]);
                                                                                                                                                                                                         assertEquals(0, dest[5]);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify mock interactions
                                                                                                                                                                                                         verify(mockIn, times(4)).read(); // 3 bytes + EOF
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                    public void testReadWithDifferentOffsetsAndLengths() throws IOException {
                                                                                                                                                                                                        // Setup test data
                                                                                                                                                                                                        byte[] testData = new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                                                                                                                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                            .thenAnswer(invocation -> {
                                                                                                                                                                                                                byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                int off = (Integer) invocation.getArguments()[1];
                                                                                                                                                                                                                int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                                                System.arraycopy(testData, 0, buf, off, len);
                                                                                                                                                                                                                return len;
                                                                                                                                                                                                            });
                                                                                                                                                                                                        
                                                                                                                                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test case 1: Normal read operation
                                                                                                                                                                                                        byte[] dest1 = new byte[10];
                                                                                                                                                                                                        int read1 = bzIn.read(dest1, 2, 5);
                                                                                                                                                                                                        assertEquals(5, read1);
                                                                                                                                                                                                        assertArrayEquals(new byte[]{0, 0, 1, 2, 3, 4, 5, 0, 0, 0}, dest1);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test case 2: Edge case where offs = len
                                                                                                                                                                                                        byte[] dest2 = new byte[10];
                                                                                                                                                                                                        int read2 = bzIn.read(dest2, 5, 5);
                                                                                                                                                                                                        assertEquals(5, read2);
                                                                                                                                                                                                        assertArrayEquals(new byte[]{0, 0, 0, 0, 0, 1, 2, 3, 4, 5}, dest2);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test case 3: Edge case where len > offs (would fail with mutant)
                                                                                                                                                                                                        byte[] dest3 = new byte[10];
                                                                                                                                                                                                        int read3 = bzIn.read(dest3, 2, 8);
                                                                                                                                                                                                        assertEquals(8, read3);
                                                                                                                                                                                                        assertArrayEquals(new byte[]{0, 0, 1, 2, 3, 4, 5, 6, 7, 8}, dest3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test case 4: Read with offset 0
                                                                                                                                                                                                        byte[] dest4 = new byte[10];
                                                                                                                                                                                                        int read4 = bzIn.read(dest4, 0, 10);
                                                                                                                                                                                                        assertEquals(10, read4);
                                                                                                                                                                                                        assertArrayEquals(testData, dest4);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test case 5: Read with small len
                                                                                                                                                                                                        byte[] dest5 = new byte[10];
                                                                                                                                                                                                        int read5 = bzIn.read(dest5, 9, 1);
                                                                                                                                                                                                        assertEquals(1, read5);
                                                                                                                                                                                                        assertArrayEquals(new byte[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, dest5);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test case 6: Read with len = 0
                                                                                                                                                                                                        byte[] dest6 = new byte[10];
                                                                                                                                                                                                        int read6 = bzIn.read(dest6, 5, 0);
                                                                                                                                                                                                        assertEquals(0, read6);
                                                                                                                                                                                                        assertArrayEquals(new byte[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, dest6);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                public void testReadWithMultipleBytesShouldFillBuffer() throws IOException {
                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                    byte[] dest = new byte[10];
                                                                                                                                                                                                    int offs = 2;
                                                                                                                                                                                                    int len = 5;
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Mock input stream to return 3 bytes before EOF
                                                                                                                                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                    when(mockInputStream.read()).thenReturn(65, 66, 67, -1);
                                                                                                                                                                                                    
                                                                                                                                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test
                                                                                                                                                                                                    int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    // Original should read 3 bytes (65,66,67) into positions 2,3,4
                                                                                                                                                                                                    assertEquals(3, bytesRead);
                                                                                                                                                                                                    assertEquals(65, dest[offs]);
                                                                                                                                                                                                    assertEquals(66, dest[offs+1]);
                                                                                                                                                                                                    assertEquals(67, dest[offs+2]);
                                                                                                                                                                                                    assertEquals(0, dest[offs+3]); // Should not be touched
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Mutant would return -1 or 0 since hi=offs and loop won't execute
                                                                                                                                                                                                    // So these assertions would fail with the mutant
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                               public void testReadWithOffsetAndLength() throws IOException {
                                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                                   byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                                   byte[] dest = new byte[10];
                                                                                                                                                                                                   int offset = 2;
                                                                                                                                                                                                   int length = 3;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Mock the input stream to return our test data
                                                                                                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                   when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                       .thenAnswer(invocation -> {
                                                                                                                                                                                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                           int off = (Integer) invocation.getArguments()[1];
                                                                                                                                                                                                           int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                                           System.arraycopy(testData, 0, buf, off, Math.min(len, testData.length));
                                                                                                                                                                                                           return Math.min(len, testData.length);
                                                                                                                                                                                                       });
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create the test object
                                                                                                                                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Perform the read operation
                                                                                                                                                                                                   int bytesRead = bzIn.read(dest, offset, length);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the results
                                                                                                                                                                                                   assertEquals("Should read requested length of bytes", length, bytesRead);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the data was copied to the correct position
                                                                                                                                                                                                   for (int i = 0; i < length; i++) {
                                                                                                                                                                                                       assertEquals("Data should be copied to correct position", 
                                                                                                                                                                                                                  testData[i], dest[offset + i]);
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify nothing was written before the offset
                                                                                                                                                                                                   for (int i = 0; i < offset; i++) {
                                                                                                                                                                                                       assertEquals(0, dest[i]);
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify nothing was written after the copied data
                                                                                                                                                                                                   for (int i = offset + length; i < dest.length; i++) {
                                                                                                                                                                                                       assertEquals(0, dest[i]);
                                                                                                                                                                                                   }
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                           public void testReadWithOffsetDetectsMutant() throws IOException {
                                                                                                                                                                                               // Setup test data with known content
                                                                                                                                                                                               byte[] testData = new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
                                                                                                                                                                                               InputStream inputStream = new ByteArrayInputStream(testData);
                                                                                                                                                                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(inputStream);
                                                                                                                                                                                               
                                                                                                                                                                                               // Test reading with non-zero offset
                                                                                                                                                                                               byte[] dest = new byte[10];
                                                                                                                                                                                               int offset = 3;
                                                                                                                                                                                               int length = 4;
                                                                                                                                                                                               
                                                                                                                                                                                               // Read into destination array starting at offset
                                                                                                                                                                                               int bytesRead = bzIn.read(dest, offset, length);
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify correct number of bytes were read
                                                                                                                                                                                               assertEquals(length, bytesRead);
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify data was written to correct position in destination array
                                                                                                                                                                                               // First 'offset' bytes should be 0 (default for new byte array)
                                                                                                                                                                                               for (int i = 0; i < offset; i++) {
                                                                                                                                                                                                   assertEquals(0, dest[i]);
                                                                                                                                                                                               }
                                                                                                                                                                                               
                                                                                                                                                                                               // Next 'length' bytes should contain the read data
                                                                                                                                                                                               for (int i = 0; i < length; i++) {
                                                                                                                                                                                                   assertEquals(testData[i], dest[offset + i]);
                                                                                                                                                                                               }
                                                                                                                                                                                               
                                                                                                                                                                                               // Remaining bytes should still be 0
                                                                                                                                                                                               for (int i = offset + length; i < dest.length; i++) {
                                                                                                                                                                                                   assertEquals(0, dest[i]);
                                                                                                                                                                                               }
                                                                                                                                                                                               
                                                                                                                                                                                               // Test edge case where offset + length equals array length
                                                                                                                                                                                               dest = new byte[10];
                                                                                                                                                                                               offset = 5;
                                                                                                                                                                                               length = 5;
                                                                                                                                                                                               bytesRead = bzIn.read(dest, offset, length);
                                                                                                                                                                                               assertEquals(length, bytesRead);
                                                                                                                                                                                               
                                                                                                                                                                                               // Clean up
                                                                                                                                                                                               bzIn.close();
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testReadWithNonZeroOffsetDetectsHiMutation() throws IOException {
                                                                                                                                                                                               // Setup test data with offset > 0
                                                                                                                                                                                               byte[] dest = new byte[10];
                                                                                                                                                                                               int offs = 5;
                                                                                                                                                                                               int len = 3;
                                                                                                                                                                                               
                                                                                                                                                                                               // Mock InputStream to return 3 bytes of test data
                                                                                                                                                                                               InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                               when(mockIn.read()).thenReturn(65, 66, 67, -1); // ASCII A,B,C then EOF
                                                                                                                                                                                               
                                                                                                                                                                                               // Create test instance and inject mock
                                                                                                                                                                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                               
                                                                                                                                                                                               // Execute read operation
                                                                                                                                                                                               int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify results
                                                                                                                                                                                               assertEquals(3, bytesRead); // Should read all 3 bytes
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify data was written to correct positions (offs to offs+len-1)
                                                                                                                                                                                               assertEquals(0, dest[0]); // Before offset should be untouched
                                                                                                                                                                                               assertEquals(0, dest[4]); // Just before offset should be untouched
                                                                                                                                                                                               assertEquals(65, dest[5]); // First byte at offset
                                                                                                                                                                                               assertEquals(66, dest[6]); // Second byte
                                                                                                                                                                                               assertEquals(67, dest[7]); // Third byte
                                                                                                                                                                                               assertEquals(0, dest[8]); // After read range should be untouched
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify mock interactions
                                                                                                                                                                                               verify(mockIn, times(4)).read(); // 3 successful reads + 1 EOF check
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                         public void testReadWithOffsetShouldStartAtCorrectPosition() throws Exception {
                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                                                                             java.util.Arrays.fill(dest, (byte) 0xFF); // Fill with known value
                                                                                                                                                                                             int offs = 3;
                                                                                                                                                                                             int len = 4;
                                                                                                                                                                                             
                                                                                                                                                                                             // Create a mock InputStream that returns our test data
                                                                                                                                                                                             InputStream mockInput = new InputStream() {
                                                                                                                                                                                                 private int count = 0;
                                                                                                                                                                                                 private final byte[] data = {0x01, 0x02, 0x03};
                                                                                                                                                                                                 
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 public int read() {
                                                                                                                                                                                                     return count < data.length ? data[count++] & 0xFF : -1;
                                                                                                                                                                                                 }
                                                                                                                                                                                             };
                                                                                                                                                                                             
                                                                                                                                                                                             // Create real BZip2CompressorInputStream with our mock input
                                                                                                                                                                                             BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInput);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private read0 method for verification
                                                                                                                                                                                             java.lang.reflect.Method read0Method = BZip2CompressorInputStream.class
                                                                                                                                                                                                 .getDeclaredMethod("read0");
                                                                                                                                                                                             read0Method.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Call the method
                                                                                                                                                                                             int result = stream.read(dest, offs, len);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify results
                                                                                                                                                                                             assertEquals(3, result); // Should return number of bytes read
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify data was written at correct positions
                                                                                                                                                                                             assertEquals((byte) 0xFF, dest[0]); // Before offset should be unchanged
                                                                                                                                                                                             assertEquals((byte) 0xFF, dest[1]);
                                                                                                                                                                                             assertEquals((byte) 0xFF, dest[2]);
                                                                                                                                                                                             assertEquals((byte) 0x01, dest[3]); // First byte at exact offset
                                                                                                                                                                                             assertEquals((byte) 0x02, dest[4]);
                                                                                                                                                                                             assertEquals((byte) 0x03, dest[5]);
                                                                                                                                                                                             assertEquals((byte) 0xFF, dest[6]); // After read data should be unchanged
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify count was called for each byte read by checking bytesRead field
                                                                                                                                                                                             java.lang.reflect.Field bytesReadField = stream.getClass()
                                                                                                                                                                                                 .getSuperclass().getDeclaredField("bytesRead");
                                                                                                                                                                                             bytesReadField.setAccessible(true);
                                                                                                                                                                                             assertEquals(3L, bytesReadField.get(stream));
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                     public void testReadWithOffsetShouldWriteAtCorrectPosition() throws IOException {
                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                         byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                                         byte[] destArray = new byte[10]; // Large enough to test offset
                                                                                                                                                                                         java.util.Arrays.fill(destArray, (byte)0); // Initialize with zeros
                                                                                                                                                                                         
                                                                                                                                                                                         // Mock the input stream to return test data
                                                                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                         when(mockInputStream.read()).thenReturn(
                                                                                                                                                                                             (int)testData[0], 
                                                                                                                                                                                             (int)testData[1], 
                                                                                                                                                                                             (int)testData[2], 
                                                                                                                                                                                             (int)testData[3], 
                                                                                                                                                                                             (int)testData[4], 
                                                                                                                                                                                             -1
                                                                                                                                                                                         );
                                                                                                                                                                                         
                                                                                                                                                                                         // Create instance with mock stream
                                                                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                                         
                                                                                                                                                                                         // Test reading with offset 3
                                                                                                                                                                                         int offset = 3;
                                                                                                                                                                                         int bytesRead = bzIn.read(destArray, offset, testData.length);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify
                                                                                                                                                                                         assertEquals("Should read all test data", testData.length, bytesRead);
                                                                                                                                                                                         
                                                                                                                                                                                         // Check data was written starting at correct offset
                                                                                                                                                                                         for (int i = 0; i < testData.length; i++) {
                                                                                                                                                                                             assertEquals("Data should be written at correct position", 
                                                                                                                                                                                                         testData[i], destArray[offset + i]);
                                                                                                                                                                                         }
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify positions before offset are untouched
                                                                                                                                                                                         for (int i = 0; i < offset; i++) {
                                                                                                                                                                                             assertEquals("Positions before offset should remain 0", 
                                                                                                                                                                                                         0, destArray[i]);
                                                                                                                                                                                         }
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify positions after written data are untouched
                                                                                                                                                                                         for (int i = offset + testData.length; i < destArray.length; i++) {
                                                                                                                                                                                             assertEquals("Positions after written data should remain 0", 
                                                                                                                                                                                                         0, destArray[i]);
                                                                                                                                                                                         }
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                public void testReadWithNonZeroOffsetDetectsDestOffsMutant() throws IOException {
                                                                                                                                                                                    // Setup test data with non-zero offset
                                                                                                                                                                                    byte[] dest = new byte[10];
                                                                                                                                                                                    java.util.Arrays.fill(dest, (byte) -1); // Fill with -1 to detect overwrites
                                                                                                                                                                                    int offs = 3;
                                                                                                                                                                                    int len = 5;
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock input stream that returns 3 bytes then EOF
                                                                                                                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                                                                                                                    when(mockIn.read()).thenReturn(65, 66, 67, -1);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create test instance
                                                                                                                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                                                                    
                                                                                                                                                                                    // Execute
                                                                                                                                                                                    int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify
                                                                                                                                                                                    assertEquals(3, bytesRead); // Should read 3 bytes
                                                                                                                                                                                    
                                                                                                                                                                                    // Check data was written at correct offset
                                                                                                                                                                                    assertEquals(65, dest[offs]);
                                                                                                                                                                                    assertEquals(66, dest[offs+1]);
                                                                                                                                                                                    assertEquals(67, dest[offs+2]);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify positions before offset weren't touched
                                                                                                                                                                                    for (int i = 0; i < offs; i++) {
                                                                                                                                                                                        assertEquals(-1, dest[i]);
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify positions after written data weren't touched
                                                                                                                                                                                    for (int i = offs + bytesRead; i < dest.length; i++) {
                                                                                                                                                                                        assertEquals(-1, dest[i]);
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testReadWithOffsetShouldWriteAtCorrectPosition1() throws IOException {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                            when(mockInputStream.read(any(byte[].class), 
                                                                                                                                                                                    anyInt(), 
                                                                                                                                                                                    anyInt())).thenAnswer(invocation -> {
                                                                                                                                                                                byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                int off = (Integer) invocation.getArguments()[1];
                                                                                                                                                                                System.arraycopy(testData, 0, buf, off, testData.length);
                                                                                                                                                                                return testData.length;
                                                                                                                                                                            });
                                                                                                                                                                            
                                                                                                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                            byte[] dest = new byte[10];
                                                                                                                                                                            int offset = 3;
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            int bytesRead = bzIn.read(dest, offset, testData.length);
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            assertEquals(testData.length, bytesRead);
                                                                                                                                                                            // Verify data was written at correct offset
                                                                                                                                                                            for (int i = 0; i < testData.length; i++) {
                                                                                                                                                                                assertEquals(testData[i], dest[offset + i]);
                                                                                                                                                                            }
                                                                                                                                                                            // Verify no data was written before the offset
                                                                                                                                                                            for (int i = 0; i < offset; i++) {
                                                                                                                                                                                assertEquals(0, dest[i]);
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                                                                                   public void testReadWhenStreamClosedShouldThrowException() throws IOException {
                                                                                                                                                                       // Arrange - create stream with null input (closed)
                                                                                                                                                                       BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(null);
                                                                                                                                                                       
                                                                                                                                                                       // Act & Assert - should throw IOException
                                                                                                                                                                       bzipStream.read();
                                                                                                                                                                   }

    @Test(expected = IOException.class)
                                                                                                                                                                   public void testReadWithNullStreamShouldThrowIOException() throws IOException {
                                                                                                                                                                       // Arrange
                                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set the in field to null since constructor might initialize it
                                                                                                                                                                       try {
                                                                                                                                                                           java.lang.reflect.Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                           inField.setAccessible(true);
                                                                                                                                                                           inField.set(bzip2Stream, null);
                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                           fail("Failed to set in field to null via reflection");
                                                                                                                                                                       }
                                                                                                                                                                       
                                                                                                                                                                       // Act
                                                                                                                                                                       bzip2Stream.read(dest, 0, 5);
                                                                                                                                                                       
                                                                                                                                                                       // Assert - exception expected
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testReadWithNonNullStreamShouldNotThrowIOException() throws IOException {
                                                                                                                                                                       // Arrange
                                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                                       InputStream mockInputStream = new ByteArrayInputStream(new byte[0]); // Empty stream will return -1 on read
                                                                                                                                                                       BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                       
                                                                                                                                                                       // Act
                                                                                                                                                                       int result = bzip2Stream.read(dest, 0, 5);
                                                                                                                                                                       
                                                                                                                                                                       // Assert
                                                                                                                                                                       assertEquals(-1, result); // Should return -1 for EOF, not throw exception
                                                                                                                                                                   }

    @Test
                                                                                                                                                               public void testReadWhenStreamOpenShouldAttemptRead() throws Exception {
                                                                                                                                                                   // Arrange - create stream with mock input (open)
                                                                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                   BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                                   
                                                                                                                                                                   // Use reflection to access and modify private state if needed
                                                                                                                                                                   // Here we'll just test the actual behavior since we can't mock private methods
                                                                                                                                                                   
                                                                                                                                                                   // Act - read from the stream
                                                                                                                                                                   // Since we can't mock read0(), we'll let it execute normally
                                                                                                                                                                   // The actual value might not be 42, but we can verify the stream was read from
                                                                                                                                                                   int result = bzipStream.read();
                                                                                                                                                                   
                                                                                                                                                                   // Assert - verify the stream was read from and not closed
                                                                                                                                                                   assertTrue(result >= -1); // Valid read returns either -1 (EOF) or a byte (0-255)
                                                                                                                                                                   verify(mockInputStream, never()).close(); // ensure stream wasn't closed
                                                                                                                                                               }

    @Test(expected = IOException.class)
                                                                                                                                                           public void testReadWithNullStreamThrowsIOException1() throws IOException {
                                                                                                                                                               // Create an instance with null input stream
                                                                                                                                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                               
                                                                                                                                                               // This should throw IOException with "stream closed" message
                                                                                                                                                               // If the mutant is present, it will either:
                                                                                                                                                               // 1. Not throw any exception (if read0() handles null)
                                                                                                                                                               // 2. Throw NullPointerException (if read0() doesn't handle null)
                                                                                                                                                               bzIn.read();
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testReadDoesNotThrowWhenStreamIsValid() throws IOException {
                                                                                                                                                               // Arrange
                                                                                                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                               when(mockInputStream.read()).thenReturn(65); // Return 'A' when read
                                                                                                                                                               
                                                                                                                                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                               byte[] dest = new byte[10];
                                                                                                                                                               int offs = 0;
                                                                                                                                                               int len = 5;
                                                                                                                                                               
                                                                                                                                                               // Act & Assert
                                                                                                                                                               try {
                                                                                                                                                                   int result = bzIn.read(dest, offs, len);
                                                                                                                                                                   // Original code should reach here and return a value
                                                                                                                                                                   assertTrue("Should return >= -1", result >= -1);
                                                                                                                                                               } catch (IOException e) {
                                                                                                                                                                   fail("Should not throw IOException when stream is valid");
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               // Verify the stream was actually used
                                                                                                                                                               verify(mockInputStream, atLeastOnce()).read();
                                                                                                                                                           }

    @Test
                                                                                                                                                              public void testReadWithNullStreamShouldThrowIOException1() throws IOException {
                                                                                                                                                                  // Setup - create stream with null input
                                                                                                                                                                  InputStream nullStream = null;
                                                                                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(nullStream);
                                                                                                                                                                  
                                                                                                                                                                  // Expect exception
                                                                                                                                                                  thrown.expect(IOException.class);
                                                                                                                                                                  thrown.expectMessage("stream closed");
                                                                                                                                                                  
                                                                                                                                                                  // Test
                                                                                                                                                                  stream.read();
                                                                                                                                                                  
                                                                                                                                                                  // The mutant would reach here and fail to throw the expected exception
                                                                                                                                                              }

    @Test
                                                                                                                                                              public void testReadWithValidStreamShouldNotThrowException() throws IOException {
                                                                                                                                                                  // Setup - mock a valid input stream
                                                                                                                                                                  InputStream mockStream = mock(InputStream.class);
                                                                                                                                                                  when(mockStream.read()).thenReturn(42); // return some dummy value
                                                                                                                                                                  
                                                                                                                                                                  BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockStream);
                                                                                                                                                                  
                                                                                                                                                                  // Test - should not throw exception
                                                                                                                                                                  int result = stream.read();
                                                                                                                                                                  
                                                                                                                                                                  // Verify
                                                                                                                                                                  assertEquals(42, result);
                                                                                                                                                                  verify(mockStream).read();
                                                                                                                                                              }

    @Test(expected = IOException.class)
                                                                                                                                                          public void testReadWithNullInputStreamThrowsIOException() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              byte[] dest = new byte[10];
                                                                                                                                                              int offs = 0;
                                                                                                                                                              int len = 5;
                                                                                                                                                              
                                                                                                                                                              // Create instance with null input stream
                                                                                                                                                              BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set the 'in' field to null since constructor might initialize it
                                                                                                                                                              Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                              inField.setAccessible(true);
                                                                                                                                                              inField.set(stream, null);
                                                                                                                                                              
                                                                                                                                                              // Act - should throw IOException when 'in' is null
                                                                                                                                                              stream.read(dest, offs, len);
                                                                                                                                                              
                                                                                                                                                              // Assert - handled by expected exception in @Test annotation
                                                                                                                                                          }

    @Test(expected = IOException.class)
                                                                                                                                                         public void testReadWithClosedStream_ShouldThrowIOExceptionWithCorrectMessage() throws Exception {
                                                                                                                                                             // Arrange
                                                                                                                                                             byte[] dest = new byte[10];
                                                                                                                                                             int offs = 0;
                                                                                                                                                             int len = 5;
                                                                                                                                                             
                                                                                                                                                             // Create a BZip2CompressorInputStream with null input stream (simulating closed stream)
                                                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to set the 'in' field to null since constructor might initialize it
                                                                                                                                                             try {
                                                                                                                                                                 Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                                                 inField.setAccessible(true);
                                                                                                                                                                 inField.set(bzIn, null);
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Failed to set input stream to null using reflection");
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             // Act & Assert
                                                                                                                                                             try {
                                                                                                                                                                 bzIn.read(dest, offs, len);
                                                                                                                                                                 fail("Expected IOException to be thrown");
                                                                                                                                                             } catch (IOException e) {
                                                                                                                                                                 assertEquals("stream closed", e.getMessage());
                                                                                                                                                                 throw e;
                                                                                                                                                             }
                                                                                                                                                         }

    @Test
                                                                                                                                                        public void testReadThrowsCorrectExceptionWhenStreamClosed1() throws IOException {
                                                                                                                                                            // Prepare
                                                                                                                                                            InputStream mockInputStream = null; // Simulate closed stream
                                                                                                                                                            BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                // Execute
                                                                                                                                                                bzipStream.read();
                                                                                                                                                                fail("Expected IOException to be thrown");
                                                                                                                                                            } catch (IOException e) {
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals("stream closed", e.getMessage());
                                                                                                                                                            }
                                                                                                                                                        }

    @Test(expected = IOException.class)
                                                                                                                                                   public void testReadWhenStreamClosedThrowsIOException1() throws IOException {
                                                                                                                                                       BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                       try {
                                                                                                                                                           stream.read();
                                                                                                                                                           fail("Expected IOException to be thrown when stream is closed");
                                                                                                                                                       } catch (IOException e) {
                                                                                                                                                           assertEquals("stream closed", e.getMessage());
                                                                                                                                                           throw e;
                                                                                                                                                       }
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testReadThrowsIOExceptionWhenStreamClosed5() throws Exception {
                                                                                                                                                       // Arrange
                                                                                                                                                       byte[] dest = new byte[10];
                                                                                                                                                       int offs = 0;
                                                                                                                                                       int len = 5;
                                                                                                                                                       
                                                                                                                                                       // Create instance with null input stream to simulate closed stream
                                                                                                                                                       BZip2CompressorInputStream stream = new BZip2CompressorInputStream((InputStream) null);
                                                                                                                                                       
                                                                                                                                                       try {
                                                                                                                                                           // Act
                                                                                                                                                           stream.read(dest, offs, len);
                                                                                                                                                           fail("Expected IOException");
                                                                                                                                                       } catch (IOException e) {
                                                                                                                                                           // Assert
                                                                                                                                                           assertEquals("stream closed", e.getMessage());
                                                                                                                                                       }
                                                                                                                                                   }

    @Test(expected = IOException.class)
                                                                                                                                               public void testReadWhenStreamClosedThrowsException2() throws IOException {
                                                                                                                                                   // Arrange - create stream with null input to simulate closed state
                                                                                                                                                   BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                   
                                                                                                                                                   try {
                                                                                                                                                       // Act - should throw IOException
                                                                                                                                                       stream.read();
                                                                                                                                                   } catch (IOException e) {
                                                                                                                                                       // Assert - verify exception message
                                                                                                                                                       assertEquals("stream closed", e.getMessage());
                                                                                                                                                       throw e; // rethrow to satisfy @Test(expected)
                                                                                                                                                   }
                                                                                                                                                   
                                                                                                                                                   // If we get here, the test fails (no exception was thrown)
                                                                                                                                                   fail("Expected IOException not thrown");
                                                                                                                                               }

    @Test(expected = IOException.class)
                                                                                                                                               public void testReadWhenStreamClosedThrowsException3() throws IOException {
                                                                                                                                                   // Arrange
                                                                                                                                                   byte[] dest = new byte[10];
                                                                                                                                                   int offs = 0;
                                                                                                                                                   int len = 5;
                                                                                                                                                   
                                                                                                                                                   // Create instance with null input stream to simulate closed stream
                                                                                                                                                   BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                                                                                   
                                                                                                                                                   // Act - should throw IOException
                                                                                                                                                   stream.read(dest, offs, len);
                                                                                                                                                   
                                                                                                                                                   // Assertion is handled by the @Test(expected) annotation
                                                                                                                                                   // If it returns -1 instead of throwing, the test will fail
                                                                                                                                               }

    @Test
                                                                                                                                              public void testReadWithZeroLength1() throws IOException {
                                                                                                                                                  // Create a mock InputStream that returns -1 (EOF) when read is called
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                                  
                                                                                                                                                  // Create the BZip2CompressorInputStream with our mock
                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                  
                                                                                                                                                  // Test case 1: len == 0 (should return 0)
                                                                                                                                                  int result = bzIn.read(new byte[10], 0, 0);
                                                                                                                                                  assertEquals(0, result);  // Should return 0 for zero-length read
                                                                                                                                                  
                                                                                                                                                  // Test case 2: len != 0 (should return -1 for EOF)
                                                                                                                                                  result = bzIn.read(new byte[10], 0, 10);
                                                                                                                                                  assertEquals(-1, result);  // Should return -1 for EOF
                                                                                                                                                  
                                                                                                                                                  // Verify the mock interactions
                                                                                                                                                  verify(mockInputStream, atLeastOnce()).read();
                                                                                                                                                  
                                                                                                                                                  // Test case 3: stream closed (should throw IOException)
                                                                                                                                                  bzIn.close();
                                                                                                                                                  try {
                                                                                                                                                      bzIn.read(new byte[10], 0, 10);
                                                                                                                                                      fail("Expected IOException for closed stream");
                                                                                                                                                  } catch (IOException e) {
                                                                                                                                                      assertEquals("stream closed", e.getMessage());
                                                                                                                                                  }
                                                                                                                                              }

    @Test
                                                                                                                                              public void testReadWithZeroLengthShouldReturnZeroWithoutReading1() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                  byte[] dest = new byte[10];
                                                                                                                                                  int offs = 0;
                                                                                                                                                  int len = 0;  // This is the key test case
                                                                                                                                                  
                                                                                                                                                  // Act
                                                                                                                                                  int result = bzIn.read(dest, offs, len);
                                                                                                                                                  
                                                                                                                                                  // Assert
                                                                                                                                                  assertEquals("Should return 0 when len=0", 0, result);
                                                                                                                                                  verify(mockInputStream, never()).read();  // Ensure no read operation occurred
                                                                                                                                              }

    @Test
                                                                                                                                             public void testReadWithZeroLength2() throws IOException {
                                                                                                                                                 // Create a mock InputStream that will return specific values
                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                 when(mockInputStream.read()).thenReturn(65); // Return 'A' when read
                                                                                                                                                 
                                                                                                                                                 // Create the BZip2CompressorInputStream with our mock
                                                                                                                                                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                 
                                                                                                                                                 // Test normal read (len > 0)
                                                                                                                                                 int result = bzIn.read();
                                                                                                                                                 assertEquals(65, result); // Should read 'A' from our mock
                                                                                                                                                 
                                                                                                                                                 // Now test the edge case that would catch the mutant
                                                                                                                                                 // We need to test the behavior when reading 0 bytes
                                                                                                                                                 // The original code should handle len == 0 properly
                                                                                                                                                 // The mutant would treat len == 0 differently
                                                                                                                                                 
                                                                                                                                                 // Since we can't directly test read0(), we'll test through the public read(byte[]) method
                                                                                                                                                 byte[] buffer = new byte[10];
                                                                                                                                                 
                                                                                                                                                 // Test reading 0 bytes - should return 0 (original behavior)
                                                                                                                                                 int bytesRead = bzIn.read(buffer, 0, 0);
                                                                                                                                                 assertEquals(0, bytesRead); // Should return 0 for reading 0 bytes
                                                                                                                                                 
                                                                                                                                                 // The mutant would potentially return -1 or throw an exception here
                                                                                                                                                 // This assertion will fail if the mutant is present
                                                                                                                                             }

    @Test
                                                                                                                                             public void testReadWithZeroLengthShouldReturnImmediately1() throws IOException {
                                                                                                                                                 // Arrange
                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                 byte[] dest = new byte[10];
                                                                                                                                                 int offs = 0;
                                                                                                                                                 int len = 0;  // This is the key test case
                                                                                                                                                 
                                                                                                                                                 // Act
                                                                                                                                                 int result = bzIn.read(dest, offs, len);
                                                                                                                                                 
                                                                                                                                                 // Assert
                                                                                                                                                 assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                                 verify(mockInputStream, never()).read();  // Ensure no read attempts were made
                                                                                                                                             }

    @Test
                                                                                                                                            public void testReadWithZeroLengthShouldReturnZero2() throws IOException {
                                                                                                                                                // Arrange
                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                
                                                                                                                                                // Create a zero-length byte array
                                                                                                                                                byte[] dest = new byte[0];
                                                                                                                                                
                                                                                                                                                // Act
                                                                                                                                                int result = bzipStream.read(dest, 0, 0);
                                                                                                                                                
                                                                                                                                                // Assert
                                                                                                                                                assertEquals("Reading zero bytes should return 0", 0, result);
                                                                                                                                                
                                                                                                                                                // Verify no interaction with the underlying stream should occur for zero-length read
                                                                                                                                                verify(mockInputStream, never()).read(any(), anyInt(), anyInt());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testReadWithZeroLengthShouldReturnZero3() throws IOException {
                                                                                                                                                // Arrange
                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                                byte[] dest = new byte[10];
                                                                                                                                                int offs = 0;
                                                                                                                                                int len = 0;  // This is the key test case
                                                                                                                                                
                                                                                                                                                // Act
                                                                                                                                                int result = bzIn.read(dest, offs, len);
                                                                                                                                                
                                                                                                                                                // Assert
                                                                                                                                                assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                                
                                                                                                                                                // Verify no interaction with the stream should occur
                                                                                                                                                verifyZeroInteractions(mockInputStream);
                                                                                                                                            }

    @Test
                                                                                                                                           public void testReadWithZeroLengthShouldReturnZeroWithoutReading2() throws IOException {
                                                                                                                                               // Arrange
                                                                                                                                               byte[] dest = new byte[10];
                                                                                                                                               int offs = 0;
                                                                                                                                               int len = 0;
                                                                                                                                               
                                                                                                                                               // Mock the InputStream to verify it's never called
                                                                                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               int result = bzIn.read(dest, offs, len);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                               
                                                                                                                                               // Verify no interaction with the underlying stream should occur
                                                                                                                                               verifyZeroInteractions(mockInputStream);
                                                                                                                                               
                                                                                                                                               // Additional check to ensure dest array wasn't modified
                                                                                                                                               byte[] expectedDest = new byte[10];
                                                                                                                                               assertArrayEquals("Destination array should remain unchanged", 
                                                                                                                                                                expectedDest, dest);
                                                                                                                                           }

    @Test
                                                                                                                                          public void testReadWithZeroLengthShouldNotCount1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                              // Create a mock input stream that returns EOF (-1)
                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                              when(mockIn.read()).thenReturn(-1);
                                                                                                                                              
                                                                                                                                              // Create the test object with our mock stream
                                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                              
                                                                                                                                              // Create a spy to verify count() calls
                                                                                                                                              BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                                                                                              
                                                                                                                                              // Get the bytesTransferred field to verify count() calls indirectly
                                                                                                                                              Field bytesTransferredField = CompressorInputStream.class.getDeclaredField("bytesTransferred");
                                                                                                                                              bytesTransferredField.setAccessible(true);
                                                                                                                                              long initialCount = (long) bytesTransferredField.get(spyBzIn);
                                                                                                                                              
                                                                                                                                              // Test with len = 0 (should not count)
                                                                                                                                              int result = spyBzIn.read(new byte[10], 0, 0);
                                                                                                                                              
                                                                                                                                              // Verify count was not called by checking bytesTransferred didn't change
                                                                                                                                              assertEquals(initialCount, bytesTransferredField.get(spyBzIn));
                                                                                                                                              
                                                                                                                                              // Test with len > 0 (should count)
                                                                                                                                              result = spyBzIn.read(new byte[10], 0, 1);
                                                                                                                                              
                                                                                                                                              // Verify count was called by checking bytesTransferred changed
                                                                                                                                              assertTrue((long) bytesTransferredField.get(spyBzIn) > initialCount);
                                                                                                                                              
                                                                                                                                              // Additional assertion for the return value
                                                                                                                                              assertEquals(-1, result); // Since our mock returns EOF
                                                                                                                                          }

    @Test
                                                                                                                                      public void testReadReturnsZeroWhenRead0ReturnsZero1() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                          
                                                                                                                                          // Use reflection to mock read0() behavior since it's private
                                                                                                                                          // First we need to set up the stream to be non-null
                                                                                                                                          Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                                                                          inField.setAccessible(true);
                                                                                                                                          inField.set(bzIn, mockInputStream);
                                                                                                                                          
                                                                                                                                          // Mock read0() to return 0
                                                                                                                                          Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                          read0Method.setAccessible(true);
                                                                                                                                          when(read0Method.invoke(bzIn)).thenReturn(0);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          int result = bzIn.read();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals("Should return 0 when read0 returns 0", 0, result);
                                                                                                                                          
                                                                                                                                          // Verify count was called with 1 (since 0 is not negative)
                                                                                                                                          // This part would need access to count method or its side effects to verify
                                                                                                                                          // Since we don't have visibility into count(), we focus on the return value
                                                                                                                                      }

    @Test
                                                                                                                                      public void testReadReturnsZeroWhenStreamReturnsZero() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                          when(mockInputStream.read()).thenReturn(0);
                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          int result = bzIn.read();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals("Should return 0 when underlying stream returns 0", 0, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testReadWithZeroLengthShouldReturnZero4() throws IOException {
                                                                                                                                          // Arrange
                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                          byte[] dest = new byte[10];
                                                                                                                                          int offs = 0;
                                                                                                                                          int len = 0;  // This is the key test condition
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          int result = bzIn.read(dest, offs, len);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals("When len=0, should return 0", 0, result);
                                                                                                                                          
                                                                                                                                          // Verify no interaction with the stream should occur
                                                                                                                                          verifyZeroInteractions(mockInputStream);
                                                                                                                                      }

    @Test
                                                                                                                                     public void testReadWhenRead0ReturnsZero() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                         
                                                                                                                                         // Mock read0() to return 0 using reflection since it's private
                                                                                                                                         Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                                                         read0Method.setAccessible(true);
                                                                                                                                         when(read0Method.invoke(bzIn)).thenReturn(0);
                                                                                                                                         
                                                                                                                                         // Also need to mock count() to verify it's called with 1
                                                                                                                                         Method countMethod = BZip2CompressorInputStream.class.getDeclaredMethod("count", int.class);
                                                                                                                                         countMethod.setAccessible(true);
                                                                                                                                         
                                                                                                                                         // Test
                                                                                                                                         int result = bzIn.read();
                                                                                                                                         
                                                                                                                                         // Verify
                                                                                                                                         assertEquals("Should return 0 when read0 returns 0", 0, result);
                                                                                                                                         
                                                                                                                                         // Verify count was called with 1 (since 0 is not less than 0)
                                                                                                                                         verify(countMethod).invoke(bzIn, 1);
                                                                                                                                         
                                                                                                                                         // Clean up
                                                                                                                                         read0Method.setAccessible(false);
                                                                                                                                         countMethod.setAccessible(false);
                                                                                                                                     }

    @Test
                                                                                                                                     public void testReadWithZeroLengthShouldReturnZeroNotMinusOne() throws IOException {
                                                                                                                                         // Arrange
                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                         byte[] dest = new byte[10];
                                                                                                                                         
                                                                                                                                         // Act - call read with len=0
                                                                                                                                         int result = bzIn.read(dest, 0, 0);
                                                                                                                                         
                                                                                                                                         // Assert
                                                                                                                                         assertEquals("When len=0, method should return 0", 0, result);
                                                                                                                                         
                                                                                                                                         // Cleanup
                                                                                                                                         bzIn.close();
                                                                                                                                     }

    @Test(expected = IOException.class)
                                                                                                                                    public void testReadThrowsExceptionWhenStreamClosed2() throws IOException {
                                                                                                                                        // Arrange
                                                                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                                                                        
                                                                                                                                        // Act & Assert
                                                                                                                                        bzIn.read();
                                                                                                                                    }

    @Test
                                                                                                                                    public void testReadWithZeroLengthShouldReturnZeroNotLen() throws IOException {
                                                                                                                                        // Arrange
                                                                                                                                        byte[] dest = new byte[10];
                                                                                                                                        int offs = 0;
                                                                                                                                        int len = 0;
                                                                                                                                        
                                                                                                                                        // Mock the input stream to be non-null (to pass the stream closed check)
                                                                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                        
                                                                                                                                        // Act
                                                                                                                                        int result = bzIn.read(dest, offs, len);
                                                                                                                                        
                                                                                                                                        // Assert
                                                                                                                                        // The original should return 0, mutant would return len (which is also 0 in this case)
                                                                                                                                        // To catch the mutant, we need to verify the semantic meaning - it should be 0
                                                                                                                                        assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                                                                        
                                                                                                                                        // Additional verification that no actual read occurred
                                                                                                                                        verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                    }

    @Test
                                                                                                                                   public void testReadReturnsNegativeOneOnEOF() throws IOException {
                                                                                                                                       // Arrange
                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                       // Mock InputStream.read() to return -1 (EOF)
                                                                                                                                       when(mockInputStream.read()).thenReturn(-1);
                                                                                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       int result = bzIn.read();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertEquals("Should return -1 on EOF", -1, result);
                                                                                                                                   }

    @Test
                                                                                                                               public void testReadDetectsHiCalculationMutant1() throws IOException {
                                                                                                                                   // Setup test data
                                                                                                                                   byte[] dest = new byte[10];
                                                                                                                                   int offs = 2;
                                                                                                                                   int len = 5;
                                                                                                                                   
                                                                                                                                   // Mock the input stream to return some test data
                                                                                                                                   InputStream mockIn = mock(InputStream.class);
                                                                                                                                   when(mockIn.read()).thenReturn(65, 66, 67, -1); // Return 3 bytes then EOF
                                                                                                                                   
                                                                                                                                   // Create the test object with our mock stream
                                                                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                                   
                                                                                                                                   // Call the method under test
                                                                                                                                   int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                                   
                                                                                                                                   // Verify results - this will catch the mutant
                                                                                                                                   // Original code should read 3 bytes (ABC) into positions 2-4
                                                                                                                                   // Mutant would return -1 and not modify the buffer
                                                                                                                                   assertEquals(3, bytesRead);
                                                                                                                                   assertEquals('A', dest[2]);
                                                                                                                                   assertEquals('B', dest[3]);
                                                                                                                                   assertEquals('C', dest[4]);
                                                                                                                                   
                                                                                                                                   // Verify no bytes were written beyond what we expect
                                                                                                                                   assertEquals(0, dest[5]);
                                                                                                                                   assertEquals(0, dest[6]);
                                                                                                                                   
                                                                                                                                   // Verify the mock interaction
                                                                                                                                   verify(mockIn, times(4)).read(); // 3 successful reads + 1 EOF check
                                                                                                                               }

    @Test
                                                                                                                              public void testReadWithOffsetAndLength1() throws IOException {
                                                                                                                                  // Setup test data
                                                                                                                                  byte[] testData = new byte[100];
                                                                                                                                  for (int i = 0; i < testData.length; i++) {
                                                                                                                                      testData[i] = (byte)(i % 256);
                                                                                                                                  }
                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                  when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                      .thenAnswer(invocation -> {
                                                                                                                                          byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                          int off = (Integer) invocation.getArguments()[1];
                                                                                                                                          int len = (Integer) invocation.getArguments()[2];
                                                                                                                                          // Verify bounds are correct
                                                                                                                                          if (off < 0 || len < 0 || off + len > buf.length) {
                                                                                                                                              throw new IndexOutOfBoundsException();
                                                                                                                                          }
                                                                                                                                          // Simulate reading some data
                                                                                                                                          System.arraycopy(testData, 0, buf, off, Math.min(len, testData.length));
                                                                                                                                          return Math.min(len, testData.length);
                                                                                                                                      });
                                                                                                                                  
                                                                                                                                  // Create test object
                                                                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                                  
                                                                                                                                  // Test case that would fail with the mutation
                                                                                                                                  byte[] dest = new byte[100];
                                                                                                                                  int offset = 50;
                                                                                                                                  int length = 30;
                                                                                                                                  
                                                                                                                                  // This would throw IndexOutOfBoundsException with the mutation (offs - len = 20)
                                                                                                                                  int bytesRead = bzIn.read(dest, offset, length);
                                                                                                                                  
                                                                                                                                  // Verify correct behavior
                                                                                                                                  assertEquals(length, bytesRead);
                                                                                                                                  for (int i = 0; i < length; i++) {
                                                                                                                                      assertEquals(testData[i], dest[offset + i]);
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Test edge case where offs + len equals array length
                                                                                                                                  offset = 70;
                                                                                                                                  length = 30;
                                                                                                                                  bytesRead = bzIn.read(dest, offset, length);
                                                                                                                                  assertEquals(length, bytesRead);
                                                                                                                                  
                                                                                                                                  // Test case that would expose the mutation more clearly
                                                                                                                                  try {
                                                                                                                                      offset = 10;
                                                                                                                                      length = 20;
                                                                                                                                      bzIn.read(dest, offset, length);
                                                                                                                                      // Should not throw exception with original code
                                                                                                                                  } catch (IndexOutOfBoundsException e) {
                                                                                                                                      fail("Original code should not throw IndexOutOfBoundsException for valid bounds");
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                          public void testReadWithMultipleBytesShouldReadFullLength() throws IOException {
                                                                                                                              // Arrange
                                                                                                                              byte[] dest = new byte[10];
                                                                                                                              int offs = 2;
                                                                                                                              int len = 5;
                                                                                                                              
                                                                                                                              // Mock the input stream to return enough bytes
                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                              when(mockInputStream.read()).thenReturn(1, 2, 3, 4, 5, -1);
                                                                                                                              
                                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                              
                                                                                                                              // Assert
                                                                                                                              assertEquals("Should read exactly len bytes", len, bytesRead);
                                                                                                                              
                                                                                                                              // Verify bytes were written to correct positions
                                                                                                                              for (int i = offs; i < offs + len; i++) {
                                                                                                                                  assertNotEquals("Destination byte at position " + i + " should be modified", 
                                                                                                                                                  0, dest[i]);
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Verify no bytes were written beyond the requested range
                                                                                                                              assertEquals("Byte before offset should remain unchanged", 0, dest[offs - 1]);
                                                                                                                              assertEquals("Byte after range should remain unchanged", 0, dest[offs + len]);
                                                                                                                          }

    @Test
                                                                                                                         public void testReadByteArrayShouldReadFullLength() throws IOException {
                                                                                                                             // Setup test data
                                                                                                                             byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                             byte[] dest = new byte[5];
                                                                                                                             int offs = 0;
                                                                                                                             int len = 5;
                                                                                                                             
                                                                                                                             // Mock the InputStream to return our test data
                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                             when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                 .thenAnswer(invocation -> {
                                                                                                                                     byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                     int offset = (int) invocation.getArguments()[1];
                                                                                                                                     int length = (int) invocation.getArguments()[2];
                                                                                                                                     System.arraycopy(testData, 0, buf, offset, length);
                                                                                                                                     return length;
                                                                                                                                 });
                                                                                                                             
                                                                                                                             // Create instance with our mock stream
                                                                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                             
                                                                                                                             // Test the read operation
                                                                                                                             int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                             
                                                                                                                             // Verify the full length was read
                                                                                                                             assertEquals("Should read full requested length", len, bytesRead);
                                                                                                                             
                                                                                                                             // Verify the data was correctly copied to the destination
                                                                                                                             assertArrayEquals("Destination array should contain the test data", 
                                                                                                                                              testData, dest);
                                                                                                                             
                                                                                                                             // Verify the mock was called with correct parameters
                                                                                                                             verify(mockInputStream).read(any(byte[].class), eq(offs), eq(len));
                                                                                                                         }

    @Test
                                                                                                                     public void testReadWithOffsetDetectsHiMutation() throws IOException {
                                                                                                                         // Setup
                                                                                                                         byte[] dest = new byte[10];
                                                                                                                         int offs = 5;
                                                                                                                         int len = 3;
                                                                                                                         
                                                                                                                         // Mock the input stream to return some test data
                                                                                                                         InputStream mockIn = mock(InputStream.class);
                                                                                                                         when(mockIn.read()).thenReturn(65, 66, 67, -1); // Return A,B,C then EOF
                                                                                                                         
                                                                                                                         // Create test instance with our mock stream
                                                                                                                         BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                         
                                                                                                                         // Execute
                                                                                                                         int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                         
                                                                                                                         // Verify
                                                                                                                         assertEquals(3, bytesRead); // Should read 3 bytes
                                                                                                                         
                                                                                                                         // Check data was written at correct offset (would fail with mutant)
                                                                                                                         assertEquals(0, dest[0]); // Should be untouched
                                                                                                                         assertEquals(0, dest[1]); // Should be untouched
                                                                                                                         assertEquals(0, dest[2]); // Should be untouched
                                                                                                                         assertEquals(0, dest[3]); // Should be untouched
                                                                                                                         assertEquals(0, dest[4]); // Should be untouched
                                                                                                                         assertEquals(65, dest[5]); // First byte at offset
                                                                                                                         assertEquals(66, dest[6]); // Second byte
                                                                                                                         assertEquals(67, dest[7]); // Third byte
                                                                                                                         assertEquals(0, dest[8]); // Should be untouched
                                                                                                                         assertEquals(0, dest[9]); // Should be untouched
                                                                                                                         
                                                                                                                         // Verify mock interactions
                                                                                                                         verify(mockIn, times(4)).read(); // 3 successful reads + 1 EOF check
                                                                                                                     }

    @Test
                                                                                                                    public void testReadWithOffsetDetectsMutant1() throws IOException {
                                                                                                                        // Setup test data
                                                                                                                        byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                        byte[] dest = new byte[10];
                                                                                                                        int offset = 5;
                                                                                                                        int len = 3;
                                                                                                                        
                                                                                                                        // Mock the InputStream to return our test data
                                                                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                                                                        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                            .thenAnswer(invocation -> {
                                                                                                                                byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                int off = (Integer) invocation.getArguments()[1];
                                                                                                                                int length = (Integer) invocation.getArguments()[2];
                                                                                                                                System.arraycopy(testData, 0, buf, off, Math.min(length, testData.length));
                                                                                                                                return Math.min(length, testData.length);
                                                                                                                            });
                                                                                                                        
                                                                                                                        // Create the test object
                                                                                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                        
                                                                                                                        // Call the method under test
                                                                                                                        int bytesRead = bzIn.read(dest, offset, len);
                                                                                                                        
                                                                                                                        // Verify the results
                                                                                                                        assertEquals(Math.min(len, testData.length), bytesRead);
                                                                                                                        
                                                                                                                        // Verify data was placed at correct offset
                                                                                                                        for (int i = 0; i < bytesRead; i++) {
                                                                                                                            assertEquals(testData[i], dest[offset + i]);
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Verify no data was written before the offset
                                                                                                                        for (int i = 0; i < offset; i++) {
                                                                                                                            assertEquals(0, dest[i]);
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Verify no data was written after the read length
                                                                                                                        for (int i = offset + bytesRead; i < dest.length; i++) {
                                                                                                                            assertEquals(0, dest[i]);
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                public void testReadWithOffsetDetectsDestOffsMutant() throws IOException {
                                                                                                                    // Setup test data - small buffer where we can verify exact positions
                                                                                                                    byte[] dest = new byte[4];
                                                                                                                    int offs = 1;
                                                                                                                    int len = 2;
                                                                                                                    
                                                                                                                    // Mock the input stream to return two bytes then EOF
                                                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                                                    when(mockIn.read()).thenReturn(65, 66, -1);
                                                                                                                    
                                                                                                                    // Create test instance with our mock stream
                                                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                                    
                                                                                                                    // Execute the read
                                                                                                                    int bytesRead = bzIn.read(dest, offs, len);
                                                                                                                    
                                                                                                                    // Verify results - this will catch the mutant
                                                                                                                    // Original: dest[1] = 65, dest[2] = 66
                                                                                                                    // Mutant: dest[2] = 65, dest[3] = 66 (and potential array bounds issue)
                                                                                                                    assertEquals("Should read exactly 2 bytes", 2, bytesRead);
                                                                                                                    assertEquals("First byte should be at position 1", 65, dest[1]);
                                                                                                                    assertEquals("Second byte should be at position 2", 66, dest[2]);
                                                                                                                    assertEquals("Position before offset should remain 0", 0, dest[0]);
                                                                                                                    assertEquals("Position after read should remain 0", 0, dest[3]);
                                                                                                                    
                                                                                                                    // Verify mock interactions
                                                                                                                    verify(mockIn, times(3)).read(); // 2 successful reads + 1 EOF check
                                                                                                                }

    @Test
                                                                                                               public void testReadWithOffsetShouldWriteAtCorrectPosition2() throws IOException {
                                                                                                                   // Setup test data
                                                                                                                   byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                   when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                       .thenAnswer(invocation -> {
                                                                                                                           byte[] buf = (byte[])invocation.getArguments()[0];
                                                                                                                           int off = (Integer)invocation.getArguments()[1];
                                                                                                                           System.arraycopy(testData, 0, buf, off, Math.min(testData.length, buf.length - off));
                                                                                                                           return testData.length;
                                                                                                                       });
                                                                                                                   
                                                                                                                   // Create instance with mock stream
                                                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                                   
                                                                                                                   // Test buffer with initial values
                                                                                                                   byte[] destBuffer = new byte[10];
                                                                                                                   java.util.Arrays.fill(destBuffer, (byte)-1); // Fill with -1 to detect overwrites
                                                                                                                   
                                                                                                                   // Test reading at specific offset
                                                                                                                   int offset = 2;
                                                                                                                   int bytesRead = bzIn.read(destBuffer, offset, 5);
                                                                                                                   
                                                                                                                   // Verify results
                                                                                                                   assertEquals("Should read all test data", testData.length, bytesRead);
                                                                                                                   
                                                                                                                   // Check data was written at correct position
                                                                                                                   for (int i = 0; i < testData.length; i++) {
                                                                                                                       assertEquals("Data should be at correct offset", 
                                                                                                                                   testData[i], destBuffer[offset + i]);
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Verify no data was written before offset
                                                                                                                   for (int i = 0; i < offset; i++) {
                                                                                                                       assertEquals("Data before offset should remain unchanged", 
                                                                                                                                   (byte)-1, destBuffer[i]);
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Verify no data was written after expected position
                                                                                                                   for (int i = offset + testData.length; i < destBuffer.length; i++) {
                                                                                                                       assertEquals("Data after read range should remain unchanged", 
                                                                                                                                   (byte)-1, destBuffer[i]);
                                                                                                                   }
                                                                                                                   
                                                                                                                   // The mutant would fail these assertions because it would write at offset+1
                                                                                                               }

    @Test
                                                                                                          public void testReadWithNonZeroOffsetShouldWriteAtCorrectPosition() throws IOException {
                                                                                                              // Setup mock input stream to return 3 bytes
                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                              when(mockIn.read()).thenReturn(65, 66, 67, -1); // ABC then EOF
                                                                                                              
                                                                                                              // Create compressor stream with mock input
                                                                                                              BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                                                              
                                                                                                              // Destination array with initial values
                                                                                                              byte[] dest = new byte[10];
                                                                                                              // Fill with 'X' to detect overwrites
                                                                                                              for (int i = 0; i < dest.length; i++) {
                                                                                                                  dest[i] = (byte) 'X';
                                                                                                              }
                                                                                                              
                                                                                                              // Call read with offset 3, length 4
                                                                                                              int offset = 3;
                                                                                                              int len = 4;
                                                                                                              int bytesRead = bzIn.read(dest, offset, len);
                                                                                                              
                                                                                                              // Verify correct number of bytes read
                                                                                                              assertEquals(3, bytesRead);
                                                                                                              
                                                                                                              // Verify data was written at correct position
                                                                                                              assertEquals('A', dest[offset]);
                                                                                                              assertEquals('B', dest[offset + 1]);
                                                                                                              assertEquals('C', dest[offset + 2]);
                                                                                                              
                                                                                                              // Verify data before offset wasn't modified
                                                                                                              for (int i = 0; i < offset; i++) {
                                                                                                                  assertEquals('X', dest[i]);
                                                                                                              }
                                                                                                              
                                                                                                              // Verify data after written bytes wasn't modified
                                                                                                              for (int i = offset + bytesRead; i < dest.length; i++) {
                                                                                                                  assertEquals('X', dest[i]);
                                                                                                              }
                                                                                                          }

    @Test
                                                                                                      public void testReadWithOffset() throws IOException {
                                                                                                          // Setup
                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                          when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                              .thenAnswer(invocation -> {
                                                                                                                  byte[] dest = (byte[]) invocation.getArguments()[0];
                                                                                                                  int offs = (Integer) invocation.getArguments()[1];
                                                                                                                  int len = (Integer) invocation.getArguments()[2];
                                                                                                                  // Fill the destination array from offset with test data
                                                                                                                  for (int i = offs; i < offs + len; i++) {
                                                                                                                      dest[i] = (byte)(i - offs + 1); // 1, 2, 3...
                                                                                                                  }
                                                                                                                  return len;
                                                                                                              });
                                                                                                          
                                                                                                          BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                          byte[] dest = new byte[10];
                                                                                                          int offset = 3;
                                                                                                          int length = 4;
                                                                                                          
                                                                                                          // Execute
                                                                                                          int bytesRead = bzIn.read(dest, offset, length);
                                                                                                          
                                                                                                          // Verify
                                                                                                          assertEquals(length, bytesRead);
                                                                                                          // Check that data was written starting at offset
                                                                                                          assertEquals(1, dest[offset]);
                                                                                                          assertEquals(2, dest[offset + 1]);
                                                                                                          assertEquals(3, dest[offset + 2]);
                                                                                                          assertEquals(4, dest[offset + 3]);
                                                                                                          // Check that data before offset wasn't modified
                                                                                                          assertEquals(0, dest[offset - 1]);
                                                                                                          // Check that data after read range wasn't modified
                                                                                                          assertEquals(0, dest[offset + length]);
                                                                                                          
                                                                                                          // Cleanup
                                                                                                          bzIn.close();
                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                 public void testReadWithNullStreamShouldThrowIOException2() throws IOException {
                                                                                                     // Create stream with null input (closed stream case)
                                                                                                     BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                     
                                                                                                     // This should throw IOException with "stream closed" message
                                                                                                     bzip2Stream.read();
                                                                                                     
                                                                                                     // The mutant would fail this test by not throwing the exception
                                                                                                 }

    @Test
                                                                                                 public void testReadWithValidStreamShouldNotThrowException1() throws Exception {
                                                                                                     // Create mock input stream
                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                     
                                                                                                     // Create real bzip2 stream with mock input
                                                                                                     BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                     
                                                                                                     // Use reflection to mock the private read0() method
                                                                                                     Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                                                     read0Method.setAccessible(true);
                                                                                                     
                                                                                                     // Create a spy to intercept the real method
                                                                                                     BZip2CompressorInputStream spyStream = spy(bzip2Stream);
                                                                                                     when(read0Method.invoke(spyStream)).thenReturn(42);
                                                                                                     
                                                                                                     // This should not throw exception
                                                                                                     int result = spyStream.read();
                                                                                                     
                                                                                                     assertEquals(42, result);
                                                                                                     // The mutant would fail this test by throwing an exception
                                                                                                 }

    @Test(expected = IOException.class)
                                                                                                 public void testReadWithNullStreamShouldThrowIOException3() throws IOException {
                                                                                                     // Create stream with null input to simulate closed stream
                                                                                                     BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                     byte[] dest = new byte[5];
                                                                                                     
                                                                                                     // This should throw IOException in original code
                                                                                                     bzip2Stream.read(dest, 0, 5);
                                                                                                     
                                                                                                     // In mutant version, this won't throw exception, causing test to fail
                                                                                                 }

    @Test
                                                                                                 public void testReadWithNonNullStreamShouldNotThrowIOException1() throws IOException {
                                                                                                     // Create mock input stream
                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                     // Configure mock to return valid data
                                                                                                     when(mockInputStream.read()).thenReturn(1);
                                                                                                     
                                                                                                     // Create stream with valid input
                                                                                                     BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                     
                                                                                                     // Create destination buffer
                                                                                                     byte[] dest = new byte[10];
                                                                                                     
                                                                                                     // This should NOT throw exception in original code
                                                                                                     bzip2Stream.read(dest, 0, 5);
                                                                                                     
                                                                                                     // In mutant version, this would throw exception, causing test to fail
                                                                                                 }

    @Test(expected = IOException.class)
                                                                                             public void testReadWithNonNullStreamShouldNotThrowExceptionButMutantDoes() throws IOException {
                                                                                                 // Arrange
                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                                 byte[] dest = new byte[10];
                                                                                                 
                                                                                                 // Act
                                                                                                 // With original code, this should work fine since stream is not null
                                                                                                 // With mutated code (if(true)), this will always throw IOException
                                                                                                 bzIn.read(dest, 0, 5);
                                                                                                 
                                                                                                 // Assert
                                                                                                 // The @Test(expected) will verify the exception is thrown
                                                                                                 // For original code, we'd need another test to verify normal operation,
                                                                                                 // but this test specifically targets the mutant case
                                                                                             }

    @Test(expected = IOException.class)
                                                                                            public void testReadWithNullStreamShouldThrowException() throws IOException {
                                                                                                // Create stream with null input to simulate closed stream
                                                                                                BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(null);
                                                                                                
                                                                                                // This should throw IOException for original code
                                                                                                // Mutant would try to call read0() on null stream instead
                                                                                                bzip2Stream.read();
                                                                                            }

    @Test
                                                                                            public void testReadWithValidStreamShouldWork() throws IOException {
                                                                                                // Setup mock to return test data
                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                when(mockInputStream.read()).thenReturn(42);
                                                                                                
                                                                                                BZip2CompressorInputStream bzip2Stream = new BZip2CompressorInputStream(mockInputStream);
                                                                                                
                                                                                                // This should work for both original and mutant
                                                                                                int result = bzip2Stream.read();
                                                                                                assertEquals(42, result);
                                                                                            }

    @Test(expected = IOException.class)
                                                                                        public void testReadWithNullInputStreamShouldThrowIOException() throws IOException {
                                                                                            // Create instance with null input stream
                                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                            
                                                                                            // This should throw IOException in original code, but mutant will try to proceed
                                                                                            bzIn.read();
                                                                                        }

    @Test(expected = IOException.class)
                                                                                        public void testReadThrowsIOExceptionWhenStreamClosed6() throws Exception {
                                                                                            // Arrange
                                                                                            byte[] dest = new byte[10];
                                                                                            int offs = 0;
                                                                                            int len = 5;
                                                                                            
                                                                                            // Create instance with null input stream (simulating closed stream)
                                                                                            BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                            
                                                                                            // Act - should throw IOException
                                                                                            stream.read(dest, offs, len);
                                                                                            
                                                                                            // Assert - handled by expected exception in annotation
                                                                                        }

    @Test
                                                                                           public void testReadWhenStreamClosedThrowsCorrectException1() throws IOException {
                                                                                               // Create an instance with null input stream to simulate closed stream
                                                                                               BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                               
                                                                                               // Set expectation for the exception
                                                                                               thrown.expect(IOException.class);
                                                                                               thrown.expectMessage("stream closed");
                                                                                               
                                                                                               // Call read which should throw the exception
                                                                                               bzIn.read();
                                                                                           }

    @Test(expected = IOException.class)
                                                                                       public void testReadWhenStreamClosedThrowsCorrectException2() throws IOException {
                                                                                           // Arrange
                                                                                           byte[] dest = new byte[10];
                                                                                           int offs = 0;
                                                                                           int len = 5;
                                                                                           
                                                                                           // Create instance with null input stream to simulate closed stream
                                                                                           BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                           
                                                                                           try {
                                                                                               // Act
                                                                                               stream.read(dest, offs, len);
                                                                                           } catch (IOException e) {
                                                                                               // Assert
                                                                                               assertEquals("stream closed", e.getMessage());
                                                                                               throw e;
                                                                                           }
                                                                                       }

    @Test(expected = IOException.class)
                                                                                      public void testReadWhenStreamClosedThrowsIOException2() throws Exception {
                                                                                          // Create a BZip2CompressorInputStream with null input stream to simulate closed stream
                                                                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                          
                                                                                          try {
                                                                                              stream.read();
                                                                                          } catch (IOException e) {
                                                                                              // Verify the exception message matches the original
                                                                                              assertEquals("stream closed", e.getMessage());
                                                                                              throw e; // rethrow to satisfy @Test(expected)
                                                                                          }
                                                                                      }

    @Test
                                                                                     public void testReadThrowsIOExceptionWhenStreamClosed7() throws Exception {
                                                                                         // Prepare test data
                                                                                         byte[] dest = new byte[10];
                                                                                         int offs = 0;
                                                                                         int len = 5;
                                                                                         
                                                                                         // Create instance with null input stream to simulate closed stream
                                                                                         BZip2CompressorInputStream stream = new BZip2CompressorInputStream((InputStream) null);
                                                                                         
                                                                                         try {
                                                                                             // Call method that should throw
                                                                                             stream.read(dest, offs, len);
                                                                                             fail("Expected IOException");
                                                                                         } catch (IOException e) {
                                                                                             // Verify exception message
                                                                                             assertEquals("stream closed", e.getMessage());
                                                                                         }
                                                                                     }

    @Test(expected = IOException.class)
                                                                                 public void testReadWhenStreamClosedThrowsException4() throws IOException {
                                                                                     // Create a BZip2CompressorInputStream with null input stream to simulate closed stream
                                                                                     BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                                     
                                                                                     try {
                                                                                         // This should throw IOException
                                                                                         bzIn.read();
                                                                                     } catch (IOException e) {
                                                                                         // Verify the exception message
                                                                                         assertEquals("stream closed", e.getMessage());
                                                                                         throw e; // rethrow to satisfy @Test(expected)
                                                                                     }
                                                                                     
                                                                                     // If we get here, the method didn't throw (which would mean the mutant survived)
                                                                                     fail("Expected IOException not thrown");
                                                                                 }

    @Test(expected = IOException.class)
                                                                                 public void testReadWhenStreamClosedThrowsException5() throws IOException {
                                                                                     // Arrange
                                                                                     BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                     // Set the 'in' field to null to simulate closed stream
                                                                                     // Using reflection since the field is private
                                                                                     try {
                                                                                         Field inField = BZip2CompressorInputStream.class.getDeclaredField("in");
                                                                                         inField.setAccessible(true);
                                                                                         inField.set(stream, null);
                                                                                     } catch (Exception e) {
                                                                                         fail("Failed to set 'in' field to null via reflection");
                                                                                     }
                                                                                     
                                                                                     byte[] dest = new byte[10];
                                                                                     
                                                                                     // Act & Assert
                                                                                     // Should throw IOException with "stream closed" message
                                                                                     stream.read(dest, 0, 5);
                                                                                 }

    @Test(expected = IOException.class)
                                                                                 public void testReadWhenStreamClosedThrowsException6() throws IOException {
                                                                                     // Arrange
                                                                                     // Create stream with null input to simulate closed stream
                                                                                     BZip2CompressorInputStream stream = new BZip2CompressorInputStream(null);
                                                                                     byte[] dest = new byte[10];
                                                                                     
                                                                                     // Act & Assert
                                                                                     // Should throw IOException with "stream closed" message
                                                                                     stream.read(dest, 0, 5);
                                                                                 }

    @Test
                                                                                public void testReadWithZeroLength3() throws IOException {
                                                                                    // Create a mock InputStream that returns EOF (-1)
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    when(mockInputStream.read(any(byte[].class), anyInt(), eq(0))).thenReturn(-1);
                                                                                    
                                                                                    // Create the test object with our mock stream
                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                    
                                                                                    // Test reading with len=0
                                                                                    byte[] dest = new byte[10];
                                                                                    int result = bzIn.read(dest, 0, 0);
                                                                                    
                                                                                    // Verify the result and that the count was handled correctly
                                                                                    assertEquals(-1, result);  // Should return -1 for EOF
                                                                                    
                                                                                    // The mutant would incorrectly handle the zero-length case
                                                                                    // by not properly counting it as EOF
                                                                                    
                                                                                    // Additional verification that the stream was properly interacted with
                                                                                    verify(mockInputStream).read(any(byte[].class), eq(0), eq(0));
                                                                                }

    @Test
                                                                                public void testReadWithZeroLengthNonEOF() throws IOException {
                                                                                    // Create a mock InputStream that returns 0 (no bytes read but not EOF)
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    when(mockInputStream.read(any(byte[].class), anyInt(), eq(0))).thenReturn(0);
                                                                                    
                                                                                    // Create the test object with our mock stream
                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                    
                                                                                    // Test reading with len=0
                                                                                    byte[] dest = new byte[10];
                                                                                    int result = bzIn.read(dest, 0, 0);
                                                                                    
                                                                                    // Verify the result and that the count was handled correctly
                                                                                    assertEquals(0, result);  // Should return 0 for successful zero-length read
                                                                                    
                                                                                    // The mutant would incorrectly handle the zero-length case
                                                                                    // by not properly counting it as a successful read
                                                                                    
                                                                                    // Additional verification that the stream was properly interacted with
                                                                                    verify(mockInputStream).read(any(byte[].class), eq(0), eq(0));
                                                                                }

    @Test
                                                                                public void testReadWithZeroLengthShouldReturnZeroImmediately() throws IOException {
                                                                                    // Arrange
                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                    byte[] dest = new byte[10];
                                                                                    int offs = 0;
                                                                                    int len = 0;  // This is the key test case
                                                                                    
                                                                                    // Act
                                                                                    int result = bzIn.read(dest, offs, len);
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                    verify(mockInputStream, never()).read();  // Ensure no actual read occurred
                                                                                    verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                    
                                                                                    // Also verify dest array wasn't modified
                                                                                    byte[] expectedDest = new byte[10];
                                                                                    assertArrayEquals("Destination array should remain unchanged", expectedDest, dest);
                                                                                }

    @Test
                                                                               public void testReadWithZeroLength4() throws IOException {
                                                                                   // Create a mock input stream that returns EOF (-1)
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                   
                                                                                   // Create the test object with our mock stream
                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                   
                                                                                   // Test reading with len=0
                                                                                   byte[] buffer = new byte[10];
                                                                                   int result = bzIn.read(buffer, 0, 0);
                                                                                   
                                                                                   // Verify behavior
                                                                                   assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                   
                                                                                   // Verify no actual read was attempted on the underlying stream
                                                                                   verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                   
                                                                                   // Test with len=0 when stream is at EOF
                                                                                   result = bzIn.read(buffer, 0, 0);
                                                                                   assertEquals("Should still return 0 for zero-length read at EOF", 0, result);
                                                                               }

    @Test
                                                                               public void testReadWithZeroLengthShouldReturnImmediately2() throws IOException {
                                                                                   // Arrange
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                   byte[] dest = new byte[10];
                                                                                   int offs = 0;
                                                                                   int len = 0;  // Zero length case
                                                                                   
                                                                                   // Act
                                                                                   int result = bzIn.read(dest, offs, len);
                                                                                   
                                                                                   // Assert
                                                                                   assertEquals("Should return 0 for zero-length read", 0, result);
                                                                                   verify(mockInputStream, never()).read();  // Verify no stream interaction
                                                                                   verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                               }

    @Test
                                                                              public void testReadWithZeroLength5() throws IOException {
                                                                                  // Setup
                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                                  byte[] dest = new byte[10];
                                                                                  
                                                                                  // Test case 1: len == 0 (should return 0)
                                                                                  int result = bzIn.read(dest, 0, 0);
                                                                                  assertEquals(0, result);
                                                                                  
                                                                                  // Test case 2: len < 0 (should throw exception)
                                                                                  try {
                                                                                      bzIn.read(dest, 0, -1);
                                                                                      fail("Expected IndexOutOfBoundsException for negative length");
                                                                                  } catch (IndexOutOfBoundsException e) {
                                                                                      assertTrue(e.getMessage().contains("len(-1) < 0."));
                                                                                  }
                                                                                  
                                                                                  // Test case 3: len > 0 (normal operation)
                                                                                  when(mockInputStream.read()).thenReturn(65, 66, -1);
                                                                                  result = bzIn.read(dest, 0, 3);
                                                                                  assertEquals(2, result);  // Reads 2 bytes before EOF
                                                                                  assertEquals(65, dest[0]);
                                                                                  assertEquals(66, dest[1]);
                                                                              }

    @Test
                                                                             public void testReadWithZeroAndNegativeLength() throws IOException {
                                                                                 // Create a mock InputStream that returns -1 when read is called
                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                 when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                 
                                                                                 // Create the test object with our mock stream
                                                                                 BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                                 
                                                                                 // Test case 1: len = 0 (should skip processing)
                                                                                 byte[] buffer1 = new byte[10];
                                                                                 int result1 = bzipStream.read(buffer1, 0, 0);
                                                                                 assertEquals(0, result1);  // Should return 0 for zero-length read
                                                                                 verify(mockInputStream, never()).read(any(byte[].class), anyInt(), eq(0)); // Shouldn't call read
                                                                                 
                                                                                 // Test case 2: len = -1 (should process, but mutant would skip)
                                                                                 byte[] buffer2 = new byte[10];
                                                                                 try {
                                                                                     int result2 = bzipStream.read(buffer2, 0, -1);
                                                                                     // If we get here, the test fails (should throw exception for negative length)
                                                                                     fail("Expected IllegalArgumentException for negative length");
                                                                                 } catch (IllegalArgumentException e) {
                                                                                     // Expected behavior - negative length should be rejected
                                                                                 }
                                                                                 
                                                                                 // Test case 3: len = 1 (normal case)
                                                                                 byte[] buffer3 = new byte[10];
                                                                                 when(mockInputStream.read(any(byte[].class), anyInt(), eq(1))).thenReturn(1);
                                                                                 int result3 = bzipStream.read(buffer3, 0, 1);
                                                                                 assertEquals(1, result3);  // Should return 1 for successful read
                                                                                 verify(mockInputStream).read(any(byte[].class), anyInt(), eq(1));
                                                                             }

    @Test
                                                                         public void testReadWithDifferentLenValues() throws IOException {
                                                                             // Create a mock InputStream that returns test data
                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                             when(mockInputStream.read()).thenReturn(65); // 'A' character
                                                                             
                                                                             // Create the test object with the mock stream
                                                                             BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                             
                                                                             // Test case 1: len is 0
                                                                             try {
                                                                                 int result = bzipStream.read(new byte[10], 0, 0);
                                                                                 // Should return 0 when len is 0 (original behavior)
                                                                                 // Mutant would still try to read and count
                                                                                 assertEquals(0, result);
                                                                             } catch (IOException e) {
                                                                                 fail("Should not throw exception for len=0");
                                                                             }
                                                                             
                                                                             // Test case 2: len is not 0
                                                                             try {
                                                                                 int result = bzipStream.read(new byte[10], 0, 5);
                                                                                 // Should return the number of bytes read (1 in this case)
                                                                                 assertEquals(1, result);
                                                                             } catch (IOException e) {
                                                                                 fail("Should not throw exception for valid read");
                                                                             }
                                                                             
                                                                             // Verify the mock interactions
                                                                             verify(mockInputStream, times(1)).read();
                                                                         }

    @Test
                                                                         public void testReadWithZeroLengthShouldReturnZeroWithoutReading3() throws IOException {
                                                                             // Arrange
                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                             byte[] dest = new byte[10];
                                                                             
                                                                             // Act - test with len=0
                                                                             int result = bzIn.read(dest, 0, 0);
                                                                             
                                                                             // Assert
                                                                             assertEquals(0, result); // Should return 0 for zero-length read
                                                                             verify(mockInputStream, never()).read(); // Should not attempt any reading
                                                                         }

    @Test
                                                                         public void testReadWithNonZeroLengthShouldReadData() throws IOException {
                                                                             // Arrange
                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                             when(mockInputStream.read()).thenReturn(65); // Return 'A' when read
                                                                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                             byte[] dest = new byte[10];
                                                                             
                                                                             // Act - test with len>0
                                                                             int result = bzIn.read(dest, 0, 5);
                                                                             
                                                                             // Assert
                                                                             assertTrue(result > 0); // Should return number of bytes read
                                                                             verify(mockInputStream, atLeastOnce()).read(); // Should attempt reading
                                                                             // This will fail with the mutant since it will return 0 due to the if(true) condition
                                                                         }

    @Test
                                                                        public void testReadWithZeroLengthReturnsZero() throws IOException {
                                                                            // Setup
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                            byte[] dest = new byte[10];
                                                                            int offs = 0;
                                                                            int len = 0;  // This is the key to trigger the len==0 case
                                                                            
                                                                            // Execute
                                                                            int result = bzIn.read(dest, offs, len);
                                                                            
                                                                            // Verify
                                                                            assertEquals("Should return 0 when len=0", 0, result);
                                                                            
                                                                            // Verify no interaction with the stream occurred
                                                                            verifyZeroInteractions(mockInputStream);
                                                                            
                                                                            // Verify destination array wasn't modified
                                                                            for (byte b : dest) {
                                                                                assertEquals(0, b);
                                                                            }
                                                                        }

    @Test
                                                                   public void testReadReturnsZeroWhenRead0ReturnsZero2() throws Exception {
                                                                       // Setup
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                       
                                                                       // Create spy to verify interactions
                                                                       BZip2CompressorInputStream spyBzIn = spy(bzIn);
                                                                       
                                                                       // Mock private read0() method using reflection
                                                                       Method read0Method = BZip2CompressorInputStream.class.getDeclaredMethod("read0");
                                                                       read0Method.setAccessible(true);
                                                                       when(read0Method.invoke(spyBzIn)).thenReturn(0);
                                                                       
                                                                       // Execute
                                                                       int result = spyBzIn.read();
                                                                       
                                                                       // Verify
                                                                       assertEquals("Should return 0 when read0 returns 0", 0, result);
                                                                   }

    @Test
                                                               public void testReadReturnsActualValueFromStream() throws IOException {
                                                                   // Arrange
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   when(mockInputStream.read()).thenReturn(42); // Return a positive value
                                                                   
                                                                   BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                   
                                                                   // Act
                                                                   int result = bzipStream.read();
                                                                   
                                                                   // Assert
                                                                   assertEquals("Should return the actual value read from stream", 42, result);
                                                                   
                                                                   // Verify the count was incremented properly (bonus check)
                                                                   // This would require exposing the count method or adding a getter for testing purposes
                                                                   // Since we don't have visibility into the count method, we'll focus on the return value
                                                               }

    @Test
                                                               public void testReadWithZeroLengthShouldReturnZeroNotNegativeOne1() throws IOException {
                                                                   // Arrange
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   BZip2CompressorInputStream bzipStream = new BZip2CompressorInputStream(mockInputStream);
                                                                   byte[] dest = new byte[10];
                                                                   int offs = 0;
                                                                   int len = 0;  // This should trigger the len==0 case
                                                                   
                                                                   // Act
                                                                   int result = bzipStream.read(dest, offs, len);
                                                                   
                                                                   // Assert
                                                                   assertEquals("When len=0, method should return 0", 0, result);
                                                               }

    @Test
                                                              public void testReadDetectsReturnLenMutant() throws IOException {
                                                                  // Create a mock InputStream that returns 0 (simulating empty read)
                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                  when(mockInputStream.read()).thenReturn(0);
                                                                  
                                                                  // Create the test object with our mock stream
                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                  
                                                                  // Call the read method and verify the return value
                                                                  int result = bzIn.read();
                                                                  
                                                                  // The original code should return 0 (from read0()), but mutant would return len
                                                                  // We need to verify it returns exactly 0 to catch the mutant
                                                                  assertEquals("Should return 0 for empty read", 0, result);
                                                                  
                                                                  // Verify the count was called with 1 (since 0 >= 0)
                                                                  // This is an additional check to ensure proper counting behavior
                                                                  // Note: This assumes count() is accessible for verification or we can observe its effects
                                                                  // If count() is private, we might need to verify through other observable behavior
                                                                  
                                                                  // Test EOF case (-1 should be returned and counted as -1)
                                                                  when(mockInputStream.read()).thenReturn(-1);
                                                                  result = bzIn.read();
                                                                  assertEquals("Should return -1 for EOF", -1, result);
                                                                  
                                                                  // Test normal read case (return value > 0)
                                                                  when(mockInputStream.read()).thenReturn(65); // 'A'
                                                                  result = bzIn.read();
                                                                  assertEquals("Should return the byte value", 65, result);
                                                              }

    @Test(expected = IOException.class)
                                                              public void testReadThrowsWhenStreamClosed() throws IOException {
                                                                  // Create with null stream to simulate closed stream
                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(null);
                                                                  bzIn.read(); // Should throw IOException
                                                              }

    @Test
                                                              public void testReadWithZeroLengthShouldReturnZero5() throws IOException {
                                                                  // Arrange
                                                                  byte[] dest = new byte[10];
                                                                  int offs = 0;
                                                                  int len = 0;
                                                                  
                                                                  // Mock the input stream to return EOF immediately
                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                  when(mockInputStream.read()).thenReturn(-1); // EOF
                                                                  
                                                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                                  
                                                                  // Act
                                                                  int result = bzIn.read(dest, offs, len);
                                                                  
                                                                  // Assert
                                                                  assertEquals("Should return 0 when len=0", 0, result);
                                                                  
                                                                  // Verify no actual read occurred
                                                                  verify(mockInputStream, never()).read();
                                                              }

    @Test
                                                             public void testReadDetectsHiMutation() throws IOException {
                                                                 // Setup
                                                                 byte[] dest = new byte[10];
                                                                 int offs = 2;
                                                                 int len = 5;
                                                                 
                                                                 // Mock input stream that returns 5 bytes of data
                                                                 InputStream mockIn = mock(InputStream.class);
                                                                 when(mockIn.read()).thenReturn(1, 2, 3, 4, 5);
                                                                 
                                                                 // Create test instance with our mock stream
                                                                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                                                                 
                                                                 // Test
                                                                 int bytesRead = bzIn.read(dest, offs, len);
                                                                 
                                                                 // Verify
                                                                 // Original would read all 5 bytes, mutant would read 0 (since hi = offs - len = -3)
                                                                 assertEquals(5, bytesRead);
                                                                 
                                                                 // Verify bytes were written to correct positions
                                                                 assertEquals(1, dest[2]);
                                                                 assertEquals(2, dest[3]);
                                                                 assertEquals(3, dest[4]);
                                                                 assertEquals(4, dest[5]);
                                                                 assertEquals(5, dest[6]);
                                                                 
                                                                 // Verify no bytes were written beyond requested range
                                                                 assertEquals(0, dest[0]);
                                                                 assertEquals(0, dest[1]);
                                                                 assertEquals(0, dest[7]);
                                                                 assertEquals(0, dest[8]);
                                                                 assertEquals(0, dest[9]);
                                                                 
                                                                 // Verify exactly len bytes were requested from stream
                                                                 verify(mockIn, times(len)).read();
                                                             }

    @Test
                                                    public void testReadByteArrayWithOffsetAndLengthDetectsMutant() throws IOException {
                                                        // Setup test data
                                                        byte[] testData = new byte[100];
                                                        java.util.Arrays.fill(testData, (byte)1); // Fill with some data
                                                        InputStream mockInputStream = mock(InputStream.class);
                                                        when(mockInputStream.read(any(byte[].class), 
                                                                anyInt(), 
                                                                anyInt())).thenAnswer(invocation -> {
                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                            int off = (Integer) invocation.getArguments()[1];
                                                            int len = (Integer) invocation.getArguments()[2];
                                                            // Verify the bounds are correct
                                                            if (off < 0 || len < 0 || off + len > buf.length) {
                                                                throw new IndexOutOfBoundsException();
                                                            }
                                                            // Simulate reading some data
                                                            java.util.Arrays.fill(buf, off, off + len, (byte)2);
                                                            return len;
                                                        });
                                                     
                                                        // Create test object
                                                        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                     
                                                        // Test case that would fail with the mutant
                                                        byte[] dest = new byte[20];
                                                        int offset = 10;
                                                        int length = 5;
                                                        
                                                        // This would fail with the mutant because:
                                                        // Original: hi = 10 + 5 = 15 (valid)
                                                        // Mutant: hi = 10 - 5 = 5 (would cause incorrect bounds checking)
                                                        int bytesRead = bzIn.read(dest, offset, length);
                                                        
                                                        // Verify the read operation
                                                        assertEquals(length, bytesRead);
                                                        
                                                        // Verify the data was written to correct positions
                                                        for (int i = 0; i < offset; i++) {
                                                            assertEquals(0, dest[i]); // Unwritten portion should be 0
                                                        }
                                                        for (int i = offset; i < offset + length; i++) {
                                                            assertEquals(2, dest[i]); // Written portion should be 2
                                                        }
                                                        for (int i = offset + length; i < dest.length; i++) {
                                                            assertEquals(0, dest[i]); // Unwritten portion should be 0
                                                        }
                                                        
                                                        // Test edge case that would definitely fail with mutant
                                                        try {
                                                            bzIn.read(dest, 5, 10); // 5 + 10 = 15 < 20 (valid)
                                                            // With mutant: 5 - 10 = -5 (would cause exception)
                                                        } catch (IndexOutOfBoundsException e) {
                                                            fail("Mutant detected: read operation failed with valid bounds");
                                                        }
                                                    }

    @Test
                                                public void testReadWithLengthGreaterThanZeroShouldReadRequestedBytes() throws IOException {
                                                    // Setup
                                                    byte[] dest = new byte[10];
                                                    int offs = 2;
                                                    int len = 5;
                                                    
                                                    // Mock input stream that can provide enough bytes
                                                    InputStream mockInputStream = mock(InputStream.class);
                                                    when(mockInputStream.read()).thenReturn(1, 2, 3, 4, 5, -1);
                                                    
                                                    BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                    
                                                    // Execute
                                                    int bytesRead = bzIn.read(dest, offs, len);
                                                    
                                                    // Verify
                                                    assertEquals("Should read exactly len bytes", len, bytesRead);
                                                    
                                                    // Check that bytes were written to correct positions
                                                    assertEquals(1, dest[offs]);
                                                    assertEquals(2, dest[offs+1]);
                                                    assertEquals(3, dest[offs+2]);
                                                    assertEquals(4, dest[offs+3]);
                                                    assertEquals(5, dest[offs+4]);
                                                    
                                                    // Positions before offs and after offs+len should remain unchanged
                                                    assertEquals(0, dest[0]);
                                                    assertEquals(0, dest[1]);
                                                    assertEquals(0, dest[offs+len]);
                                                    assertEquals(0, dest[offs+len+1]);
                                                }

    @Test
                                               public void testReadWithOffsetAndLength2() throws IOException {
                                                   // Setup test data
                                                   byte[] testData = new byte[]{1, 2, 3, 4, 5, 6, 7, 8};
                                                   byte[] dest = new byte[10];
                                                   int offset = 2;
                                                   int length = 5;
                                                   
                                                   // Mock the input stream to return our test data
                                                   InputStream mockInputStream = mock(InputStream.class);
                                                   when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                                       .thenAnswer(invocation -> {
                                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                                           int off = (Integer) invocation.getArguments()[1];
                                                           int len = (Integer) invocation.getArguments()[2];
                                                           System.arraycopy(testData, 0, buf, off, Math.min(len, testData.length));
                                                           return Math.min(len, testData.length);
                                                       });
                                                   
                                                   // Create the test object
                                                   BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                                   
                                                   // Perform the read operation
                                                   int bytesRead = bzIn.read(dest, offset, length);
                                                   
                                                   // Verify the results
                                                   assertEquals(length, bytesRead); // Should read exactly 'length' bytes
                                                   
                                                   // Verify the data was placed in correct positions
                                                   for (int i = 0; i < length; i++) {
                                                       assertEquals(testData[i], dest[offset + i]);
                                                   }
                                                   
                                                   // Verify positions before offset are untouched (should be 0)
                                                   for (int i = 0; i < offset; i++) {
                                                       assertEquals(0, dest[i]);
                                                   }
                                                   
                                                   // Verify positions after offset+length are untouched (should be 0)
                                                   for (int i = offset + length; i < dest.length; i++) {
                                                       assertEquals(0, dest[i]);
                                                   }
                                               }

    @Test
                                      public void testReadWithOffsetDetectsHiMutation1() throws IOException {
                                          // Setup
                                          byte[] dest = new byte[10];
                                          int offs = 5;
                                          int len = 3;
                                          
                                          // Create mock InputStream that returns 3 bytes (1, 2, 3) then EOF
                                          InputStream mockInputStream = mock(InputStream.class);
                                          when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                              .thenAnswer(invocation -> {
                                                  Object[] args = invocation.getArguments();
                                                  byte[] b = (byte[]) args[0];
                                                  int off = (Integer) args[1];
                                                  b[off] = 1;
                                                  b[off+1] = 2;
                                                  b[off+2] = 3;
                                                  return 3;
                                              })
                                              .thenReturn(-1); // EOF
                                          
                                          // Create real BZip2CompressorInputStream with our mock
                                          BZip2CompressorInputStream stream = new BZip2CompressorInputStream(mockInputStream);
                                          
                                          // Test
                                          int bytesRead = stream.read(dest, offs, len);
                                          
                                          // Verify
                                          assertEquals(3, bytesRead);
                                          // Check data was written at correct offset
                                          assertEquals(1, dest[offs]);
                                          assertEquals(2, dest[offs+1]);
                                          assertEquals(3, dest[offs+2]);
                                          // Check no data was written before offset
                                          assertEquals(0, dest[offs-1]);
                                          // Check no data was written after offset+len
                                          assertEquals(0, dest[offs+len]);
                                          
                                          // This test would fail with the mutant because:
                                          // - Mutant would write to positions 0,1,2 instead of 5,6,7
                                          // - Would potentially write beyond array bounds if len > dest.length
                                      }

    @Test
                              public void testReadWithOffsetDetectsMutant2() throws IOException {
                                  // Setup test data
                                  byte[] testData = new byte[]{1, 2, 3, 4, 5};
                                  byte[] dest = new byte[10];
                                  int offset = 5;
                                  int length = 3;
                                  
                                  // Mock the input stream to return our test data
                                  InputStream mockInputStream = mock(InputStream.class);
                                  when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                                      .thenAnswer(invocation -> {
                                          byte[] buf = (byte[]) invocation.getArguments()[0];
                                          int off = (int) invocation.getArguments()[1];
                                          int len = (int) invocation.getArguments()[2];
                                          System.arraycopy(testData, 0, buf, off, Math.min(len, testData.length));
                                          return Math.min(len, testData.length);
                                      });
                                  
                                  // Create instance with our mock stream
                                  BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                                  
                                  // Call the method
                                  int bytesRead = bzIn.read(dest, offset, length);
                                  
                                  // Verify the results
                                  assertEquals("Should read correct number of bytes", 
                                      Math.min(length, testData.length), bytesRead);
                                  
                                  // Verify data was written at correct offset
                                  for (int i = 0; i < bytesRead; i++) {
                                      assertEquals("Data should be written at correct offset",
                                          testData[i], dest[offset + i]);
                                  }
                                  
                                  // Verify no data was written outside the specified range
                                  for (int i = 0; i < offset; i++) {
                                      assertEquals("No data should be written before offset",
                                          0, dest[i]);
                                  }
                                  for (int i = offset + bytesRead; i < dest.length; i++) {
                                      assertEquals("No data should be written after offset+length",
                                          0, dest[i]);
                                  }
                              }

    @Test
                         public void testReadWithOffsetShouldStartAtExactOffset() throws IOException {
                             // Setup
                             byte[] dest = new byte[10];
                             java.util.Arrays.fill(dest, (byte) 0xFF); // Fill with known value
                             InputStream mockInput = mock(InputStream.class);
                             when(mockInput.read()).thenReturn(0x41, 0x42, 0x43, -1); // Return 3 bytes then EOF
                             
                             BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInput);
                             int offset = 5;
                             int len = 3;
                             
                             // Execute
                             int bytesRead = bzIn.read(dest, offset, len);
                             
                             // Verify
                             assertEquals(3, bytesRead); // Should read all 3 bytes
                             
                             // Verify bytes were written starting at exact offset
                             assertEquals(0x41, dest[offset] & 0xFF);
                             assertEquals(0x42, dest[offset+1] & 0xFF);
                             assertEquals(0x43, dest[offset+2] & 0xFF);
                             
                             // Verify no bytes were written before offset
                             assertEquals((byte)0xFF, dest[offset-1]);
                             
                             // Verify no bytes were written after offset+len
                             if (offset + len < dest.length) {
                                 assertEquals((byte)0xFF, dest[offset+len]);
                             }
                             
                             // Verify mock interaction
                             verify(mockInput, times(4)).read(); // 3 bytes + EOF check
                         }

    @Test
                 public void testReadWithOffsetShouldWriteAtCorrectPosition3() throws IOException {
                     // Setup test data
                     byte[] testData = new byte[]{1, 2, 3, 4, 5};
                     byte[] dest = new byte[10];
                     int offs = 2;
                     int len = 3;
                     
                     // Initialize all bytes to -1 so we can detect writes
                     java.util.Arrays.fill(dest, (byte)-1);
                     
                     // Mock the InputStream to return our test data
                     InputStream mockIn = mock(InputStream.class);
                     when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                         Object[] args = invocation.getArguments();
                         byte[] b = (byte[]) args[0];
                         int offset = (int) args[1];
                         System.arraycopy(testData, 0, b, offset, Math.min(len, testData.length));
                         return len;
                     });
                     
                     // Create the test object with our mock stream
                     BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockIn);
                     
                     // Call the method under test
                     int bytesRead = bzIn.read(dest, offs, len);
                     
                     // Verify the results
                     assertEquals(len, bytesRead);
                     
                     // Check that data was written starting at correct offset
                     assertEquals(-1, dest[offs-1]); // Should not be written
                     assertEquals(1, dest[offs]);    // First byte should be here
                     assertEquals(2, dest[offs+1]);
                     assertEquals(3, dest[offs+2]);
                     assertEquals(-1, dest[offs+3]); // Should not be written
                 }

    @Test
             public void testReadWithOffsetShouldWriteDataAtCorrectPosition() throws IOException {
                 // Arrange
                 byte[] dest = new byte[10]; // Destination buffer
                 int offs = 5; // Non-zero offset
                 int len = 3; // Length to read
                 
                 // Mock the input stream to return some test data
                 InputStream mockInputStream = mock(InputStream.class);
                 when(mockInputStream.read()).thenReturn(65, 66, 67, -1); // ABC then EOF
                 
                 BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
                 
                 // Act
                 int bytesRead = bzIn.read(dest, offs, len);
                 
                 // Assert
                 assertEquals(3, bytesRead); // Should read 3 bytes
                 assertEquals(0, dest[offs-1]); // Byte before offset should remain 0
                 assertEquals(65, dest[offs]);   // First byte at offset
                 assertEquals(66, dest[offs+1]); // Second byte
                 assertEquals(67, dest[offs+2]); // Third byte
                 assertEquals(0, dest[offs+3]);  // Byte after read data should remain 0
                 
                 // Verify the mutated version would fail these assertions
                 // because it would write starting at index 0
             }

    @Test
    public void testReadWithOffset1() throws IOException {
        // Setup test data
        byte[] testData = new byte[]{1, 2, 3, 4, 5};
        byte[] dest = new byte[10];
        int offset = 3;
        
        // Mock the input stream to return our test data
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
            .thenAnswer(invocation -> {
                byte[] buf = (byte[]) invocation.getArguments()[0];
                int off = (int) invocation.getArguments()[1];
                System.arraycopy(testData, 0, buf, off, testData.length);
                return testData.length;
            });
        
        // Create the test object
        BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(mockInputStream);
        
        // Perform the read operation
        int bytesRead = bzIn.read(dest, offset, testData.length);
        
        // Verify the results
        assertEquals(testData.length, bytesRead);
        
        // Check that data was written at the correct offset
        for (int i = 0; i < testData.length; i++) {
            assertEquals(testData[i], dest[offset + i]);
        }
        
        // Verify that positions before offset are untouched
        for (int i = 0; i < offset; i++) {
            assertEquals(0, dest[i]);
        }
        
        // Verify that positions after data are untouched
        for (int i = offset + testData.length; i < dest.length; i++) {
            assertEquals(0, dest[i]);
        }
    }


}
