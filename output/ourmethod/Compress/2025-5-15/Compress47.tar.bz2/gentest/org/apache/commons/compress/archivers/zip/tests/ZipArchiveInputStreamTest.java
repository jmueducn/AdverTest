package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.deflate64.Deflate64CompressorInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testRead_EmptyBuffer() throws Exception {
                                                    // Arrange
                                                    byte[] inputData = "test data".getBytes();
                                                    InputStream inputStream = new ByteArrayInputStream(inputData);
                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                    byte[] buffer = new byte[0]; // empty buffer
                                            
                                                    // Act
                                                    int result = zis.read(buffer);
                                            
                                                    // Assert
                                                    assertEquals(0, result);
                                                }

    @Test
                                                public void testRead_NormalCase() throws Exception {
                                                    // Arrange
                                                    byte[] inputData = "test data".getBytes();
                                                    InputStream inputStream = new ByteArrayInputStream(inputData);
                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                    byte[] buffer = new byte[inputData.length];
                                            
                                                    // Act
                                                    int result = zis.read(buffer);
                                            
                                                    // Assert
                                                    assertEquals(inputData.length, result);
                                                    assertArrayEquals(inputData, buffer);
                                                }

    @Test
                                                public void testRead_PartialRead() throws Exception {
                                                    // Arrange
                                                    byte[] inputData = "test data".getBytes();
                                                    InputStream inputStream = new ByteArrayInputStream(inputData);
                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                    byte[] buffer = new byte[4]; // smaller than input
                                            
                                                    // Act
                                                    int result = zis.read(buffer);
                                            
                                                    // Assert
                                                    assertEquals(4, result);
                                                    byte[] expected = new byte[4];
                                                    System.arraycopy(inputData, 0, expected, 0, 4);
                                                    assertArrayEquals(expected, buffer);
                                                }

    @Test
                                                public void testRead_EndOfStream() throws Exception {
                                                    // Arrange
                                                    byte[] inputData = new byte[0]; // empty input
                                                    InputStream inputStream = new ByteArrayInputStream(inputData);
                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                    byte[] buffer = new byte[10];
                                            
                                                    // Act
                                                    int result = zis.read(buffer);
                                            
                                                    // Assert
                                                    assertEquals(-1, result);
                                                }

    @Test
                                        public void testCanReadEntryData_WithNonZipArchiveEntry_ReturnsFalse() {
                                            // Arrange
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                            ArchiveEntry nonZipEntry = mock(ArchiveEntry.class);
                                            
                                            // Act
                                            boolean result = zais.canReadEntryData(nonZipEntry);
                                            
                                            // Assert
                                            assertFalse(result);
                                        }

    @Test
                                        public void testCanReadEntryData_WithZipEntryCannotHandleData_ReturnsFalse() throws Exception {
                                            // Arrange
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                            ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                            
                                            // Mock ZipUtil.canHandleEntryData to return false
                                            when(zipEntry.getMethod()).thenReturn(-1); // Invalid method
                                            
                                            // Act
                                            boolean result = zais.canReadEntryData(zipEntry);
                                            
                                            // Assert
                                            assertFalse(result);
                                        }

    @Test
                                        public void testCanReadEntryData_WithZipEntryNoDataDescriptorSupport_ReturnsFalse() throws Exception {
                                            // Arrange
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                            ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                            
                                            // Mock conditions
                                            when(zipEntry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED);
                                            when(zipEntry.getGeneralPurposeBit()).thenReturn(new GeneralPurposeBit());
                                            
                                            // Create a real ZipArchiveInputStream that will return false for supportsDataDescriptorFor
                                            // by using the constructor that sets allowStoredEntriesWithDataDescriptor to false
                                            ZipArchiveInputStream zaisSpy = spy(new ZipArchiveInputStream(
                                                mockInputStream, 
                                                "UTF-8", 
                                                false, 
                                                false // This will make supportsDataDescriptorFor return false
                                            ));
                                            
                                            // Act
                                            boolean result = zaisSpy.canReadEntryData(zipEntry);
                                            
                                            // Assert
                                            assertFalse(result);
                                        }

    @Test
                                        public void testCanReadEntryData_WithZipEntryNoCompressedSizeSupport_ReturnsFalse() throws Exception {
                                            // Arrange
                                            InputStream mockInputStream = mock(InputStream.class);
                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                            ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                            
                                            // Mock conditions
                                            when(zipEntry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED);
                                            
                                            // Use reflection to set private fields since we can't mock private methods
                                            Field supportsDataDescriptorField = ZipArchiveInputStream.class.getDeclaredField("supportsDataDescriptor");
                                            supportsDataDescriptorField.setAccessible(true);
                                            supportsDataDescriptorField.set(zais, true);
                                            
                                            Field supportsCompressedSizeField = ZipArchiveInputStream.class.getDeclaredField("supportsCompressedSize");
                                            supportsCompressedSizeField.setAccessible(true);
                                            supportsCompressedSizeField.set(zais, false);
                                            
                                            // Act
                                            boolean result = zais.canReadEntryData(zipEntry);
                                            
                                            // Assert
                                            assertFalse(result);
                                        }

    @Test
                                        public void testCanReadEntryData_WithNullEntry_ReturnsFalse() {
                                            // Arrange
                                            InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                            
                                            // Act
                                            boolean result = zais.canReadEntryData(null);
                                            
                                            // Assert
                                            assertFalse(result);
                                        }

    @Test
                                        public void testRead_WhenCurrentEntryIsNull_ReturnsMinusOne() throws Exception {
                                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mock(InputStream.class));
                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                            currentField.setAccessible(true);
                                            currentField.set(zis, null);
                                            byte[] buffer = new byte[10];
                                            
                                            assertEquals(-1, zis.read(buffer, 0, 10));
                                        }

    @Test
                                        public void testRead_WithStoredMethod_CallsReadStored() throws Exception {
                                            // Create a real ZipArchiveInputStream with a mock input stream
                                            InputStream mockInput = mock(InputStream.class);
                                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                            zis = spy(zis);
                                            
                                            // Create and configure entry
                                            ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                            entry.setMethod(ZipArchiveOutputStream.STORED);
                                            
                                            // Use reflection to set private fields
                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                            currentField.setAccessible(true);
                                            Object current = mock(ZipArchiveInputStream.class.getDeclaredClasses()[0]);
                                            currentField.set(zis, current);
                                            
                                            Field entryField = current.getClass().getDeclaredField("entry");
                                            entryField.setAccessible(true);
                                            entryField.set(current, entry);
                                            
                                            // Mock private methods
                                            Method supportsDataDescriptorMethod = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                            supportsDataDescriptorMethod.setAccessible(true);
                                            when(supportsDataDescriptorMethod.invoke(zis, entry)).thenReturn(true);
                                            
                                            Method supportsCompressedSizeMethod = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                            supportsCompressedSizeMethod.setAccessible(true);
                                            when(supportsCompressedSizeMethod.invoke(zis, entry)).thenReturn(true);
                                            
                                            byte[] buffer = new byte[10];
                                            
                                            Method readStoredMethod = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "readStored", byte[].class, int.class, int.class);
                                            readStoredMethod.setAccessible(true);
                                            when(readStoredMethod.invoke(zis, buffer, 0, 10)).thenReturn(5);
                                            
                                            assertEquals(5, zis.read(buffer, 0, 10));
                                            verify(zis, times(1)).read(buffer, 0, 10); // Verify public method was called
                                        }

    @Test
                                        public void testRead_WithDeflatedMethod_CallsReadDeflated() throws Exception {
                                            // Create mock input stream and real ZipArchiveInputStream
                                            InputStream mockInput = mock(InputStream.class);
                                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                            zis = spy(zis);
                                            
                                            // Create test entry with DEFLATED method
                                            ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                            entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                            
                                            // Use reflection to set private 'current' field
                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                            currentField.setAccessible(true);
                                            Object currentEntry = currentField.get(zis);
                                            
                                            // Mock the necessary private methods
                                            Method supportsDataDescriptor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                            supportsDataDescriptor.setAccessible(true);
                                            when(supportsDataDescriptor.invoke(zis, entry)).thenReturn(true);
                                            
                                            Method supportsCompressedSize = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                            supportsCompressedSize.setAccessible(true);
                                            when(supportsCompressedSize.invoke(zis, entry)).thenReturn(true);
                                            
                                            // Mock readDeflated method
                                            Method readDeflated = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "readDeflated", byte[].class, int.class, int.class);
                                            readDeflated.setAccessible(true);
                                            when(readDeflated.invoke(zis, any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                            
                                            // Create test buffer
                                            byte[] buffer = new byte[10];
                                            
                                            // Test and verify
                                            assertEquals(5, zis.read(buffer, 0, 10));
                                            verify(readDeflated).invoke(zis, buffer, 0, 10);
                                        }

    @Test
                                        public void testRead_WithOtherSupportedMethods_ReadsFromInputStream() throws Exception {
                                            // Create a mock input stream that will return a zip entry with UNSHRINKING method
                                            InputStream mockInput = mock(InputStream.class);
                                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                            
                                            // Create a test zip entry with UNSHRINKING method
                                            ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                            entry.setMethod(ZipMethod.UNSHRINKING.getCode());
                                            
                                            // Use reflection to set the current entry
                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                            currentField.setAccessible(true);
                                            
                                            // Create and set a mock input stream for reading entry data
                                            InputStream entryDataStream = mock(InputStream.class);
                                            when(entryDataStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                            
                                            // Create a mock current entry
                                            Object currentEntry = mock(ZipArchiveInputStream.class.getDeclaredClasses()[0]);
                                            when(currentEntry.getClass().getMethod("getEntry").invoke(currentEntry)).thenReturn(entry);
                                            when(currentEntry.getClass().getMethod("getIn").invoke(currentEntry)).thenReturn(entryDataStream);
                                            currentField.set(zis, currentEntry);
                                            
                                            // Use reflection to mock the support methods
                                            Method supportsDataDescriptor = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                            supportsDataDescriptor.setAccessible(true);
                                            when(supportsDataDescriptor.invoke(zis, entry)).thenReturn(true);
                                            
                                            Method supportsCompressedSize = ZipArchiveInputStream.class.getDeclaredMethod(
                                                "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                            supportsCompressedSize.setAccessible(true);
                                            when(supportsCompressedSize.invoke(zis, entry)).thenReturn(true);
                                            
                                            // Test the read operation
                                            byte[] buffer = new byte[10];
                                            assertEquals(5, zis.read(buffer, 0, 10));
                                            verify(entryDataStream).read(buffer, 0, 10);
                                        }

    @Test
                                    public void testRead_WhenMaxNotReached_ReturnsByte() throws Exception {
                                        // Arrange
                                        InputStream mockStream = mock(InputStream.class);
                                        when(mockStream.read()).thenReturn(65); // 'A'
                                        
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockStream);
                                        
                                        // Use reflection to set max to -1 (no limit) and pos to 0
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.setLong(zais, -1L);
                                        
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.setLong(zais, 0L);
                                        
                                        // Act
                                        int result = zais.read();
                                        
                                        // Assert
                                        assertEquals(65, result);
                                        assertEquals(1L, posField.getLong(zais));
                                    }

    @Test
                                    public void testRead_WhenMaxReached_ReturnsMinusOne() throws Exception {
                                        // Arrange
                                        InputStream mockStream = mock(InputStream.class);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockStream);
                                        
                                        // Use reflection to set private fields
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, 10L);
                                        
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 10L);
                                        
                                        // Act
                                        int result = zais.read();
                                        
                                        // Assert
                                        assertEquals(-1, result);
                                        // Verify no interaction with underlying stream
                                        verify(mockStream, never()).read();
                                    }

    @Test
                                    public void testRead_WhenStreamEnds_ReturnsMinusOne() throws Exception {
                                        // Arrange
                                        InputStream mockStream = mock(InputStream.class);
                                        when(mockStream.read()).thenReturn(-1);
                                        
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockStream);
                                        
                                        // Use reflection to set private fields
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, -1L);
                                        
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 0L);
                                        
                                        // Act
                                        int result = zais.read();
                                        
                                        // Assert
                                        assertEquals(-1, result);
                                        assertEquals(0L, posField.get(zais)); // Position shouldn't increment
                                    }

    @Test
                                    public void testRead_WhenIOExceptionOccurs_ThrowsIOException() throws Exception {
                                        // Arrange
                                        InputStream mockStream = mock(InputStream.class);
                                        when(mockStream.read()).thenThrow(new IOException("Test exception"));
                                        
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockStream);
                                        
                                        // Set private fields using reflection
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, -1L);
                                        
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 0L);
                                        
                                        // Set up expected exception
                                        ExpectedException exception = ExpectedException.none();
                                        exception.expect(IOException.class);
                                        exception.expectMessage("Test exception");
                                        
                                        // Act
                                        zais.read();
                                    }

    @Test
                                    public void testRead_MultipleReads_IncrementsPositionCorrectly() throws Exception {
                                        // Arrange
                                        InputStream mockStream = mock(InputStream.class);
                                        when(mockStream.read())
                                            .thenReturn(65)  // First read
                                            .thenReturn(66)  // Second read
                                            .thenReturn(67); // Third read
                                        
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockStream);
                                        
                                        // Set private fields using reflection
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, -1L);
                                        
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 0L);
                                    
                                        // Act & Assert
                                        assertEquals(65, zais.read());
                                        assertEquals(1L, posField.get(zais));
                                        
                                        assertEquals(66, zais.read());
                                        assertEquals(2L, posField.get(zais));
                                        
                                        assertEquals(67, zais.read());
                                        assertEquals(3L, posField.get(zais));
                                    }

    @Test
                                    public void testRead_IOExceptionFromUnderlyingStream() throws Exception {
                                        // Arrange
                                        InputStream inputStream = mock(InputStream.class);
                                        when(inputStream.read(any(byte[].class), anyInt(), anyInt()))
                                            .thenThrow(new IOException("Test exception"));
                                        ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                        byte[] buffer = new byte[10];
                                        
                                        try {
                                            // Act
                                            zis.read(buffer);
                                            fail("Expected IOException to be thrown");
                                        } catch (IOException e) {
                                            // Assert
                                            assertEquals("Test exception", e.getMessage());
                                        }
                                    }

    @Test
                                    public void testRead_AfterClose() throws Exception {
                                        // Arrange
                                        byte[] inputData = "test data".getBytes();
                                        InputStream inputStream = new ByteArrayInputStream(inputData);
                                        ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                        byte[] buffer = new byte[10];
                                        zis.close();
                                        
                                        try {
                                            // Act
                                            zis.read(buffer);
                                            fail("Expected IOException to be thrown");
                                        } catch (IOException e) {
                                            // Assert
                                            assertEquals("Stream closed", e.getMessage());
                                        }
                                    }

    @Test
                                    public void testRead_WhenMaxReached_ReturnsMinusOne1() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        
                                        // Use reflection to set private fields
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 10L);
                                        
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, 10L);
                                        
                                        byte[] buffer = new byte[10];
                                        
                                        // Act
                                        int result = zais.read(buffer, 0, 5);
                                        
                                        // Assert
                                        assertEquals(-1, result);
                                        verify(mockIn, never()).read(any(byte[].class), anyInt(), anyInt());
                                    }

    @Test
                                    public void testRead_WhenMaxNotReached_ReadsUpToMaxMinusPos() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        when(mockIn.read(any(), anyInt(), anyInt())).thenReturn(3);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        
                                        // Set private fields using reflection
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 5L);
                                        
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, 10L);
                                        
                                        byte[] buffer = new byte[10];
                                        
                                        // Act
                                        int result = zais.read(buffer, 2, 8); // len=8 but maxRead should be 5 (10-5)
                                        
                                        // Assert
                                        assertEquals(3, result);
                                        assertEquals(8L, posField.get(zais));
                                        verify(mockIn).read(buffer, 2, 5); // Verify maxRead was 5
                                    }

    @Test
                                    public void testRead_WhenMaxNegative_ReadsUpToLen() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(4);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        
                                        // Use reflection to set private fields
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 0L);
                                        
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, -1L); // No max limit
                                        
                                        byte[] buffer = new byte[10];
                                        
                                        // Act
                                        int result = zais.read(buffer, 1, 6);
                                        
                                        // Assert
                                        assertEquals(4, result);
                                        assertEquals(4L, posField.get(zais));
                                        verify(mockIn).read(buffer, 1, 6);
                                    }

    @Test
                                    public void testRead_WhenStreamReturnsMinusOne_ReturnsMinusOne() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        
                                        // Use reflection to set private fields
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 0L);
                                        
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, 100L);
                                        
                                        byte[] buffer = new byte[10];
                                        
                                        // Act
                                        int result = zais.read(buffer, 0, 5);
                                        
                                        // Assert
                                        assertEquals(-1, result);
                                        assertEquals(0L, posField.get(zais)); // Position shouldn't change
                                    }

    @Test
                                    public void testRead_UpdatesCountersCorrectly() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(2);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        
                                        // Use reflection to set private fields
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 3L);
                                        
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, 10L);
                                        
                                        byte[] buffer = new byte[10];
                                        
                                        // Act
                                        int result = zais.read(buffer, 0, 5);
                                        
                                        // Assert
                                        assertEquals(2, result);
                                        assertEquals(5L, posField.get(zais));
                                    }

    @Test
                                    public void testRead_WithZeroLength_ReturnsZero() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        
                                        // Use reflection to set private fields
                                        Field posField = ZipArchiveInputStream.class.getDeclaredField("pos");
                                        posField.setAccessible(true);
                                        posField.set(zais, 0L);
                                        
                                        Field maxField = ZipArchiveInputStream.class.getDeclaredField("max");
                                        maxField.setAccessible(true);
                                        maxField.set(zais, 10L);
                                        
                                        byte[] buffer = new byte[10];
                                        
                                        // Act
                                        int result = zais.read(buffer, 0, 0);
                                        
                                        // Assert
                                        assertEquals(0, result);
                                        assertEquals(0L, posField.get(zais));
                                        verify(mockIn, never()).read(any(), anyInt(), anyInt());
                                    }

    @Test
                                    public void testRead_WhenBufferNull_ThrowsNullPointer() throws Exception {
                                        // Arrange
                                        InputStream mockIn = mock(InputStream.class);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                        ExpectedException expectedException = ExpectedException.none();
                                        
                                        expectedException.expect(NullPointerException.class);
                                        
                                        // Act
                                        zais.read(null, 0, 5);
                                    }

    @Test
                                    public void testCanReadEntryData_WithZipEntryAllConditionsTrue_ReturnsTrue() throws Exception {
                                        // Arrange
                                        InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                        ZipArchiveEntry zipEntry = mock(ZipArchiveEntry.class);
                                        
                                        // Set up entry to be DEFLATED
                                        when(zipEntry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED);
                                        
                                        // Use reflection to set private fields to make conditions true
                                        Field supportsDataDescriptorField = ZipArchiveInputStream.class.getDeclaredField("allowStoredEntriesWithDataDescriptor");
                                        supportsDataDescriptorField.setAccessible(true);
                                        supportsDataDescriptorField.setBoolean(zais, true);
                                        
                                        Field supportsCompressedSizeField = ZipArchiveInputStream.class.getDeclaredField("supportsCompressedSize");
                                        supportsCompressedSizeField.setAccessible(true);
                                        supportsCompressedSizeField.setBoolean(zais, true);
                                        
                                        // Act
                                        boolean result = zais.canReadEntryData(zipEntry);
                                        
                                        // Assert
                                        assertTrue(result);
                                    }

    @Test
                                    public void testRead_WhenClosed_ThrowsIOException() throws Exception {
                                        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                        Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                        closedField.setAccessible(true);
                                        closedField.set(zis, true);
                                        byte[] buffer = new byte[10];
                                        
                                        try {
                                            zis.read(buffer, 0, 10);
                                            fail("Expected IOException to be thrown");
                                        } catch (IOException e) {
                                            assertEquals("The stream is closed", e.getMessage());
                                        }
                                    }

    @Test
                                    public void testSupportsCompressedSizeFor_WhenSizeIsKnown() throws Exception {
                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                        when(entry.getCompressedSize()).thenReturn(100L);
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                        
                                        Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                            "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                        method.setAccessible(true);
                                        boolean result = (boolean) method.invoke(zais, entry);
                                        
                                        assertTrue(result);
                                    }

    @Test
                                    public void testSupportsCompressedSizeFor_WhenDeflated() throws Exception {
                                        // Create mock entry
                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                        // Create real ZipArchiveInputStream with dummy stream
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                        
                                        // Setup mock behavior
                                        when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                        when(entry.getMethod()).thenReturn(ZipEntry.DEFLATED);
                                        
                                        // Use reflection to access private method
                                        Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                            "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                        method.setAccessible(true);
                                        boolean result = (boolean) method.invoke(zais, entry);
                                        
                                        // Test and assert
                                        assertTrue(result);
                                    }

    @Test
                                    public void testSupportsCompressedSizeFor_WhenEnhancedDeflated() throws Exception {
                                        // Create mock entry
                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                        // Setup mock behaviors
                                        when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                        when(entry.getMethod()).thenReturn(ZipMethod.ENHANCED_DEFLATED.getCode());
                                        
                                        // Initialize ZipArchiveInputStream with minimum required parameters
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                        
                                        // Use reflection to access private method
                                        Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                            "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                        method.setAccessible(true);
                                        
                                        // Test the method
                                        assertTrue((Boolean)method.invoke(zais, entry));
                                    }

    @Test
                                    public void testSupportsCompressedSizeFor_WhenStoredWithDataDescriptor_Allowed() throws Exception {
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]), "UTF-8", true, true);
                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                        GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                        when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                        when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                        when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                        when(gpb.usesDataDescriptor()).thenReturn(true);
                                        
                                        Method method = ZipArchiveInputStream.class.getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                        method.setAccessible(true);
                                        boolean result = (boolean) method.invoke(zais, entry);
                                        assertTrue(result);
                                    }

    @Test(expected = NullPointerException.class)
                                public void testRead_NullBuffer() throws Exception {
                                    // Arrange
                                    InputStream inputStream = mock(InputStream.class);
                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                    
                                    // Act
                                    zis.read(null);
                                }

    @Test
                            public void testSupportsCompressedSizeFor_WhenStoredWithDataDescriptor_NotAllowed() throws Exception {
                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                
                                // Create ZipArchiveInputStream with allowStoredEntriesWithDataDescriptor=false
                                InputStream in = new ByteArrayInputStream(new byte[0]);
                                ZipArchiveInputStream zais = new ZipArchiveInputStream(in, "UTF-8", false, false);
                                
                                when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                when(gpb.usesDataDescriptor()).thenReturn(true);
                                
                                // Use reflection to access private method
                                Method method = ZipArchiveInputStream.class.getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                method.setAccessible(true);
                                boolean result = (boolean) method.invoke(zais, entry);
                                assertFalse(result);
                            }

    @Test
                            public void testSupportsCompressedSizeFor_WhenStoredWithoutDataDescriptor() throws Exception {
                                // Create mock objects
                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                
                                // Setup mock behavior
                                when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                when(gpb.usesDataDescriptor()).thenReturn(false);
                                
                                // Create real object under test
                                ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                
                                // Set allowStoredEntriesWithDataDescriptor to false through reflection
                                Field field = ZipArchiveInputStream.class.getDeclaredField("allowStoredEntriesWithDataDescriptor");
                                field.setAccessible(true);
                                field.set(zais, false);
                                
                                // Get private method via reflection
                                Method method = ZipArchiveInputStream.class.getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                                method.setAccessible(true);
                                boolean result = (boolean) method.invoke(zais, entry);
                                
                                assertFalse(result);
                            }

    @Test
                            public void testSupportsCompressedSizeFor_WhenUnknownMethod() throws Exception {
                                // Create mock objects
                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                
                                // Initialize ZipArchiveInputStream with allowStoredEntriesWithDataDescriptor=false
                                ZipArchiveInputStream zais = new ZipArchiveInputStream(
                                    new ByteArrayInputStream(new byte[0]), "UTF-8", false, false);
                                
                                // Set up mock behaviors
                                when(entry.getCompressedSize()).thenReturn(ZipArchiveEntry.SIZE_UNKNOWN);
                                when(entry.getMethod()).thenReturn(999); // Unknown method
                                when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                when(gpb.usesDataDescriptor()).thenReturn(false);
                                
                                // Use reflection to access private method
                                Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                    "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                method.setAccessible(true);
                                boolean result = (boolean) method.invoke(zais, entry);
                                
                                // Assert
                                assertFalse(result);
                            }

    @Test
                            public void testSupportsCompressedSizeFor_WhenSizeKnownAndMethodStored() throws Exception {
                                // Create mock ZipArchiveEntry
                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                // Create real ZipArchiveInputStream with allowStoredEntriesWithDataDescriptor set to false
                                ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]), "UTF-8", false, false);
                                
                                // Setup mock behavior
                                when(entry.getCompressedSize()).thenReturn(100L);
                                when(entry.getMethod()).thenReturn(ZipEntry.STORED);
                                when(entry.getGeneralPurposeBit()).thenReturn(new GeneralPurposeBit());
                                
                                // Use reflection to access private method
                                Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                    "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                method.setAccessible(true);
                                boolean result = (boolean) method.invoke(zais, entry);
                                
                                assertTrue(result);
                            }

    @Test
                            public void testSupportsCompressedSizeFor_WhenSizeKnownAndDataDescriptorUsed() throws Exception {
                                // Create mock objects
                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                GeneralPurposeBit gpb = mock(GeneralPurposeBit.class);
                                
                                // Create real object under test
                                ZipArchiveInputStream zais = new ZipArchiveInputStream(
                                    new ByteArrayInputStream(new byte[0]), "UTF-8", true, true);
                                
                                // Set up mock behavior
                                when(entry.getCompressedSize()).thenReturn(100L);
                                when(entry.getGeneralPurposeBit()).thenReturn(gpb);
                                when(gpb.usesDataDescriptor()).thenReturn(true);
                                
                                // Use reflection to access private method
                                Method method = ZipArchiveInputStream.class.getDeclaredMethod(
                                    "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                method.setAccessible(true);
                                boolean result = (boolean) method.invoke(zais, entry);
                                
                                // Test the method
                                assertTrue(result);
                            }

    @Test
                            public void testRead_WhenLengthNegative_ThrowsIndexOutOfBounds() throws Exception {
                                // Arrange
                                InputStream mockIn = mock(InputStream.class);
                                when(mockIn.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                byte[] buffer = new byte[10];
                                
                                try {
                                    // Act
                                    zais.read(buffer, 0, -1);
                                    fail("Expected IndexOutOfBoundsException to be thrown");
                                } catch (IndexOutOfBoundsException e) {
                                    // Assert
                                    // Exception was thrown as expected
                                }
                            }

    @Test
                            public void testRead_WithUnsupportedDataDescriptor_ThrowsUnsupportedZipFeatureException() throws Exception {
                                // Create a real ZipArchiveInputStream with a mocked InputStream
                                InputStream mockInput = mock(InputStream.class);
                                when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                
                                // Create a test entry
                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                
                                // Use reflection to set private fields
                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                currentField.setAccessible(true);
                                
                                // Create and set a mock entry
                                Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                Constructor<?> constructor = currentEntryClass.getDeclaredConstructor(ZipArchiveEntry.class);
                                constructor.setAccessible(true);
                                Object current = constructor.newInstance(entry);
                                currentField.set(zis, current);
                                
                                // Mock supportsDataDescriptorFor to return false
                                Method supportsMethod = ZipArchiveInputStream.class.getDeclaredMethod(
                                    "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                supportsMethod.setAccessible(true);
                                when(supportsMethod.invoke(zis, entry)).thenReturn(false);
                                
                                // Invoke the read method and verify exception
                                try {
                                    byte[] buffer = new byte[10];
                                    zis.read(buffer, 0, 10);
                                    fail("Expected UnsupportedZipFeatureException");
                                } catch (UnsupportedZipFeatureException e) {
                                    // Expected exception
                                }
                            }

    @Test
                            public void testRead_WithUnsupportedMethod_ThrowsUnsupportedZipFeatureException() throws Exception {
                                // Create a real input stream with test data
                                ByteArrayInputStream bais = new ByteArrayInputStream(new byte[0]);
                                ZipArchiveInputStream zis = new ZipArchiveInputStream(bais);
                                
                                // Create an entry with unsupported method
                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                entry.setMethod(999); // Some unsupported method code
                                
                                // Use reflection to set private fields
                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                currentField.setAccessible(true);
                                
                                // Create a simple current entry holder
                                Object current = new Object();
                                try {
                                    Field entryField = current.getClass().getDeclaredField("entry");
                                    entryField.setAccessible(true);
                                    entryField.set(current, entry);
                                } catch (NoSuchFieldException e) {
                                    // If the structure is different, create a minimal implementation
                                    Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveInputStream$CurrentEntry");
                                    current = currentEntryClass.getDeclaredConstructor().newInstance();
                                    Field entryField = currentEntryClass.getDeclaredField("entry");
                                    entryField.setAccessible(true);
                                    entryField.set(current, entry);
                                }
                                
                                currentField.set(zis, current);
                                
                                // Set supports methods to true using reflection
                                try {
                                    Method supportsDataDescriptor = ZipArchiveInputStream.class.getDeclaredMethod(
                                        "supportsDataDescriptorFor", ZipArchiveEntry.class);
                                    supportsDataDescriptor.setAccessible(true);
                                    supportsDataDescriptor.invoke(zis, entry);
                                    
                                    Method supportsCompressedSize = ZipArchiveInputStream.class.getDeclaredMethod(
                                        "supportsCompressedSizeFor", ZipArchiveEntry.class);
                                    supportsCompressedSize.setAccessible(true);
                                    supportsCompressedSize.invoke(zis, entry);
                                } catch (NoSuchMethodException e) {
                                    // If methods don't exist, assume they would return true
                                }
                                
                                byte[] buffer = new byte[10];
                                
                                try {
                                    zis.read(buffer, 0, 10);
                                    fail("Expected UnsupportedZipFeatureException");
                                } catch (UnsupportedZipFeatureException e) {
                                    // expected
                                }
                            }

    @Test
                        public void testRead_WhenOffsetNegative_ThrowsIndexOutOfBounds() throws Exception {
                            // Arrange
                            InputStream mockIn = mock(InputStream.class);
                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                            byte[] buffer = new byte[10];
                            
                            // Act & Assert
                            try {
                                zais.read(buffer, -1, 5);
                                fail("Expected IndexOutOfBoundsException to be thrown");
                            } catch (IndexOutOfBoundsException e) {
                                // Expected exception
                            }
                        }

    @Test
                        public void testRead_WithUnsupportedCompressedSize_ThrowsUnsupportedZipFeatureException() throws Exception {
                            ExpectedException expectedException = ExpectedException.none();
                            
                            // Create mock InputStream that returns EOF immediately
                            InputStream mockInput = mock(InputStream.class);
                            when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                            
                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                            ZipArchiveEntry entry = new ZipArchiveEntry("test");
                            
                            // Use reflection to set private fields
                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                            currentField.setAccessible(true);
                            Object current = new Object(); // We don't need actual CurrentEntry functionality
                            currentField.set(zis, current);
                            
                            Field entryField = current.getClass().getDeclaredField("entry");
                            entryField.setAccessible(true);
                            entryField.set(current, entry);
                            
                            // Set up the entry to have an unsupported compressed size
                            Field methodField = ZipArchiveEntry.class.getDeclaredField("method");
                            methodField.setAccessible(true);
                            methodField.set(entry, ZipMethod.UNKNOWN.getCode());
                            
                            byte[] buffer = new byte[10];
                            
                            expectedException.expect(UnsupportedZipFeatureException.class);
                            expectedException.expectMessage("UNKNOWN_COMPRESSED_SIZE");
                            zis.read(buffer, 0, 10);
                        }

    @Test
            public void testRead_UpdatesCRCWhenReadSuccessful() throws Exception {
                // Create mock input stream
                InputStream mockInput = mock(InputStream.class);
                
                // Create real ZipArchiveInputStream with mock input
                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                zis = spy(zis);
                
                // Create test entry
                final ZipArchiveEntry testEntry = new ZipArchiveEntry("test");
                testEntry.setMethod(ZipArchiveOutputStream.STORED);
                
                // Use reflection to set private fields
                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                currentField.setAccessible(true);
                
                // Create mock CRC32
                CRC32 mockCrc = mock(CRC32.class);
                
                // Create current entry object
                Object currentEntry = new Object() {
                    public final ZipArchiveEntry entry = testEntry;
                    public final CRC32 crc = mockCrc;
                };
                currentField.set(zis, currentEntry);
                
                // Mock private methods using reflection
                Method readStoredMethod = ZipArchiveInputStream.class.getDeclaredMethod("readStored", byte[].class, int.class, int.class);
                readStoredMethod.setAccessible(true);
                when(readStoredMethod.invoke(zis, any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                
                Method supportsDataDescriptorMethod = ZipArchiveInputStream.class.getDeclaredMethod("supportsDataDescriptorFor", ZipArchiveEntry.class);
                supportsDataDescriptorMethod.setAccessible(true);
                when(supportsDataDescriptorMethod.invoke(zis, eq(testEntry))).thenReturn(true);
                
                Method supportsCompressedSizeMethod = ZipArchiveInputStream.class.getDeclaredMethod("supportsCompressedSizeFor", ZipArchiveEntry.class);
                supportsCompressedSizeMethod.setAccessible(true);
                when(supportsCompressedSizeMethod.invoke(zis, eq(testEntry))).thenReturn(true);
                
                // Test
                byte[] buffer = new byte[10];
                zis.read(buffer, 0, 10);
                
                // Verify CRC was updated
                verify(mockCrc).update(buffer, 0, 5);
            }

    @Test
    public void testRead_WithInvalidOffsetOrLength_ThrowsArrayIndexOutOfBounds() throws Exception {
        // Setup
        InputStream mockInputStream = mock(InputStream.class);
        ZipArchiveInputStream zis = 
            new ZipArchiveInputStream(mockInputStream);
        byte[] buffer = new byte[10];
        
        // Use reflection to set private current field
        Field currentField = ZipArchiveInputStream.class
            .getDeclaredField("current");
        currentField.setAccessible(true);
        Class<?>[] declaredClasses = ZipArchiveInputStream.class.getDeclaredClasses();
        Object current = mock(declaredClasses[0]);
        currentField.set(zis, current);
        
        // Set up mock entry to avoid NPE in supportsDataDescriptorFor check
        Field entryField = declaredClasses[0].getDeclaredField("entry");
        entryField.setAccessible(true);
        ZipArchiveEntry mockEntry = 
            mock(ZipArchiveEntry.class);
        entryField.set(current, mockEntry);
        
        // Test various invalid combinations
        try {
            zis.read(buffer, 11, 1); // offset > buffer.length
            org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
            // expected
        }
        
        try {
            zis.read(buffer, 0, -1); // length < 0
            org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
            // expected
        }
        
        try {
            zis.read(buffer, -1, 1); // offset < 0
            org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
            // expected
        }
        
        try {
            zis.read(buffer, 5, 6); // buffer.length - offset < length
            org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException e) {
            // expected
        }
    }


}
