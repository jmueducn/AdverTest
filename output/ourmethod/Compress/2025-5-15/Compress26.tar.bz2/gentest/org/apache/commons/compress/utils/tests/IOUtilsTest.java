package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
 
public class IOUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_ZeroBytes() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 0);
                                                                                                                                                                                                                                                                                           assertEquals(0, skipped);
                                                                                                                                                                                                                                                                                           verify(input, never()).skip(anyLong());
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_AllBytesSkipped() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           when(input.skip(10)).thenReturn(10L);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                           assertEquals(10, skipped);
                                                                                                                                                                                                                                                                                           verify(input).skip(10);
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_PartialSkipThenComplete() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           when(input.skip(10)).thenReturn(5L, 5L);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                           assertEquals(10, skipped);
                                                                                                                                                                                                                                                                                           verify(input, times(2)).skip(10);
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_PartialSkipThenRead() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           when(input.skip(10)).thenReturn(5L, 0L);
                                                                                                                                                                                                                                                                                           when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                               .thenReturn(5, 0);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                           assertEquals(10, skipped);
                                                                                                                                                                                                                                                                                           verify(input, times(2)).skip(10);
                                                                                                                                                                                                                                                                                           verify(input, times(1)).read(any(byte[].class), anyInt(), eq(5));
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_AllViaRead() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           when(input.skip(10)).thenReturn(0L);
                                                                                                                                                                                                                                                                                           when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                               .thenReturn(5, 5, 0);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                           assertEquals(10, skipped);
                                                                                                                                                                                                                                                                                           verify(input).skip(10);
                                                                                                                                                                                                                                                                                           verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_EndOfStreamBeforeComplete() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           when(input.skip(10)).thenReturn(5L, 0L);
                                                                                                                                                                                                                                                                                           when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                               .thenReturn(2, 0);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                           assertEquals(7, skipped);
                                                                                                                                                                                                                                                                                           verify(input, times(2)).skip(10);
                                                                                                                                                                                                                                                                                           verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_WithRealStream() throws IOException {
                                                                                                                                                                                                                                                                                           byte[] data = new byte[100];
                                                                                                                                                                                                                                                                                           for (int i = 0; i < data.length; i++) {
                                                                                                                                                                                                                                                                                               data[i] = (byte) i;
                                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                                           InputStream input = new ByteArrayInputStream(data);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 50);
                                                                                                                                                                                                                                                                                           assertEquals(50, skipped);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           skipped = IOUtils.skip(input, 60);
                                                                                                                                                                                                                                                                                           assertEquals(50, skipped);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           skipped = IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                           assertEquals(0, skipped);
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                                       public void testSkip_LargeNumber() throws IOException {
                                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                           when(input.skip(Integer.MAX_VALUE + 1L)).thenReturn(Integer.MAX_VALUE + 1L);
                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, Integer.MAX_VALUE + 1L);
                                                                                                                                                                                                                                                                                           assertEquals(Integer.MAX_VALUE + 1L, skipped);
                                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                               public void testSkip_NegativeNumber() throws IOException {
                                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                   ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                                                                                                                                                                   exceptionRule.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                   IOUtils.skip(input, -1);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                               public void testSkip_IOExceptionDuringSkip() throws IOException {
                                                                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                                   when(input.skip(anyLong())).thenThrow(new IOException());
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                                                                                       IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                                       fail("Expected IOException");
                                                                                                                                                                                                                                                                                   } catch (IOException e) {
                                                                                                                                                                                                                                                                                       // expected
                                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                                               }

    @Test(expected = IOException.class)
                                                                                                                                                                                                                                                                           public void testSkip_IOExceptionDuringRead() throws IOException {
                                                                                                                                                                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                               when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                                               when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                                   .thenThrow(new IOException());
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               IOUtils.skip(input, 10);
                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                       public void testSkipWithZeroBytesShouldNotEnterLoop() throws IOException {
                                                                                                                                                                                                                                                                           // Arrange
                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                           when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                                           when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Act - try to skip 0 bytes
                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 0);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Assert
                                                                                                                                                                                                                                                                           assertEquals(0, skipped);
                                                                                                                                                                                                                                                                           verify(input, never()).skip(anyLong());  // Shouldn't call skip when numToSkip is 0
                                                                                                                                                                                                                                                                           verify(input, never()).read(any(byte[].class), anyInt(), anyInt());  // Shouldn't call read when numToSkip is 0
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testSkipWithExhaustedStreamShouldNotLoopInfinitely() throws IOException {
                                                                                                                                                                                                                                                                           // Arrange
                                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                           when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                                           when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Act - try to skip bytes from exhausted stream
                                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, 100);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Assert
                                                                                                                                                                                                                                                                           assertEquals(0, skipped);  // Should return 0 when stream is exhausted
                                                                                                                                                                                                                                                                           verify(input, atMost(1)).read(any(byte[].class), anyInt(), anyInt());  // Shouldn't keep reading after EOF
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                      public void testSkipWithExactBufferSizeShouldNotLoopExtraTime() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                                                                          final int skipBufSize;
                                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                                              Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                                                                                                                                                              field.setAccessible(true);
                                                                                                                                                                                                                                                                              skipBufSize = field.getInt(null);
                                                                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                                                                              throw new RuntimeException("Failed to access SKIP_BUF_SIZE via reflection", e);
                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                          InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                          when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                                          when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                                                              .thenReturn(skipBufSize)  // First read fills buffer
                                                                                                                                                                                                                                                                              .thenReturn(-1);          // Second read indicates EOF
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                          // Act - try to skip exactly buffer size
                                                                                                                                                                                                                                                                          long skipped = IOUtils.skip(input, skipBufSize);
                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                          // Assert
                                                                                                                                                                                                                                                                          assertEquals(skipBufSize, skipped);
                                                                                                                                                                                                                                                                          verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());  // Should only read once
                                                                                                                                                                                                                                                                      }

    @Test(timeout = 1000) // timeout ensures test fails if infinite loop occurs
                                                                                                                                                                                                                                                                  public void testSkip_DetectsInfiniteLoopMutant() throws IOException {
                                                                                                                                                                                                                                                                      // Arrange
                                                                                                                                                                                                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                      when(mockInput.skip(anyLong()))
                                                                                                                                                                                                                                                                          .thenReturn(10L)  // first skip returns 10
                                                                                                                                                                                                                                                                          .thenReturn(0L);  // subsequent skips return 0
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Act
                                                                                                                                                                                                                                                                      long skipped = IOUtils.skip(mockInput, 20);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Assert
                                                                                                                                                                                                                                                                      assertEquals(10, skipped);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify mock interactions
                                                                                                                                                                                                                                                                      verify(mockInput, times(2)).skip(anyLong());
                                                                                                                                                                                                                                                                      verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                 public void testSkipShouldUseInputStreamSkipMethod() throws IOException {
                                                                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                     long numToSkip = 100L;
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     // Setup mock to skip 50 bytes on first call to skip()
                                                                                                                                                                                                                                                                     when(mockInput.skip(numToSkip)).thenReturn(50L);
                                                                                                                                                                                                                                                                     // Setup mock to return -1 when read into buffer (simulate EOF)
                                                                                                                                                                                                                                                                     when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                                     long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                                                                     // Verify skip() was called on the input stream
                                                                                                                                                                                                                                                                     verify(mockInput).skip(numToSkip);
                                                                                                                                                                                                                                                                     // Verify total skipped is what skip() returned (50)
                                                                                                                                                                                                                                                                     assertEquals(50L, skipped);
                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                     // With the mutant, this test would fail because:
                                                                                                                                                                                                                                                                     // 1. The mutant would not call skip() (verification would fail)
                                                                                                                                                                                                                                                                     // 2. The mutant would try to read into buffer and get -1, returning 0 (assertion would fail)
                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                public void testSkipWithNegativeSkippedValue() throws Exception {
                                                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                                    when(mockInput.skip(anyLong())).thenReturn(-1L); // Simulate error case
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                                                    long result = IOUtils.skip(mockInput, 100L);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                                                    // Original behavior would continue trying to skip (return 100)
                                                                                                                                                                                                                                                                    // Mutated behavior would break immediately (return 0)
                                                                                                                                                                                                                                                                    assertEquals("Should handle negative skip return value correctly", 
                                                                                                                                                                                                                                                                                100L, result);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Verify the fallback read was attempted
                                                                                                                                                                                                                                                                    verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                   public void testSkip_ExactlyConsumedBySkip_ShouldNotUseBuffer() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                       long numToSkip = 100L;
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Mock behavior - first skip consumes all requested bytes
                                                                                                                                                                                                                                                                       when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Test
                                                                                                                                                                                                                                                                       long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       assertEquals("Should have skipped all bytes", numToSkip, skipped);
                                                                                                                                                                                                                                                                       verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                                                                                                       verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // This test would fail with the mutant because:
                                                                                                                                                                                                                                                                       // 1. The mutant would enter the buffer-reading block when numToSkip becomes 0
                                                                                                                                                                                                                                                                       // 2. We would see additional read() calls that shouldn't happen
                                                                                                                                                                                                                                                                       // 3. The never() verification on read() would fail
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                   public void testSkip_ZeroBytesRequested_ShouldNotUseBuffer() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                       long numToSkip = 0L;
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Test
                                                                                                                                                                                                                                                                       long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                                                                                       assertEquals("Should have skipped 0 bytes", 0L, skipped);
                                                                                                                                                                                                                                                                       verify(input, never()).skip(anyLong());
                                                                                                                                                                                                                                                                       verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // This test would fail with the mutant because:
                                                                                                                                                                                                                                                                       // 1. The mutant would enter the buffer-reading block when numToSkip is 0
                                                                                                                                                                                                                                                                       // 2. We would see read() calls that shouldn't happen
                                                                                                                                                                                                                                                                       // 3. The never() verification on read() would fail
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                              public void testSkip_ShouldNotReadBufferWhenSkippedFully() throws Exception {
                                                                                                                                                                                                                                                                  // Arrange
                                                                                                                                                                                                                                                                  InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                  long numToSkip = 10;
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Mock behavior:
                                                                                                                                                                                                                                                                  // First skip() call will skip all requested bytes
                                                                                                                                                                                                                                                                  when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Act
                                                                                                                                                                                                                                                                  long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Assert
                                                                                                                                                                                                                                                                  assertEquals(numToSkip, result);
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify we never entered the buffer-reading path
                                                                                                                                                                                                                                                                  verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                  // Verify skip was called exactly once with the full amount
                                                                                                                                                                                                                                                                  verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                            public void testSkipWithExactBufferSize() throws IOException {
                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                final int SKIP_BUF_SIZE = 8192; // Same as IOUtils.SKIP_BUF_SIZE
                                                                                                                                                                                                                                                                final long bytesToSkip = SKIP_BUF_SIZE;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                                // First skip() call returns 0 to force buffer reading
                                                                                                                                                                                                                                                                when(input.skip(bytesToSkip)).thenReturn(0L);
                                                                                                                                                                                                                                                                // Simulate reading exactly SKIP_BUF_SIZE bytes in one read
                                                                                                                                                                                                                                                                when(input.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                                                                                                                                                                                                    byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                                                    int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                                                                                                    // Original code would pass len = SKIP_BUF_SIZE
                                                                                                                                                                                                                                                                    // Mutant would pass len = SKIP_BUF_SIZE + 1
                                                                                                                                                                                                                                                                    assertEquals(SKIP_BUF_SIZE, len); // This will catch the mutant
                                                                                                                                                                                                                                                                    return len; // Return full read
                                                                                                                                                                                                                                                                });
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                                long skipped = IOUtils.skip(input, bytesToSkip);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                                assertEquals(bytesToSkip, skipped);
                                                                                                                                                                                                                                                                verify(input, times(1)).read(any(byte[].class), eq(0), eq(SKIP_BUF_SIZE));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                        public void testSkipWithZeroBytesShouldNotEnterLoop1() throws IOException {
                                                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                                                            InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                            when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Act - try to skip 0 bytes
                                                                                                                                                                                                                                                            long skipped = IOUtils.skip(input, 0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                                                            assertEquals(0, skipped);
                                                                                                                                                                                                                                                            verify(input, never()).skip(anyLong());  // skip() shouldn't be called at all
                                                                                                                                                                                                                                                            // Also verify readFully() is never called (though we can't directly verify it here)
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Additional verification that no buffer was allocated/read
                                                                                                                                                                                                                                                            // This would normally require spying on the class or refactoring to be more testable
                                                                                                                                                                                                                                                            // But the key point is that with numToSkip=0, we shouldn't enter any loops
                                                                                                                                                                                                                                                        }

    @Test(timeout = 1000) // Add timeout to catch infinite loops
                                                                                                                                                                                                                                                       public void testSkip_DetectsInfiniteLoopMutant1() throws IOException {
                                                                                                                                                                                                                                                           // Arrange
                                                                                                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                                           long numToSkip = 10L;
                                                                                                                                                                                                                                                           when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Act
                                                                                                                                                                                                                                                           long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Assert
                                                                                                                                                                                                                                                           assertEquals("Should have skipped all bytes", numToSkip, skipped);
                                                                                                                                                                                                                                                           verify(input, times(1)).skip(numToSkip);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // The test will fail by timeout if the mutant is present (infinite loop)
                                                                                                                                                                                                                                                           // With original code, it will complete normally after one skip
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                          public void testSkipWithSmallNumToSkipDetectsMathMinMutant() throws Exception {
                                                                                                                                                                                                                                                              // Arrange
                                                                                                                                                                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                              long numToSkip = 100; // Less than SKIP_BUF_SIZE
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // First skip() call returns 0 to force the buffer read path
                                                                                                                                                                                                                                                              when(mockInput.skip(numToSkip)).thenReturn(0L);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test will fail here if mutant is present because:
                                                                                                                                                                                                                                                              // Original: would call readFully with 100 (Math.min)
                                                                                                                                                                                                                                                              // Mutant: would call readFully with 8192 (Math.max)
                                                                                                                                                                                                                                                              when(mockInput.read(any(byte[].class), eq(0), eq(100))).thenReturn(100);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                                                              long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Assert
                                                                                                                                                                                                                                                              assertEquals(100, skipped);
                                                                                                                                                                                                                                                              verify(mockInput).skip(100);
                                                                                                                                                                                                                                                              verify(mockInput).read(any(byte[].class), eq(0), eq(100));
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                     public void testSkipWithLargeNumToSkip() throws Exception {
                                                                                                                                                                                                                                                         // Arrange
                                                                                                                                                                                                                                                         final int SKIP_BUF_SIZE = 8192; // Common buffer size, matches implementation
                                                                                                                                                                                                                                                         InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                         long numToSkip = SKIP_BUF_SIZE + 100; // More than SKIP_BUF_SIZE
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // First skip() call returns 0 to force the buffer read path
                                                                                                                                                                                                                                                         when(mockInput.skip(numToSkip)).thenReturn(0L);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Both original and mutant would use SKIP_BUF_SIZE here
                                                                                                                                                                                                                                                         when(mockInput.read(any(byte[].class), eq(0), eq(SKIP_BUF_SIZE))).thenReturn(SKIP_BUF_SIZE);
                                                                                                                                                                                                                                                         when(mockInput.read(any(byte[].class), eq(0), eq(100))).thenReturn(100);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Act
                                                                                                                                                                                                                                                         long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Assert
                                                                                                                                                                                                                                                         assertEquals(numToSkip, skipped);
                                                                                                                                                                                                                                                         verify(mockInput).skip(numToSkip);
                                                                                                                                                                                                                                                         verify(mockInput).read(any(byte[].class), eq(0), eq(SKIP_BUF_SIZE));
                                                                                                                                                                                                                                                         verify(mockInput).read(any(byte[].class), eq(0), eq(100));
                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                            public void testSkipWithLargeInputShouldUseBufferSize() throws Exception {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                // Get private SKIP_BUF_SIZE using reflection
                                                                                                                                                                                                                                                Field skipBufSizeField = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                                                                                                                                skipBufSizeField.setAccessible(true);
                                                                                                                                                                                                                                                int SKIP_BUF_SIZE = skipBufSizeField.getInt(null);
                                                                                                                                                                                                                                                final long LARGE_SKIP = SKIP_BUF_SIZE * 2L; // Twice buffer size
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Mock behavior:
                                                                                                                                                                                                                                                // First skip returns 0 (forcing fallback to buffer reading)
                                                                                                                                                                                                                                                when(mockInput.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                                // When reading, return buffer size chunks
                                                                                                                                                                                                                                                doAnswer(invocation -> {
                                                                                                                                                                                                                                                    byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                                    int len = (int) invocation.getArguments()[2];
                                                                                                                                                                                                                                                    // Verify we never try to read more than SKIP_BUF_SIZE
                                                                                                                                                                                                                                                    assertTrue("Read length should not exceed SKIP_BUF_SIZE", 
                                                                                                                                                                                                                                                              len <= SKIP_BUF_SIZE);
                                                                                                                                                                                                                                                    return len; // Return full read length
                                                                                                                                                                                                                                                }).when(mockInput).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                long skipped = IOUtils.skip(mockInput, LARGE_SKIP);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals("Should skip requested amount", LARGE_SKIP, skipped);
                                                                                                                                                                                                                                                // Verify the mock interactions
                                                                                                                                                                                                                                                verify(mockInput, atLeastOnce()).skip(LARGE_SKIP);
                                                                                                                                                                                                                                                verify(mockInput, atLeast(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                   public void testSkipHandlesZeroByteReads() throws Exception {
                                                                                                                                                                                                                                       // Create a mock InputStream that will:
                                                                                                                                                                                                                                       // 1. First return 0 when skip() is called (forcing fallback to read)
                                                                                                                                                                                                                                       // 2. Then return 0 on first read attempt (test case for mutation)
                                                                                                                                                                                                                                       // 3. Then return actual data on subsequent reads
                                                                                                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                       when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // First read returns 0, subsequent reads return data
                                                                                                                                                                                                                                       byte[] testData = new byte[]{1, 2, 3};
                                                                                                                                                                                                                                       when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                           .thenReturn(0)  // First read returns 0
                                                                                                                                                                                                                                           .thenAnswer(invocation -> {
                                                                                                                                                                                                                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                               int len = (int) invocation.getArguments()[2];
                                                                                                                                                                                                                                               System.arraycopy(testData, 0, buf, 0, Math.min(testData.length, len));
                                                                                                                                                                                                                                               return Math.min(testData.length, len);
                                                                                                                                                                                                                                           });
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                       // Try to skip more bytes than our test data contains
                                                                                                                                                                                                                                       long requestedSkip = 10L;
                                                                                                                                                                                                                                       long actualSkipped = IOUtils.skip(input, requestedSkip);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                       // Verify behavior:
                                                                                                                                                                                                                                       // Original code should continue reading after getting 0 bytes and eventually skip all testData
                                                                                                                                                                                                                                       // Mutant would stop at first 0-byte read and return 0
                                                                                                                                                                                                                                       assertTrue("Should have skipped some bytes", actualSkipped > 0);
                                                                                                                                                                                                                                       assertEquals("Should have skipped all available bytes", testData.length, actualSkipped);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify mock interactions
                                                                                                                                                                                                                                       verify(input, atLeastOnce()).skip(requestedSkip);
                                                                                                                                                                                                                                       verify(input, atLeast(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                               public void testSkip_DetectsEndOfStream() throws Exception {
                                                                                                                                                                                                                                   // Setup mock InputStream that will:
                                                                                                                                                                                                                                   // 1. First skip returns 5 (partial skip)
                                                                                                                                                                                                                                   // 2. First readFully returns 10 (partial read)
                                                                                                                                                                                                                                   // 3. Second readFully returns 0 (end of stream)
                                                                                                                                                                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                                                   when(mockInput.skip(anyLong())).thenReturn(5L);
                                                                                                                                                                                                                                   when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                                       .thenReturn(10)  // first read
                                                                                                                                                                                                                                       .thenReturn(0);  // second read (end of stream)
                                                                                                                                                                                                                               
                                                                                                                                                                                                                                   // Test skipping 20 bytes
                                                                                                                                                                                                                                   long skipped = IOUtils.skip(mockInput, 20);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                                   // Verify behavior
                                                                                                                                                                                                                                   // Original should return 15 (5 + 10) when hitting end of stream
                                                                                                                                                                                                                                   // Mutant would continue trying to read and potentially loop infinitely
                                                                                                                                                                                                                                   assertEquals(15, skipped);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                                   // Verify interaction - should stop after getting 0 from read
                                                                                                                                                                                                                                   verify(mockInput, times(1)).skip(20);
                                                                                                                                                                                                                                   verify(mockInput, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                 public void testSkip_DetectsNumToSkipAdditionMutant() throws Exception {
                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                     InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                     long requestedSkip = 10000;
                                                                                                                                                                                                                     // Using common buffer size since SKIP_BUF_SIZE is private
                                                                                                                                                                                                                     int skipBufSize = 8192;
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock behavior:
                                                                                                                                                                                                                     // First skip() call skips part of the request
                                                                                                                                                                                                                     when(input.skip(requestedSkip)).thenReturn(5000L);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Then mock readFully to return partial reads
                                                                                                                                                                                                                     // First read returns 2000, second returns 3000 (total 5000 + 2000 + 3000 = 10000)
                                                                                                                                                                                                                     when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                                         .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                             public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                                                                                                 int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                                                                 return len > 2000 ? 2000 : 3000; // First call returns 2000, second 3000
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                         });
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                     long actualSkipped = IOUtils.skip(input, requestedSkip);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                     assertEquals("Should have skipped all requested bytes", 
                                                                                                                                                                                                                                 requestedSkip, actualSkipped);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify interaction - should have called skip once then read twice
                                                                                                                                                                                                                     verify(input, times(1)).skip(requestedSkip);
                                                                                                                                                                                                                     verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                            public void testSkipWithMultipleReads() throws IOException {
                                                                                                                                                                                                // Setup mock input stream that will require multiple reads
                                                                                                                                                                                                InputStream mockInput = mock(InputStream.class);
                                                                                                                                                                                                
                                                                                                                                                                                                // First skip will only skip part of the requested bytes
                                                                                                                                                                                                when(mockInput.skip(anyLong())).thenReturn(5L);
                                                                                                                                                                                                
                                                                                                                                                                                                // Then mock the read operations - each will read 2 bytes until done
                                                                                                                                                                                                when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                                                    .thenAnswer(invocation -> {
                                                                                                                                                                                                        Object[] args = invocation.getArguments();
                                                                                                                                                                                                        int len = (Integer) args[2];
                                                                                                                                                                                                        return Math.min(2, len); // return 2 bytes each time
                                                                                                                                                                                                    });
                                                                                                                                                                                                
                                                                                                                                                                                                long numToSkip = 10; // We want to skip 10 bytes
                                                                                                                                                                                                long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                                                                
                                                                                                                                                                                                // Original code would return 10 (full skip), mutant would return 2 (last read)
                                                                                                                                                                                                assertEquals("Should skip all requested bytes", numToSkip, skipped);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify the interactions
                                                                                                                                                                                                verify(mockInput, atLeastOnce()).skip(anyLong());
                                                                                                                                                                                                verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                       public void testSkipWithPartialReadsDetectsMutant() throws IOException {
                                                                                                                                                                           // Setup mock InputStream that returns partial reads
                                                                                                                                                                           InputStream input = mock(InputStream.class);
                                                                                                                                                                           
                                                                                                                                                                           // First skip() call returns 0 to force fallback to readFully path
                                                                                                                                                                           when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                                           
                                                                                                                                                                           // Configure readFully to return partial reads (less than SKIP_BUF_SIZE)
                                                                                                                                                                           // First read returns 100 bytes, second returns 50
                                                                                                                                                                           when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                               .thenAnswer(invocation -> {
                                                                                                                                                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                   int off = (Integer) invocation.getArguments()[1];
                                                                                                                                                                                   int len = (Integer) invocation.getArguments()[2];
                                                                                                                                                                                   return len > 100 ? 100 : 50;
                                                                                                                                                                               });
                                                                                                                                                                           
                                                                                                                                                                           long numToSkip = 150; // Need two reads to skip this in original (100 + 50)
                                                                                                                                                                                                // Mutant would need 150 reads (1 byte at a time)
                                                                                                                                                                           
                                                                                                                                                                           // Test the method
                                                                                                                                                                           long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                                           
                                                                                                                                                                           // Verify behavior
                                                                                                                                                                           // Original would complete in 2 read operations (100 + 50 = 150)
                                                                                                                                                                           // Mutant would do 150 operations (1 byte each)
                                                                                                                                                                           verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                           
                                                                                                                                                                           // Verify correct number of bytes skipped
                                                                                                                                                                           assertEquals(150, skipped);
                                                                                                                                                                           
                                                                                                                                                                           // Verify we didn't skip more than requested
                                                                                                                                                                           assertTrue(skipped <= numToSkip);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                  public void testSkipShouldUseSkipMethodFirst() throws IOException {
                                                                                                                                                                      // Create a mock InputStream that can skip some bytes
                                                                                                                                                                      InputStream input = mock(InputStream.class);
                                                                                                                                                                      when(input.skip(anyLong())).thenAnswer(invocation -> {
                                                                                                                                                                          Long requested = (Long) invocation.getArguments()[0];
                                                                                                                                                                          return requested > 10 ? 10 : requested; // Skip up to 10 bytes at a time
                                                                                                                                                                      });
                                                                                                                                                                      
                                                                                                                                                                      // Test skipping 20 bytes - original should use skip() twice then be done
                                                                                                                                                                      long skipped = IOUtils.skip(input, 20);
                                                                                                                                                                      
                                                                                                                                                                      // Verify the correct amount was skipped
                                                                                                                                                                      assertEquals(20, skipped);
                                                                                                                                                                      
                                                                                                                                                                      // Verify skip() was called with the right arguments
                                                                                                                                                                      verify(input, times(2)).skip(anyLong());
                                                                                                                                                                      
                                                                                                                                                                      // Verify the fallback buffer reading was NOT used
                                                                                                                                                                      // (since skip() was sufficient)
                                                                                                                                                                      verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                      
                                                                                                                                                                      // For the mutant: 
                                                                                                                                                                      // - skip(0) would be called but return 0
                                                                                                                                                                      // - Then it would fall through to buffer reading
                                                                                                                                                                      // So this test would fail on the verify(input, never()) check
                                                                                                                                                                  }

    @Test
                                                                                                                                                         public void testSkipWithPartialSkipAndBufferRead() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                             // Setup
                                                                                                                                                             InputStream input = mock(InputStream.class);
                                                                                                                                                             long numToSkip = 1024; // More than SKIP_BUF_SIZE to force buffer read
                                                                                                                                                             
                                                                                                                                                             // Use reflection to access private SKIP_BUF_SIZE
                                                                                                                                                             Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                                             field.setAccessible(true);
                                                                                                                                                             int skipBufSize = field.getInt(null);
                                                                                                                                                             byte[] testData = new byte[skipBufSize];
                                                                                                                                                             java.util.Arrays.fill(testData, (byte) 1); // Fill with known data
                                                                                                                                                             
                                                                                                                                                             // Mock behavior
                                                                                                                                                             when(input.skip(numToSkip)).thenReturn(512L); // First skip only does half
                                                                                                                                                             when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                                 .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                                                                                                                                     @Override
                                                                                                                                                                     public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                                                                                                                                         Object[] args = invocation.getArguments();
                                                                                                                                                                         byte[] buf = (byte[]) args[0];
                                                                                                                                                                         int offset = (Integer) args[1];
                                                                                                                                                                         int len = (Integer) args[2];
                                                                                                                                                                         
                                                                                                                                                                         // Verify offset is 0 (original) vs 1 (mutant)
                                                                                                                                                                         assertEquals(0, offset); // This will fail for the mutant
                                                                                                                                                                         
                                                                                                                                                                         System.arraycopy(testData, 0, buf, offset, len);
                                                                                                                                                                         return len;
                                                                                                                                                                     }
                                                                                                                                                                 });
                                                                                                                                                             
                                                                                                                                                             // Test
                                                                                                                                                             long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                             
                                                                                                                                                             // Verify
                                                                                                                                                             assertEquals(numToSkip, skipped); // Should skip full amount
                                                                                                                                                             verify(input, times(1)).skip(numToSkip);
                                                                                                                                                             verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                         }

    @Test
                                                                                                                                                     public void testSkip_WhenNumToSkipIsZero_ShouldNotPerformAnyOperations() throws IOException {
                                                                                                                                                         // Arrange
                                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                                         long numToSkip = 0L;
                                                                                                                                                         
                                                                                                                                                         // Act
                                                                                                                                                         long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                         
                                                                                                                                                         // Assert
                                                                                                                                                         assertEquals(0L, result);
                                                                                                                                                         verify(input, never()).skip(anyLong());
                                                                                                                                                         verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                     }

    @Test
                                                                                                                                                    public void testSkip_WhenStreamReturnsZero_ShouldNotLoopInfinitely() throws IOException {
                                                                                                                                                        // Arrange
                                                                                                                                                        InputStream input = mock(InputStream.class);
                                                                                                                                                        when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                        when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                                        long numToSkip = 10L;
                                                                                                                                                        
                                                                                                                                                        // Act
                                                                                                                                                        long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                        
                                                                                                                                                        // Assert
                                                                                                                                                        assertEquals(0L, result);
                                                                                                                                                        verify(input, times(1)).skip(10L);
                                                                                                                                                        verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSkipWithZeroBytesShouldReturnImmediately() throws Exception {
                                                                                                                                                        // Arrange
                                                                                                                                                        InputStream input = mock(InputStream.class);
                                                                                                                                                        long numToSkip = 0L;
                                                                                                                                                        
                                                                                                                                                        // Act & Assert
                                                                                                                                                        // This test will fail for the mutant because it would enter an infinite loop
                                                                                                                                                        // instead of returning immediately when numToSkip is 0
                                                                                                                                                        long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0L, result);
                                                                                                                                                        verify(input, never()).skip(anyLong());
                                                                                                                                                        verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSkipWithEmptyStreamShouldNotLoopInfinitely() throws Exception {
                                                                                                                                                        // Arrange
                                                                                                                                                        InputStream input = mock(InputStream.class);
                                                                                                                                                        when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                        when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                                        long numToSkip = 10L;
                                                                                                                                                        
                                                                                                                                                        // Act & Assert
                                                                                                                                                        // This test will fail for the mutant because it would enter an infinite loop
                                                                                                                                                        // instead of breaking when the stream returns -1
                                                                                                                                                        long result = IOUtils.skip(input, numToSkip);
                                                                                                                                                        
                                                                                                                                                        assertEquals(0L, result);
                                                                                                                                                        verify(input, atLeastOnce()).skip(numToSkip);
                                                                                                                                                        verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testSkipShouldUseInputStreamSkipWhenAvailable() throws Exception {
                                                                                                                                                   // Arrange
                                                                                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                                                                                   when(mockInput.skip(anyLong())).thenReturn(10L); // mock to skip 10 bytes successfully
                                                                                                                                                   
                                                                                                                                                   long numToSkip = 20;
                                                                                                                                                   
                                                                                                                                                   // Act
                                                                                                                                                   long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                                   
                                                                                                                                                   // Assert
                                                                                                                                                   // Verify that input.skip() was called (would fail for mutant)
                                                                                                                                                   verify(mockInput, atLeastOnce()).skip(anyLong());
                                                                                                                                                   // Verify the correct number of bytes were skipped
                                                                                                                                                   assertEquals(20, skipped);
                                                                                                                                                   // Verify we didn't fall back to buffer reading (would fail for mutant)
                                                                                                                                                   verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                   
                                                                                                                                                   // Additional verification that the skip was properly accounted for
                                                                                                                                                   // The original code would subtract the skipped amount from numToSkip
                                                                                                                                                   // The mutant would ignore the skipped bytes and try to read everything
                                                                                                                                                   // So we can also verify interaction counts
                                                                                                                                                   verify(mockInput, times(2)).skip(anyLong()); // called twice: first 10, then remaining 10
                                                                                                                                               }

    @Test
                                                                                                                                              public void testSkipWithNegativeSkippedValue1() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  InputStream input = mock(InputStream.class);
                                                                                                                                                  when(input.skip(anyLong()))
                                                                                                                                                      .thenReturn(-1L)  // First skip returns negative
                                                                                                                                                      .thenReturn(10L); // Subsequent skip returns positive
                                                                                                                                                  
                                                                                                                                                  // Act
                                                                                                                                                  long skipped = IOUtils.skip(input, 100);
                                                                                                                                                  
                                                                                                                                                  // Assert
                                                                                                                                                  // Original code would process the negative return as non-zero and continue,
                                                                                                                                                  // eventually using readFully to skip remaining bytes
                                                                                                                                                  // Mutated code would break the loop on negative return
                                                                                                                                                  assertEquals("Should have skipped all bytes despite negative skip return", 
                                                                                                                                                              100, skipped);
                                                                                                                                                  
                                                                                                                                                  // Verify the fallback to readFully was called (for original behavior)
                                                                                                                                                  verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                              }

    @Test
                                                                                                                                             public void testSkipWithZeroBytesShouldNotRead() throws Exception {
                                                                                                                                                 // Arrange
                                                                                                                                                 InputStream input = mock(InputStream.class);
                                                                                                                                                 when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                                 
                                                                                                                                                 // Act
                                                                                                                                                 long skipped = IOUtils.skip(input, 0);
                                                                                                                                                 
                                                                                                                                                 // Assert
                                                                                                                                                 assertEquals(0, skipped);
                                                                                                                                                 verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                 verify(input, times(1)).skip(0); // Only skip(0) should be called
                                                                                                                                             }

    @Test
                                                                                                                                            public void testSkip_ShouldNotUseBufferWhenNoBytesRemain() throws Exception {
                                                                                                                                                // Setup mock InputStream
                                                                                                                                                InputStream input = mock(InputStream.class);
                                                                                                                                                
                                                                                                                                                // Case where all bytes are skipped in first phase
                                                                                                                                                long numToSkip = 100;
                                                                                                                                                when(input.skip(numToSkip)).thenReturn(numToSkip);
                                                                                                                                                
                                                                                                                                                // Execute
                                                                                                                                                long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertEquals(numToSkip, skipped);
                                                                                                                                                verify(input).skip(numToSkip);
                                                                                                                                                verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                
                                                                                                                                                // The mutant would fail this test because it would still try to read into buffer
                                                                                                                                                // even though numToSkip became 0 after the initial skip
                                                                                                                                            }

    @Test
                                                                                                                                          public void testSkipBufferSize() throws IOException {
                                                                                                                                              // Arrange
                                                                                                                                              final int SKIP_BUF_SIZE = 8192; // Assuming this is the value from class
                                                                                                                                              final long numToSkip = SKIP_BUF_SIZE + 100; // Force buffer usage
                                                                                                                                              InputStream input = mock(InputStream.class);
                                                                                                                                              
                                                                                                                                              // First skip will only skip part of the requested bytes
                                                                                                                                              when(input.skip(numToSkip)).thenReturn(100L);
                                                                                                                                              // Subsequent reads will return chunks
                                                                                                                                              when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                  .thenAnswer(invocation -> {
                                                                                                                                                      Object[] args = invocation.getArguments();
                                                                                                                                                      byte[] buf = (byte[]) args[0];
                                                                                                                                                      int len = (int) args[2];
                                                                                                                                                      // Verify buffer size is exactly SKIP_BUF_SIZE
                                                                                                                                                      assertEquals(SKIP_BUF_SIZE, buf.length);
                                                                                                                                                      return len; // Return full read each time
                                                                                                                                                  });
                                                                                                                                              
                                                                                                                                              // Act
                                                                                                                                              long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                                              
                                                                                                                                              // Assert
                                                                                                                                              assertEquals(numToSkip, skipped);
                                                                                                                                              // Additional verification that buffer was used
                                                                                                                                              verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                          }

    @Test
                                                                                                                                      public void testSkipWithZeroBytesShouldNotRead1() throws IOException {
                                                                                                                                          // Arrange
                                                                                                                                          InputStream input = mock(InputStream.class);
                                                                                                                                          when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                          when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          long skipped = IOUtils.skip(input, 0);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(0, skipped);
                                                                                                                                          verify(input, never()).skip(anyLong());
                                                                                                                                          verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testSkipShouldStopWhenNumToSkipReachesZero() throws IOException {
                                                                                                                                          // Arrange
                                                                                                                                          InputStream input = mock(InputStream.class);
                                                                                                                                          // First skip returns 10, second skip would return 0 (but shouldn't be called)
                                                                                                                                          when(input.skip(anyLong())).thenReturn(10L).thenReturn(0L);
                                                                                                                                          // Set up readFully to return 5 then 0 (but shouldn't be called)
                                                                                                                                          when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                              .thenReturn(5)
                                                                                                                                              .thenReturn(0);
                                                                                                                                          
                                                                                                                                          // Act - try to skip 10 bytes
                                                                                                                                          long skipped = IOUtils.skip(input, 10);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(10, skipped);
                                                                                                                                          // Verify skip was called exactly once (not twice)
                                                                                                                                          verify(input, times(1)).skip(anyLong());
                                                                                                                                          // Verify read was never called (since skip handled it all)
                                                                                                                                          verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                      }

    @Test
                                                                                                                                     public void testSkipWithExactBufferSize1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                         // Arrange
                                                                                                                                         InputStream input = mock(InputStream.class);
                                                                                                                                         when(input.skip(anyLong())).thenReturn(0L);
                                                                                                                                         
                                                                                                                                         // Get the private SKIP_BUF_SIZE field using reflection
                                                                                                                                         Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                         field.setAccessible(true);
                                                                                                                                         int skipBufSize = (int) field.get(null);
                                                                                                                                         
                                                                                                                                         // Simulate reading exactly SKIP_BUF_SIZE bytes
                                                                                                                                         when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                             .thenReturn(skipBufSize)
                                                                                                                                             .thenReturn(0);
                                                                                                                                         
                                                                                                                                         // Act - try to skip exactly SKIP_BUF_SIZE bytes
                                                                                                                                         long skipped = IOUtils.skip(input, skipBufSize);
                                                                                                                                         
                                                                                                                                         // Assert
                                                                                                                                         assertEquals(skipBufSize, skipped);
                                                                                                                                         // Verify read was called exactly once (not twice)
                                                                                                                                         verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                     }

    @Test(timeout = 1000) // Add timeout to detect infinite loops
                                                                                                                                 public void testSkip_DetectsInfiniteLoopMutant2() throws IOException {
                                                                                                                                     // Arrange
                                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                                     when(mockInput.skip(anyLong())).thenReturn(0L); // First skip attempt returns 0
                                                                                                                                     when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                         .thenReturn(-1); // Subsequent reads return EOF
                                                                                                                                     
                                                                                                                                     long numToSkip = 100;
                                                                                                                                     
                                                                                                                                     // Act
                                                                                                                                     long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                                                                     
                                                                                                                                     // Assert
                                                                                                                                     assertEquals(0, skipped); // Should skip 0 bytes since input is exhausted
                                                                                                                                     
                                                                                                                                     // Verify interactions
                                                                                                                                     verify(mockInput).skip(numToSkip);
                                                                                                                                     verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                 }

    @Test
                                                                                                                               public void testSkipWithLargeNumToSkipShouldUseBufferSize() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                   // Arrange
                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                   
                                                                                                                                   // Get private SKIP_BUF_SIZE using reflection
                                                                                                                                   Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                                   field.setAccessible(true);
                                                                                                                                   int skipBufSize = field.getInt(null);
                                                                                                                                   
                                                                                                                                   long largeSkipValue = skipBufSize + 100; // Larger than buffer size
                                                                                                                                   
                                                                                                                                   // First skip attempt returns partial skip
                                                                                                                                   when(input.skip(largeSkipValue)).thenReturn((long)skipBufSize - 50L);
                                                                                                                                   
                                                                                                                                   // Mock readFully to verify buffer size and return partial read
                                                                                                                                   doAnswer(invocation -> {
                                                                                                                                       byte[] buf = (byte[]) invocation.getArguments()[1];
                                                                                                                                       int len = (int) invocation.getArguments()[3];
                                                                                                                                       // Verify we're not trying to read more than SKIP_BUF_SIZE
                                                                                                                                       assertEquals(skipBufSize, len);
                                                                                                                                       assertEquals(skipBufSize, buf.length);
                                                                                                                                       return 50; // return remaining bytes to complete the skip
                                                                                                                                   }).when(input).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                                   
                                                                                                                                   // Act
                                                                                                                                   long skipped = IOUtils.skip(input, largeSkipValue);
                                                                                                                                   
                                                                                                                                   // Assert
                                                                                                                                   assertEquals(largeSkipValue, skipped);
                                                                                                                                   
                                                                                                                                   // Verify interactions
                                                                                                                                   verify(input).skip(largeSkipValue);
                                                                                                                                   verify(input).read(any(byte[].class), eq(0), eq(skipBufSize));
                                                                                                                               }

    @Test
                                                                                                                           public void testSkip_ShouldContinueWhenReadReturnsZero() throws Exception {
                                                                                                                               // Arrange
                                                                                                                               InputStream input = mock(InputStream.class);
                                                                                                                               long numToSkip = 1024;
                                                                                                                               
                                                                                                                               // First skip attempt returns partial skip
                                                                                                                               when(input.skip(numToSkip)).thenReturn(512L);
                                                                                                                               
                                                                                                                               // First readFully call returns 0 (but not EOF)
                                                                                                                               // Second readFully call returns 512 (remaining bytes)
                                                                                                                               when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                   .thenReturn(0)
                                                                                                                                   .thenReturn(512);
                                                                                                                               
                                                                                                                               // Act
                                                                                                                               long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                               
                                                                                                                               // Assert
                                                                                                                               assertEquals(1024, skipped);
                                                                                                                               
                                                                                                                               // Verify behavior
                                                                                                                               verify(input, times(1)).skip(numToSkip);
                                                                                                                               verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                                           }

    @Test
                                                                                                                         public void testSkip_DetectsMutantReadCondition() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                             // Arrange
                                                                                                                             InputStream input = mock(InputStream.class);
                                                                                                                             long numToSkip = 2048; // More than SKIP_BUF_SIZE to trigger the second loop
                                                                                                                             
                                                                                                                             // Use reflection to get the private SKIP_BUF_SIZE
                                                                                                                             Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                                             field.setAccessible(true);
                                                                                                                             int skipBufSize = field.getInt(null);
                                                                                                                             byte[] testBuffer = new byte[skipBufSize];
                                                                                                                             
                                                                                                                             // First skip will only skip part of the requested bytes
                                                                                                                             when(input.skip(numToSkip)).thenReturn(1000L);
                                                                                                                             
                                                                                                                             // First readFully will read some bytes (not end of stream)
                                                                                                                             when(IOUtils.readFully(input, testBuffer, 0, skipBufSize))
                                                                                                                                 .thenReturn(skipBufSize);
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             // Original code would continue reading until all bytes are skipped
                                                                                                                             // Mutant would break after first readFully regardless of bytes read
                                                                                                                             verify(input, atLeast(2)).skip(numToSkip);
                                                                                                                             verify(input, atLeast(2)).read(testBuffer, 0, skipBufSize);
                                                                                                                             assertEquals("Should have skipped all requested bytes", numToSkip, skipped);
                                                                                                                         }

    @Test
                                                                                                                    public void testSkipDetectsAdditionMutant() throws IOException {
                                                                                                                        // Arrange
                                                                                                                        InputStream input = mock(InputStream.class);
                                                                                                                        when(input.skip(anyLong())).thenReturn(5L); // first skip returns 5 bytes
                                                                                                                        // subsequent reads return 10 bytes each until done
                                                                                                                        when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                                                            .thenAnswer(inv -> {
                                                                                                                                byte[] buf = (byte[]) inv.getArguments()[0];
                                                                                                                                int len = (Integer) inv.getArguments()[2];
                                                                                                                                return Math.min(len, 10); // return up to 10 bytes
                                                                                                                            });
                                                                                                                        
                                                                                                                        long numToSkip = 25; // need to skip 25 bytes
                                                                                                                        
                                                                                                                        // Act
                                                                                                                        long skipped = IOUtils.skip(input, numToSkip);
                                                                                                                        
                                                                                                                        // Assert
                                                                                                                        assertEquals("Should have skipped all requested bytes", numToSkip, skipped);
                                                                                                                        
                                                                                                                        // Verify interaction - should have done:
                                                                                                                        // 1 initial skip (5 bytes)
                                                                                                                        // Then reads for remaining 20 bytes (2 reads of 10 bytes each)
                                                                                                                        verify(input, times(1)).skip(25);
                                                                                                                        verify(input, times(2)).read(any(byte[].class), eq(0), anyInt());
                                                                                                                    }

    @Test
                                                                                                           public void testSkipWithMultipleBufferReads() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                               // Get private SKIP_BUF_SIZE using reflection
                                                                                                               Field skipBufSizeField = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                               skipBufSizeField.setAccessible(true);
                                                                                                               final int SKIP_BUF_SIZE = skipBufSizeField.getInt(null);
                                                                                                               
                                                                                                               // Setup test data
                                                                                                               final long bytesToSkip = SKIP_BUF_SIZE * 2 + 10; // Need more than one buffer read
                                                                                                               final InputStream mockInput = mock(InputStream.class);
                                                                                                               
                                                                                                               // Mock behavior:
                                                                                                               // First skip() call returns 0 to force buffer reading path
                                                                                                               when(mockInput.skip(anyLong())).thenReturn(0L);
                                                                                                               
                                                                                                               // First buffer read returns full buffer
                                                                                                               doAnswer(invocation -> {
                                                                                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                   return Math.min(buf.length, (int)bytesToSkip);
                                                                                                               }).when(mockInput).read(any(byte[].class), anyInt(), anyInt());
                                                                                                               
                                                                                                               // Call method
                                                                                                               long skipped = IOUtils.skip(mockInput, bytesToSkip);
                                                                                                               
                                                                                                               // Verify - mutant would return wrong value here
                                                                                                               assertEquals("Should have skipped all requested bytes", 
                                                                                                                            bytesToSkip, skipped);
                                                                                                               
                                                                                                               // Verify interaction - should have tried to skip first
                                                                                                               verify(mockInput).skip(bytesToSkip);
                                                                                                               
                                                                                                               // Verify buffer reads happened
                                                                                                               verify(mockInput, atLeast(2)).read(any(byte[].class), anyInt(), anyInt());
                                                                                                           }

    @Test
                                                                                                  public void testSkipWithMultipleBytesPerReadDetectsMutant() throws IOException {
                                                                                                      // Arrange
                                                                                                      InputStream input = mock(InputStream.class);
                                                                                                      
                                                                                                      // First skip attempt returns 0 to force the fallback path
                                                                                                      when(input.skip(anyLong())).thenReturn(0L);
                                                                                                      
                                                                                                      // Set up readFully to return 10 bytes each time (more than 1)
                                                                                                      when(input.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                                                          Object[] args = invocation.getArguments();
                                                                                                          byte[] buf = (byte[]) args[0];
                                                                                                          int off = (int) args[1];
                                                                                                          int len = (int) args[2];
                                                                                                          return len; // return full requested length
                                                                                                      });
                                                                                                      
                                                                                                      long numToSkip = 20;
                                                                                                      long expectedSkipped = 20; // Should skip all 20 bytes
                                                                                                      
                                                                                                      // Act
                                                                                                      long actualSkipped = IOUtils.skip(input, numToSkip);
                                                                                                      
                                                                                                      // Assert
                                                                                                      assertEquals("Should have skipped all requested bytes", 
                                                                                                                  expectedSkipped, actualSkipped);
                                                                                                      
                                                                                                      // Verify the fallback path was used (readFully called)
                                                                                                      verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                                                  }

    @Test
                                                                                             public void testSkipDetectsMutatedSkipCall() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                 // Arrange
                                                                                                 InputStream input = mock(InputStream.class);
                                                                                                 long numToSkip = 100L;
                                                                                                 
                                                                                                 // Get the private SKIP_BUF_SIZE using reflection
                                                                                                 Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                                                 field.setAccessible(true);
                                                                                                 int skipBufSize = field.getInt(null);
                                                                                                 
                                                                                                 // Mock behavior:
                                                                                                 // - First skip should skip 50 bytes (but mutant would skip 0)
                                                                                                 // - Then fall back to buffer reading for remaining 50
                                                                                                 when(input.skip(numToSkip)).thenReturn(50L);
                                                                                                 when(input.skip(0)).thenReturn(0L); // This is what mutant would do
                                                                                                 
                                                                                                 // Mock the readFully behavior for the fallback
                                                                                                 byte[] skipBuf = new byte[skipBufSize];
                                                                                                 when(input.read(skipBuf, 0, (int)Math.min(50, skipBufSize)))
                                                                                                     .thenReturn(50);
                                                                                                 
                                                                                                 // Act
                                                                                                 long skipped = IOUtils.skip(input, numToSkip);
                                                                                                 
                                                                                                 // Assert
                                                                                                 // Verify the skip was called with correct parameter (would fail for mutant)
                                                                                                 verify(input).skip(numToSkip);
                                                                                                 
                                                                                                 // Verify total skipped bytes (would pass for both, but we need to check the path)
                                                                                                 assertEquals(100L, skipped);
                                                                                                 
                                                                                                 // Verify the fallback was used for remaining bytes
                                                                                                 verify(input).read(skipBuf, 0, (int)Math.min(50, skipBufSize));
                                                                                             }

    @Test
                                                                                         public void testSkip_WhenNumToSkipIsZero_ShouldNotPerformAnyOperations1() throws IOException {
                                                                                             // Arrange
                                                                                             InputStream input = mock(InputStream.class);
                                                                                             long numToSkip = 0L;
                                                                                             
                                                                                             // Act
                                                                                             long result = IOUtils.skip(input, numToSkip);
                                                                                             
                                                                                             // Assert
                                                                                             assertEquals(0L, result);
                                                                                             verify(input, never()).skip(anyLong());
                                                                                             verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                         }

    @Test
                                                                                         public void testSkip_WhenStreamReturnsZero_ShouldNotLoopInfinitely1() throws IOException {
                                                                                             // Arrange
                                                                                             InputStream input = mock(InputStream.class);
                                                                                             when(input.skip(anyLong())).thenReturn(0L);
                                                                                             when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                             long numToSkip = 10L;
                                                                                             
                                                                                             // Act
                                                                                             long result = IOUtils.skip(input, numToSkip);
                                                                                             
                                                                                             // Assert
                                                                                             assertEquals(0L, result);
                                                                                             verify(input, times(1)).skip(10L);
                                                                                             verify(input, times(1)).read(any(byte[].class), anyInt(), anyInt());
                                                                                         }

    @Test(timeout = 1000) // Add timeout to catch infinite loop from mutant
                                                                                        public void testSkip_ExactBytesAvailable_ShouldComplete() throws Exception {
                                                                                            // Arrange
                                                                                            final long bytesToSkip = 100L;
                                                                                            InputStream input = mock(InputStream.class);
                                                                                            
                                                                                            // Mock behavior:
                                                                                            // First skip() call returns all requested bytes
                                                                                            when(input.skip(bytesToSkip)).thenReturn(bytesToSkip);
                                                                                            
                                                                                            // Act
                                                                                            long skipped = IOUtils.skip(input, bytesToSkip);
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals("Should have skipped all requested bytes", 
                                                                                                        bytesToSkip, skipped);
                                                                                            verify(input, times(1)).skip(bytesToSkip);
                                                                                            // Should not reach the readFully part
                                                                                            verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                                        }

    @Test
                                                                                       public void testSkip_ShouldCallInputStreamSkipMethod() throws IOException {
                                                                                           // Arrange
                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                           long numToSkip = 100L;
                                                                                           
                                                                                           // Configure the mock to:
                                                                                           // 1. Return 50 when skip(100) is called first time
                                                                                           // 2. Return 0 when skip(50) is called second time (forcing fallback to buffer read)
                                                                                           when(mockInput.skip(100L)).thenReturn(50L);
                                                                                           when(mockInput.skip(50L)).thenReturn(0L);
                                                                                           
                                                                                           // Configure the buffer read to return 50 bytes
                                                                                           when(mockInput.read(any(byte[].class), anyInt(), anyInt())).thenReturn(50);
                                                                                           
                                                                                           // Act
                                                                                           long skipped = IOUtils.skip(mockInput, numToSkip);
                                                                                           
                                                                                           // Assert
                                                                                           // Verify skip was called at least once (would fail on mutant)
                                                                                           verify(mockInput, atLeastOnce()).skip(anyLong());
                                                                                           
                                                                                           // Verify the total skipped is correct (100 - 0 = 100)
                                                                                           assertEquals(100L, skipped);
                                                                                           
                                                                                           // Verify the buffer read was called for the remaining 50 bytes
                                                                                           verify(mockInput).read(any(byte[].class), eq(0), eq(50));
                                                                                       }

    @Test
                                                                             public void testSkipWithNegativeSkippedValue2() throws Exception {
                                                                                 // Arrange
                                                                                 InputStream input = mock(InputStream.class);
                                                                                 long numToSkip = 100;
                                                                                 int bufferSize = 4096; // Common buffer size
                                                                                 
                                                                                 // First skip returns negative value (shouldn't happen per InputStream contract)
                                                                                 when(input.skip(numToSkip)).thenReturn(-1L);
                                                                                 // Subsequent reads return normal values
                                                                                 when(input.read(any(byte[].class), anyInt(), anyInt()))
                                                                                     .thenReturn(bufferSize); // return full read length
                                                                                 
                                                                                 // Act
                                                                                 long skipped = IOUtils.skip(input, numToSkip);
                                                                              
                                                                                 // Assert
                                                                                 // Original behavior should complete skipping all bytes despite negative skip return
                                                                                 assertEquals(numToSkip, skipped);
                                                                                 
                                                                                 // Verify the fallback read was used
                                                                                 verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                                                             }

    @Test
                                                                         public void testSkipWithZeroBytesShouldNotRead2() throws IOException {
                                                                             // Arrange
                                                                             InputStream input = mock(InputStream.class);
                                                                             when(input.skip(anyLong())).thenReturn(0L);
                                                                             
                                                                             // Act
                                                                             long skipped = IOUtils.skip(input, 0);
                                                                             
                                                                             // Assert
                                                                             assertEquals(0, skipped);
                                                                             verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                                             // Also verify readFully isn't called (though we can't directly verify static methods)
                                                                             // The key assertion is that we skip 0 bytes without any read operations
                                                                         }

    @Test
                                                                        public void testSkipWithZeroBytesShouldNotAllocateBuffer() throws IOException {
                                                                            // Arrange
                                                                            InputStream input = mock(InputStream.class);
                                                                            when(input.skip(anyLong())).thenReturn(0L);
                                                                            
                                                                            // Act - try to skip 0 bytes
                                                                            long skipped = IOUtils.skip(input, 0);
                                                                            
                                                                            // Assert
                                                                            assertEquals(0, skipped);
                                                                            verify(input, times(1)).skip(0); // should try skip once
                                                                            verify(input, never()).read(any(byte[].class), anyInt(), anyInt()); // should never try to read
                                                                            verify(input, never()).read(any(byte[].class)); // should never try to read
                                                                            // The mutant would fail this test because it would try to allocate and read into a buffer
                                                                        }

    @Test
                                                              public void testSkipBufferSize1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                  // Arrange
                                                                  InputStream input = mock(InputStream.class);
                                                                  
                                                                  // Use reflection to get private SKIP_BUF_SIZE
                                                                  Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
                                                                  field.setAccessible(true);
                                                                  int skipBufSize = field.getInt(null);
                                                                  
                                                                  long numToSkip = skipBufSize + 1; // Force fallback path
                                                                  
                                                                  // Make first skip return partial skip
                                                                  when(input.skip(numToSkip)).thenReturn(skipBufSize - 1L);
                                                                  
                                                                  // Capture the buffer used in readFully
                                                                  org.mockito.ArgumentCaptor<byte[]> bufferCaptor = org.mockito.ArgumentCaptor.forClass(byte[].class);
                                                                  when(input.read(bufferCaptor.capture(), anyInt(), anyInt()))
                                                                      .thenReturn(skipBufSize) // First read full buffer
                                                                      .thenReturn(2); // Second read remaining 2 bytes
                                                                  
                                                                  // Act
                                                                  long skipped = IOUtils.skip(input, numToSkip);
                                                                  
                                                                  // Assert
                                                                  assertEquals(numToSkip, skipped);
                                                                  
                                                                  // Verify buffer size is exactly SKIP_BUF_SIZE
                                                                  byte[] usedBuffer = bufferCaptor.getValue();
                                                                  assertEquals(skipBufSize, usedBuffer.length);
                                                                  
                                                                  // Verify interactions
                                                                  verify(input, times(1)).skip(numToSkip);
                                                                  verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                                              }

    @Test
                                                          public void testSkip_DetectsMutatedLoopCondition() throws IOException {
                                                              // Setup
                                                              InputStream input = mock(InputStream.class);
                                                              long numToSkip = 10;
                                                              
                                                              // Mock behavior:
                                                              // First skip returns 10 bytes (completing the skip in one operation)
                                                              when(input.skip(numToSkip)).thenReturn(10L);
                                                              
                                                              // The key is that with numToSkip=0, the mutated version would still enter the loop
                                                              // So we need to verify readFully is NOT called when numToSkip reaches 0
                                                              
                                                              // Execute
                                                              long skipped = IOUtils.skip(input, numToSkip);
                                                              
                                                              // Verify
                                                              assertEquals(10, skipped);
                                                              
                                                              // Verify readFully was never called (since skip completed fully)
                                                              verify(input, never()).read(any(byte[].class), anyInt(), anyInt());
                                                              
                                                              // Additional verification that skip was called exactly once
                                                              verify(input, times(1)).skip(anyLong());
                                                          }

    @Test
                                                    public void testSkipWithInsufficientBytesShouldNotLoopInfinitely() throws IOException {
                                                        // Arrange
                                                        InputStream input = mock(InputStream.class);
                                                        when(input.skip(anyLong())).thenReturn(0L); // Simulate stream that can't skip
                                                        when(input.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1); // Simulate EOF
                                                        
                                                        long numToSkip = 100L; // Request to skip more bytes than available
                                                        
                                                        // Act
                                                        long skipped = IOUtils.skip(input, numToSkip);
                                                        
                                                        // Assert
                                                        assertEquals(0L, skipped); // Should return 0 since no bytes could be skipped
                                                        verify(input, atLeastOnce()).skip(anyLong()); // Verify skip was attempted
                                                        verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt()); // Verify read was attempted
                                                    }

    @Test
                                       public void testSkipWithSmallNumToSkipDetectsMathMinMutation() throws IOException {
                                           // Setup
                                           InputStream input = mock(InputStream.class);
                                           long numToSkip = 100;  // Smaller than typical SKIP_BUF_SIZE (8192)
                                           
                                           // Mock behavior:
                                           // First skip() call returns 0 to force fallback to readFully
                                           when(input.skip(numToSkip)).thenReturn(0L);
                                           
                                           // Capture the buffer size used in readFully
                                           final int[] readSize = new int[1];
                                           doAnswer(invocation -> {
                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                               int len = (int) invocation.getArguments()[2];
                                               readSize[0] = len;
                                               // Return that we read all requested bytes
                                               return len;
                                           }).when(input).read(any(byte[].class), anyInt(), anyInt());
                                           
                                           // Execute
                                           long skipped = IOUtils.skip(input, numToSkip);
                                           
                                           // Verify
                                           assertEquals("Should have skipped all requested bytes", numToSkip, skipped);
                                           // This is the key assertion that catches the mutant:
                                           // Original would use min(100, SKIP_BUF_SIZE) = 100
                                           // Mutant would use max(100, SKIP_BUF_SIZE) = SKIP_BUF_SIZE
                                           assertEquals("Should only read the requested number of bytes when smaller than buffer", 
                                                       (int)numToSkip, readSize[0]);
                                       }

    @Test
                                   public void testSkip_DetectsMutant_WhenNumToSkipLargerThanBuffer() throws Exception {
                                       // Arrange
                                       final int SKIP_BUF_SIZE = 8192; // Assuming this is the value from class
                                       final long largeSkip = SKIP_BUF_SIZE + 100; // Larger than buffer size
                                       InputStream input = mock(InputStream.class);
                                       
                                       // Mock behavior:
                                       // First skip returns partial skip
                                       when(input.skip(largeSkip)).thenReturn(100L);
                                       // Subsequent skips return 0 to force fallback to readFully
                                       
                                       // Mock readFully to capture the len parameter
                                       final int[] capturedLen = new int[1];
                                       doAnswer(invocation -> {
                                           capturedLen[0] = (int) invocation.getArguments()[3]; // len parameter
                                           return capturedLen[0]; // return full read
                                       }).when(IOUtils.class);
                                       IOUtils.readFully(any(InputStream.class), any(byte[].class), anyInt(), anyInt());
                                       
                                       // Act
                                       long skipped = IOUtils.skip(input, largeSkip);
                                       
                                       // Assert
                                       // Verify the mutant would be caught by checking we never try to read more than SKIP_BUF_SIZE
                                       assertTrue("Should not try to read more than SKIP_BUF_SIZE at once", 
                                                  capturedLen[0] <= SKIP_BUF_SIZE);
                                       // Verify we skipped the correct amount
                                       assertEquals(largeSkip, skipped);
                                   }

    @Test
                                  public void testSkipWithPartialReads() throws IOException {
                                      // Setup mock input stream that will:
                                      // 1. Return 0 on first skip attempt (forcing fallback to readFully)
                                      // 2. Return 0 on first readFully attempt (but stream not ended)
                                      // 3. Return remaining bytes on subsequent read
                                      InputStream input = mock(InputStream.class);
                                      when(input.skip(anyLong())).thenReturn(0L);
                                      
                                      // First readFully returns 0 (but stream not ended)
                                      // Second readFully returns remaining bytes
                                      when(input.read(any(byte[].class), anyInt(), anyInt()))
                                          .thenReturn(0)
                                          .thenReturn(10);
                                      
                                      // We want to skip 20 bytes
                                      long numToSkip = 20;
                                      
                                      // Original behavior should skip all 20 bytes (0 + 10 + 10)
                                      // Mutated behavior would stop after first readFully returns 0
                                      long skipped = IOUtils.skip(input, numToSkip);
                                      
                                      // Verify original behavior would continue reading after 0
                                      assertEquals(20, skipped);
                                      
                                      // Verify we made the expected calls
                                      verify(input, times(1)).skip(20);
                                      verify(input, times(2)).read(any(byte[].class), anyInt(), anyInt());
                                  }

    @Test
                                public void testSkip_DetectsMutantWhenReadFullyReturnsZero() throws Exception {
                                    // Arrange
                                    InputStream input = mock(InputStream.class);
                                    long numToSkip = 1024; // Request to skip 1KB
                                    
                                    // First skip() call will skip some bytes but not all
                                    when(input.skip(numToSkip)).thenReturn(512L);
                                    
                                    // Subsequent readFully calls will return 0 (end of stream)
                                    // This is where the mutant differs - original would break, mutant would always break
                                    // Using standard buffer size of 8192 which is common for I/O operations
                                    byte[] expectedBuffer = new byte[8192];
                                    
                                    // Act
                                    long actuallySkipped = IOUtils.skip(input, numToSkip);
                                    
                                    // Assert
                                    // Original behavior would return 512 (only what was skipped before hitting end)
                                    // Mutant behavior would return 1024 (incorrectly reporting full skip)
                                    assertEquals("Should only count actually skipped bytes when hitting end of stream", 
                                                512L, actuallySkipped);
                                    
                                    // Verify interactions
                                    verify(input).skip(numToSkip);
                                    verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                                }

    @Test
                   public void testSkipWithPartialReadsShouldReturnCorrectCount() throws IOException {
                       // Arrange
                       InputStream input = mock(InputStream.class);
                       when(input.skip(anyLong())).thenReturn(0L); // Force fallback to readFully
                       when(input.read(any(byte[].class), anyInt(), anyInt()))
                           .thenAnswer(invocation -> {
                               byte[] buf = (byte[]) invocation.getArguments()[0];
                               int off = (Integer) invocation.getArguments()[1];
                               int len = (Integer) invocation.getArguments()[2];
                               // Return partial read (less than requested)
                               return Math.min(5, len);
                           })
                           .thenReturn(-1); // EOF
                       
                       long numToSkip = 10;
                       
                       // Act
                       long skipped = IOUtils.skip(input, numToSkip);
                       
                       // Assert
                       // Original would return 5 (from partial read) then stop at EOF
                       // Mutant would either:
                       // - Return wrong count (if test ends)
                       // - Hang indefinitely (if stream keeps providing data)
                       assertEquals(5, skipped);
                       
                       // Verify we called read with expected parameters
                       verify(input, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
                   }

    @Test
          public void testSkipWithPartialReadsDetectsMutant1() throws IOException {
              // Setup mock InputStream that will require multiple reads
              InputStream mockInput = mock(InputStream.class);
              
              // First skip() call returns partial skip
              when(mockInput.skip(anyLong())).thenReturn(10L);
              
              // Then simulate partial reads when readFully is called
              // First read returns 100 bytes, second returns 50 (should need 140 more)
              // With mutant, this would set numToSkip to 50 instead of decreasing by 50
              when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
                  .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                      private int count = 0;
                      @Override
                      public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                          int len = (Integer)invocation.getArguments()[2];
                          if (count++ == 0) {
                              return len > 100 ? 100 : 50;
                          } else {
                              return 50;
                          }
                      }
                  });
              
              // Test skipping 200 bytes (10 via skip, 100 + 50 via reads, then 40 more)
              long skipped = IOUtils.skip(mockInput, 200);
              
              // Original would return 200 (10+100+50+40), mutant would return wrong value
              assertEquals("Should have skipped all requested bytes", 200, skipped);
              
              // Verify interaction - should have called skip once and read multiple times
              verify(mockInput, times(1)).skip(200);
              verify(mockInput, atLeast(2)).read(any(byte[].class), anyInt(), anyInt());
          }

    @Test
      public void testSkipCallsInputSkipWithCorrectParameter() throws Exception {
          // Arrange
          InputStream mockInput = mock(InputStream.class);
          long numToSkip = 100L;
          
          // Set up mock behavior
          when(mockInput.skip(numToSkip)).thenReturn(numToSkip);
          
          // Act
          long result = IOUtils.skip(mockInput, numToSkip);
          
          // Assert
          // Verify skip was called with the correct parameter
          verify(mockInput).skip(numToSkip);
          assertEquals("Should have skipped all bytes", numToSkip, result);
          
          // Additional verification that we didn't fall back to buffer reading
          verify(mockInput, never()).read(any(byte[].class), anyInt(), anyInt());
      }

    @Test
    public void testSkipWithPartialReadsAndBufferOffset() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Get the private SKIP_BUF_SIZE constant via reflection
        Field field = IOUtils.class.getDeclaredField("SKIP_BUF_SIZE");
        field.setAccessible(true);
        int SKIP_BUF_SIZE = field.getInt(null);
        
        // Setup mock InputStream that will:
        // 1. Return 0 on first skip() to force buffer read path
        // 2. Return specific byte pattern when read
        InputStream mockInput = mock(InputStream.class);
        when(mockInput.skip(anyLong())).thenReturn(0L);
        
        // Setup to return 3 bytes when readFully is called (less than SKIP_BUF_SIZE)
        final byte[] testData = new byte[]{1, 2, 3};
        when(mockInput.read(any(byte[].class), anyInt(), anyInt()))
            .thenAnswer(invocation -> {
                byte[] buf = (byte[]) invocation.getArguments()[0];
                int offset = (Integer) invocation.getArguments()[1];
                int len = (Integer) invocation.getArguments()[2];
                
                // Verify offset is 0 (original behavior)
                // This will fail with the mutant which uses offset 1
                assertEquals(0, offset);
                
                System.arraycopy(testData, 0, buf, offset, Math.min(len, testData.length));
                return testData.length;
            });
     
        // Test skipping exactly SKIP_BUF_SIZE bytes to hit boundary condition
        long skipped = IOUtils.skip(mockInput, SKIP_BUF_SIZE);
        
        // Verify correct number of bytes were skipped
        assertEquals(SKIP_BUF_SIZE, skipped);
        
        // Verify mock interactions
        verify(mockInput, atLeastOnce()).skip(anyLong());
        verify(mockInput, atLeastOnce()).read(any(byte[].class), anyInt(), anyInt());
    }


}
