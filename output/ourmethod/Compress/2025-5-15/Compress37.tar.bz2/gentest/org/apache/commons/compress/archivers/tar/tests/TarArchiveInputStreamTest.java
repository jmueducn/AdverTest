package gentest.gentest.org.apache.commons.compress.archivers.tar.tests.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import gentest.org.apache.commons.compress.archivers.tar.tests.*;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.Assert;
import org.mockito.Mockito;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class TarArchiveInputStreamTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                public void testParsePaxHeaders_SingleHeader() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    String input = "21 comment=Hello World\\n";
                                                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                                                    
                                                                                                                                                                    // Get the parsePaxHeaders method via reflection
                                                                                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(1, result.size());
                                                                                                                                                                    assertEquals("Hello World", result.get("comment"));
                                                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_MultipleHeaders() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "21 comment=Hello World\\n25 path=usr/local/bin\\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Get the parsePaxHeaders method via reflection
                                                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals(2, result.size());
                                                                                                                                    assertEquals("Hello World", result.get("comment"));
                                                                                                                                    assertEquals("usr/local/bin", result.get("path"));
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_EmptyValue() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "12 comment=\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Get the parsePaxHeaders method via reflection
                                                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals(1, result.size());
                                                                                                                                    assertEquals("", result.get("comment"));
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_RemoveHeader() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "12 comment=\\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Set up global headers using reflection
                                                                                                                                    Map<String, String> globalHeaders = new HashMap<>();
                                                                                                                                    globalHeaders.put("comment", "old value");
                                                                                                                                    
                                                                                                                                    Field globalPaxHeadersField = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                                                                    globalPaxHeadersField.setAccessible(true);
                                                                                                                                    globalPaxHeadersField.set(tarInput, globalHeaders);
                                                                                                                                    
                                                                                                                                    // Get parsePaxHeaders method using reflection
                                                                                                                                    Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeadersMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals(0, result.size());
                                                                                                                                    assertNull(result.get("comment"));
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_WithGlobalHeaders() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "21 comment=Hello World\\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    Map<String, String> globalHeaders = new HashMap<>();
                                                                                                                                    globalHeaders.put("path", "global/path");
                                                                                                                                    
                                                                                                                                    // Use reflection to set private field
                                                                                                                                    Field globalPaxHeadersField = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                                                                    globalPaxHeadersField.setAccessible(true);
                                                                                                                                    globalPaxHeadersField.set(tarInput, globalHeaders);
                                                                                                                                    
                                                                                                                                    // Use reflection to call package-private method
                                                                                                                                    Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeadersMethod.setAccessible(true);
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals(2, result.size());
                                                                                                                                    assertEquals("Hello World", result.get("comment"));
                                                                                                                                    assertEquals("global/path", result.get("path"));
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_IncompleteRead() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "100 comment=This is too short\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Get the private parsePaxHeaders method via reflection
                                                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                                                    
                                                                                                                                    try {
                                                                                                                                        // Execute
                                                                                                                                        parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                                        fail("Expected IOException to be thrown");
                                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                                        // Verify
                                                                                                                                        assertTrue(e.getCause() instanceof IOException);
                                                                                                                                        assertEquals("Failed to read Paxheader. Expected 96 bytes, read 0", 
                                                                                                                                                   e.getCause().getMessage());
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_EmptyInput() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Get the private method via reflection
                                                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertTrue(result.isEmpty());
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_BlankLine() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    String input = "\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Get the parsePaxHeaders method via reflection
                                                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertTrue(result.isEmpty());
                                                                                                                                }

    @Test
                                                                                                                                public void testParsePaxHeaders_NonUTF8Encoding() throws Exception {
                                                                                                                                    // Setup - Using a character that's different in UTF-8 vs other encodings
                                                                                                                                    String input = "16 comment=Héllo\n";
                                                                                                                                    InputStream mockInput = new ByteArrayInputStream(input.getBytes("ISO-8859-1"));
                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput, "ISO-8859-1");
                                                                                                                                    
                                                                                                                                    // Use reflection to access the private method
                                                                                                                                    Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                    parsePaxHeadersMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, String> result = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInput, mockInput);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals(1, result.size());
                                                                                                                                    // The exact value might differ based on encoding handling
                                                                                                                                    assertNotNull(result.get("comment"));
                                                                                                                                }

    @Test
                                                                                                                            public void testParsePaxHeaders_InvalidLength() throws Exception {
                                                                                                                                // Setup
                                                                                                                                String input = "abc comment=Hello\\n";
                                                                                                                                InputStream mockInput = new ByteArrayInputStream(input.getBytes());
                                                                                                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                                                
                                                                                                                                // Get the private parsePaxHeaders method via reflection
                                                                                                                                Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                                parsePaxHeaders.setAccessible(true);
                                                                                                                                
                                                                                                                                // Expected exception
                                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                                exception.expect(IOException.class);
                                                                                                                                exception.expectMessage("Failed to read Paxheader");
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                                            }

    @Test
                                                                                                                       public void testParsePaxHeadersWithMinimalHeader() throws IOException {
                                                                                                                           // Setup
                                                                                                                           String headerData = "3 a=b\n";
                                                                                                                           InputStream input = new ByteArrayInputStream(headerData.getBytes("UTF-8"));
                                                                                                                           Map<String, String> globalPaxHeaders = new HashMap<>();
                                                                                                                           TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
                                                                                                                           
                                                                                                                           // Need to set globalPaxHeaders via reflection since it's private
                                                                                                                           try {
                                                                                                                               Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                                                               field.setAccessible(true);
                                                                                                                               field.set(tarInput, globalPaxHeaders);
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Failed to set globalPaxHeaders via reflection");
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Execute - need to use reflection to call private parsePaxHeaders method
                                                                                                                           Map<String, String> result = null;
                                                                                                                           try {
                                                                                                                               Method method = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                                               method.setAccessible(true);
                                                                                                                               result = (Map<String, String>) method.invoke(tarInput, input);
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Failed to invoke parsePaxHeaders via reflection");
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Verify
                                                                                                                           assertEquals(1, result.size());
                                                                                                                           assertEquals("b", result.get("a"));
                                                                                                                           
                                                                                                                           // Additional verification that the length was calculated correctly
                                                                                                                           // The mutant would fail here because with read=1 initially,
                                                                                                                           // it would calculate restLen incorrectly and either:
                                                                                                                           // - throw an exception (if it tries to read negative length)
                                                                                                                           // - or store wrong value (if it reads wrong number of bytes)
                                                                                                                       }

    @Test
                                                                                                          public void testParsePaxHeadersDetectsReadDecrementMutant() throws Exception {
                                                                                                              // Prepare test data - simple header "11 key=val\\n" (11 chars total)
                                                                                                              // Breakdown: "11 " (3) + "key=" (4) + "val\\n" (4) = 11 bytes
                                                                                                              byte[] testData = "11 key=val\n".getBytes("UTF-8");
                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                              
                                                                                                              // Setup mock to return bytes one by one with call count tracking
                                                                                                              final java.util.concurrent.atomic.AtomicInteger callCount = new java.util.concurrent.atomic.AtomicInteger(0);
                                                                                                              when(mockInput.read()).thenAnswer(inv -> {
                                                                                                                  int currentCount = callCount.getAndIncrement();
                                                                                                                  return currentCount < testData.length ? testData[currentCount] : -1;
                                                                                                              });
                                                                                                              
                                                                                                              // Create instance and call method
                                                                                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                                                              
                                                                                                              // Use reflection to access private parsePaxHeaders method
                                                                                                              Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                              parsePaxHeaders.setAccessible(true);
                                                                                                              @SuppressWarnings("unchecked")
                                                                                                              Map<String, String> headers = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                                                              
                                                                                                              // Verify results
                                                                                                              assertEquals(1, headers.size());
                                                                                                              assertEquals("val", headers.get("key"));
                                                                                                              
                                                                                                              // Verify mock interactions - should read exactly 11 bytes
                                                                                                              verify(mockInput, times(11)).read();
                                                                                                              
                                                                                                              // The mutant would fail because:
                                                                                                              // 1. With read--, the byte count would be wrong
                                                                                                              // 2. restLen calculation would be incorrect (11 - wrong_read_count)
                                                                                                              // 3. Either array size would be wrong or wrong bytes would be read
                                                                                                              // 4. Might throw exception or return wrong value
                                                                                                          }

    @Test
                                                                                                     public void testParsePaxHeaders_SpaceAfterLength() throws IOException {
                                                                                                         // Setup test data - input with space after length
                                                                                                         String testInput = "25 comment=This is a comment\n";
                                                                                                         InputStream input = new ByteArrayInputStream(testInput.getBytes("UTF-8"));
                                                                                                         
                                                                                                         // Initialize global headers if needed
                                                                                                         Map<String, String> globalPaxHeaders = new HashMap<>();
                                                                                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
                                                                                                         
                                                                                                         // Use reflection to set globalPaxHeaders since it's private
                                                                                                         try {
                                                                                                             Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                                             field.setAccessible(true);
                                                                                                             field.set(tarInput, globalPaxHeaders);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to set globalPaxHeaders via reflection");
                                                                                                         }
                                                                                                         
                                                                                                         // Call parsePaxHeaders - this is package-private so we need to make it accessible
                                                                                                         Map<String, String> headers;
                                                                                                         try {
                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                             method.setAccessible(true);
                                                                                                             headers = (Map<String, String>) method.invoke(tarInput, input);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to invoke parsePaxHeaders via reflection");
                                                                                                             return;
                                                                                                         }
                                                                                                         
                                                                                                         // Verify results
                                                                                                         assertEquals(1, headers.size());
                                                                                                         assertEquals("This is a comment", headers.get("comment"));
                                                                                                         
                                                                                                         // Now test with input that would fail with mutant (no space after length)
                                                                                                         String mutantTestInput = "25comment=This should fail\n";
                                                                                                         InputStream mutantInput = new ByteArrayInputStream(mutantTestInput.getBytes("UTF-8"));
                                                                                                         
                                                                                                         try {
                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                             method.setAccessible(true);
                                                                                                             Map<String, String> mutantHeaders = (Map<String, String>) method.invoke(tarInput, mutantInput);
                                                                                                             
                                                                                                             // With original code, this should be empty (can't parse without space)
                                                                                                             // With mutant code, it would incorrectly parse "25comment" as keyword
                                                                                                             assertTrue(mutantHeaders.isEmpty());
                                                                                                         } catch (Exception e) {
                                                                                                             // Original code should throw IOException when parsing fails
                                                                                                             assertTrue(e.getCause() instanceof IOException);
                                                                                                         }
                                                                                                     }

    @Test
                                                                                                public void testParsePaxHeaders_DetectsNullOutputStreamMutant() throws Exception {
                                                                                                    // Prepare test data - a simple PAX header "11 keyword=value\n"
                                                                                                    byte[] testData = "11 keyword=value\n".getBytes("UTF-8");
                                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                                    
                                                                                                    // Mock the InputStream behavior
                                                                                                    when(mockInputStream.read())
                                                                                                        .thenReturn((int) '1')  // first digit of length
                                                                                                        .thenReturn((int) '1')  // second digit of length
                                                                                                        .thenReturn((int) ' ')  // space after length
                                                                                                        .thenReturn((int) 'k')  // start of keyword
                                                                                                        .thenReturn((int) 'e')
                                                                                                        .thenReturn((int) 'y')
                                                                                                        .thenReturn((int) 'w')
                                                                                                        .thenReturn((int) 'o')
                                                                                                        .thenReturn((int) 'r')
                                                                                                        .thenReturn((int) 'd')
                                                                                                        .thenReturn((int) '=')  // end of keyword
                                                                                                        .thenReturn((int) 'v')  // start of value
                                                                                                        .thenReturn((int) 'a')
                                                                                                        .thenReturn((int) 'l')
                                                                                                        .thenReturn((int) 'u')
                                                                                                        .thenReturn((int) 'e')
                                                                                                        .thenReturn((int) '\n') // end of header
                                                                                                        .thenReturn(-1);        // EOF
                                                                                                    
                                                                                                    // Create test instance
                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInputStream);
                                                                                                    
                                                                                                    // Use reflection to access the private parsePaxHeaders method
                                                                                                    Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                                    parsePaxHeaders.setAccessible(true);
                                                                                                    
                                                                                                    // This will throw NullPointerException with the mutant
                                                                                                    // With original code, it would process the header normally
                                                                                                    parsePaxHeaders.invoke(tarInput, mockInputStream);
                                                                                                    
                                                                                                    // If we get here with original code, verify header was processed
                                                                                                    // But mutant will throw before this point
                                                                                                    Map<String, String> headers = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInputStream);
                                                                                                    assertEquals("value", headers.get("keyword"));
                                                                                                }

    @Test
                                                                                           public void testParsePaxHeadersWithMultiByteKeyword() throws Exception {
                                                                                               // Setup test data - header with multi-byte keyword
                                                                                               String keyword = "longkeyword"; // 10 bytes
                                                                                               String value = "testvalue";
                                                                                               String header = "25 " + keyword + "=" + value + "\n"; // 25 = length(2) + space(1) + keyword(10) + =(1) + value(9) + \n(1)
                                                                                               
                                                                                               // Create input stream with test data
                                                                                               InputStream input = new ByteArrayInputStream(header.getBytes("UTF-8"));
                                                                                               
                                                                                               // Create TarArchiveInputStream
                                                                                               TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
                                                                                               
                                                                                               // Use reflection to access private parsePaxHeaders method
                                                                                               Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                               parsePaxHeaders.setAccessible(true);
                                                                                               
                                                                                               // Call method under test
                                                                                               @SuppressWarnings("unchecked")
                                                                                               Map<String, String> headers = (Map<String, String>) parsePaxHeaders.invoke(tarInput, input);
                                                                                               
                                                                                               // Verify results
                                                                                               assertEquals(1, headers.size());
                                                                                               assertEquals(value, headers.get(keyword));
                                                                                               
                                                                                               // The mutation would cause restLen to be calculated incorrectly (25 - 0 instead of 25 - 13)
                                                                                               // This would either throw IOException (if buffer too small) or store wrong value
                                                                                               // Our assertion verifies correct value was stored
                                                                                           }

    @Test
                                                                                      public void testParsePaxHeadersDetectsEqualsSignMutation() throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
                                                                                          // Setup test data - valid PAX header format
                                                                                          String keyword = "testkey";
                                                                                          String value = "testvalue";
                                                                                          String paxHeader = "21 " + keyword + "=" + value + "\n"; // "21 " is length of rest
                                                                                          
                                                                                          // Convert to bytes for InputStream
                                                                                          byte[] bytes = paxHeader.getBytes("UTF-8");
                                                                                          InputStream inputStream = new ByteArrayInputStream(bytes);
                                                                                          
                                                                                          // Initialize global headers if needed
                                                                                          Map<String, String> globalPaxHeaders = new HashMap<String, String>();
                                                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                                                                          
                                                                                          // Use reflection to set globalPaxHeaders since it's private
                                                                                          try {
                                                                                              Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                              field.setAccessible(true);
                                                                                              field.set(tarInput, globalPaxHeaders);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to set globalPaxHeaders via reflection");
                                                                                          }
                                                                                          
                                                                                          // Use reflection to access private parsePaxHeaders method
                                                                                          Method parsePaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                          parsePaxHeadersMethod.setAccessible(true);
                                                                                          @SuppressWarnings("unchecked")
                                                                                          Map<String, String> headers = (Map<String, String>) parsePaxHeadersMethod.invoke(tarInput, inputStream);
                                                                                          
                                                                                          // Verify the header was parsed correctly
                                                                                          assertEquals(1, headers.size());
                                                                                          assertEquals(value, headers.get(keyword));
                                                                                          
                                                                                          // The mutant would fail here because:
                                                                                          // 1. With if(ch != '='), it would process the keyword incorrectly
                                                                                          // 2. Would either not store the value or store incorrect key
                                                                                          // 3. Might throw exception due to incorrect parsing
                                                                                      }

    @Test
                                                                                 public void testParsePaxHeadersDetectsKeywordMutation() throws IOException {
                                                                                     // Prepare test data - valid PAX header format
                                                                                     String headerData = "21 path=/test/path\n";
                                                                                     java.io.ByteArrayInputStream inputStream = new java.io.ByteArrayInputStream(headerData.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                                                                                     
                                                                                     // Initialize global headers if needed
                                                                                     Map<String, String> globalPaxHeaders = new HashMap<String, String>();
                                                                                     TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                                                                     
                                                                                     // Use reflection to set globalPaxHeaders since it's private
                                                                                     try {
                                                                                         Field globalHeadersField = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                         globalHeadersField.setAccessible(true);
                                                                                         globalHeadersField.set(tarInput, globalPaxHeaders);
                                                                                     } catch (Exception e) {
                                                                                         fail("Failed to set globalPaxHeaders field");
                                                                                     }
                                                                                     
                                                                                     // Call parsePaxHeaders through reflection since it's private
                                                                                     Map<String, String> headers;
                                                                                     try {
                                                                                         Method parseMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                         parseMethod.setAccessible(true);
                                                                                         headers = (Map<String, String>) parseMethod.invoke(tarInput, inputStream);
                                                                                     } catch (Exception e) {
                                                                                         fail("Failed to invoke parsePaxHeaders method");
                                                                                         return;
                                                                                     }
                                                                                     
                                                                                     // Verify the keyword was properly parsed
                                                                                     assertTrue("Header should contain 'path' key", headers.containsKey("path"));
                                                                                     assertEquals("/test/path", headers.get("path"));
                                                                                     
                                                                                     // Additional check that empty string is not a key
                                                                                     assertFalse("Empty string should not be a key", headers.containsKey(""));
                                                                                 }

    @Test
                                                                            public void testParsePaxHeaders_restLenNot() throws IOException {
                                                                                // Setup
                                                                                Map<String, String> globalPaxHeaders = new HashMap<>();
                                                                                globalPaxHeaders.put("existing", "value");
                                                                                
                                                                                // Mock input stream that provides: "12 keyword=value\n" (restLen=11 case)
                                                                                byte[] inputBytes = "12 keyword=value\n".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                                                                InputStream mockInputStream = new ByteArrayInputStream(inputBytes);
                                                                                
                                                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInputStream);
                                                                                try {
                                                                                    Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                    field.setAccessible(true);
                                                                                    field.set(tarInput, globalPaxHeaders);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set globalPaxHeaders via reflection");
                                                                                }
                                                                                
                                                                                // Test - should keep "keyword" when restLen≠1
                                                                                Map<String, String> result = null;
                                                                                try {
                                                                                    Method method = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                                    method.setAccessible(true);
                                                                                    result = (Map<String, String>) method.invoke(tarInput, mockInputStream);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to invoke parsePaxHeaders via reflection");
                                                                                }
                                                                                
                                                                                // Verify
                                                                                assertEquals("Header should be kept when restLen≠1", "value", result.get("keyword"));
                                                                                assertEquals("Existing headers should remain", "value", result.get("existing"));
                                                                                
                                                                                // This would fail with mutant (would remove the header)
                                                                                assertNotNull("Header value should not be null (kept)", result.get("keyword"));
                                                                            }

    @Test
                                                                        public void testParsePaxHeaders_restLenEquals() throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
                                                                            // Setup
                                                                            Map<String, String> globalPaxHeaders = new HashMap<>();
                                                                            globalPaxHeaders.put("existing", "value");
                                                                            
                                                                            // Mock input stream that provides: "1 keyword=\n" (restLen=1 case)
                                                                            byte[] inputBytes = "1 keyword=\n".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                                                            InputStream mockInputStream = new ByteArrayInputStream(inputBytes);
                                                                            
                                                                            TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInputStream);
                                                                            // Use reflection to set globalPaxHeaders since it's private
                                                                            try {
                                                                                Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                field.setAccessible(true);
                                                                                field.set(tarInput, globalPaxHeaders);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set globalPaxHeaders via reflection");
                                                                            }
                                                                            
                                                                            // Get parsePaxHeaders method via reflection
                                                                            Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                            parsePaxHeaders.setAccessible(true);
                                                                            
                                                                            // Test - should remove "keyword" when restLen=1
                                                                            @SuppressWarnings("unchecked")
                                                                            Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInputStream);
                                                                            
                                                                            // Verify
                                                                            assertFalse("Header should be removed when restLen=1", result.containsKey("keyword"));
                                                                            assertEquals("Existing headers should remain", "value", result.get("existing"));
                                                                            
                                                                            // Now test with mutant (would keep the header)
                                                                            // This is the key assertion that would fail with the mutant
                                                                            assertNull("Header value should be null (removed)", result.get("keyword"));
                                                                        }

    @Test
                                                                                           public void testParsePaxHeadersShouldRemoveKeywordWhenRestLenIs() throws Exception {
                                                                                               // Prepare test data - header with length 1 (only newline)
                                                                                               String testHeader = "1 keyword=\\n";
                                                                                               java.io.ByteArrayInputStream mockInputStream = new java.io.ByteArrayInputStream(testHeader.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                                                                                               
                                                                                               // Initialize global headers with some data
                                                                                               java.util.Map<String, String> globalPaxHeaders = new java.util.HashMap<>();
                                                                                               globalPaxHeaders.put("keyword", "value");
                                                                                               
                                                                                               // Create test instance - need to use reflection to set globalPaxHeaders
                                                                                               TarArchiveInputStream tarInput = new TarArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
                                                                                               java.lang.reflect.Field globalHeadersField = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                                                               globalHeadersField.setAccessible(true);
                                                                                               globalHeadersField.set(tarInput, globalPaxHeaders);
                                                                                               
                                                                                               // Call the method under test using reflection
                                                                                               java.lang.reflect.Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", java.io.InputStream.class);
                                                                                               parsePaxHeaders.setAccessible(true);
                                                                                               java.util.Map<String, String> result = (java.util.Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInputStream);
                                                                                               
                                                                                               // Verify the keyword was removed (original behavior)
                                                                                               assertFalse("Keyword should be removed when restLen is 1", result.containsKey("keyword"));
                                                                                               
                                                                                               // Additional verification that the map is not null and other entries remain
                                                                                               assertNotNull("Headers map should not be null", result);
                                                                                           }

    @Test
                                                              public void testParsePaxHeadersWithValueShouldReadCompleteValue() throws Exception {
                                                                  // Prepare test data - header with length 15, keyword "key" and value "value"
                                                                  String headerData = "15 key=value\n";
                                                                  InputStream mockInput = new ByteArrayInputStream(headerData.getBytes("UTF-8"));
                                                                  
                                                                  // Create instance (using simplest constructor)
                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                                  
                                                                  // Get the private parsePaxHeaders method via reflection
                                                                  Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                  parsePaxHeaders.setAccessible(true);
                                                                  
                                                                  // Call method under test
                                                                  @SuppressWarnings("unchecked")
                                                                  Map<String, String> result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                                  
                                                                  // Verify behavior
                                                                  assertEquals(1, result.size());
                                                                  assertEquals("value", result.get("key"));
                                                                  
                                                                  // Additional verification that the full value was read
                                                                  // If mutant is present, this would throw IOException instead
                                                              }

    @Test
                                                              public void testParsePaxHeadersDetectsBufferSizeMutation() throws Exception {
                                                                  // Setup - create a header with a value that needs reading
                                                                  String header = "16 user.name=john.doe\n";
                                                                  InputStream input = new ByteArrayInputStream(header.getBytes("UTF-8"));
                                                                  
                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
                                                                  
                                                                  // Use reflection to access private parsePaxHeaders method
                                                                  Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                                  parsePaxHeaders.setAccessible(true);
                                                                  
                                                                  // Test - this will throw IOException if mutant is present
                                                                  @SuppressWarnings("unchecked")
                                                                  Map<String, String> headers = (Map<String, String>) parsePaxHeaders.invoke(tarInput, input);
                                                                  
                                                                  // Verify
                                                                  assertEquals("john.doe", headers.get("user.name"));
                                                                  assertEquals(1, headers.size());
                                                              }

    @Test
                                                         public void testParsePaxHeadersWithValidEntryShouldReadValueCorrectly() throws Exception {
                                                             // Prepare test data - a valid PAX header entry
                                                             String headerData = "25 comment=Hello World\n"; // length=25, keyword=comment, value=Hello World
                                                             byte[] headerBytes = headerData.getBytes("UTF-8");
                                                             
                                                             // Mock the InputStream to return our test data
                                                             InputStream mockInput = mock(InputStream.class);
                                                             
                                                             // Setup mock behavior:
                                                             // First return each character of "25 " (length part)
                                                             when(mockInput.read()).thenReturn(
                                                                 (int)'2', (int)'5', (int)' ',
                                                                 // Then return each character of "comment=" (keyword part)
                                                                 (int)'c', (int)'o', (int)'m', (int)'m', (int)'e', (int)'n', (int)'t', (int)'=',
                                                                 // Then return the value "Hello World\n" (11 chars + newline)
                                                                 (int)'H', (int)'e', (int)'l', (int)'l', (int)'o', (int)' ',
                                                                 (int)'W', (int)'o', (int)'r', (int)'l', (int)'d', (int)'\n',
                                                                 // Finally return -1 for EOF
                                                                 -1);
                                                             
                                                             // Create instance
                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                             
                                                             // Use reflection to access private parsePaxHeaders method
                                                             Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                             parsePaxHeaders.setAccessible(true);
                                                             @SuppressWarnings("unchecked")
                                                             Map<String, String> headers = (Map<String, String>) parsePaxHeaders.invoke(tarInput, mockInput);
                                                             
                                                             // Verify results
                                                             assertEquals(1, headers.size());
                                                             assertEquals("Hello World", headers.get("comment"));
                                                             
                                                             // Verify mock interactions
                                                             verify(mockInput, atLeastOnce()).read();
                                                         }

    @Test
                                                    public void testParsePaxHeaders_ShouldAddValidEntry() throws IOException {
                                                        // Prepare test data - a valid PAX header "11 key=value\n"
                                                        byte[] testData = "11 key=value\n".getBytes(java.nio.charset.StandardCharsets.UTF_8);
                                                        InputStream mockInput = new ByteArrayInputStream(testData);
                                                        
                                                        // Initialize global headers (empty in this case)
                                                        Map<String, String> globalPaxHeaders = new HashMap<>();
                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                        
                                                        // Use reflection to set globalPaxHeaders since it's private
                                                        try {
                                                            Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                            field.setAccessible(true);
                                                            field.set(tarInput, globalPaxHeaders);
                                                        } catch (Exception e) {
                                                            fail("Failed to set globalPaxHeaders via reflection");
                                                        }
                                                        
                                                        // Call parsePaxHeaders - using reflection since it's private
                                                        Map<String, String> result;
                                                        try {
                                                            Method method = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                            method.setAccessible(true);
                                                            result = (Map<String, String>) method.invoke(tarInput, mockInput);
                                                        } catch (Exception e) {
                                                            fail("Failed to invoke parsePaxHeaders via reflection");
                                                            return;
                                                        }
                                                        
                                                        // Verify the header was added
                                                        assertNotNull("Result map should not be null", result);
                                                        assertEquals("Map should contain exactly one entry", 1, result.size());
                                                        assertTrue("Map should contain 'key'", result.containsKey("key"));
                                                        assertEquals("Value should be 'value'", "value", result.get("key"));
                                                        
                                                        // Additional verification that the entry was actually added (not removed)
                                                        assertNotEquals("Map should not be empty", java.util.Collections.emptyMap(), result);
                                                    }

    @Test
                                               public void testParsePaxHeadersWithMultipleHeadersDetectsMutant() throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
                                                   // Setup test data with multiple headers
                                                   String header1 = "21 comment=This is a comment\n";
                                                   String header2 = "25 path=some/file/name.txt\n";
                                                   String input = header1 + header2;
                                                   InputStream inputStream = new ByteArrayInputStream(input.getBytes("UTF-8"));
                                                   
                                                   // Initialize global headers if needed
                                                   Map<String, String> globalPaxHeaders = new HashMap<String, String>();
                                                   TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                                   
                                                   // Use reflection to set globalPaxHeaders since it's private
                                                   try {
                                                       Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                       field.setAccessible(true);
                                                       field.set(tarInput, globalPaxHeaders);
                                                   } catch (Exception e) {
                                                       fail("Failed to set globalPaxHeaders via reflection");
                                                   }
                                                   
                                                   // Use reflection to call parsePaxHeaders
                                                   Map<String, String> result = null;
                                                   try {
                                                       Method method = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                       method.setAccessible(true);
                                                       result = (Map<String, String>) method.invoke(tarInput, inputStream);
                                                   } catch (Exception e) {
                                                       fail("Failed to invoke parsePaxHeaders via reflection");
                                                   }
                                                   
                                                   // Verify both headers were processed
                                                   assertEquals(2, result.size());
                                                   assertEquals("This is a comment", result.get("comment"));
                                                   assertEquals("some/file/name.txt", result.get("path"));
                                                   
                                                   // Verify stream was fully consumed
                                                   assertEquals(-1, inputStream.read());
                                               }

    @Test
                                          public void testParsePaxHeaders_DetectsReadInitializationMutant() throws Exception {
                                              // Setup test input where length exactly matches bytes read
                                              // Format: "3 a=\n" (3 bytes total: 'a', '=', '\n')
                                              // Original: read increments to 3 (space + 'a' + '='), restLen = 3-3 = 0 (but becomes 1 after NL adjustment)
                                              // Mutant: read starts at 1, increments to 4, restLen = 3-4 = -1 (broken)
                                              byte[] input = "3 a=\n".getBytes("UTF-8");
                                              InputStream mockInput = new ByteArrayInputStream(input);
                                              
                                              // Initialize with empty global headers
                                              Map<String, String> globalPaxHeaders = new HashMap<String, String>();
                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                              
                                              // Use reflection to set globalPaxHeaders since it's private
                                              try {
                                                  Field field = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                  field.setAccessible(true);
                                                  field.set(tarInput, globalPaxHeaders);
                                              } catch (Exception e) {
                                                  fail("Failed to set globalPaxHeaders via reflection");
                                              }
                                              
                                              // Use reflection to call parsePaxHeaders since it's private
                                              Method parseMethod = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                              parseMethod.setAccessible(true);
                                              @SuppressWarnings("unchecked")
                                              Map<String, String> result = (Map<String, String>) parseMethod.invoke(tarInput, mockInput);
                                              
                                              // Verify the header was properly processed
                                              // Original behavior: key 'a' should be removed (restLen becomes 1 after NL adjustment)
                                              // Mutant behavior: would either throw exception or leave key in map
                                              assertFalse("Header 'a' should not be present in result", result.containsKey("a"));
                                              assertTrue("Result map should be empty", result.isEmpty());
                                              
                                              // Additional verification that the stream was fully consumed
                                              assertEquals(-1, mockInput.read());
                                          }

    @Test
                                     public void testParsePaxHeadersDetectsReadDecrementMutant1() throws IOException {
                                         // Setup test data - simple PAX header "11 key=val\n"
                                         byte[] headerBytes = "11 key=val\n".getBytes("UTF-8");
                                         InputStream mockInput = new ByteArrayInputStream(headerBytes);
                                         Map<String, String> globalPaxHeaders = new HashMap<>();
                                         
                                         // Create instance (using reflection since constructor may be private)
                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                         
                                         try {
                                             // Use reflection to access parsePaxHeaders since it's private
                                             Method parseMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                 "parsePaxHeaders", InputStream.class);
                                             parseMethod.setAccessible(true);
                                             
                                             @SuppressWarnings("unchecked")
                                             Map<String, String> headers = (Map<String, String>) parseMethod.invoke(
                                                 tarInput, mockInput);
                                             
                                             // Verify correct parsing
                                             assertEquals(1, headers.size());
                                             assertEquals("val", headers.get("key"));
                                             
                                         } catch (Exception e) {
                                             fail("Should not throw exception for valid input");
                                         }
                                         
                                         // Test with another input that would fail with read--
                                         headerBytes = "15 longer=value\n".getBytes("UTF-8");
                                         mockInput = new ByteArrayInputStream(headerBytes);
                                         
                                         try {
                                             Method parseMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                 "parsePaxHeaders", InputStream.class);
                                             parseMethod.setAccessible(true);
                                             
                                             @SuppressWarnings("unchecked")
                                             Map<String, String> headers = (Map<String, String>) parseMethod.invoke(
                                                 tarInput, mockInput);
                                             
                                             assertEquals(1, headers.size());
                                             assertEquals("value", headers.get("longer"));
                                             
                                         } catch (Exception e) {
                                             // With read-- mutation, this would likely throw an exception
                                             fail("Mutation would cause this to fail with read--");
                                         }
                                     }

    @Test
                                public void testParsePaxHeadersDetectsSpaceAfterLength() throws IOException {
                                    // Prepare test data - a valid PAX header "11 key=value\n" 
                                    // (length=11, space, keyword=key, value=value)
                                    byte[] headerData = "11 key=value\n".getBytes("UTF-8");
                                    InputStream inputStream = new ByteArrayInputStream(headerData);
                                    
                                    // Initialize global headers if needed (empty in this case)
                                    Map<String, String> globalPaxHeaders = new HashMap<String, String>();
                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                    
                                    // Use reflection to set globalPaxHeaders since it's private
                                    try {
                                        Field globalPaxHeadersField = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                        globalPaxHeadersField.setAccessible(true);
                                        globalPaxHeadersField.set(tarInput, globalPaxHeaders);
                                    } catch (Exception e) {
                                        fail("Failed to set globalPaxHeaders field");
                                    }
                                    
                                    // Call parsePaxHeaders through reflection since it's private
                                    Map<String, String> result;
                                    try {
                                        Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                        parsePaxHeaders.setAccessible(true);
                                        result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, inputStream);
                                    } catch (Exception e) {
                                        fail("Failed to invoke parsePaxHeaders method");
                                        return;
                                    }
                                    
                                    // Verify the header was properly parsed
                                    assertEquals(1, result.size());
                                    assertEquals("value", result.get("key"));
                                    
                                    // Additional check for the mutant - if the space wasn't detected properly,
                                    // the header wouldn't be added to the map
                                    assertTrue("Header should contain 'key'", result.containsKey("key"));
                                }

    @Test
                                                   public void testParsePaxHeaders_DetectsNullByteArrayOutputStreamMutant() throws Exception {
                                                       // Prepare test data - a valid PAX header format
                                                       String headerData = "21 comment=Hello World\\n";
                                                       InputStream mockInput = new ByteArrayInputStream(headerData.getBytes("UTF-8"));
                                                       
                                                       // Create instance and set up
                                                       TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInput);
                                                       
                                                       // Get the parsePaxHeaders method via reflection
                                                       Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                       parsePaxHeaders.setAccessible(true);
                                                       
                                                       try {
                                                           // This will throw NullPointerException if mutant is present
                                                           parsePaxHeaders.invoke(tarInput, mockInput);
                                                           
                                                           // If we get here with original code, verify header was processed
                                                           // But mutant would have thrown exception before this point
                                                           fail("Expected NullPointerException from mutant not thrown");
                                                       } catch (InvocationTargetException e) {
                                                           if (e.getCause() instanceof NullPointerException) {
                                                               // This is expected for the mutant
                                                               return;
                                                           }
                                                           throw e;
                                                       }
                                                   }

    @Test
                                              public void testParsePaxHeadersWithEqualsSign() throws IOException {
                                                  // Setup test data - format is "length keyword=value\n"
                                                  String headerContent = "15 key=value\n";
                                                  InputStream inputStream = new java.io.ByteArrayInputStream(headerContent.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                                                  
                                                  // Initialize global headers if needed
                                                  Map<String, String> globalPaxHeaders = new HashMap<String, String>();
                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                                  
                                                  // Use reflection to set globalPaxHeaders since it's private
                                                  try {
                                                      Field globalPaxHeadersField = TarArchiveInputStream.class.getDeclaredField("globalPaxHeaders");
                                                      globalPaxHeadersField.setAccessible(true);
                                                      globalPaxHeadersField.set(tarInput, globalPaxHeaders);
                                                  } catch (Exception e) {
                                                      fail("Failed to set globalPaxHeaders field");
                                                  }
                                                  
                                                  // Call parsePaxHeaders (using reflection since it's private)
                                                  Map<String, String> result;
                                                  try {
                                                      Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", InputStream.class);
                                                      parsePaxHeaders.setAccessible(true);
                                                      result = (Map<String, String>) parsePaxHeaders.invoke(tarInput, inputStream);
                                                  } catch (Exception e) {
                                                      fail("Failed to invoke parsePaxHeaders method");
                                                      return;
                                                  }
                                                  
                                                  // Verify results
                                                  assertEquals(1, result.size());
                                                  assertEquals("value", result.get("key"));
                                                  
                                                  // Verify the '=' was properly handled
                                                  assertFalse(result.containsKey("key=")); // Mutant would include '=' in key
                                                  assertFalse(result.containsKey("key=value")); // Mutant might read entire rest as key
                                              }

    @Test
                                         public void testParsePaxHeaders_restLen1ShouldRemoveHeader() throws Exception {
                                             // Setup test data for case where restLen == 1 (only newline)
                                             String headerData = "21 comment=This is a comment\n"; // len=21, keyword=comment
                                             // The format is "length keyword=value\n"
                                             // For restLen=1 case, we need: len = (length of "comment=") + 1
                                             // "comment=" is 8 chars, so len=9, input="9 comment=\n"
                                             String input = "9 comment=\n";
                                             java.io.InputStream inputStream = new java.io.ByteArrayInputStream(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                                             
                                             // Create instance (using simplest constructor)
                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(inputStream);
                                             
                                             // Call method - need to use reflection since it's private
                                             java.lang.reflect.Method parsePaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("parsePaxHeaders", java.io.InputStream.class);
                                             parsePaxHeaders.setAccessible(true);
                                             
                                             @SuppressWarnings("unchecked")
                                             java.util.Map<String, String> headers = (java.util.Map<String, String>) parsePaxHeaders.invoke(tarInput, inputStream);
                                             
                                             // Verify behavior - original should remove header, mutant would keep it
                                             assertFalse("Header should be removed when restLen is 1", headers.containsKey("comment"));
                                             
                                             // Additional test case where restLen != 1
                                             input = "22 comment=value\n";
                                             inputStream = new java.io.ByteArrayInputStream(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                                             headers = (java.util.Map<String, String>) parsePaxHeaders.invoke(tarInput, inputStream);
                                             assertTrue("Header should be kept when restLen is not 1", headers.containsKey("comment"));
                                             assertEquals("value", headers.get("comment"));
                                         }

}
