package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                      public void testParseOctal_WithLeadingSpaces() {
                                                                                                          // Test with leading spaces
                                                                                                          assertEquals(7L, TarUtils.parseOctal(new byte[]{' ', ' ', '7', ' '}, 0, 4));
                                                                                                          assertEquals(10L, TarUtils.parseOctal(new byte[]{' ', '1', '0', ' '}, 0, 4));
                                                                                                          assertEquals(0L, TarUtils.parseOctal(new byte[]{' ', '0', ' '}, 0, 3));
                                                                                                      }

 @Test
                                                                                                      public void testParseOctal_WithOffset() {
                                                                                                          // Test with non-zero offset
                                                                                                          byte[] buffer = {'x', 'x', ' ', '1', '2', '3', ' ', 'x'};
                                                                                                          assertEquals(83L, TarUtils.parseOctal(buffer, 2, 5));
                                                                                                      }

 @Test
                                                                                                      public void testParseOctal_AllSpaces() {
                                                                                                          // Test when all bytes are spaces
                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                          TarUtils.parseOctal(new byte[]{' ', ' '}, 0, 2);
                                                                                                      }

 @Test
                                                      public void testParseOctal_ValidNumbers() {
                                                          // Test typical octal numbers
                                                          assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', ' '}, 0, 2));
                                                          assertEquals(7L, TarUtils.parseOctal(new byte[]{'7', ' '}, 0, 2));
                                                          assertEquals(10L, TarUtils.parseOctal(new byte[]{'1', '0', ' '}, 0, 3));
                                                          assertEquals(511L, TarUtils.parseOctal(new byte[]{'7', '7', '7', ' '}, 0, 4));
                                                          assertEquals(83L, TarUtils.parseOctal(new byte[]{'1', '2', '3', ' '}, 0, 4));
                                                      }

 @Test
                                                      public void testParseOctal_ZeroValue() {
                                                          // Test when first byte is 0
                                                          assertEquals(0L, TarUtils.parseOctal(new byte[]{0, ' '}, 0, 2));
                                                          assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', ' '}, 0, 2));
                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                      public void testParseOctal_InvalidLength() {
                                                          // Test length < 2
                                                          TarUtils.parseOctal(new byte[]{'1'}, 0, 1);
                                                      }

 @Test
                                                      public void testParseOctal_InvalidTrailer() {
                                                          // Test invalid trailer (not space or NUL)
                                                          try {
                                                              TarUtils.parseOctal(new byte[]{'1', '2'}, 0, 2);
                                                              fail("Expected IllegalArgumentException to be thrown");
                                                          } catch (IllegalArgumentException e) {
                                                              // Expected exception
                                                          }
                                                      }

 @Test
                                                      public void testParseOctal_InvalidDigits() {
                                                          // Test invalid octal digits
                                                          org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                          
                                                          thrown.expect(IllegalArgumentException.class);
                                                          TarUtils.parseOctal(new byte[]{'8', ' '}, 0, 2);
                                                      
                                                          thrown.expect(IllegalArgumentException.class);
                                                          TarUtils.parseOctal(new byte[]{'a', ' '}, 0, 2);
                                                      
                                                          thrown.expect(IllegalArgumentException.class);
                                                          TarUtils.parseOctal(new byte[]{'9', ' '}, 0, 2);
                                                      }

 @Test
                                                      public void testParseOctal_MaximumValidOctal() {
                                                          // Test maximum valid 3-digit octal number
                                                          assertEquals(511L, TarUtils.parseOctal(new byte[]{'7', '7', '7', ' '}, 0, 4));
                                                      }

 @Test(expected = IllegalArgumentException.class)
              public void testParseOctal_DetectsTrailerMutation() {
                  // Arrange
                  byte[] buffer = {
                      ' ',  // valid leading space (start position)
                      '1',  // valid octal digit
                      '2',  // valid octal digit
                      'x'   // invalid trailer (should be space or NUL)
                  };
                  int offset = 0;
                  int length = buffer.length;
                  
                  // Act
                  TarUtils.parseOctal(buffer, offset, length);
                  
                  // Assert
                  // Expecting IllegalArgumentException due to invalid trailer
                  // If mutant is present, this test will fail (no exception thrown)
                  // because it checks buffer[start] (' ') instead of buffer[end-1] ('x')
              }

 @Test(expected = IllegalArgumentException.class)
             public void testParseOctalTrailingCharValidation() {
                 // Create a buffer where:
                 // - offset position is space (valid)
                 // - actual end position is invalid (not space or NUL)
                 byte[] buffer = {
                     ' ', '1', '2', '3', 'x'  // last char 'x' is invalid
                 };
                 int offset = 0;
                 int length = buffer.length;
                 
                 // Original code should throw IllegalArgumentException because of invalid trailing 'x'
                 // Mutant would check buffer[offset] (space) and accept it, missing the invalid 'x'
                 TarUtils.parseOctal(buffer, offset, length);
                 
                 // If mutant is present, this test will fail (no exception thrown)
                 // Original code will pass (exception thrown)
             }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
            public void testParseOctalWithExactLengthBufferShouldNotAccessOutOfBounds() {
                // Create a buffer with valid octal digits and trailing space
                byte[] buffer = {'1', '2', '3', ' '};
                int offset = 0;
                int length = buffer.length; // Exact length
                
                // This should throw ArrayIndexOutOfBoundsException for the mutant
                // but work fine for original code
                TarUtils.parseOctal(buffer, offset, length);
                
                // If we get here, the test fails (mutant survived)
                // because original code would handle this case properly
                // while mutant would throw ArrayIndexOutOfBoundsException
            }

 @Test
           public void testParseOctalWithDifferentStartAndEndTrailers() {
               // Create a buffer where:
               // - start-1 position contains 'a' (invalid trailer)
               // - end-1 position contains ' ' (valid trailer)
               // - actual octal number is "123"
               byte[] buffer = {
                   'a',       // start-1 position (index 0)
                   ' ', ' ',   // leading spaces (indices 1-2)
                   '1', '2', '3', // actual number (indices 3-5)
                   ' '         // valid trailer (index 6)
               };
               
               // Original should pass as it checks the valid trailer at end-1
               // Mutant will fail as it checks the invalid 'a' at start-1
               try {
                   long result = TarUtils.parseOctal(buffer, 1, 6); // offset 1, length 6
                   assertEquals(83L, result); // 1*64 + 2*8 + 3 = 83
               } catch (IllegalArgumentException e) {
                   fail("Valid octal number should be parsed successfully");
               }
           }

 @Test(expected = IllegalArgumentException.class)
          public void testParseOctalDetectsTrailingCharacterMutant() {
              // Create a buffer where first char is valid but last char is invalid
              byte[] buffer = {
                  ' ',  // valid leading space
                  '1',  // valid octal digit
                  '2',  // valid octal digit
                  'x'   // invalid trailer (neither space nor NUL)
              };
              
              // This should throw IllegalArgumentException in original code
              // but would pass in mutant since it checks start instead of end
              TarUtils.parseOctal(buffer, 0, buffer.length);
              
              // If no exception is thrown, the test fails (mutant survives)
          }

 @Test(expected = IllegalArgumentException.class)
         public void testParseOctalDetectsMutatedTrailerCheck() {
             // Arrange
             byte[] buffer = new byte[] {' ', '1', '2', '3', 'x'}; // Last char 'x' is invalid
             int offset = 0;
             int length = 5; // covers the whole buffer
             
             // Act - should throw because last char 'x' is neither space nor NUL
             // But mutant would check buffer[0] (space) and think it's valid
             TarUtils.parseOctal(buffer, offset, length);
             
             // Assert - handled by expected exception
             // If mutant is present, no exception would be thrown and test would fail
         }

 @Test
        public void testParseOctalWithTrailingSpaceAfterDigit() {
            // Create a buffer with valid octal digits followed by space
            byte[] buffer = {' ', '1', '2', '3', ' '};
            int offset = 0;
            int length = buffer.length;
            
            // Original should parse "123" (83 in decimal)
            long expected = (1L << 6) + (2L << 3) + 3L; // 1*64 + 2*8 + 3 = 83
            
            // Test with original code (should pass)
            long result = TarUtils.parseOctal(buffer, offset, length);
            assertEquals(expected, result);
            
            // Mutated version would fail because:
            // - It would see start=1, end=4 (after first space trim)
            // - Original: while(1 < 3 && ...) - would process positions 1,2,3
            // - Mutant: while(1 <= 3 && ...) - would also check position 4 (space)
            //   and incorrectly decrement end, losing the '3' digit
            // Expected result would be 12 (1*8 + 2 = 10) if mutant was present
        }

 @Test
       public void testParseOctalWithSingleTrailingSpace() {
           // Create a buffer with digits followed by exactly one space
           byte[] buffer = {' ', '1', '2', '3', ' '}; // " 123 " with length 5
           
           // Original behavior should parse "123" (octal) = 83 (decimal)
           // Mutated version would incorrectly trim the '3' and parse "12" = 10
           
           long result = TarUtils.parseOctal(buffer, 0, buffer.length);
           
           // Verify correct parsing of all digits (83 in decimal)
           assertEquals(83L, result);
           
           // The mutant would return 10L instead, which would fail this assertion
       }

 @Test
      public void testParseOctalInvalidTrailerDetected() {
          // Setup test case where:
          // - start > 0 (so start-1 is valid)
          // - byte at start-1 is valid (space or NUL)
          // - actual last byte is invalid (neither space nor NUL)
          // Original should throw exception, mutant would incorrectly accept
          
          byte[] buffer = {
              ' ',  // start-1 position (valid)
              '1', '2', '3', 'x'  // invalid trailer 'x'
          };
          int offset = 1;  // start at '1'
          int length = 4;   // covers '1','2','3','x'
          
          try {
              TarUtils.parseOctal(buffer, offset, length);
              fail("Expected IllegalArgumentException for invalid trailer");
          } catch (IllegalArgumentException e) {
              // Expected behavior - test passes
              assertTrue(e.getMessage().contains("trailing"));
          }
          
          // Additional test case where start=0 to catch potential ArrayIndexOutOfBounds
          byte[] buffer2 = {
              '1', '2', '3', 'x'  // invalid trailer 'x', start would be 0
          };
          try {
              TarUtils.parseOctal(buffer2, 0, 4);
              fail("Expected IllegalArgumentException for invalid trailer with start=0");
          } catch (IllegalArgumentException e) {
              // Expected behavior
          }
      }

 @Test
     public void testParseOctalDetectsTrailerMutation() {
         // Create a buffer where first byte is valid (space) but last byte is invalid
         byte[] buffer = new byte[] {' ', '1', '2', '3', 'x'}; // 'x' is invalid trailer
         int offset = 0;
         int length = buffer.length;
         
         try {
             TarUtils.parseOctal(buffer, offset, length);
             fail("Expected IllegalArgumentException for invalid trailer");
         } catch (IllegalArgumentException e) {
             // Expected behavior - original code would throw exception
             // Mutated code would pass because it checks buffer[start] instead of buffer[end-1]
             assertTrue(e.getMessage().contains("trailer"));
         }
         
         // Additional test case where first and last are different valid values
         buffer = new byte[] {' ', '1', '2', '3', ' '};
         long result = TarUtils.parseOctal(buffer, offset, length);
         assertEquals(83L, result); // 123 in octal is 83 in decimal
         
         // Test case where first is invalid but last is valid (should fail for both original and mutant)
         buffer = new byte[] {'x', '1', '2', '3', ' '};
         try {
             TarUtils.parseOctal(buffer, offset, length);
             fail("Expected IllegalArgumentException for invalid digit");
         } catch (IllegalArgumentException e) {
             assertTrue(e.getMessage().contains("invalid digit"));
         }
     }

 @Test(expected = IllegalArgumentException.class)
    public void testParseOctalDetectsMutatedTrailerCheck1() {
        // Create a buffer where:
        // - First character (offset) is space (valid trailer for mutant)
        // - Last character is invalid (not NUL or space)
        byte[] buffer = new byte[] {' ', '1', '2', '3', 'x'};
        int offset = 0;
        int length = buffer.length;
        
        // Original code should throw IllegalArgumentException because last char 'x' is invalid
        // Mutant would pass because it checks buffer[offset] (space) instead
        TarUtils.parseOctal(buffer, offset, length);
        
        // Assertion is handled by @Test(expected)
    }

 @Test
   public void testParseOctalTrailingSpaceBoundaryCondition() {
       // Create a buffer with exactly one trailing space
       byte[] buffer = {' ', '1', '2', '3', ' '};
       int offset = 0;
       int length = buffer.length;
       
       // This should parse "123" (octal) which is 83 in decimal
       long expected = (1 << 6) + (2 << 3) + 3; // 64 + 16 + 3 = 83
       
       // Test with original code - should work fine
       long result = TarUtils.parseOctal(buffer, offset, length);
       assertEquals(expected, result);
       
       // The mutant would fail here because:
       // With start <= end-1, it would try to process the space after "123"
       // which would either:
       // 1. Throw ArrayIndexOutOfBoundsException if it tries to access buffer[end]
       // 2. Or incorrectly include the space in parsing if bounds checking is loose
       // 3. Or throw IllegalArgumentException for invalid octal digit
       
       // Additional test case where last byte is NUL
       byte[] bufferWithNul = {' ', '1', '2', '3', 0};
       result = TarUtils.parseOctal(bufferWithNul, offset, length);
       assertEquals(expected, result);
       
       // Test case where there's no trailing space/NUL (should throw exception)
       byte[] invalidBuffer = {' ', '1', '2', '3', '4'};
       try {
           TarUtils.parseOctal(invalidBuffer, offset, length);
           fail("Should have thrown IllegalArgumentException");
       } catch (IllegalArgumentException e) {
           // expected
       }
   }

 @Test
  public void testParseOctalWithSingleTrailingSpaceShouldNotProcessIt() {
      // Setup buffer with single trailing space: "123 " (ASCII values)
      byte[] buffer = new byte[]{'1', '2', '3', ' '};
      int offset = 0;
      int length = 4;
      
      // Expected behavior: should parse "123" as octal (83 in decimal)
      long expected = (1L << 6) + (2L << 3) + 3L; // 1*64 + 2*8 + 3 = 83
      
      // Test - this will fail with the mutant
      long actual = TarUtils.parseOctal(buffer, offset, length);
      
      // Verify correct parsing (mutant would try to process the space and throw exception)
      assertEquals("Should parse octal value ignoring single trailing space", 
                  expected, actual);
      
      // Also test with single trailing NUL
      buffer = new byte[]{'1', '2', '3', 0};
      actual = TarUtils.parseOctal(buffer, offset, length);
      assertEquals("Should parse octal value ignoring single trailing NUL", 
                  expected, actual);
  }

 @Test
 public void testParseOctalDetectsTrailerMutation1() {
     // Create a buffer where:
     // - start will be at index 2 after skipping spaces
     // - buffer[end-1] is invalid (not space or NUL)
     // - buffer[start-1] is valid (space)
     byte[] buffer = {
         ' ', ' ', '1', '2', '3', 'x'  // last char 'x' is invalid trailer
     };
     int offset = 0;
     int length = buffer.length;
     
     // Original should throw because last char 'x' is invalid
     try {
         TarUtils.parseOctal(buffer, offset, length);
         fail("Expected IllegalArgumentException for invalid trailer");
     } catch (IllegalArgumentException e) {
         // Expected behavior
     }
     
     // Mutant would check buffer[start-1] which is ' ' (valid)
     // So it wouldn't throw and would incorrectly parse
     // This test will fail on the mutant, thus detecting it
 }

}
