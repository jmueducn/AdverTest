package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                public void testWriteLocalFileHeader_WithExtraFields() throws IOException {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("data.bin");
                                                                                                                                                                    entry.setSize(1000);
                                                                                                                                                                    entry.setCompressedSize(1000);
                                                                                                                                                                    entry.setCrc(1234567890L);
                                                                                                                                                                    entry.setMethod(ZipArchiveEntry.STORED);
                                                                                                                                                                    // Add some extra field data
                                                                                                                                                                    byte[] extraData = new byte[] {0x01, 0x02, 0x03, 0x04};
                                                                                                                                                                    entry.setExtra(extraData);
                                                                                                                                                                    
                                                                                                                                                                    // Execute - use reflection to access protected method
                                                                                                                                                                    try {
                                                                                                                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                            "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        method.invoke(zos, entry);
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Failed to invoke writeLocalFileHeader: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    byte[] header = bos.toByteArray();
                                                                                                                                                                    // Check extra field length (little endian)
                                                                                                                                                                    assertEquals(4, header[28] & 0xff);
                                                                                                                                                                    assertEquals(0, header[29] & 0xff);
                                                                                                                                                                    // Check extra field content
                                                                                                                                                                    assertEquals(0x01, header[30] & 0xff);
                                                                                                                                                                    assertEquals(0x02, header[31] & 0xff);
                                                                                                                                                                    assertEquals(0x03, header[32] & 0xff);
                                                                                                                                                                    assertEquals(0x04, header[33] & 0xff);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testWriteLocalFileHeader_NullEntry() throws IOException {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                                                    
                                                                                                                                                                    // Expected exception setup
                                                                                                                                                                    try {
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                            "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Execute and verify exception
                                                                                                                                                                        method.invoke(zos, (ZipArchiveEntry)null);
                                                                                                                                                                        fail("Expected NullPointerException");
                                                                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                                                                        Throwable cause = e.getCause();
                                                                                                                                                                        assertEquals(NullPointerException.class, cause.getClass());
                                                                                                                                                                        assertEquals("entry", cause.getMessage());
                                                                                                                                                                    } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                                                                                                        fail("Failed to access method via reflection: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreateLocalFileHeader_StoredMethodWithoutChannel() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                                    ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                                                                                                    
                                                                                                                                                                    // Mock entry properties
                                                                                                                                                                    when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                                                                                                    // Skip getAlignment() mock since it's protected
                                                                                                                                                                    when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                                    when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                                                                                                    when(entry.getCrc()).thenReturn(12345L);
                                                                                                                                                                    when(entry.getCompressedSize()).thenReturn(100L);
                                                                                                                                                                    when(entry.getSize()).thenReturn(100L);
                                                                                                                                                                    when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                                                                                                    
                                                                                                                                                                    // Get private method via reflection
                                                                                                                                                                    Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                        "createLocalFileHeader", 
                                                                                                                                                                        ZipArchiveEntry.class, 
                                                                                                                                                                        ByteBuffer.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        long.class);
                                                                                                                                                                    createLocalFileHeader.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    byte[] result = (byte[]) createLocalFileHeader.invoke(
                                                                                                                                                                        zaos, entry, name, true, false, 0L);
                                                                                                                                                                    
                                                                                                                                                                    // Get private constants via reflection
                                                                                                                                                                    Field crcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                                                                                                                    crcOffsetField.setAccessible(true);
                                                                                                                                                                    int crcOffset = crcOffsetField.getInt(zaos);
                                                                                                                                                                    
                                                                                                                                                                    Field compressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                                                                                                                    compressedSizeOffsetField.setAccessible(true);
                                                                                                                                                                    int compressedSizeOffset = compressedSizeOffsetField.getInt(zaos);
                                                                                                                                                                    
                                                                                                                                                                    Field originalSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_ORIGINAL_SIZE_OFFSET");
                                                                                                                                                                    originalSizeOffsetField.setAccessible(true);
                                                                                                                                                                    int originalSizeOffset = originalSizeOffsetField.getInt(zaos);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                    // Check CRC is written
                                                                                                                                                                    assertEquals(12345L, ZipLong.getValue(result, crcOffset));
                                                                                                                                                                    // Check sizes are written
                                                                                                                                                                    assertEquals(100L, ZipLong.getValue(result, compressedSizeOffset));
                                                                                                                                                                    assertEquals(100L, ZipLong.getValue(result, originalSizeOffset));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreateLocalFileHeader_DeflatedMethodWithPhased() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                                    ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                                                                                                    
                                                                                                                                                                    // Mock entry properties
                                                                                                                                                                    when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                                                                                                    // Use reflection to set alignment since getAlignment() is protected
                                                                                                                                                                    Field alignmentField = ZipArchiveEntry.class.getDeclaredField("alignment");
                                                                                                                                                                    alignmentField.setAccessible(true);
                                                                                                                                                                    alignmentField.set(entry, 0);
                                                                                                                                                                    when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                                    when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                                                                                                    when(entry.getCrc()).thenReturn(12345L);
                                                                                                                                                                    when(entry.getCompressedSize()).thenReturn(100L);
                                                                                                                                                                    when(entry.getSize()).thenReturn(200L);
                                                                                                                                                                    when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                                                                                                    
                                                                                                                                                                    // Get private createLocalFileHeader method via reflection
                                                                                                                                                                    Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                        "createLocalFileHeader", 
                                                                                                                                                                        ZipArchiveEntry.class, 
                                                                                                                                                                        ByteBuffer.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        boolean.class, 
                                                                                                                                                                        long.class);
                                                                                                                                                                    createLocalFileHeader.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Execute with phased=true
                                                                                                                                                                    byte[] result = (byte[]) createLocalFileHeader.invoke(zaos, entry, name, true, true, 0L);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                    
                                                                                                                                                                    // Get private offset constants via reflection
                                                                                                                                                                    Field crcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                                                                                                                    crcOffsetField.setAccessible(true);
                                                                                                                                                                    int crcOffset = (int) crcOffsetField.get(zaos);
                                                                                                                                                                    
                                                                                                                                                                    Field compressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                                                                                                                    compressedSizeOffsetField.setAccessible(true);
                                                                                                                                                                    int compressedSizeOffset = (int) compressedSizeOffsetField.get(zaos);
                                                                                                                                                                    
                                                                                                                                                                    Field originalSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_ORIGINAL_SIZE_OFFSET");
                                                                                                                                                                    originalSizeOffsetField.setAccessible(true);
                                                                                                                                                                    int originalSizeOffset = (int) originalSizeOffsetField.get(zaos);
                                                                                                                                                                    
                                                                                                                                                                    // Check CRC is written for phased
                                                                                                                                                                    assertEquals(12345L, ZipLong.getValue(result, crcOffset));
                                                                                                                                                                    // Check sizes are written for phased
                                                                                                                                                                    assertEquals(100L, ZipLong.getValue(result, compressedSizeOffset));
                                                                                                                                                                    assertEquals(200L, ZipLong.getValue(result, originalSizeOffset));
                                                                                                                                                                    
                                                                                                                                                                    // Clean up
                                                                                                                                                                    zaos.close();
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testCreateLocalFileHeader_WithZip64Extra() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                            ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                            ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                                                                                            
                                                                                                                                                            // Mock entry properties
                                                                                                                                                            when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                                                                                            when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                            when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                                                                                            when(entry.getCrc()).thenReturn(12345L);
                                                                                                                                                            when(entry.getCompressedSize()).thenReturn(0xFFFFFFFFL); // ZIP64 magic value
                                                                                                                                                            when(entry.getSize()).thenReturn(0xFFFFFFFFL); // ZIP64 magic value
                                                                                                                                                            when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private hasZip64Extra method
                                                                                                                                                            Method hasZip64ExtraMethod = ZipArchiveOutputStream.class.getDeclaredMethod("hasZip64Extra", ZipArchiveEntry.class);
                                                                                                                                                            hasZip64ExtraMethod.setAccessible(true);
                                                                                                                                                            when(hasZip64ExtraMethod.invoke(zaos, entry)).thenReturn(true);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private createLocalFileHeader method
                                                                                                                                                            Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                "createLocalFileHeader", 
                                                                                                                                                                ZipArchiveEntry.class, 
                                                                                                                                                                ByteBuffer.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                long.class
                                                                                                                                                            );
                                                                                                                                                            createLocalFileHeaderMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Execute
                                                                                                                                                            byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                                                                                                                zaos, 
                                                                                                                                                                entry, 
                                                                                                                                                                name, 
                                                                                                                                                                true, 
                                                                                                                                                                false, 
                                                                                                                                                                0L
                                                                                                                                                            );
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNotNull(result);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private offset constants
                                                                                                                                                            Field compressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                                                                                                            compressedSizeOffsetField.setAccessible(true);
                                                                                                                                                            int compressedSizeOffset = compressedSizeOffsetField.getInt(zaos);
                                                                                                                                                            
                                                                                                                                                            Field originalSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_ORIGINAL_SIZE_OFFSET");
                                                                                                                                                            originalSizeOffsetField.setAccessible(true);
                                                                                                                                                            int originalSizeOffset = originalSizeOffsetField.getInt(zaos);
                                                                                                                                                            
                                                                                                                                                            // Check ZIP64 magic values are written
                                                                                                                                                            assertEquals(0xFFFFFFFFL, ZipLong.getValue(result, compressedSizeOffset));
                                                                                                                                                            assertEquals(0xFFFFFFFFL, ZipLong.getValue(result, originalSizeOffset));
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testCreateLocalFileHeader_WithNonEncodableName() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                            ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                                            ByteBuffer name = ByteBuffer.wrap("テスト.txt".getBytes("UTF-8"));
                                                                                                                                                            
                                                                                                                                                            // Mock entry properties
                                                                                                                                                            when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                                                                                            // Use reflection to mock getAlignment() since it's protected
                                                                                                                                                            Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                                                                                                                            getAlignmentMethod.setAccessible(true);
                                                                                                                                                            when(getAlignmentMethod.invoke(entry)).thenReturn(0);
                                                                                                                                                            when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                            when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                                                                                            when(entry.getCrc()).thenReturn(12345L);
                                                                                                                                                            when(entry.getCompressedSize()).thenReturn(100L);
                                                                                                                                                            when(entry.getSize()).thenReturn(100L);
                                                                                                                                                            when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                                                                                            
                                                                                                                                                            // Get private method via reflection
                                                                                                                                                            Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                "createLocalFileHeader", 
                                                                                                                                                                ZipArchiveEntry.class, 
                                                                                                                                                                ByteBuffer.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                long.class);
                                                                                                                                                            createLocalFileHeaderMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Execute with encodable=false
                                                                                                                                                            byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                                                                                                                zaos, entry, name, false, false, 0L);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNotNull(result);
                                                                                                                                                            // Get private field via reflection
                                                                                                                                                            Field lfhGpbOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_GPB_OFFSET");
                                                                                                                                                            lfhGpbOffsetField.setAccessible(true);
                                                                                                                                                            int lfhGpbOffset = lfhGpbOffsetField.getInt(zaos);
                                                                                                                                                            
                                                                                                                                                            // Check general purpose bit is set for UTF-8
                                                                                                                                                            int gpb = ZipShort.getValue(result, lfhGpbOffset);
                                                                                                                                                            assertTrue((gpb & GeneralPurposeBit.UFT8_NAMES_FLAG) != 0);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testVersionNeededToExtract_WhenNeitherZip64NorDataDescriptor() throws Exception {
                                                                                                                                                            // Arrange
                                                                                                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                            
                                                                                                                                                            // Use reflection to test private methods if absolutely necessary
                                                                                                                                                            Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                                                                                            versionMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Act & Assert
                                                                                                                                                            assertEquals(10, versionMethod.invoke(zos, ZipArchiveOutputStream.DEFLATED, false, false));
                                                                                                                                                            assertEquals(20, versionMethod.invoke(zos, ZipArchiveOutputStream.STORED, false, false));
                                                                                                                                                            
                                                                                                                                                            // For unknown method, we can't predict the exact value since we can't mock the private method
                                                                                                                                                            // So we just verify it returns some value (not testing exact value)
                                                                                                                                                            assertNotNull(versionMethod.invoke(zos, 999, false, false));
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testUsesDataDescriptor_ChannelNotNull() throws Exception {
                                                                                                                                                            // Setup: channel is not null
                                                                                                                                                            SeekableByteChannel mockChannel = mock(SeekableByteChannel.class);
                                                                                                                                                            ZipArchiveOutputStream zosWithChannel = new ZipArchiveOutputStream(mockChannel);
                                                                                                                                                            
                                                                                                                                                            // Set private method field using reflection
                                                                                                                                                            Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                                                                                            methodField.setAccessible(true);
                                                                                                                                                            methodField.set(zosWithChannel, ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                            
                                                                                                                                                            // Get private usesDataDescriptor method using reflection
                                                                                                                                                            Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                            usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Invoke the method and assert
                                                                                                                                                            boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                                zosWithChannel, ZipArchiveOutputStream.DEFLATED, false);
                                                                                                                                                            assertFalse(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_ChannelNotNullMethodDeflated() throws Exception {
                                                                                                                                                        // Setup: channel not null but method=DEFLATED
                                                                                                                                                        SeekableByteChannel mockChannel = mock(SeekableByteChannel.class);
                                                                                                                                                        ZipArchiveOutputStream zosWithChannel = new ZipArchiveOutputStream(mockChannel);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set private method field
                                                                                                                                                        Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                                                                                        methodField.setAccessible(true);
                                                                                                                                                        methodField.set(zosWithChannel, ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to call private usesDataDescriptor method
                                                                                                                                                        Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                            zosWithChannel, ZipArchiveOutputStream.DEFLATED, false);
                                                                                                                                                        
                                                                                                                                                        assertFalse(result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_AllConditionsFalse() throws Exception {
                                                                                                                                                        // Setup: phased=true, method=STORED, channel not null
                                                                                                                                                        SeekableByteChannel mockChannel = mock(SeekableByteChannel.class);
                                                                                                                                                        ZipArchiveOutputStream zosWithChannel = new ZipArchiveOutputStream(mockChannel);
                                                                                                                                                        
                                                                                                                                                        // Set private method field using reflection
                                                                                                                                                        Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                                                                                        methodField.setAccessible(true);
                                                                                                                                                        methodField.set(zosWithChannel, ZipArchiveOutputStream.STORED);
                                                                                                                                                        
                                                                                                                                                        // Get private usesDataDescriptor method using reflection
                                                                                                                                                        Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Invoke the method and assert
                                                                                                                                                        boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                            zosWithChannel, ZipArchiveOutputStream.STORED, true);
                                                                                                                                                        assertFalse(result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testVersionNeededToExtractMethod_Deflated() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                        final int DEFLATED = 8; // ZipArchiveOutputStream.DEFLATED
                                                                                                                                                        final int DEFLATE_MIN_VERSION = 20; // ZipArchiveOutputStream.DEFLATE_MIN_VERSION
                                                                                                                                                        
                                                                                                                                                        // Get private method via reflection
                                                                                                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "versionNeededToExtractMethod", int.class);
                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Test DEFLATED compression method
                                                                                                                                                        int result = (int) method.invoke(zos, DEFLATED);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertEquals("DEFLATED method should return DEFLATE_MIN_VERSION", 
                                                                                                                                                                     DEFLATE_MIN_VERSION, result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testVersionNeededToExtractMethod_EdgeCases() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                        
                                                                                                                                                        // Get private method via reflection
                                                                                                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "versionNeededToExtractMethod", int.class);
                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Get constant values via reflection
                                                                                                                                                        Field deflatedField = ZipArchiveOutputStream.class.getDeclaredField("DEFLATED");
                                                                                                                                                        deflatedField.setAccessible(true);
                                                                                                                                                        int DEFLATED = deflatedField.getInt(zos);
                                                                                                                                                        
                                                                                                                                                        Field initialVersionField = ZipArchiveOutputStream.class.getDeclaredField("INITIAL_VERSION");
                                                                                                                                                        initialVersionField.setAccessible(true);
                                                                                                                                                        int INITIAL_VERSION = initialVersionField.getInt(zos);
                                                                                                                                                        
                                                                                                                                                        // Test boundary cases
                                                                                                                                                        assertEquals("Method just below DEFLATED should return INITIAL_VERSION",
                                                                                                                                                                    INITIAL_VERSION, 
                                                                                                                                                                    method.invoke(zos, DEFLATED - 1));
                                                                                                                                                        
                                                                                                                                                        assertEquals("Method just above DEFLATED should return INITIAL_VERSION",
                                                                                                                                                                    INITIAL_VERSION, 
                                                                                                                                                                    method.invoke(zos, DEFLATED + 1));
                                                                                                                                                        
                                                                                                                                                        assertEquals("Zero method should return INITIAL_VERSION",
                                                                                                                                                                    INITIAL_VERSION, 
                                                                                                                                                                    method.invoke(zos, 0));
                                                                                                                                                        
                                                                                                                                                        assertEquals("Negative method should return INITIAL_VERSION",
                                                                                                                                                                    INITIAL_VERSION, 
                                                                                                                                                                    method.invoke(zos, -1));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testWriteLocalFileHeader_StandardEntry() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                        entry.setSize(100);
                                                                                                                                                        entry.setCompressedSize(80);
                                                                                                                                                        entry.setCrc(123456789L);
                                                                                                                                                        entry.setMethod(8); // DEFLATED = 8
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                        Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                                                                                                        writeLocalFileHeader.setAccessible(true);
                                                                                                                                                        writeLocalFileHeader.invoke(zos, entry, false);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        byte[] header = bos.toByteArray();
                                                                                                                                                        // Check Local File Header signature
                                                                                                                                                        assertEquals(0x04034b50, 
                                                                                                                                                                    (header[0] & 0xff) | ((header[1] & 0xff) << 8) | 
                                                                                                                                                                    ((header[2] & 0xff) << 16) | ((header[3] & 0xff) << 24));
                                                                                                                                                        // Check version needed to extract
                                                                                                                                                        assertEquals(20, header[4] & 0xff);
                                                                                                                                                        assertEquals(0, header[5] & 0xff);
                                                                                                                                                        // Check general purpose bit flag
                                                                                                                                                        assertEquals(0, header[6] & 0xff);
                                                                                                                                                        assertEquals(0, header[7] & 0xff);
                                                                                                                                                        // Check compression method (DEFLATED)
                                                                                                                                                        assertEquals(8, header[8] & 0xff);
                                                                                                                                                        assertEquals(0, header[9] & 0xff);
                                                                                                                                                        // Check filename length (8 chars for "test.txt")
                                                                                                                                                        assertEquals(8, header[26] & 0xff);
                                                                                                                                                        assertEquals(0, header[27] & 0xff);
                                                                                                                                                        // Check extra field length (should be 0 for standard entry)
                                                                                                                                                        assertEquals(0, header[28] & 0xff);
                                                                                                                                                        assertEquals(0, header[29] & 0xff);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testWriteLocalFileHeader_AfterFinish() throws IOException {
                                                                                                                                                        // Setup
                                                                                                                                                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                        zos.finish();
                                                                                                                                                        
                                                                                                                                                        // Expect exception
                                                                                                                                                        try {
                                                                                                                                                            Method method = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            method.invoke(zos, entry);
                                                                                                                                                            fail("Expected IOException to be thrown");
                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                            Throwable cause = e.getCause();
                                                                                                                                                            assertTrue(cause instanceof IOException);
                                                                                                                                                            assertEquals("Stream has already been finished", cause.getMessage());
                                                                                                                                                        } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testWriteLocalFileHeader_UnicodeName() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                                                                                                        StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                        
                                                                                                                                                        // Create output stream with mock components
                                                                                                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to inject mocks since they're private fields
                                                                                                                                                        Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                                                                                                        encodingField.setAccessible(true);
                                                                                                                                                        encodingField.set(zos, mockEncoding);
                                                                                                                                                        
                                                                                                                                                        Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                                                                                                        compressorField.setAccessible(true);
                                                                                                                                                        compressorField.set(zos, mockCompressor);
                                                                                                                                                        
                                                                                                                                                        // Mock behavior
                                                                                                                                                        when(mockEncoding.canEncode(anyString())).thenReturn(false);
                                                                                                                                                        when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                        Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                        writeLocalFileHeader.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        verify(mockEncoding).canEncode("test.txt");
                                                                                                                                                        // Should still write the header even with unicode name
                                                                                                                                                        verify(mockCompressor).writeCounted(any(byte[].class));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testWriteLocalFileHeader_VerifyDataStartPositions() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                                                                                                        StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                        
                                                                                                                                                        // Create output stream with mock compressor
                                                                                                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set private fields
                                                                                                                                                        Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                                                                                                        encodingField.setAccessible(true);
                                                                                                                                                        encodingField.set(zos, mockEncoding);
                                                                                                                                                        
                                                                                                                                                        Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                                                                                                        compressorField.setAccessible(true);
                                                                                                                                                        compressorField.set(zos, mockCompressor);
                                                                                                                                                        
                                                                                                                                                        // Mock behavior
                                                                                                                                                        when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                                                                                                                        when(mockCompressor.getTotalBytesWritten())
                                                                                                                                                            .thenReturn(100L)    // initial position
                                                                                                                                                            .thenReturn(150L);  // position after writing header
                                                                                                                                                        
                                                                                                                                                        // Make protected method accessible
                                                                                                                                                        Method writeLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                        writeLocalFileHeaderMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        writeLocalFileHeaderMethod.invoke(zos, entry);
                                                                                                                                                        
                                                                                                                                                        // Verify entry data positions were set correctly
                                                                                                                                                        Field entryField = ZipArchiveOutputStream.class.getDeclaredField("entry");
                                                                                                                                                        entryField.setAccessible(true);
                                                                                                                                                        Object currentEntry = entryField.get(zos);
                                                                                                                                                        
                                                                                                                                                        // Get CurrentEntry class and its fields
                                                                                                                                                        Class<?> currentEntryClass = Class.forName("org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream$CurrentEntry");
                                                                                                                                                        Field localDataStartField = currentEntryClass.getDeclaredField("localDataStart");
                                                                                                                                                        localDataStartField.setAccessible(true);
                                                                                                                                                        Field dataStartField = currentEntryClass.getDeclaredField("dataStart");
                                                                                                                                                        dataStartField.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Get private LFH_CRC_OFFSET value via reflection
                                                                                                                                                        Field crcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                                                                                                        crcOffsetField.setAccessible(true);
                                                                                                                                                        long crcOffset = crcOffsetField.getLong(zos);
                                                                                                                                                        
                                                                                                                                                        assertEquals(100L + crcOffset, localDataStartField.getLong(currentEntry));
                                                                                                                                                        assertEquals(150L, dataStartField.getLong(currentEntry));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testWriteDataDescriptor_ZeroSizes() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                                        entry.setMethod(java.util.zip.ZipEntry.DEFLATED);
                                                                                                                                                        entry.setCrc(0L);
                                                                                                                                                        entry.setCompressedSize(0L);
                                                                                                                                                        entry.setSize(0L);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                        Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                                                                                        writeDataDescriptor.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        writeDataDescriptor.invoke(zos, entry);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        byte[] result = bos.toByteArray();
                                                                                                                                                        // Should write: DD_SIG (4 bytes) + CRC (4 bytes) + compressed size (4 bytes) + size (4 bytes)
                                                                                                                                                        assertEquals(16, result.length);
                                                                                                                                                        
                                                                                                                                                        // Verify DD_SIG (0x08074b50 in little-endian)
                                                                                                                                                        assertEquals(0x50, result[0] & 0xff);
                                                                                                                                                        assertEquals(0x4b, result[1] & 0xff);
                                                                                                                                                        assertEquals(0x07, result[2] & 0xff);
                                                                                                                                                        assertEquals(0x08, result[3] & 0xff);
                                                                                                                                                        
                                                                                                                                                        // Verify CRC (0)
                                                                                                                                                        assertEquals(0, result[4] & 0xff);
                                                                                                                                                        assertEquals(0, result[5] & 0xff);
                                                                                                                                                        assertEquals(0, result[6] & 0xff);
                                                                                                                                                        assertEquals(0, result[7] & 0xff);
                                                                                                                                                        
                                                                                                                                                        // Verify compressed size (0)
                                                                                                                                                        assertEquals(0, result[8] & 0xff);
                                                                                                                                                        assertEquals(0, result[9] & 0xff);
                                                                                                                                                        assertEquals(0, result[10] & 0xff);
                                                                                                                                                        assertEquals(0, result[11] & 0xff);
                                                                                                                                                        
                                                                                                                                                        // Verify size (0)
                                                                                                                                                        assertEquals(0, result[12] & 0xff);
                                                                                                                                                        assertEquals(0, result[13] & 0xff);
                                                                                                                                                        assertEquals(0, result[14] & 0xff);
                                                                                                                                                        assertEquals(0, result[15] & 0xff);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testVersionNeededToExtract_WhenUsedDataDescriptorIsTrue() throws Exception {
                                                                                                                                                        // Arrange
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                        
                                                                                                                                                        // Get private method via reflection
                                                                                                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Define constants locally since we can't rely on class-level imports
                                                                                                                                                        final int DEFLATED = ZipArchiveOutputStream.DEFLATED;
                                                                                                                                                        final int STORED = ZipArchiveOutputStream.STORED;
                                                                                                                                                        final int DATA_DESCRIPTOR_MIN_VERSION = 20; // Standard value for data descriptor
                                                                                                                                                        
                                                                                                                                                        // Act & Assert
                                                                                                                                                        // Should return DATA_DESCRIPTOR_MIN_VERSION when zip64 is false but usedDataDescriptor is true
                                                                                                                                                        assertEquals(DATA_DESCRIPTOR_MIN_VERSION, 
                                                                                                                                                                   method.invoke(zos, 0, false, true));
                                                                                                                                                        assertEquals(DATA_DESCRIPTOR_MIN_VERSION, 
                                                                                                                                                                   method.invoke(zos, DEFLATED, false, true));
                                                                                                                                                        assertEquals(DATA_DESCRIPTOR_MIN_VERSION, 
                                                                                                                                                                   method.invoke(zos, STORED, false, true));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testVersionNeededToExtract_PriorityOfConditions() throws Exception {
                                                                                                                                                        // Arrange
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                                        
                                                                                                                                                        // Get private method via reflection
                                                                                                                                                        Method versionNeededToExtract = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                                                                                        versionNeededToExtract.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Get constants via reflection
                                                                                                                                                        Field zip64MinVersionField = ZipArchiveOutputStream.class.getDeclaredField("ZIP64_MIN_VERSION");
                                                                                                                                                        zip64MinVersionField.setAccessible(true);
                                                                                                                                                        int ZIP64_MIN_VERSION = (int) zip64MinVersionField.get(null);
                                                                                                                                                        
                                                                                                                                                        Field dataDescriptorMinVersionField = ZipArchiveOutputStream.class.getDeclaredField("DATA_DESCRIPTOR_MIN_VERSION");
                                                                                                                                                        dataDescriptorMinVersionField.setAccessible(true);
                                                                                                                                                        int DATA_DESCRIPTOR_MIN_VERSION = (int) dataDescriptorMinVersionField.get(null);
                                                                                                                                                        
                                                                                                                                                        // Get the versionNeededToExtractMethod via reflection
                                                                                                                                                        Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "versionNeededToExtractMethod", int.class);
                                                                                                                                                        versionNeededToExtractMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Act & Assert
                                                                                                                                                        // zip64 should take highest priority
                                                                                                                                                        assertEquals(ZIP64_MIN_VERSION, 
                                                                                                                                                                   versionNeededToExtract.invoke(zos, 0, true, true));
                                                                                                                                                        
                                                                                                                                                        // then data descriptor
                                                                                                                                                        assertEquals(DATA_DESCRIPTOR_MIN_VERSION, 
                                                                                                                                                                   versionNeededToExtract.invoke(zos, 0, false, true));
                                                                                                                                                        
                                                                                                                                                        // finally the method-based version
                                                                                                                                                        // Instead of mocking, we'll test with a known method value
                                                                                                                                                        int methodVersion = (int) versionNeededToExtractMethod.invoke(zos, 0);
                                                                                                                                                        assertEquals(methodVersion, 
                                                                                                                                                                   versionNeededToExtract.invoke(zos, 0, false, false));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_AllConditionsTrue() throws Exception {
                                                                                                                                                        // Create output stream that writes to nowhere (null output stream)
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new OutputStream() {
                                                                                                                                                            @Override
                                                                                                                                                            public void write(int b) throws IOException {
                                                                                                                                                                // Do nothing
                                                                                                                                                            }
                                                                                                                                                        });
                                                                                                                                                        
                                                                                                                                                        // Set method to DEFLATED using public API
                                                                                                                                                        zos.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                        Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                            zos, ZipArchiveOutputStream.DEFLATED, false);
                                                                                                                                                        
                                                                                                                                                        assertTrue(result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_PhasedTrue() throws Exception {
                                                                                                                                                        // Setup: phased=true (should return false regardless of other conditions)
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set the private 'method' field
                                                                                                                                                        Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                                                                                        methodField.setAccessible(true);
                                                                                                                                                        methodField.set(zos, ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access and invoke the private usesDataDescriptor method
                                                                                                                                                        Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                        boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                            zos, ZipArchiveOutputStream.DEFLATED, true);
                                                                                                                                                        
                                                                                                                                                        assertFalse(result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_MethodNotDeflated() throws Exception {
                                                                                                                                                        // Setup: method=STORED (not DEFLATED)
                                                                                                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                                                                                        zos.setMethod(ZipArchiveOutputStream.STORED);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                        Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                        boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                            zos, ZipArchiveOutputStream.STORED, false);
                                                                                                                                                        
                                                                                                                                                        assertFalse(result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_PhasedTrueMethodDeflated() throws Exception {
                                                                                                                                                        // Setup: phased=true overrides method=DEFLATED
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                        zos.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                        Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptor.setAccessible(true);
                                                                                                                                                        boolean result = (boolean) usesDataDescriptor.invoke(zos, ZipArchiveOutputStream.DEFLATED, true);
                                                                                                                                                        
                                                                                                                                                        assertFalse(result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testUsesDataDescriptor_PhasedTrueMethodStored() throws Exception {
                                                                                                                                                        // Setup: phased=true and method=STORED
                                                                                                                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                                                                                        zos.setMethod(ZipArchiveOutputStream.STORED);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                        Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                            "usesDataDescriptor", int.class, boolean.class);
                                                                                                                                                        usesDataDescriptorMethod.setAccessible(true);
                                                                                                                                                        boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                                                                                            zos, ZipArchiveOutputStream.STORED, true);
                                                                                                                                                        
                                                                                                                                                        assertFalse(result);
                                                                                                                                                        zos.close();
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testVersionNeededToExtractMethod_Stored() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut);
                                                                                                                                                
                                                                                                                                                // Get private method via reflection
                                                                                                                                                Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                    "versionNeededToExtractMethod", int.class);
                                                                                                                                                method.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Test STORED compression method
                                                                                                                                                int storedMethod = 0; // STORED method is represented by 0
                                                                                                                                                int result = (int) method.invoke(zos, storedMethod);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                int initialVersion = 10; // INITIAL_VERSION is typically 10
                                                                                                                                                assertEquals("STORED method should return INITIAL_VERSION", 
                                                                                                                                                             initialVersion, result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testVersionNeededToExtractMethod_OtherMethods() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                                                                                
                                                                                                                                                // Get INITIAL_VERSION constant via reflection
                                                                                                                                                Field initialVersionField = ZipArchiveOutputStream.class.getDeclaredField("INITIAL_VERSION");
                                                                                                                                                initialVersionField.setAccessible(true);
                                                                                                                                                int INITIAL_VERSION = initialVersionField.getInt(null);
                                                                                                                                                
                                                                                                                                                // Get private method via reflection
                                                                                                                                                Method versionNeededMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                    "versionNeededToExtractMethod", int.class);
                                                                                                                                                versionNeededMethod.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Test with some arbitrary method number that's neither DEFLATED nor STORED
                                                                                                                                                int arbitraryMethod = 99;
                                                                                                                                                int result = (int) versionNeededMethod.invoke(zos, arbitraryMethod);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertEquals("Any non-DEFLATED method should return INITIAL_VERSION", 
                                                                                                                                                            INITIAL_VERSION, result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testWriteLocalFileHeader_EntryWithNullName() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry((String)null);
                                                                                                                                                
                                                                                                                                                // Get the protected method via reflection
                                                                                                                                                Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                    "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                writeLocalFileHeader.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Expect exception
                                                                                                                                                ExpectedException expected = ExpectedException.none();
                                                                                                                                                expected.expect(NullPointerException.class);
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testWriteLocalFileHeader_StandardEntry1() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                                                                                                StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream((OutputStream) null);
                                                                                                                                                
                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                                                                                                encodingField.setAccessible(true);
                                                                                                                                                encodingField.set(zos, mockEncoding);
                                                                                                                                                
                                                                                                                                                Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                                                                                                compressorField.setAccessible(true);
                                                                                                                                                compressorField.set(zos, mockCompressor);
                                                                                                                                                
                                                                                                                                                Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("metaData");
                                                                                                                                                metaDataField.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Initialize metadata map if null
                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                Map<ZipArchiveEntry, Object> metaData = 
                                                                                                                                                    (Map<ZipArchiveEntry, Object>) metaDataField.get(zos);
                                                                                                                                                if (metaData == null) {
                                                                                                                                                    metaData = new HashMap<>();
                                                                                                                                                    metaDataField.set(zos, metaData);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                
                                                                                                                                                when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                                                                                                                when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                                                                                                
                                                                                                                                                // Use reflection to call protected method
                                                                                                                                                Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                    "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                writeLocalFileHeader.setAccessible(true);
                                                                                                                                                writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                verify(mockEncoding).canEncode("test.txt");
                                                                                                                                                verify(mockCompressor, atLeastOnce()).getTotalBytesWritten();
                                                                                                                                                verify(mockCompressor).writeCounted(any(byte[].class));
                                                                                                                                                
                                                                                                                                                // Verify metadata was stored
                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                Map<ZipArchiveEntry, Object> updatedMetaData = 
                                                                                                                                                    (Map<ZipArchiveEntry, Object>) metaDataField.get(zos);
                                                                                                                                                assertTrue(updatedMetaData.containsKey(entry));
                                                                                                                                                Object meta = updatedMetaData.get(entry);
                                                                                                                                                
                                                                                                                                                // Use reflection to verify metadata contents
                                                                                                                                                Method getOffset = meta.getClass().getDeclaredMethod("getOffset");
                                                                                                                                                getOffset.setAccessible(true);
                                                                                                                                                assertEquals(100L, getOffset.invoke(meta));
                                                                                                                                                
                                                                                                                                                Method usesDataDescriptor = meta.getClass().getDeclaredMethod("usesDataDescriptor");
                                                                                                                                                usesDataDescriptor.setAccessible(true);
                                                                                                                                                assertFalse((Boolean)usesDataDescriptor.invoke(meta));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testWriteLocalFileHeader_DifferentUnicodePolicies() throws Exception {
                                                                                                                                                // Setup required objects
                                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                                ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                                                                                                StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                                                                                                
                                                                                                                                                // Set up mocks
                                                                                                                                                when(mockEncoding.canEncode(anyString())).thenReturn(false);
                                                                                                                                                when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                                                                                                
                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                                                                                                encodingField.setAccessible(true);
                                                                                                                                                encodingField.set(zos, mockEncoding);
                                                                                                                                                
                                                                                                                                                Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                                                                                                compressorField.setAccessible(true);
                                                                                                                                                compressorField.set(zos, mockCompressor);
                                                                                                                                                
                                                                                                                                                // Test with NEVER policy
                                                                                                                                                zos.setCreateUnicodeExtraFields(ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NEVER);
                                                                                                                                                
                                                                                                                                                // Access protected method via reflection
                                                                                                                                                Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                    "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                writeLocalFileHeader.setAccessible(true);
                                                                                                                                                writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                                
                                                                                                                                                verify(mockCompressor).writeCounted(any(byte[].class));
                                                                                                                                                
                                                                                                                                                // Test with ALWAYS policy
                                                                                                                                                reset(mockCompressor);
                                                                                                                                                when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                                                                                                zos.setCreateUnicodeExtraFields(ZipArchiveOutputStream.UnicodeExtraFieldPolicy.ALWAYS);
                                                                                                                                                
                                                                                                                                                writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                                verify(mockCompressor).writeCounted(any(byte[].class));
                                                                                                                                            }

    @Test
                                                                                                                                        public void testWriteLocalFileHeader_WithZip64ExtraFields() throws IOException {
                                                                                                                                            // Setup
                                                                                                                                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                            zos.setUseZip64(Zip64Mode.Always);
                                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("large.bin");
                                                                                                                                            entry.setSize(0xFFFFFFFFL + 1); // Force ZIP64
                                                                                                                                            entry.setCompressedSize(0xFFFFFFFFL + 1);
                                                                                                                                            entry.setCrc(1234567890L);
                                                                                                                                            entry.setMethod(java.util.zip.ZipEntry.DEFLATED);
                                                                                                                                            
                                                                                                                                            // Execute - use reflection to access protected method
                                                                                                                                            try {
                                                                                                                                                Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                    "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                                writeLocalFileHeader.setAccessible(true);
                                                                                                                                                writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to invoke writeLocalFileHeader: " + e.getMessage());
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            byte[] header = bos.toByteArray();
                                                                                                                                            // Check version needed to extract (should be 45 for ZIP64)
                                                                                                                                            assertEquals(45, header[4] & 0xff);
                                                                                                                                            assertEquals(0, header[5] & 0xff);
                                                                                                                                            // Check sizes in header should be 0xFFFFFFFF
                                                                                                                                            assertEquals(0xFF, header[18] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[19] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[20] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[21] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[22] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[23] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[24] & 0xff);
                                                                                                                                            assertEquals(0xFF, header[25] & 0xff);
                                                                                                                                            // Check extra field length (should be > 0 for ZIP64)
                                                                                                                                            assertTrue((header[28] & 0xff) > 0 || (header[29] & 0xff) > 0);
                                                                                                                                        }

    @Test
                                                                                                                                    public void testCreateLocalFileHeader_WithAlignmentAndMethodChangeNotAllowed() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                        ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                                                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                        ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                                                                        
                                                                                                                                        // Mock alignment extra field
                                                                                                                                        ResourceAlignmentExtraField alignmentEx = mock(ResourceAlignmentExtraField.class);
                                                                                                                                        when(alignmentEx.getAlignment()).thenReturn((short)4);  // Changed to cast as short
                                                                                                                                        when(alignmentEx.allowMethodChange()).thenReturn(false);
                                                                                                                                        when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(alignmentEx);
                                                                                                                                        
                                                                                                                                        // Mock other entry properties
                                                                                                                                        Method setAlignment = ZipArchiveEntry.class.getDeclaredMethod("setAlignment", int.class);
                                                                                                                                        setAlignment.setAccessible(true);
                                                                                                                                        setAlignment.invoke(entry, 0);
                                                                                                                                        
                                                                                                                                        when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                        when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                                                                        when(entry.getCrc()).thenReturn(12345L);
                                                                                                                                        when(entry.getCompressedSize()).thenReturn(100L);
                                                                                                                                        when(entry.getSize()).thenReturn(200L);
                                                                                                                                        when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                                                                        
                                                                                                                                        // Get private method via reflection
                                                                                                                                        Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                            "createLocalFileHeader", 
                                                                                                                                            ZipArchiveEntry.class, 
                                                                                                                                            ByteBuffer.class, 
                                                                                                                                            boolean.class, 
                                                                                                                                            boolean.class, 
                                                                                                                                            long.class);
                                                                                                                                        createLocalFileHeader.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Execute
                                                                                                                                        byte[] result = (byte[]) createLocalFileHeader.invoke(
                                                                                                                                            zaos, 
                                                                                                                                            entry, 
                                                                                                                                            name, 
                                                                                                                                            true, 
                                                                                                                                            false, 
                                                                                                                                            0L);
                                                                                                                                        
                                                                                                                                        // Verify
                                                                                                                                        assertNotNull(result);
                                                                                                                                        
                                                                                                                                        // Get private field via reflection
                                                                                                                                        Field lfhSigOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG_OFFSET");
                                                                                                                                        lfhSigOffsetField.setAccessible(true);
                                                                                                                                        int lfhSigOffset = lfhSigOffsetField.getInt(zaos);
                                                                                                                                        
                                                                                                                                        // Should include alignment padding
                                                                                                                                        assertTrue(result.length > lfhSigOffset + 4);
                                                                                                                                    }

    @Test
                                                                                                                                    public void testVersionNeededToExtract_WhenZip64IsTrue() throws Exception {
                                                                                                                                        // Arrange
                                                                                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                        
                                                                                                                                        // Get private method via reflection
                                                                                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                            "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                                                                        method.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Standard ZIP64 minimum version
                                                                                                                                        final int ZIP64_MIN_VERSION = 45;
                                                                                                                                        
                                                                                                                                        // Act & Assert
                                                                                                                                        // Should return ZIP64_MIN_VERSION regardless of other parameters
                                                                                                                                        assertEquals(ZIP64_MIN_VERSION, 
                                                                                                                                                   method.invoke(zos, 0, true, false));
                                                                                                                                        assertEquals(ZIP64_MIN_VERSION, 
                                                                                                                                                   method.invoke(zos, ZipArchiveEntry.DEFLATED, true, true));
                                                                                                                                        assertEquals(ZIP64_MIN_VERSION, 
                                                                                                                                                   method.invoke(zos, ZipArchiveEntry.STORED, true, false));
                                                                                                                                    }

    @Test
                                                                                                                            public void testWriteLocalFileHeader_WithUnicodeFilename() throws IOException {
                                                                                                                                // Setup
                                                                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                                                                zos.setEncoding("UTF-8");
                                                                                                                                zos.setUseLanguageEncodingFlag(true);
                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("tést.txt");
                                                                                                                                entry.setSize(200);
                                                                                                                                entry.setCompressedSize(180);
                                                                                                                                entry.setCrc(987654321L);
                                                                                                                                
                                                                                                                                // Use reflection to access protected method
                                                                                                                                try {
                                                                                                                                    Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                        "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                    writeLocalFileHeader.setAccessible(true);
                                                                                                                                    writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to invoke writeLocalFileHeader: " + e.getMessage());
                                                                                                                                } finally {
                                                                                                                                    zos.close();
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                byte[] header = bos.toByteArray();
                                                                                                                                // Check general purpose bit flag has EFS flag set
                                                                                                                                assertEquals(0, header[6] & 0xff);
                                                                                                                                assertEquals(8, header[7] & 0xff); // EFS flag is set
                                                                                                                                // Check compression method (STORED)
                                                                                                                                assertEquals(0, header[8] & 0xff);
                                                                                                                                assertEquals(0, header[9] & 0xff);
                                                                                                                                // Check filename length (9 chars for "tést.txt" in UTF-8)
                                                                                                                                assertEquals(9, header[26] & 0xff);
                                                                                                                                assertEquals(0, header[27] & 0xff);
                                                                                                                            }

    @Test
                                                                                                                            public void testWriteLocalFileHeader_WithDataDescriptor() throws Exception {
                                                                                                                                // Setup
                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                                
                                                                                                                                // Mock ZipEncoding
                                                                                                                                ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                                                                                when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                                                                                                
                                                                                                                                // Mock StreamCompressor
                                                                                                                                StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                                                                                when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                                                                                
                                                                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                                                                
                                                                                                                                // Use reflection to inject mocks
                                                                                                                                Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                                                                                encodingField.setAccessible(true);
                                                                                                                                encodingField.set(zos, mockEncoding);
                                                                                                                                
                                                                                                                                Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                                                                                compressorField.setAccessible(true);
                                                                                                                                compressorField.set(zos, mockCompressor);
                                                                                                                                
                                                                                                                                Field metaDataField = ZipArchiveOutputStream.class.getDeclaredField("entries");
                                                                                                                                metaDataField.setAccessible(true);
                                                                                                                                
                                                                                                                                // Test
                                                                                                                                Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                    "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                                                                                writeLocalFileHeader.setAccessible(true);
                                                                                                                                writeLocalFileHeader.invoke(zos, entry);
                                                                                                                                
                                                                                                                                // Verify metadata indicates data descriptor will be used
                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                Map<ZipArchiveEntry, Object> entries = 
                                                                                                                                    (Map<ZipArchiveEntry, Object>) metaDataField.get(zos);
                                                                                                                                Object entryMetaData = entries.get(entry);
                                                                                                                                Field usesDataDescriptorField = entryMetaData.getClass().getDeclaredField("usesDataDescriptor");
                                                                                                                                usesDataDescriptorField.setAccessible(true);
                                                                                                                                assertTrue((boolean)usesDataDescriptorField.get(entryMetaData));
                                                                                                                            }

    @Test
                                                                                                                            public void testCreateLocalFileHeader_WithAlignmentAndMethodChangeAllowed() throws Exception {
                                                                                                                                // Setup
                                                                                                                                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                                                                
                                                                                                                                // Mock alignment extra field
                                                                                                                                ResourceAlignmentExtraField alignmentEx = mock(ResourceAlignmentExtraField.class);
                                                                                                                                when(alignmentEx.allowMethodChange()).thenReturn(true);
                                                                                                                                when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(alignmentEx);
                                                                                                                                
                                                                                                                                // Mock other entry properties
                                                                                                                                Method setAlignment = ZipArchiveEntry.class.getDeclaredMethod("setAlignment", int.class);
                                                                                                                                setAlignment.setAccessible(true);
                                                                                                                                setAlignment.invoke(entry, 0);
                                                                                                                                
                                                                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                                                                when(entry.getCrc()).thenReturn(12345L);
                                                                                                                                when(entry.getCompressedSize()).thenReturn(100L);
                                                                                                                                when(entry.getSize()).thenReturn(200L);
                                                                                                                                when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                                                                
                                                                                                                                // Get private method via reflection
                                                                                                                                Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                    "createLocalFileHeader", 
                                                                                                                                    ZipArchiveEntry.class, 
                                                                                                                                    ByteBuffer.class, 
                                                                                                                                    boolean.class, 
                                                                                                                                    boolean.class, 
                                                                                                                                    long.class);
                                                                                                                                createLocalFileHeader.setAccessible(true);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                byte[] result = (byte[]) createLocalFileHeader.invoke(zaos, entry, name, true, false, 0L);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                assertNotNull(result);
                                                                                                                                
                                                                                                                                // Get private fields via reflection
                                                                                                                                Field lfhSigOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG_OFFSET");
                                                                                                                                lfhSigOffsetField.setAccessible(true);
                                                                                                                                int lfhSigOffset = lfhSigOffsetField.getInt(zaos);
                                                                                                                                
                                                                                                                                Field lfhSigField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG");
                                                                                                                                lfhSigField.setAccessible(true);
                                                                                                                                byte[] lfhSig = (byte[]) lfhSigField.get(zaos);
                                                                                                                                
                                                                                                                                assertEquals(lfhSigOffset + 4, result.length);
                                                                                                                                // Verify signature
                                                                                                                                assertArrayEquals(lfhSig, new byte[]{result[0], result[1], result[2], result[3]});
                                                                                                                            }

    @Test
                                                                                                                            public void testWriteDataDescriptor_NoDataDescriptor() throws Exception {
                                                                                                                                // Setup
                                                                                                                                OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                
                                                                                                                                // Get protected writeDataDescriptor method via reflection
                                                                                                                                Method writeDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                                                                writeDataDescriptorMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                writeDataDescriptorMethod.invoke(zos, entry);
                                                                                                                                
                                                                                                                                // Verify that no data was written to the output stream
                                                                                                                                verify(mockOutputStream, never()).write(any(byte[].class));
                                                                                                                                verify(mockOutputStream, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                            }

    @Test
                                                                                                                            public void testWriteDataDescriptor_Max32BitValues() throws Exception {
                                                                                                                                // Setup
                                                                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut) {
                                                                                                                                    // Override protected method to make it accessible for testing
                                                                                                                                    @Override
                                                                                                                                    protected void writeDataDescriptor(ZipArchiveEntry ze) throws IOException {
                                                                                                                                        super.writeDataDescriptor(ze);
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                entry.setMethod(ZipArchiveEntry.DEFLATED);
                                                                                                                                
                                                                                                                                // Use reflection to set private fields since they can't be set directly
                                                                                                                                Field crcField = ZipArchiveEntry.class.getDeclaredField("crc");
                                                                                                                                crcField.setAccessible(true);
                                                                                                                                crcField.set(entry, 0xFFFFFFFFL);
                                                                                                                                
                                                                                                                                Field sizeField = ZipArchiveEntry.class.getDeclaredField("size");
                                                                                                                                sizeField.setAccessible(true);
                                                                                                                                sizeField.set(entry, 0xFFFFFFFFL);
                                                                                                                                
                                                                                                                                Field csizeField = ZipArchiveEntry.class.getDeclaredField("compressedSize");
                                                                                                                                csizeField.setAccessible(true);
                                                                                                                                csizeField.set(entry, 0xFFFFFFFFL);
                                                                                                                                
                                                                                                                                // Execute - use reflection to call protected method
                                                                                                                                Method writeDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                                                                writeDataDescriptorMethod.setAccessible(true);
                                                                                                                                writeDataDescriptorMethod.invoke(zos, entry);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                // Get the DD_SIG value through reflection
                                                                                                                                Field ddSigField = ZipArchiveOutputStream.class.getDeclaredField("DD_SIG");
                                                                                                                                ddSigField.setAccessible(true);
                                                                                                                                byte[] ddSig = (byte[]) ddSigField.get(null);
                                                                                                                                
                                                                                                                                // Verify the expected bytes were written to the output stream
                                                                                                                                byte[] expectedCrc = ZipLong.getBytes(0xFFFFFFFFL);
                                                                                                                                byte[] expectedSize = ZipLong.getBytes(0xFFFFFFFFL);
                                                                                                                                
                                                                                                                                // The order should be: DD_SIG, CRC, Compressed Size, Size
                                                                                                                                verify(mockOut).write(ddSig, 0, ddSig.length);
                                                                                                                                verify(mockOut).write(expectedCrc, 0, expectedCrc.length);
                                                                                                                                verify(mockOut).write(expectedSize, 0, expectedSize.length);
                                                                                                                                verify(mockOut).write(expectedSize, 0, expectedSize.length);
                                                                                                                            }

    @Test
                                                                            public void testWriteDataDescriptor_RegularSizes() throws Exception {
                                                                                // Setup
                                                                                ByteArrayOutputStream mockOut = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut);
                                                                                ZipArchiveOutputStream spyZos = spy(zos);
                                                                                
                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                entry.setSize(2000L);
                                                                                entry.setCompressedSize(1000L);
                                                                                entry.setCrc(0x12345678L);
                                                                                
                                                                                // Mock usesDataDescriptor to return true
                                                                                Method usesDataDescriptor = ZipArchiveOutputStream.class
                                                                                    .getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptor.setAccessible(true);
                                                                                when(usesDataDescriptor.invoke(spyZos, 
                                                                                    anyInt(), anyBoolean())).thenReturn(true);
                                                                                
                                                                                // Mock hasZip64Extra to return false
                                                                                Method hasZip64Extra = ZipArchiveOutputStream.class
                                                                                    .getDeclaredMethod("hasZip64Extra", ZipArchiveEntry.class);
                                                                                hasZip64Extra.setAccessible(true);
                                                                                when(hasZip64Extra.invoke(spyZos, entry)).thenReturn(false);
                                                                                
                                                                                // Access protected writeDataDescriptor method via reflection
                                                                                Method writeDataDescriptor = ZipArchiveOutputStream.class
                                                                                    .getDeclaredMethod("writeDataDescriptor", ZipArchiveEntry.class);
                                                                                writeDataDescriptor.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                writeDataDescriptor.invoke(spyZos, entry);
                                                                                
                                                                                // Verify
                                                                                byte[] output = mockOut.toByteArray();
                                                                                assertTrue(output.length > 0);  // Verify something was written
                                                                                // Additional verification of the written data can be added here
                                                                            }

    @Test
                                                            public void testWriteDataDescriptor_Zip64Sizes() throws Exception {
                                                                // Setup
                                                                java.io.OutputStream mockOut = mock(java.io.OutputStream.class);
                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut);
                                                                ZipArchiveOutputStream spyZos = spy(zos);
                                                                
                                                                // Create ArgumentCaptor for writeOut calls
                                                                org.mockito.ArgumentCaptor<byte[]> captor = org.mockito.ArgumentCaptor.forClass(byte[].class);
                                                                
                                                                // Use reflection to access private methods
                                                                try {
                                                                    Method usesDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                        "usesDataDescriptor", int.class, boolean.class);
                                                                    usesDataDescriptor.setAccessible(true);
                                                                    when((Boolean)usesDataDescriptor.invoke(spyZos, anyInt(), anyBoolean())).thenReturn(true);
                                                                    
                                                                    Method hasZip64Extra = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                        "hasZip64Extra", ZipArchiveEntry.class);
                                                                    hasZip64Extra.setAccessible(true);
                                                                    
                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                    when((Boolean)hasZip64Extra.invoke(spyZos, entry)).thenReturn(true);
                                                                    when(entry.getCrc()).thenReturn(0x12345678L);
                                                                    
                                                                    // Use reflection to get ZIP64_MAGIC value
                                                                    Field zip64MagicField = ZipLong.class.getDeclaredField("ZIP64_MAGIC");
                                                                    zip64MagicField.setAccessible(true);
                                                                    long zip64Magic = ((ZipLong) zip64MagicField.get(null)).getValue();
                                                                    
                                                                    when(entry.getCompressedSize()).thenReturn(zip64Magic + 1L);
                                                                    when(entry.getSize()).thenReturn(zip64Magic + 1L);
                                                                    
                                                                    // Use reflection to get DD_SIG value
                                                                    Field ddSigField = ZipArchiveOutputStream.class.getDeclaredField("DD_SIG");
                                                                    ddSigField.setAccessible(true);
                                                                    byte[] ddSig = (byte[]) ddSigField.get(null);
                                                                    
                                                                    // Execute
                                                                    Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                        "writeDataDescriptor", ZipArchiveEntry.class);
                                                                    writeDataDescriptor.setAccessible(true);
                                                                    writeDataDescriptor.invoke(spyZos, entry);
                                                                    
                                                                    // Verify the output
                                                                    verify(mockOut, times(4)).write(captor.capture());
                                                                    List<byte[]> capturedValues = captor.getAllValues();
                                                                    assertArrayEquals(ddSig, capturedValues.get(0));
                                                                    assertArrayEquals(ZipLong.getBytes(0x12345678L), capturedValues.get(1));
                                                                    assertArrayEquals(ZipEightByteInteger.getBytes(zip64Magic + 1L), capturedValues.get(2));
                                                                    assertArrayEquals(ZipEightByteInteger.getBytes(zip64Magic + 1L), capturedValues.get(3));
                                                                } catch (Exception e) {
                                                                    fail("Reflection operation failed: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                        public void testWriteLocalFileHeader_WithDataDescriptor1() throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
                                            // Setup
                                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                            ZipArchiveEntry entry = new ZipArchiveEntry("streamed.bin");
                                            entry.setMethod(ZipArchiveEntry.DEFLATED);
                                            // No size/crc set to force data descriptor
                                            
                                            // Make protected method accessible
                                            Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                "writeLocalFileHeader", ZipArchiveEntry.class);
                                            writeLocalFileHeader.setAccessible(true);
                                            
                                            // Execute
                                            writeLocalFileHeader.invoke(zos, entry);
                                            
                                            // Verify
                                            byte[] header = bos.toByteArray();
                                            // Check general purpose bit flag has data descriptor flag set
                                            assertEquals(8, header[6] & 0xff);
                                            assertEquals(0, header[7] & 0xff);
                                            // Sizes and CRC should be zero
                                            for (int i = 14; i <= 25; i++) {
                                                assertEquals(0, header[i] & 0xff);
                                            }
                                            
                                            // Clean up
                                            zos.close();
                                        }


}
