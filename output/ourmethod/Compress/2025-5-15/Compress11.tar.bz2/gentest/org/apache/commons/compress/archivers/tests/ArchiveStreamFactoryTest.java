package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_NullInputStream() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   factory.createArchiveInputStream("ar", null);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ArType() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ZipType() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_TarType() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_JarType() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_CpioType() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_DumpType() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_CaseInsensitive() throws Exception {
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveInputStream result1 = factory.createArchiveInputStream("ar", mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result1 instanceof ArArchiveInputStream);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveInputStream result2 = factory.createArchiveInputStream("ZIP", mockInputStream);
                                                                                                                                                                                                                                   assertTrue(result2 instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_EmptyArchiveType() throws Exception {
                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                   ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                   expectedException.expect(ArchiveException.class);
                                                                                                                                                                                                                                   expectedException.expectMessage("Archiver:  not found.");
                                                                                                                                                                                                                                   InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Test
                                                                                                                                                                                                                                   factory.createArchiveInputStream("", mockInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_UnsupportedMark() throws Exception {
                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                   when(input.markSupported()).thenReturn(false);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                                       factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                       fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                       assertEquals("Mark is not supported.", e.getMessage());
                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ZipFormat() throws Exception {
                                                                                                                                                                                                                                   byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                                                                                                                                                                                                                                   // Create a mock stream with just the signature bytes
                                                                                                                                                                                                                                   InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_JarFormat() throws Exception {
                                                                                                                                                                                                                                   byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04};
                                                                                                                                                                                                                                   // Create a simple input stream with the JAR signature
                                                                                                                                                                                                                                   InputStream input = new ByteArrayInputStream(jarSignature);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_ArFormat() throws Exception {
                                                                                                                                                                                                                                   // AR format signature is "!<arch>\n" (8 bytes)
                                                                                                                                                                                                                                   byte[] arSignature = new byte[] {'!', '<', 'a', 'r', 'c', 'h', '>', '\n'};
                                                                                                                                                                                                                                   InputStream input = new ByteArrayInputStream(arSignature);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_CpioFormat() throws Exception {
                                                                                                                                                                                                                                   // Cpio old format magic is "070707" in octal, which is 0xC7, 0x71, 0x71 in hex
                                                                                                                                                                                                                                   byte[] cpioSignature = new byte[] {(byte)0xC7, 0x71, 0x71, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                                                                                                   InputStream input = new ByteArrayInputStream(cpioSignature);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_DumpFormat() throws Exception {
                                                                                                                                                                                                                                   byte[] dumpSignature = new byte[] {
                                                                                                                                                                                                                                       0x50, 0x4B, 0x03, 0x04, 0x44, 0x55, 0x4D, 0x50, // Dump signature
                                                                                                                                                                                                                                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // Padding to reach 32 bytes
                                                                                                                                                                                                                                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                                                                                                                                                                                                                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
                                                                                                                                                                                                                                   };
                                                                                                                                                                                                                                   InputStream input = new ByteArrayInputStream(dumpSignature);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_TarFormat() throws Exception {
                                                                                                                                                                                                                                   // Create a mock TAR signature (USTAR in bytes 257-262)
                                                                                                                                                                                                                                   byte[] tarSignature = new byte[512];
                                                                                                                                                                                                                                   System.arraycopy(new byte[] {'u','s','t','a','r'}, 0, tarSignature, 257, 5);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create input stream with the signature
                                                                                                                                                                                                                                   InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                                                               public void testCreateArchiveInputStream_IOException() throws Exception {
                                                                                                                                                                                                                                   ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                   expectedException.expect(ArchiveException.class);
                                                                                                                                                                                                                                   expectedException.expectMessage("Could not use reset and mark operations.");
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                                                                                                   when(input.markSupported()).thenReturn(true);
                                                                                                                                                                                                                                   doThrow(new IOException("Test exception")).when(input).mark(anyInt());
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                                                                   factory.createArchiveInputStream(input);
                                                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                       public void testCreateArchiveInputStream_NullArchiverName() throws Exception {
                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                           
                                                                                                                                                                                           try {
                                                                                                                                                                                               factory.createArchiveInputStream(null, mockInputStream);
                                                                                                                                                                                               fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                           } catch (IllegalArgumentException e) {
                                                                                                                                                                                               assertEquals("Archivername must not be null.", e.getMessage());
                                                                                                                                                                                           }
                                                                                                                                                                                       }

 @Test
                                                                                                                                                                                       public void testCreateArchiveInputStream_UnknownArchiveType() throws Exception {
                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                           InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                           
                                                                                                                                                                                           try {
                                                                                                                                                                                               factory.createArchiveInputStream("unknown", mockInputStream);
                                                                                                                                                                                               fail("Expected ArchiveException to be thrown");
                                                                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                                                                               assertEquals("Archiver: unknown not found.", e.getMessage());
                                                                                                                                                                                           }
                                                                                                                                                                                       }

 @Test
                                                                                                                                                                                       public void testCreateArchiveInputStream_UnknownFormat() throws Exception {
                                                                                                                                                                                           byte[] unknownSignature = new byte[] {0x00, 0x01, 0x02, 0x03};
                                                                                                                                                                                           InputStream input = new ByteArrayInputStream(unknownSignature) {
                                                                                                                                                                                               @Override
                                                                                                                                                                                               public boolean markSupported() {
                                                                                                                                                                                                   return true;
                                                                                                                                                                                               }
                                                                                                                                                                                           };
                                                                                                                                                                                           
                                                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                                                           try {
                                                                                                                                                                                               factory.createArchiveInputStream(input);
                                                                                                                                                                                               fail("Expected ArchiveException");
                                                                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                                                                               assertEquals("No Archiver found for the stream signature", e.getMessage());
                                                                                                                                                                                           }
                                                                                                                                                                                       }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_ShouldNotCatchRuntimeException() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       String archiverName = ArchiveStreamFactory.ZIP; // valid archiver name
                                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                       
                                                                                                                                                       // Make the mock throw RuntimeException when read is called
                                                                                                                                                       when(mockInputStream.read()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                                       
                                                                                                                                                       // Expect the RuntimeException to propagate
                                                                                                                                                       thrown.expect(RuntimeException.class);
                                                                                                                                                       thrown.expectMessage("Test exception");
                                                                                                                                                       
                                                                                                                                                       // Execute
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       factory.createArchiveInputStream(archiverName, mockInputStream);
                                                                                                                                                       
                                                                                                                                                       // Verification is handled by ExpectedException rule
                                                                                                                                                   }

 @Test
                                                                                                                                              public void testCreateArchiveInputStream_ShouldNotCatchRuntimeException1() throws Exception {
                                                                                                                                                  // Create mock InputStream that throws RuntimeException
                                                                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                                                                  when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                                  doThrow(new RuntimeException("Test runtime exception")).when(mockInput).mark(anyInt());
                                                                                                                                              
                                                                                                                                                  // Set expectation for original behavior
                                                                                                                                                  thrown.expect(RuntimeException.class);
                                                                                                                                                  thrown.expectMessage("Test runtime exception");
                                                                                                                                              
                                                                                                                                                  // Execute test
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  factory.createArchiveInputStream(mockInput);
                                                                                                                                                  
                                                                                                                                                  // If the mutant is present, this would instead throw ArchiveException
                                                                                                                                                  // The test will fail if the exception is caught and wrapped
                                                                                                                                              }

 @Test
                                                                                                                                              public void testCreateArchiveInputStream_ShouldStillCatchIOException() throws Exception {
                                                                                                                                                  // Create mock InputStream that throws IOException
                                                                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                                                                  when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                                  doThrow(new IOException("Test IO exception")).when(mockInput).mark(anyInt());
                                                                                                                                              
                                                                                                                                                  // Set expectation for both original and mutated behavior
                                                                                                                                                  thrown.expect(ArchiveException.class);
                                                                                                                                                  thrown.expectMessage("Could not use reset and mark operations.");
                                                                                                                                              
                                                                                                                                                  // Execute test
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                  factory.createArchiveInputStream(mockInput);
                                                                                                                                                  
                                                                                                                                                  // This test passes for both original and mutated code
                                                                                                                                                  // Included for completeness of testing
                                                                                                                                              }

 @Test
                                                                                                                                              public void testCreateArchiveInputStreamWithUnknownArchiver() throws Exception {
                                                                                                                                                  // Prepare test data
                                                                                                                                                  String unknownArchiver = "UNKNOWN";
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                          
                                                                                                                                                  // Set expectation for exception
                                                                                                                                                  thrown.expect(ArchiveException.class);
                                                                                                                                                  thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                                                                                                                          
                                                                                                                                                  // Execute the method that should throw exception
                                                                                                                                                  factory.createArchiveInputStream(unknownArchiver, mockInputStream);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testCreateArchiveInputStreamWithNullArchiver() throws Exception {
                                                                                                                                                  // Prepare test data
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                          
                                                                                                                                                  // Set expectation for exception
                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                  thrown.expectMessage("Archivername must not be null.");
                                                                                                                                          
                                                                                                                                                  // Execute the method that should throw exception
                                                                                                                                                  factory.createArchiveInputStream(null, mockInputStream);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testCreateArchiveInputStreamWithNullInputStream() throws Exception {
                                                                                                                                                  // Prepare test data
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                          
                                                                                                                                                  // Set expectation for exception
                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                  thrown.expectMessage("InputStream must not be null.");
                                                                                                                                          
                                                                                                                                                  // Execute the method that should throw exception
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, null);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testCreateArchiveInputStreamWithValidArchiver() throws Exception {
                                                                                                                                                  // Prepare test data
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                          
                                                                                                                                                  // Test all supported archive types
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInputStream);
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInputStream);
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInputStream);
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInputStream);
                                                                                                                                                  factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInputStream);
                                                                                                                                              }

 @Test(expected = ArchiveException.class)
                                                                                                                                          public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldThrowWithCorrectMessage() throws Exception {
                                                                                                                                              // Arrange
                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                              when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                                              doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                                                                                                                                              
                                                                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                              
                                                                                                                                              // Act & Assert
                                                                                                                                              try {
                                                                                                                                                  factory.createArchiveInputStream(mockInputStream);
                                                                                                                                                  fail("Expected ArchiveException to be thrown");
                                                                                                                                              } catch (ArchiveException e) {
                                                                                                                                                  assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                                                                  throw e;
                                                                                                                                              }
                                                                                                                                          }

 @Test(expected = ArchiveException.class)
                                                                                                                                             public void testCreateArchiveInputStreamWithUnknownFormat() throws Exception {
                                                                                                                                                 // Prepare test data
                                                                                                                                                 String unknownArchiverName = "UNKNOWN_FORMAT";
                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                 
                                                                                                                                                 // Create factory instance
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 
                                                                                                                                                 // This should throw ArchiveException for original code
                                                                                                                                                 // Mutant would return null instead
                                                                                                                                                 factory.createArchiveInputStream(unknownArchiverName, mockInputStream);
                                                                                                                                                 
                                                                                                                                                 // If we reach here without exception, the test fails (for original code)
                                                                                                                                                 // For mutant, it would return null but we won't reach here because 
                                                                                                                                                 // we're expecting an exception
                                                                                                                                             }

 @Test
                                                                                                                                             public void testCreateArchiveInputStreamWithUnknownFormatDetectsMutant() throws Exception {
                                                                                                                                                 // This alternative test explicitly checks for null return to catch mutant
                                                                                                                                                 String unknownArchiverName = "UNKNOWN_FORMAT";
                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                 
                                                                                                                                                 try {
                                                                                                                                                     ArchiveInputStream result = factory.createArchiveInputStream(unknownArchiverName, mockInputStream);
                                                                                                                                                     // If we get here, check if result is null (mutant behavior)
                                                                                                                                                     assertNotNull("Method should throw exception for unknown format, not return null", result);
                                                                                                                                                 } catch (ArchiveException e) {
                                                                                                                                                     // This is expected behavior for original code
                                                                                                                                                     assertTrue(true);
                                                                                                                                                 }
                                                                                                                                             }

 @Test(expected = ArchiveException.class)
                                                                                                                                         public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ThrowsArchiveException() throws Exception {
                                                                                                                                             // Arrange
                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                             when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                                             doThrow(new IOException("mark failed")).when(mockInputStream).mark(anyInt());
                                                                                                                                             
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             
                                                                                                                                             // Act
                                                                                                                                             factory.createArchiveInputStream(mockInputStream);
                                                                                                                                             
                                                                                                                                             // Assert - expected exception is declared in annotation
                                                                                                                                             // If mutant is present (returns null), this will fail as no exception is thrown
                                                                                                                                         }

 @Test
                                                                                                                                            public void testCreateArchiveInputStreamWithUnsupportedFormatThrowsException() throws Exception {
                                                                                                                                                // Arrange
                                                                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                String unsupportedFormat = "UNSUPPORTED_FORMAT";
                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                
                                                                                                                                                // Set expectation
                                                                                                                                                thrown.expect(ArchiveException.class);
                                                                                                                                                thrown.expectMessage("Archiver: " + unsupportedFormat + " not found.");
                                                                                                                                                
                                                                                                                                                // Act
                                                                                                                                                factory.createArchiveInputStream(unsupportedFormat, mockInputStream);
                                                                                                                                                
                                                                                                                                                // Assertion is handled by the ExpectedException rule
                                                                                                                                            }

 @Test
                                                                                                                                       public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowArchiveException() throws Exception {
                                                                                                                                           // Arrange
                                                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                           when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                                           doThrow(new IOException("mark failed")).when(mockInputStream).mark(anyInt());
                                                                                                                                           
                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                           
                                                                                                                                           // Act & Assert
                                                                                                                                           try {
                                                                                                                                               factory.createArchiveInputStream(mockInputStream);
                                                                                                                                               fail("Expected ArchiveException to be thrown");
                                                                                                                                           } catch (ArchiveException e) {
                                                                                                                                               assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                                                               assertTrue(e.getCause() instanceof IOException);
                                                                                                                                           }
                                                                                                                                       }

 @Test
                                                                                                                              public void testCreateArchiveInputStream_IOExceptionPrintsMessage() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                                                  when(mockInput.markSupported()).thenReturn(true);
                                                                                                                                  when(mockInput.read(any(byte[].class))).thenThrow(new IOException("Test IO Error"));
                                                                                                                                  
                                                                                                                                  java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
                                                                                                                                  java.io.PrintStream originalOut = System.out;
                                                                                                                                  System.setOut(new java.io.PrintStream(outContent));
                                                                                                                                  
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  
                                                                                                                                  // Set up expected exception
                                                                                                                                  ExpectedException exception = ExpectedException.none();
                                                                                                                                  exception.expect(ArchiveException.class);
                                                                                                                                  exception.expectMessage("Could not use reset and mark operations.");
                                                                                                                                  
                                                                                                                                  try {
                                                                                                                                      // Act
                                                                                                                                      factory.createArchiveInputStream(mockInput);
                                                                                                                                  } finally {
                                                                                                                                      // Clean up
                                                                                                                                      System.setOut(originalOut);
                                                                                                                                      // Verify the mutant behavior - message was printed
                                                                                                                                      assertTrue(outContent.toString().contains("Test IO Error"));
                                                                                                                                  }
                                                                                                                              }

 @Test
                                                                                                                          public void testCreateArchiveInputStream_IOException_ShouldNotPrintMessage() throws Exception {
                                                                                                                              // Arrange
                                                                                                                              org.apache.commons.compress.archivers.ArchiveStreamFactory factory = 
                                                                                                                                  new org.apache.commons.compress.archivers.ArchiveStreamFactory();
                                                                                                                              java.io.InputStream mockInput = new java.io.InputStream() {
                                                                                                                                  @Override
                                                                                                                                  public int read() throws java.io.IOException {
                                                                                                                                      throw new java.io.IOException("Test IOException");
                                                                                                                                  }
                                                                                                                              };
                                                                                                                              
                                                                                                                              // Save original System.out and redirect to our stream
                                                                                                                              java.io.PrintStream originalOut = System.out;
                                                                                                                              java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
                                                                                                                              System.setOut(new java.io.PrintStream(outContent));
                                                                                                                              
                                                                                                                              try {
                                                                                                                                  // Act
                                                                                                                                  try {
                                                                                                                                      factory.createArchiveInputStream(org.apache.commons.compress.archivers.ArchiveStreamFactory.ZIP, mockInput);
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      // Expected exception
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  String output = outContent.toString();
                                                                                                                                  assertFalse("Mutation detected: Exception message was printed to console", 
                                                                                                                                             output.contains("Test IOException"));
                                                                                                                              } finally {
                                                                                                                                  // Restore original System.out
                                                                                                                                  System.setOut(originalOut);
                                                                                                                              }
                                                                                                                          }

 @Test(expected = ArchiveException.class)
                                                                                                                      public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldThrowWithFixedMessage() throws Exception {
                                                                                                                          // Arrange
                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                          IOException ioException = new IOException("Simulated IO error");
                                                                                                                          
                                                                                                                          // Mock the InputStream to throw IOException when mark/reset is called
                                                                                                                          doThrow(ioException).when(mockInputStream).mark(anyInt());
                                                                                                                          
                                                                                                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                          
                                                                                                                          // Act & Assert
                                                                                                                          try {
                                                                                                                              factory.createArchiveInputStream(mockInputStream);
                                                                                                                              fail("Expected ArchiveException to be thrown");
                                                                                                                          } catch (ArchiveException e) {
                                                                                                                              // Verify exception message is the original fixed string, not the IO exception's message
                                                                                                                              assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                                              // Verify the cause is our simulated IOException
                                                                                                                              assertSame(ioException, e.getCause());
                                                                                                                              // Re-throw to satisfy @Test(expected)
                                                                                                                              throw e;
                                                                                                                          }
                                                                                                                      }

 @Test(expected = ArchiveException.class)
                                                                                                                     public void testCreateArchiveInputStream_ExceptionMessage() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                         
                                                                                                                         // Simulate an IOException when mark/reset is called
                                                                                                                         when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                         doThrow(new java.io.IOException("Mocked IO error")).when(mockInputStream).reset();
                                                                                                                     
                                                                                                                         // Act
                                                                                                                         try {
                                                                                                                             factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                                                                         } catch (ArchiveException e) {
                                                                                                                             // Assert
                                                                                                                             assertEquals("Expected specific error message", 
                                                                                                                                          "Could not use reset and mark operations.", 
                                                                                                                                          e.getMessage());
                                                                                                                             throw e;
                                                                                                                         }
                                                                                                                     }

 @Test
                                                                                                                     public void testCreateArchiveInputStream_shouldThrowArchiveExceptionWithProperMessageWhenResetFails() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                         
                                                                                                                         // Simulate mark/reset operation failure
                                                                                                                         when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                         doThrow(new IOException("Mark not supported")).when(mockInputStream).reset();
                                                                                                                 
                                                                                                                         // Expect specific exception with message
                                                                                                                         thrown.expect(ArchiveException.class);
                                                                                                                         thrown.expectMessage("Could not use reset and mark operations.");
                                                                                                                 
                                                                                                                         // Act
                                                                                                                         // This would test the version of createArchiveInputStream that handles mark/reset
                                                                                                                         // Note: Since the exact method signature isn't shown, this is based on the mutant info
                                                                                                                         factory.createArchiveInputStream(mockInputStream);
                                                                                                                     }

 @Test
                                                                                                                     public void testCreateArchiveInputStream_shouldThrowExceptionForUnknownArchiver() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                         String unknownArchiver = "UNKNOWN";
                                                                                                                 
                                                                                                                         // Expect exception with proper message
                                                                                                                         thrown.expect(ArchiveException.class);
                                                                                                                         thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                                                                                                 
                                                                                                                         // Act
                                                                                                                         factory.createArchiveInputStream(unknownArchiver, mockInputStream);
                                                                                                                     }

 @Test
                                                                                                                     public void testCreateArchiveInputStream_shouldThrowExceptionForNullArchiverName() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                 
                                                                                                                         // Expect exception
                                                                                                                         thrown.expect(IllegalArgumentException.class);
                                                                                                                         thrown.expectMessage("Archivername must not be null.");
                                                                                                                 
                                                                                                                         // Act
                                                                                                                         factory.createArchiveInputStream(null, mockInputStream);
                                                                                                                     }

 @Test
                                                                                                                     public void testCreateArchiveInputStream_shouldThrowExceptionForNullInputStream() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                 
                                                                                                                         // Expect exception
                                                                                                                         thrown.expect(IllegalArgumentException.class);
                                                                                                                         thrown.expectMessage("InputStream must not be null.");
                                                                                                                 
                                                                                                                         // Act
                                                                                                                         factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, null);
                                                                                                                     }

 @Test(expected = ArchiveException.class)
                                                                                                                 public void testCreateArchiveInputStream_IOException_ShouldThrowWithCorrectMessage() throws Exception {
                                                                                                                     // Arrange
                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                     when(mockInput.markSupported()).thenReturn(true);
                                                                                                                     doThrow(new IOException("Simulated IO error")).when(mockInput).mark(anyInt());
                                                                                                                     
                                                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                     
                                                                                                                     // Act & Assert
                                                                                                                     try {
                                                                                                                         factory.createArchiveInputStream(mockInput);
                                                                                                                         fail("Expected ArchiveException to be thrown");
                                                                                                                     } catch (ArchiveException e) {
                                                                                                                         // Verify the exception message contains the expected string
                                                                                                                         assertTrue("Exception message should contain 'Could not use reset and mark operations'", 
                                                                                                                                   e.getMessage().contains("Could not use reset and mark operations"));
                                                                                                                         throw e;
                                                                                                                     }
                                                                                                                 }

 @Test
                                                                                                       public void testCreateArchiveInputStream_ShouldNotCatchRuntimeException2() throws Exception {
                                                                                                           // Setup
                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                           String archiverName = ArchiveStreamFactory.ZIP; // Using a valid archiver name
                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                           
                                                                                                           // Configure mock to throw RuntimeException when used
                                                                                                           when(mockInputStream.read(any(byte[].class))).thenThrow(new RuntimeException("Test exception"));
                                                                                                           
                                                                                                           // Create the stream (this shouldn't throw as the exception occurs during reading)
                                                                                                           ArchiveInputStream ais = factory.createArchiveInputStream(archiverName, mockInputStream);
                                                                                                           
                                                                                                           try {
                                                                                                               // This line should trigger the exception when the stream is actually used
                                                                                                               ais.read(new byte[10]);
                                                                                                               fail("Expected RuntimeException to be thrown");
                                                                                                           } catch (RuntimeException e) {
                                                                                                               // Verify the exception
                                                                                                               assertEquals("Test exception", e.getMessage());
                                                                                                           }
                                                                                                       }

 @Test
                                                                                                   public void testCreateArchiveInputStream_ShouldNotCatchRuntimeException3() throws Exception {
                                                                                                       // Setup
                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                       String archiverName = ArchiveStreamFactory.ZIP; // Using a valid archiver name
                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                       
                                                                                                       // Configure mock to throw RuntimeException when used
                                                                                                       when(mockInputStream.read(any(byte[].class))).thenThrow(new RuntimeException("Test exception"));
                                                                                                       
                                                                                                       // Test
                                                                                                       ArchiveInputStream ais = factory.createArchiveInputStream(archiverName, mockInputStream);
                                                                                                       
                                                                                                       try {
                                                                                                           // This line should trigger the exception when the stream is actually used
                                                                                                           ais.read(new byte[10]);
                                                                                                           fail("Expected RuntimeException to be thrown");
                                                                                                       } catch (RuntimeException e) {
                                                                                                           // Verify the exception
                                                                                                           assertEquals("Test exception", e.getMessage());
                                                                                                       }
                                                                                                   }

 @Test
                                                                                          public void testCreateArchiveInputStream_IOExceptionShouldIncludeCause() throws Exception {
                                                                                              // Arrange
                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                              when(mockInput.markSupported()).thenReturn(true);
                                                                                              when(mockInput.read(any(byte[].class))).thenThrow(new IOException("Test IO Error"));
                                                                                              
                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                              
                                                                                              // Set expectation
                                                                                              thrown.expect(ArchiveException.class);
                                                                                              thrown.expectMessage("Could not use reset and mark operations.");
                                                                                              thrown.expectCause(org.hamcrest.CoreMatchers.is(org.hamcrest.CoreMatchers.instanceOf(IOException.class)));
                                                                                              
                                                                                              // Act
                                                                                              factory.createArchiveInputStream(mockInput);
                                                                                          }

 @Test
                                                                  public void testCreateArchiveInputStream_ShouldIncludeCauseInException() throws Exception {
                                                                      // Arrange
                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                      
                                                                      // Make the stream throw IOException when mark/reset is called
                                                                      doThrow(new IOException("Test error")).when(mockInputStream).mark(anyInt());
                                                                      
                                                                      // Setup expected exception
                                                                      ExpectedException exception = ExpectedException.none();
                                                                      exception.expect(ArchiveException.class);
                                                                      exception.expectMessage("Could not use reset and mark operations.");
                                                                      exception.expectCause(org.hamcrest.CoreMatchers.is(org.hamcrest.CoreMatchers.instanceOf(IOException.class)));
                                                                      
                                                                      // Act
                                                                      factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                                                  }

 @Test(expected = ArchiveException.class)
                                                                  public void testCreateArchiveInputStreamWithUnknownFormatThrowsArchiveException() throws Exception {
                                                                      // Arrange
                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                      InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                      String unknownFormat = "UNKNOWN_FORMAT";
                                                                      
                                                                      // Act & Assert
                                                                      factory.createArchiveInputStream(unknownFormat, inputStream);
                                                                  }

 @Test
                                                                  public void testCreateArchiveInputStreamExceptionType() {
                                                                      // Arrange
                                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                      InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                      String unknownFormat = "UNKNOWN_FORMAT";
                                                                      
                                                                      try {
                                                                          // Act
                                                                          factory.createArchiveInputStream(unknownFormat, inputStream);
                                                                          fail("Expected exception was not thrown");
                                                                      } catch (Exception e) {
                                                                          // Assert
                                                                          assertTrue("Should throw ArchiveException", e instanceof ArchiveException);
                                                                          assertFalse("Should not throw RuntimeException", e instanceof RuntimeException);
                                                                      }
                                                                  }

 @Test
                                                         public void testCreateArchiveInputStream_shouldThrowArchiveExceptionWhenMarkFails() throws Exception {
                                                             // Arrange
                                                             InputStream mockInputStream = mock(InputStream.class);
                                                             when(mockInputStream.markSupported()).thenReturn(true);
                                                             doThrow(new IOException("Mark failed")).when(mockInputStream).mark(anyInt());
                                                             
                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                             
                                                             try {
                                                                 // Act
                                                                 factory.createArchiveInputStream(mockInputStream);
                                                                 fail("Expected ArchiveException to be thrown");
                                                             } catch (ArchiveException e) {
                                                                 // Assert
                                                                 assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                             }
                                                         }

 @Test
                                                         public void testCreateArchiveInputStreamWithUnknownArchiverShouldThrowExceptionWithCorrectMessage() throws Exception {
                                                             // Arrange
                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                             InputStream mockInputStream = mock(InputStream.class);
                                                             String unknownArchiver = "UNKNOWN_FORMAT";
                                                             
                                                             // Set expectation for exception type and message
                                                             thrown.expect(ArchiveException.class);
                                                             thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                                             
                                                             // Act
                                                             factory.createArchiveInputStream(unknownArchiver, mockInputStream);
                                                         }

 @Test(expected = ArchiveException.class)
                                                     public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_OriginalMessage() throws Exception {
                                                         // Arrange
                                                         InputStream mockInputStream = mock(InputStream.class);
                                                         when(mockInputStream.markSupported()).thenReturn(true);
                                                         doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                                                         
                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                         
                                                         // Act & Assert
                                                         try {
                                                             factory.createArchiveInputStream(mockInputStream);
                                                             fail("Expected ArchiveException to be thrown");
                                                         } catch (ArchiveException e) {
                                                             assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                             throw e;
                                                         }
                                                     }

 @Test(expected = ArchiveException.class)
                                                        public void testCreateArchiveInputStreamWithUnsupportedArchiveType() throws Exception {
                                                            // Prepare test data
                                                            String unsupportedArchiverName = "UNSUPPORTED_FORMAT";
                                                            InputStream mockInputStream = mock(InputStream.class);
                                                            
                                                            // Create factory instance
                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                            
                                                            // This should throw ArchiveException for original code
                                                            // Mutant would return null instead
                                                            factory.createArchiveInputStream(unsupportedArchiverName, mockInputStream);
                                                            
                                                            // If we reach here without exception, the test fails (for original code)
                                                            // For mutant, we could add:
                                                            // ArchiveInputStream result = factory.createArchiveInputStream(unsupportedArchiverName, mockInputStream);
                                                            // assertNull("Should throw exception but returned null", result);
                                                            // But the @Test(expected) is cleaner for the original behavior
                                                        }

 @Test(expected = ArchiveException.class)
                                                    public void testCreateArchiveInputStream_IOExceptionDuringSignatureCheck_ThrowsArchiveException() throws Exception {
                                                        // Arrange
                                                        InputStream mockInputStream = mock(InputStream.class);
                                                        when(mockInputStream.markSupported()).thenReturn(true);
                                                        
                                                        // Simulate IOException during signature reading
                                                        doThrow(new IOException("Test IO Exception")).when(mockInputStream).mark(anyInt());
                                                        
                                                        ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                        
                                                        // Act & Assert
                                                        // Should throw ArchiveException, mutant would return null
                                                        factory.createArchiveInputStream(mockInputStream);
                                                    }

 @Test
                                                       public void testCreateArchiveInputStreamForTar() throws Exception {
                                                           // Prepare test data
                                                           String archiverName = ArchiveStreamFactory.TAR;
                                                           InputStream mockInputStream = mock(InputStream.class);
                                                           
                                                           // Create instance of class under test
                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                           
                                                           // Call method under test
                                                           ArchiveInputStream result = factory.createArchiveInputStream(archiverName, mockInputStream);
                                                           
                                                           // Verify results
                                                           assertNotNull("Result should not be null", result);
                                                           assertTrue("Should return TarArchiveInputStream for TAR type", 
                                                                     result instanceof TarArchiveInputStream);
                                                           
                                                           // Additional verification that the correct input stream was used
                                                           // This would be implementation specific, but we can verify the mock wasn't interacted with
                                                           // in unexpected ways if needed
                                                           verifyZeroInteractions(mockInputStream);
                                                       }

 @Test(expected = IllegalArgumentException.class)
                                                       public void testCreateArchiveInputStreamWithNullArchiverName() throws Exception {
                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                           factory.createArchiveInputStream(null, mock(InputStream.class));
                                                       }

 @Test(expected = IllegalArgumentException.class)
                                                       public void testCreateArchiveInputStreamWithNullInputStream1() throws Exception {
                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                           factory.createArchiveInputStream(ArchiveStreamFactory.TAR, null);
                                                       }

 @Test(expected = ArchiveException.class)
                                                       public void testCreateArchiveInputStreamWithUnknownArchiveType() throws Exception {
                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                           factory.createArchiveInputStream("UNKNOWN_TYPE", mock(InputStream.class));
                                                       }

 @Test(expected = ArchiveException.class)
                                                  public void testCreateArchiveInputStream_InvalidTarHeader() throws Exception {
                                                      // Create a byte array with enough length (>=512) but invalid TAR content
                                                      byte[] invalidTarContent = new byte[512];
                                                      // Fill with some data that's not a valid TAR header
                                                      for (int i = 0; i < invalidTarContent.length; i++) {
                                                          invalidTarContent[i] = (byte) 0xFF;
                                                      }
                                                      
                                                      // Create a mock InputStream that returns our invalid TAR content
                                                      InputStream mockInput = mock(InputStream.class);
                                                      when(mockInput.markSupported()).thenReturn(true);
                                                      when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                          byte[] buf = (byte[]) invocation.getArguments()[0];
                                                          System.arraycopy(invalidTarContent, 0, buf, 0, Math.min(buf.length, invalidTarContent.length));
                                                          return Math.min(buf.length, invalidTarContent.length);
                                                      });
                                                      
                                                      // This should throw ArchiveException as none of the archive types will match
                                                      ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                      factory.createArchiveInputStream(mockInput);
                                                      
                                                      // Verify the mock interactions
                                                      verify(mockInput, atLeastOnce()).mark(anyInt());
                                                      verify(mockInput, atLeastOnce()).reset();
                                                  }

 @Test
                                         public void testCreateArchiveInputStream_IOException_ShouldPrintMessage() throws Exception {
                                             // Arrange
                                             InputStream mockInputStream = mock(InputStream.class);
                                             when(mockInputStream.markSupported()).thenReturn(true);
                                             doThrow(new IOException("Test IO Exception")).when(mockInputStream).mark(anyInt());
                                             
                                             // Redirect System.out to capture output
                                             java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
                                             java.io.PrintStream originalOut = System.out;
                                             System.setOut(new java.io.PrintStream(outContent));
                                             
                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                             
                                             try {
                                                 // Act
                                                 factory.createArchiveInputStream(mockInputStream);
                                                 fail("Expected ArchiveException to be thrown");
                                             } catch (ArchiveException e) {
                                                 // Assert
                                                 String expectedOutput = "Test IO Exception";
                                                 assertTrue("System.out should contain the exception message", 
                                                           outContent.toString().contains(expectedOutput));
                                                 assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                 assertTrue(e.getCause() instanceof IOException);
                                                 throw e;
                                             } finally {
                                                 // Restore System.out
                                                 System.setOut(originalOut);
                                             }
                                         }

 @Test
                                     public void testCreateArchiveInputStream_IOExceptionShouldPrintMessage() throws Exception {
                                         // Arrange
                                         String archiverName = "zip"; // using string literal instead of constant
                                         InputStream mockInputStream = mock(InputStream.class);
                                         when(mockInputStream.read()).thenThrow(new IOException("Test IO Exception"));
                                         
                                         // Capture System.out
                                         java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
                                         java.io.PrintStream originalOut = System.out;
                                         System.setOut(new java.io.PrintStream(outContent));
                                         
                                         try {
                                             // Act
                                             try {
                                                 new ArchiveStreamFactory().createArchiveInputStream(archiverName, mockInputStream);
                                                 fail("Expected ArchiveException due to IOException");
                                             } catch (ArchiveException e) {
                                                 // Expected - the underlying stream throws IOException
                                             }
                                             
                                             // Assert
                                             assertTrue("System.out should contain the exception message", 
                                                       outContent.toString().contains("Test IO Exception"));
                                         } finally {
                                             // Restore System.out
                                             System.setOut(originalOut);
                                         }
                                     }

 @Test
                                     public void testCreateArchiveInputStream_ExceptionMessage1() throws Exception {
                                         // Prepare
                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                         InputStream mockInputStream = mock(InputStream.class);
                                         
                                         // Make the input stream throw IOException when mark/reset is called
                                         doThrow(new IOException("Mark/reset failed")).when(mockInputStream).mark(anyInt());
                                         
                                         // Expect ArchiveException with the specific message
                                         thrown.expect(ArchiveException.class);
                                         thrown.expectMessage("Could not use reset and mark operations.");
                                         
                                         // Test
                                         factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInputStream);
                                         
                                         // Verify mark was called (implementation detail)
                                         verify(mockInputStream).mark(anyInt());
                                     }

 @Test(expected = ArchiveException.class)
                                 public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldThrowWithSpecificMessage() throws Exception {
                                     // Arrange
                                     InputStream mockInputStream = mock(InputStream.class);
                                     when(mockInputStream.markSupported()).thenReturn(true);
                                     
                                     // Simulate IOException during mark operation
                                     doThrow(new IOException("Simulated IO Error")).when(mockInputStream).mark(anyInt());
                                     
                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                     
                                     // Act
                                     try {
                                         factory.createArchiveInputStream(mockInputStream);
                                     } catch (ArchiveException e) {
                                         // Assert
                                         assertEquals("Could not use reset and mark operations.", e.getMessage());
                                         throw e;
                                     }
                                 }

 @Test
                                public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldIncludeCause() throws Exception {
                                    // Arrange
                                    InputStream mockInputStream = mock(InputStream.class);
                                    when(mockInputStream.markSupported()).thenReturn(true);
                                    doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                                    
                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                    
                                    // Act & Assert
                                    try {
                                        factory.createArchiveInputStream(mockInputStream);
                                        fail("Expected ArchiveException to be thrown");
                                    } catch (ArchiveException e) {
                                        // Verify the exception message
                                        assertEquals("Could not use reset and mark operations.", e.getMessage());
                                        
                                        // This assertion will catch the mutant - verify the cause exists
                                        assertNotNull("Exception should have a cause", e.getCause());
                                        assertTrue("Cause should be IOException", e.getCause() instanceof IOException);
                                        assertEquals("Simulated IO error", e.getCause().getMessage());
                                    }
                                }

 @Test
                   public void testCreateArchiveInputStream_PropagatesMarkResetExceptionWithCause() throws Exception {
                       // Arrange
                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                       InputStream mockInput = mock(InputStream.class);
                       
                       // Setup mock to throw IOException on mark/reset
                       doThrow(new IOException("Mark not supported")).when(mockInput).mark(anyInt());
                       
                       // We'll test with ZIP as an example, but could test with any supported format
                       thrown.expect(ArchiveException.class);
                       thrown.expectMessage("Could not use reset and mark operations.");
                       thrown.expectCause(org.hamcrest.CoreMatchers.is(org.hamcrest.CoreMatchers.instanceOf(IOException.class)));
                       
                       // Act
                       try (ArchiveInputStream ais = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput)) {
                           // This should trigger mark/reset operation in the stream
                           ais.mark(100);
                           ais.reset();
                       }
                   }

 @Test
                   public void testCreateArchiveInputStreamWithUnknownArchiverThrowsArchiveException() throws Exception {
                       // Prepare test data
                       String unknownArchiver = "UNKNOWN_FORMAT";
                       InputStream mockInputStream = mock(InputStream.class);
                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                       
                       // Set expectation
                       thrown.expect(ArchiveException.class);
                       thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                       
                       // Execute test
                       factory.createArchiveInputStream(unknownArchiver, mockInputStream);
                   }

 @Test(expected = ArchiveException.class)
               public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ThrowsArchiveException1() throws Exception {
                   // Arrange
                   InputStream mockInputStream = mock(InputStream.class);
                   when(mockInputStream.markSupported()).thenReturn(true);
                   doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                   
                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                   
                   // Act & Assert
                   factory.createArchiveInputStream(mockInputStream);
                   
                   // The test will pass if ArchiveException is thrown (original behavior)
                   // The test will fail if RuntimeException is thrown (mutant behavior)
                   // The expected annotation ensures we're testing for the specific exception type
               }

 @Test
             public void testCreateArchiveInputStreamWithUnsupportedFormatThrowsCorrectException() throws Exception {
                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                 InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                 try {
                     factory.createArchiveInputStream("UNSUPPORTED_FORMAT", mockInputStream);
                     fail("Expected ArchiveException to be thrown");
                 } catch (ArchiveException e) {
                     assertEquals("Archiver: UNSUPPORTED_FORMAT not found.", e.getMessage());
                     throw e;
                 }
             }

 @Test
             public void testCreateArchiveInputStreamWithNullArchiverNameThrowsIllegalArgumentException() {
                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                 InputStream mockInputStream = mock(InputStream.class);
                 try {
                     factory.createArchiveInputStream(null, mockInputStream);
                     fail("Expected IllegalArgumentException to be thrown");
                 } catch (Exception e) {
                     assertTrue(e instanceof IllegalArgumentException);
                     assertEquals("Archivername must not be null.", e.getMessage());
                 }
             }

 @Test
             public void testCreateArchiveInputStreamWithNullInputStreamThrowsIllegalArgumentException() {
                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                 try {
                     factory.createArchiveInputStream("zip", null);
                     fail("Expected IllegalArgumentException to be thrown");
                 } catch (Exception e) {
                     assertTrue(e instanceof IllegalArgumentException);
                     assertEquals("InputStream must not be null.", e.getMessage());
                 }
             }

 @Test
             public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldThrowWithCorrectMessage1() throws Exception {
                 // Arrange
                 InputStream mockInput = mock(InputStream.class);
                 doThrow(new IOException("Simulated IO error")).when(mockInput).mark(anyInt());
                 
                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                 
                 try {
                     // Act
                     factory.createArchiveInputStream(mockInput);
                     fail("Expected ArchiveException to be thrown");
                 } catch (ArchiveException e) {
                     // Assert
                     assertEquals("Could not use reset and mark operations.", e.getMessage());
                 }
             }

 @Test(expected = ArchiveException.class)
             public void testCreateArchiveInputStreamWithUnsupportedArchiveType1() throws Exception {
                 // Prepare test data
                 String unsupportedArchiveName = "UNSUPPORTED_FORMAT";
                 InputStream mockInputStream = mock(InputStream.class);
                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                 
                 // Execute - should throw ArchiveException
                 factory.createArchiveInputStream(unsupportedArchiveName, mockInputStream);
                 
                 // If we reach here, the test fails because no exception was thrown
                 // The mutant would return null instead of throwing, making the test fail
             }

 @Test(expected = ArchiveException.class)
         public void testCreateArchiveInputStream_IOExceptionDuringSignatureCheck_ThrowsArchiveException1() throws Exception {
             // Arrange
             InputStream mockInputStream = mock(InputStream.class);
             
             // Configure mock to:
             // 1. Support mark operations (first if condition)
             when(mockInputStream.markSupported()).thenReturn(true);
             // 2. Throw IOException when reading signature
             when(mockInputStream.read(any(byte[].class))).thenThrow(new IOException("Test IO Exception"));
             
             ArchiveStreamFactory factory = new ArchiveStreamFactory();
             
             // Act & Assert
             // Should throw ArchiveException for original code
             // Mutant would return null, causing test to fail
             factory.createArchiveInputStream(mockInputStream);
         }

 @Test
            public void testCreateArchiveInputStreamWithUnsupportedFormatThrowsException1() throws Exception {
                // Arrange
                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                String unsupportedArchiver = "UNSUPPORTED_FORMAT";
                InputStream mockInputStream = mock(InputStream.class);
                
                // Set expectation
                thrown.expect(ArchiveException.class);
                thrown.expectMessage("Archiver: " + unsupportedArchiver + " not found.");
                
                // Act
                factory.createArchiveInputStream(unsupportedArchiver, mockInputStream);
                
                // Assert - handled by ExpectedException rule
            }

 @Test(expected = ArchiveException.class)
        public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ThrowsArchiveException2() throws Exception {
            // Arrange
            InputStream failingInputStream = mock(InputStream.class);
            when(failingInputStream.markSupported()).thenReturn(true);
            
            // Simulate IOException during mark operation
            doThrow(new IOException("mark failed")).when(failingInputStream).mark(anyInt());
            
            ArchiveStreamFactory factory = new ArchiveStreamFactory();
            
            // Act & Assert
            // This should throw ArchiveException in original code
            // Mutant will just print to stdout and continue, failing this test
            factory.createArchiveInputStream(failingInputStream);
        }

 @Test
           public void testCreateArchiveInputStream_throwsIOException() throws Exception {
               // Setup
               String archiverName = ArchiveStreamFactory.ZIP; // using a valid archiver name
               InputStream mockInputStream = mock(InputStream.class);
               
               // Make the input stream throw IOException when read
               when(mockInputStream.read()).thenThrow(new IOException("Test IOException"));
               
               // Expect ArchiveException to be thrown (not silently ignored)
               thrown.expect(ArchiveException.class);
               thrown.expectMessage("IOException occurred when creating ZipArchiveInputStream");
               
               // Execute
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               factory.createArchiveInputStream(archiverName, mockInputStream);
           }

 @Test
           public void testCreateArchiveInputStream_invalidArchiver() throws Exception {
               // Setup
               String invalidArchiver = "INVALID_FORMAT";
               InputStream mockInputStream = mock(InputStream.class);
               
               // Expect ArchiveException
               thrown.expect(ArchiveException.class);
               thrown.expectMessage("Archiver: " + invalidArchiver + " not found.");
               
               // Execute
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               factory.createArchiveInputStream(invalidArchiver, mockInputStream);
           }

 @Test
           public void testCreateArchiveInputStream_nullArchiverName() throws Exception {
               // Setup
               InputStream mockInputStream = mock(InputStream.class);
               
               // Expect IllegalArgumentException
               thrown.expect(IllegalArgumentException.class);
               thrown.expectMessage("Archivername must not be null.");
               
               // Execute
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               factory.createArchiveInputStream(null, mockInputStream);
           }

 @Test
           public void testCreateArchiveInputStream_nullInputStream() throws Exception {
               // Setup
               String archiverName = ArchiveStreamFactory.ZIP;
               
               // Expect IllegalArgumentException
               thrown.expect(IllegalArgumentException.class);
               thrown.expectMessage("InputStream must not be null.");
               
               // Execute
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               factory.createArchiveInputStream(archiverName, null);
           }

 @Test
      public void testCreateArchiveInputStream_HandlesTarDetectionException() throws Exception {
          // Create a mock input stream that will:
          // 1. Support mark/reset
          // 2. Return enough bytes for TAR detection (512)
          // 3. But contain invalid TAR data that will cause exception during detection
          InputStream in = mock(InputStream.class);
          when(in.markSupported()).thenReturn(true);
          
          // First read for initial signature check (12 bytes)
          when(in.read(any(byte[].class))).thenAnswer(inv -> {
              byte[] buf = (byte[]) inv.getArguments()[0];
              return buf.length; // return full length read
          });
          
          // Second read for dump signature (32 bytes)
          // Third read for TAR header (512 bytes)
          // Make sure reset() is called properly
          doNothing().when(in).reset();
          
          // Create malformed TAR data that will cause exception in TarArchiveInputStream
          byte[] malformedTar = new byte[512];
          // Put some non-TAR data that will cause exception during detection
          System.arraycopy("NOT_A_TAR_FILE".getBytes(), 0, malformedTar, 0, 13);
          
          ArchiveStreamFactory factory = new ArchiveStreamFactory();
          
          try {
              factory.createArchiveInputStream(in);
              fail("Expected ArchiveException to be thrown");
          } catch (ArchiveException e) {
              // Verify the exception message indicates no archiver was found
              assertEquals("No Archiver found for the stream signature", e.getMessage());
          }
          
          // Verify the mock interactions
          verify(in, atLeastOnce()).mark(anyInt());
          verify(in, atLeastOnce()).reset();
      }

 @Test
      public void testCreateArchiveInputStream_ExceptionMessage2() throws Exception {
          // Arrange
          ArchiveStreamFactory factory = new ArchiveStreamFactory();
          String archiverName = ArchiveStreamFactory.ZIP; // valid archiver name
          InputStream in = mock(InputStream.class);
          
          // Make the stream throw an IOException when used
          doThrow(new java.io.IOException("Test error")).when(in).read(any(byte[].class));
          
          // Set exception expectations
          thrown.expect(ArchiveException.class);
          thrown.expectMessage("Could not use reset and mark operations.");
          
          // Act
          factory.createArchiveInputStream(archiverName, in);
          
          // Assert - handled by ExpectedException rule
      }

 @Test(expected = ArchiveException.class)
  public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldThrowWithSpecificMessage1() throws Exception {
      // Arrange
      InputStream mockInputStream = mock(InputStream.class);
      when(mockInputStream.markSupported()).thenReturn(true);
      doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
      
      ArchiveStreamFactory factory = new ArchiveStreamFactory();
      
      // Act
      try {
          factory.createArchiveInputStream(mockInputStream);
      } catch (ArchiveException e) {
          // Assert
          assertEquals("Could not use reset and mark operations.", e.getMessage());
          throw e;
      }
  }

 @Test(expected = ArchiveException.class)
 public void testCreateArchiveInputStream_shouldThrowExceptionWithCorrectMessageWhenMarkResetFails() throws Exception {
     // Arrange
     String archiverName = ArchiveStreamFactory.ZIP; // any supported format
     InputStream in = mock(InputStream.class);
     
     // Simulate IOException on mark/reset
     doThrow(new IOException("mark/reset not supported")).when(in).mark(anyInt());
     
     // Act & Assert
     try {
         new ArchiveStreamFactory().createArchiveInputStream(archiverName, in);
         fail("Expected ArchiveException to be thrown");
     } catch (ArchiveException e) {
         // Verify the exception message contains the expected content
         assertTrue("Exception message should contain information about reset/mark operations",
                   e.getMessage().contains("Could not use reset and mark operations"));
         throw e;
     }
 }

 @Test(expected = ArchiveException.class)
 public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_ShouldThrowWithDescriptiveMessage() throws Exception {
     // Arrange
     InputStream mockInputStream = mock(InputStream.class);
     when(mockInputStream.markSupported()).thenReturn(true);
     doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
     
     ArchiveStreamFactory factory = new ArchiveStreamFactory();
     
     // Act & Assert
     try {
         factory.createArchiveInputStream(mockInputStream);
         fail("Expected ArchiveException to be thrown");
     } catch (ArchiveException e) {
         // Verify the exception message contains the expected description
         assertEquals("Could not use reset and mark operations.", e.getMessage());
         throw e;
     }
 }

}
