package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                        public void testEquals_Reflexive() {
                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                            assertTrue(entry.equals(entry));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_NullComparison() {
                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                            assertFalse(entry.equals(null));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_DifferentClass() {
                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                                                            Object obj = new Object();
                                                                                                                            assertFalse(entry.equals(obj));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_SameName() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                            assertTrue(entry1.equals(entry2));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_DifferentName() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.txt");
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.txt");
                                                                                                                            assertFalse(entry1.equals(entry2));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_CaseSensitiveNames() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("TEST.TXT");
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                            // Assuming name comparison is case-sensitive
                                                                                                                            assertFalse(entry1.equals(entry2));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_WithDifferentMethods() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                            entry1.setMethod(8); // DEFLATED
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                            entry2.setMethod(0); // STORED
                                                                                                                            // Method shouldn't affect equality
                                                                                                                            assertTrue(entry1.equals(entry2));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_Symmetry() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                            assertTrue(entry1.equals(entry2));
                                                                                                                            assertTrue(entry2.equals(entry1));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_Transitivity() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                            ZipArchiveEntry entry3 = new ZipArchiveEntry("test.txt");
                                                                                                                            assertTrue(entry1.equals(entry2));
                                                                                                                            assertTrue(entry2.equals(entry3));
                                                                                                                            assertTrue(entry1.equals(entry3));
                                                                                                                        }

    @Test
                                                                                                                        public void testEquals_Consistent() {
                                                                                                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                            for (int i = 0; i < 10; i++) {
                                                                                                                                assertTrue(entry1.equals(entry2));
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                public void testEquals_NullNameBoth() {
                                                                                                                    org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry1 = 
                                                                                                                        new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((String)null);
                                                                                                                    org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry2 = 
                                                                                                                        new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((String)null);
                                                                                                                    assertTrue(entry1.equals(entry2));
                                                                                                                }

    @Test
                                                                                                                public void testEquals_NullNameFirst() {
                                                                                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                    assertFalse(entry1.equals(entry2));
                                                                                                                }

    @Test
                                                                                                                public void testEquals_NullNameSecond() {
                                                                                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry((String)null);
                                                                                                                    assertFalse(entry1.equals(entry2));
                                                                                                                }

    @Test
                                                                                                                public void testEquals_WithDifferentPlatforms() throws Exception {
                                                                                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                    
                                                                                                                    // Use reflection to set platform since setPlatform is protected
                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                    setPlatformMethod.invoke(entry1, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                    setPlatformMethod.invoke(entry2, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                    
                                                                                                                    // Platform shouldn't affect equality
                                                                                                                    assertTrue(entry1.equals(entry2));
                                                                                                                }

    @Test
                                                                                                                public void testEquals_WithDifferentExtraFields() {
                                                                                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("test.txt");
                                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                                                                                    
                                                                                                                    // Using public methods to set extra fields
                                                                                                                    entry1.addExtraField(mock(ZipExtraField.class));
                                                                                                                    entry2.addExtraField(mock(ZipExtraField.class));
                                                                                                                    
                                                                                                                    // Extra fields shouldn't affect equality
                                                                                                                    assertTrue(entry1.equals(entry2));
                                                                                                                }

    @Test
                                                                                                            public void testEqualsWithSameObjectShouldReturnTrue() {
                                                                                                                // Create a ZipArchiveEntry object
                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                                                                                
                                                                                                                // Test equals with itself
                                                                                                                assertTrue("Comparing object with itself should return true", entry.equals(entry));
                                                                                                                
                                                                                                                // Additional verification that the name comparison didn't affect this case
                                                                                                                assertEquals("testEntry", entry.getName());
                                                                                                            }

    @Test
                                                                                                            public void testEqualsWithDifferentObjectsSameName() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("sameName");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("sameName");
                                                                                                                
                                                                                                                assertTrue("Objects with same name should be equal", entry1.equals(entry2));
                                                                                                            }

    @Test
                                                                                                            public void testEqualsWithDifferentObjectsDifferentName() {
                                                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("name1");
                                                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("name2");
                                                                                                                
                                                                                                                assertFalse("Objects with different names should not be equal", entry1.equals(entry2));
                                                                                                            }

    @Test
                                                                                                            public void testEqualsWithNull() {
                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                assertFalse("Comparing with null should return false", entry.equals(null));
                                                                                                            }

    @Test
                                                                                                            public void testEqualsWithDifferentClass() {
                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                Object obj = new Object();
                                                                                                                assertFalse("Comparing with different class should return false", entry.equals(obj));
                                                                                                            }

    @Test
                                                                                                          public void testEqualsWithNullNames() {
                                                                                                              // Create two entries with null names
                                                                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                                                                              
                                                                                                              // Set names to null through reflection since name is private
                                                                                                              try {
                                                                                                                  Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                                                  nameField.setAccessible(true);
                                                                                                                  nameField.set(entry1, null);
                                                                                                                  nameField.set(entry2, null);
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Failed to set name field through reflection");
                                                                                                              }
                                                                                                              
                                                                                                              // Should return true for two null names (original behavior)
                                                                                                              // Mutant will return false because it skips the null check
                                                                                                              assertTrue("Two entries with null names should be equal", entry1.equals(entry2));
                                                                                                              
                                                                                                              // Create entry with non-null name
                                                                                                              ZipArchiveEntry entry3 = new ZipArchiveEntry("test");
                                                                                                              
                                                                                                              // Test entry with null name vs non-null name
                                                                                                              assertFalse("Entry with null name should not equal non-null name", entry1.equals(entry3));
                                                                                                              
                                                                                                              // Test entry with non-null name vs null name
                                                                                                              assertFalse("Entry with non-null name should not equal null name", entry3.equals(entry1));
                                                                                                          }

    @Test
                                                                                                     public void testEqualsWhenFirstNameNullAndSecondNameNotNull() throws Exception {
                                                                                                         // Create two entries with dummy names first
                                                                                                         ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                                                                                                         ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                                                                                                         
                                                                                                         // Use reflection to access protected setName method
                                                                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                         setNameMethod.setAccessible(true);
                                                                                                         
                                                                                                         // Set names - one null, one not null
                                                                                                         setNameMethod.invoke(entry1, (String)null);
                                                                                                         setNameMethod.invoke(entry2, "someName");
                                                                                                         
                                                                                                         // Original should return false when one name is null and other isn't
                                                                                                         // Mutant would return true
                                                                                                         assertFalse("Entries with one null name and one non-null name should not be equal", 
                                                                                                                    entry1.equals(entry2));
                                                                                                         
                                                                                                         // Also test reverse case for completeness
                                                                                                         assertFalse("Entries with one null name and one non-null name should not be equal", 
                                                                                                                    entry2.equals(entry1));
                                                                                                     }

    @Test
                                                                                                public void testEqualsWhenCurrentNameIsNullAndOtherNameIsNotNull() {
                                                                                                    // Create two entries
                                                                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                                    
                                                                                                    // The original should return false since one name is null and other isn't
                                                                                                    // The mutant would return true because it skips the null check
                                                                                                    assertFalse("Should return false when current name is null and other name is not null", 
                                                                                                                entry1.equals(entry2));
                                                                                                }

    @Test
                                                                                           public void testEqualsWithOneNullName() throws Exception {
                                                                                               // Create two entries with empty names using public constructor
                                                                                               ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                               ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                                                               
                                                                                               // Use reflection to access protected setName method
                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                               setNameMethod.setAccessible(true);
                                                                                               
                                                                                               // Set one name to null explicitly, leave other as default (empty string)
                                                                                               setNameMethod.invoke(entry1, (String)null);
                                                                                               
                                                                                               // Original behavior: should return true (both names effectively null)
                                                                                               // Mutant behavior: will return false
                                                                                               assertTrue("Entries with both names null should be equal", 
                                                                                                          entry1.equals(entry2));
                                                                                               
                                                                                               // Also test reverse case
                                                                                               assertTrue("Entries with both names null should be equal (reverse)", 
                                                                                                          entry2.equals(entry1));
                                                                                           }

    @Test
                                                                                           public void testEqualsWithBothNullNames() throws Exception {
                                                                                               // Create two entries with names (we'll set them to null via reflection)
                                                                                               ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                               ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                                               
                                                                                               // Use reflection to access protected setName method
                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                               setNameMethod.setAccessible(true);
                                                                                               setNameMethod.invoke(entry1, (String)null);
                                                                                               setNameMethod.invoke(entry2, (String)null);
                                                                                               
                                                                                               assertTrue("Entries with both names explicitly null should be equal",
                                                                                                          entry1.equals(entry2));
                                                                                           }

    @Test
                                                                                           public void testEqualsWithNonNullAndNullNames() throws Exception {
                                                                                               // Create entries with one null and one non-null name
                                                                                               ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                               ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                                               
                                                                                               // Use reflection to set protected name fields
                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                               setNameMethod.setAccessible(true);
                                                                                               setNameMethod.invoke(entry1, (String)null);
                                                                                               setNameMethod.invoke(entry2, "test");
                                                                                               
                                                                                               assertFalse("Entry with null name should not equal entry with non-null name",
                                                                                                          entry1.equals(entry2));
                                                                                           }

    @Test
                                                                                      public void testEqualsWithOneNullName1() throws Exception {
                                                                                          // Create two entries with dummy names first
                                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                                                                                          
                                                                                          // Use reflection to access protected setName method
                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                          setNameMethod.setAccessible(true);
                                                                                          
                                                                                          // Set one name to null and other to non-null
                                                                                          setNameMethod.invoke(entry1, (String)null);
                                                                                          setNameMethod.invoke(entry2, "test.txt");
                                                                                          
                                                                                          // Verify equals returns false when one name is null and other isn't
                                                                                          assertFalse("Entries should not be equal when one name is null and other isn't", 
                                                                                                     entry1.equals(entry2));
                                                                                          assertFalse("Entries should not be equal when one name is null and other isn't (reverse)", 
                                                                                                     entry2.equals(entry1));
                                                                                          
                                                                                          // Additional verification: both null names should return true
                                                                                          setNameMethod.invoke(entry2, (String)null);
                                                                                          assertTrue("Entries should be equal when both names are null", 
                                                                                                    entry1.equals(entry2));
                                                                                      }

    @Test
                                                                                 public void testEqualsWhenBothNamesAreNull() {
                                                                                     // Create two entries with null names using public constructor
                                                                                     ZipArchiveEntry entry1 = new ZipArchiveEntry((String)null);
                                                                                     ZipArchiveEntry entry2 = new ZipArchiveEntry((String)null);
                                                                                     
                                                                                     // Verify they are considered equal
                                                                                     assertTrue(entry1.equals(entry2));
                                                                                     assertTrue(entry2.equals(entry1)); // Test symmetry
                                                                                     
                                                                                     // Verify equals is reflexive
                                                                                     assertTrue(entry1.equals(entry1));
                                                                                     
                                                                                     // Verify equals with null returns false
                                                                                     assertFalse(entry1.equals(null));
                                                                                 }

    @Test
                                                                                 public void testEqualsWithDifferentNonNullNames() {
                                                                                     // Create two entries with different non-null names
                                                                                     ZipArchiveEntry entry1 = new ZipArchiveEntry("name1");
                                                                                     ZipArchiveEntry entry2 = new ZipArchiveEntry("name2");
                                                                                     
                                                                                     // Should return false for both comparisons
                                                                                     assertFalse(entry1.equals(entry2));
                                                                                     assertFalse(entry2.equals(entry1));
                                                                                 }

    @Test
                                                                            public void testEqualsWithNullNameShouldNotThrowException() throws Exception {
                                                                                // Create entry with null name using reflection
                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                setNameMethod.setAccessible(true);
                                                                                setNameMethod.invoke(entry1, new Object[] { null });
                                                                                
                                                                                // Create entry with non-null name
                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                                
                                                                                // This should return false (not throw exception) in original code
                                                                                // Mutated version would throw NullPointerException
                                                                                assertFalse(entry1.equals(entry2));
                                                                                
                                                                                // Also test reverse comparison
                                                                                assertFalse(entry2.equals(entry1));
                                                                            }

    @Test
                                                                            public void testEqualsWithBothNullNames1() throws Exception {
                                                                                // Create two entries with dummy names first
                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                                                                                
                                                                                // Use reflection to set names to null
                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                setNameMethod.setAccessible(true);
                                                                                setNameMethod.invoke(entry1, (String)null);
                                                                                setNameMethod.invoke(entry2, (String)null);
                                                                                
                                                                                // Should return true for both comparisons
                                                                                assertTrue(entry1.equals(entry2));
                                                                                assertTrue(entry2.equals(entry1));
                                                                            }

    @Test
                                                                            public void testEqualsWithSameObject() {
                                                                                // Create a ZipArchiveEntry object
                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                                                
                                                                                // Compare the object with itself
                                                                                // This should return true immediately in original implementation
                                                                                // Mutated version will skip the self-reference check
                                                                                assertTrue("Object should be equal to itself", entry.equals(entry));
                                                                                
                                                                                // Also verify hashcode consistency
                                                                                assertEquals("Hashcode should be equal for same object", 
                                                                                            entry.hashCode(), entry.hashCode());
                                                                            }

    @Test
                                                                            public void testEqualsWithDifferentObjects() {
                                                                                // Create two different entries with same name
                                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("testEntry");
                                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("testEntry");
                                                                                
                                                                                // These should be considered equal
                                                                                assertTrue("Entries with same name should be equal", entry1.equals(entry2));
                                                                                
                                                                                // Create entries with different names
                                                                                ZipArchiveEntry entry3 = new ZipArchiveEntry("differentEntry");
                                                                                assertFalse("Entries with different names should not be equal", 
                                                                                           entry1.equals(entry3));
                                                                            }

    @Test
                                                                            public void testEqualsWithNull1() {
                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                                                assertFalse("Should return false when comparing with null", 
                                                                                           entry.equals(null));
                                                                            }

    @Test
                                                                            public void testEqualsWithDifferentClass1() {
                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                                                Object other = new Object();
                                                                                assertFalse("Should return false when comparing with different class", 
                                                                                           entry.equals(other));
                                                                            }

    @Test
                                                                      public void testEqualsWithNullNameShouldReturnFalseWhenOtherNameNotNull() throws Exception {
                                                                          // Create first entry with null name using reflection
                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                          setNameMethod.setAccessible(true);
                                                                          setNameMethod.invoke(entry1, (String)null);
                                                                          
                                                                          // Create second entry with non-null name
                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                          
                                                                          // Should return false when comparing null name with non-null name
                                                                          assertFalse(entry1.equals(entry2));
                                                                      }

    @Test
                                                                      public void testEqualsWithNonNullNameShouldReturnFalseWhenOtherNameNull() throws Exception {
                                                                          // Create first entry with non-null name using public constructor
                                                                          ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                                                                          
                                                                          // Create second entry with null name using reflection
                                                                          ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                          setNameMethod.setAccessible(true);
                                                                          setNameMethod.invoke(entry2, (String)null);
                                                                          
                                                                          // Should return false when comparing non-null name with null name
                                                                          assertFalse(entry1.equals(entry2));
                                                                      }

    @Test
                                                                 public void testEqualsWithNullNameAndNonNullNameShouldReturnFalse() {
                                                                     // Create first entry with non-null name (we'll set it to null via reflection)
                                                                     ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                     // Use reflection to set private name field to null since there's no setter
                                                                     try {
                                                                         Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                         nameField.setAccessible(true);
                                                                         nameField.set(entry1, null);
                                                                     } catch (Exception e) {
                                                                         fail("Failed to set name field via reflection");
                                                                     }
                                                                     
                                                                     // Create second entry with non-null name
                                                                     ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                     
                                                                     // Test equality in both directions
                                                                     assertFalse("Entry with null name should not equal entry with non-null name", 
                                                                                entry1.equals(entry2));
                                                                     assertFalse("Entry with non-null name should not equal entry with null name", 
                                                                                entry2.equals(entry1));
                                                                     
                                                                     // Also test against itself
                                                                     assertTrue("Entry should equal itself", entry1.equals(entry1));
                                                                     assertTrue("Entry should equal itself", entry2.equals(entry2));
                                                                 }

    @Test
                                                            public void testEqualsWithNullNameVsNonNullName() {
                                                                // Create first entry with non-null name (we'll set it to null via reflection)
                                                                ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                                // Use reflection to set private name field to null since setName() might prevent null
                                                                try {
                                                                    Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                    nameField.setAccessible(true);
                                                                    nameField.set(entry1, null);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set name field via reflection");
                                                                }
                                                                
                                                                // Create second entry with non-null name
                                                                ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                                                
                                                                // Original should return false when one name is null and other isn't
                                                                // Mutant would return true because it skips the null check
                                                                assertFalse("Should return false when comparing null name with non-null name", 
                                                                           entry1.equals(entry2));
                                                                
                                                                // Also test reverse case (though not directly related to this mutant)
                                                                assertFalse("Should return false when comparing non-null name with null name",
                                                                           entry2.equals(entry1));
                                                            }

    @Test
                                                       public void testEqualsWithNullAndNonNullNamesShouldReturnFalse() {
                                                           // Create two entries with dummy names that will be overwritten
                                                           ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                                                           ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                                                           
                                                           // Set entry1's name to null (protected method needs reflection)
                                                           try {
                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                               setNameMethod.setAccessible(true);
                                                               setNameMethod.invoke(entry1, (String)null);
                                                               setNameMethod.invoke(entry2, "non-null-name");
                                                           } catch (Exception e) {
                                                               fail("Failed to set name via reflection");
                                                           }
                                                           
                                                           // Test equality in both directions
                                                           assertFalse("Entries with null and non-null names should not be equal", 
                                                                       entry1.equals(entry2));
                                                           assertFalse("Entries with null and non-null names should not be equal (reverse)", 
                                                                       entry2.equals(entry1));
                                                           
                                                           // Also test case where both names are null
                                                           try {
                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                               setNameMethod.setAccessible(true);
                                                               setNameMethod.invoke(entry2, (String)null);
                                                           } catch (Exception e) {
                                                               fail("Failed to set name via reflection");
                                                           }
                                                           assertTrue("Entries with both names null should be equal", 
                                                                      entry1.equals(entry2));
                                                       }

    @Test
                                                  public void testEqualsWhenFirstNameIsNullAndSecondIsNotNull() {
                                                      // Create first entry with a dummy name (we'll set it to null via reflection)
                                                      ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                                      // Use reflection to set the private name field to null since there's no setter
                                                      try {
                                                          java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                          nameField.setAccessible(true);
                                                          nameField.set(entry1, null);
                                                      } catch (Exception e) {
                                                          fail("Failed to set name field via reflection");
                                                      }
                                                  
                                                      // Create second entry with non-null name
                                                      ZipArchiveEntry entry2 = new ZipArchiveEntry("test.txt");
                                                  
                                                      // The original code would return false here (via !false)
                                                      // The mutant would return true directly
                                                      // Both are logically correct, but we want to test the specific implementation
                                                      assertFalse("Entries should not be equal when one name is null and other isn't", 
                                                                 entry1.equals(entry2));
                                                      
                                                      // Also test the reverse case
                                                      assertFalse("Entries should not be equal when one name is null and other isn't", 
                                                                 entry2.equals(entry1));
                                                  }

    @Test
                                             public void testEqualsWithBothNullNamesShouldReturnTrue() {
                                                 // Create two entries with dummy names (we'll set them to null via reflection)
                                                 ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
                                                 ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
                                                 
                                                 // Set names to null using reflection since setName is protected
                                                 try {
                                                     Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                     nameField.setAccessible(true);
                                                     nameField.set(entry1, null);
                                                     nameField.set(entry2, null);
                                                 } catch (Exception e) {
                                                     fail("Failed to set name field via reflection");
                                                 }
                                                 
                                                 // Test equality in both directions
                                                 assertTrue("Entries with null names should be equal", entry1.equals(entry2));
                                                 assertTrue("Equals should be symmetric", entry2.equals(entry1));
                                                 
                                                 // Also test hashcode consistency
                                                 assertEquals("Equal objects must have equal hashcodes", 
                                                              entry1.hashCode(), entry2.hashCode());
                                             }

    @Test
                                        public void testEqualsWithNullNameShouldThrowWhenOriginalNull() throws Exception {
                                            // Create two entries with different name scenarios
                                            ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy"); // Use public constructor
                                            // Use reflection to set name to null
                                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                            setNameMethod.setAccessible(true);
                                            setNameMethod.invoke(entry1, new Object[] { null });  // myName will be null
                                            
                                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");  // otherName will be "test"
                                            
                                            // Expected behavior - original should throw NPE when myName is null
                                            try {
                                                entry1.equals(entry2);
                                                fail("Expected NullPointerException when comparing with null name");
                                            } catch (NullPointerException e) {
                                                // This is expected behavior for original code
                                            }
                                            
                                            // The mutant would reach here and return false instead of throwing
                                            // So this test would fail for the mutant version
                                        }

    @Test
                                    public void testEquals_SameObject_ShouldReturnTrue() {
                                        // Arrange
                                        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                        
                                        // Act & Assert
                                        assertTrue("Comparing an object with itself should return true", 
                                                   entry.equals(entry));
                                    }

    @Test
                                    public void testEquals_SameObject_ShouldReturnTrueImmediately() {
                                        // Arrange
                                        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry") {
                                            @Override
                                            public String getName() {
                                                fail("getName() should not be called when comparing with itself");
                                                return super.getName();
                                            }
                                        };
                                        
                                        // Act & Assert
                                        assertTrue(entry.equals(entry));
                                    }

    @Test
                                  public void testEqualsWithNullName() {
                                      // Create first entry with null name
                                      ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                                      // Use reflection to set private name field to null since setName() might prevent null
                                      try {
                                          java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                          nameField.setAccessible(true);
                                          nameField.set(entry1, null);
                                      } catch (Exception e) {
                                          fail("Failed to set name field to null via reflection");
                                      }
                                      
                                      // Create second entry with non-null name
                                      ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                      
                                      // This should return false since one name is null and other isn't
                                      // The mutant would skip this check and potentially return true
                                      assertFalse(entry1.equals(entry2));
                                      
                                      // Also test case where both have null names
                                      ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
                                      try {
                                          java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                          nameField.setAccessible(true);
                                          nameField.set(entry3, null);
                                      } catch (Exception e) {
                                          fail("Failed to set name field to null via reflection");
                                      }
                                      assertTrue(entry1.equals(entry3));
                                  }

    @Test
                             public void testEqualsWithNullNames1() throws Exception {
                                 // Create entries with different name scenarios
                                 ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                 // Use reflection to set name to null
                                 Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                 setName.setAccessible(true);
                                 setName.invoke(entry1, new Object[] { null });
                                 
                                 // Case 1: otherName is not null - should return false
                                 ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                                 assertFalse("Entries with null vs non-null names should not be equal", 
                                            entry1.equals(entry2));
                                 
                                 // Case 2: otherName is null - should return true
                                 ZipArchiveEntry entry3 = new ZipArchiveEntry("");
                                 setName.invoke(entry3, new Object[] { null });
                                 assertTrue("Entries with both null names should be equal",
                                           entry1.equals(entry3));
                                 
                                 // Additional test for original equals contract
                                 assertTrue("Equals should be reflexive", entry1.equals(entry1));
                                 assertFalse("Equals with null should return false", entry1.equals(null));
                                 assertFalse("Equals with different class should return false", 
                                            entry1.equals(new Object()));
                             }

    @Test
                        public void testEqualsWhenThisNameIsNullAndOtherNameIsNotNull() {
                            // Create first entry with non-null name (we'll set it to null via reflection)
                            ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                            // Use reflection to set private name field to null since setName() might prevent null
                            try {
                                Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                nameField.setAccessible(true);
                                nameField.set(entry1, null);
                            } catch (Exception e) {
                                fail("Failed to set name field via reflection");
                            }
                            
                            // Create second entry with non-null name
                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                            
                            // The original code returns true for this case (which seems incorrect)
                            // The mutant would also return true
                            // This test verifies this specific case is handled (though the behavior seems wrong)
                            assertTrue(entry1.equals(entry2));
                            
                            // Note: The correct behavior should probably be to return false in this case,
                            // suggesting the original code has a bug where it returns !false (true) instead of false
                        }

    @Test
                        public void testEqualsWhenNamesAreEqual() {
                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                            
                            assertTrue("Entries should be equal when names are equal", 
                                      entry1.equals(entry2));
                        }

    @Test
                        public void testEqualsWhenNamesAreDifferent() {
                            ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                            ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                            
                            assertFalse("Entries should not be equal when names are different", 
                                       entry1.equals(entry2));
                        }

    @Test
                   public void testEqualsWhenThisNameIsNullAndOtherNameIsNotNull1() {
                       // Create two entries - use the public constructor that takes a name
                       ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                       
                       // Set entry1's name to null (using reflection since name is private)
                       try {
                           java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                           nameField.setAccessible(true);
                           nameField.set(entry1, null);
                       } catch (Exception e) {
                           fail("Failed to set name field via reflection");
                       }
                       
                       // Original behavior: should return true when this.name is null and other.name is not null
                       // Mutant behavior: will return false
                       assertTrue("Entries should be equal when this.name is null and other.name is not null", 
                                 entry1.equals(entry2));
                   }

    @Test
                   public void testEqualsWhenBothNamesAreNull1() {
                       ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                       ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                       
                       try {
                           java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                           nameField.setAccessible(true);
                           nameField.set(entry1, null);
                           nameField.set(entry2, null);
                       } catch (Exception e) {
                           fail("Failed to set name field via reflection");
                       }
                       
                       assertTrue("Entries should be equal when both names are null", 
                                 entry1.equals(entry2));
                   }

    @Test
                   public void testEqualsWithSameNames() {
                       // Create two entries with same names
                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                       
                       // Should return true when names are equal
                       assertTrue(entry1.equals(entry2));
                   }

    @Test
                   public void testEqualsWithDifferentNames() {
                       // Create two entries with different names
                       ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
                       ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
                       
                       // Should return false when names are different
                       assertFalse(entry1.equals(entry2));
                   }

    @Test
              public void testEqualsWithNullNameAndNonNullName() {
                  // Create first entry with dummy name then set to null via reflection
                  ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                  try {
                      java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                      nameField.setAccessible(true);
                      nameField.set(entry1, null);
                  } catch (Exception e) {
                      fail("Failed to set name field via reflection");
                  }
                  
                  // Create second entry with non-null name
                  ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
                  
                  // Original behavior should return false when one name is null and other isn't
                  assertFalse(entry1.equals(entry2));
                  
                  // Also test reverse case
                  assertFalse(entry2.equals(entry1));
              }

    @Test
              public void testEqualsWithBothNullNames2() {
                  // Create two entries with non-null names first
                  ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
                  ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                  try {
                      // Set both names to null via reflection
                      java.lang.reflect.Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                      nameField.setAccessible(true);
                      nameField.set(entry1, null);
                      nameField.set(entry2, null);
                  } catch (Exception e) {
                      fail("Failed to set name field via reflection");
                  }
                  
                  // Should return true when both names are null
                  assertTrue(entry1.equals(entry2));
              }

    @Test
         public void testEqualsWithNullNames2() {
             // Create two entries with dummy names (using public constructor)
             ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy1");
             ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy2");
             
             // Declare nameField outside try block
             java.lang.reflect.Field nameField = null;
             try {
                 nameField = ZipArchiveEntry.class.getDeclaredField("name");
                 nameField.setAccessible(true);
                 nameField.set(entry1, null);
                 nameField.set(entry2, null);
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
             
             // Test equality - should be true for original, would pass with mutant too
             assertTrue(entry1.equals(entry2));
             
             // Additional test cases for completeness
             // Case 1: One null name, one non-null
             try {
                 nameField.set(entry1, "test");
                 assertFalse(entry1.equals(entry2));
                 assertFalse(entry2.equals(entry1));
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
             
             // Case 2: Different non-null names
             try {
                 nameField.set(entry2, "different");
                 assertFalse(entry1.equals(entry2));
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
             
             // Case 3: Same non-null names
             try {
                 nameField.set(entry1, "same");
                 nameField.set(entry2, "same");
                 assertTrue(entry1.equals(entry2));
             } catch (Exception e) {
                 fail("Failed to set name field via reflection");
             }
         }

    @Test
    public void testEqualsWithNullNameShouldNotThrowNPE() throws Exception {
        // Create two entries with different name scenarios
        ZipArchiveEntry entry1 = new ZipArchiveEntry("dummy");
        // Use reflection to set name to null
        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
        setNameMethod.setAccessible(true);
        setNameMethod.invoke(entry1, (String)null);
        
        ZipArchiveEntry entry2 = new ZipArchiveEntry("non-null-name");
        
        // Test equals in both directions
        assertFalse("Entry with null name should not equal non-null name", 
                   entry1.equals(entry2));
        assertFalse("Entry with non-null name should not equal null name", 
                   entry2.equals(entry1));
        
        // Also test case where both names are null
        ZipArchiveEntry entry3 = new ZipArchiveEntry("dummy");
        setNameMethod.invoke(entry3, (String)null);
        assertTrue("Two entries with null names should be equal", 
                  entry1.equals(entry3));
    }


}
