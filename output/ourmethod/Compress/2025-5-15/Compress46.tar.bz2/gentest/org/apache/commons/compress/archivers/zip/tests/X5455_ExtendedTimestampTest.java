package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.Serializable;
import java.util.Date;
import java.util.zip.ZipException;
 
public class X5455_ExtendedTimestampTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                       public void testUnixTimeToZipLong_ValidPositiveValue() throws Exception {
                                                                           long input = 1234567890L;
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           ZipLong result = (ZipLong) method.invoke(null, input);
                                                                           assertNotNull(result);
                                                                           assertEquals(input, result.getValue());
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_ValidNegativeValue() throws Exception {
                                                                           long input = -1234567890L;
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           ZipLong result = (ZipLong) method.invoke(null, input);
                                                                           assertNotNull(result);
                                                                           assertEquals(input, result.getValue());
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_ZeroValue() throws Exception {
                                                                           long input = 0L;
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           ZipLong result = (ZipLong) method.invoke(null, input);
                                                                           assertNotNull(result);
                                                                           assertEquals(input, result.getValue());
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_Max32BitValue() throws Exception {
                                                                           long input = Integer.MAX_VALUE;
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           ZipLong result = (ZipLong) method.invoke(null, input);
                                                                           assertNotNull(result);
                                                                           assertEquals(input, result.getValue());
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_Min32BitValue() throws Exception {
                                                                           long input = Integer.MIN_VALUE;
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           ZipLong result = (ZipLong) method.invoke(null, input);
                                                                           assertNotNull(result);
                                                                           assertEquals(input, result.getValue());
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_AboveMax32BitValue() throws Exception {
                                                                           long input = (long)Integer.MAX_VALUE + 1;
                                                                           thrown.expect(IllegalArgumentException.class);
                                                                           thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                                           
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           method.invoke(null, input);
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_BelowMin32BitValue() throws Exception {
                                                                           long input = (long)Integer.MIN_VALUE - 1;
                                                                           thrown.expect(IllegalArgumentException.class);
                                                                           thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                                           
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           method.invoke(null, input);
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_LargePositiveOutOfRange() throws Exception {
                                                                           long input = Long.MAX_VALUE;
                                                                           thrown.expect(IllegalArgumentException.class);
                                                                           thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                                           
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           method.invoke(null, input);
                                                                       }

    @Test
                                                                       public void testUnixTimeToZipLong_LargeNegativeOutOfRange() throws Exception {
                                                                           long input = Long.MIN_VALUE;
                                                                           thrown.expect(IllegalArgumentException.class);
                                                                           thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                                           
                                                                           Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                           method.setAccessible(true);
                                                                           method.invoke(null, input);
                                                                       }

    @Test
                                                                  public void testUnixTimeToZipLong_ValidValue() throws Exception {
                                                                      long validValue = 1234567890L; // Within 32-bit range
                                                                      
                                                                      // Get the private method using reflection
                                                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                      method.setAccessible(true);
                                                                      
                                                                      // Invoke the method
                                                                      ZipLong result = (ZipLong) method.invoke(null, validValue);
                                                                      
                                                                      assertNotNull(result);
                                                                      assertEquals(validValue, result.getValue());
                                                                  }

    @Test
                                                                  public void testUnixTimeToZipLong_ValueTooSmall() throws Exception {
                                                                      long tooSmall = (long)Integer.MIN_VALUE - 1L;
                                                                      thrown.expect(IllegalArgumentException.class);
                                                                      thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + tooSmall);
                                                                      
                                                                      // Use reflection to access the private method
                                                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                      method.setAccessible(true);
                                                                      method.invoke(null, tooSmall);
                                                                  }

    @Test
                                                                  public void testUnixTimeToZipLong_ValueTooLarge() throws Exception {
                                                                      long tooLarge = (long)Integer.MAX_VALUE + 1L;
                                                                      thrown.expect(IllegalArgumentException.class);
                                                                      thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + tooLarge);
                                                                      
                                                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                      method.setAccessible(true);
                                                                      method.invoke(null, tooLarge);
                                                                  }

    @Test
                                                                  public void testUnixTimeToZipLong_BoundaryMinValue() throws Exception {
                                                                      long minValue = Integer.MIN_VALUE;
                                                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                      method.setAccessible(true);
                                                                      ZipLong result = (ZipLong) method.invoke(null, minValue);
                                                                      assertNotNull(result);
                                                                      assertEquals(minValue, result.getValue());
                                                                  }

    @Test
                                                                  public void testUnixTimeToZipLong_BoundaryMaxValue() throws Exception {
                                                                      long maxValue = Integer.MAX_VALUE;
                                                                      Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                      method.setAccessible(true);
                                                                      ZipLong result = (ZipLong) method.invoke(null, maxValue);
                                                                      assertNotNull(result);
                                                                      assertEquals(maxValue, result.getValue());
                                                                  }

    @Test
                                                             public void testUnixTimeToZipLong_ValidRange() throws Exception {
                                                                 // Get the private method using reflection
                                                                 Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                 unixTimeToZipLong.setAccessible(true);
                                                                 
                                                                 // Test with minimum valid value
                                                                 ZipLong result1 = (ZipLong) unixTimeToZipLong.invoke(null, Integer.MIN_VALUE);
                                                                 assertNotNull(result1);
                                                                 assertEquals(Integer.MIN_VALUE, result1.getValue());
                                                                 
                                                                 // Test with maximum valid value
                                                                 ZipLong result2 = (ZipLong) unixTimeToZipLong.invoke(null, Integer.MAX_VALUE);
                                                                 assertNotNull(result2);
                                                                 assertEquals(Integer.MAX_VALUE, result2.getValue());
                                                                 
                                                                 // Test with zero
                                                                 ZipLong result3 = (ZipLong) unixTimeToZipLong.invoke(null, 0);
                                                                 assertNotNull(result3);
                                                                 assertEquals(0, result3.getValue());
                                                             }

    @Test
                                                             public void testUnixTimeToZipLong_BelowMinValue() throws Exception {
                                                                 Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                 method.setAccessible(true);
                                                                 
                                                                 long testValue = (long)Integer.MIN_VALUE - 1;
                                                                 String expectedMessage = "X5455 timestamps must fit in a signed 32 bit integer: " + testValue;
                                                                 
                                                                 try {
                                                                     method.invoke(null, testValue);
                                                                     fail("Expected IllegalArgumentException");
                                                                 } catch (InvocationTargetException e) {
                                                                     assertEquals(IllegalArgumentException.class, e.getCause().getClass());
                                                                     assertEquals(expectedMessage, e.getCause().getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testUnixTimeToZipLong_AboveMaxValue() throws Exception {
                                                                 Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                 method.setAccessible(true);
                                                                 
                                                                 try {
                                                                     method.invoke(null, (long)Integer.MAX_VALUE + 1);
                                                                     fail("Expected IllegalArgumentException");
                                                                 } catch (InvocationTargetException e) {
                                                                     assertEquals(IllegalArgumentException.class, e.getCause().getClass());
                                                                     assertEquals("X5455 timestamps must fit in a signed 32 bit integer: " + ((long)Integer.MAX_VALUE + 1), 
                                                                                e.getCause().getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testUnixTimeToZipLong_ExtremeValues() throws Exception {
                                                                 // Get the private method using reflection
                                                                 Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                                 unixTimeToZipLong.setAccessible(true);
                                                                 
                                                                 // Test with Long.MIN_VALUE
                                                                 thrown.expect(IllegalArgumentException.class);
                                                                 thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + Long.MIN_VALUE);
                                                                 unixTimeToZipLong.invoke(null, Long.MIN_VALUE);
                                                                 
                                                                 // Test with Long.MAX_VALUE
                                                                 thrown.expect(IllegalArgumentException.class);
                                                                 thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + Long.MAX_VALUE);
                                                                 unixTimeToZipLong.invoke(null, Long.MAX_VALUE);
                                                             }

    @Test
                                                        public void testUnixTimeToZipLong_ValidRange1() throws Exception {
                                                            // Get the private method using reflection
                                                            Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                            unixTimeToZipLong.setAccessible(true);
                                                            
                                                            // Test with minimum valid value
                                                            ZipLong result = (ZipLong) unixTimeToZipLong.invoke(null, (long)Integer.MIN_VALUE);
                                                            assertEquals(Integer.MIN_VALUE, result.getValue());
                                                            
                                                            // Test with maximum valid value
                                                            result = (ZipLong) unixTimeToZipLong.invoke(null, (long)Integer.MAX_VALUE);
                                                            assertEquals(Integer.MAX_VALUE, result.getValue());
                                                            
                                                            // Test with zero
                                                            result = (ZipLong) unixTimeToZipLong.invoke(null, 0L);
                                                            assertEquals(0, result.getValue());
                                                        }

    @Test
                                                        public void testUnixTimeToZipLong_BelowMinValue1() throws Exception {
                                                            long invalidValue = (long)Integer.MIN_VALUE - 1;
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + invalidValue);
                                                            
                                                            // Use reflection to access the private method
                                                            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                            method.setAccessible(true);
                                                            method.invoke(null, invalidValue);
                                                        }

    @Test
                                                        public void testUnixTimeToZipLong_AboveMaxValue1() throws Exception {
                                                            long invalidValue = (long)Integer.MAX_VALUE + 1;
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + invalidValue);
                                                            
                                                            Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                            method.setAccessible(true);
                                                            method.invoke(null, invalidValue);
                                                        }

    @Test
                                                   public void testUnixTimeToZipLong_throwsCorrectExceptionMessage() throws Exception {
                                                       // Get the private method using reflection
                                                       Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                                           "unixTimeToZipLong", long.class);
                                                       unixTimeToZipLong.setAccessible(true);
                                                       
                                                       // Test with value below Integer.MIN_VALUE
                                                       try {
                                                           unixTimeToZipLong.invoke(null, (long)Integer.MIN_VALUE - 1L);
                                                           fail("Expected IllegalArgumentException");
                                                       } catch (InvocationTargetException e) {
                                                           Throwable cause = e.getCause();
                                                           assertTrue(cause instanceof IllegalArgumentException);
                                                           assertEquals("X5455 timestamps must fit in a signed 32 bit integer: " + ((long)Integer.MIN_VALUE - 1L), 
                                                                       cause.getMessage());
                                                       }
                                                       
                                                       // Test with value above Integer.MAX_VALUE
                                                       try {
                                                           unixTimeToZipLong.invoke(null, (long)Integer.MAX_VALUE + 1L);
                                                           fail("Expected IllegalArgumentException");
                                                       } catch (InvocationTargetException e) {
                                                           Throwable cause = e.getCause();
                                                           assertTrue(cause instanceof IllegalArgumentException);
                                                           assertEquals("X5455 timestamps must fit in a signed 32 bit integer: " + ((long)Integer.MAX_VALUE + 1L), 
                                                                       cause.getMessage());
                                                       }
                                                   }

    @Test
                                              public void testUnixTimeToZipLong_ThrowsExceptionWhenValueTooLarge() throws Exception {
                                                  // Arrange
                                                  long input = (long)Integer.MAX_VALUE + 1;
                                                  Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                  method.setAccessible(true);
                                                  
                                                  // Assert exception
                                                  ExpectedException thrown = ExpectedException.none();
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                  
                                                  // Act
                                                  method.invoke(null, input);
                                              }

    @Test
                                              public void testUnixTimeToZipLong_ThrowsExceptionWhenValueTooSmall() throws Exception {
                                                  // Arrange
                                                  long input = (long)Integer.MIN_VALUE - 1;
                                                  ExpectedException thrown = ExpectedException.none();
                                                  
                                                  // Get the private method using reflection
                                                  Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                                  method.setAccessible(true);
                                                  
                                                  // Assert exception
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("X5455 timestamps must fit in a signed 32 bit integer: " + input);
                                                  
                                                  // Act
                                                  method.invoke(null, input);
                                              }

    @Test
                                              public void testUnixTimeToZipLong_ReturnsZipLongForValidInput() throws Exception {
                                                  // Arrange
                                                  long input = 123456789L;
                                                  
                                                  // Get the private method using reflection
                                                  Method unixTimeToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                                      "unixTimeToZipLong", long.class);
                                                  unixTimeToZipLongMethod.setAccessible(true);
                                                  
                                                  // Act
                                                  ZipLong result = (ZipLong) unixTimeToZipLongMethod.invoke(null, input);
                                                  
                                                  // Assert
                                                  assertNotNull(result);
                                                  assertEquals(input, result.getValue());
                                              }

    @Test
                                              public void testUnixTimeToZipLong_HandlesBoundaryValues() throws Exception {
                                                  // Get the private method using reflection
                                                  Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                                      "unixTimeToZipLong", long.class);
                                                  unixTimeToZipLong.setAccessible(true);
                                                  
                                                  // Test minimum valid value
                                                  ZipLong minResult = (ZipLong) unixTimeToZipLong.invoke(
                                                      null, (long)Integer.MIN_VALUE);
                                                  assertEquals(Integer.MIN_VALUE, minResult.getValue());
                                                  
                                                  // Test maximum valid value
                                                  ZipLong maxResult = (ZipLong) unixTimeToZipLong.invoke(
                                                      null, (long)Integer.MAX_VALUE);
                                                  assertEquals(Integer.MAX_VALUE, maxResult.getValue());
                                              }

    @Test(expected = IllegalArgumentException.class)
                                         public void testUnixTimeToZipLong_TooLargeValue() throws Exception {
                                             // This value is larger than Integer.MAX_VALUE but within long range
                                             long input = (long)Integer.MAX_VALUE + 1;
                                             
                                             // Use reflection to access the private method
                                             Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                             method.setAccessible(true);
                                             method.invoke(null, input);
                                         }

    @Test(expected = IllegalArgumentException.class)
                                         public void testUnixTimeToZipLong_TooSmallValue() throws Exception {
                                             // This value is smaller than Integer.MIN_VALUE but within long range
                                             long input = (long)Integer.MIN_VALUE - 1;
                                             
                                             // Use reflection to access the private method
                                             Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                             method.setAccessible(true);
                                             method.invoke(null, input);
                                         }

    @Test
                                         public void testUnixTimeToZipLong_ValidValue1() throws Exception {
                                             // Get the private method using reflection
                                             Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
                                             unixTimeToZipLong.setAccessible(true);
                                             
                                             // Test with max 32-bit value
                                             long input = Integer.MAX_VALUE;
                                             ZipLong result = (ZipLong) unixTimeToZipLong.invoke(null, input);
                                             assertEquals(input, result.getValue());
                                             
                                             // Test with min 32-bit value
                                             input = Integer.MIN_VALUE;
                                             result = (ZipLong) unixTimeToZipLong.invoke(null, input);
                                             assertEquals(input, result.getValue());
                                             
                                             // Test with zero
                                             input = 0;
                                             result = (ZipLong) unixTimeToZipLong.invoke(null, input);
                                             assertEquals(input, result.getValue());
                                         }

    @Test
                                    public void testDateToZipLongWithNullInput() throws Exception {
                                        // Test that null input returns null
                                        X5455_ExtendedTimestamp timestamp = new X5455_ExtendedTimestamp();
                                        
                                        // Get the private method using reflection
                                        Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                        dateToZipLongMethod.setAccessible(true);
                                        
                                        // Invoke the method with null input
                                        ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, (Date)null);
                                        
                                        assertNull("Null input should return null", result);
                                    }

    @Test
                                    public void testDateToZipLongWithNonNullInput() throws Exception {
                                        // Test that non-null input returns a ZipLong
                                        X5455_ExtendedTimestamp timestamp = new X5455_ExtendedTimestamp();
                                        Date testDate = new Date(); // Current time
                                        
                                        // Use reflection to access private method
                                        Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                            "dateToZipLong", Date.class);
                                        dateToZipLongMethod.setAccessible(true);
                                        ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                                        
                                        // We can't know the exact expected value since it depends on current time,
                                        // but we can verify it's not null and is a ZipLong instance
                                        assertNotNull("Non-null input should not return null", result);
                                        assertTrue("Result should be a ZipLong", result instanceof ZipLong);
                                        
                                        // Additionally, we can verify the value is roughly correct (within last hour)
                                        long expectedSeconds = testDate.getTime() / 1000;
                                        long actualSeconds = result.getValue(); // Assuming ZipLong.getValue() exists
                                        assertTrue("Time should be roughly correct", 
                                            Math.abs(expectedSeconds - actualSeconds) < 3600); // Within 1 hour
                                    }

    @Test
                               public void testDateToZipLong_DetectsDivisionToMultiplicationMutant() throws Exception {
                                   // Create a fixed date for testing (e.g., 2023-01-01 00:00:00 UTC)
                                   long testTimeMillis = 1672531200000L; // Known timestamp in milliseconds
                                   Date testDate = new Date(testTimeMillis);
                                   
                                   // Expected value is time in seconds (millis / 1000)
                                   long expectedSeconds = testTimeMillis / 1000;
                                   
                                   // Use reflection to access the private method
                                   Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                   dateToZipLongMethod.setAccessible(true);
                                   
                                   // Call the method
                                   ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                                   
                                   // Verify the result is not null
                                   assertNotNull(result);
                                   
                                   // Get the actual value from the ZipLong (assuming getValue() exists)
                                   long actualValue = result.getValue();
                                   
                                   // Assert the value matches expected seconds
                                   assertEquals("The converted time should be in seconds", 
                                                expectedSeconds, actualValue);
                                   
                                   // Additional assertion to specifically catch the mutant
                                   // The mutant would produce a value that's 1000 times larger than expected
                                   assertTrue("Should not be 1000 times larger than expected",
                                              actualValue < expectedSeconds * 1000);
                               }

    @Test
                           public void testDateToZipLong_ConvertsMillisecondsToSeconds() {
                               // Create a fixed date for testing (2023-01-01 00:00:00 UTC)
                               Date testDate = new Date(1672531200000L); // 1672531200000 ms since epoch
                               
                               // Mock the unixTimeToZipLong to just return the input as ZipLong for testing
                               // (Assuming we can mock static methods here - if not, we'd need to test the actual output)
                               X5455_ExtendedTimestamp instance = new X5455_ExtendedTimestamp();
                               
                               // Expected behavior: converts ms to s (divide by 1000)
                               long expectedUnixTime = 1672531200L; // 1672531200000 / 1000
                               
                               // Actual call - we need to verify either:
                               // 1) The value passed to unixTimeToZipLong is divided by 1000 (if we can mock/spy)
                               // 2) Or test the final output against known correct value
                               
                               // Since we can't easily test private methods directly, we'll test through a public method
                               // that uses dateToZipLong. Looking at the class, setModifyJavaTime uses dateToZipLong.
                               instance.setModifyJavaTime(testDate);
                               ZipLong result = instance.getModifyTime();
                               
                               // Verify the result is based on seconds, not milliseconds
                               // The exact ZipLong value depends on unixTimeToZipLong implementation,
                               // but we know it should be based on the seconds value (1672531200)
                               // rather than milliseconds (1672531200000)
                               assertNotNull(result);
                               
                               // If we can access the long value in ZipLong (assuming getValue() exists):
                               long resultValue = result.getValue();
                               assertTrue("Result should be based on seconds (much smaller value)", 
                                         resultValue < 1672531200000L);
                               
                               // More precise test - should equal the seconds value (implementation dependent)
                               assertEquals(expectedUnixTime, resultValue);
                           }

    @Test
                           public void testDateToZipLong_DividesBy() throws Exception {
                               // Use reflection to test private method directly
                               Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod(
                                   "dateToZipLong", Date.class);
                               method.setAccessible(true);
                               
                               Date testDate = new Date(100000L); // 100 seconds
                               
                               // Call original - should return value based on 100 (100000/1000)
                               ZipLong result = (ZipLong) method.invoke(null, testDate);
                               
                               // If the mutation survives, result would be based on 100000
                               // Original would be based on 100
                               assertEquals(100L, result.getValue());
                               
                               // Or test that result is not 100000 (mutant value)
                               assertNotEquals(100000L, result.getValue());
                           }

    @Test
                         public void testDateToZipLongWithNullInput1() {
                             // Test that method properly handles null input by returning null
                             // This will catch the mutant that changed the null check to 'if (false)'
                             Date nullDate = null;
                             
                             try {
                                 // Get the private method using reflection
                                 Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                                 dateToZipLongMethod.setAccessible(true);
                                 
                                 // Invoke the method on null instance since it's static
                                 ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, nullDate);
                                 assertNull("Method should return null for null input", result);
                             } catch (NullPointerException e) {
                                 fail("Method threw NullPointerException instead of returning null for null input");
                             } catch (Exception e) {
                                 fail("Unexpected exception occurred: " + e.getMessage());
                             }
                         }

    @Test
                    public void testDateToZipLongDetectsDivisionToAdditionMutant() throws Exception {
                        // Create a fixed date for testing (e.g., 2023-01-01 00:00:00 UTC)
                        long testTime = 1672531200000L; // Known timestamp in milliseconds
                        Date testDate = new Date(testTime);
                        
                        // Expected value: timestamp in seconds (original behavior)
                        long expectedUnixTime = testTime / 1000;
                        // Mutated behavior would produce: testTime + 1000
                        
                        // Use reflection to access the private method
                        Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                        dateToZipLongMethod.setAccessible(true);
                        
                        // Call the method
                        ZipLong result = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                        
                        // Verify the result matches expected Unix time conversion
                        // This will fail if the mutant is present (division replaced with addition)
                        assertEquals(expectedUnixTime, result.getValue());
                        
                        // Additional verification - check that it's not the mutated value
                        assertNotEquals(testTime + 1000, result.getValue());
                        
                        // Also test null input case
                        ZipLong nullResult = (ZipLong) dateToZipLongMethod.invoke(null, (Date) null);
                        assertNull(nullResult);
                    }

    @Test
                public void testDateToZipLong_DetectsDivisionMutation() throws Exception {
                    // Create a fixed date (January 1, 1970 00:00:01 GMT - 1000ms since epoch)
                    Date testDate = new Date(1000L);
                    
                    // Use reflection to access the private method
                    Method method = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                    method.setAccessible(true);
                    
                    // Expected: 1000ms / 1000 = 1 second
                    // Mutated would produce: 1000ms / 2000 = 0.5 seconds (truncated to 0)
                    ZipLong result = (ZipLong) method.invoke(null, testDate);
                    
                    // Verify the conversion is correct (1 second)
                    // This will fail if the mutant is present (would get 0 instead)
                    assertEquals(1L, result.getValue());
                    
                    // Additional test with 3000ms to ensure detection
                    testDate = new Date(3000L);
                    result = (ZipLong) method.invoke(null, testDate);
                    // Expected: 3 (3000/1000), Mutant would give 1 (3000/2000)
                    assertEquals(3L, result.getValue());
                }

    @Test
              public void testDateToZipLong() throws Exception {
                  // Get the private method using reflection
                  Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
                  dateToZipLongMethod.setAccessible(true);
                  
                  // Test case 1: null input - should return null
                  Date nullDate = null;
                  ZipLong result1 = (ZipLong) dateToZipLongMethod.invoke(null, nullDate);
                  assertNull("Null date should return null", result1);
                
                  // Test case 2: non-null input - should return ZipLong
                  Date testDate = new Date(); // current date
                  ZipLong result2 = (ZipLong) dateToZipLongMethod.invoke(null, testDate);
                  assertNotNull("Non-null date should not return null", result2);
                  
                  // Verify the conversion is correct by checking the time (within 1 second tolerance)
                  long expectedSeconds = testDate.getTime() / 1000;
                  long actualSeconds = result2.getValue(); // Assuming ZipLong has getValue()
                  assertEquals("Time conversion should be correct", 
                              expectedSeconds, actualSeconds);
              }

    @Test
         public void testDateToZipLong_ShouldConvertMillisecondsToSeconds() throws Exception {
             // Create a fixed date for testing (e.g., 1234567890 milliseconds since epoch)
             Date testDate = new Date(1234567890L);
             
             // Get private methods via reflection
             Method dateToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
             Method unixTimeToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("unixTimeToZipLong", long.class);
             dateToZipLong.setAccessible(true);
             unixTimeToZipLong.setAccessible(true);
             
             // Expected value: 1234567890 / 1000 = 1234567 seconds
             ZipLong expected = (ZipLong) unixTimeToZipLong.invoke(null, 1234567L);
             
             // Actual value from method
             ZipLong actual = (ZipLong) dateToZipLong.invoke(null, testDate);
             
             // Assert equals - this will fail if the mutant is present
             // because mutant would produce 1234567890/100 = 12345678
             assertEquals(expected, actual);
             
             // Additional test with another value to be thorough
             Date testDate2 = new Date(9876543210L);
             ZipLong expected2 = (ZipLong) unixTimeToZipLong.invoke(null, 9876543L);
             ZipLong actual2 = (ZipLong) dateToZipLong.invoke(null, testDate2);
             assertEquals(expected2, actual2);
         }

    @Test
         public void testDateToZipLong_WithNullInput() throws Exception {
             // Test null input case
             Method dateToZipLongMethod = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
             dateToZipLongMethod.setAccessible(true);
             Object result = dateToZipLongMethod.invoke(null, (Date)null);
             assertNull(result);
         }

    @Test
    public void testDateToZipLongDetectsTimeUnitMutation() throws Exception {
        // Get the private method using reflection
        Method dateToZipLong = X5455_ExtendedTimestamp.class.getDeclaredMethod("dateToZipLong", Date.class);
        dateToZipLong.setAccessible(true);
        
        // Create a fixed date (January 1, 2020 00:00:00 GMT)
        Date testDate = new Date(1577836800000L); // This timestamp is known
        
        // Call the method - should convert milliseconds to seconds
        ZipLong result = (ZipLong) dateToZipLong.invoke(null, testDate);
        
        // Verify the result is the correct seconds value
        // Original correct value should be 1577836800 (1577836800000 / 1000)
        // Mutated version would return 1577836800000
        assertEquals(1577836800L, result.getValue());
        
        // Also test with null input
        assertNull(dateToZipLong.invoke(null, new Object[]{null}));
        
        // Test with current time to ensure general case works
        Date now = new Date();
        long expectedSeconds = now.getTime() / 1000;
        assertEquals(expectedSeconds, ((ZipLong) dateToZipLong.invoke(null, now)).getValue());
    }


}
