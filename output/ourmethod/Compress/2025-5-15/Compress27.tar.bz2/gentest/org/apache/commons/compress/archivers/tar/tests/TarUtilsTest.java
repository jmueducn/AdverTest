package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                  public void testParseOctal_ValidOctalNumbers() {
                                                      // Test typical octal values
                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', '0'}, 0, 2));
                                                      assertEquals(7L, TarUtils.parseOctal(new byte[]{'0', '7'}, 0, 2));
                                                      assertEquals(10L, TarUtils.parseOctal(new byte[]{'0', '1', '0'}, 0, 3));
                                                      assertEquals(511L, TarUtils.parseOctal(new byte[]{'0', '7', '7', '7'}, 0, 4));
                                                      
                                                      // Test with leading spaces
                                                      assertEquals(42L, TarUtils.parseOctal(new byte[]{' ', ' ', '0', '5', '2'}, 0, 5));
                                                      
                                                      // Test with trailing spaces
                                                      assertEquals(42L, TarUtils.parseOctal(new byte[]{'0', '5', '2', ' ', ' '}, 0, 5));
                                                      
                                                      // Test with both leading and trailing spaces
                                                      assertEquals(42L, TarUtils.parseOctal(new byte[]{' ', '0', '5', '2', ' '}, 0, 5));
                                                  }

 @Test
                                                  public void testParseOctal_LeadingZeroReturnsZero() {
                                                      // Test that leading zero (first character) returns 0
                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{'0', '1', '2'}, 0, 3));
                                                  }

 @Test
                                                  public void testParseOctal_EmptyOrAllSpaces() {
                                                      // Test all spaces
                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{' ', ' ', ' '}, 0, 3));
                                                      
                                                      // Test with offset and length
                                                      assertEquals(0L, TarUtils.parseOctal(new byte[]{'x', ' ', ' ', 'x'}, 1, 2));
                                                  }

 @Test
                                                  public void testParseOctal_InvalidLength() {
                                                      thrown.expect(IllegalArgumentException.class);
                                                      thrown.expectMessage("Length 1 must be at least 2");
                                                      TarUtils.parseOctal(new byte[]{'1'}, 0, 1);
                                                  }

 @Test
                                                  public void testParseOctal_InvalidCharacters() {
                                                      // Test non-octal digits
                                                      thrown.expect(IllegalArgumentException.class);
                                                      TarUtils.parseOctal(new byte[]{'0', '8'}, 0, 2);
                                                      
                                                      thrown.expect(IllegalArgumentException.class);
                                                      TarUtils.parseOctal(new byte[]{'0', 'a'}, 0, 2);
                                                      
                                                      thrown.expect(IllegalArgumentException.class);
                                                      TarUtils.parseOctal(new byte[]{'0', '9'}, 0, 2);
                                                  }

 @Test
                                                  public void testParseOctal_WithOffset() {
                                                      // Test with different offsets
                                                      byte[] buffer = {'x', 'x', '0', '1', '2', 'x', 'x'};
                                                      assertEquals(10L, TarUtils.parseOctal(buffer, 2, 3));
                                                      
                                                      buffer = new byte[]{'x', ' ', '1', '2', ' ', 'x'};
                                                      assertEquals(10L, TarUtils.parseOctal(buffer, 1, 4));
                                                  }

 @Test
                                                  public void testParseOctal_MaximumValue() {
                                                      // Test maximum 3-digit octal value
                                                      assertEquals(511L, TarUtils.parseOctal(new byte[]{'7', '7', '7'}, 0, 3));
                                                      
                                                      // Test maximum value with spaces
                                                      assertEquals(511L, TarUtils.parseOctal(new byte[]{' ', '7', '7', '7', ' '}, 0, 5));
                                                  }

 @Test
                                                  public void testParseOctal_TrailingNulls() {
                                                      // Test with trailing null bytes
                                                      assertEquals(42L, TarUtils.parseOctal(new byte[]{'0', '5', '2', 0, 0}, 0, 5));
                                                      
                                                      // Test with mixed trailing nulls and spaces
                                                      assertEquals(42L, TarUtils.parseOctal(new byte[]{'0', '5', '2', 0, ' '}, 0, 5));
                                                  }

 @Test
  public void testParseOctalWithLeadingZeroReturnsZero() {
      // Arrange
      byte[] buffer = new byte[]{0, '1', '2', '3'}; // First byte is 0
      int offset = 0;
      int length = 4;
      
      // Act
      long result = TarUtils.parseOctal(buffer, offset, length);
      
      // Assert
      assertEquals("Method should return 0 when first byte is 0", 0L, result);
  }

 @Test
     public void testParseOctalWithLeadingZero() {
         // Test case specifically designed to catch the return 0L -> return -1L mutant
         byte[] buffer = new byte[]{'0', '1', '2', '3'}; // First byte is '0'
         long result = TarUtils.parseOctal(buffer, 0, 4);
         assertEquals("Method should return 0 when first byte is '0'", 0L, result);
         
         // Additional test cases to ensure general functionality
         byte[] buffer2 = new byte[]{' ', '1', '2', '3'}; // Leading space
         assertEquals(83L, TarUtils.parseOctal(buffer2, 0, 4)); // 123 in octal is 83 in decimal
         
         byte[] buffer3 = new byte[]{'7', '7', ' ', ' '}; // Trailing spaces
         assertEquals(63L, TarUtils.parseOctal(buffer3, 0, 4)); // 77 in octal is 63 in decimal
     }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctalWithInvalidDigit() {
         byte[] buffer = new byte[]{'0', '8', '2', '3'}; // '8' is invalid in octal
         TarUtils.parseOctal(buffer, 0, 4);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testParseOctalWithShortLength() {
         byte[] buffer = new byte[]{'1'};
         TarUtils.parseOctal(buffer, 0, 1); // Length < 2 should throw
     }

}
